export const BACKUP_FORMAT_VERSION = 2 as const
export const PAOLO_DATA_FORMAT = "paolo-data-ndjson-gzip" as const
export const PG_DUMP_FORMAT = "postgresql-custom" as const

// Migrationsstand, auf dem ein Archiv erzeugt wurde: die Nummer der hoechsten
// Datei in drizzle/. Bis #102 stand hier unveraendert "0024", obwohl laengst
// weitere Migrationen hinzugekommen waren — jedes Archiv trug dieselbe Kennung,
// und die Versionspruefung beim Restore war wirkungslos.
// tests/backup/coverage.test.ts schlaegt fehl, sobald eine neue Migration
// hinzukommt und dieser Wert nicht mitgezogen wird.
export const PAOLO_SCHEMA_VERSION = "0036" as const

/**
 * Bis #102 eingefrorene Kennung. Archive mit diesem Wert koennen jeden
 * Migrationsstand zwischen 0024 und 0035 haben; ihr tatsaechliches Schema
 * steht nicht im Archiv. Sie werden nicht aus Kompatibilitaetsgruenden
 * akzeptiert, sondern mit Verweis auf den dokumentierten Weg abgelehnt.
 */
export const LEGACY_FROZEN_SCHEMA_VERSION = "0024" as const

export const BACKUP_ID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i

// Explicit dependency order. These names are constants owned by the application;
// archive input is never interpolated into SQL unless it matches this allowlist.
export const PAOLO_DATA_TABLES = [
  "organizations",
  "roles",
  "better_auth_users",
  "reports",
  // Aufbewahrungspruefungen (0027): Fremdschluessel auf organizations,
  // report_id zeigt fachlich auf reports — deshalb direkt danach.
  // Fehlten bis #102 im Archiv — nach einem Restore erschienen bereits
  // gepruefte Meldungen wieder als faellig, der Nachweis der Entscheidungen
  // war verloren.
  "report_retention_reviews",
  "organization_legal_settings",
  "safety_meetings",
  "privacy_incidents",
  "sms_documents",
  "user_roles",
  "better_auth_accounts",
  "better_auth_sessions",
  "better_auth_verifications",
  "measures",
  "attachments",
  "report_notes",
  "audit_logs",
] as const

/**
 * Tabellen des aktiven Schemas, die bewusst NICHT im PAOLO-Datenarchiv stehen.
 * Jede Ausnahme braucht eine Begruendung. tests/backup/coverage.test.ts
 * verlangt, dass jede Tabelle aus lib/db/schema.ts entweder archiviert oder
 * hier aufgefuehrt ist — eine neue Tabelle kann nicht mehr still fehlen.
 */
export const PAOLO_DATA_EXCLUDED_TABLES: Readonly<Record<string, string>> = {
  public_report_rate_limits:
    "Kurzlebige Missbrauchsschutz-Zaehler (pseudonymisierte Identifier, standardmaessig nach einem Tag zur Loeschung vorgesehen); kein fachlicher Bestand.",
  better_auth_login_rate_limits:
    "Kurzlebige Anmeldeschutz-Zaehler (HMAC-Identifier); kein fachlicher Bestand.",
  backup_cron_state:
    "Betriebszustand des Backup-Crons (Lease, letzter Lauf) der Quellinstallation; im Ziel bedeutungslos.",
}

export type PaoloDataTable = (typeof PAOLO_DATA_TABLES)[number]

export function isPaoloDataTable(value: string): value is PaoloDataTable {
  return (PAOLO_DATA_TABLES as readonly string[]).includes(value)
}

/** Verweis fuer Ablehnungen: wie ein Archiv eines anderen Stands zurueckgespielt wird. */
export const RESTORE_OTHER_SCHEMA_GUIDANCE =
  "Archiv mit dem PAOLO-Release wiederherstellen, auf dem es erzeugt wurde, und die Datenbank danach mit scripts/migrate.psql auf den aktuellen Stand bringen (docs/backup-restore.md, Abschnitt „Archiv eines anderen Migrationsstands“)."
