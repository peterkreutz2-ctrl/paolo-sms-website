/**
 * Technische Rollenschluessel. Sie sind Bestandteil der Datenbank (`roles.key`,
 * referenziert ueber `user_roles.role_id`) und werden NICHT umbenannt, wenn sich
 * eine Bezeichnung aendert.
 *
 * `instructor` ist ein historischer Schluessel: Die Rolle hiess bis 09/2026
 * „Fluglehrer“ und heisst seitdem **Safety Assistant**. Der Schluessel blieb,
 * weil eine Umbenennung eine Datenmigration ueber alle Installationen erzwingen
 * wuerde, ohne dass sich Verhalten oder Berechtigungen aendern. Dasselbe Muster
 * traegt bereits `user_roles.clerk_user_id`, das die Identitaets-ID des jeweils
 * gewaehlten Auth-Providers haelt (siehe AGENTS.md).
 *
 * Die sichtbare Bezeichnung steht ausschliesslich in ROLE_LABELS darunter.
 */
export const ROLE_KEYS = ["admin", "safety_manager", "instructor", "member"] as const

export type AppRoleKey = (typeof ROLE_KEYS)[number]

/**
 * Einzige Quelle für benutzerseitig sichtbare Rollenbezeichnungen. Die Spalte
 * `roles.label` in der Datenbank wird dafür bewusst NICHT gelesen (historischer
 * Seed-Wert, siehe drizzle/0003) — Anzeige immer über den Rollenkey hier.
 *
 * Deshalb kostet eine Umbenennung hier keine Migration: `roles.label` traegt
 * fuer `instructor` weiterhin „Fluglehrer“ und fuer `safety_manager` seit jeher
 * „Sicherheitsmanager“ — beides folgenlos, weil es niemand liest.
 */
export const ROLE_LABELS: Record<AppRoleKey, string> = {
  admin: "Administrator",
  safety_manager: "Safety Manager",
  instructor: "Safety Assistant",
  member: "Benutzer",
}

// ─── Fähigkeiten: die einzige Quelle ────────────────────────────────────────
//
// Vorher lagen die Berechtigungen an zwei Stellen: einer generischen
// Ressource/Aktion-Matrix in lib/auth/permissions.ts und den benannten
// Prädikaten hier. Beide führten dieselben Rollenlisten getrennt — wer eine
// änderte, änderte in fünf von sieben Fällen nichts, weil die Matrix
// überwiegend gar nicht aufgerufen wurde (#44).
//
// Jetzt gibt es eine Tabelle. Die benannten Prädikate darunter bleiben als
// dünne Zugriffe bestehen: Sie tragen die fachliche Absicht („wer darf
// bearbeiten"), die eine Zeichenkette wie "reports.edit" an der Aufrufstelle
// nicht transportiert — die Rollenliste steht aber nur noch hier.
//
// Im gesamten System gibt es genau vier Rollenmengen. Das ist kein Zufall,
// sondern das Modell: Administration, Bearbeitung, interner Zugang — und die
// gesamte angemeldete Mitgliedschaft. Die vierte kam mit #50/M1 hinzu und
// hat einen eigenen Grund, siehe MEMBERS. Eine fuenfte gehoert begruendet,
// nicht nebenbei ergaenzt; tests/auth/role-predicates.test.ts faellt darueber.

/** Nur Administratoren. */
const ADMINS: readonly AppRoleKey[] = ["admin"]

/** Bearbeiterkreis: darf Sicherheitsdaten verändern. */
const EDITORS: readonly AppRoleKey[] = ["admin", "safety_manager"]

/** Interner Zugang: darf lesen und mitarbeiten, aber nicht verändern. */
const INTERNAL: readonly AppRoleKey[] = ["admin", "safety_manager", "instructor"]

/**
 * Die gesamte angemeldete Mitgliedschaft — jede zugewiesene Rolle.
 *
 * Die **vierte** Rollenmenge, und die einzige. Sie existiert, weil das
 * Sichtbarkeitsmodell der SMS-Dokumente vier Stufen kennt (`confidential`,
 * `staff`, `members`, `public`) und die Stufe `members` bewusst offener ist
 * als `staff`: Sie adressiert alle Mitglieder, nicht nur den Bearbeiterkreis.
 * Drei Rollenmengen können vier Stufen nicht abbilden.
 *
 * Vorher stand diese Regel als `roleKeys.length > 0` in
 * `getReadableVisibilityDbValues` — die einzige Berechtigung im System, die
 * nicht über `can()` lief. Sie war nicht ausnutzbar, aber latent: Jede
 * künftige fünfte Rolle hätte den Lesezugriff auf `members`-Dokumente beim
 * Anlegen stillschweigend geerbt. Jetzt muss sie hier eingetragen werden.
 */
const MEMBERS: readonly AppRoleKey[] = [
  "admin",
  "safety_manager",
  "instructor",
  "member",
]

/**
 * Wer darf was. Ergänzungen gehören hierher und nirgendwo sonst.
 *
 * Die Schlüssel benennen Fähigkeiten, nicht Seiten oder Routen: Eine Fähigkeit
 * kann an mehreren Stellen gebraucht werden, und eine Seite kann mehrere
 * brauchen. Die Zuordnung Fähigkeit → Stelle steht in
 * docs/permission-matrix.md.
 */
export const ROLE_CAPABILITIES = {
  "reports.read": INTERNAL,
  // Ue1 (#50): Melderidentitaet und interner Bearbeitungsdiskurs sind ENGER
  // als der sicherheitsfachliche Inhalt. Beide liegen auf EDITORS, nicht auf
  // INTERNAL — es entsteht also KEINE fuenfte Rollenmenge, sondern zwei
  // Faehigkeiten auf einer bestehenden.
  //
  // Begruendung: Der Safety Assistant soll den Stand des Sicherheits-
  // managements kennen, arbeitet aber nicht am SMS-Regelkreis mit. Wer nicht
  // klassifiziert, bewertet, entscheidet und nicht an den Melder zurueck-
  // meldet, braucht dessen Identitaet fuer keine Aufgabe. Vertrauenswuerdig-
  // keit der Person senkt das Missbrauchsrisiko, begruendet aber keinen Zweck.
  "reports.reporter.read": EDITORS,
  "reports.notes.read": EDITORS,
  "reports.edit": EDITORS,
  "measures.read": INTERNAL,
  "measures.edit": EDITORS,
  "documents.read": INTERNAL,
  "documents.read.members": MEMBERS,
  "documents.edit": EDITORS,
  "attachments.access": INTERNAL,
  "roles.manage": INTERNAL,
  // Zugangsaktionen an einem Konto (Anmeldelink erneuern; Sperren folgt). ENGER
  // als `roles.manage`: Der Safety Assistant darf Rollen an Benutzern verwalten,
  // erhaelt aber keine Aktion, die den Zugang eines Kontos beruehrt (#111).
  "accounts.access": EDITORS,
  "admin.only": ADMINS,
} as const

export type RoleCapability = keyof typeof ROLE_CAPABILITIES

/**
 * Trägt mindestens eine der übergebenen Rollen diese Fähigkeit?
 *
 * Unbekannte Zeichenketten in roleKeys zählen nicht mit — sie können aus der
 * Datenbank kommen und dürfen nie zu einer Berechtigung führen.
 */
export function can(
  roleKeys: readonly AppRoleKey[],
  capability: RoleCapability
): boolean {
  const allowed = ROLE_CAPABILITIES[capability]
  return roleKeys.some((key) => allowed.includes(key))
}

// ─── Benannte Zugriffe ──────────────────────────────────────────────────────
// Jeder ist eine Zeile über der Tabelle. Sie existieren, weil der Name an der
// Aufrufstelle die Absicht trägt — nicht, weil sie eine eigene Regel hätten.

/** Darf Meldungen und den internen Bereich lesen. */
export function hasReportReadRole(roleKeys: readonly AppRoleKey[]): boolean {
  return can(roleKeys, "reports.read")
}

/**
 * Darf die strukturierte Melderidentitaet lesen — Name, Rolle, Kontakt.
 *
 * Enger als hasReportReadRole: Der sicherheitsfachliche Inhalt einer Meldung
 * (Beschreibung, Klassifikation, Status, Massnahmen) bleibt fuer den internen
 * Zugang offen, die Identitaet der meldenden Person nicht. Freitexte und
 * Anhaenge koennen weiterhin Personen erkennbar machen — das ist eine Frage
 * der Schreibdisziplin und der Datenschutzpruefung, nicht dieses Praedikats.
 */
export function hasReporterIdentityReadRole(
  roleKeys: readonly AppRoleKey[]
): boolean {
  return can(roleKeys, "reports.reporter.read")
}

/**
 * Darf interne Notizen und Nachtraege einer Meldung lesen.
 *
 * Notizen tragen den Bearbeitungsdiskurs — Verdachtsmomente, Bewertungen von
 * Personen, Namen Dritter — und nennen ihren Verfasser. Was der Safety
 * Assistant kennen soll, gehoert in Beschreibung, Klassifikation, Massnahme
 * oder SMS-Dokument, nicht in eine interne Notiz.
 */
export function hasReportNotesReadRole(
  roleKeys: readonly AppRoleKey[]
): boolean {
  return can(roleKeys, "reports.notes.read")
}

/** Darf Meldungen, Maßnahmen und SMS-Dokumente verändern. */
export function hasSafetyEditRole(roleKeys: readonly AppRoleKey[]): boolean {
  return can(roleKeys, "reports.edit")
}

/** Darf Maßnahmen lesen. */
export function hasMeasureReadRole(roleKeys: readonly AppRoleKey[]): boolean {
  return can(roleKeys, "measures.read")
}

/** Darf Anhänge an Meldungen hochladen und herunterladen. */
export function hasAttachmentAccessRole(
  roleKeys: readonly AppRoleKey[]
): boolean {
  return can(roleKeys, "attachments.access")
}

/** Nur Administratoren: Import, Export, Backups. */
export function hasAdminRole(roleKeys: readonly AppRoleKey[]): boolean {
  return can(roleKeys, "admin.only")
}

/**
 * Darf SMS-Dokumente überhaupt lesen. Welche Sichtbarkeitsstufen davon
 * tatsächlich sichtbar sind, entscheidet getReadableVisibilityDbValues in
 * lib/constants/sms-documents.ts — dieses Prädikat ist nur die Vorstufe.
 */
export function hasDocumentReadRole(roleKeys: readonly AppRoleKey[]): boolean {
  return can(roleKeys, "documents.read")
}

/**
 * Darf Dokumente der Stufe `members` lesen — also alles, was für die gesamte
 * angemeldete Mitgliedschaft bestimmt ist.
 *
 * Weiter als `hasDocumentReadRole`, nicht enger: `members` ist die offenere
 * Stufe. Wer intern lesen darf, darf das hier erst recht.
 */
export function hasMembersDocumentReadRole(
  roleKeys: readonly AppRoleKey[]
): boolean {
  return can(roleKeys, "documents.read.members")
}

export function isAppRoleKey(value: string): value is AppRoleKey {
  return (ROLE_KEYS as readonly string[]).includes(value)
}

/**
 * Which current role a target user may have for the actor to manage them.
 * safety_manager may only manage instructor and member users.
 */
export const MANAGEABLE_TARGET_ROLES: Readonly<Record<AppRoleKey, readonly AppRoleKey[]>> = {
  admin: ["admin", "safety_manager", "instructor", "member"],
  safety_manager: ["instructor", "member"],
  instructor: ["member"],
  member: [],
}

/**
 * Which roles the actor may REMOVE from a target user.
 * safety_manager may not remove the safety_manager role.
 */
export const REMOVABLE_ROLES: Readonly<Record<AppRoleKey, readonly AppRoleKey[]>> = {
  admin: ["admin", "safety_manager", "instructor", "member"],
  safety_manager: ["instructor", "member"],
  instructor: ["member"],
  member: [],
}

/**
 * Which roles the actor may ASSIGN to a target user.
 * safety_manager may elevate instructor/member to safety_manager, but not to admin.
 */
export const ASSIGNABLE_ROLES: Readonly<Record<AppRoleKey, readonly AppRoleKey[]>> = {
  admin: ["admin", "safety_manager", "instructor", "member"],
  safety_manager: ["safety_manager", "instructor", "member"],
  instructor: ["member"],
  member: [],
}

/**
 * Darf die Benutzerverwaltung öffnen. Welche Rollen der Handelnde dort
 * tatsächlich vergeben oder entziehen darf, entscheiden ASSIGNABLE_ROLES und
 * REMOVABLE_ROLES — auch hier ist das Prädikat nur die Vorstufe.
 */
export function canManageRoles(roleKeys: readonly AppRoleKey[]): boolean {
  return can(roleKeys, "roles.manage")
}

/** Darf Zugangsaktionen an Konten ausloesen (Administrator, Safety Manager). */
export function hasAccountAccessRole(roleKeys: readonly AppRoleKey[]): boolean {
  return can(roleKeys, "accounts.access")
}

/**
 * Darf der Handelnde eine Zugangsaktion (z. B. einen Anmeldelink erneuern) am
 * Zielkonto ausloesen? Zwei Bedingungen, beide noetig: die Faehigkeit
 * `accounts.access` UND der bisherige Zustaendigkeitsbereich der Rollenverwaltung
 * (`canManageTargetUser`). Nie am eigenen Konto.
 *
 * Das Zielkonto ohne Rolle ist verwaltbar (`canManageTargetUser` mit leerer
 * Liste); der Safety Assistant scheitert trotzdem schon an der Faehigkeit.
 */
export function canManageAccountAccess(
  actorRoles: readonly AppRoleKey[],
  targetCurrentRoles: readonly AppRoleKey[],
  isSelf: boolean
): boolean {
  if (isSelf) return false
  return hasAccountAccessRole(actorRoles) && canManageTargetUser(actorRoles, targetCurrentRoles)
}

/**
 * Darf der Handelnde das Konto loeschen? Wie `canManageAccountAccess`, zusaetzlich
 * nie bei einem Konto mit Administratorrolle: Die Rolle wird vorher regulaer
 * geaendert (Letzter-Administrator-Schutz). Der Safety Assistant scheitert schon an
 * der Faehigkeit `accounts.access`.
 */
export function canDeleteAccount(
  actorRoles: readonly AppRoleKey[],
  targetCurrentRoles: readonly AppRoleKey[],
  isSelf: boolean
): boolean {
  if (targetCurrentRoles.includes("admin")) return false
  return canManageAccountAccess(actorRoles, targetCurrentRoles, isSelf)
}

/** Returns all roles the actor may assign; used to build role dropdowns. */
export function getAssignableRoles(roleKeys: readonly AppRoleKey[]): AppRoleKey[] {
  const result = new Set<AppRoleKey>()
  for (const key of roleKeys) {
    for (const r of ASSIGNABLE_ROLES[key]) result.add(r)
  }
  return [...result]
}

/**
 * Can the actor manage the target user?
 * Every current role of the target must be within the actor's manageable targets.
 * Returns true for users with no existing roles (new users not yet in the system).
 */
export function canManageTargetUser(
  actorRoles: readonly AppRoleKey[],
  targetCurrentRoles: readonly AppRoleKey[]
): boolean {
  if (targetCurrentRoles.length === 0) return canManageRoles(actorRoles)
  return targetCurrentRoles.every((targetRole) =>
    actorRoles.some((actorRole) => MANAGEABLE_TARGET_ROLES[actorRole].includes(targetRole))
  )
}

/** Can the actor remove a specific role from a target user? */
export function canRemoveRole(
  actorRoles: readonly AppRoleKey[],
  roleToRemove: AppRoleKey
): boolean {
  return actorRoles.some((actorRole) => REMOVABLE_ROLES[actorRole].includes(roleToRemove))
}

/** Can the actor assign (give) a specific role to a target user? */
export function canAssignRole(
  actorRoles: readonly AppRoleKey[],
  roleToAssign: AppRoleKey
): boolean {
  return actorRoles.some((actorRole) => ASSIGNABLE_ROLES[actorRole].includes(roleToAssign))
}