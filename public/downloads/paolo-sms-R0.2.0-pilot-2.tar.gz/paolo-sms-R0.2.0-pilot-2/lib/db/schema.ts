import { sql } from "drizzle-orm"
// Active application schema; retired experimental AI tables are not entities.
// See docs/database-migrations.md for the replay contract.
import {
    date,
    index,
    jsonb,
    pgTable,
    text,
    timestamp,
    uuid,
    varchar,
    boolean,
    integer,
    uniqueIndex,
  } from "drizzle-orm/pg-core"

  
  export const organizations = pgTable("organizations", {
    id: uuid("id").defaultRandom().primaryKey(),
  
    name: text("name").notNull(),

    // Anzeigename im Kopf der Anwendung (#117). NULL = kein Name, es erscheint
    // nur "PAOLO SMS". Bewusst getrennt von `name` (Bootstrap-Wert): Die
    // Migration 0035 und der Bootstrap uebernehmen `name` einmalig, danach sind
    // beide Felder unabhaengig. Der Wert ist oeffentlich sichtbar.
    displayName: text("display_name"),

    type: text("type").notNull().default("flight_school"),
  
    safetyMeetingIntervalMonths: integer("safety_meeting_interval_months").notNull().default(12),

    // DSGVO-Retention-Review (Arbeitspaket 3): optionales, organisationsbezogenes
    // Pruefintervall in Monaten. NULL = Funktion nicht konfiguriert/deaktiviert —
    // PAOLO gibt keine Frist vor, siehe docs/data-protection-concept.md.
    reportRetentionReviewIntervalMonths: integer("report_retention_review_interval_months"),

    // Organisationsschalter fuer die oeffentliche Statusrueckmeldung
    // (/communications). true = die Box "Status von Sicherheitsmeldungen"
    // erscheint. false = die oeffentliche Abfrage liefert nichts und die Box
    // entfaellt; Meldungen, Codes und Workflow bleiben unberuehrt, und die
    // Dreimonatsfrist laeuft weiter. Voreinstellung "Ein", auch fuer
    // bestehende Installationen.
    publicReportStatusEnabled: boolean("public_report_status_enabled")
      .notNull()
      .default(true),

    // Datenschutz-Einwilligung auf /submit-report (#101). Voreinstellung "Ein",
    // auch fuer bestehende Installationen. Der Text ist NULL, solange der
    // Standardtext aus lib/constants/public-report-privacy-consent.ts gilt.
    publicReportPrivacyConsentEnabled: boolean(
      "public_report_privacy_consent_enabled"
    )
      .notNull()
      .default(true),
    publicReportPrivacyConsentText: text("public_report_privacy_consent_text"),

    // SMS-Verantwortung (rein dokumentarisch, siehe ICAO Annex 19).
    // Accountable Executive = nicht delegierbare Gesamtverantwortung (Accountability),
    // Safety Manager = delegierbare operative SMS-Aufgaben (Responsibility).
    // Diese Felder erzeugen KEINE Programmberechtigung und aendern die App-Rollen
    // (admin, safety_manager, instructor, member) nicht. "term" ist bewusst
    // Freitext (z. B. "seit 01/2026", "unbefristet"), keine Fristenlogik.
    accountableExecutiveName: text("accountable_executive_name"),
    accountableExecutiveFunction: text("accountable_executive_function"),
    accountableExecutiveContact: text("accountable_executive_contact"),
    accountableExecutiveTerm: text("accountable_executive_term"),

    safetyManagerName: text("safety_manager_name"),
    safetyManagerFunction: text("safety_manager_function"),
    safetyManagerContact: text("safety_manager_contact"),
    safetyManagerTerm: text("safety_manager_term"),

    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  })
  export const publicReportRateLimits = pgTable(
    "public_report_rate_limits",
    {
      id: uuid("id").defaultRandom().primaryKey(),
      organizationId: uuid("organization_id")
        .references(() => organizations.id, { onDelete: "cascade" })
        .notNull(),
      scope: text("scope").notNull(),
      identifier: text("identifier").notNull(),
      windowStart: timestamp("window_start", { withTimezone: true }).notNull(),
      windowDurationSeconds: integer("window_duration_seconds").notNull(),
      acceptedCount: integer("accepted_count").notNull().default(0),
      blockedCount: integer("blocked_count").notNull().default(0),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull(),
    },
    (t) => [
      uniqueIndex("public_report_rate_limits_unique")
        .on(t.organizationId, t.scope, t.identifier, t.windowStart),
      index("public_report_rate_limits_window_start_idx").on(t.windowStart),
    ]
  )

  // Anmeldeversuche fuer Better Auth. Die Identifier sind HMAC-Werte, nie
  // Klartext-E-Mail-Adressen oder IP-Adressen. Die Tabelle hat absichtlich
  // keinen Organisationsbezug: sie wird vor einer erfolgreichen Anmeldung
  // und damit vor jeder Rollen-/Organisationszuordnung verwendet.
  export const betterAuthLoginRateLimits = pgTable(
    "better_auth_login_rate_limits",
    {
      id: uuid("id").defaultRandom().primaryKey(),
      scope: text("scope").notNull(),
      identifier: text("identifier").notNull(),
      windowStart: timestamp("window_start", { withTimezone: true }).notNull(),
      windowDurationSeconds: integer("window_duration_seconds").notNull(),
      attemptCount: integer("attempt_count").notNull().default(0),
      blockedCount: integer("blocked_count").notNull().default(0),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull(),
    },
    (t) => [
      uniqueIndex("better_auth_login_rate_limits_unique").on(
        t.scope,
        t.identifier,
        t.windowStart
      ),
      index("better_auth_login_rate_limits_window_start_idx").on(t.windowStart),
    ]
  )

  export const reports = pgTable(
    "reports",
    {
      id: uuid("id").defaultRandom().primaryKey(),
  
    organizationId: uuid("organization_id")
      .references(() => organizations.id)
      .notNull(),
  
    reportType: text("report_type").notNull(),
    status: text("status").notNull().default("new"),
    priority: text("priority").notNull().default("medium"),
  
    shortDescription: varchar("short_description", {
      length: 120,
    }).notNull(),
  
    detailedDescription: text("detailed_description").notNull(),
  
    isAnonymous: boolean("is_anonymous").notNull().default(true),

    occurredAt: timestamp("occurred_at"),
    locationText: text("location_text"),
    reporterLessonsLearned: text("reporter_lessons_learned"),
    reporterSuggestedMeasures: text("reporter_suggested_measures"),
    sourceChannel: text("source_channel").notNull().default("public_form"),
    publicSubmissionId: uuid("public_submission_id"),

    activityArea: text("activity_area"),
    activityType: text("activity_type"),
    flightPhase: text("flight_phase"),
    launchType: text("launch_type"),
    // severity kept for backward-compat; injurySeverity + damageSeverity are the canonical fields
    severity: text("severity"),

    injurySeverity: text("injury_severity"),
    damageSeverity: text("damage_severity"),
    isReportableAccident: boolean("is_reportable_accident"),

    // ICAO-Risikomatrix (strukturierte Risikobewertung, rein dokumentarisch).
    // riskProbability: "1".."5" (Eintrittswahrscheinlichkeit / Safety Risk
    // Probability), riskSeverity: "A".."E" (Schweregrad / Safety Risk Severity).
    // Beide nullable = "nicht bewertet"; ersetzen priority/status NICHT.
    // Werte/Labels: lib/constants/report-risk.ts.
    riskProbability: text("risk_probability"),
    riskSeverity: text("risk_severity"),
    reporterName: text("reporter_name"),
    reporterRole: text("reporter_role"),
    reporterContact: text("reporter_contact"),

    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),

    deletedAt: timestamp("deleted_at"),
    deletedBy: text("deleted_by"),
    deleteReason: text("delete_reason"),

    // Manuelle Anonymisierung strukturierter Melderdaten (erster kontrollierter
    // Schritt). Freitexte und Anhaenge bleiben bewusst manuell zu pruefen.
    // anonymizationStatus ermoeglicht spaetere Abstufungen
    // (none / partial / completed / needs_review), siehe
    // lib/constants/report-anonymization.ts.
    anonymizedAt: timestamp("anonymized_at"),
    anonymizedBy: text("anonymized_by"),
    anonymizationNote: text("anonymization_note"),
    anonymizationStatus: text("anonymization_status").notNull().default("none"),

    // DSGVO-Retention-Review (Arbeitspaket 3): Fristanker, ab wann eine
    // Meldung fuer eine Aufbewahrungs-/Anonymisierungspruefung in Frage
    // kommt. Gesetzt beim ersten Wechsel nach "closed"/"hidden", geloescht
    // beim Verlassen dieser Gruppe, unveraendert bei Wechseln innerhalb der
    // Gruppe. Faelligkeiten werden dynamisch berechnet (Anker + Intervall
    // aus organizations.reportRetentionReviewIntervalMonths), nicht
    // materialisiert.
    retentionReviewEligibleAt: timestamp("retention_review_eligible_at"),

    // ─── Oeffentliche Statusrueckmeldung ────────────────────────────────────
    //
    // publicCode: neutraler Meldungscode ("Falke-12"). NULL heisst "kein
    // oeffentlicher Eintrag" — so bleiben Bestandsmeldungen und CSV-Importe
    // ausserhalb der oeffentlichen Liste, ohne dass es dafuer eine zweite
    // Regel braucht. Vergeben wird er beim Anlegen ueber das oeffentliche
    // Formular (lib/actions/reports.ts); das ausdrueckliche Operator-
    // Spieldaten-Fixture setzt feste synthetische Codes.
    //
    // publicClosedAt: Fristanker der Dreimonatsregel. Gesetzt beim WECHSEL
    // nach "closed", sonst unveraendert — siehe
    // computePublicClosedAtUpdate in lib/constants/public-report-status.ts.
    // Bewusst mit Zeitzone: aus dieser Spalte wird gerechnet, und das Ergebnis
    // darf nicht von der Sitzungszeitzone der Installation abhaengen.
    publicCode: text("public_code"),
    publicClosedAt: timestamp("public_closed_at", { withTimezone: true }),

    // ─── Nachweis der Datenschutz-Einwilligung (#101) ───────────────────────
    //
    // Gesetzt nur fuer Meldungen ueber das oeffentliche Formular, wenn die
    // Einwilligungsabfrage der Organisation eingeschaltet war. Alle drei
    // gemeinsam belegt oder gemeinsam NULL — die CHECK-Bedingung
    // `reports_privacy_consent_complete` (Migration 0034) sichert das in der
    // Datenbank ab. Snapshots statt Hash/Version: in sich geschlossen, ohne
    // Texthistorie. Bestandsmeldungen bleiben NULL (kein Backfill).
    privacyConsentAt: timestamp("privacy_consent_at", { withTimezone: true }),
    privacyConsentText: text("privacy_consent_text"),
    privacyPolicySnapshot: text("privacy_policy_snapshot"),
  },
  (t) => [
    uniqueIndex("reports_public_submission_unique").on(t.publicSubmissionId),
  ]
)

  export const measures = pgTable("measures", {
    id: uuid("id").defaultRandom().primaryKey(),

    reportId: uuid("report_id")
      .references(() => reports.id, { onDelete: "cascade" })
      .notNull(),

    title: varchar("title", { length: 200 }).notNull(),
    description: text("description"),
    assignedToText: text("assigned_to_text"),
    status: text("status").notNull().default("open"),
    dueDate: timestamp("due_date", { withTimezone: true, mode: "date" }),

    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  })

  export const safetyMeetings = pgTable("safety_meetings", {
    id: uuid("id").defaultRandom().primaryKey(),
    organizationId: uuid("organization_id")
      .references(() => organizations.id)
      .notNull(),
    meetingDate: date("meeting_date").notNull(),
    title: varchar("title", { length: 200 }),
    notes: text("notes"),
    createdByClerkUserId: text("created_by_clerk_user_id").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  })

  export const roles = pgTable(
    "roles",
    {
      id: uuid("id").defaultRandom().primaryKey(),
      key: text("key").notNull(),
      label: text("label").notNull(),
      createdAt: timestamp("created_at").defaultNow().notNull(),
    },
    (t) => [uniqueIndex("roles_key_unique").on(t.key)]
  )

  export const userRoles = pgTable(
    "user_roles",
    {
      id: uuid("id").defaultRandom().primaryKey(),
      clerkUserId: text("clerk_user_id").notNull(),
      roleId: uuid("role_id")
        .references(() => roles.id, { onDelete: "cascade" })
        .notNull(),
      organizationId: uuid("organization_id")
        .references(() => organizations.id, { onDelete: "cascade" }),
      createdAt: timestamp("created_at").defaultNow().notNull(),
    },
    (t) => [
      uniqueIndex("user_roles_single_global_unique")
        .on(t.clerkUserId)
        .where(sql`${t.organizationId} IS NULL`),
      uniqueIndex("user_roles_org_unique")
        .on(t.clerkUserId, t.roleId, t.organizationId)
        .where(sql`${t.organizationId} IS NOT NULL`),
    ]
  )

  // Anhaenge fuer Meldungen UND SMS-Dokumente.
  // Bewusst eine gemeinsame Tabelle statt einer zweiten Attachment-
  // Infrastruktur: Upload, Storage, Validierung und Loeschung bleiben
  // identisch. Genau eine der beiden Zuordnungen ist gesetzt; erzwungen wird
  // das von der CHECK-Bedingung `attachments_exactly_one_owner` aus Migration
  // 0029, nicht nur vom Anwendungscode.
  //
  // smsDocumentId hat bewusst KEIN onDelete: "cascade" (anders als reportId):
  // ein Cascade wuerde die Zeilen still entfernen und die Dateien im
  // Blob-Speicher verwaisen lassen. deleteSmsDocument() loescht deshalb erst
  // die Dateien und dann die Zeilen.
  //
  // Sichtbarkeits-/Freigabefelder fehlen hier absichtlich — die oeffentliche
  // Freigabe ist Gegenstand spaeterer Arbeitspakete.
  export const attachments = pgTable(
    "attachments",
    {
      id: uuid("id").defaultRandom().primaryKey(),

      reportId: uuid("report_id").references(() => reports.id, {
        onDelete: "cascade",
      }),

      smsDocumentId: uuid("sms_document_id").references(() => smsDocuments.id),

      // Oeffentliche Freigabe (Migration 0030). DEFAULT false: eine
      // Veroeffentlichung ist immer eine bewusste Aenderung, nie ein
      // Nebeneffekt. Nur Anhaenge von SMS-Dokumenten duerfen oeffentlich sein;
      // das erzwingt die CHECK-Bedingung
      // `attachments_public_only_for_sms_documents` auf Datenbankebene.
      // Freigabedatum, freigebender Benutzer und Freigabevermerk gehoeren zum
      // Freigabe-Workflow und fehlen hier bewusst.
      isPublic: boolean("is_public").notNull().default(false),

      // Freigabenachweis (Migration 0031). Bleibt beim Widerruf bewusst
      // erhalten: die Felder bedeuten "letzte Freigabe", nicht "aktuell
      // oeffentlich" — dafuer steht allein isPublic. So bleibt nachvoll-
      // ziehbar, wer wann mit welcher Begruendung veroeffentlicht hat, auch
      // nachdem die Freigabe zurueckgenommen wurde.
      //
      // Die CHECK-Bedingung `attachments_public_requires_release_record`
      // erzwingt auf Datenbankebene, dass isPublic ohne vollstaendigen
      // Nachweis gar nicht gesetzt werden kann.
      //
      // Die bestaetigte Checkliste steht bewusst nicht hier: einzelne
      // Boolean-Spalten koennten nur `true` enthalten und traegen damit keine
      // Information. Ihr Zustand samt Version liegt im Audit-Ereignis.
      publicReleasedAt: timestamp("public_released_at"),
      publicReleasedByClerkUserId: text("public_released_by_clerk_user_id"),
      publicReleaseNote: text("public_release_note"),

      originalFileName: text("original_file_name").notNull(),
      mimeType: text("mime_type").notNull(),
      fileSize: integer("file_size").notNull(),

      storageProvider: text("storage_provider").notNull(),
      storageKey: text("storage_key").notNull(),
      publicUrl: text("public_url").notNull(),

      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull(),
    },
    (t) => [
      index("attachments_sms_document_idx").on(t.smsDocumentId, t.createdAt),
    ]
  )

  export const reportNotes = pgTable(
    "report_notes",
    {
      id: uuid("id").defaultRandom().primaryKey(),
      organizationId: uuid("organization_id")
        .references(() => organizations.id)
        .notNull(),
      reportId: uuid("report_id")
        .references(() => reports.id, { onDelete: "cascade" })
        .notNull(),
      authorClerkUserId: text("author_clerk_user_id").notNull(),
      noteType: text("note_type").notNull(),
      content: text("content").notNull(),
      createdAt: timestamp("created_at").defaultNow().notNull(),
    },
    (t) => [
      index("report_notes_report_idx").on(t.reportId, t.createdAt),
      index("report_notes_org_idx").on(t.organizationId, t.createdAt),
    ]
  )

  // DSGVO-Retention-Review-Prüfprotokoll (Arbeitspaket 4): dokumentiert
  // bewusste Entscheidungen ("geprüft/keine Aktion", "zurückgestellt",
  // "anonymisiert", "gelöscht") zu einem Report im Rahmen der periodischen
  // Aufbewahrungsprüfung. Schreibt/löscht keine Reportdaten selbst — reine
  // Dokumentation, ergänzend zu den bestehenden Anonymisierungs-/
  // Löschaktionen. reportId bewusst OHNE Fremdschlüssel-Constraint (Muster
  // wie auditLogs.resourceId), damit ein Hard Delete des Reports die
  // Prüfhistorie nicht mitreisst. reportType und computedDueAt sind
  // Snapshots zum Entscheidungszeitpunkt, damit eine Zeile auch nach einem
  // Hard Delete eigenstaendig verstaendlich bleibt, ohne Melderdaten oder
  // Freitext zu duplizieren.
  export const reportRetentionReviews = pgTable(
    "report_retention_reviews",
    {
      id: uuid("id").defaultRandom().primaryKey(),
      reportId: uuid("report_id").notNull(),
      organizationId: uuid("organization_id")
        .references(() => organizations.id)
        .notNull(),
      reportType: text("report_type").notNull(),
      decision: text("decision").notNull(),
      reason: text("reason"),
      postponedUntil: date("postponed_until"),
      computedDueAt: timestamp("computed_due_at").notNull(),
      reviewedByClerkUserId: text("reviewed_by_clerk_user_id").notNull(),
      createdAt: timestamp("created_at").defaultNow().notNull(),
    },
    (t) => [
      index("report_retention_reviews_report_idx").on(t.reportId, t.createdAt),
      index("report_retention_reviews_org_idx").on(t.organizationId, t.createdAt),
    ]
  )

  export const auditLogs = pgTable(
    "audit_logs",
    {
      id: uuid("id").defaultRandom().primaryKey(),
      organizationId: uuid("organization_id")
        .references(() => organizations.id)
        .notNull(),
      clerkUserId: text("clerk_user_id"),
      action: text("action").notNull(),
      resourceType: text("resource_type").notNull(),
      resourceId: uuid("resource_id").notNull(),
      changes: jsonb("changes"),
      createdAt: timestamp("created_at").defaultNow().notNull(),
    },
    (t) => [
      index("audit_logs_org_created_idx").on(t.organizationId, t.createdAt),
      index("audit_logs_resource_idx").on(t.resourceId),
      index("audit_logs_user_idx").on(t.clerkUserId),
    ]
  )

  // Singleton coordination row for externally triggered scheduled backups.
  export const backupCronState = pgTable("backup_cron_state", {
    key: text("key").primaryKey(),
    status: text("status").notNull(),
    lastStartedAt: timestamp("last_started_at", { withTimezone: true }).notNull(),
    leaseExpiresAt: timestamp("lease_expires_at", { withTimezone: true }).notNull(),
    lastCompletedAt: timestamp("last_completed_at", { withTimezone: true }),
    lastBackupId: uuid("last_backup_id"),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  })

  // Betreiberspezifische Rechtsangaben (Impressum / Datenschutzerklärung).
  // 1:1 zur Organisation. Alle Inhaltsfelder sind optional — die Texte bleiben
  // prüfpflichtig und werden vom Betreiber der jeweiligen Instanz gepflegt.
  export const organizationLegalSettings = pgTable(
    "organization_legal_settings",
    {
      id: uuid("id").defaultRandom().primaryKey(),
      organizationId: uuid("organization_id")
        .references(() => organizations.id, { onDelete: "cascade" })
        .notNull(),

      operatorName: text("operator_name"),
      operatorLegalForm: text("operator_legal_form"),
      operatorAddress: text("operator_address"),
      operatorEmail: text("operator_email"),
      operatorPhone: text("operator_phone"),
      representedBy: text("represented_by"),
      registerInfo: text("register_info"),
      vatId: text("vat_id"),
      supervisoryAuthority: text("supervisory_authority"),

      privacyResponsibleName: text("privacy_responsible_name"),
      privacyContactEmail: text("privacy_contact_email"),
      dataProtectionOfficer: text("data_protection_officer"),
      hostingProviderInfo: text("hosting_provider_info"),
      dataRetentionInfo: text("data_retention_info"),

      legalExtraText: text("legal_extra_text"),
      privacyExtraText: text("privacy_extra_text"),

      // Vollstaendige, betreiber-editierbare Datenschutzerklaerung (Langtext,
      // getrennt von den kurzen strukturierten Feldern oben). Migration 0019.
      privacyPolicyText: text("privacy_policy_text"),

      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull(),
    },
    (t) => [
      uniqueIndex("organization_legal_settings_org_unique").on(
        t.organizationId
      ),
    ]
  )

  // SMS-Dokumentenablage: strukturierte SMS-Dokumentation (Sicherheitsrichtlinie,
  // SMS-Handbuch, Notfallpläne, Protokolle der Sicherheitsbesprechungen) als
  // reiner Text/Markdown. Kein allgemeines Dokumentenmanagement, keine
  // Safety-Communication. category/visibility sind Freitext auf DB-Ebene und
  // werden über lib/constants/sms-documents.ts + Zod validiert (analog zu den
  // übrigen Workflow-Strings). visibility steuert nur die Sichtbarkeit für die
  // Rolle instructor (internal = nur admin/safety_manager, published = auch
  // instructor). Bewusst NICHT enthalten: Uploads, Versionierung, Review-Felder
  // (reviewDueAt/reviewIntervalMonths) — spätere Ausbaustufen, siehe
  // docs/development-log.md. Ein späteres optionales safetyMeetingId bleibt offen.
  export const smsDocuments = pgTable(
    "sms_documents",
    {
      id: uuid("id").defaultRandom().primaryKey(),
      organizationId: uuid("organization_id")
        .references(() => organizations.id, { onDelete: "cascade" })
        .notNull(),

      category: text("category").notNull(),
      title: varchar("title", { length: 200 }).notNull(),
      content: text("content").notNull(),
      // Dreistufig: confidential | staff | public (Migration 0023 stellt die
      // Altwerte internal→confidential, published→staff um).
      visibility: text("visibility").notNull().default("confidential"),

      createdByClerkUserId: text("created_by_clerk_user_id").notNull(),
      updatedByClerkUserId: text("updated_by_clerk_user_id"),

      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull(),
    },
    (t) => [
      index("sms_documents_org_category_created_idx").on(
        t.organizationId,
        t.category,
        t.createdAt
      ),
      index("sms_documents_org_visibility_idx").on(
        t.organizationId,
        t.visibility
      ),
    ]
  )

  // Dokumentation von Datenschutzvorfällen (Incident-Response).
  // Reines Dokumentations-/Nachverfolgungsmodul: PAOLO trifft keine rechtliche
  // Entscheidung und versendet keine automatische Meldung. Statuswerte und
  // Labels: lib/constants/privacy-incidents.ts.
  export const privacyIncidents = pgTable(
    "privacy_incidents",
    {
      id: uuid("id").defaultRandom().primaryKey(),
      organizationId: uuid("organization_id")
        .references(() => organizations.id, { onDelete: "cascade" })
        .notNull(),

      title: text("title").notNull(),
      status: text("status").notNull().default("new"),

      discoveredAt: timestamp("discovered_at"),
      discoveredByText: text("discovered_by_text"),

      description: text("description").notNull(),
      affectedDataCategories: text("affected_data_categories"),
      affectedPersonsEstimate: text("affected_persons_estimate"),
      immediateActions: text("immediate_actions"),

      riskAssessment: text("risk_assessment").notNull().default("unknown"),
      notificationDecision: text("notification_decision")
        .notNull()
        .default("open"),
      decisionReason: text("decision_reason"),
      followUpActions: text("follow_up_actions"),

      closedAt: timestamp("closed_at"),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull(),
    },
    (t) => [
      index("privacy_incidents_org_created_idx").on(
        t.organizationId,
        t.createdAt
      ),
    ]
  )

  // Better Auth core tables. They are deliberately namespaced to avoid
  // collisions with PAOLO's existing role/user-role domain tables.
  export const betterAuthUsers = pgTable(
    "better_auth_users",
    {
      id: text("id").primaryKey(),
      name: text("name").notNull(),
      email: text("email").notNull(),
      emailVerified: boolean("email_verified").default(false).notNull(),
      image: text("image"),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull(),
    },
    (t) => [uniqueIndex("better_auth_users_email_unique").on(t.email)]
  )

  export const betterAuthSessions = pgTable(
    "better_auth_sessions",
    {
      id: text("id").primaryKey(),
      expiresAt: timestamp("expires_at").notNull(),
      token: text("token").notNull(),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull(),
      ipAddress: text("ip_address"),
      userAgent: text("user_agent"),
      userId: text("user_id")
        .references(() => betterAuthUsers.id, { onDelete: "cascade" })
        .notNull(),
    },
    (t) => [
      uniqueIndex("better_auth_sessions_token_unique").on(t.token),
      index("better_auth_sessions_user_id_idx").on(t.userId),
    ]
  )

  export const betterAuthAccounts = pgTable(
    "better_auth_accounts",
    {
      id: text("id").primaryKey(),
      accountId: text("account_id").notNull(),
      providerId: text("provider_id").notNull(),
      userId: text("user_id")
        .references(() => betterAuthUsers.id, { onDelete: "cascade" })
        .notNull(),
      accessToken: text("access_token"),
      refreshToken: text("refresh_token"),
      idToken: text("id_token"),
      accessTokenExpiresAt: timestamp("access_token_expires_at"),
      refreshTokenExpiresAt: timestamp("refresh_token_expires_at"),
      scope: text("scope"),
      password: text("password"),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull(),
    },
    (t) => [
      uniqueIndex("better_auth_accounts_provider_account_unique").on(
        t.providerId,
        t.accountId
      ),
      index("better_auth_accounts_user_id_idx").on(t.userId),
    ]
  )

  export const betterAuthVerifications = pgTable(
    "better_auth_verifications",
    {
      id: text("id").primaryKey(),
      identifier: text("identifier").notNull(),
      value: text("value").notNull(),
      expiresAt: timestamp("expires_at").notNull(),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull(),
    },
    (t) => [
      index("better_auth_verifications_identifier_idx").on(t.identifier),
    ]
  )
