import "server-only"
import { randomBytes } from "node:crypto"
import { clerkClient } from "@clerk/nextjs/server"
import { hashPassword } from "better-auth/crypto"
import { and, eq, inArray } from "drizzle-orm"
import { usesBetterAuth, usesFileAuth } from "@/lib/auth"
import { getFileUsers } from "@/lib/auth/file-auth"
import { isClerkAPIResponseError } from "@clerk/nextjs/errors"
import { splitName } from "@/lib/auth/account-lifecycle"
import { getBetterAuth } from "@/auth"
import { ACCESS_LINK_TTL_SECONDS, buildPasswordLinkUrl, captureResetToken, resolveAccessLinkBaseUrl } from "@/lib/auth/access-link"
import { fetchAllPages } from "@/lib/auth/user-overview"
import { db } from "@/lib/db"
import { betterAuthAccounts, betterAuthUsers } from "@/lib/db/schema"

export type DirectoryUser = { id: string; email: string; displayName: string }
export const FILE_USER_MANAGEMENT_MESSAGE = "Benutzer werden im Entwicklungsmodus über config/dev-users.json verwaltet."
function normalize(user: { id: string; firstName: string | null; lastName: string | null; primaryEmailAddressId: string | null; emailAddresses: Array<{ id: string; emailAddress: string }> }): DirectoryUser {
  const email = user.emailAddresses.find((item) => item.id === user.primaryEmailAddressId)?.emailAddress ?? user.emailAddresses[0]?.emailAddress ?? ""
  return { id: user.id, email, displayName: [user.firstName, user.lastName].filter(Boolean).join(" ").trim() || email || user.id }
}
export async function listDirectoryUsers(options?: { ids?: string[]; email?: string; limit?: number }) {
  if (usesFileAuth()) {
    let users = getFileUsers().map(({ id, email, displayName }) => ({ id, email, displayName }))
    if (options?.ids) users = users.filter((u) => options.ids!.includes(u.id))
    if (options?.email) users = users.filter((u) => u.email.toLowerCase() === options.email!.toLowerCase())
    return users.slice(0, options?.limit)
  }
  if (usesBetterAuth()) {
    const conditions = []
    if (options?.ids?.length) conditions.push(inArray(betterAuthUsers.id, options.ids))
    if (options?.email) conditions.push(eq(betterAuthUsers.email, options.email.toLowerCase()))
    const rows = await db.select({ id: betterAuthUsers.id, email: betterAuthUsers.email, name: betterAuthUsers.name }).from(betterAuthUsers).where(conditions.length ? and(...conditions) : undefined).limit(options?.limit ?? 100)
    return rows.map((user) => ({ id: user.id, email: user.email, displayName: user.name || user.email }))
  }
  const client = await clerkClient(); const { data } = await client.users.getUserList({ ...(options?.ids ? { userId: options.ids } : {}), ...(options?.email ? { emailAddress: [options.email] } : {}), limit: options?.limit ?? 100 })
  return data.map(normalize)
}
// Alle Konten des Verzeichnisses, ohne Obergrenze. Clerk liefert nur seitenweise
// (hoechstens 500 je Abruf); fetchAllPages liest bis `totalCount` und wirft,
// wenn Konten fehlen, statt die Liste still abzuschneiden. Better Auth und die
// Entwicklungsdatei kennen kein Limit.
export async function listAllDirectoryUsers(): Promise<DirectoryUser[]> {
  if (usesFileAuth()) return listDirectoryUsers()
  if (usesBetterAuth()) {
    const rows = await db.select({ id: betterAuthUsers.id, email: betterAuthUsers.email, name: betterAuthUsers.name }).from(betterAuthUsers)
    return rows.map((user) => ({ id: user.id, email: user.email, displayName: user.name || user.email }))
  }
  const client = await clerkClient()
  const users = await fetchAllPages(async (offset, limit) => {
    const { data, totalCount } = await client.users.getUserList({ limit, offset, orderBy: "+created_at" })
    return { data: data.map(normalize), totalCount }
  })
  return users
}
// Welche der Kennungen gehoeren zu einem Konto, das im Verzeichnis existiert?
// `null` heisst: Das Verzeichnis war nicht erreichbar — der Aufrufer darf daraus
// weder „existiert“ noch „existiert nicht“ schliessen.
export async function findLiveAccountIds(ids: readonly string[]): Promise<Set<string> | null> {
  const unique = [...new Set(ids)]
  if (unique.length === 0) return new Set()
  try {
    const found = new Set<string>()
    for (let start = 0; start < unique.length; start += 100) {
      const chunk = unique.slice(start, start + 100)
      for (const user of await listDirectoryUsers({ ids: chunk, limit: chunk.length })) found.add(user.id)
    }
    return found
  } catch {
    return null
  }
}
export async function createDirectoryUser(input: { email: string; name?: string }) {
  if (usesFileAuth()) throw new Error(FILE_USER_MANAGEMENT_MESSAGE)
  if (usesBetterAuth()) {
    if (!input.name?.trim()) throw new Error("Name ist erforderlich.")
    const id = crypto.randomUUID()
    const now = new Date()
    const password = await hashPassword(randomBytes(32).toString("base64url"))
    await db.transaction(async (tx) => {
      await tx.insert(betterAuthUsers).values({ id, name: input.name!.trim(), email: input.email.toLowerCase(), emailVerified: true, createdAt: now, updatedAt: now })
      await tx.insert(betterAuthAccounts).values({ id: crypto.randomUUID(), accountId: id, providerId: "credential", userId: id, password, createdAt: now, updatedAt: now })
    })
    return { id, email: input.email.toLowerCase(), displayName: input.name.trim() }
  }
  const client = await clerkClient(); return normalize(await client.users.createUser({ emailAddress: [input.email], skipPasswordRequirement: true }))
}
export async function createDirectorySignInUrl(userId: string, requestOrigin?: string | null) {
  if (usesFileAuth() || usesBetterAuth()) throw new Error(FILE_USER_MANAGEMENT_MESSAGE)
  const client = await clerkClient(); const token = await client.signInTokens.createSignInToken({ userId, expiresInSeconds: ACCESS_LINK_TTL_SECONDS }); const url = new URL("/sign-in", resolveAccessLinkBaseUrl(requestOrigin)); url.searchParams.set("__clerk_ticket", token.token); return url.toString()
}

// ─── Konto lesen, Name aendern, loeschen (#114) ─────────────────────────────
// Better Auth wird fuer Aenderung und Loeschung direkt in der Datenbank behandelt
// (lib/auth/account-lifecycle-db.ts), damit es mit Rollen und Audit in EINER
// Transaktion laeuft. Die folgenden Funktionen betreffen den Anbieter Clerk.

/** Das Konto mit dieser Kennung, `null` wenn es nicht existiert. Wirft, wenn das Verzeichnis nicht erreichbar ist. */
export async function getDirectoryUser(userId: string): Promise<DirectoryUser | null> {
  const [user] = await listDirectoryUsers({ ids: [userId], limit: 1 })
  return user ?? null
}
export async function updateClerkAccountName(userId: string, name: string): Promise<void> {
  if (usesFileAuth() || usesBetterAuth()) throw new Error(FILE_USER_MANAGEMENT_MESSAGE)
  const client = await clerkClient()
  await client.users.updateUser(userId, splitName(name))
}
/** Loescht das Clerk-Konto. „Nicht gefunden“ gilt als bereits geloescht (Wiederholung bleibt unschaedlich). */
export async function deleteClerkAccount(userId: string): Promise<"deleted" | "not-found"> {
  if (usesFileAuth() || usesBetterAuth()) throw new Error(FILE_USER_MANAGEMENT_MESSAGE)
  const client = await clerkClient()
  try {
    await client.users.deleteUser(userId)
    return "deleted"
  } catch (error) {
    if (isClerkAPIResponseError(error) && error.status === 404) return "not-found"
    throw error
  }
}

// Ein Link, mit dem die Person (wieder) Zugang bekommt: bei Clerk ein neuer
// Sign-in-Link, bei Better Auth ein Link zum Festlegen eines neuen Passworts.
// Beide gelten ACCESS_LINK_TTL_SECONDS (sieben Tage). Aeltere Links bleiben bis
// zu ihrem Ablauf gueltig — Clerk kann Token nicht auflisten, und in das interne
// Token-Speicherformat von Better Auth greift PAOLO nicht ein.
//
// Der Link ist ein Zugangsschluessel: Er wird nur zurueckgegeben, nie
// protokolliert und nie in eine Fehlermeldung aufgenommen.
export type DirectoryAccessLink = { url: string; kind: "sign-in" | "password" }
export async function createDirectoryAccessLink(userId: string, requestOrigin?: string | null): Promise<DirectoryAccessLink> {
  if (usesFileAuth()) throw new Error(FILE_USER_MANAGEMENT_MESSAGE)
  if (!usesBetterAuth()) return { url: await createDirectorySignInUrl(userId, requestOrigin), kind: "sign-in" }

  const [account] = await db.select({ email: betterAuthUsers.email }).from(betterAuthUsers).where(eq(betterAuthUsers.id, userId)).limit(1)
  if (!account) throw new Error("Konto nicht gefunden.")
  const { token } = await captureResetToken(() => getBetterAuth().api.requestPasswordReset({ body: { email: account.email } }))
  if (!token) throw new Error("Better Auth hat kein Token geliefert.")
  return { url: buildPasswordLinkUrl(resolveAccessLinkBaseUrl(requestOrigin), token), kind: "password" }
}
