// Anmelde- und Passwortlinks (Issue #111). Reine Logik ohne Datenbank- und
// Providerzugriff, damit sie ohne Umgebung testbar bleibt
// (tests/auth/access-link.test.ts).
import { AsyncLocalStorage } from "node:async_hooks"
import { createHash } from "node:crypto"

/**
 * Gueltigkeit jedes Links, den ein Administrator oder Safety Manager
 * bereitstellt: sieben Tage. Eine Konstante fuer beide Anbieter — Clerk
 * (`expiresInSeconds` des Sign-in-Tokens) und Better Auth
 * (`resetPasswordTokenExpiresIn`).
 *
 * Aeltere Links werden NICHT widerrufen, wenn ein neuer ausgestellt wird:
 * Clerk kann Token nicht auflisten, und Better Auth speichert sie in einem
 * internen Format, in das PAOLO nicht eingreift. Sie gelten bis zu ihrem Ablauf.
 */
export const ACCESS_LINK_TTL_SECONDS = 7 * 24 * 60 * 60

// Der Fragment-Pfad der Seite „Passwort festlegen“. Das Token steht hinter dem
// `#` und erreicht deshalb weder Serverprotokolle noch das Referer-Feld.
export const SET_PASSWORD_PATH = "/set-password"

export function buildPasswordLinkUrl(baseUrl: string, token: string): string {
  const url = new URL(SET_PASSWORD_PATH, baseUrl)
  url.hash = token
  return url.toString()
}

export function resolveAccessLinkBaseUrl(
  requestOrigin?: string | null,
  env: Record<string, string | undefined> = process.env
): string {
  if (requestOrigin) {
    try {
      const url = new URL(requestOrigin)
      const isHttp = url.protocol === "http:" || url.protocol === "https:"
      const isOriginOnly =
        url.pathname === "/" && !url.search && !url.hash && !url.username && !url.password
      if (isHttp && isOriginOnly) return url.origin
    } catch {
      // Kein gueltiger Request-Origin: auf die Betreiberkonfiguration fallen.
    }
  }

  return env.APP_BASE_URL || env.BETTER_AUTH_URL || "http://localhost:3000"
}

// ─── Audit-Kennung eines Kontos ─────────────────────────────────────────────
//
// `audit_logs.resource_id` ist eine UUID (Migration 0006). Die Kennung eines
// Kontos ist es nicht immer: Better-Auth-Konten tragen eine UUID, Clerk-Konten
// aber `user_…`. Ein Audit-Eintrag mit der rohen Clerk-Kennung scheitert an
// Postgres (22P02) — genau das schlug beim ersten Clerk-Test von #111 zu, waehrend
// jeder Better-Auth-Lauf gruen blieb.
//
// Deshalb erhaelt jedes Konto eine daraus abgeleitete, stabile UUID (Version 5,
// RFC 4122): gleiche Kennung → gleiche UUID, sodass Eintraege zu einem Konto ueber
// den Index auf `resource_id` zusammenfindbar bleiben. Die Kennung selbst steht
// weiter in `changes.targetClerkUserId`; die abgeleitete UUID ist nur der
// Ordnungsschluessel. Keine Migration noetig.
export const ACCOUNT_AUDIT_NAMESPACE = "6f1d8a3e-7c52-4b1e-9a43-2d0b8c7e4f10"

export function accountAuditResourceId(
  accountId: string,
  namespace: string = ACCOUNT_AUDIT_NAMESPACE
): string {
  const hash = createHash("sha1")
    .update(Buffer.from(namespace.replace(/-/g, ""), "hex"))
    .update(accountId, "utf8")
    .digest()
  hash[6] = (hash[6] & 0x0f) | 0x50
  hash[8] = (hash[8] & 0x3f) | 0x80
  const hex = hash.subarray(0, 16).toString("hex")
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20, 32)}`
}

// ─── Token-Abfang ───────────────────────────────────────────────────────────
//
// Better Auth gibt das Reset-Token nur an `emailAndPassword.sendResetPassword`
// heraus — vorgesehen fuer den Mailversand. PAOLO hat keinen E-Mail-Dienst; der
// Link soll stattdessen einmalig im Dashboard erscheinen.
//
// Deshalb nimmt der Callback das Token ausschliesslich entgegen, WENN der
// aktuelle Aufruf in `captureResetToken` steht. Jeder andere Aufruf — etwa eine
// Anfrage ueber die oeffentliche HTTP-Route — erreicht `recordResetToken` ohne
// Bereich und verwirft das Token. Es gibt keinen Modulzustand, der ein Token
// ueber Aufrufe hinweg haelt; der Bereich lebt genau so lange wie der Aufruf.
//
// Das Token wird nie protokolliert und nie in eine Fehlermeldung aufgenommen.

type Capture = { token?: string }
const storage = new AsyncLocalStorage<Capture>()

/** Fuehrt `run` aus und liefert dessen Ergebnis zusammen mit dem abgefangenen Token. */
export async function captureResetToken<T>(
  run: () => Promise<T>
): Promise<{ result: T; token: string | undefined }> {
  const capture: Capture = {}
  const result = await storage.run(capture, run)
  return { result, token: capture.token }
}

/** Vom Callback `sendResetPassword` aufgerufen. Ohne umgebenden Bereich wirkungslos. */
export function recordResetToken(token: string): void {
  const capture = storage.getStore()
  if (capture) capture.token = token
}
