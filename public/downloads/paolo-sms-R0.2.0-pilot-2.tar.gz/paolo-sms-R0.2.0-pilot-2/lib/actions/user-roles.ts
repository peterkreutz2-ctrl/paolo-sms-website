"use server"

import { appAuth, usesBetterAuth, usesFileAuth } from "@/lib/auth"
import { createDirectoryAccessLink, createDirectoryUser, FILE_USER_MANAGEMENT_MESSAGE, deleteClerkAccount, findLiveAccountIds, getDirectoryUser, listDirectoryUsers, updateClerkAccountName } from "@/lib/auth/user-directory"
import { and, eq, isNull } from "drizzle-orm"
import { revalidatePath } from "next/cache"
import { headers } from "next/headers"

import { accountAuditResourceId } from "@/lib/auth/access-link"
import {
  changedAccountFields,
  decideAccountDeletion,
  DELETION_REFUSAL_MESSAGES,
  normalizeTargetRoles,
  runProviderFirstDeletion,
  validateAccountData,
} from "@/lib/auth/account-lifecycle"
import {
  AccountChangeRefused,
  deleteBetterAuthAccount,
  deleteRoleAssignments,
  isUniqueViolation,
  readAccountRoleKeys,
  updateBetterAuthAccount,
} from "@/lib/auth/account-lifecycle-db"
import { ADMIN_CHANGE_REFUSAL_MESSAGES } from "@/lib/auth/admin-invariant"
import {
  AdminChangeRefused,
  guardAdminRoleChange,
  readGlobalAdminIds,
} from "@/lib/auth/admin-role-lock"
import { logAuditEvent } from "@/lib/audit"
import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import {
  canAssignRole,
  canManageAccountAccess,
  canManageRoles,
  canManageTargetUser,
  canRemoveRole,
  isAppRoleKey,
} from "@/lib/constants/roles"
import { db } from "@/lib/db"
import { organizations, roles, userRoles } from "@/lib/db/schema"
import { demoBlockedResult, isDemoMode } from "@/lib/demo/mode"

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

async function currentRequestOrigin(): Promise<string | null> {
  return (await headers()).get("origin")
}

async function loadTargetCurrentRoles(clerkUserId: string) {
  const rows = await db
    .select({ roleKey: roles.key })
    .from(userRoles)
    .innerJoin(roles, eq(userRoles.roleId, roles.id))
    .where(and(eq(userRoles.clerkUserId, clerkUserId), isNull(userRoles.organizationId)))
  return rows.map((r) => r.roleKey).filter(isAppRoleKey)
}

// Schnappschuss der Administratorkonten, die im Verzeichnis existieren — VOR
// der Transaktion, weil es ein Netzwerkaufruf ist. `null`: Verzeichnis nicht
// erreichbar. Die eigentliche Pruefung (Sperre, frisches Lesen) macht
// guardAdminRoleChange in der Transaktion; siehe lib/auth/admin-role-lock.ts.
async function snapshotLiveAdminIds(): Promise<Set<string> | null> {
  return findLiveAccountIds(await readGlobalAdminIds(db))
}

function adminRefusalResult(error: unknown): UserRoleActionState | null {
  if (!(error instanceof AdminChangeRefused)) return null
  return { success: false, message: ADMIN_CHANGE_REFUSAL_MESSAGES[error.reason] }
}

export type UserRoleActionState = {
  success: boolean
  message: string
  // Zugangsschluessel — nur in der Antwort, nie gespeichert, geloggt oder auditiert.
  signInUrl?: string
  // „sign-in“: Clerk-Anmeldelink. „password“: Better-Auth-Link zum Festlegen eines Passworts.
  linkKind?: "sign-in" | "password"
}

export async function assignRole(
  _: UserRoleActionState,
  formData: FormData
): Promise<UserRoleActionState> {
  if (isDemoMode()) return demoBlockedResult("accounts")
  if (usesFileAuth()) return { success: false, message: FILE_USER_MANAGEMENT_MESSAGE }
  const { userId } = await appAuth()
  if (!userId) {
    return { success: false, message: "Nicht angemeldet." }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!canManageRoles(roleKeys)) {
    return { success: false, message: "Keine Berechtigung." }
  }

  const clerkUserId = formData.get("clerkUserId")
  const roleKey = formData.get("roleKey")

  if (typeof clerkUserId !== "string" || !clerkUserId.trim()) {
    return { success: false, message: "Ungültige Konto-Kennung." }
  }

  if (typeof roleKey !== "string" || !isAppRoleKey(roleKey)) {
    return { success: false, message: "Ungültige Rolle." }
  }

  const targetId = clerkUserId.trim()

  // Load target's current roles — needed for permission checks and audit trail
  const targetRoleKeys = await loadTargetCurrentRoles(targetId)

  // Check: can actor manage this target user?
  if (!canManageTargetUser(roleKeys, targetRoleKeys)) {
    return { success: false, message: "Keine Berechtigung, diesen Benutzer zu verwalten." }
  }

  if (targetRoleKeys.length === 1 && targetRoleKeys[0] === roleKey) {
    return { success: false, message: "Die ausgewählte Rolle ist bereits zugewiesen. Es wurde nichts geändert." }
  }

  // Check: can actor remove the target's current role(s)?
  for (const currentRole of targetRoleKeys) {
    if (!canRemoveRole(roleKeys, currentRole)) {
      return { success: false, message: "Keine Berechtigung, die aktuelle Rolle dieses Benutzers zu entfernen." }
    }
  }

  // Check: can actor assign the new role?
  if (!canAssignRole(roleKeys, roleKey)) {
    return { success: false, message: "Keine Berechtigung, diese Rolle zu vergeben." }
  }

  const live = await findLiveAccountIds([targetId])
  if (live === null) {
    return { success: false, message: "Das Konto kann gerade nicht geprüft werden. Bitte später erneut versuchen." }
  }
  if (!live.has(targetId)) {
    return { success: false, message: "Das Konto fehlt beim Anmeldedienst. Bitte die Rolle bereinigen." }
  }

  const [role] = await db
    .select({ id: roles.id })
    .from(roles)
    .where(eq(roles.key, roleKey))
    .limit(1)

  if (!role) {
    return { success: false, message: "Rolle nicht in der Datenbank gefunden." }
  }

  const [organization] = await db
    .select({ id: organizations.id })
    .from(organizations)
    .limit(1)

  const previousRoleKey = targetRoleKeys[0] ?? null

  // Letzter-Administrator-Schutz: Der Schnappschuss der lebenden Konten wird
  // nur gebraucht, wenn die Administratorrolle wegfaellt. Die Pruefung selbst
  // laeuft in der Transaktion unter Sperre, auf frisch gelesenem Stand — und
  // zwar immer, damit auch eine zwischenzeitlich erteilte Administratorrolle
  // nicht an der Pruefung vorbei entzogen werden kann.
  const liveAdminIds =
    targetRoleKeys.includes("admin") && roleKey !== "admin"
      ? await snapshotLiveAdminIds()
      : new Set<string>()

  // Ein Rollenwechsel ist Loeschen PLUS Einfuegen (genau eine globale Rolle je
  // Benutzer). Beides zusammen mit dem Audit-Eintrag in EINER Transaktion:
  // Ohne die Klammer machte ein fehlgeschlagenes Insert aus dem Wechsel einen
  // ersatzlosen Entzug — der Benutzer stand danach ohne Rolle da, waehrend die
  // Meldung nur von einem Fehler sprach.
  try {
    await db.transaction(async (tx) => {
      await guardAdminRoleChange(tx, {
        targetId,
        targetStaysAdmin: roleKey === "admin",
        liveAccountIds: liveAdminIds,
      })

      await tx
        .delete(userRoles)
        .where(
          and(
            eq(userRoles.clerkUserId, targetId),
            isNull(userRoles.organizationId)
          )
        )

      const [newRow] = await tx
        .insert(userRoles)
        .values({ clerkUserId: targetId, roleId: role.id })
        .returning({ id: userRoles.id })

      if (!newRow) throw new Error("role-insert-failed")

      if (organization) {
        await logAuditEvent(
          {
            organizationId: organization.id,
            clerkUserId: userId,
            action: "ROLE_ASSIGNED",
            resourceType: "user_role",
            resourceId: newRow.id,
            changes: {
              targetClerkUserId: targetId,
              previousRoleKey,
              newRoleKey: roleKey,
            },
          },
          tx
        )
      }
    })
  } catch (error) {
    const refusal = adminRefusalResult(error)
    if (refusal) return refusal
    console.error("[user-roles] Rollenzuweisung fehlgeschlagen:", error)
    return {
      success: false,
      message:
        "Fehler beim Zuweisen der Rolle. Die bisherige Rolle bleibt unverändert bestehen.",
    }
  }

  revalidatePath("/dashboard/users")
  return { success: true, message: "Rolle erfolgreich zugewiesen." }
}

// Entfernt ausschliesslich eine verwaiste Rolle nach Pruefung beim Anmeldedienst.
export async function removeOrphanedRole(
  _: UserRoleActionState,
  formData: FormData
): Promise<UserRoleActionState> {
  if (isDemoMode()) return demoBlockedResult("accounts")
  if (usesFileAuth()) return { success: false, message: FILE_USER_MANAGEMENT_MESSAGE }
  const { userId } = await appAuth()
  if (!userId) return { success: false, message: "Nicht angemeldet." }

  const roleKeys = await getCurrentUserRoles()
  if (!canManageRoles(roleKeys)) return { success: false, message: "Keine Berechtigung." }

  const userRoleId = formData.get("userRoleId")
  if (typeof userRoleId !== "string" || !userRoleId.trim()) {
    return { success: false, message: "Ungültige Rollen-ID." }
  }

  const [row] = await db
    .select({
      id: userRoles.id,
      clerkUserId: userRoles.clerkUserId,
      roleKey: roles.key,
    })
    .from(userRoles)
    .innerJoin(roles, eq(userRoles.roleId, roles.id))
    .where(and(eq(userRoles.id, userRoleId.trim()), isNull(userRoles.organizationId)))
    .limit(1)

  if (!row) return { success: false, message: "Zuweisung nicht gefunden." }

  // Ein unbekannter Rollenwert wird wie die am staerksten geschuetzte Rolle
  // behandelt (siehe app/dashboard/users/page.tsx).
  if (isAppRoleKey(row.roleKey)) {
    if (!canManageTargetUser(roleKeys, [row.roleKey])) {
      return { success: false, message: "Keine Berechtigung, diesen Eintrag zu verwalten." }
    }
    if (!canRemoveRole(roleKeys, row.roleKey)) {
      return { success: false, message: "Keine Berechtigung, diese Rolle zu entfernen." }
    }
  } else if (!canManageTargetUser(roleKeys, ["admin"])) {
    return { success: false, message: "Keine Berechtigung, diesen Eintrag zu verwalten." }
  }

  const live = await findLiveAccountIds([row.clerkUserId])
  if (live === null) {
    return {
      success: false,
      message:
        "Die Kontenliste des Anmeldedienstes ist gerade nicht erreichbar. Ob das Konto noch existiert, lässt sich deshalb nicht prüfen — bitte später erneut versuchen.",
    }
  }
  if (live.has(row.clerkUserId)) {
    return {
      success: false,
      message:
        "Das Konto existiert noch. Eine Rolle lässt sich nur bereinigen, wenn das Konto fehlt — bitte die Rolle stattdessen ändern.",
    }
  }

  const [organization] = await db
    .select({ id: organizations.id })
    .from(organizations)
    .limit(1)

  try {
    await db.transaction(async (tx) => {
      await tx.delete(userRoles).where(eq(userRoles.id, row.id))

      if (organization) {
        await logAuditEvent(
          {
            organizationId: organization.id,
            clerkUserId: userId,
            action: "ROLE_REMOVED",
            resourceType: "user_role",
            resourceId: row.id,
            changes: {
              targetClerkUserId: row.clerkUserId,
              removedRoleKey: row.roleKey,
              orphaned: true,
            },
          },
          tx
        )
      }
    })
  } catch (error) {
    console.error("[user-roles] Bereinigung einer verwaisten Rolle fehlgeschlagen:", error)
    return {
      success: false,
      message:
        "Die verwaiste Rolle konnte nicht bereinigt werden. Es wurde nichts geändert — bitte erneut versuchen.",
    }
  }

  revalidatePath("/dashboard/users")
  return { success: true, message: "Verwaiste Rolle wurde bereinigt." }
}

export async function createUserWithRole(
  _: UserRoleActionState,
  formData: FormData
): Promise<UserRoleActionState> {
  if (isDemoMode()) return demoBlockedResult("accounts")
  if (usesFileAuth()) return { success: false, message: FILE_USER_MANAGEMENT_MESSAGE }
  const { userId } = await appAuth()
  if (!userId) return { success: false, message: "Nicht angemeldet." }

  const roleKeys = await getCurrentUserRoles()
  if (!canManageAccountAccess(roleKeys, [], false)) return { success: false, message: "Keine Berechtigung." }

  const email = (formData.get("email") as string | null)?.trim().toLowerCase() ?? ""
  const name = (formData.get("name") as string | null)?.trim() ?? ""
  const roleKey = formData.get("roleKey")

  if (!email || !EMAIL_RE.test(email)) {
    return { success: false, message: "Ungültige E-Mail-Adresse." }
  }

  if (usesBetterAuth() && !name) {
    return { success: false, message: "Name ist erforderlich." }
  }

  if (typeof roleKey !== "string" || !isAppRoleKey(roleKey)) {
    return { success: false, message: "Ungültige Rolle." }
  }

  if (!canAssignRole(roleKeys, roleKey)) {
    return { success: false, message: "Keine Berechtigung, diese Rolle zu vergeben." }
  }

  const [role] = await db
    .select({ id: roles.id })
    .from(roles)
    .where(eq(roles.key, roleKey))
    .limit(1)

  if (!role) return { success: false, message: "Rolle nicht in der Datenbank gefunden." }

  let clerkUserId: string
  try {
    const existing = await listDirectoryUsers({ email, limit: 1 })
    if (existing.length > 0) {
      return { success: false, message: "Für diese E-Mail-Adresse besteht bereits ein Konto. Rolle und Kontodaten können in der vorhandenen Zeile geändert werden, wenn Ihre Berechtigungen dies zulassen. Andernfalls wenden Sie sich an einen Administrator." }
    }
    const created = await createDirectoryUser({ email, name })
    clerkUserId = created.id
  } catch {
    // Providerfehler koennen sensible Eingaben enthalten.
    return { success: false, message: "Konto konnte nicht angelegt werden. Möglicherweise besteht diese E-Mail-Adresse bereits. Bitte die Kontenliste prüfen." }
  }

  try {
    const [organization] = await db
      .select({ id: organizations.id })
      .from(organizations)
      .limit(1)

    // Kontoanlage und Rollenzuweisung sind getrennte Schritte. Bei einem
    // Fehler bleibt das neue Konto ohne Rolle sichtbar; es wird nicht neu angelegt.
    await db.transaction(async (tx) => {
      const [newRow] = await tx
        .insert(userRoles)
        .values({ clerkUserId, roleId: role.id })
        .returning({ id: userRoles.id })

      if (!newRow) throw new Error("role-insert-failed")

      if (organization) {
        await logAuditEvent(
          {
            organizationId: organization.id,
            clerkUserId: userId,
            action: "ROLE_ASSIGNED",
            resourceType: "user_role",
            resourceId: newRow.id,
            changes: {
              targetClerkUserId: clerkUserId,
              previousRoleKey: null,
              newRoleKey: roleKey,
              createdUser: true,
            },
          },
          tx
        )
      }
    })
  } catch {
    revalidatePath("/dashboard/users")
    return { success: false, message: "Konto angelegt, Rollenzuweisung fehlgeschlagen. Bitte in der vorhandenen Zeile eine Rolle zuweisen und anschließend „Anmeldelink erneuern“ verwenden." }
  }

  let link: UserRoleActionState
  try {
    // Die Anlageberechtigung samt Zielrolle wurde bereits oben geprueft.
    // Ein neu ernannter Safety Manager ist danach nicht mehr durch einen
    // anderen Safety Manager verwaltbar, braucht aber seinen Erstzugangslink.
    link = await createAuditedAccessLink(clerkUserId, userId)
  } catch {
    link = { success: false, message: "" }
  }
  revalidatePath("/dashboard/users")
  if (!link.success) {
    return { success: false, message: "Konto und Rolle wurden angelegt, aber der Anmeldelink konnte nicht bereitgestellt werden. Bitte in der vorhandenen Zeile „Anmeldelink erneuern“ verwenden; falls das Konto nicht sichtbar ist, einen Administrator hinzuziehen." }
  }
  return { ...link, message: "Konto und Rolle wurden angelegt. Den Link jetzt sicher an die Person weitergeben." }
}

// Anmeldelink erneuern (#111): Clerk ein neuer Sign-in-Link, Better Auth ein
// Link zum Festlegen eines neuen Passworts. Beide sieben Tage gueltig.
//
// Berechtigung: Faehigkeit `accounts.access` (Administrator, Safety Manager) UND
// Zustaendigkeitsbereich der Rollenverwaltung (`canManageTargetUser`), nie am
// eigenen Konto. Der Safety Assistant hat diese Aktion nicht.
//
// Der Link ist ein Zugangsschluessel. Er steht ausschliesslich in der Antwort
// dieser Aktion. Weder er noch das darin enthaltene Token werden geloggt oder in
// den Audit-Eintrag geschrieben; auditiert wird nur DASS und FUER WEN ein Link
// ausgestellt wurde. Scheitert der Audit-Eintrag, wird der Link nicht
// ausgeliefert — ein Link ohne Spur gibt es nicht.
export async function issueAccessLink(
  _: UserRoleActionState,
  formData: FormData
): Promise<UserRoleActionState> {
  if (isDemoMode()) return demoBlockedResult("accounts")
  if (usesFileAuth()) return { success: false, message: FILE_USER_MANAGEMENT_MESSAGE }
  const { userId } = await appAuth()
  if (!userId) return { success: false, message: "Nicht angemeldet." }

  const roleKeys = await getCurrentUserRoles()
  if (!canManageRoles(roleKeys)) return { success: false, message: "Keine Berechtigung." }

  const clerkUserId = formData.get("clerkUserId")
  if (typeof clerkUserId !== "string" || !clerkUserId.trim()) {
    return { success: false, message: "Ungültige Konto-Kennung." }
  }
  const targetId = clerkUserId.trim()

  // Ein unbekannter Rollenwert in der Datenbank gilt als die am staerksten
  // geschuetzte Rolle (siehe app/dashboard/users/page.tsx).
  const targetRows = await db
    .select({ roleKey: roles.key })
    .from(userRoles)
    .innerJoin(roles, eq(userRoles.roleId, roles.id))
    .where(and(eq(userRoles.clerkUserId, targetId), isNull(userRoles.organizationId)))
  const targetRoleKeys = targetRows.map((row) =>
    isAppRoleKey(row.roleKey) ? row.roleKey : ("admin" as const)
  )

  if (!canManageAccountAccess(roleKeys, targetRoleKeys, targetId === userId)) {
    return { success: false, message: "Keine Berechtigung, für dieses Konto einen Link zu erstellen." }
  }

  const live = await findLiveAccountIds([targetId])
  if (live === null) {
    return {
      success: false,
      message:
        "Die Kontenliste des Anmeldedienstes ist gerade nicht erreichbar. Der Link kann deshalb jetzt nicht erstellt werden — bitte später erneut versuchen.",
    }
  }
  if (!live.has(targetId)) {
    return { success: false, message: "Für diese Rolle gibt es kein Konto mehr. Bitte die Rolle bereinigen." }
  }

  return createAuditedAccessLink(targetId, userId)
}

// Nur intern: Aufrufer pruefen Anlage- bzw. Erneuerungsberechtigung zuvor.
async function createAuditedAccessLink(targetId: string, userId: string): Promise<UserRoleActionState> {
  let link: Awaited<ReturnType<typeof createDirectoryAccessLink>>
  try {
    link = await createDirectoryAccessLink(targetId, await currentRequestOrigin())
  } catch {
    // Keine Providerfehler ausgeben: Sie koennen Links oder Tokens enthalten.
    console.error("[user-roles] Link konnte nicht erstellt werden.")
    return {
      success: false,
      message:
        "Der Link konnte nicht erstellt werden. Bitte prüfen, ob der Anmeldedienst erreichbar ist und – bei Clerk – Sign-in-Tokens im Clerk Dashboard aktiviert sind.",
    }
  }

  const [organization] = await db
    .select({ id: organizations.id })
    .from(organizations)
    .limit(1)

  if (organization) {
    try {
      // Mit tx: Ein Fehler wird geworfen statt verschluckt (siehe logAuditEvent).
      await db.transaction(async (tx) => {
        await logAuditEvent(
          {
            organizationId: organization.id,
            clerkUserId: userId,
            action: "ACCESS_LINK_ISSUED",
            resourceType: "user_account",
            // audit_logs.resource_id ist eine UUID; Clerk-Kennungen sind keine.
            resourceId: accountAuditResourceId(targetId),
            changes: { targetClerkUserId: targetId, linkKind: link.kind },
          },
          tx
        )
      })
    } catch {
      console.error("[user-roles] Audit-Eintrag zur Linkausstellung fehlgeschlagen.")
      return {
        success: false,
        message: "Der Audit-Eintrag konnte nicht geschrieben werden, deshalb wird der Link nicht angezeigt. Bitte erneut versuchen.",
      }
    }
  }

  return {
    success: true,
    message: link.kind === "password" ? "Link zum Festlegen eines Passworts erstellt." : "Anmeldelink erstellt.",
    signInUrl: link.url,
    linkKind: link.kind,
  }
}

// ─── Kontodaten ändern und Konto löschen (#114) ─────────────────────────────
//
// Gemeinsame Vorarbeit beider Aktionen: Ziel lesen, Zuständigkeit prüfen, das
// Konto im Verzeichnis finden. Die Rechte sind die der Zugangsaktionen
// (`accounts.access` UND Zuständigkeitsbereich der Rollenverwaltung, nie das
// eigene Konto). Der Safety Assistant erhält die Aktionen nicht.
type ManagedAccount = {
  targetId: string
  targetRoleKeys: ReturnType<typeof normalizeTargetRoles>
  account: NonNullable<Awaited<ReturnType<typeof getDirectoryUser>>>
}

async function resolveManagedAccount(
  formData: FormData,
  actorRoles: Parameters<typeof canManageAccountAccess>[0],
  actorId: string
): Promise<ManagedAccount | { error: UserRoleActionState }> {
  const raw = formData.get("clerkUserId")
  if (typeof raw !== "string" || !raw.trim()) {
    return { error: { success: false, message: "Ungültige Konto-Kennung." } }
  }
  const targetId = raw.trim()
  if (targetId === actorId) {
    return { error: { success: false, message: DELETION_REFUSAL_MESSAGES.self } }
  }

  const targetRoleKeys = normalizeTargetRoles(await readAccountRoleKeys(db, targetId))
  if (!canManageAccountAccess(actorRoles, targetRoleKeys, false)) {
    return { error: { success: false, message: "Keine Berechtigung, dieses Konto zu verwalten." } }
  }

  let account: ManagedAccount["account"] | null
  try {
    account = await getDirectoryUser(targetId)
  } catch {
    return {
      error: {
        success: false,
        message:
          "Die Kontenliste des Anmeldedienstes ist gerade nicht erreichbar. Bitte später erneut versuchen.",
      },
    }
  }
  if (!account) {
    return {
      error: {
        success: false,
        message: "Für diese Rolle gibt es kein Konto mehr. Bitte die Rolle bereinigen.",
      },
    }
  }
  return { targetId, targetRoleKeys, account }
}

// Name (Clerk und Better Auth) und E-Mail-Adresse (nur Better Auth) ändern. Bei
// Clerk bleibt die E-Mail-Änderung dem Benutzerprofil des Anbieters vorbehalten;
// die Aktion lehnt sie ab. Das eigene Konto ist ausgenommen (ein Tippfehler in der
// eigenen E-Mail-Adresse würde bei Better Auth die Anmeldung kosten).
//
// Audit: nur welche Felder sich geändert haben, nie Namen oder Adressen.
export async function updateAccountData(
  _: UserRoleActionState,
  formData: FormData
): Promise<UserRoleActionState> {
  if (isDemoMode()) return demoBlockedResult("accounts")
  if (usesFileAuth()) return { success: false, message: FILE_USER_MANAGEMENT_MESSAGE }
  const { userId } = await appAuth()
  if (!userId) return { success: false, message: "Nicht angemeldet." }

  const roleKeys = await getCurrentUserRoles()
  if (!canManageRoles(roleKeys)) return { success: false, message: "Keine Berechtigung." }

  const target = await resolveManagedAccount(formData, roleKeys, userId)
  if ("error" in target) return target.error
  const { targetId, account } = target

  const emailEditable = usesBetterAuth()
  const input = validateAccountData(
    { name: formData.get("name"), email: formData.get("email") },
    { emailEditable }
  )
  if (!input.ok) return { success: false, message: input.message }

  if (!emailEditable) {
    const submitted = String(formData.get("email") ?? "").trim().toLowerCase()
    if (submitted && submitted !== account.email.trim().toLowerCase()) {
      return {
        success: false,
        message: "E-Mail-Adressen werden bei Clerk im Benutzerprofil der Person geändert.",
      }
    }
  }

  const changedFields = changedAccountFields({
    currentName: account.displayName,
    currentEmail: account.email,
    name: input.name,
    email: input.email,
  })
  if (changedFields.length === 0) return { success: false, message: "Es gibt keine Änderung." }

  const [organization] = await db
    .select({ id: organizations.id })
    .from(organizations)
    .limit(1)

  const writeAudit = (tx: Parameters<typeof logAuditEvent>[1]) =>
    organization
      ? logAuditEvent(
          {
            organizationId: organization.id,
            clerkUserId: userId,
            action: "ACCOUNT_DATA_UPDATED",
            resourceType: "user_account",
            resourceId: accountAuditResourceId(targetId),
            changes: { targetClerkUserId: targetId, changedFields },
          },
          tx
        )
      : Promise.resolve()

  if (usesBetterAuth()) {
    try {
      await db.transaction(async (tx) => {
        await updateBetterAuthAccount(tx, targetId, {
          ...(changedFields.includes("name") ? { name: input.name } : {}),
          ...(changedFields.includes("email") && input.email ? { email: input.email } : {}),
        })
        await writeAudit(tx)
      })
    } catch (error) {
      if (isUniqueViolation(error)) {
        return { success: false, message: "Diese E-Mail-Adresse wird bereits verwendet." }
      }
      console.error("[user-roles] Kontodaten ändern fehlgeschlagen:", error instanceof Error ? error.message : "unbekannter Fehler")
      return { success: false, message: "Die Kontodaten konnten nicht geändert werden. Es wurde nichts geändert — bitte erneut versuchen." }
    }
  } else {
    try {
      await updateClerkAccountName(targetId, input.name)
    } catch (error) {
      console.error("[user-roles] Name bei Clerk ändern fehlgeschlagen:", error instanceof Error ? error.message : "unbekannter Fehler")
      return { success: false, message: "Der Name konnte beim Anmeldedienst nicht geändert werden. Es wurde nichts geändert — bitte erneut versuchen." }
    }
    try {
      await db.transaction(async (tx) => {
        await writeAudit(tx)
      })
    } catch (error) {
      console.error("[user-roles] Audit-Eintrag zur Namensänderung fehlgeschlagen:", error instanceof Error ? error.message : "unbekannter Fehler")
      return { success: false, message: "Der Name wurde geändert, der Audit-Eintrag konnte aber nicht geschrieben werden." }
    }
  }

  revalidatePath("/dashboard/users")
  return { success: true, message: "Kontodaten geändert." }
}

// Konto endgültig löschen — ohne vorherige Sperrung. Entfernt das Konto beim
// Anmeldedienst, seine Sitzungen und seine Rollenzuweisungen. Meldungen, Notizen,
// Besprechungen, SMS-Dokumente und Audit-Einträge bleiben unverändert; die Kennung
// darin wird weder ersetzt noch anonymisiert. DSGVO-Löschanträge laufen weiter über
// die bestehenden Datenschutzprozesse.
//
// Nie das eigene Konto, nie ein Konto mit Administratorrolle (die Rolle wird vorher
// regulär geändert, mit dem Letzter-Administrator-Schutz aus #109). Bestätigung:
// die vollständige E-Mail-Adresse des Kontos, serverseitig geprüft.
//
// Better Auth: Rollen, Konto (Sitzungen und Passwort per Kaskade) und Audit in einer
// Transaktion. Clerk: Rolle unmittelbar vor dem Anbieteraufruf erneut prüfen, dann
// Anbieter, dann Rollen und Audit (siehe runProviderFirstDeletion).
export async function deleteAccount(
  _: UserRoleActionState,
  formData: FormData
): Promise<UserRoleActionState> {
  if (isDemoMode()) return demoBlockedResult("accounts")
  if (usesFileAuth()) return { success: false, message: FILE_USER_MANAGEMENT_MESSAGE }
  const { userId } = await appAuth()
  if (!userId) return { success: false, message: "Nicht angemeldet." }

  const roleKeys = await getCurrentUserRoles()
  if (!canManageRoles(roleKeys)) return { success: false, message: "Keine Berechtigung." }

  const target = await resolveManagedAccount(formData, roleKeys, userId)
  if ("error" in target) return target.error
  const { targetId, targetRoleKeys, account } = target

  const decision = decideAccountDeletion({
    actorRoles: roleKeys,
    actorId: userId,
    targetId,
    targetRoles: targetRoleKeys,
    accountEmail: account.email,
    typedEmail: String(formData.get("confirmEmail") ?? ""),
  })
  if (!decision.ok) {
    return { success: false, message: DELETION_REFUSAL_MESSAGES[decision.reason] }
  }

  const [organization] = await db
    .select({ id: organizations.id })
    .from(organizations)
    .limit(1)

  const writeAudit = (tx: Parameters<typeof logAuditEvent>[1], previousRoleKey: string | null) =>
    organization
      ? logAuditEvent(
          {
            organizationId: organization.id,
            clerkUserId: userId,
            action: "ACCOUNT_DELETED",
            resourceType: "user_account",
            resourceId: accountAuditResourceId(targetId),
            // Weder Name noch E-Mail-Adresse: Die Kennung bleibt als Pseudonym.
            changes: { targetClerkUserId: targetId, previousRoleKey },
          },
          tx
        )
      : Promise.resolve()

  if (usesBetterAuth()) {
    try {
      await db.transaction(async (tx) => {
        const { previousRoleKeys } = await deleteBetterAuthAccount(tx, targetId)
        await writeAudit(tx, previousRoleKeys[0] ?? null)
      })
    } catch (error) {
      if (error instanceof AccountChangeRefused) {
        return {
          success: false,
          message:
            error.reason === "admin-role"
              ? DELETION_REFUSAL_MESSAGES["admin-role"]
              : "Für diese Rolle gibt es kein Konto mehr. Bitte die Rolle bereinigen.",
        }
      }
      console.error("[user-roles] Konto löschen fehlgeschlagen:", error instanceof Error ? error.message : "unbekannter Fehler")
      return { success: false, message: "Das Konto konnte nicht gelöscht werden. Es wurde nichts geändert — bitte erneut versuchen." }
    }
    revalidatePath("/dashboard/users")
    return { success: true, message: "Konto gelöscht." }
  }

  const outcome = await runProviderFirstDeletion({
    recheckNotAdmin: async () =>
      normalizeTargetRoles(await readAccountRoleKeys(db, targetId)).includes("admin")
        ? "admin"
        : "not-admin",
    deleteAtProvider: () => deleteClerkAccount(targetId),
    cleanupInDatabase: async () => {
      try {
        await db.transaction(async (tx) => {
          const previousRoleKeys = await deleteRoleAssignments(tx, targetId)
          await writeAudit(tx, previousRoleKeys[0] ?? null)
        })
      } catch (error) {
        console.error(
          "[user-roles] Konto beim Anmeldedienst gelöscht, Bereinigung in PAOLO fehlgeschlagen:",
          error instanceof Error ? error.message : "unbekannter Fehler"
        )
        throw error
      }
    },
  })
  revalidatePath("/dashboard/users")
  return { success: outcome.success, message: outcome.message }
}
