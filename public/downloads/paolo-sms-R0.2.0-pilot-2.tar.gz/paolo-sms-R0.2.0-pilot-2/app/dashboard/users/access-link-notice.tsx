import type { UserRoleActionState } from "@/lib/actions/user-roles"

type Props = {
  url: string
  kind: NonNullable<UserRoleActionState["linkKind"]>
}

// Der Link erscheint genau hier, in der Antwort der Aktion — er wird nirgends
// gespeichert, geloggt oder auditiert (#111). Wer die Seite verlaesst, muss einen
// neuen Link erzeugen.
export function AccessLinkNotice({ url, kind }: Props) {
  const isPassword = kind === "password"

  return (
    <div className="space-y-2 rounded-md border border-amber-200 bg-amber-50 p-4 text-sm dark:border-amber-800 dark:bg-amber-950">
      <p className="font-medium text-amber-800 dark:text-amber-200">
        {isPassword
          ? "Link zum Festlegen eines Passworts (gültig 7 Tage, einmal verwendbar)"
          : "Einmaliger Anmeldelink (gültig 7 Tage)"}
      </p>
      <input
        readOnly
        value={url}
        aria-label={isPassword ? "Link zum Festlegen eines Passworts" : "Anmeldelink"}
        onClick={(e) => (e.target as HTMLInputElement).select()}
        className="w-full rounded border bg-background px-2 py-1 font-mono text-xs"
      />
      {isPassword ? (
        <p className="text-amber-700 dark:text-amber-300">
          Diesen Link über einen sicheren Übertragungsweg an die Person weitergeben.
          Der Link kann nur einmal angezeigt werden. Er erlaubt den Zugriff auf das Konto.
          Ältere Links für dieses Konto bleiben bis zu ihrem Ablauf gültig.
        </p>
      ) : (
        <div className="space-y-2 text-amber-700 dark:text-amber-300">
          <p>
            Diesen Link ausschließlich über einen gesicherten Übermittlungsweg
            an die betreffende Person weitergeben. Er erlaubt den direkten
            Zugriff auf das Konto und wird hier nicht erneut angezeigt. Ältere
            Links bleiben bis zu ihrem Ablauf gültig.
          </p>
          <p>
            Die Person muss für spätere Anmeldungen Google SSO mit dem
            Google-Konto verwenden, das zur eingeladenen E-Mail-Adresse gehört,
            oder noch während der ersten Sitzung in der eingebetteten
            Clerk-Kontoverwaltung ein Passwort festlegen. Die Person darf sich
            erst danach abmelden.
          </p>
        </div>
      )}
    </div>
  )
}
