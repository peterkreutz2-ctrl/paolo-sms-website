import { appAuth, usesBetterAuth, usesFileAuth } from "@/lib/auth"
import { listAllDirectoryUsers } from "@/lib/auth/user-directory"
import { buildUserOverview, type AccountStatus, type OverviewRow } from "@/lib/auth/user-overview"
import { eq, isNull } from "drizzle-orm"
import { notFound, redirect } from "next/navigation"

import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import {
  ROLE_LABELS,
  canDeleteAccount,
  canManageAccountAccess,
  canManageRoles,
  canManageTargetUser,
  getAssignableRoles,
  isAppRoleKey,
  type AppRoleKey,
} from "@/lib/constants/roles"
import { db } from "@/lib/db"
import { roles, userRoles } from "@/lib/db/schema"
import { DEMO_BLOCKED_MESSAGES, isDemoMode } from "@/lib/demo/mode"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"

import { AccessLinkButton } from "./access-link-button"
import { AssignRoleInline } from "./assign-role-inline"
import { CleanupOrphanRoleButton } from "./cleanup-orphan-role-button"
import { DeleteAccountDialog } from "./delete-account-dialog"
import { EditAccountForm } from "./edit-account-form"
import { CreateUserForm } from "./create-user-form"


const STATUS_LABELS: Readonly<Record<AccountStatus, string>> = {
  active: "Aktiv",
  "no-role": "Ohne Rolle",
  missing: "Konto fehlt",
  unverified: "Konto nicht prüfbar",
}

const STATUS_HINTS: Readonly<Record<AccountStatus, string>> = {
  active: "",
  "no-role":
    "Dieses Konto kann sich anmelden, hat aber keinen internen Zugang und sieht nur, was ein anonymer Besucher sieht. Es entsteht, wenn ein Konto außerhalb von PAOLO angelegt wurde oder eine Rollenzuweisung fehlgeschlagen ist.",
  missing:
    "Für diese Rolle gibt es kein Konto mehr beim Anmeldedienst. Die Rolle kann bereinigt werden; ein verwaister Administrator zählt nicht als funktionsfähig.",
  unverified: "",
}

export default async function UsersPage() {
  const { userId } = await appAuth()
  if (!userId) redirect("/sign-in")

  const roleKeys = await getCurrentUserRoles()
  if (!canManageRoles(roleKeys)) notFound()

  // Demo: Die Verwaltung ist gesperrt (lib/demo/mode.ts). Eine Seite mit
  // wirkungslosen Formularen und dem Hinweis auf einen fehlenden
  // Administrator waere irrefuehrend.
  if (isDemoMode()) {
    return (
      <main className="mx-auto max-w-4xl space-y-4 p-8">
        <h1 className="text-2xl font-semibold">Zugangs- und Rollenverwaltung</h1>
        <p className="text-sm text-muted-foreground">
          {DEMO_BLOCKED_MESSAGES.accounts}
        </p>
      </main>
    )
  }

  const assignableRoles = getAssignableRoles(roleKeys)

  // roles.label wird bewusst nicht selektiert: sichtbare Rollennamen kommen
  // ausschliesslich aus ROLE_LABELS (siehe lib/constants/roles.ts).
  const roleRows = await db
    .select({
      id: userRoles.id,
      clerkUserId: userRoles.clerkUserId,
      roleKey: roles.key,
      createdAt: userRoles.createdAt,
    })
    .from(userRoles)
    .innerJoin(roles, eq(userRoles.roleId, roles.id))
    .where(isNull(userRoles.organizationId))
    .orderBy(userRoles.createdAt)

  // Ohne erreichbares oder vollstaendiges Verzeichnis ist weder „Konto fehlt“
  // noch „Alle Konten haben eine Rolle“ belegbar. Die Seite sagt dann, dass die
  // Liste unvollstaendig sein kann, statt falsche Sicherheit zu vermitteln.
  let accounts: Awaited<ReturnType<typeof listAllDirectoryUsers>> | null = null
  try {
    accounts = await listAllDirectoryUsers()
  } catch {
    accounts = null
  }
  const directoryAvailable = accounts !== null

  const allRows = buildUserOverview({ accounts, roleRows })

  // Angezeigt wird nur, wen der Handelnde auch verwalten darf — dieselbe
  // Funktion, die schon die Aktionen steuert (Issue #50, Ue2). Das ist
  // Anzeige, keine Absicherung: Wer die Seite oeffnen darf, entscheidet
  // `canManageRoles`, und jede Aktion prueft serverseitig erneut.
  //
  // Unbekannter Rollenwert aus der Datenbank: wird wie die am staerksten
  // geschuetzte Rolle behandelt — nur wer Administratoren verwalten darf, sieht
  // ihn. „Keine Rolle“ waere die falsche Richtung: `canManageTargetUser`
  // liefert fuer eine leere Rollenliste `true`.
  const visibleRows = allRows.filter((row) => {
    if (row.roleKey === null) return canManageTargetUser(roleKeys, [])
    return isAppRoleKey(row.roleKey)
      ? canManageTargetUser(roleKeys, [row.roleKey])
      : canManageTargetUser(roleKeys, ["admin"])
  })

  const hasFunctioningAdmin = allRows.some(
    (row) => row.roleKey === "admin" && row.status !== "missing"
  )

  return (
    <main className="mx-auto max-w-4xl space-y-8 p-4 sm:p-8">
      <div>
        <h1 className="text-2xl font-semibold">Zugangs- und Rollenverwaltung</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Rollen steuern, welche Bereiche eine angemeldete Person im Dashboard sehen und bearbeiten darf. Die Rollenverwaltung erfolgt in PAOLO SMS — der Anmeldedienst dient ausschließlich der Anmeldung. Rollen nur entsprechend der vorgesehenen Zuständigkeit vergeben.
        </p>
      </div>

      {!directoryAvailable ? (
        <p
          role="alert"
          className="rounded-md border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive"
        >
          Die Kontenliste des Anmeldedienstes ist gerade nicht erreichbar. Die
          Liste zeigt nur Konten mit Rolle und kann unvollständig sein; ob ein
          Konto fehlt oder ohne Rolle ist, lässt sich jetzt nicht feststellen.
        </p>
      ) : !hasFunctioningAdmin ? (
        <p
          role="alert"
          className="rounded-md border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive"
        >
          Es gibt derzeit keinen funktionsfähigen Administrator. Bitte den
          Betreiber der Installation informieren.
        </p>
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle>Angemeldete Personen</CardTitle>
          <CardDescription>
            Jede angemeldete Person hat höchstens eine globale Rolle.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {visibleRows.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              Keine angemeldeten Personen vorhanden.
            </p>
          ) : (
            <ul className="divide-y rounded-lg border">
              {visibleRows.map((row) => (
                <PersonRow
                  key={row.id}
                  row={row}
                  roleKeys={roleKeys}
                  assignableRoles={assignableRoles}
                  currentUserId={userId}
                />
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      {canManageAccountAccess(roleKeys, [], false) ? <Card>
        <CardHeader>
          <CardTitle>Neue angemeldete Person anlegen</CardTitle>
          <CardDescription>
            {usesBetterAuth()
              ? "Better-Auth-Konto mit E-Mail, Name und Rolle anlegen. Die Person legt ihr Passwort über den anschließend angezeigten Link selbst fest."
              : "Clerk-Konto per E-Mail anlegen und eine Rolle zuweisen. Bereits vorhandene E-Mail-Adressen werden abgelehnt."}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <CreateUserForm assignableRoles={assignableRoles} betterAuth={usesBetterAuth()} />
        </CardContent>
      </Card> : null}
    </main>
  )
}

function PersonRow({
  row,
  roleKeys,
  assignableRoles,
  currentUserId,
}: {
  row: OverviewRow
  roleKeys: AppRoleKey[]
  assignableRoles: AppRoleKey[]
  currentUserId: string
}) {
  const currentRole = row.roleKey !== null && isAppRoleKey(row.roleKey) ? row.roleKey : null
  const hint = STATUS_HINTS[row.status]
  // Zugangsaktionen: nur Administrator und Safety Manager, nur im Zustaendigkeits-
  // bereich der Rollenverwaltung, nie am eigenen Konto und nicht fuer ein Konto,
  // das es nicht mehr gibt. Anzeige, keine Absicherung — die Aktion prueft erneut.
  const targetRoles: AppRoleKey[] = row.roleKey === null ? [] : currentRole ? [currentRole] : ["admin"]
  const canIssueLink =
    !usesFileAuth() &&
    row.status !== "missing" &&
    canManageAccountAccess(roleKeys, targetRoles, row.id === currentUserId)

  // Löschen: wie die Zugangsaktionen, zusätzlich nie bei einer Administratorrolle
  // (die Rolle wird vorher regulär geändert) und nur mit bekannter E-Mail-Adresse,
  // weil die Bestätigung sie verlangt. Anzeige, keine Absicherung.
  const canDelete =
    canIssueLink &&
    row.status !== "unverified" &&
    canDeleteAccount(roleKeys, targetRoles, row.id === currentUserId)

  return (
    <li
      data-user-id={row.id}
      data-status={row.status}
      className="space-y-2 px-4 py-3 text-sm"
    >
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0 space-y-0.5 break-words">
          <p className="font-medium">{row.displayName}</p>
          {row.email && row.email !== row.displayName ? (
            <p className="text-xs text-muted-foreground">{row.email}</p>
          ) : null}
          {row.displayName !== row.id ? (
            <p className="font-mono text-xs text-muted-foreground/60">{row.id}</p>
          ) : null}
        </div>
        <div className="flex shrink-0 flex-wrap items-center gap-2">
          {row.roleKey !== null ? (
            <span
              data-testid="role-badge"
              className="rounded-full bg-muted px-2 py-0.5 text-xs"
            >
              Aktuelle Rolle: {currentRole ? ROLE_LABELS[currentRole] : row.roleKey}
            </span>
          ) : null}
          {row.status !== "active" ? <span
            className="rounded-full bg-amber-100 px-2 py-0.5 text-xs text-amber-900 dark:bg-amber-950 dark:text-amber-200"
          >
            {STATUS_LABELS[row.status]}
          </span> : null}
        </div>
      </div>

      {hint ? <p className="text-xs text-muted-foreground">{hint}</p> : null}

      <div className="flex flex-wrap items-center justify-between gap-3">
        {row.status === "missing" && row.userRoleId ? (
          <CleanupOrphanRoleButton userRoleId={row.userRoleId} />
        ) : (
          <AssignRoleInline
            clerkUserId={row.id}
            accountLabel={row.displayName}
            assignableRoles={assignableRoles}
            currentRoleKey={currentRole ?? undefined}
          />
        )}
      </div>

      {canIssueLink ? <AccessLinkButton clerkUserId={row.id} /> : null}

      {canIssueLink || canDelete ? (
        <div className="flex flex-wrap items-start justify-between gap-3">
          {canIssueLink ? (
            <EditAccountForm
              clerkUserId={row.id}
              currentName={row.displayName === row.email || row.displayName === row.id ? "" : row.displayName}
              currentEmail={row.email ?? ""}
              emailEditable={usesBetterAuth()}
            />
          ) : (
            <span />
          )}
          {canDelete && row.email ? (
            <DeleteAccountDialog clerkUserId={row.id} displayName={row.displayName} email={row.email} />
          ) : null}
        </div>
      ) : null}
    </li>
  )
}
