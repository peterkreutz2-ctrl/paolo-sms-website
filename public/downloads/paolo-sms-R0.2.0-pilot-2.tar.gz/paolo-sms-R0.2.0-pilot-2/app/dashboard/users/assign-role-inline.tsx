"use client"

import { useActionState } from "react"

import { assignRole, type UserRoleActionState } from "@/lib/actions/user-roles"
import { type AppRoleKey, ROLE_LABELS } from "@/lib/constants/roles"
import { Button } from "@/components/ui/button"

// Rollenzuweisung direkt an einer Zeile der Kontenliste. Das Konto steht fest
// und kommt als Hidden-Field mit; zu wählen bleibt nur die Rolle. Die Element-
// IDs tragen die Kennung, weil das Formular je Zeile einmal vorkommt.

type Props = {
  clerkUserId: string
  accountLabel: string
  assignableRoles: AppRoleKey[]
  currentRoleKey?: AppRoleKey
}

const initialState: UserRoleActionState = { success: false, message: "" }

export function AssignRoleInline({ clerkUserId, accountLabel, assignableRoles, currentRoleKey }: Props) {
  const [state, formAction, isPending] = useActionState(assignRole, initialState)

  return (
    <form action={formAction} className="flex flex-wrap items-center gap-2">
      <input type="hidden" name="clerkUserId" value={clerkUserId} />

      <label
        htmlFor={`roleKey-${clerkUserId}`}
        className="text-sm font-medium"
      >{`Neue Rolle für ${accountLabel}`}</label>
      <select
        id={`roleKey-${clerkUserId}`}
        name="roleKey"
        required
        defaultValue=""
        className="rounded-md border bg-background px-2 py-1 text-sm"
      >
        <option value="" disabled>Bitte auswählen</option>
        {assignableRoles.filter((key) => key !== currentRoleKey).map((key) => (
          <option key={key} value={key}>
            {ROLE_LABELS[key]}
          </option>
        ))}
      </select>

      <Button type="submit" size="sm" disabled={isPending}>
        {isPending ? "Wird zugewiesen…" : (currentRoleKey ? "Rolle ändern" : "Rolle zuweisen")}
      </Button>

      {state.message ? (
        <p
          className={`text-xs ${state.success ? "text-emerald-600" : "text-destructive"}`}
        >
          {state.message}
        </p>
      ) : null}
    </form>
  )
}
