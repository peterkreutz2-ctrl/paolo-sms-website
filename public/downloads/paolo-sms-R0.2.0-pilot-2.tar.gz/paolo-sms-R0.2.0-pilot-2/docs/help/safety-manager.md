# Safety Manager – Hilfe

*Diese Seite beschreibt die Bedienung. Verbindlich für den Berechtigungsumfang
ist [`../permission-matrix.md`](../permission-matrix.md); die fachliche
Rollenbeschreibung steht in [`../role-responsibilities.md`](../role-responsibilities.md).
Die Bedeutung der hier verwendeten Fachbegriffe steht im [`../glossar.md`](../glossar.md).*

## Rolle und Verantwortung

Der Safety Manager ist für die interne Bearbeitung von Sicherheitsmeldungen verantwortlich. Er sichtet eingehende Meldungen, bewertet sie, leitet Maßnahmen ein und dokumentiert Sicherheitsbesprechungen. Er ist das operative Zentrum des SMS-Prozesses.

## Meldungen sichten und priorisieren

Neue Meldungen erscheinen im Dashboard und in der Meldungsliste (`/dashboard/reports`). Die Liste kann nach Status und Priorität gefiltert werden.

Empfohlene Reihenfolge beim Eingang einer neuen Meldung:

1. Meldung öffnen und vollständig lesen.
2. Priorität setzen: `Niedrig`, `Mittel`, `Hoch` oder `Kritisch`.
3. Status setzen: z. B. `In Prüfung`, wenn die Meldung bearbeitet wird.
4. Bei Bedarf: Notiz oder Nachtrag hinzufügen.
5. Maßnahmen anlegen, falls notwendig.
6. Status abschließen: `Maßnahmen beschlossen` oder `Abgeschlossen`.

## Status und Priorität bearbeiten

Status und Priorität können auf der Meldungs-Detailseite jederzeit geändert werden. Alle Änderungen werden im Audit-Log festgehalten.

Verfügbare Status: `Neu`, `In Prüfung`, `In Bearbeitung`, `Maßnahmen beschlossen`, `Abgeschlossen`, `Ausgeblendet`

**Die Statuswechsel steuern zugleich die öffentliche Statusrückmeldung** (siehe unten). Ein zusätzlicher Freigabeschritt ist dafür nicht nötig und auch nicht vorgesehen.

## Notizen und Nachträge

Auf der Meldungs-Detailseite können interne Notizen und Nachträge hinzugefügt werden. Diese sind nur für angemeldete Personen sichtbar.

## Anhänge prüfen

Dateianhänge zu einer Meldung sind auf der Detailseite sichtbar und können heruntergeladen oder gelöscht werden.

Erlaubt sind JPG, PNG, WEBP, PDF, TXT, IGC, GPX, KML und MP4 – jeweils **bis 4 MB**. Bilder und Videos werden direkt in der Liste angezeigt, alles andere über „Öffnen / Download".

**Videos:** nur MP4, höchstens 60 Sekunden. Empfohlen sind 720p bei 30 Bildern pro Sekunde und möglichst kein Ton. PAOLO wandelt Videos nicht um – größere Aufnahmen müssen vorher gekürzt und komprimiert werden. Passt eine Datei nicht, erscheint die Meldung schon bei der Auswahl; abgeschickt wird sie gar nicht erst. Ob ein Video im Browser abspielt, hängt vom Gerät ab: auf iPhone und iPad funktioniert die Wiedergabe voraussichtlich nicht. Der Download-Link steht deshalb immer daneben.

## Anhänge an SMS-Dokumenten

Unter „Dokumente" können SMS-Dokumente eigene Anhänge tragen – dieselben Dateitypen und dasselbe Limit wie bei Meldungen. Diesen Bereich sehen **nur Administrator und Safety Manager**; Safety Assistants haben dort weder Anhänge noch Freigabe.

Jeder Anhang hat einen von drei Zuständen:

| Status | Bedeutung |
| --- | --- |
| Nur intern | Standard nach dem Hochladen. Nicht öffentlich abrufbar. |
| Freigegeben – noch nicht öffentlich | Freigegeben, aber die Mitteilung selbst steht nicht auf „Öffentlich". Die Datei ist **nicht** erreichbar. |
| Öffentlich abrufbar | Freigegeben **und** die Mitteilung ist öffentlich. Die Datei ist ohne Anmeldung im Internet abrufbar. |

## Anhang öffentlich freigeben

Der Weg führt über „Öffentlich freigeben…" am jeweiligen Anhang. Der Dialog bündelt bewusst drei Dinge an einer Stelle:

1. **Vorschau der konkreten Datei.** Bilder und Videos werden dort angezeigt, PDF und Tracklogs lassen sich öffnen. Ohne gesehenen Inhalt sollte nichts freigegeben werden.
2. **Freigabeprüfung.** Zu bestätigen sind: keine personenbezogenen Daten, keine erkennbaren unbeteiligten Personen bzw. deren Zustimmung, keine Ton- oder Stimmaufnahmen Dritter, geklärte Urheber- und Nutzungsrechte, vorliegende Einwilligungen, und ein erkennbarer Sicherheitszweck. **Bei Tracklogs kommt ein Punkt hinzu:** Pilotenname im Header, Startplatz, Zeitstempel und die genaue Flugspur sind bewusst zu veröffentlichen.
3. **Freigabevermerk** (Pflicht, mindestens 10 Zeichen). Kurz in eigenen Worten, woraus sich die Zulässigkeit ergibt – zum Beispiel „Keine unzulässigen personenbezogenen Daten enthalten; erforderliche Bildrechte liegen vor." Der Vermerk wird am Anhang gespeichert und ist später einsehbar.

Der Knopf bleibt gesperrt, bis alle Punkte bestätigt und der Vermerk ausgefüllt ist.

**Was die Freigabe bewirkt:** Die Datei ist unter `/communications` ohne Anmeldung erreichbar – Bilder und Videos direkt sichtbar, PDF und Tracklogs als Download. Bei IGC-Dateien erscheint zusätzlich ein Hinweis auf einen externen Viewer; die Datei wird dabei **nicht** automatisch an einen Dienst übertragen, der Betrachter lädt sie selbst herunter.

## Freigabe zurücknehmen

„Freigabe zurücknehmen" macht die Datei sofort unzugänglich – ohne Rückfrage, weil das die sichere Richtung ist. Die Angaben zur letzten Freigabe (Zeitpunkt und Vermerk) bleiben absichtlich stehen, damit nachvollziehbar bleibt, dass und warum veröffentlicht wurde.

Freigabe und Widerruf werden im Audit-Log protokolliert. Aus Datenschutzgründen stehen dort weder der Dateiname noch der Text des Freigabevermerks.

**Eine Grenze, die man kennen sollte:** Der Widerruf wirkt in PAOLO sofort. Kopien, die jemand in der Zwischenzeit heruntergeladen hat, sind damit nicht zurückholbar. Deshalb ist die Prüfung **vor** der Freigabe entscheidend.

## Maßnahmen anlegen und nachverfolgen

Maßnahmen können direkt auf der Meldungs-Detailseite angelegt werden. Felder:

- Titel (Pflicht)
- Beschreibung
- Fälligkeitsdatum
- Status: `Offen`, `In Bearbeitung`, `Erledigt`, `Verworfen`
- Verantwortlich (Freitext)

Die Maßnahmenliste unter `/dashboard/measures` gibt einen Überblick über alle offenen und überfälligen Maßnahmen organisationsweit.

## Maßnahmen verwerfen

Eine Maßnahme, die sich erledigt hat oder irrtümlich angelegt wurde, wird auf
`Verworfen` gesetzt. Sie verschwindet damit aus der Nachverfolgung — aus
„Offene" und „Überfällige" auf dem Dashboard, aus der Maßnahmenliste und aus
der Arbeitsliste der Besprechungsprotokolle — bleibt aber auf der
Meldungs-Detailseite sichtbar, getrennt unter „Verworfen".

**Das Verwerfen verlangt eine kurze Begründung** (mindestens 10 Zeichen).
Ohne sie bleibt der Knopf gesperrt, wie beim Freigabevermerk für Anhänge. Der
Vermerk wird im Audit-Log festgehalten — **bitte keine personenbezogenen
Angaben eintragen**; er steht dort im Klartext, weil es dafür bislang keine
eigene Spalte gibt.

Eine bereits verworfene Maßnahme lässt sich weiterhin ohne neue Begründung
bearbeiten, und auch wieder auf `Offen` zurücksetzen.

**Gelöscht wird nichts.** Eine Maßnahme, die einmal existierte, gehört zum
Verlauf der Meldung. Enthält sie personenbezogene Angaben, die entfernt werden
müssen, ist das ein Datenschutzvorgang — siehe
[`../privacy-operations.md`](../privacy-operations.md).

## Sicherheitsbesprechungen eintragen

Sicherheitsbesprechungen werden unter dem Dashboard-Block „Sicherheitsbesprechung" eingetragen. Pflichtfeld ist das Datum; Titel und Notiz sind optional.

Das Dashboard zeigt automatisch:

- Datum der letzten Besprechung
- Datum der nächsten Fälligkeit
- Status: `Aktuell`, `Bald fällig` oder `Überfällig`

## Öffentliche Statusrückmeldung

Jede Meldung aus dem öffentlichen Formular erhält beim Speichern einen neutralen Meldungscode (zum Beispiel `Falke-12`). Die meldende Person bekommt ihn im Bestätigungsdialog angezeigt und kann ihn zusammen mit einer Zusammenfassung ihrer Meldung herunterladen.

Auf der öffentlichen Seite „Sicherheitsinformationen“ steht ganz oben die Box **„Status von Sicherheitsmeldungen“**. Sie ist zugeklappt und nennt in der Zeile darunter die Anzahl. Jede Zeile der aufgeklappten Liste zeigt ausschließlich den Meldungscode und den Bearbeitungsstatus — keine Inhalte, keine Namen, keine Kategorien, keine Datumsangaben.

Für dich bedeutet das **keine zusätzliche Arbeit**: Die Anzeige folgt automatisch dem Status, den du ohnehin setzt.

| Dein Status | Öffentlich sichtbar |
|---|---|
| Neu | Neu |
| In Prüfung | In Prüfung |
| In Bearbeitung | In Bearbeitung |
| Maßnahmen beschlossen | Maßnahmen beschlossen |
| Abgeschlossen | Abgeschlossen — und drei Monate nach dem Abschluss verschwindet der Eintrag |
| Ausgeblendet | kein Eintrag, sofort |

Weiteres, das du wissen solltest:

- Eine Meldung im **Papierkorb** erscheint ebenfalls nicht öffentlich.
- Setzt du eine ausgeblendete oder abgeschlossene Meldung wieder auf einen Bearbeitungsstatus, **erscheint sie wieder** — mit dem neuen Status. Ein erneuter Abschluss startet die drei Monate neu.
- Das bloße Speichern einer bereits abgeschlossenen Meldung — etwa nur zur Änderung der Priorität — verlängert die Frist **nicht**.
- Meldungen aus dem CSV-Import haben keinen Meldungscode und erscheinen deshalb nie in der Liste. Auch Meldungen, die vor Einführung dieser Funktion eingegangen sind, bleiben außen vor. Das ausdrücklich geladene synthetische Operator-Spieldaten-Fixture enthält dagegen Meldungscodes, damit sich die öffentliche Statusrückmeldung erproben lässt.
- Ob die Box überhaupt erscheint, entscheidet der Administrator unter Organisationseinstellungen → „Statusrückmeldungen öffentlich anzeigen“. Sie selbst können das dort ebenfalls umstellen.
- Ihre eigenen Sicherheitshinweise erscheinen auf derselben Seite unter der Überschrift **„Sicherheitshinweise“** — dieselbe Bezeichnung wie intern.

Was das für die Meldekultur bedeutet: Die Liste beantwortet die Frage „Passiert mit meiner Meldung überhaupt etwas?“, ohne etwas über den Inhalt zu verraten. Sie zeigt aber, **dass** und **wann** gemeldet wurde. In einer kleinen Gruppe kann das mit anderem Wissen zusammengebracht werden; das ist bekannt und bewusst in Kauf genommen. Wenn eine Meldung besonders heikel ist, ist der Status `Ausgeblendet` der Weg, sie aus der öffentlichen Liste zu nehmen — er wirkt sofort.

## Datenschutz-Einwilligung im Meldeformular

Unter `/dashboard/privacy` → **Einwilligung im Meldeformular** schaltest du die Datenschutz-Einwilligung auf „Sicherheitsmeldung einreichen“ ein oder aus und pflegst ihren Text. Voreingestellt ist sie eingeschaltet, mit einem abgestimmten Standardtext.

- Eingeschaltet muss der Melder ein leeres Kontrollkästchen ankreuzen, bevor er absenden kann. Ausgeschaltet entfällt es.
- Ein eigener Text muss `[Datenschutzerklärung]` genau einmal enthalten — dort steht im Formular der Link zur Datenschutzerklärung. Lass eine Textänderung vorher prüfen.
- Zu jeder Meldung mit Einwilligung speichert PAOLO Zeitpunkt, Einwilligungstext und die gültige Datenschutzerklärung als Nachweis.
- Änderst du Schalter oder Text, während jemand gerade meldet, muss er die Einwilligung neu laden und erneut zustimmen. Seine übrigen Eingaben bleiben erhalten.
- Jede Änderung steht im Audit-Log.

## Anzeigename der Organisation

Der „Anzeigename der Organisation“ steht einzeilig neben „PAOLO SMS“ im Kopf der Anwendung und ist **öffentlich sichtbar**. Er wird unter `/dashboard/settings` im Bereich **Anzeigename** gepflegt (Administratoren und Safety Manager); leer gelassen, erscheint nur „PAOLO SMS“. Einzelheiten stehen in der Anleitung für Administratoren unter Organisationseinstellungen.

## Turnus für Sicherheitsbesprechungen einstellen

Der Turnus (in Monaten) kann unter `/dashboard/admin` → Organisationseinstellungen geändert werden. Zulässig sind 1 bis 24 Monate, der Standardwert ist 12 Monate. Der Dashboard-Status wird sofort neu berechnet.

Oberhalb von 12 Monaten weist das Formular darauf hin, dass Sicherheitsbesprechungen mindestens einmal jährlich, idealerweise vierteljährlich stattfinden sollten; bei akuten Anlässen wie schweren Unfällen sollten zusätzlich außerordentliche Sicherheitsbesprechungen einberufen werden.

## Audit-Log nutzen

Das Audit-Log ist über `/dashboard/admin` → Audit-Log erreichbar. Es protokolliert alle sicherheitsrelevanten Aktionen im System: Statusänderungen, Maßnahmen, Sicherheitsbesprechungen und mehr. Es dient der Nachvollziehbarkeit und kann bei internen Überprüfungen hilfreich sein.

## Neue angemeldete Person anlegen und Rollen ändern

In der Zugangs- und Rollenverwaltung (`/dashboard/users`) können Sie neue
Konten mit der Rolle Benutzer, Safety Assistant oder Safety Manager anlegen.
Eine Administratorrolle dürfen Sie nicht vergeben. Pro Konto besteht höchstens
eine globale Rolle; „Rolle ändern“ ersetzt die bisherige Rolle.

Bei Clerk geben Sie die E-Mail-Adresse und die Rolle ein, bei Better Auth
zusätzlich den Namen. Nach erfolgreicher
Konto- und Rollenerstellung erscheint einmalig der Erstzugangslink: bei Clerk
ein Anmeldelink, bei Better Auth ein Link zu „Passwort festlegen“. Geben Sie
diesen ausschließlich über einen sicheren Übertragungsweg an die Person weiter.

Auch beim Anlegen eines weiteren Safety Managers erhalten Sie dessen
Erstzugangslink. Danach können Sie dieses Konto nicht mehr verwalten; es wird
Ihnen in der Kontenliste nicht angezeigt. Konten anderer Safety Manager und
Administratoren sind für Sie ebenfalls nicht sichtbar. Sie können deren Rolle
oder Kontodaten nicht ändern, das Konto nicht löschen und keinen neuen
Anmeldelink erzeugen. Dafür ist ein Administrator zuständig.

Besteht die eingegebene E-Mail-Adresse bereits, wird die Anlage ohne Änderung
an Konto oder Rolle abgelehnt. Die vorhandene Zeile können Sie nur verwenden,
wenn Ihre Berechtigungen dies zulassen. Ist das Konto nicht sichtbar oder die
benötigte Aktion nicht verfügbar, wenden Sie sich an einen Administrator.

Scheitert die Rollenzuweisung nach der Kontoanlage, bleibt das Konto mit
„Ohne Rolle“ bestehen. Weisen Sie ihm in der vorhandenen Zeile eine Rolle zu
und verwenden Sie anschließend „Anmeldelink erneuern“. Scheitert nur die
Linkbereitstellung, bleiben Konto und Rolle bestehen. Verwenden Sie ebenfalls
„Anmeldelink erneuern“, statt das Konto erneut anzulegen. Bei einem neu
angelegten Safety Manager übernimmt dies ein Administrator.

## Anmeldelink erneuern

In der Zugangs- und Rollenverwaltung (`/dashboard/users`) können Sie für Safety Assistants, Benutzer und Konten ohne Rolle einen neuen Anmeldelink erzeugen, wenn ein Zugang verloren oder abgelaufen ist. Für Administratoren, andere Safety Manager und für Ihr eigenes Konto geht das nicht.

Der Link gilt sieben Tage, erscheint nur einmal auf dem Bildschirm und gehört nur an die betreffende Person. Ältere Links bleiben bis zu ihrem Ablauf gültig. Bei Better Auth legt die Person über den Link ihr Passwort selbst neu fest; danach sind ihre bisherigen Sitzungen beendet.

## Kontodaten ändern und Konto löschen

Für Safety Assistants, Benutzer und Konten ohne Rolle können Sie in der Zugangs- und Rollenverwaltung den Namen ändern (bei Better Auth auch die E-Mail-Adresse) und das Konto endgültig löschen; zur Bestätigung ist die vollständige E-Mail-Adresse einzugeben. Für Administratoren, andere Safety Manager und Ihr eigenes Konto geht das nicht. Meldungen, Notizen und Audit-Einträge bleiben unverändert. Löschanfragen nach DSGVO laufen weiterhin über die Datenschutzprozesse.

## Administrationsübersicht

Safety Manager erreichen ihre Verwaltungsfunktionen über `/dashboard/admin`. Welche Kacheln dort für welche Rolle erscheinen, steht in [`../permission-matrix.md`](../permission-matrix.md), Abschnitt „Seiten und Routen" — CSV-Import und -Export sind dem Administrator vorbehalten, der FIDA-Export bewusst nicht.
