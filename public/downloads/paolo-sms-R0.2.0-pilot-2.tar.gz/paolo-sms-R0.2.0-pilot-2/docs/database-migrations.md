# Datenbank-Migrationen

Verbindliches Verfahren für PAOLO SMS, Stand 2026-08-27.

**Alle SQL-Dateien in `drizzle/` werden immer in Dateireihenfolge angewandt —
auch auf bereits initialisierten Datenbanken.** Eine konsistente Datenbank nach
`0000` bis zu einer beliebigen früheren Migration kann den vollständigen aktuellen
Satz erneut erhalten, ohne vorhandene Daten zu verlieren. Beispiel:
`0000..0007` → `0000..0031` → erneut `0000..0031`.

Aktueller Satz: **`0000`–`0036`**, nächste freie Nummer: **`0037`**.
Das gilt für die **überarbeiteten Dateien dieser Version**, nicht für SQL aus
älteren Checkouts. Keine alten und neuen Dateifassungen mischen.

## 1. Migrationsstrategie (verbindlich)

### 1.1 Quellen und Geltungsbereich

- `lib/db/schema.ts` beschreibt das aktive Anwendungsschema.
- Die geordneten SQL-Dateien in `drizzle/` beschreiben dessen Aufbau und
  notwendige Datenüberführungen. Vorhandene experimentelle AI-Tabellen bleiben
  außerhalb des aktiven Anwendungsschemas unverändert (siehe Abschnitt 2).
- Die reale Datenbank ist das Ergebnis. Drizzle-Journal, Snapshots und
  `drizzle.__drizzle_migrations` bleiben historische, unvollständige Artefakte;
  für dieses Verfahren ist **keine Migrationsbuchhaltung erforderlich**.

Voraussetzung ist ein konsistenter früherer Präfixzustand und darin gültige
Daten. Beliebiger manueller Schema-Drift, gleichnamige inkompatible Objekte,
fehlende Berechtigungen oder beschädigte Daten sind keine unterstützten
Ausgangszustände. Ein Fehler wird nicht verschluckt oder durch Löschen behoben.
Bereits vor diesem Update gelöschte Daten können nur aus einem Backup kommen.

### 1.2 Anwendung nur mit psql

Auf dem DB-Server oder einem Rechner mit PostgreSQL-Client genügen `psql` und
die Dateien `scripts/migrate.psql` sowie `drizzle/*.sql` aus **demselben Release**.
Die relative Verzeichnisstruktur beibehalten. Node.js, npm und Drizzle CLI sind
für die Anwendung nicht erforderlich.

```bash
# Lokal per Socket; DB-Name und Rolle bewusst wählen:
psql -X -U paolo -d paolo -f scripts/migrate.psql

# Remote über einen zuvor eingerichteten libpq-Service:
psql -X -d 'service=paolo' -f scripts/migrate.psql

# Alternativ mit bewusst gesetztem DATABASE_URL:
psql -X -d "$DATABASE_URL" -f scripts/migrate.psql
```

Passwörter vorzugsweise über `.pgpass`/`PGPASSFILE` oder einen Passwortprompt
bereitstellen. Keine Secrets in Logs aufnehmen. `psql` liest keine `.env`-Dateien.
Bei Remote-Verbindungen die TLS-Vorgaben des Betreibers einhalten.

Der Einstieg enthält alle Dateien explizit in aufsteigender Reihenfolge mittels
`\ir` (relativ zum Skript, unabhängig vom Arbeitsverzeichnis). Er setzt
`ON_ERROR_STOP`, führt **den gesamten Satz in einer Transaktion** aus, setzt den
Suchpfad auf `public` und serialisiert parallele Aufrufe desselben Einstiegs mit
einem transaktionsgebundenen Advisory Lock. `lock_timeout = 10s` verhindert
unbegrenztes Warten auf Sperren. Bei einem Fehler endet der Batch mit Fehlerstatus
und wird zurückgerollt. Erst nach Behebung erneut den vollständigen Satz ausführen.
Nicht mit einer äußeren Transaktion oder `--single-transaction` kombinieren.

`IF NOT EXISTS`-Hinweise werden im Einstieg unterdrückt (`client_min_messages =
warning`); echte Warnungen und Fehler bleiben sichtbar. Die alten Warnungen vor
dem Wiederholen des vollständigen SQL-Verlaufs gelten nicht mehr.

Interaktiv außerhalb einer laufenden Transaktion ist auch `\i
/Pfad/scripts/migrate.psql` möglich. Bei einem Fehler in einer bestehenden
psql-Sitzung ausdrücklich `ROLLBACK;` ausführen, bevor erneut gestartet wird.

Die einzelnen SQL-Dateien bleiben reines PostgreSQL-SQL, ohne psql-Metabefehle
oder eigene Transaktionssteuerung. Wer sie ohne den Einstieg einspielt, muss
Reihenfolge, Abbruch bei Fehler, Transaktion und alleinige Ausführung selbst
sicherstellen, z. B. für eine einzelne geprüfte Datei:

```bash
psql -X -v ON_ERROR_STOP=1 --single-transaction -d "$DATABASE_URL" \
  -f drizzle/0031_add_attachment_release_record.sql
```

Der vollständige Einstieg ist der Standard für Neuinstallation **und** Update.
Ein Suffix ist nur bei nachgewiesenem Vorzustand sinnvoll; insbesondere dieses
Update korrigiert historische Dateien und muss daher vollständig laufen.

#### Aus dem Docker-App-Image

Das App-Image enthält `/app/drizzle/`, `/app/scripts/migrate.psql` und
`/app/scripts/migrate.sh` aus demselben Build sowie den PostgreSQL-Client.
Das PostgreSQL-Image und seine Daten-Volumes bleiben unverändert. Die Migration
ist weiterhin **manuell**; der normale App-Start führt kein SQL aus.

Der POSIX-Shell-Einstieg benötigt ein bewusst gesetztes `DATABASE_URL`, lädt
keine `.env`-Dateien und ruft ausschließlich den oben beschriebenen psql-Einstieg
auf. Er funktioniert unabhängig vom Arbeitsverzeichnis, verweigert eine fehlende
oder leere URL und gibt den psql-Fehlerstatus unverändert zurück. In Compose kommt
die URL aus der konfigurierten `env_file`. Sie muss auf das freigegebene Ziel
zeigen und eine Eigentümerrolle mit den in Abschnitt 1.3 genannten Rechten
verwenden. Falls die App eingeschränkte Laufzeitrechte verwendet, für den
Migrationscontainer gesondert freigegebene Zugangsdaten bereitstellen.

Der Shell-Einstieg unterdrückt mit `psql -q -o /dev/null` normale
Command-Tags (`BEGIN`, `SET`, `CREATE TABLE` usw.) und Abfrageergebnisse.
**Warnungen und Fehler bleiben auf stderr sichtbar**, der Exit-Status bleibt
unverändert. Ein erfolgreicher Lauf ohne Warnungen erzeugt keine psql-Ausgabe.
Für ausführliche Diagnoseausgabe kann `psql -X -d "$DATABASE_URL" -f
/app/scripts/migrate.psql` direkt aufgerufen werden. Nach einer Änderung am
Einstieg das App-Image neu bauen; bereits gebaute Images behalten ihr Verhalten.

Für ein Update das Ziel-App-Image zuerst bauen, Schreibzugriffe pausieren und
den Einstieg in einem einmaligen Container **dieses Images** ausführen:

```bash
docker compose build app || exit 1
# Backup und Wartungsfenster gemäß Operator-Runbook; DB muss bereit sein.
docker compose stop app || exit 1
docker compose run --rm --no-deps -T app sh /app/scripts/migrate.sh || exit 1
```

`run` startet hier keinen Webserver und veröffentlicht keine App-Ports.
`--no-deps` startet auch keine Datenbank: das geprüfte Ziel muss bereits laufen
und Verbindungen annehmen. Nach erfolgreicher Schema-/Datenprüfung die App mit
`docker compose up -d --no-deps --force-recreate app` starten. Bei Verwendung
des Produktions-Overlays dieses bei **jedem** Compose-Befehl mit angeben; der
vollständige Ablauf einschließlich Nginx steht im
[Operator-Runbook](runbooks/production-docker-update.md).

Für einen bewussten Replay der **bereits laufenden Image-Version** ist auch
folgender Aufruf möglich; Schreibzugriffe vorher anderweitig pausieren:

```bash
docker compose exec -T app sh /app/scripts/migrate.sh
# Alternativ in einer mit `docker compose exec app sh` geöffneten Shell:
sh /app/scripts/migrate.sh
```

**Ein Build aktualisiert keinen laufenden Container.** `exec` verwendet dessen
alten SQL-Stand, bis er neu erstellt wurde; deshalb beim Update `run` verwenden.
Für Remote-Betrieb oder Installationen ohne Docker bleibt der direkte
psql-Aufruf unverändert verfügbar. Der Shell-Einstieg ist optional.

### 1.3 Betrieb und Freigabe

Vor einem Lauf Ziel-DB und autorisierten Auftrag prüfen, getestetes Backup
bereithalten und ein Wartungsfenster wählen. Schreibende App-Prozesse/Jobs für
den Lauf pausieren: DDL, Indexaufbau, Constraint-Prüfung und Datenmigrationen
können Tabellen sperren. Eine einzige Transaktion hält Sperren bis zum Ende;
Idempotenz bedeutet weder Null-Downtime noch eine Laufzeitgarantie.

Der ausführende Benutzer muss die Anwendungstabellen besitzen bzw. deren
Eigentümerrolle verwenden und Objekte im Schema `public` anlegen dürfen.
Kein Superuser ist grundsätzlich nötig. Es gibt weiterhin keinen
Migrationslauf beim Containerstart und keinen automatischen Zugriff auf andere
Installationen. Reference Prod und Betreiberinstallationen bleiben getrennt.

Docker-Ausführung: [Operator-Runbook](runbooks/production-docker-update.md).
Nach Erfolg Schema, Daten und Anwendung prüfen; bei Rollback vorzugsweise den
Anwendungscode zurücksetzen, nicht neue Spalten mit Nutzdaten löschen.

### 1.4 Verbindliche Regeln für jede neue SQL-Datei

1. Nächste freie vierstellige Nummer verwenden; keine Lücken, Umnummerierung
   oder Wiederverwendung. SQL manuell erstellen, aktives `lib/db/schema.ts`
   synchron halten. Kein `drizzle-kit generate`, `migrate` oder `push`.
2. **Jeder frühere konsistente Präfix muss den gesamten neuen Satz vertragen.**
   Idempotenz ist Pflicht, nicht „wo möglich“. Auch Wiederholungen nach späteren
   Migrationen prüfen: alte Defaults, strengere Indizes oder entfernte Features
   dürfen nicht wiederhergestellt werden.
3. Tabellen, Spalten und Indizes mit geeigneten Existenzprüfungen anlegen;
   Constraints tabellenspezifisch prüfen. `duplicate_object` nur für die konkrete
   bereits vorhandene Definition behandeln; keine pauschalen Fehlerfänger.
4. Daten erhalten. Kein `DROP TABLE`, `DROP COLUMN`, `TRUNCATE` oder `DELETE`
   zum Herstellen des Zielschemas. Strukturwechsel benötigen eine verlustfreie
   Überführung oder ein dokumentiertes relationales Archiv. Benötigte Backfills
   **vor** strengeren Constraints ausführen; wiederholbar, auf betroffene Zeilen
   begrenzt, ohne bestehende Benutzerwerte oder Freigaben zu überschreiben.
   Statische Ausgangsdaten gehören in dieselbe Migration, die ihre Tabelle
   anlegt. Test-Seeds setzen diese Daten als Migrationsergebnis voraus und
   dürfen sie nicht selbst rekonstruieren.
5. Kein `BEGIN`/`COMMIT`/`ROLLBACK`, keine psql-Metabefehle und keine außerhalb
   einer Transaktion erforderlichen Statements in `drizzle/*.sql`.
   `--> statement-breakpoint` bleibt ein optionaler SQL-Kommentar; niemals am
   Semikolon oder an Kommentaren selbst SQL zerlegen.
6. Datei in `scripts/migrate.psql` ergänzen. `npm run test:node` kontrolliert
   Nummerierung und vollständige Reihenfolge. Keine Journal-/Snapshot-Pflege.
7. `npm run test:migrations` ausführen: echtes PostgreSQL mit psql, alle Präfixe,
   Datenvergleich und wiederholter Voll-Lauf. Neue Entitäten/Felder und erlaubte
   Datenüberführungen im Fixture und den Assertions abdecken. Nach dem aktuellen
   vollständigen Migrationslauf bootstrapped der Test zusätzlich eine leere
   Installation und lädt den produktiven Betreiber-Spieldatensatz. Jede Änderung
   unter `drizzle/*.sql` muss damit auch nachweisen, dass dieser Datensatz weiter
   vollständig ladbar ist. Die Tests dürfen nicht lediglich leere Tabellen oder
   Zeilenzahlen prüfen.
8. Schema-/Migrationsänderungen über Branch und Pull Request mit Ansatz,
   Datenüberführung, Betriebsfolgen und Verifikationsnachweis. Entwicklungslog
   und [Release-Checkliste](release-checklist.md) aktualisieren.

Historische SQL darf für diese Replay-Eigenschaft nach geprüfter Überführung
angepasst werden; veröffentlichte Nummern bleiben bestehen. Dieses Update ist
bewusst eine solche Korrektur. Alte Originale bleiben als unveränderliches
Testfixture und in Git verfügbar. Künftige fachliche Änderungen erhalten eine
neue Nummer; notwendige Replay-Anpassungen älterer Dateien müssen im selben PR
geprüft werden. Destruktive Datenbereinigung nach Betreiberentscheidung gehört
in einen separaten Wartungsvorgang, nicht in den wiederholbaren Migrationssatz.

## 2. Datenüberführungen und AI-Bereinigung

### AI-Experiment (`0010`–`0013`)

Vergleich mit `experimental/ai-dialog` (`b1ce622`): Die dortigen SQL-Dateien
`0000`–`0012` sind mit dem bisherigen `main` identisch. `0010`–`0012` legen
**ausschließlich sechs AI-Tabellen** an; sie ergänzen keine AI-Spalten in
`reports` oder `organizations`. `0013` wurde erst auf `main` zur Löschung dieser
Tabellen ergänzt. Der Branch enthält außerdem schon allgemeine Melderfelder und
`safety_meetings` im TypeScript-Schema, die später durch `0017`/`0018` im SQL
nachgezogen wurden. Diese heute verwendeten Nicht-AI-Felder bleiben erhalten.
Bereits erzeugte Meldungen, deren `source_channel` und historische AI-Ereignisse
in `audit_logs` bleiben ebenfalls unverändert. Die vorhandenen Audit-Labels
dienen weiterhin der Lesbarkeit alter Einträge, nicht einem aktiven AI-Feature.

- `0010`–`0013` bleiben nummerierte Platzhalter ohne DDL. Frische
  Installationen erzeugen keine AI-Tabellen und kein Archivschema.
- Nach Rückmeldung des Repository-Eigentümers gibt es keine zu unterstützende
  Referenzinstallation auf einem AI-Zwischenstand `0010`–`0012`. Eine eigene
  Archivierung dieser Tabellen ist deshalb nicht erforderlich.
- Falls dennoch experimentelle Tabellen vorhanden sind, lässt der Replay sie
  unverändert im bisherigen Schema. Das vermeidet Datenverlust auch für diese
  historischen Präfixe, ohne neue Legacy-Strukturen einzuführen. Ihre Prüfung
  oder Löschung ist ein separater, ausdrücklich autorisierter Wartungsvorgang.
- Die sechs Namen sind `ai_intake_settings`, `ai_dialog_sessions`,
  `ai_dialog_turns`, `ai_dialog_artifacts`, `ai_intake_rate_limits` und
  `ai_usage_events`. Anwendungs-Lösch-/Anonymisierungswege und der begrenzte
  `paolo_data`-Export decken diese ehemaligen Dialogdaten nicht ab.

Read-only Inspektion bei Bedarf in psql: `\dt public.ai_*` und
`\d+ public.ai_dialog_sessions`. Für vorhandene Altbestände einen vollständigen
`pg_dump` und gegebenenfalls separate Artefaktdateien sichern. Gesprächsinhalte
nicht in öffentliche Logs kopieren. Bereits durch das alte `0013` gelöschte
Daten sind nicht rekonstruierbar. Die experimentelle Anwendung darf nicht
parallel auf dieser DB laufen.

### Rollen (`0003`/`0005`)

`0003` erzeugt den alten Benutzer/Rollen-Unique-Index nur vor Einführung von
`organization_id`. `0005` ersetzt ihn durch globale und organisationsbezogene
Unique-Indizes. Mehrere gültige Rollenzuordnungen desselben Benutzers bleiben
beim Wiederholen erhalten; vorhandene Rollenlabels werden nicht überschrieben.

### Dokumente und Anhänge (`0023`/`0031`)

`0023` überführt `internal` → `confidential` und `published` → `staff`, ohne
Inhalte oder bereits aktuelle Sichtbarkeiten zu ändern.

`0030` erlaubte bereits öffentliche Dokument-Anhänge ohne Freigabenachweis.
`0031` erhält deren `is_public`-Wert und ergänzt nur fehlende Nachweisfelder mit
**expliziter technischer Bestandsübernahme**: Akteur
`migration:0031:legacy-public`, Migrationszeitpunkt und ein Hinweis, dass keine
nachträgliche menschliche Freigabe und keine Kenntnis des ursprünglichen
Freigabezeitpunkts vorliegt. Das ist kein erfundener menschlicher Prüfnachweis.
Vorhandene Angaben sowie private/widerrufene Anhänge bleiben unverändert.
Danach erzwingt der Constraint die Nachweisfelder für öffentliche Anhänge.

## 3. Verifikation

```bash
npm run test:node
npm run test:migrations
```

Der Integrationstest benötigt lokal Docker und `postgres:16`, keine externe DB
und keine Secrets. Er erzeugt ausschließlich einen eigenen Container ohne
Netzwerk oder Host-Port, mit flüchtigem Datenverzeichnis, und entfernt ihn danach.
Er liest weder `DATABASE_URL` noch `.env`. Der separate CI-Workflow
`.github/workflows/migrations.yml` führt ihn nur aus, wenn SQL-Dateien in
`drizzle/` geändert wurden (Pull Request nach `main` oder Push auf `main`).
Änderungen nur an Dokumentation, Anwendung oder Tests starten diesen DB-Check
nicht; bei Teständerungen den Befehl deshalb lokal ausführen.

Die Matrix baut alle 32 ursprünglichen Präfixe aus dem eingefrorenen SQL-Fixture
und alle aktuellen Präfixe aus den überarbeiteten Dateien auf, zusätzlich leere
Datenbanken. Sie füllt jede vorhandene Tabelle einschließlich optionaler Felder,
AI-Inhalte, organisationsbezogener Rollen, verschiedener Dokumentsichtbarkeiten
und öffentlicher Anhänge. Nach zwei Voll-Läufen werden sämtliche bisherigen
Werte/Zeilenzahlen sowie Spalten, Typen, Defaults, Nullability, Constraints und
Indizes des aktiven Schemas gegen einen frischen Aufbau verglichen. Nur die
sechs bekannten AI-Tabellen sind von diesem Schema-Vergleich ausgenommen; ihre
Zeilen und Zusatzspalten bleiben im Datenvergleich enthalten. Ein zusätzliches
Archivschema darf nicht entstehen. Erlaubte Überführungen sind
explizit in Assertions beschrieben. Zusätzlich werden der echte psql-Einstieg
und vollständiger Rollback bei einem absichtlich injizierten Fehler geprüft.
Ein separater Lauf prüft das Upgrade neben befüllten AI-Tabellen als gewöhnlicher
Datenbank-/Tabelleneigentümer ohne Superuser-Rechte.

Der Shell-Einstieg wird außerdem mit einem fremden Arbeitsverzeichnis, Leerzeichen
im Bundle-Pfad, fehlender URL, Verbindungsfehler und injiziertem SQL-Fehler geprüft.
Erfolgreiche Läufe bleiben still; injizierte Warnungen und Fehler müssen trotz
unterdrückter Routineausgabe sichtbar bleiben und SQL-Fehler weiterhin abbrechen.
Bei Änderungen an Dockerfile, Bundle oder Shell-Einstieg zusätzlich das tatsächlich
gebaute Release-Image prüfen:

```bash
docker build -t paolo-sms:migration-check .
node tests/migrations/replay.mjs --app-image paolo-sms:migration-check
```

Diese Option führt zusätzlich zum normalen Testlauf Container aus dem App-Image
ohne Source-Mount aus. Sie prüft die enthaltenen Dateien gegen den Checkout,
Neuinstallation und befülltes Upgrade samt Replay mit dem normalen Nicht-root-
Image-Benutzer und einer DB-Eigentümerrolle ohne Superuser-Rechte. Nur der
Netzwerk-Namespace der eigenen Wegwerf-DB wird geteilt; keine Host-Ports oder
externen Datenbankziele werden verwendet. Der CI-Trigger bleibt ausschließlich
auf SQL-Änderungen beschränkt; Image-/Shell-Änderungen deshalb lokal prüfen.

Nach dem Präfix-/Replay-Teil erzeugt der Test außerdem eine frisch vollständig
migrierte Datenbank, legt die minimale Organisation/Admin-Zuordnung an und führt
die aus dem produktiven Spieldatenmodul erzeugten Inserts aus. Geprüft werden
20 Meldungen, 10 Maßnahmen, sechs Notizen, zwei Sicherheitsbesprechungen und
der Seed-Auditeintrag. Historische Präfixstände müssen den heutigen Datensatz
nicht laden können; maßgeblich ist der aktuelle vollständige Zielstand.

Quellen zu psql-Fehlerbehandlung/Includes und PostgreSQL-Strukturänderungen:
[psql](https://www.postgresql.org/docs/16/app-psql.html),
[ALTER TABLE](https://www.postgresql.org/docs/16/sql-altertable.html).


Frühere Migrationsprotokolle und die abgelösten Warnungen sind in der Git-Historie
und im Entwicklungsprotokoll des Repositorys nachvollziehbar (nicht im Quellpaket). Für neue Läufe
gilt ausschließlich das oben beschriebene Verfahren.
