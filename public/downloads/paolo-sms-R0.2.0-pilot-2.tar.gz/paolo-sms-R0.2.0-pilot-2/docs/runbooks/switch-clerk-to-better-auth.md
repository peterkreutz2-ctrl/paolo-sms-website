# Clerk-Installation auf Better Auth umstellen

Diese Betriebsanleitung beschreibt die Umstellung einer bestehenden
PAOLO-SMS-Docker-Installation von Clerk auf Better Auth, ohne die
PostgreSQL-Datenbank zu ersetzen oder vorhandene Fachdaten zu löschen.

Clerk ist der Standard bei der Installation. Better Auth ist eine optionale,
selbst betriebene Alternative für Betreiber, die lokale Kontrolle über
Authentifizierungsdaten und geringere Kosten für externe Anbieter bevorzugen.
Sie übernehmen dafür mehr Betriebsverantwortung und akzeptieren derzeit
weniger vollständige Funktionen zum Zurücksetzen von Passwörtern, zur
Verwaltung des Benutzerlebenszyklus und zur Sitzungsverwaltung. Die verbindlichen
Entscheidungskriterien und der aktuelle Vorbehalt stehen in
[`../installation-decision-guide.md`](../installation-decision-guide.md).

Dieses Runbook behandelt den Wechsel des Authentifizierungsanbieters, nicht
den allgemeinen Ablauf eines Releases oder einer Datenbankmigration. Für die
begleitenden Schritte zu Zustandsprüfung, Backup, Release und Abschlussprüfung
gilt
[`production-docker-update.md`](production-docker-update.md).

Eine **Produktionsinstallation** bezeichnet hier eine konkrete, unabhängig
betriebene Installation eines Vereins, einer Flugschule oder ihres
Dienstleisters. Damit ist keine zentrale PAOLO-SaaS-Umgebung gemeint.
Die **Reference Prod** des Projektteams enthält ausschließlich Spiel- und
Testdaten und dient der Erprobung dieses Ablaufs; sie ist keine echte
Produktivinstanz eines Betreibers.

Keine Secrets, Zugangsdaten, Tokens, privaten Schlüssel, öffentlichen
IP-Adressen, Hostnamen, Konto-IDs oder personenbezogenen Benutzerdaten in
diesem Dokument oder in Befehlsausgaben festhalten.

## Voraussetzungen

- Die bereitgestellte Anwendungsversion unterstützt `AUTH_MODE=betterauth`.
- Die Migrationen bis einschließlich `0024_add_better_auth.sql` wurden angewandt.
- Die aktuelle Installation ist funktionsfähig und verfügt über ein geprüftes
  Datenbank-Backup.
- Die öffentliche HTTPS-Basis-URL ist bekannt.
- Der Betreiber kann `.env.docker.local` bearbeiten und Docker-Befehle ausführen.
- Der Betreiber hat entschieden, dass der aktuelle Funktionsumfang von Better
  Auth für den Produktivbetrieb ausreicht. Vor dem Ersetzen von Clerk insbesondere
  das Zurücksetzen von Passwörtern sowie die Benutzer- und Sitzungsverwaltung prüfen.

Die vorhandenen Clerk-Variablen während der ersten Umstellung in der geschützten
Umgebungsdatei belassen. Im Better-Auth-Modus werden sie ignoriert und
ermöglichen eine schnellere Rückkehr zu Clerk.

## Schritt 1 — Vorhandenes Better-Auth-Schema prüfen

Ziel: Eine Konfigurationsumstellung verhindern, solange der Datenbank die für
Better Auth erforderlichen Tabellen fehlen.

Beispielbefehle:

```bash
cd /opt/paolo-sms

docker compose -f docker-compose.yml -f docker-compose.prod.yml exec -T db \
  psql -U paolo -d paolo -c "
SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'public'
  AND table_name IN (
    'better_auth_users',
    'better_auth_sessions',
    'better_auth_accounts',
    'better_auth_verifications'
  )
ORDER BY table_name;
"
```

Erwartetes Ergebnis: Alle vier Tabellen werden aufgelistet. Fehlt eine Tabelle,
den Vorgang abbrechen. Vor der weiteren Umstellung das kontrollierte
Migrationsverfahren für den Produktivbetrieb mit dem vollständigen, geprüften
Einstieg `scripts/migrate.psql` durchführen.

## Schritt 2 — Better-Auth-Secret erzeugen und sicher aufbewahren

Ziel: Better Auth ein starkes, dauerhaftes Signatur-Secret bereitstellen, das
vom Datenbankpasswort und den Backup-Secrets unabhängig ist.

Beispielbefehl:

```bash
umask 077
openssl rand -hex 32
```

Den erzeugten Wert im dafür vorgesehenen Passwortmanager speichern. Nicht in
Dokumentation, Tickets, Chats oder Argumente von Shell-Befehlen einfügen.
Eine spätere Rotation dieses Secrets macht bestehende Sitzungen ungültig.

## Schritt 3 — Better Auth konfigurieren

Ziel: Better Auth auswählen und die maßgebliche öffentliche URL für
Authentifizierungsanfragen und Anwendungslinks festlegen.

Beispieleinträge für die Umgebungsdatei:

```env
AUTH_MODE=betterauth
BETTER_AUTH_SECRET=<generated-secret>
BETTER_AUTH_URL=https://<public-domain>
APP_BASE_URL=https://<public-domain>
```

Datei bearbeiten und absichern:

```bash
nano .env.docker.local
chmod 600 .env.docker.local
stat -c '%a %U %G %n' .env.docker.local
```

Nicht geheime Werte prüfen und sicherstellen, dass jede erforderliche Variable
genau einmal vorkommt:

```bash
grep -E '^(AUTH_MODE|BETTER_AUTH_URL|APP_BASE_URL)=' .env.docker.local

for name in APP_BASE_URL AUTH_MODE BETTER_AUTH_URL BETTER_AUTH_SECRET; do
  count="$(grep -c "^${name}=" .env.docker.local)"
  echo "$name count=$count"
done

better_auth_secret="$(
  sed -n 's/^BETTER_AUTH_SECRET=//p' .env.docker.local
)"

if [ "${#better_auth_secret}" -ge 32 ]; then
  echo "BETTER_AUTH_SECRET=SET_AND_LONG_ENOUGH"
else
  echo "BETTER_AUTH_SECRET=MISSING_OR_TOO_SHORT"
fi

unset better_auth_secret
```

Erwartetes Ergebnis: Dateirechte `600`, übereinstimmende öffentliche HTTPS-URLs,
genau ein Eintrag je Variable und ein ausreichend langes Secret. Doppelte
Einträge entfernen; andernfalls kann ein späterer Wert die beabsichtigte
Einstellung unbemerkt überschreiben.

Eine Änderung an der Datei verändert den bereits laufenden Container nicht.
Clerk bleibt aktiv, bis der App-Container ausdrücklich neu erstellt wird.

## Better-Auth-Secret bei Offenlegung oder geplant rotieren

Dieses Verfahren beschreibt einen Betriebsvorgang und ist nicht Bestandteil
eines Security-Release-Laufs. Nach Abschluss des Wechsels bewertet
Security-Release-Stufe 2 (interne Sicherheitsunterlage des Repositorys) den
erreichten Better-Auth-Zielzustand automatisiert; sie prüft weder den Wechsel
selbst noch die konkrete Secret-Ablage der Betreiberumgebung.

Dieses Verfahren gilt sowohl bei einem vermuteten oder bestätigten
Offenlegungsfall als auch bei einer geplanten Rotation. Ein Secretwert wird
niemals in einem Ticket, Chat, Betriebsprotokoll oder Shell-Argument
dokumentiert.

### Offenlegungsfall

1. Den Vorfall intern mit Zeitpunkt, betroffener Installation und
   verantwortlicher Betriebsrolle eröffnen. Keine vermuteten Secretwerte oder
   personenbezogenen Daten eintragen.
2. Den Zugriff auf die geschützte Umgebungsdatei oder den verwendeten
   Secret-Speicher auf die notwendigen Betriebsrollen begrenzen. Hinweise auf
   eine weitergehende Offenlegung getrennt nach dem geltenden
   Sicherheitsvorfallprozess behandeln.
3. Mit `umask 077` und `openssl rand -hex 32` ein neues
   `BETTER_AUTH_SECRET` erzeugen und unmittelbar im vorgesehenen
   Passwortmanager oder Secret-Speicher sichern.
4. Den bisherigen Wert in der geschützten Laufzeitkonfiguration ersetzen. Den
   alten Wert nicht in eine Sicherung, Notiz oder Rückfall-Datei kopieren.
5. Den App-Container neu erstellen und danach Nginx neu starten:

   ```bash
   docker compose -f docker-compose.yml -f docker-compose.prod.yml \
     up -d --force-recreate app

   docker compose -f docker-compose.yml -f docker-compose.prod.yml \
     restart nginx
   ```

6. Den öffentlichen Zustandscheck aufrufen. Anschließend in einem privaten
   Browserfenster eine neue Anmeldung und Abmeldung prüfen.
7. Eine vor der Rotation bestehende Sitzung muss den Zugriff auf eine
   geschützte Seite verlieren. Bleibt sie gültig, die Rotation als
   fehlgeschlagen behandeln und keine Freigabe erklären.
8. Das Betriebsprotokoll ergänzt ausschließlich: Zeitpunkt, ausführende
   Betriebsrolle, Grund `Offenlegungsfall`, Ergebnis von Zustandscheck,
   Neuanmeldung, Abmeldung und Prüfung der alten Sitzung. Der Secretwert und
   Sitzungsdaten werden nicht protokolliert.

Ein kompromittiertes Secret wird auch bei Problemen nicht wieder eingesetzt.
Stattdessen wird ein weiterer neuer Wert erzeugt und die Ursache des Fehlers
behoben.

### Geplante Rotation

1. Wartungszeitpunkt und verantwortliche Betriebsrolle festlegen. Betroffene
   Personen vorab darauf hinweisen, dass bestehende Sitzungen enden.
2. Neues Secret wie oben erzeugen, geschützt hinterlegen und in der
   Laufzeitkonfiguration ersetzen.
3. App-Container und Nginx wie oben neu starten.
4. Zustandscheck, Neuanmeldung, Abmeldung und Ungültigkeit einer bestehenden
   Sitzung prüfen.
5. Im Betriebsprotokoll nur Zeitpunkt, Betriebsrolle, Grund
   `geplante Rotation` und die vier Prüfergebnisse dokumentieren.

Ein Anwendungs-Rollback verwendet weiterhin das neue Secret. Das alte Secret
ist kein zulässiger technischer Rückfallweg.

## Schritt 4 — Temporäres Bootstrap-Image bauen

Ziel: Das TypeScript-Bootstrap-Skript ausführen, ohne Node.js und
Entwicklungsabhängigkeiten auf dem Produktionshost zu installieren. Das normale
Produktionsimage enthält nur die Standalone-Laufzeitumgebung und kann dieses
Skript nicht ausführen.

Beispielbefehle:

```bash
docker build \
  --target builder \
  -t paolo-sms:betterauth-bootstrap \
  .

echo "Bootstrap image build exit: $?"

docker image inspect paolo-sms:betterauth-bootstrap \
  --format 'Image ID: {{.Id}}'
```

Die Option `-t` vergibt die lokale Image-Referenz
`paolo-sms:betterauth-bootstrap`. Sie startet oder veröffentlicht das Image
nicht und ersetzt auch nicht `paolo-sms:prod`.

## Schritt 5 — Ersten Better-Auth-Administrator einrichten

Ziel: Die ersten Passwort-Zugangsdaten anlegen und die zugehörige
Better-Auth-Benutzer-ID der globalen PAOLO-Rolle `admin` zuordnen.

Das von PostgreSQL verwendete Compose-Netzwerk ermitteln:

```bash
DB_CONTAINER_ID="$(
  docker compose -f docker-compose.yml -f docker-compose.prod.yml ps -q db
)"

DB_NETWORK="$(
  docker inspect "$DB_CONTAINER_ID" \
    --format '{{range $name, $config := .NetworkSettings.Networks}}{{$name}}{{end}}'
)"

printf 'Database network: %s\n' "$DB_NETWORK"
```

Den interaktiven Bootstrap mit der vorgesehenen E-Mail-Adresse und dem
Anzeigenamen des Administrators ausführen:

```bash
docker run --rm -it \
  --network "$DB_NETWORK" \
  --env-file .env.docker.local \
  paolo-sms:betterauth-bootstrap \
  npm run auth:bootstrap-admin -- admin@example.org "Administrator Name"
```

Ein starkes, nur hierfür verwendetes Passwort eingeben und im Passwortmanager
speichern. Der Bootstrap ist bewusst auf die Ersteinrichtung begrenzt und
verweigert die Ausführung, sobald bereits ein Better-Auth-Benutzer oder ein
globaler Better-Auth-Administrator existiert. Der einmalige Container wird
dank `--rm` automatisch entfernt.

Bestehende Clerk-Identitäten werden nicht konvertiert. Ihre Einträge in
`user_roles` können bestehen bleiben; diese Identitäten können sich jedoch
nicht anmelden, solange Better Auth ausgewählt ist. Weitere Better-Auth-Konten
werden anschließend über die Zugangs- und Rollenverwaltung von PAOLO angelegt.

## Schritt 6 — Identitäts- und Berechtigungsdaten prüfen

Ziel: Vor der Umstellung der laufenden Anwendung bestätigen, dass sowohl die
Authentifizierungsdaten als auch die PAOLO-Berechtigungen angelegt wurden.

Beispielbefehle:

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml exec -T db \
  psql -U paolo -d paolo -c "
SELECT count(*) AS better_auth_user_count
FROM better_auth_users;

SELECT count(*) AS credential_account_count
FROM better_auth_accounts
WHERE provider_id = 'credential'
  AND password IS NOT NULL;

SELECT count(*) AS global_better_auth_admin_count
FROM better_auth_users bau
JOIN user_roles ur
  ON ur.clerk_user_id = bau.id
JOIN roles r
  ON r.id = ur.role_id
WHERE r.key = 'admin'
  AND ur.organization_id IS NULL;

SELECT count(*) AS active_session_count
FROM better_auth_sessions;
"
```

Nach einem neuen Bootstrap werden ein Benutzer, ein Konto mit
Passwort-Zugangsdaten und ein globaler Better-Auth-Administrator erwartet.
Vor der ersten Anmeldung darf noch keine Sitzung existieren.

## Kontobereitstellung und administratives Recovery

### Kontobereitstellung

Der Bootstrap des ersten Administrators bleibt die Ausnahme: Er verwendet das
in Schritt 5 gesetzte Passwort, weil noch keine angemeldete Person einen
administrativen Passwortlink erzeugen kann.

Weitere Konten legen Administratoren oder Safety Manager in der Zugangs- und
Rollenverwaltung an. Benötigt werden E-Mail-Adresse, Name und die zulässige
Rolle. Ein Passwortfeld gibt es nicht. PAOLO erzeugt ein kryptografisch starkes
Ausgangspasswort, das weder angezeigt noch übermittelt, protokolliert oder
auditiert wird. Nach Konto- und Rollenerstellung erscheint einmalig ein Link
zu „Passwort festlegen“ (sieben Tage gültig, einmal verwendbar).

Vor der Übergabe Berechtigung und Identität der Person über einen vereinbarten
zweiten Kontaktweg prüfen. Den Link ausschließlich über einen sicheren
Übertragungsweg weitergeben. Konto und Rolle bestehen unmittelbar; es gibt
keinen ausstehenden Einladungsstatus und keinen automatischen E-Mail-Versand.
Vorhandene normalisierte E-Mail-Adressen werden ohne Änderungen abgelehnt.

Scheitert die Rollenzuweisung, bleibt das Konto mit „Ohne Rolle“ bestehen.
In der vorhandenen Zeile die Rolle zuweisen und anschließend „Anmeldelink
erneuern“ verwenden. Scheitert nur die Linkbereitstellung, bleiben Konto und
Rolle bestehen; ebenfalls „Anmeldelink erneuern“ verwenden, nicht erneut anlegen.

### Administratives Recovery

Administrator oder Safety Manager erzeugen nach Identitätsprüfung in der
vorhandenen Kontenzeile mit „Anmeldelink erneuern“ einen neuen Link zu
„Passwort festlegen“. Die Person setzt ihr Passwort selbst. Benutzer-ID und
Rolle bleiben erhalten; nach erfolgreichem Festlegen werden die bisherigen
Sitzungen widerrufen. Ältere Links bleiben bis zum Ablauf gültig, sofern sie
nicht bereits verbraucht wurden.

Keine direkten Änderungen an Passwortspalten, keine neue Identität und kein
Löschen und Neuerstellen als Ersatz für Recovery. Im Betriebsprotokoll nur
Zeitpunkt, ausführende Betriebsrolle, erfolgte Identitätsprüfung und Ergebnis
erfassen; keine personenbezogenen Daten, Passwörter, Hashes, Links oder Tokens.

## Schritt 7 — Anwendung umstellen

Ziel: Den App-Container mit der neuen Umgebungskonfiguration neu erstellen,
während PostgreSQL und die persistenten Volumes unverändert bleiben.

Beispielbefehle:

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml \
  up -d --force-recreate app
```

Das Ergebnis des Zustandschecks der Anwendung abwarten:

```bash
APP_CONTAINER_ID="$(
  docker compose -f docker-compose.yml -f docker-compose.prod.yml ps -q app
)"

for attempt in $(seq 1 30); do
  health="$(
    docker inspect "$APP_CONTAINER_ID" \
      --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}'
  )"

  echo "App health: $health"

  if [ "$health" = "healthy" ] || [ "$health" = "unhealthy" ]; then
    break
  fi

  sleep 2
done
```

Den aktiven Authentifizierungsmodus prüfen und Nginx die Docker-Adresse des
App-Containers neu auflösen lassen:

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml exec -T app \
  printenv AUTH_MODE

docker compose -f docker-compose.yml -f docker-compose.prod.yml \
  restart nginx

docker compose -f docker-compose.yml -f docker-compose.prod.yml ps
curl -fsS https://<public-domain>/api/health
```

Erwartetes Ergebnis: `AUTH_MODE` gibt `betterauth` aus, alle Dienste sind
`healthy`, und der öffentliche Endpunkt liefert `{"status":"ok"}`.

Nach dem Neuerstellen des App-Containers muss Nginx neu gestartet werden.
Andernfalls kann Nginx die interne Docker-IP des vorherigen App-Containers
weiterverwenden und vorübergehend `502 Bad Gateway` zurückgeben.

## Schritt 8 — Authentifizierung über den öffentlichen HTTPS-Zugang testen

Ziel: Cookies, Weiterleitungen, das Verhalten des Authentifizierungsanbieters
und die Berechtigungen über den tatsächlichen Reverse Proxy prüfen.
Der Zustandscheck des Containers allein reicht dafür nicht aus.

In einem privaten Browserfenster:

1. `/sign-in` öffnen.
2. Mit dem über den Bootstrap angelegten Better-Auth-Administrator anmelden.
3. `/dashboard`, `/dashboard/admin`, `/dashboard/users` und
   `/dashboard/reports` öffnen.
4. Eine bestehende Meldung öffnen und prüfen, ob ihre Detailseite geladen wird.
5. `/sign-up` öffnen und prüfen, dass keine öffentliche Selbstregistrierung
   möglich ist.
6. Abmelden.
7. `/dashboard` direkt öffnen und prüfen, dass eine Anmeldung verlangt wird.

Damit werden Authentifizierung, Sitzungsverwaltung, die Berechtigungen des
globalen Administrators und der weiterhin mögliche Zugriff auf Fachdaten aus
der Zeit vor der Umstellung geprüft.

## Schritt 9 — Temporäre Werkzeuge entfernen

Ziel: Die Entwicklungswerkzeuge nach dem einmaligen Bootstrap aus dem lokalen
Docker-Image-Bestand des Produktionshosts entfernen.

Beispielbefehle:

```bash
docker image rm paolo-sms:betterauth-bootstrap
echo "Image removal exit: $?"

if docker image inspect paolo-sms:betterauth-bootstrap >/dev/null 2>&1; then
  echo "Bootstrap image still present"
else
  echo "Bootstrap image removed"
fi
```

Gemeinsam genutzte Image-Schichten, die das Produktionsimage weiterhin
referenziert, bleiben durch Docker geschützt.

## Schritt 10 — Backup erstellen und Abschlussprüfung durchführen

Ziel: Die Better-Auth-Identität sichern und den abschließenden Betriebszustand
bestätigen.

Der vollständige Ablauf für Backup und Abschlussprüfung steht in
[`production-docker-update.md`](production-docker-update.md). Die folgenden
Befehle ergänzen lediglich die anbieterspezifischen Abschlussprüfungen.

Das geschützte Backup nur auslösen, wenn der konfigurierte Mindestabstand
dies zulässt:

```bash
sudo /usr/bin/curl --config /etc/paolo/backup-cron.curl
echo "Backup exit: $?"
```

HTTP `429` ist zu erwarten, wenn innerhalb von
`BACKUP_CRON_MIN_INTERVAL_MINUTES` bereits ein anderes Backup erfolgreich
erstellt wurde. Den Schutz durch Mindestabstand und Ausführungssperre (Lease)
im Produktivbetrieb nicht abschwächen oder umgehen, nur um ein zweites Archiv
zu erzwingen. Stattdessen Cron prüfen und das nächste nach Ablauf des
Mindestabstands regulär erstellte Archiv kontrollieren:

```bash
sudo stat -c '%a %U %G %n' /etc/paolo/backup-cron.curl
sudo cat /etc/cron.d/paolo-backup
systemctl is-active cron

docker compose -f docker-compose.yml -f docker-compose.prod.yml exec -T app \
  ls -lhtr /app/backups | tail -4
```

Abschließende Prüfung durchführen:

```bash
git branch --show-current
git log -1 --oneline
git status --short

docker compose -f docker-compose.yml -f docker-compose.prod.yml ps

docker compose -f docker-compose.yml -f docker-compose.prod.yml exec -T app \
  printenv AUTH_MODE

curl -fsS https://<public-domain>/api/health

df -h /
docker system df
```

## Rückkehr zu Clerk

Falls Better Auth nicht funktioniert, Anwendung und Datenbank ansonsten aber
weiterhin nutzbar sind:

1. `AUTH_MODE=clerk` setzen.
2. Die beibehaltenen Clerk-Variablen auf Korrektheit prüfen.
3. Den App-Container neu erstellen.
4. Nginx neu starten.
5. Den öffentlichen Zustandscheck und die Anmeldung über Clerk prüfen.

Beispielbefehle:

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml \
  up -d --force-recreate app

docker compose -f docker-compose.yml -f docker-compose.prod.yml \
  restart nginx
```

Keine Better-Auth-Benutzer löschen und nicht `npm run auth:reset` ausführen,
nur um zu Clerk zurückzukehren. Die Auswahl des Authentifizierungsanbieters
erfolgt über `AUTH_MODE`.

## Beispiel: erfolgreich erprobte Umstellung

Beim dokumentierten Durchlauf am 2026-07-30 auf einer produktionsnahen
Testinstallation (keiner echten Produktionsumgebung) ergab sich Folgendes:

- Die vier Better-Auth-Tabellen waren durch Migration `0024` bereits vorhanden.
- Die geschützte Umgebungsdatei hatte die Rechte `0600`.
- Ein doppelter Eintrag für `APP_BASE_URL` wurde vor der Umstellung erkannt
  und entfernt.
- Das temporäre Builder-Image wurde erfolgreich gebaut und dem
  Compose-Datenbanknetzwerk zugeordnet.
- Der Bootstrap erzeugte einen Better-Auth-Benutzer, ein Konto mit
  Passwort-Zugangsdaten und einen globalen Administrator; vor der Anmeldung
  gab es keine Sitzung.
- Der App-Container wurde neu erstellt, Nginx neu gestartet und alle Dienste
  erreichten den Zustand `healthy`.
- Die Browserprüfungen für Anmeldung, Administration, Zugangs- und Rollenverwaltung,
  Meldungen, bestehende Meldungsdetails, deaktivierte öffentliche Registrierung,
  Abmeldung und die Zugriffskontrolle geschützter Routen waren erfolgreich.
- Das temporäre Bootstrap-Image wurde entfernt.
- Ein Backup-Versuch nach der Umstellung am selben Tag lieferte `429`, weil
  seit dem Backup vor dem Update der konfigurierte Mindestabstand von
  1.440 Minuten noch nicht verstrichen war. Der eingerichtete Cron-Auftrag
  blieb gültig.
