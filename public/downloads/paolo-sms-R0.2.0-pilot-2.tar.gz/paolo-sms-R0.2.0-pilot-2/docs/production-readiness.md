# PAOLO SMS – Produktionsbereitschaft

Dieses Dokument beschreibt den aktuellen Stand von PAOLO SMS im Hinblick auf Produktionsbetrieb. Es dient als Arbeitsgrundlage und wird fortgeschrieben. Es ersetzt keine formale Sicherheitsprüfung oder Zertifizierung.

Wer eine Installation einführen und betreiben will, beginnt beim
[Betreiberleitfaden](operator-guide.md); dieses Dokument nennt die Grenzen, die
dabei zu kennen sind.

---

## Einordnung

PAOLO SMS befindet sich im MVP-/Pilotbetrieb. Das System ist für eine kleine, bekannte Benutzergruppe in einem kontrollierten Umfeld ausgelegt. Was PAOLO vor einer Pilotfreigabe schuldet und was der Betreiber vor der Inbetriebnahme mitbringen muss, trennt der Abschnitt „Maßnahmen vor Inbetriebnahme".

PAOLO SMS ist dabei keine zentral betriebene SaaS-Anwendung. Vereine,
Flugschulen oder ihre Dienstleister betreiben voneinander unabhängige
Installationen und entscheiden selbst über Hosting, Authentifizierung,
Datenbank und Storage. Dieses Dokument bewertet die Software als Grundlage für
solche Betreiberinstallationen; es beschreibt keine einzelne zentrale
Produktionsumgebung.

Das Projektteam betreibt ausschließlich eine produktionsnahe
Referenzinstallation (`Reference Prod`) mit Spiel-/Testdaten für Installations-,
Update-, Migrations-, Backup- und Betriebsproben. Sie enthält keine realen
Betreiberdaten und ist keine echte Produktivinstanz eines Vereins oder einer
Flugschule.

Die aktuelle Betriebsannahme ist eine Organisation pro Installation. Ein
zentraler Mehrorganisationen-/Mandantenbetrieb, etwa durch den DHV, ist nicht
Gegenstand der Friends-&-Family-Phase und würde eine größere spätere Produkt-,
Sicherheits-, Datenschutz- und Architekturentscheidung erfordern.

---

## Aktueller Sicherheitsstand

- Authentifizierung ist über `AUTH_MODE` austauschbar (`clerk` | `betterauth` |
  `file`, siehe [`installation-decision-guide.md`](installation-decision-guide.md)).
  Die Standardinstallation nutzt `AUTH_MODE=clerk`: keine eigene
  Passwortverwaltung, Public Sign-up deaktiviert (Clerk Restricted Mode aktiv).
  Bei `AUTH_MODE=betterauth` verwaltet PAOLO Zugangsdaten selbst
  (datenbankbasiertes E-Mail/Passwort-Login). Das reduziert externe
  Provider-Abhängigkeit und mögliche laufende Auth-Kosten, erhöht aber die
  Betreiberverantwortung für Secrets, Recovery, Benutzer-Lifecycle, Sitzungen,
  Backups und Sicherheitsupdates. Ob dieser Modus bereits vollständig
  produktionsreif als Clerk-Ersatz ist, ist noch nicht entschieden. Eine
  Umstellung wurde auf einer produktionsnahen Testinstallation erfolgreich
  erprobt, nicht auf einer realen Produktionsumgebung; Runbook:
  [`runbooks/switch-clerk-to-better-auth.md`](runbooks/switch-clerk-to-better-auth.md).
- PAOLO-Rollen werden separat in der PAOLO-Datenbank vergeben; der jeweilige
  Auth-Provider übernimmt ausschließlich Login und Session.
- Dashboard-Zugriff über rollenbasierte Prüfungen in Server Components und Server Actions.
- Server Actions prüfen Berechtigungen vor jeder schreibenden Operation.
- Audit-Log protokolliert sicherheitsrelevante Aktionen.
- **Sicherheits-Vorabcheck am 04.09.2026 durchgeführt** (read-only, kein
  Ersatz für das vollständige Assessment): 471 Commits der Git-Historie
  durchsucht — **keine Secrets**, keine je committete `.env`-Datei außer den
  `*.example`, kein privater Schlüssel, kein Cloud- oder Repository-Token.
  Abhängigkeiten: 17 Advisories, 10 hoch, 7 mittel, keine kritischen; der
  blockierende Teil steht unter „Maßnahmen vor Inbetriebnahme". Ports: Das
  Produktions-Overlay veröffentlicht ausschließlich 80/443 über Nginx, die App
  ist nur intern erreichbar, die Datenbank gar nicht. Nicht geprüft: OWASP,
  Auth-/Autorisierungstests, ZAP, Container- und Host-Härtung.
- Strukturierte PostgreSQL-Datenbank; Datenmodell relational. Der Betreiber
  wählt zwischen PostgreSQL im eigenen Docker (Standard für Selbstbetrieb) und
  Neon als Cloud-Variante, siehe
  [`installation-decision-guide.md`](installation-decision-guide.md).
- Dateianhänge (Vercel Blob oder lokaler Dateispeicher) sind grundsätzlich nur
  für angemeldete Nutzer mit entsprechender Rolle abrufbar. **Eine Ausnahme
  besteht bewusst:** Anhänge eines SMS-Dokuments können vom Safety
  Manager ausdrücklich öffentlich freigegeben werden und sind dann ohne
  Anmeldung abrufbar. Das setzt zwei Bedingungen zugleich voraus — der Anhang
  ist freigegeben **und** die Mitteilung selbst steht auf „Öffentlich". Die
  Auslieferung läuft über eine kontrollierte Route, die beides bei jedem
  einzelnen Abruf neu prüft; es gibt keine öffentlichen Blob-Direktlinks.
  Ein Widerruf wirkt daher sofort.
- Vor jeder Freigabe ist eine Datenschutz- und Rechteprüfung zu bestätigen
  (personenbezogene Daten, erkennbare Personen, Ton-/Stimmaufnahmen, Urheber-
  und Nutzungsrechte, Einwilligungen; bei Tracklogs zusätzlich Pilotenname und
  Positionsdaten) und ein Freigabevermerk im Klartext zu hinterlegen. Freigabe
  und Widerruf werden im Audit-Log protokolliert; Zustandsänderung und
  Audit-Eintrag erfolgen atomar in einer Transaktion.
- Erlaubte Dateitypen sind als Positivliste definiert: JPG, PNG, WEBP, PDF,
  TXT, IGC, GPX, KML und MP4. Das Größenlimit beträgt einheitlich 4 MiB für
  alle Storage-Provider. Video zusätzlich: nur MP4, maximal 60 Sekunden,
  Prüfung über Endung, MIME-Typ und Dateisignatur.
- **Melderidentität und interne Notizen sind auf den Bearbeiterkreis begrenzt**
  (Ü1 zu Issue #50): Name, Rolle und Kontakt der meldenden Person sowie die
  internen Notizen sehen nur `admin` und `safety_manager`. Für die Rolle
  `instructor` (Safety Assistant) werden diese Daten serverseitig **nicht
  geladen**, nicht bloß ausgeblendet. **Nicht erfasst** sind Freitexte, Anhänge
  und das Feld `assignedToText` an Maßnahmen — sie können weiterhin Personen
  erkennbar machen und stehen dem internen Zugang offen. Das bleibt eine Frage
  der Schreibdisziplin und der Datenschutzprüfung nach Abschluss.
- Administrationsfunktionen unter `/dashboard/admin` gebündelt; Import und Export nur für Admin.
- Datenschutz-Werkzeuge unter `/dashboard/privacy` (Betroffenenanfragen-Suche, Anonymisierung strukturierter Melderdaten, Incident-Response-Dokumentation) nur für `admin`/`safety_manager`; Betriebssicht in [`docs/privacy-operations.md`](privacy-operations.md).
- Rechtliche Angaben installationsspezifisch über `/dashboard/admin/legal` pflegbar; öffentliche Seiten `/impressum` und `/datenschutz` zeigen fehlende Felder als „noch nicht hinterlegt".

---

## Annahmen für MVP/Pilotbetrieb

- Kleine, bekannte Benutzergruppe.
- Kontrollierte Rollenvergabe durch Admin oder Safety Manager.
- Benutzerzugang manuell durch einen Administrator: bei `AUTH_MODE=clerk` über
  einen Sign-in-Link, bei `AUTH_MODE=betterauth` über einen Link zu
  „Passwort festlegen“. Das interne Ausgangspasswort wird nicht offengelegt. In beiden Fällen ohne automatischen Versand.
- Betrieb zunächst in einer Organisation bzw. einem kontrollierten Umfeld.
- Keine offene öffentliche SaaS-Plattform.

---

## Bekannte Einschränkungen

- **Öffentliche Statusrückmeldung veröffentlicht Metadaten:** Auf
  `/communications` steht je Meldung ein zufälliger Meldungscode und der
  Bearbeitungsstatus — keine Inhalte, keine Namen, keine Datumsangaben. Die
  Liste zeigt damit trotzdem, **dass** gemeldet wurde und in welcher
  Reihenfolge. In einer kleinen Organisation kann das mit anderem Wissen zu
  einem Rückschluss auf eine einzelne Meldung führen. Das Restrisiko ist
  bekannt und für diese Funktion bewusst in Kauf genommen; die
  verhältnismäßige Gegenmaßnahme ist der Organisationsschalter
  „Statusrückmeldungen öffentlich anzeigen" (Voreinstellung: ein), der die
  Datenbereitstellung vollständig abschaltet. Einordnung und Begründung:
  [`data-protection-concept.md`](data-protection-concept.md), Abschnitt 11a.
- **Organisations-Scoping:** Das Datenmodell unterstützt mehrere Organisationen (Feld `organizationId` in `user_roles`), aber der Mehrorganisationenbetrieb ist noch nicht vollständig umgesetzt. Alle Abfragen filtern aktuell auf globale Rollen ohne Organisationszuordnung.
- **Middleware-/Route-Schutz:** Berechtigungsprüfungen erfolgen überwiegend in Server Components und Server Actions. Ein zusätzlicher Schutz auf Middleware-Ebene (z. B. via `clerkMiddleware` mit Route-Guards) ist möglich, aber noch nicht umgesetzt.
- **Benutzerprofildaten:** Bei `AUTH_MODE=clerk` (Standardinstallation)
  gibt es keine lokale Users-Tabelle mit vollständigen Profildaten;
  Anzeigenamen und E-Mail-Adressen kommen aus der Clerk-API und sind nicht
  lokal persistiert. Bei `AUTH_MODE=betterauth` liegen Profildaten dagegen in
  der lokalen Tabelle `better_auth_users`.
- **Einladungsverfahren:** Die Kontoanlage ist in beiden Anmeldeverfahren manuell. **Für eine PAOLO-Installation mit Clerk-Authentifizierung ist mindestens ein SSO-Anbieter erforderlich.** Bei Clerk übermittelt der Administrator den einmaligen Anmeldelink manuell und ausschließlich über einen gesicherten Übermittlungsweg. Die Person verwendet für spätere Anmeldungen Google SSO mit dem zur eingeladenen E-Mail-Adresse gehörenden Google-Konto oder legt noch während der ersten Sitzung in der eingebetteten Clerk-Kontoverwaltung ein Passwort fest, bevor sie sich abmeldet. Bei Better Auth wird nach der regulären Kontoanlage einmalig ein Link zu „Passwort festlegen“ angezeigt und sicher übermittelt. Das kryptografisch erzeugte Ausgangspasswort wird niemandem bekannt gemacht. Der Bootstrap des ersten Administrators bleibt ausgenommen. Verlorene oder abgelaufene Zugänge lassen sich über „Anmeldelink erneuern“ ersetzen (Administrator und Safety Manager, #111): bei Clerk durch einen neuen Sign-in-Link, bei Better Auth durch einen Link zur Seite „Passwort festlegen“ (sieben Tage gültig, einmal verwendbar, alle bisherigen Sitzungen werden widerrufen), ohne E-Mail-Dienst. Der Clerk-Ablauf ist eine Übergangslösung: Es gibt keine ausstehenden Registrierungen, keinen Einladungsstatus, keinen automatischen E-Mail-Versand und keine vorgemerkte Rolle, die erst nach erfolgreicher Registrierung gebunden wird. **Grenzen:** Ein neuer Link widerruft ältere nicht — sie gelten bis zu ihrem Ablauf (Clerk kann Token nicht auflisten, in das interne Speicherformat von Better Auth greift PAOLO nicht ein). Das Better-Auth-Token liegt im Klartext in `better_auth_verifications`; wer die Tabelle oder ein Backup lesen kann, kann Links bis zum Ablauf einlösen. Der reguläre Erstzugang erfolgt über den Passwortlink.
- **Kontopflege:** Administrator und Safety Manager (im Zuständigkeitsbereich) ändern den Namen und bei Better Auth die E-Mail-Adresse und löschen Konten ohne vorherige Sperrung (#114). Bei Clerk bleibt die E-Mail-Änderung dem Benutzerprofil des Anbieters vorbehalten; die Löschung ist beim Anbieter nicht umkehrbar. Die Löschung ist bei Clerk nicht atomar (Anbieter, dann Datenbank); ein Teilfehler hinterlässt eine verwaiste Rolle („Konto fehlt“), die sich bereinigen lässt. Historische Datensätze und Audit-Einträge behalten die Kennung; Backups enthalten gelöschte Konten. Eine Kontosperre gibt es nicht.
- **Upload-Sicherheit:** Erlaubte Dateitypen, Größenlimit (4 MiB) und ein
  Löschkonzept sind definiert und umgesetzt. **Offen bleibt allein die
  Malware-/Virenprüfung** — hochgeladene Dateien werden nicht auf Schadcode
  untersucht. Als organisatorische Ersatzmaßnahme trägt jedes Upload-Formular
  einen Sicherheitshinweis (`UPLOAD_MALWARE_NOTICE` in
  `lib/constants/upload-safety.ts`), der zum Hochladen ausschließlich Dateien
  bekannter Herkunft auffordert und externe Dateien einer Prüfung vor dem
  Hochladen unterwirft. Das ersetzt keine technische Prüfung. Die Auslieferung setzt durchgängig `X-Content-Type-Options:
  nosniff`; nur Bilder (JPEG/PNG/WebP) und MP4 werden inline ausgeliefert, alles
  übrige als Download. SVG steht bewusst nicht auf der Positivliste.
- **Größenlimit ist plattformbedingt:** 4 MiB ergeben sich aus dem
  Request-Limit von Vercel (4,5 MB, infrastrukturseitig nicht änderbar), nicht
  aus einer fachlichen Überlegung. Größere Uploads würden die Anwendung gar
  nicht erreichen. Reicht das nicht aus, wäre ein direkter Browser-zu-Speicher-
  Upload nötig; das ist bewusst zurückgestellt, weil es die provider-neutrale
  Storage-Abstraktion aufbrechen und einen Produktionspfad ohne automatisierte
  Testabdeckung schaffen würde.
- **Attachment-Backup:** Das Backup umfasst ausschließlich die Datenbank.
  Dateibytes aus Vercel Blob oder dem lokalen Speicher sind **nicht** enthalten
  (`attachmentsIncluded: false`). Nach einem Restore fehlen die Dateien,
  während die Datenbankzeilen auf sie verweisen. Siehe
  [`backup-restore.md`](backup-restore.md).
- **Rate-Limit öffentlicher Anhänge:** Die öffentliche Auslieferung ist auf
  300 Abrufe je Client und Stunde begrenzt (konfigurierbar über
  `PUBLIC_ATTACHMENT_RATE_LIMIT_MAX`). Der Wert ist ein Startwert ohne
  Betriebserfahrung und im laufenden Betrieb zu beobachten — insbesondere bei
  Videos, die bis zu 4 MiB je Abruf erzeugen und wegen `Cache-Control:
  no-store` bei jeder Ansicht neu übertragen werden. Docker-Nginx und die
  native Ubuntu-Anleitung begrenzen zusätzlich auf 60 Requests je IP/Minute
  mit Burst 20 (GET und HEAD, getrennte Zone vom Meldeformular). Der App-Limiter
  erlaubt bei fehlendem Salt/IP oder Zählfehlern weiter Downloads; der
  Nginx-Schutz bleibt davon unabhängig. Auf Vercel gilt diese Nginx-Schicht
  nicht. Betrieb und Grenzen: [Rate-Limit-Runbook](runbooks/public-report-rate-limit.md).
- **Video-Wiedergabe nicht garantiert:** Videos werden ohne
  HTTP-Range-Unterstützung ausgeliefert. Chrome, Edge und Firefox spielen sie
  bei dieser Dateigröße ab; **Safari verlangt Bereichsabrufe und spielt daher
  voraussichtlich nicht** — auf iOS betrifft das jeden Browser. Neben dem
  Player steht deshalb immer ein Download-Link.
- **Backup und Restore:** Verfahren, Werkzeuge und Grenzen sind definiert und
  umgesetzt — verschlüsselter Dump (`age`), Cron-Auslösung, Aufbewahrung, ein
  Restore-Ablauf und die Warnung, niemals auf der Produktivinstanz zu proben:
  [`backup-restore.md`](backup-restore.md). **Zwei Lücken bleiben:** Anhänge
  sind nicht enthalten (siehe „Attachment-Backup" oben), und eine echte
  Wiederherstellung wurde bislang **nicht** gegen eine produktionsnahe Instanz
  durchgespielt. Ein Backup, das nie zurückgespielt wurde, ist kein
  nachgewiesenes Backup.
- **Veraltete Anzeige nach Speichern in Core-/Reporter-/Klassifikations-Formularen:**
  In `app/dashboard/reports/[reportId]/workflow-form.tsx` nutzen
  `ReportCoreFormEditable`, `ReportReporterInfoFormEditable` und
  `ReportClassificationFormEditable` unkontrollierte Felder (`defaultValue`)
  kombiniert mit `router.refresh()` nach erfolgreichem Speichern. Da die
  jeweiligen Sektionen in `app/dashboard/reports/[reportId]/page.tsx` ohne
  `key`-Prop eingebunden sind, wird die Client-Komponente
  nach dem Refresh nicht neu gemountet — die Anzeige kann trotz erfolgreich
  gespeichertem Serverwert veraltet bleiben, bis die Seite komplett neu
  geladen wird. Identisches Muster wie der behobene Fall in
  `ReportWorkflowFormEditable` (dort per gezieltem `key={`${status}-${priority}`}`
  an `<ReportWorkflowForm>` behoben). Für diese drei Formulare bewusst noch
  **nicht** behoben — ein gemeinsamer `key` (z. B. über `report.updatedAt`)
  würde beim Speichern einer Sektion auch die anderen, ggf. gerade mit
  ungespeicherten Eingaben offenen Sektionen remounten und deren Entwürfe
  verwerfen. Ein sauberer Fix braucht je Sektion einen eigenen, aus ihren
  eigenen `initial*`-Werten abgeleiteten `key` (oder eine Umstellung auf
  kontrollierte Felder), unabhängig von den anderen Sektionen.
- **Migrations- und Release-Konzept:** Der vollständige SQL-Satz unter `drizzle/`
  ist aus jedem konsistenten historischen Präfix idempotent und ohne Datenverlust
  anwendbar. `scripts/migrate.psql` führt ihn per psql atomar aus; CI prüft bei
  SQL-Änderungen die Präfixmatrix auf PostgreSQL. Betreiber führen ihn nach Backup und Freigabe im
  Wartungsfenster aus, nicht automatisch beim Containerstart. Etwaige
  experimentelle AI-Tabellen bleiben unverändert und benötigen eine eigene
  Datenschutz-/Backup-Prüfung; es wird kein Archivschema angelegt. Siehe [Migrationsverfahren](database-migrations.md).
- **Datenaufbewahrung und Löschung — „Datenschutzprüfung Stufe 1":** Die
  periodische Prüfung abgeschlossener/ausgeblendeter Meldungen auf
  verbliebenen Personenbezug ist als zweistufiger, manuell ausgelöster
  Ablauf umgesetzt (Fristanker `reports.retentionReviewEligibleAt`,
  organisationsbezogen konfigurierbares Prüfintervall, Erinnerungs-Kachel/
  -Filter im Dashboard, Prüfprotokoll `reportRetentionReviews`; Migrationen
  `0026`/`0027`, siehe [`docs/database-migrations.md`](database-migrations.md)):
  1. **Personenbezogene Melderdaten entfernen** (nur falls Name/Rolle/Kontakt
     in den dafür vorgesehenen Feldern eingetragen sind; entfernt nur diese
     strukturierten Felder, Freitexte/Notizen/Anhänge bleiben unverändert).
  2. **Datenschutzprüfung abschließen** — verbleibende Inhalte (insbesondere
     Freitexte, Notizen, Anhänge) prüfen und Ergebnis dokumentieren.

  Sichtbare, auswählbare Entscheidungen: „Keine personenbezogenen Daten
  vorhanden", „Vollständig anonymisiert" (erfordert eine explizite Bestätigung
  per Checkliste plus Prüfvermerk, bevor `anonymizationStatus` auf
  `completed` gesetzt wird) und „Prüfung zurückstellen" (Datum muss in der
  Zukunft liegen, serverseitig validiert). Das Entscheidungsfeld startet
  neutral („Bitte Entscheidung auswählen …") und ist nicht speicherbar, solange
  keine echte Entscheidung gewählt ist. „Gelöscht" ist bewusst **keine**
  auswählbare Option mehr (vermischte Papierkorb-/Lösch-Workflow mit der
  Datenschutzprüfung) — historische `deleted`-Einträge bleiben aber weiterhin
  korrekt lesbar. Löschung/Papierkorb (`softDeleteReport`/`hardDeleteReport`)
  bleibt ein separater, unveränderter Workflow und kein reguläres Ergebnis der
  Datenschutzprüfung selbst.

  Neue/geänderte Freitexte, Notizen, Anhänge oder inhaltliche
  Maßnahmenänderungen setzen einen bereits als `completed` bestätigten
  Prüfstatus automatisch zurück auf `needs_review` (rein strukturierte oder
  workflowbezogene Änderungen lösen bewusst keinen Reset aus); ein Report mit
  `needs_review` erscheint dadurch automatisch wieder im Dashboard-Zähler und
  im Listenfilter `?retention=due`.

  PAOLO gibt weiterhin **keine** konkrete Frist vor — diese bleibt eine
  organisatorische/rechtliche Entscheidung des jeweiligen Betreibers (siehe
  Issue #16 und `docs/data-protection-concept.md`). Offen: Rückwirkende
  Bereinigung historischer Audit-Log-Klartextreste über
  `scripts/redact-anonymized-report-audit-logs.ts` (implementiert, noch nicht
  gegen eine reale Datenbank ausgeführt).
- **Installierbares Betreiber-Modell / Rechtstexte:** PAOLO soll auch von Vereinen und Flugschulen selbst installiert und betrieben werden können. Verantwortlicher nach DSGVO ist voraussichtlich der jeweilige Betreiber der Instanz, nicht der Softwareautor. Die dafür nötige Konfiguration (`/dashboard/admin/legal` → Rechtliche Angaben) und die öffentlichen Seiten `/impressum`/`/datenschutz` sind umgesetzt und nicht fest im Code verdrahtet; die **Inhalte** bleiben installationsspezifisch zu pflegen und vor Produktivbetrieb rechtlich zu prüfen (siehe `docs/data-protection-concept.md`, Abschnitte 17–23).
- **Datenschutzprozesse sichtbar, aber manuell:** Betroffenenanfragen-Suche, Anonymisierung strukturierter Melderdaten nach Abschluss und Incident-Response-Dokumentation sind unter `/dashboard/privacy` als Werkzeuge und Checklisten hinterlegt. Es gibt bewusst keine automatische Löschung und keine automatische Freitext-Anonymisierung; die rechtliche Bewertung liegt beim Betreiber (Betriebssicht: `docs/privacy-operations.md`).
- **DB-Constraints:** Der Unique-Constraint für globale Rollen pro Benutzer wird im Code erzwungen (DELETE + INSERT). Ein zusätzlicher Datenbank-Constraint wäre robuster.

---

## Maßnahmen vor Inbetriebnahme

Die offenen Punkte verteilen sich auf zwei Verantwortungsbereiche, die getrennt
gehören:

- **PAOLO** — Projekt-, Entwicklungs-, Test- und Dokumentationsarbeiten, die vor
  einer Pilotfreigabe auf Projektseite abgeschlossen sein müssen. Erst danach
  ist die Software einem Betreiber übergebbar.
- **Betreiber** — organisatorische, rechtliche und betriebliche Voraussetzungen
  der Flugschule beziehungsweise des Vereins. PAOLO stellt die Werkzeuge, kann
  die Entscheidungen und Nachweise aber nicht abnehmen.

Innerhalb beider Bereiche sind einige Punkte **variantenabhängig**: Sie fallen
nur auf bestimmten Betriebswegen an und entfallen sonst ersatzlos. Was erst vor
breiter Produktivnutzung zählt, steht darunter.

### PAOLO — vor Pilotfreigabe

- **Next.js auf eine nicht betroffene Version heben — erledigt (26.10.2026).**
  Der Sicherheits-Vorabcheck vom 04.09.2026 und ein erneuter `npm audit` haben
  Advisories gefunden, die genau die Mechanismen treffen, auf denen PAOLO aufsetzt
  (Server Actions, Image Optimization, `use cache`). Zuletzt zwei kritische
  Schwachstellen (Remote Code Execution) in 16.0.0–16.4.0. Die Anwendung steht auf
  Next.js 16.4.3; `npm audit` meldet keine kritischen und keine hohen Befunde mehr
  (vier moderate in der Entwicklungswerkzeug-Kette `drizzle-kit`). Bei jedem
  künftigen Framework-Wechsel gehören Lint, Typen, Node-Suiten, Build und beide
  E2E-Provider dazu.
- **Restore-Verfahren nachweisen und Anhangssicherung beschreiben — erledigt
  (26.10.2026).** [`backup-restore.md`](backup-restore.md) beschreibt die vollständige
  Sicherung (Datenbank, Anhänge, Konfiguration) und die Wiederherstellung. Der
  Nachweis mit repräsentativen Daten und Anhängen läuft gegen ein aus dem Paket
  gebautes Image und auf einem Linux-Betreiberhost; er deckte mehrere Fehler auf, die
  behoben sind (siehe dort, „Nachgewiesener Stand“). Nicht erprobt: sehr große
  Datenmengen, Anhänge in Vercel Blob, der Weg über Clerk.

Variantenabhängig, je nach Zuschnitt des Piloten:

- **BetterAuth Passwort Wechsel:** Better Auth kennt keinen erzwungenen
  Passwortwechsel nach der ersten Anmeldung. Ein vergessenes Passwort lässt sich
  über „Anmeldelink erneuern“ zurücksetzen (#111); einen Self-Service-Wechsel
  gibt es weiterhin nicht.
  
- **Bei Vercel-Betrieb: Sicherheitsheader** — erledigt mit Issue #107. Auf
  Vercel setzt die Anwendung `X-Content-Type-Options`, `Referrer-Policy`,
  `Permissions-Policy` und `X-Frame-Options` mit denselben Werten wie die
  Nginx-Vorlage (`next.config.ts`, Werte in `lib/security-headers.ts`, nur bei
  `VERCEL=1`). HSTS liefert Vercel selbst, strenger als die Vorlage
  (`max-age=63072000; includeSubDomains; preload`). Im Docker-Pfad bleiben die
  Header Sache der Nginx-Vorlage und greifen nach deren Aktivierung; die
  Anwendung setzt sie dort nicht, damit sie nicht doppelt ankommen.
  `tests/security/security-headers.test.ts` hält beide Pfade gleich. Eine
  Content-Security-Policy setzt keiner der beiden Pfade.

### Betreiber — vor Inbetriebnahme

- **Verantwortlichen benennen und Rechtsgrundlage festlegen** (Issue #16, A1
  und B1). Ohne Verantwortlichen nach Art. 4 Nr. 7 kann niemand eine
  Betroffenenanfrage beantworten oder gegenüber einer Aufsichtsbehörde
  einstehen; ohne Rechtsgrundlage nach Art. 6 fehlt der Verarbeitung die Basis.
  Meldungen aus dem Flugbetrieb sind Echtdaten ab der ersten Minute. Abschnitt
  16 des [Datenschutzkonzepts](data-protection-concept.md) nennt die Benennung
  selbst als Mindestanforderung; PAOLO leistet keine Rechtsberatung.
- **Impressum und Datenschutzerklärung befüllen und rechtlich prüfen lassen.**
  Eingabe unter `/dashboard/admin/legal`, Ausgabe unter `/impressum` und
  `/datenschutz`, fehlende Felder erscheinen als „noch nicht hinterlegt“. Der
  vorhandene Stand ist als `NEEDS REVIEW` / Pilot-Blocker abgenommen
  (`mvp-test-results.md`, 15.1.7). Es ist der einzige Punkt, den die meldende
  Person selbst zu sehen bekommt.
- **Datenschutz-Einwilligung im Meldeformular prüfen.** Sie ist ab Migration
  `0034` voreingestellt eingeschaltet, auch in bestehenden Installationen:
  Nach dem Update kann eine Meldung erst nach Zustimmung abgesendet werden.
  Unter `/dashboard/privacy` entscheiden, ob die Abfrage zur eigenen
  Rechtsgrundlage passt (Issue #16), und den Text bei Bedarf anpassen und
  prüfen lassen. Siehe [Datenschutzkonzept](data-protection-concept.md),
  Abschnitt 11b.
- **Restore der eigenen Installation proben.** Dass das Verfahren grundsätzlich
  trägt, weist PAOLO nach; dass es in *dieser* Installation trägt — mit diesen
  Schlüsseln, diesem Speicher, diesem Volumen — kann nur der Betreiber zeigen.
  Auf einer Testinstanz proben, niemals auf der Produktivinstanz.
- **Anhänge in die eigene Sicherung aufnehmen.** Das Backup umfasst nur die
  Datenbank (`attachmentsIncluded: false`). Beim Docker-Pfad mit lokalem
  Dateispeicher ein `tar` des Speicherverzeichnisses neben dem bestehenden
  Backup-Cron — kein Entwicklungsaufwand, aber jemand muss es einrichten.
- **Production-Check in der Zielumgebung** (`mvp-test-results.md`, Block 13):
  Restricted Mode aktiv, Umgebungsvariablen vollständig, Auth-Schlüssel der
  richtigen Umgebung, Storage erreichbar, HTTPS ohne Mixed Content und keine
  internen Fehlerdetails nach außen. Eine Stunde Durchgehen, aber in der echten
  Umgebung.

Variantenabhängig, je nach Betriebsweg:

- **Bei externen Dienstleistern** (Clerk, Neon, Vercel Blob): AVV nach Art. 28
  und Drittlandfrage nach Art. 44 ff. Der Docker-Pfad mit Better Auth, eigenem
  PostgreSQL und lokalem Dateispeicher kommt außer dem Hoster ohne
  Auftragsverarbeiter aus.
- **Nach einer Kennenlernphase mit Spieldaten (nur docker, VMS Betrieb):** Bereinigung vor dem
  Echtbetrieb. Eine frisch initialisierte Instanz ist bereits leer — der
  Bootstrap schreibt ausschließlich Organisation, Rollen, Zuweisungen,
  Auth-Konten und Audit-Log.

### Vor breiter Produktivnutzung

Ohne Zuordnung heißt: PAOLO.

- Organisations-Scoping konsequent prüfen und umsetzen, bevor mehrere
  Organisationen das System nutzen.
- Vollständiges Sicherheitsassessment nach
  `security/assessment-plan.md` (interne Sicherheitsunterlage, nicht im Quellpaket): OWASP-Prüfung
  gegen Staging, Supply-Chain und SBOM, Host- und Container-Härtung, dazu die
  Anlage von Bedrohungsmodell, Befundregister und Maßnahmenlog. Das eigene
  Better-Auth-Profil muss vor jeder produktiven Better-Auth-Nutzung bestehen.
- Vollständiger E2E-Lauf mit beiden Auth-Providern und die bislang ausstehende
  Sichtprüfung auf der Referenzinstallation (`mvp-test-results.md`, 18.9).
- Vor einer Öffentlichschaltung des Repositories: Klarnamen aus
  `scripts/cleanup-test-data-before-production.ts` entfernen. Die
  Historienprüfung selbst ist erledigt (Vorabcheck 04.09.2026, keine Secrets in
  471 Commits); übrig bleiben vier Clerk-Benutzer-IDs mit Klarnamen im
  Kommentar — keine Secrets, aber personenbezogen. Auch
  `development-log.md` und `mvp-test-results.md` nennen Personen und
  Betriebsdetails; das ist eine Entscheidung, keine Lücke.
- `docker-compose.yml` bindet den lokalen Staging-App-Port ausschließlich an
  `127.0.0.1:3000`; das Produktions-Overlay hebt ihn mit `ports: !reset []`
  vollständig auf. Ein Basis-Compose-Lauf ist damit nicht über LAN oder
  Internet erreichbar und der Produktionsweg bleibt allein bei Nginx.
- `shadcn` von `dependencies` nach `devDependencies` verschieben. Das
  Scaffolding-CLI zieht `@modelcontextprotocol/sdk` und darüber express, hono,
  qs und undici in jeden `npm ci`; vier der gemeldeten Advisories stammen aus
  diesem Ast. Die Laufzeit erreicht es nicht — der standalone-Build nimmt nur
  importierten Code auf.
- Virenprüfung für hochgeladene Dateien vorsehen. Erlaubte Dateitypen und
  Größenlimit sind definiert und umgesetzt; die Malware-Prüfung fehlt noch.
- **Betreiber:** Speicherdauer und Löschfristen festlegen (Issue #16, B2 und
  B3). PAOLO löscht nichts automatisch, deshalb kein Pilot-Blocker — zwei
  Antworten können aber Entwicklungsarbeit auslösen: die Wartefrist zwischen
  `closed` und Anonymisierung und die Audit-Log-Aufbewahrung bei Löschung.
- **Betreiber:** Migrations- und Restore-Verfahren vor echten Betriebsdaten
  erproben, sobald das erste Update ansteht.
- Einladungsverfahren verbessern: Statusverfolgung für offene Einladungen,
  automatischer Versand, erzwungener Passwortwechsel bei Better Auth.
- Middleware-/Route-Schutz auf Ebene der Next.js-Middleware ergänzen.
- Historische Audit-Log-Klartextreste bereits anonymisierter Reports per
  `scripts/redact-anonymized-report-audit-logs.ts` bereinigen. Betrifft nur
  Bestandsdaten; eine frische Installation hat keine.
- Nebenläufiges Speichern absichern: Zwei Bearbeiter überschreiben einander
  ohne Hinweis, der spätere Vorgang gewinnt.
- Veraltete Anzeige nach dem Speichern in Core-, Melder- und
  Klassifikationsformular beheben (siehe „Bekannte Einschränkungen“).
- Monitoring und Logging für den laufenden Betrieb prüfen (Fehlertracking,
  Performance).
- Exportstrategie erweitern, falls Maßnahmen oder Sicherheitsbesprechungen
  separat exportiert werden sollen.

### Später

- Mehrorganisationenbetrieb vollständig umsetzen.
- Systemstatus-Seite über den vorhandenen Health-Endpunkt `/api/health` hinaus
  (Verfügbarkeitshistorie, Abhängigkeiten, sichtbarer Betriebsstatus).
- Erweiterte Nutzerhilfe über die vorhandene rollenbezogene In-App-Hilfe unter
  `/dashboard/hilfe` hinaus (etwa Suche oder kontextbezogene Einstiege).
- Nutzeransicht für Meldende/Beteiligte (`member`-Rolle aktivieren): eigene Meldungen vervollständigen, eigene Anhänge hochladen, ggf. freigegebene Meldungen einsehen. Erfordert eigene reduzierte Ansicht und Anpassung der Seitenguards.

---

## Betriebsnotizen

- GitHub-Kollaborateure und PAOLO-SMS-Benutzer sind getrennte Systeme; GitHub-Zugriff ergibt keinen Anwendungszugriff.
- Secrets (Datenbankzugang, API-Keys, Tokens) gehören nicht ins Repository — ausschließlich in `.env.local` (lokal) oder Vercel-Umgebungsvariablen (Produktion).
- Umgebungsvariablen müssen je Environment (Development, Preview, Production) gepflegt werden.
- Vor größeren Schemaänderungen Datenbank-Backup erstellen.
- Test- und Produktivdaten nicht vermischen.

---

## Fazit

Die Software ist für den kontrollierten MVP-/Pilotbetrieb mit einer bekannten
Benutzergruppe geeignet. **Freigebbar und betriebsbereit ist sie damit noch
nicht**, und die beiden Fragen sind verschieden: Vor einer Pilotfreigabe sind
die Punkte unter „PAOLO — vor Pilotfreigabe" abzuschließen; vor der ersten
echten Meldung kommen die Voraussetzungen unter „Betreiber — vor
Inbetriebnahme" hinzu, die das Projekt nicht abnehmen kann.

Für eine breitere Nutzung, mehrere Organisationen oder einen offenen Betrieb
kommen die Härtungsschritte darüber hinaus hinzu. Dieses Dokument ist eine
Arbeitsgrundlage und wird mit dem Fortschritt des Projekts aktualisiert.
