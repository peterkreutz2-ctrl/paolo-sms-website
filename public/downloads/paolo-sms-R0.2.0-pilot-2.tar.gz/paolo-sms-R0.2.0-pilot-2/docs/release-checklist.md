# Release-Checkliste für Datenbankschemaänderungen

> Lebendes Dokument — bei jedem Release, der neue Erkenntnisse liefert,
> weiterzuentwickeln (siehe "Lessons Learned" am Ende).

Diese Checkliste gilt für **jedes Release, das eine neue Migration unter
`drizzle/*.sql` und/oder eine Änderung an `lib/db/schema.ts` enthält.** Sie
ist bewusst allgemein gehalten — nicht spezifisch für eine einzelne
Migration — und als wiederverwendbares Vorlagen-Dokument gedacht: pro
Release kopieren (oder als Kommentar in den zugehörigen PR/Issue
einfügen), ausfüllen und abhaken.

Sie ersetzt nicht die ausführlichen Verfahrensbeschreibungen in
[`docs/database-migrations.md`](database-migrations.md) und
[`docs/backup-restore.md`](backup-restore.md) — diese bleiben die
maßgeblichen Referenzen für das *Wie*. Diese Checkliste stellt sicher,
dass **kein Schritt vergessen wird** und dokumentiert, *dass* und *wann*
er ausgeführt wurde.

Diese Datei ist die **Release-Owner-Checkliste für Vorbereitung und Freigabe**.
Die konkrete, befehlsorientierte Ausführung eines freigegebenen Updates auf
einer Docker-Produktionsinstallation steht getrennt im Operator-Runbook
[`runbooks/production-docker-update.md`](runbooks/production-docker-update.md).

---

## Release-Metadaten (pro Release ausfüllen)

- Migration(en): `drizzle/00XX_*.sql`
- Schema-Änderung(en) in `lib/db/schema.ts`: kurz benennen
- Verantwortlich für diesen Release-Durchlauf: ______
- Datum: ______

---

## 1. Vorbereitung — betroffene Datenbankziele identifizieren

- [ ] Alle für dieses Projekt real existierenden Datenbankziele durchgehen
      und je Ziel **aktiv/inaktiv** sowie **betroffen/nicht betroffen**
      vermerken. Bekannte Ziele (Stand dieses Dokuments — bei neuen Zielen
      ergänzen):
  - [ ] **Neon Production** (backing `paolo-sms.vercel.app`)
  - [ ] **Vercel Preview** — vorab klären, ob Preview denselben
        Neon-`neondb` nutzt oder einen eigenen Neon-Branch (Vercel
        Project Settings → Environment Variables; Neon-Dashboard →
        Branches). Nicht aus dem Repository allein feststellbar.
  - [ ] **Lokale/Docker-PostgreSQL** je Entwickler/Operator (`.env.docker.local`,
        Compose-Service `db`) — nur relevant, wenn dort produktiv-nahe
        oder sonst relevante Daten liegen.
  - [ ] **Selbst betriebene Instanzen weiterer Betreiber** (Vereine,
        Flugschulen, Release-Übungsumgebungen wie die EC2-Instanz) — je
        nach Betriebsstatus einzeln vermerken, siehe Abschnitt 7.
  - [ ] **E2E-Testdatenbank** — nur relevant, falls ein persistentes
        `.env.e2e.local` existiert (sonst wird bei jedem Testlauf ohnehin
        neu geseedet, keine manuelle Migration nötig).
- [ ] Vollständiger SQL-Satz auf Idempotenz und Datenerhalt aus jedem früheren
      konsistenten Präfix geprüft. Nötige Backfills erfolgen vor neuen Constraints;
      keine Datenlöschung im Replay-Pfad. Etwaige Altbestände ausdrücklich prüfen.
- [ ] `scripts/migrate.psql` enthält alle Dateien in Reihenfolge. Historische
      Replay-Korrekturen sind mitgeprüft; keine Nummer entfernt/neu vergeben.

## 2. Backup-/Wiederherstellungsmöglichkeit sicherstellen

- [ ] Für **jedes** betroffene, produktiv oder sonst relevante Ziel **vor**
      der Migration eine Wiederherstellungsmöglichkeit sichergestellt:
  - Neon: Branch/Snapshot **oder** bewusst akzeptiertes "Restore from
    history"-Fenster — Referenzzeitpunkt **vor** der Migration notieren:
    ______
  - Docker/self-hosted: `pg_dump`/PAOLO-Backup-Feature **oder** bei
    geringem Risiko (z. B. leere/experimentelle Dev-DB) bewusster Verzicht,
    mit kurzer Begründung: ______
- [ ] Werkzeuge für den gewählten Weg tatsächlich verfügbar geprüft (z. B.
  `neonctl`/API-Key, `pg_dump`, `age`-Binary + `BACKUP_AGE_RECIPIENTS`,
  Docker-Daemon läuft) — **bevor** mit der Migration begonnen wird, nicht
  erst währenddessen.
- [ ] Wer die Wiederherstellungsoption akzeptiert/freigegeben hat, ist
  dokumentiert (Name, Zeitpunkt).

## 3. Migration zuerst risikoarm testen

- [ ] `npm run test:node` und `npm run test:migrations` erfolgreich: alle
      ursprünglichen und überarbeiteten Präfixe mit befüllten Tabellen, zwei
      Voll-Läufen, Feld-/Schema-Vergleich und psql-Rollback-Test. Neue Tabellen
      und Datenüberführungen sind in Fixtures/Assertions abgedeckt.

- [ ] Bei Docker-Releases das gebaute App-Image mit
      `node tests/migrations/replay.mjs --app-image <gebautes-app-image>` geprüft:
      enthaltene SQL-Dateien/Einstiege entsprechen dem Checkout, Neuinstallation
      und befülltes Upgrade/Replay funktionieren ohne Source-Mount als Nicht-root.
      Auch bei reinen Image-/Shell-Änderungen lokal ausführen; der DB-CI-Check
      bleibt bewusst auf Änderungen an `drizzle/*.sql` beschränkt.

- [ ] Bei größeren Datenmengen zusätzlich Laufzeit, Sperren und Backfills auf
  einem autorisierten Staging-/Backup-Klon erprobt. Die synthetische Präfixmatrix
  ersetzt keine Prüfung installationsspezifischer Drift oder Datenmengen.
- [ ] PostgreSQL-Version, Ergebnis und Betriebsfolgen dokumentiert. Ein fehlender
  echter DB-Test ist kein bestandener Migrationsnachweis; vor Freigabe nachholen.

## 4. Migration in sinnvoller Reihenfolge anwenden

Empfohlene Standardreihenfolge (Abweichungen begründen):

1. [ ] Nicht-produktives Ziel (siehe Abschnitt 3)
2. [ ] Neon Production
3. [ ] Weitere aktive, produktiv genutzte Self-Hosting-Ziele (falls
   vorhanden)
4. [ ] Vercel Preview, falls eigener Neon-Branch (sonst mit Schritt 2
   bereits erledigt)

Je Ziel: Ziel-Datenbank **unmittelbar vor** Ausführung eindeutig verifizieren
(z. B. `current_database()`/Hostname prüfen, keine Secrets ausgeben), dann
**den gesamten geprüften Satz** über `psql -X -d <Ziel> -f
scripts/migrate.psql` anwenden. Kein `drizzle-kit generate`/`migrate`/`push`
(siehe `docs/database-migrations.md`).

## 5. Migration je Ziel verifizieren

Je Ziel, direkt nach Anwendung:

- [ ] Neue Spalte(n)/Tabelle(n) vorhanden — Name, Typ, Nullability geprüft
  (`information_schema.columns`).
- [ ] Zeilenzahlen und repräsentative Feldwerte erhalten; erlaubte
  Datenüberführungen explizit bestätigt. Zeilenzahlen allein beweisen keinen
  Datenerhalt. Etwaige experimentelle Altbestände in Prüfung und Full-pg_dump einbeziehen.
- [ ] Bei mehreren Statements: jedes einzeln bestätigt ausgeführt (nicht
  nur "Skript ohne Fehler beendet" — siehe Lessons Learned unten).

## 6. Commit / Push / Deployment

- [ ] Branch und Pull Request für Migrationsänderungen erstellt; CI und Preview
  geprüft. Migration auf jedem ausdrücklich autorisierten Ziel angewandt und
  verifiziert, bevor dort der neue Anwendungscode aktiviert wird.
- [ ] Nur die tatsächlich beabsichtigten Dateien gestaged (kein `git add -A`),
  `git status` vor dem Commit geprüft.
- [ ] Commit erstellt, `git status`/`git log` nach dem Commit verifiziert.
- [ ] Vor dem Push Divergenz des Feature-Branches prüfen; nur diesen Branch
  pushen. Konflikte vor dem Review klären, nicht direkt nach `main` pushen.
- [ ] Nach dem Push den Feature-Branch verifiziert; Merge nach `main` erst nach
  Review und vollständiger E2E-Suite gemäß `AGENTS.md`.
- [ ] Deployment-Bestätigung eingeholt (z. B. Vercel-Production-Deploy
  erfolgreich, `/api/health` erreichbar).
- [ ] **Prüffrage:** Sind Code und Datenbankschema nach Abschluss des
  Rollouts auf allen relevanten Zielsystemen synchron?

## 7. Nachkontrolle der neuen Funktion

- [ ] Nach erfolgreichem Deployment: die **fachliche Funktion**, die die
  Schemaänderung trägt, in der jeweiligen Umgebung tatsächlich ausgelöst
  und geprüft (nicht nur Schema-Check) — z. B. eine Testmeldung durch den
  entsprechenden Workflow-Schritt laufen lassen und das erwartete Verhalten
  bestätigen.
- [ ] `npm run test:node`, `npm run test:migrations`, vollständige E2E-Suite,
  `tsc --noEmit` und `eslint` erfolgreich; nur dedizierte Testdatenbanken verwenden.

## 8. Kommunikation mit weiteren Betreibern

- [ ] Falls andere, nicht selbst kontrollierte Installationen existieren
  (Self-Hosting bei Vereinen/Flugschulen, Übungs-/Release-Umgebungen wie
  die EC2-Instanz): Hinweis vorbereitet/versendet, dass eine neue Migration
  vorliegt und **manuell** eingespielt werden muss (kein automatischer
  Rollout) — mit Verweis auf `docs/database-migrations.md` und die
  Änderungen und den vollständigen psql-Einstieg des Releases.
- [ ] Für aktuell inaktive/nicht laufende Übungsziele (z. B. EC2, laut
  Planung als künftige "Release Migration"-Übung vorgesehen): keine
  sofortige Aktion nötig, aber als offener Punkt für die nächste Aktivierung
  vermerkt.

## 9. Abschluss-Dokumentation

- [ ] Eintrag in `docs/development-log.md` (neuester Eintrag oben, siehe
  `AGENTS.md`) mit: welche Migration, welche Ziele, wer, wann, Ergebnis.
- [ ] Diese Checkliste (ausgefüllt) im zugehörigen PR/Issue verlinkt oder
  angehängt, falls für dieses Release ein PR/Issue existiert.

---

## 10. Paketfreigabe (Quellpaket)

Gilt zusätzlich, bevor ein Quellpaket weitergegeben oder veröffentlicht wird
(Beschreibung: [`release-package.md`](release-package.md)).

- [ ] Die drei Versionsstellen stimmen überein. Der Release-Tag heißt `R<version>`
      und zeigt auf den ausgewählten Commit in der Historie von `main`.
- [ ] Das Paket wird mit `npm run release:build` aus diesem **getaggten Commit**
      gebaut; Commit und Tag sind in `RELEASE.json` und in der Freigabe vermerkt.
- [ ] `npm run release:draft` hat die geprüften Dateien in einen privaten
      GitHub-Release-Entwurf hochgeladen. Veröffentlichung erfolgt ausdrücklich
      über GitHub oder `gh`; die öffentliche Website wird zunächst separat gepflegt.
- [ ] Für weitere Änderungen auf `main` ist eine neue, noch nicht getaggte Version
      vorbereitet, etwa die nächste Patch-Version mit `-ib`. Die CI-Prüfung zur
      Versionsbindung darf nicht rot übergangen werden.
- [ ] `npm run test:node`, Lint, Typen und Build sind grün; die E2E-Suite lief mit
      Better Auth und mit Clerk (isolierte Wiederholungen vermerkt).
- [ ] **Paketinhalt:** `scripts/release/package-files.txt` entspricht dem Paket; die
      Diff `--since <früherer-Stand>` wurde durchgesehen, jede neue Datei darf
      ausgeliefert werden. Keine internen Sicherheits- oder Entwicklungsunterlagen,
      keine Zugangsdaten.
- [ ] **Schwachstellen:** `npm audit` ohne kritische und hohe Befunde in
      Produktionsabhängigkeiten; Image-Scan (zum Beispiel Grype) ohne kritische
      Befunde in Anwendung und Systempaketen; verbleibende Befunde bewertet
      (Maßnahmenlog `security/measures-log.md`, Entscheidungen nur durch Menschen).
- [ ] **Lizenz und Markenhinweise:** `npm run licenses:check` grün; `LICENSE`,
      `NOTICE`, `BRAND-USAGE.md`, `THIRD-PARTY-LIST.md` und
      `THIRD-PARTY-NOTICES.md` im Paket und die vier erstgenannten Hinweise im
      Docker-Image.
- [ ] **Betrieb:** Installation, Update, Sicherung und Wiederherstellung wurden mit
      genau diesem Paket (und, wo nötig, einem Vorgängerpaket) erprobt; nicht erprobte
      Teile stehen in den Release-Notes.
- [ ] **Release-Notes** nennen Schemaänderungen und die Kompatibilität für
      Rücknahmen.
- [ ] Prüfsumme (SHA-256) wird **getrennt vom Archiv** veröffentlicht; nach dem
      Upload wurde die veröffentlichte Datei heruntergeladen und gegen das geprüfte
      Paket verglichen.
- [ ] Vorabversionen sind als „Vorabversion – nicht für den Produktivbetrieb
      freigegeben“ gekennzeichnet (`VORABVERSION.md`, `RELEASE.json`, Download-Seite).

## Rollback-Verfahren

- Anwendungscode bevorzugt zurückrollen und additive Spalten mit Daten behalten.
  `DROP COLUMN` ist kein regulärer Rollback-Schritt: es würde neue Daten löschen.
- Für nicht-additive/destruktive Migrationen: Rollback-Weg **vor** der
  Migration festlegen (nicht erst im Fehlerfall improvisieren) — z. B.
  Restore aus dem in Abschnitt 2 gesicherten Snapshot/Backup.
- Wer den Rollback im Zweifel auslösen darf und wie er informiert wird,
  vorab klären, wenn der Release außerhalb üblicher Arbeitszeiten erfolgt.

---

## Lessons Learned (bei Bedarf ergänzen)

- Ein Skript, das eine Migrationsdatei automatisiert in Einzelstatements
  zerlegt (z. B. per Kommentar-/Breakpoint-Parsing), kann bei
  mehrzeiligen Kommentarblöcken einzelne Statements versehentlich
  verwerfen. Bekanntes, sichereres Vorgehen: Statements einzeln und
  wörtlich ausführen, jedes Einzelergebnis prüfen, statt sich auf
  "Skript ohne Fehler beendet" zu verlassen.
- Vor Beginn der Backup-Vorbereitung (Abschnitt 2) prüfen, ob die
  benötigten Werkzeuge in der ausführenden Umgebung überhaupt verfügbar
  sind (`neonctl`, `psql`, `pg_dump`, `age`, laufender Docker-Daemon) —
  sonst rechtzeitig vorher klären statt erst mitten im Ablauf festzustellen.
- Vor jeder Migration alle tatsächlich betroffenen Datenbankziele
  identifizieren und Verantwortlichkeiten klären.

---

*Feedback und Ergänzungen willkommen — dieses Dokument soll mit jedem
Release, der neue Erkenntnisse liefert, weiterentwickelt werden.*
