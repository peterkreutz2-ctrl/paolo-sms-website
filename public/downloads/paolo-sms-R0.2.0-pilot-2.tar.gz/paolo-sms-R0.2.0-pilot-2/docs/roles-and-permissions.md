# Rollen und Berechtigungen

## Zweck

Dieses Dokument erklärt **warum** das Rollenmodell von PAOLO SMS so aussieht,
wie es aussieht: das Sichtbarkeitsmodell der SMS-Dokumente, die Vererbung und
Rücknahme von Anhang-Freigaben, den Zustand „Konto ohne Rolle", die Regeln der
Rollenvergabe und die Fähigkeitentabelle samt der Entscheidung aus #44. Das ist
der Teil, den man dem Code nicht ansieht.

**Wer etwas nachschlagen will, ist hier falsch.** Die drei Rollendokumente
teilen sich die Arbeit so:

| Frage | Datei |
|---|---|
| Wozu ist eine Rolle da, welche Rechte braucht sie dafür, was ist offen? | [`role-responsibilities.md`](role-responsibilities.md) |
| Wer darf welche Aktion, hinter welchem Guard, mit welchem Scope? | [`permission-matrix.md`](permission-matrix.md) |
| Warum ist es so geregelt? | dieses Dokument |

Die Navigation stellt keine Sicherheitsgrenze dar. Maßgeblich sind die
serverseitigen Guards und die Prüfungen in den Server Actions; welche das je
Stelle sind, steht vollständig in der Matrix.

---

## Einzelrolle pro Konto

Jedes Konto besitzt höchstens eine globale Rolle. Die Datenbank erzwingt dies
über `user_roles_single_global_unique`. Ein Rollenwechsel ersetzt die bisherige
Rolle atomar. Eine reguläre Aktion zum ersatzlosen Entfernen gibt es nicht.
Migration 0036 behält bei bestehenden Mehrfachzuweisungen die höchste Rolle:
Administrator, Safety Manager, Safety Assistant, Benutzer. Untergeordnete Rollen
gewähren keine zusätzlichen Fähigkeiten. Die ursprüngliche Zeile der höchsten
Rolle bleibt erhalten. Unbekannte Rollen in Mehrfachzuweisungen stoppen die
Migration zur Prüfung, statt stillschweigend verworfen zu werden.

„Rolle bereinigen“ betrifft ausschließlich fehlende Konten. Bei Clerk können
Rolleneinträge nach einer externen Kontolöschung oder einem fehlgeschlagenen
PAOLO-Bereinigungsschritt zurückbleiben. Bei Better Auth werden Konto und Rollen
regulär atomar gelöscht; verwaiste Rollen sind dort etwa nach direkten Eingriffen,
einem unvollständigen Restore oder einem Wechsel des Anmeldeverfahrens möglich.
Die Bereinigung prüft das Fehlen beim aktuell konfigurierten Anmeldedienst.

## Rollen

| Schlüssel | Bezeichnung | Beschreibung |
|---|---|---|
| `admin` | Administrator | Vollzugriff auf alle Funktionen |
| `safety_manager` | Safety Manager | Operativer Betrieb des SMS, keine Admin-exklusiven Funktionen |
| `instructor` | Safety Assistant | Lesezugriff auf Meldungen, Anhänge hochladen, eingeschränkte Rollenvergabe |
| `member` | Benutzer | Vorbereitete Rolle für spätere angemeldete Meldende/Beteiligte; aktuell kein operativer Dashboard-Zugang (siehe Hinweis unten) |

**Hinweis zur Rolle `member`:** `member` ist für angemeldete Meldende und
Beteiligte vorgesehen, die keinen vollen internen Bearbeitungszugang erhalten
sollen. Seit der Sichtbarkeitsstufe `members` (#36) hat die Rolle einen echten,
eigenen Nutzen: Auf `/communications` sieht ein angemeldetes Mitglied
zusätzlich zu den öffentlichen auch die als `members` gekennzeichneten
Dokumente und kann deren Anhänge herunterladen. Im **internen** Bereich bleibt
sie ohne Zugang — die Dashboard-Seiten sind durch `hasReportReadRole`
geschützt, das `member` ausschließt (Maßnahmen über `hasMeasureReadRole`,
Zugangs- und Rollenverwaltung über `canManageRoles`, für `member` mit derselben Wirkung).
Der Aufruf endet mit HTTP 404 und der Erklärseite aus
`app/dashboard/not-found.tsx`, inklusive Abmelde-Button.

Das geplante Zielbild — anmelden, eigene Meldungen einsehen und
vervollständigen, eigene Anhänge hochladen — ist **nicht** umgesetzt und hängt
nicht nur an einem Guard: `createReport` speichert keine Verknüpfung zum
angemeldeten Konto, ein Anker für „eigene Meldung" existiert also gar nicht.
Die offene Entscheidung dazu steht in
[`role-responsibilities.md`](role-responsibilities.md).

---

## SMS-Dokumente: Sichtbarkeitsmodell

Dokumente (`sms_documents`, inkl. der Kategorie `safety_information` /
„Sicherheitsinformationen") haben eine vierstufige Sichtbarkeit, aufsteigend
nach Offenheit:

| Stufe | Sichtbar für | Auf `/communications` |
|---|---|---|
| `confidential` | admin, safety_manager | — |
| `staff` | + instructor (angemeldet) | — |
| `members` | alle Angemeldeten **mit** zugewiesener PAOLO-Rolle | ✓ nach Anmeldung |
| `public` | + jede·r ohne Anmeldung | ✓ (exakt `public`) |

`members` ist bewusst offener als `staff`: Die Stufe adressiert die gesamte
angemeldete Mitgliedschaft, `staff` nur den internen Bearbeiterkreis. Wer
`staff` lesen darf, darf deshalb auch `members` lesen — nicht umgekehrt.

**Eine Leseregel, drei Verbraucher.** Welche `visibility`-Werte eine Rollenmenge
lesen darf, entscheidet ausschließlich `getReadableVisibilityDbValues`
(`lib/constants/sms-documents.ts`). Die Rückgabe `null` heißt „keine
Einschränkung" und gilt für `hasSafetyEditRole` — bewusst keine Aufzählung,
damit ein unbekannter Wert, der laut `normalizeVisibility` als `confidential`
gilt, diesem Kreis sichtbar bleibt. Genutzt wird die Regel von der öffentlichen
Liste (`/communications`), der internen Liste (`/dashboard/documents`) und der
Anhang-Auslieferung mit Sitzung; dupliziert ist sie nirgends.

- Erstellen/Bearbeiten/Sichtbarkeit ändern/Löschen: nur `hasSafetyEditRole`
  (admin/safety_manager). `member` hat weiterhin keinen **internen**
  Dokumentenzugriff — nur die `members`-Sicht auf `/communications`.
- Ein angemeldetes Konto **ohne** zugewiesene PAOLO-Rolle sieht exakt das, was
  ein anonymer Besucher sieht.
- `staff` und `confidential` erscheinen auf `/communications` unter keinen
  Umständen — auch nicht für admin oder safety_manager. Die Seite ist eine
  Darstellungsfläche, keine zweite Berechtigungsregel.
- Der Wechsel auf `public` ist im Formular durch eine Datenschutzwarnung und
  einen Bestätigungsdialog abgesichert; das Zurückziehen (`public → members`/
  `staff`/`confidential`) läuft über dieselbe Aktualisierungsaktion und
  entfernt das Dokument sofort aus der öffentlichen Sicht.
- Für die Kategorie `safety_meeting_minutes` ist `members` ausdrücklich
  zulässig, verlangt im Formular aber eine Kenntnisnahme: Protokolle enthalten
  häufig personenbezogene Angaben (`SMS_DOCUMENT_MEETING_MINUTES_MEMBERS_HINT`).
- **Altwert-Migration (0023):** `internal → confidential`, `published → staff`.
  Bis 0023 auf Docker **und** Neon angewandt ist, verstehen die internen
  Lesepfade die Altwerte kompatibel; die anmeldefreie Ausgabe filtert dagegen
  ausschließlich auf den exakten Wert `public`.


### Anhänge: Vererbung und Rücknahme

Anhänge haben **keine** eigene Sichtbarkeitsspalte. Es gibt zwei getrennte Tore,
als reine Funktionen nebeneinander in `lib/constants/attachment-visibility.ts`:

| Tor | Gilt für | Entscheidet anhand von |
|---|---|---|
| `canServePublicly` | anmeldefreier Abruf | `attachments.is_public` **und** exakt `visibility = 'public'` |
| `canServeToSession` | Abruf mit Sitzung | Rollen **und** `visibility` des Elterndokuments |

Die beiden Richtungen werden nie vermischt: `is_public` wird nie aus der
Dokumentsichtbarkeit abgeleitet (ein Dokument auf `public` zu heben gibt keinen
einzigen Anhang frei), und der Sitzungszugriff nie aus `is_public`.

**Die Liste auf `/communications` folgt denselben beiden Toren.** Sie zeigt je
Besucher genau das, was er auch laden kann: anonym die anmeldefrei abrufbaren,
mit Sitzung die über die geerbte Sichtbarkeit erreichbaren. Ein angemeldeter
Besucher sieht an einer öffentlichen Mitteilung deshalb auch **nicht
freigegebene** Anhänge — er durfte sie über die Sitzungsroute immer schon
laden. Genau dieser Fall trägt den Hinweis „Nicht freigegeben – nur
angemeldet", damit er nicht unter dem Öffentlich-Abzeichen missverstanden
wird. Vorher baute die Seite ihre Auswahl als eigenes SQL und war dabei enger
als die Auslieferung (Regelaudit F3).

Das Abzeichen an einem Anhang benennt vier Zustände, abgeleitet aus derselben
Quelle (`describeAttachmentReach` / `attachmentReachLabel`):

| Zustand | Abzeichen |
|---|---|
| freigegeben, Dokument `public` | „Öffentlich abrufbar" |
| freigegeben, Dokument nicht `public` | „Freigegeben – noch nicht öffentlich" |
| nicht freigegeben, Dokument `public` | „Nicht freigegeben – nur angemeldet" |
| nicht freigegeben, sonst | „Sichtbar: {Stufe}" |

Die letzten beiden Zeilen sind der Grund für die Aufteilung: „Sichtbar:
Öffentlich" wäre falsch, weil ein Anhang ohne eigene Freigabe anmeldefrei nicht
abrufbar ist — und ein pauschales „Nur intern" wäre bei `members` genauso
falsch, nur in die andere Richtung.

Wechselt ein Dokument von `public` auf eine restriktivere Stufe, wird
`is_public` aller seiner Anhänge in derselben Transaktion zurückgesetzt und je
Anhang mit der Aktion `SMS_DOCUMENT_ATTACHMENT_UNPUBLISHED_BY_DOWNGRADE`
auditiert — unterscheidbar vom manuellen Widerruf. Der Freigabenachweis
(`publicReleasedAt`, `publicReleasedByClerkUserId`, `publicReleaseNote`) bleibt
erhalten; er bedeutet „letzte Freigabe", nicht „aktuell öffentlich". Eine
spätere erneute Veröffentlichung des Dokuments gibt die Anhänge **nicht**
automatisch wieder frei.


#### Die zwei Auslieferungswege

Alle Seiten prüfen zusätzlich `auth()` und leiten bei fehlender Session auf `/sign-in` um.

**Der anmeldefreie Weg.** Sie liefert einen Anhang
nur aus, wenn zwei Bedingungen zugleich erfüllt sind: `attachments.is_public`
ist gesetzt **und** das zugehörige SMS-Dokument steht auf
`visibility = 'public'`. Beides wird bei jedem einzelnen Abruf neu geprüft —
einmal in der SQL-Bedingung und ein zweites Mal auf der geladenen Zeile.
Ein Widerruf wirkt dadurch sofort. Anhänge von Meldungen sind strukturell
ausgeschlossen (Inner Join auf `sms_documents`), und eine Datenbankbedingung
verhindert, dass ein Meldungs-Anhang überhaupt als öffentlich markiert werden
kann. Jede Ablehnung antwortet mit identischem 404, damit von außen nicht
erkennbar ist, ob eine ID existiert.

**Der Weg mit Sitzung**, seit Issue #36 unter der neutralen Route
`/documents/[documentId]/attachments/[attachmentId]/download` — bewusst nicht
mehr unter `/dashboard`, weil ein `member` ohne internen Dashboard-Zugang hier
die Anhänge eines `members`-Dokuments lädt. Die frühere Beschränkung auf
`hasSafetyEditRole` ist entfallen: Anhänge erben jetzt die Sichtbarkeit ihres
Elterndokuments, womit die Frage „hängt der Anhang an etwas Vertraulichem?"
beantwortbar ist. Wie beim anmeldefreien Weg wird zweimal geprüft — in der
SQL-Bedingung und auf der geladenen Zeile — und jede Ablehnung antwortet mit
identischem 404, auch die fehlende Anmeldung. Anhänge von Meldungen sind über
den Inner Join auf `sms_documents` ausgeschlossen; für sie gilt weiterhin die
eigene Route unter `/dashboard/reports`.

Damit bleibt es bei genau zwei Auslieferungswegen für Anhänge von
SMS-Dokumenten: einer anonym, einer mit Sitzung.

---

## Woher die Rollen kommen

`getCurrentUserRoles()` hat **zwei** Quellen, und nur eine davon beschreibt
dieses Dokument sonst:

| `AUTH_MODE` | Quelle | Rollen je Konto |
|---|---|---|
| `clerk`, `betterauth` | Tabelle `user_roles`, Join auf `roles` | strukturell genau eine globale Rolle (DELETE + INSERT in einer Transaktion) |
| `file` | die Benutzerdatei der Dateiauthentifizierung | **mehrere möglich** — das Schema dort ist `roles: array().min(1)` |

Beide Wege filtern über `isAppRoleKey`; ein unbekannter Schlüssel erzeugt in
keinem Fall eine Berechtigung.

Der Unterschied ist auf die Entwicklung begrenzt: `lib/auth/file-auth.ts`
wirft bei `NODE_ENV=production`, und die automatisierte E2E-Suite darf diesen
Modus laut Projektregel nicht verwenden. Er ist trotzdem festgehalten, weil
sich damit lokal ein Zustand herstellen lässt, den eine Betreiberinstallation
nicht kennt — ein Konto mit mehreren Rollen. Die Prädikate kommen damit
zurecht (sie fragen „trägt **eine** der Rollen diese Fähigkeit"), aber
Annahmen wie „ein Konto hat genau eine Rolle" gelten dort nicht.

---

## Konten ohne Rolle

Ein angemeldetes Konto **ohne** zugewiesene PAOLO-Rolle ist ein gültiger
Zustand, aber ein Übergangszustand.

**Wie er entsteht:** durch Anlage außerhalb von PAOLO — legt ein Administrator
ein Konto direkt beim Anmeldedienst an (Clerk-Dashboard, Einladung), existiert
es dort, bevor in PAOLO eine Rolle vergeben ist. Außerdem, wenn in
`createUserWithRole` die Kontoanlage gelingt, die anschließende
Rollenzuweisung aber scheitert: Das Directory liegt außerhalb der
Datenbanktransaktion und lässt sich nicht zurückrollen.

**Was er bedeutet:** Das Konto kann sich anmelden, hat keinen internen Zugang
(alle Dashboard-Seiten enden mit 404 und der Erklärseite aus
`app/dashboard/not-found.tsx`) und sieht auf `/communications` genau das, was
ein anonymer Besucher sieht — insbesondere **keine** Inhalte der Stufe
`members`. `getCurrentUserRoles()` liefert für ein solches Konto `[]`, dieselbe
Liste wie für einen anonymen Abruf.

**Was ihn nicht erzeugt:** Eine reguläre Aktion zum Entfernen einer Rolle
existiert nicht. Ein Rollenwechsel läuft über `assignRole` und ersetzt die
bisherige Rolle in derselben Transaktion.

**Wo er sichtbar ist:** `/dashboard/users` führt eine einzige Kontenliste („Angemeldete
Personen"). Ein Konto ohne globale `user_roles`-Zeile trägt dort den Status
„Ohne Rolle" und eine Zuweisung an Ort und Stelle. Die Liste liest das
Verzeichnis vollständig (bei Clerk seitenweise über alle Konten); ist der
Anmeldedienst nicht erreichbar oder unvollständig, weist die Seite das aus,
statt eine unvollständige Liste als „alles in Ordnung" darzustellen.

## Verwaiste Rollen und der letzte Administrator

Umgekehrt kann eine Rollenzeile ohne Konto bestehen — etwa wenn ein Konto beim
Anmeldedienst gelöscht wird. Die Liste zeigt sie mit dem Status „Konto fehlt"
(**verwaiste Rolle**), und „Rolle bereinigen" (`removeOrphanedRole`) entfernt
sie, sofern das Verzeichnis erreichbar ist und das Konto tatsächlich fehlt.
Das ist bewusst kein Umweg um den Schutz der letzten Rolle: Es bleibt kein
Konto zurück, das angemeldet wäre.

Seit #114 löscht PAOLO ein Konto selbst und entfernt dabei die Rollenzuweisungen. Bei
Clerk geschieht das in zwei Schritten (Anbieter, dann Datenbank); scheitert der zweite,
bleibt genau so eine verwaiste Rolle zurück und lässt sich bereinigen.

Ein verwaister Administrator zählt nicht als funktionsfähiger Administrator.
Der Schutz „es bleibt mindestens ein funktionsfähiger Administrator" prüft
deshalb gegen das Verzeichnis, nicht nur gegen die Rollenzeilen
(`lib/auth/admin-invariant.ts`). Er läuft in der Transaktion der Rollenänderung
unter einer Datenbanksperre (`pg_advisory_xact_lock`) und liest den Stand dort
frisch; zwei gleichzeitige Herabstufungen können so nicht beide durchgehen.
Ist das Verzeichnis nicht erreichbar, wird eine Änderung an einer
Administratorrolle abgelehnt statt geraten.

**Grenze:** Die Transaktion schützt nur PAOLO-eigene Schreibzugriffe. Wird ein
Administratorkonto zwischen Verzeichnisabruf und Commit oder außerhalb von PAOLO
gesperrt oder gelöscht, kann PAOLO das nicht verhindern. Die Seite zeigt dann den
Hinweis „Es gibt derzeit keinen funktionsfähigen Administrator"; zur Behebung ist
der Betreiber der Installation gefragt.


---

## Rollenvergabe

Welche Rollen eine Rolle an andere vergeben darf, ist in `ASSIGNABLE_ROLES` (`lib/constants/roles.ts`) definiert:

| Handelnde Rolle | Vergabefähige Rollen |
|---|---|
| `admin` | admin, safety_manager, instructor, member |
| `safety_manager` | instructor, member |
| `instructor` | member |
| `member` | — (keine) |

Die Funktion `canManageRoles` gibt für `admin`, `safety_manager` und `instructor` `true` zurück und steuert den Seitenzugang zu `/dashboard/users`. Die tatsächlich vergabbaren Rollen werden zusätzlich per `getAssignableRoles` geprüft.

Schutzmechanismus: Ein Admin kann seine eigene Admin-Rolle nicht selbst durch eine andere ersetzen oder entfernen, solange er die einzige aktive Admin-Rollenzuweisung hat.


---

## Fähigkeitentabelle (`lib/constants/roles.ts`)

Die einzige Quelle. Die benannten Prädikate oben sind dünne Zugriffe darauf —
sie tragen die fachliche Absicht an der Aufrufstelle, die Rollenliste steht nur
hier.

| Fähigkeit | Erlaubte Rollen | Zugriff |
|---|---|---|
| `reports.read` | admin, safety_manager, instructor | `hasReportReadRole` |
| `reports.edit` | admin, safety_manager | `hasSafetyEditRole` |
| `measures.read` | admin, safety_manager, instructor | `hasMeasureReadRole` |
| `measures.edit` | admin, safety_manager | (über `hasSafetyEditRole`) |
| `documents.read` | admin, safety_manager, instructor | `hasDocumentReadRole` |
| `documents.read.members` | admin, safety_manager, instructor, member | `hasMembersDocumentReadRole` |
| `documents.edit` | admin, safety_manager | (über `hasSafetyEditRole`) |
| `attachments.access` | admin, safety_manager, instructor | `hasAttachmentAccessRole` |
| `roles.manage` | admin, safety_manager, instructor | `canManageRoles` |
| `accounts.access` | admin, safety_manager | `hasAccountAccessRole`, `canManageAccountAccess` (zusätzlich `canManageTargetUser`, nie das eigene Konto), `canDeleteAccount` (zusätzlich nie mit Administratorrolle) |
| `admin.only` | admin | `hasAdminRole` |

**Entscheidung (#44):** Vorher lagen die Berechtigungen an zwei Stellen — einer
generischen Ressource/Aktion-Matrix in `lib/auth/permissions.ts` und den
benannten Prädikaten hier. Beide führten dieselben Rollenlisten getrennt, und
fünf der sieben Matrixeinträge wurden nie aufgerufen: Wer sie änderte, änderte
nichts.

Gewählt wurde die Tabelle als Quelle **mit** benannten Zugriffen darüber, nicht
die generische Matrix. Zwei Gründe: Die Prädikate trugen bereits über dreißig
Aufrufstellen, die Matrix sieben — die Richtung mit dem kleineren Eingriff war
damit vorgezeichnet. Und `hasDocumentReadRole` wie `canManageRoles` sind nur
Vorstufen; den eigentlichen Umfang entscheiden `getReadableVisibilityDbValues`
bzw. `ASSIGNABLE_ROLES`. Eine Ressource/Aktion-Achse hätte das nicht
abgebildet, sondern verdeckt.

Im gesamten System gibt es genau vier Rollenmengen. Die vierte — die gesamte
angemeldete Mitgliedschaft — kam mit #50/M1 hinzu und hat einen eigenen Grund:
Das Sichtbarkeitsmodell der SMS-Dokumente kennt vier Stufen, und `members`
adressiert alle Mitglieder statt nur den Bearbeiterkreis; drei Mengen können
vier Stufen nicht abbilden.

Vorher stand diese eine Regel als `roleKeys.length > 0` in
`getReadableVisibilityDbValues` — die einzige Berechtigung, die nicht über
`can()` lief. Sie war nicht ausnutzbar, weil `getCurrentUserRoles` unbekannte
Rollen herausfiltert, aber latent: Eine künftige fünfte Rolle hätte den
Lesezugriff auf `members`-Dokumente beim Anlegen stillschweigend geerbt.

Ein Prädikat, das eine **fünfte** Rollenmenge einführt, fällt in
`tests/auth/role-predicates.test.ts` auf.


---

## Bekannte Einschränkungen

- **Navigation ist keine Sicherheitsgrenze.** Die Sichtbarkeit von Menüpunkten und Karten dient der Benutzerführung. Alle schreibenden und lesenden Operationen sind serverseitig abgesichert. Welche Menüpunkte und Karten es gibt, ist bewusst **nicht** dokumentiert: Die Oberfläche ändert sich häufiger als diese Datei, und eine gespiegelte Liste war zuletzt an beiden Stellen veraltet.
- **Organisations-Scoping vorbereitet, nicht aktiv.** Das Feld `organizationId` in `user_roles` ist nullable und für spätere Mehrorganisationsunterstützung vorgesehen. Aktuell werden ausschließlich globale Rollen (`organizationId IS NULL`) verwendet. Analyse: [`organization-scoping.md`](organization-scoping.md).
- **Kein Datenbank-Constraint für „höchstens eine globale Rolle pro Benutzer".** Die Code-Logik erzwingt dies per DELETE + INSERT, seit #40 in einer gemeinsamen Transaktion. Ein DB-seitiger Constraint fehlt und ist auch nicht ohne Weiteres möglich: `user_roles.clerk_user_id` hat bewusst keinen Fremdschlüssel, weil das Directory bei Clerk außerhalb der Datenbank liegt.
- **Middleware-Schutz nicht vollständig.** Die Datei `proxy.ts` verwendet `clerkMiddleware()` ohne Route-Schutz. Berechtigungsprüfungen erfolgen ausschließlich auf Ebene der Server Components und Server Actions.
- **Fachliche Abweichungen sind hier nicht verzeichnet.** Wo die durchgesetzte Berechtigung vom fachlichen Soll abweicht, steht das im Register offener Punkte in [`role-responsibilities.md`](role-responsibilities.md) — nicht in dieser Datei und nicht in der Matrix.

---

## Pflegehinweis

Dieses Dokument trägt Begründungen, keine Aufstellungen. Bei einer Änderung an
Rollen, Guards oder Server Actions gehört zuerst
[`permission-matrix.md`](permission-matrix.md) nachgezogen; diese Datei nur
dann, wenn sich die **Begründung** ändert — also das Sichtbarkeitsmodell, die
Anhang-Vererbung, die Vergaberegeln oder die Fähigkeitentabelle.

Maßgeblich ist immer der Code, nicht dieses Dokument. Bei Abweichungen gilt der
Code. Eine Abweichung zum fachlichen Soll ist dagegen ein Befund und gehört ins
Register in [`role-responsibilities.md`](role-responsibilities.md), statt durch
Angleichen der Beschreibung stillgelegt zu werden.
