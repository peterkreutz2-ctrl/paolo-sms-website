# Installation aus dem Quellpaket

Diese Anleitung beschreibt die Erstinstallation von PAOLO SMS aus dem
versionierten Quellpaket `paolo-sms-R<version>.tar.gz` auf einem Docker-Host
(VM oder eigener Server). Sie braucht **keinen Zugang zum Git-Repository** und
keine Entwicklungswerkzeuge. Aufbau und Inhalt des Pakets beschreibt
[`release-package.md`](release-package.md).

Die Anleitung deckt Paketprüfung, Entpacken, Konfiguration,
Datenbankinitialisierung, Einrichtung des ersten globalen Administrators und
Inbetriebnahme ab. Sie ersetzt keine Detailanleitung, sondern verweist darauf:

- Entscheidung über Hosting, Anmeldeverfahren und Datenbank:
  [`installation-decision-guide.md`](installation-decision-guide.md)
- Vorbereitung eines Ubuntu-Hosts und Nginx/TLS:
  [`docker-vm-deployment.md`](docker-vm-deployment.md)
- alle Konfigurationswerte und der Bootstrap im Detail:
  [`docker-setup.md`](docker-setup.md)
- Datenschutz- und Betriebsvoraussetzungen:
  [`production-readiness.md`](production-readiness.md)

Die Anleitung ist für die Erstinstallation gedacht; Sicherung und
Wiederherstellung beschreibt Abschnitt 11. Vor einem Echtdatenbetrieb gelten die
Voraussetzungen aus [`production-readiness.md`](production-readiness.md).

## 1. Voraussetzungen

- Docker Engine oder Docker Desktop mit dem Compose-Plugin (`docker compose`,
  getestet mit Docker 29 und Compose v5).
- Auf dem Host `tar`, `sha256sum` (Windows: PowerShell `Get-FileHash`) und `curl`
  für die Prüfung der Installation. Node.js, npm und Git sind **nicht**
  erforderlich; gebaut wird im Docker-Image.
- Ausgehender Internetzugang des Hosts für den Image-Build (Basisimages und
  npm-Pakete) und die erste Bereitstellung.
- Für den öffentlichen Betrieb: Domain mit `A`-Record, offene Ports 80 und 443.

## 2. Verzeichnisaufbau

Betreiberdaten und austauschbare Software liegen getrennt. Ein späteres Release
ersetzt nur ein Verzeichnis unter `releases/`; Konfiguration, Nginx-Einstellungen
und die Daten bleiben unberührt.

```text
/opt/paolo-sms/                  Betreiberwurzel (PAOLO_HOME)
├── downloads/                   Paket und SHA256SUMS
├── config/
│   ├── .env.docker.local        Betreiberkonfiguration mit Geheimnissen
│   └── nginx/conf.d/            aktive Nginx-Konfiguration (nur mit --prod)
├── releases/
│   └── paolo-sms-R<version>/     entpacktes Paket (austauschbar)
└── current -> releases/paolo-sms-R<version>
```

Die **persistenten Daten** liegen nicht in diesen Verzeichnissen, sondern in drei
Docker-Volumes des Compose-Projekts `paolo-sms`: Datenbank
(`paolo-sms_paolo-db-data`), Anhänge (`paolo-sms_paolo-storage-data`) und
lokale Sicherungen (`paolo-sms_paolo-backup-data`). Bei Betrieb mit Nginx kommen
Zertifikate und ACME-Webroot hinzu.

Anlegen unter Linux:

```bash
sudo install -d -o "$USER" -g "$USER" /opt/paolo-sms/{downloads,config,releases}
```

Unter Windows (Test- oder Evaluationsinstallation mit Docker Desktop) lautet das
Äquivalent `C:\paolo-sms\{downloads,config,releases}`; die PowerShell-Befehle
stehen in Abschnitt 9.

## 3. Paket prüfen und entpacken

Das Paket und die Datei `SHA256SUMS` stammen aus derselben Quelle. Beides nach
`/opt/paolo-sms/downloads` kopieren (zum Beispiel per `scp`).

```bash
cd /opt/paolo-sms/downloads
sha256sum -c SHA256SUMS
tar -xzf paolo-sms-R<version>.tar.gz -C /opt/paolo-sms/releases
cd /opt/paolo-sms/releases/paolo-sms-R<version>
sha256sum -c FILES.sha256 --quiet && echo "Dateien unverändert"
cat RELEASE.json
ln -sfn releases/paolo-sms-R<version> /opt/paolo-sms/current
```

`sha256sum -c SHA256SUMS` prüft, dass das Archiv unverändert ist, und
`FILES.sha256` prüft jede entpackte Datei. `RELEASE.json` nennt Version, Commit
und die letzte Migration des Pakets.

Die Prüfsumme belegt nur die Unversehrtheit gegenüber dem Wert, den man aus
einer getrennten, vertrauenswürdigen Quelle erhalten hat. Das Paket ist nicht
signiert; die Echtheit der Quelle lässt sich damit noch nicht prüfen.

Lizenz und Hinweise stehen im Paket unter `LICENSE`, `NOTICE`,
`BRAND-USAGE.md`, `THIRD-PARTY-NOTICES.md` und `THIRD-PARTY-LIST.md`; sie
gelangen auch in das gebaute Docker-Image.

## 4. Konfiguration

Die Vorlage wird **außerhalb** des Release-Verzeichnisses abgelegt und geschützt:

```bash
cp /opt/paolo-sms/current/.env.docker.example /opt/paolo-sms/config/.env.docker.local
chmod 600 /opt/paolo-sms/config/.env.docker.local
```

Die Datei enthält Geheimnisse. Sie gehört in keine Versionsverwaltung, in kein
Ticket und in keine Sicherung ohne Verschlüsselung. Zufällige Werte erzeugt
`openssl rand -hex 32`; hexadezimale Werte sind URL-sicher und für
`DATABASE_URL` geeignet.

Mindestens zu setzen, hier für Better Auth (die selbst betriebene Variante; für
Clerk den Abschnitt „Authentifizierung vorab festlegen“ in
[`docker-vm-deployment.md`](docker-vm-deployment.md) beachten):

| Variable | Wert |
|---|---|
| `POSTGRES_PASSWORD` | zufälliges Passwort |
| `DATABASE_URL` | `postgres://paolo:<passwort>@db:5432/paolo?sslmode=disable`; Passwort wie oben |
| `AUTH_MODE` | `betterauth` |
| `BETTER_AUTH_SECRET` | zufälliger Wert, mindestens 32 Zeichen |
| `APP_BASE_URL` und `BETTER_AUTH_URL` | dieselbe öffentliche Basis-URL; lokal `http://localhost:3000`, öffentlich `https://<domain>` |
| `PUBLIC_REPORT_RATE_LIMIT_SALT` | zufälliger Wert |
| `BETTER_AUTH_LOGIN_RATE_LIMIT_SALT` | zufälliger Wert |
| `BACKUP_CRON_SECRET` | zufälliger Wert, mindestens 32 Zeichen |
| `BACKUP_AGE_RECIPIENTS` | öffentliche age-Empfänger; vor Nutzung der Sicherung die Beispielwerte ersetzen |

`POSTGRES_USER` und `POSTGRES_DB` bleiben bei `paolo`, `STORAGE_PROVIDER=local`
legt Anhänge im Docker-Volume ab. Weitere Werte und ihre Bedeutung stehen in
[`docker-setup.md`](docker-setup.md), Abschnitt 4. Für den Betrieb hinter einer
Domain muss `APP_BASE_URL` die öffentliche HTTPS-Adresse sein; eine
`localhost`-Adresse erzeugt Links, die ins Leere laufen.

## 5. Compose-Aufruf und Projektname

Alle Befehle laufen über das mitgelieferte Skript
`scripts/deploy/paolo-compose.sh` (Windows: `paolo-compose.ps1`). Es ruft
`docker compose` auf und legt zwei Dinge fest:

- die Konfigurationsdatei `config/.env.docker.local` außerhalb des Release-
  Verzeichnisses und
- den **dauerhaft gleichen Compose-Projektnamen** `paolo-sms`.

Der zweite Punkt ist wichtig: Docker Compose leitet den Projektnamen sonst aus
dem Verzeichnisnamen ab. Der enthält die Version, und ein Release-Wechsel würde
neue, leere Volumes für Datenbank und Anhänge anlegen, während die bisherigen
Daten unverändert, aber unbenutzt zurückbleiben. Deshalb **nie** direkt
`docker compose` im Release-Verzeichnis aufrufen.

```bash
PAOLO=/opt/paolo-sms/current/scripts/deploy/paolo-compose.sh
```

`$PAOLO --prod …` fügt `docker-compose.prod.yml` hinzu (Nginx auf 80/443, keine
veröffentlichten App-Ports) und verlangt die Nginx-Konfiguration unter
`config/nginx/conf.d`; siehe Abschnitt 8. Die folgenden Schritte funktionieren
in beiden Betriebsarten, mit `--prod` nach `$PAOLO`.

## 6. Datenbank initialisieren, Administrator anlegen, starten

```bash
$PAOLO build app
$PAOLO up -d db
$PAOLO ps              # warten, bis db "healthy" ist
```

Der Image-Build dauert einige Minuten. Das Image wird aus dem entpackten Paket
gebaut; Git wird nicht benötigt.

Der SQL-Satz des Releases wird aus dem gebauten Image auf die leere Datenbank
angewendet. Ein erfolgreicher Lauf gibt nichts aus und endet mit Exit-Code 0:

```bash
$PAOLO run --rm --no-deps -T app sh /app/scripts/migrate.sh
```

Danach Organisation und ersten globalen Administrator anlegen. Der Aufruf ist
interaktiv; er fragt Name und Typ der Organisation sowie E-Mail, Anzeigename und
Passwort (mindestens acht Zeichen) ab:

```bash
$PAOLO run --rm --no-deps app node scripts/initialize-installation.mjs
```

Der Bootstrap ist absichtlich **nur für eine frische Installation**: Er bricht
ab, sobald schon eine Organisation oder Rollenzuweisung existiert. Für die
Automatisierung gibt es einen nicht interaktiven Modus
(`--non-interactive`, `--organization-name=…`, siehe `--help` und
[`docker-setup.md`](docker-setup.md), Abschnitt 6.2). Das Passwort wird dann über
die Umgebungsvariable `BETTER_AUTH_BOOTSTRAP_PASSWORD` übergeben, nie als
Argument.

Anwendung starten:

```bash
$PAOLO up -d app
```

## 7. Inbetriebnahme prüfen

Ohne `--prod` ist die Anwendung nur lokal erreichbar:

```bash
curl -fsS http://127.0.0.1:3000/api/health      # {"status":"ok"}
```

Im Browser prüfen: `http://127.0.0.1:3000/` und `/submit-report` laden ohne
Anmeldung, `/dashboard` leitet auf die Anmeldeseite um, die Anmeldung mit dem
Bootstrap-Administrator führt in das Dashboard. Die vollständige Liste der
Funktionsprüfungen steht in [`docker-vm-deployment.md`](docker-vm-deployment.md),
Abschnitt 5.

## 8. Betrieb hinter Nginx und TLS

Für den öffentlichen Betrieb gilt der Ablauf aus
[`docker-vm-deployment.md`](docker-vm-deployment.md), Abschnitt 4, mit diesen
Abweichungen für das Paket-Layout:

| In `docker-vm-deployment.md` | Im Paket-Layout |
|---|---|
| `docker compose -f docker-compose.yml -f docker-compose.prod.yml …` | `$PAOLO --prod …` |
| `deploy/nginx/conf.d/…` (Vorlagen umbenennen) | `/opt/paolo-sms/config/nginx/conf.d/…` |
| `bash scripts/deploy/…` | `bash /opt/paolo-sms/current/scripts/deploy/…` |
| `configure-backup-cron.sh` (liest `.env.docker.local`) | als Argument `/opt/paolo-sms/config/.env.docker.local` übergeben |

Die Nginx-Konfiguration einmal aus dem Release kopieren, damit die später
aktivierte TLS-Konfiguration bei einem Release-Wechsel erhalten bleibt:

```bash
mkdir -p /opt/paolo-sms/config/nginx
cp -r /opt/paolo-sms/current/deploy/nginx/conf.d /opt/paolo-sms/config/nginx/
```

Danach liegt die Konfiguration unter `/opt/paolo-sms/config/nginx/conf.d`; dort
werden später die HTTP- und HTTPS-Vorlagen umbenannt.

`configure-certbot-renewal.sh` erkennt das Paket-Layout und ruft Certbot und
Nginx über das Skript `paolo-compose.sh` auf. Als Verzeichnis
`/opt/paolo-sms/current` angeben, damit ein späterer Release-Wechsel ohne neue
Cron-Datei auskommt:

```bash
sudo bash /opt/paolo-sms/current/scripts/deploy/configure-certbot-renewal.sh /opt/paolo-sms/current
```

## 9. Windows und PowerShell

Für Test- und Evaluationsinstallationen mit Docker Desktop.

```powershell
New-Item -ItemType Directory C:\paolo-sms\downloads, C:\paolo-sms\config, C:\paolo-sms\releases
Set-Location C:\paolo-sms\downloads
Get-FileHash .\paolo-sms-R<version>.tar.gz -Algorithm SHA256   # mit SHA256SUMS vergleichen
tar -xzf .\paolo-sms-R<version>.tar.gz -C C:\paolo-sms\releases
Copy-Item C:\paolo-sms\releases\paolo-sms-R<version>\.env.docker.example C:\paolo-sms\config\.env.docker.local
$PAOLO = "C:\paolo-sms\releases\paolo-sms-R<version>\scripts\deploy\paolo-compose.ps1"
& $PAOLO build app
```

- Windows 10/11 bringt `tar` mit. Einen Symlink `current` gibt es hier nicht;
  das Skript wird direkt aus dem Release-Verzeichnis aufgerufen.
- **Kein `npm run … --`.** PowerShell wertet `--` selbst aus; der
  dokumentierte Aufruf `npm run setup:initialize -- --non-interactive …` fragt
  dann stillschweigend interaktiv nach. Deshalb in dieser Anleitung
  `node scripts/initialize-installation.mjs …`.
- Die Argumente von `paolo-compose.ps1` werden unverändert an Docker Compose
  weitergereicht.

**Git Bash unter Windows** wandelt Argumente, die wie ein Linux-Pfad aussehen,
in Windows-Pfade um. `sh /app/scripts/migrate.sh` wird so zu
`C:/Program Files/Git/app/scripts/migrate.sh`, und der Aufruf scheitert mit
„can't open“. Abhilfe: vorher `export MSYS_NO_PATHCONV=1`, oder PowerShell
verwenden.

## 10. Fehlerbilder

| Beobachtung | Ursache und Abhilfe |
|---|---|
| `Konfigurationsdatei fehlt` | `config/.env.docker.local` fehlt oder `PAOLO_HOME` stimmt nicht; Abschnitt 4 |
| `Release-Verzeichnis nicht unter <PAOLO_HOME>/releases/` | Paket nicht unter `releases/` entpackt; Abschnitt 2 |
| `can't open …/migrate.sh` unter Git Bash | Pfadumwandlung, Abschnitt 9 |
| Bootstrap fragt nach, obwohl Argumente angegeben waren | PowerShell hat `--` verschluckt, Abschnitt 9 |
| Bootstrap lehnt ab | Datenbank ist nicht leer; Bootstrap ist nur für frische Installationen |
| `db` wird nicht `healthy` | `POSTGRES_PASSWORD` und `DATABASE_URL` passen nicht zusammen; bei geändertem Passwort muss das Volume zum Passwort passen |
| Anwendung verbindet nicht zur Datenbank | `DATABASE_URL` zeigt auf `db`, nicht `localhost` |
| Anmeldung liefert `429`, ohne dass ein Limit erreicht ist | Im Produktionsbetrieb muss `BETTER_AUTH_LOGIN_RATE_LIMIT_TRUSTED_IP_HEADER` gesetzt sein und der Proxy den Header liefern; ohne vertrauenswürdige Client-Adresse lehnt die Anmeldung ab (siehe [`runbooks/better-auth-login-rate-limit.md`](runbooks/better-auth-login-rate-limit.md)). Hinter Nginx ist das vorbereitet |

## 11. Sicherung und Wiederherstellung

Eine Installation besteht aus Datenbank, Anhängen und Konfiguration. Alle drei
sichert ein Aufruf; `age`-Schlüssel, Reihenfolge, Kopie auf einen anderen Server
und die Wiederherstellung auf einer neuen Installation stehen in
[`backup-restore.md`](backup-restore.md), Abschnitt „Vollständige Sicherung einer
Docker-Installation“:

```bash
sh /opt/paolo-sms/current/scripts/deploy/paolo-backup.sh create
```

Vor dem Echtbetrieb: `BACKUP_AGE_RECIPIENTS` in der Konfiguration auf eigene
öffentliche Schlüssel setzen, eine Sicherung erstellen und die Wiederherstellung
einmal auf einer Wegwerf-Instanz üben.

## 12. Grenzen des Nachweises

Erprobt sind Erstinstallation, Update, Rückstellung, Sicherung, Wiederherstellung und
Nginx mit einem selbst ausgestellten Zertifikat (siehe
[`update-from-package.md`](update-from-package.md), Abschnitt „Nachgewiesener Stand“).
Nicht erprobt sind die Ausstellung eines Zertifikats bei Let's Encrypt (benötigt eine
öffentliche Domain) und der Betrieb mit Clerk als Anmeldeverfahren (benötigt ein
externes Clerk-Projekt). Ein Update zurück auf eine ältere Version ist nur bei
nachgewiesener Schemakompatibilität zulässig. `package.json` enthält Skripte für
Entwicklungswerkzeuge, die im Paket fehlen (`e2e:*`, `demo:rebuild`,
`help:generate`, `test:*`); für den Betrieb gelten die Befehle dieser Anleitung.
