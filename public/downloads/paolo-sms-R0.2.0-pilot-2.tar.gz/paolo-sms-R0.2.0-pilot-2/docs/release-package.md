# Quellpaket

Ein Quellpaket ist ein versioniertes Archiv `paolo-sms-R<version>.tar.gz`. Es
enthält den Quellcode und die Dokumentation, die für Installation, Betrieb und
Nutzung nötig sind, und lässt sich ohne Zugang zum Entwicklungsrepository
installieren. Dieses Dokument beschreibt, wie das Paket entsteht und wie sich
ein Paket prüfen lässt. Die Installation aus dem Paket beschreibt
[`install-from-package.md`](install-from-package.md); das Update beschreibt
[`update-from-package.md`](update-from-package.md).

Die erste Vorabversion `0.2.0-pilot.1` wurde am 26.10.2026 über das getrennte
Website-Repository veröffentlicht. Dieses historische Paket behält seinen Namen
ohne `R` und seine Prüfsumme. Neue Releases folgen dem unten beschriebenen Ablauf.
Das Anwendungsrepository bleibt privat; nur das geprüfte Quellpaket wird öffentlich.

## Version, Release-Tag und GitHub Release

`package.json` ist die Versionsquelle. Beispiel:

| Stelle | Wert |
|---|---|
| `package.json`, `package-lock.json` und dessen Wurzelpaket | `1.2.3-pilot` |
| Git-Tag und GitHub-Release-Titel | `R1.2.3-pilot` |
| Archiv und entpacktes Verzeichnis | `paolo-sms-R1.2.3-pilot` |
| Release-Notes | `docs/release-notes/R1.2.3-pilot.md` |

Major, Minor und Patch folgen SemVer ohne führende Nullen. Die Ergänzung nach
dem Bindestrich ist optional, ein bis zehn Zeichen lang und enthält ausschließlich
ASCII-Buchstaben, Ziffern oder Bindestriche. Groß-/Kleinschreibung bleibt erhalten;
rein numerische Ergänzungen haben ebenfalls keine führenden Nullen. Punkte und
Build-Metadaten mit `+` sind ausgeschlossen. `prerelease` passt in zehn Zeichen,
`pre-release` dagegen nicht. Jede Ergänzung bezeichnet eine Vorabversion; auch
eine Versionsnummer ohne Ergänzung ersetzt keine menschliche Betriebsfreigabe.

### Lokaler Ablauf

Alle Aufrufe erfolgen im Entwicklungsrepository mit Node.js 24; für den Upload
sind GitHub CLI (`gh`) und eine Anmeldung mit Schreibzugriff auf das private
Anwendungsrepository erforderlich. Die Beispiele bestimmen keine nächste Version.

1. **Version vorbereiten:** `npm run release:version -- 1.2.4-ib` validiert die
   Eingabe und führt `npm version … --no-git-tag-version` aus. Die drei
   Versionsstellen werden gemeinsam aktualisiert. npm-Schritte `preversion`,
   `version` und `postversion` bleiben nutzbar, etwa für eine spätere Versionsanzeige.
   Anschließend wird die Gleichheit erneut geprüft. Der Befehl selbst erstellt
   weder Commit noch Tag. Eigene npm-Folgeschritte dürfen diese Trennung nicht
   durch Tag-Erstellung oder Veröffentlichung umgehen. Fehler werden nicht durch
   automatisches Zurücksetzen verdeckt. Änderungen prüfen, Release-Notes anlegen,
   committen und über den üblichen Review-Prozess nach `main` bringen. Die
   Zielversion darf währenddessen über mehrere Commits bestehen bleiben.
2. **Tag erstellen:** `npm run release:tag -- --commit <commit>` liest die Version
   aus diesem Commit und prüft Lockfile und nicht leere Release-Notes. Nach
   Aktualisierung von `origin/main` muss der Commit in dessen Historie liegen;
   er muss weder Merge-Commit noch aktuelle Spitze sein. Der Befehl erstellt
   einen annotierten lokalen `R`-Tag. Ein bestehender Tag am gleichen Commit
   wird wiederverwendet; ein anderer Commit ist ein Fehler. Noch kein Push und
   kein GitHub Release.
3. **Paket bauen:** `npm run release:build` leitet den Tag aus der lokalen
   `package.json` ab, prüft die drei Versionsstellen im getaggten Commit und
   baut nur dessen Dateien. Version, Tag und vollständiger Commit werden
   angezeigt; ein abweichender lokaler Entwicklungsstand wird ausdrücklich
   benannt. Die Builder-Dateien müssen zum getaggten Commit passen; nötigenfalls
   diesen Stand auschecken. Ausgabe: `dist/release/R<version>/` mit Archiv,
   `SHA256SUMS` und `release-metadata.json`. Bestehende abweichende Dateien
   werden nicht überschrieben. Bei einem noch nicht veröffentlichten Fehlbau
   die lokalen Artefakte ausdrücklich entfernen und neu bauen.
4. **Privaten Entwurf hochladen:** `npm run release:draft` leitet den Tag ebenso
   ab und prüft Paketinhalt gegen den Quellcommit, Prüfsummen, Metadaten und
   das private Ziel `peterkreutz2-ctrl/paolo-sms`. Ziel, Version, Tag, Commit
   und Dateien werden vor dem Upload angezeigt. Erst nach Bestätigung wird
   ausschließlich dieser Tag gepusht und ein GitHub-Release-Entwurf mit den
   Release-Notes sowie den drei Dateien erstellt. `npm run release:draft -- --yes`
   überspringt nur die Rückfrage; ohne Eingabemöglichkeit und ohne `--yes`
   bricht der Befehl ab. Ergänzte Versionen erhalten das Prerelease-Kennzeichen.
   Wiederholungen ergänzen fehlende Dateien; vorhandene Dateien müssen bytegleich
   sein. Abweichende Tags, Metadaten, Anhänge oder bereits veröffentlichte Releases
   werden nicht überschrieben. Temporäres Markdown für `--notes-file` wird entfernt.
5. **Veröffentlichen:** Ein Mensch prüft den Entwurf und veröffentlicht ihn in
   der GitHub-Oberfläche oder mit `gh release edit R<version> --repo
   peterkreutz2-ctrl/paolo-sms --draft=false`. Eine Vorabversion bleibt ein
   Prerelease. Das veröffentlichte GitHub Release bleibt privat. Vorher gelten
   weiterhin sämtliche Prüfungen aus [`release-checklist.md`](release-checklist.md).

Die Metadatendatei enthält `version`, `releaseTag`, `commit`, `commitDate`,
`archiveName`, `size` (Bytes), `sha256`, `license`, `prerelease` und `releaseNotes`
(vollständiger Text aus dem getaggten Commit). Sie wird nicht in das Archiv
eingebettet und behauptet keine Freigabe. `commitDate` ist kein Veröffentlichungsdatum.

### Durchgehendes Befehlsbeispiel (PowerShell 7)

Das Beispiel beginnt im sauberen Entwicklungsrepository. Node.js 24, Git und
GitHub CLI müssen verfügbar sein; `origin` muss zum privaten Anwendungsrepository
zeigen. Alle Befehle eines Blocks einzeln prüfen und bei einem Fehler stoppen.
Die beispielhafte Zielversion vor Beginn bewusst durch die freizugebende Version
ersetzen; sie ist keine Festlegung der nächsten Projektversion. Es werden echte
Branches, Tags und ab dem Upload-Schritt echte GitHub-Dateien angelegt.

**Vorbereitung im Branch:**

```powershell
$releaseVersion = "1.2.3-pilot"
$releaseTag = "R$releaseVersion"
$releaseBranch = "codex/release-$releaseTag"
$notesPath = "docs/release-notes/$releaseTag.md"

node --version
npm --version
git --version
gh auth status --hostname github.com
git status --short
git remote -v
git fetch origin --tags
git switch main
git pull --ff-only origin main
git switch -c $releaseBranch

npm run release:version -- $releaseVersion
git diff -- package.json package-lock.json
```

Die drei Versionsstellen müssen übereinstimmen. Release-Notes als UTF-8-Datei
anlegen und vor dem Commit fachlich ausfüllen. Sie nennen Änderungen,
Migrationen, Konfigurationsänderungen, bekannte Grenzen und die Kompatibilität
für Rücknahmen. Für eine Vorabversion den Testdaten-/Vorabversionshinweis ergänzen:

```powershell
New-Item -ItemType File -Path $notesPath
notepad $notesPath

git add package.json package-lock.json $notesPath
git commit -m "Release $releaseTag vorbereiten"

node scripts/release/build-source-package.mjs --commit HEAD --update-file-list
git diff -- scripts/release/package-files.txt
git add scripts/release/package-files.txt
git commit -m "Paketdateiliste für $releaseTag aktualisieren"
```

Neue Release-Notes gehören ins Paket und müssen deshalb in der Dateiliste stehen.
Den zweiten Commit nur erstellen, wenn die Liste tatsächlich geändert wurde.
Falls Builder-Dateien geändert wurden, müssen sie bereits vor dem Aufruf von
`--update-file-list` committet sein. Die Liste selbst wird anschließend geprüft
und committet. Das gilt ebenso für weitere neue Paketdateien.

**Prüfen und nach main übernehmen:**

```powershell
npm ci
npm run licenses:check
npm run lint
npx tsc --noEmit
npm run test:node
npm run build
```

Zusätzlich gelten die Paketfreigabe und gegebenenfalls die Migrationsprüfungen
aus [`release-checklist.md`](release-checklist.md). Vor dem Pull Request sind
beide vollständigen E2E-Läufe erforderlich. Einrichtung und sichere Auswahl der
dedizierten Testumgebung stehen in `docs/end-2-end-test-overview.md` des
Entwicklungsrepositorys. Werden zwei entsprechend eingerichtete Umgebungsdateien
verwendet, lauten die Aufrufe beispielsweise:

```powershell
$env:E2E_ENV_FILE = ".env.e2e.betterauth.local"
npm run e2e:test
$env:E2E_ENV_FILE = ".env.e2e.clerk.local"
npm run e2e:test
Remove-Item Env:E2E_ENV_FILE

git push -u origin $releaseBranch
gh pr create --base main --head $releaseBranch
$releasePr = gh pr view --json number --jq .number
gh pr checks $releasePr
```

Die beiden Dateinamen sind Beispiele für bereits konfigurierte Umgebungen;
sie werden nicht automatisch angelegt. Ergebnisse und etwaige isolierte Clerk-
Wiederholungen gehören in den Pull Request. Vor dem Merge Review, CI und Preview
nach den Projektregeln prüfen; die dokumentierte Vercel-Autorisierungsausnahme
bleibt bestehen. Erst nach Freigabe zusammenführen und den freizugebenden Commit
auswählen:

```powershell
gh pr merge $releasePr --merge --delete-branch
git switch main
git pull --ff-only origin main
git status --short
git log -1 --oneline
$releaseCommit = git rev-parse HEAD
git show "${releaseCommit}:package.json"
```

Die angezeigte Version muss die freizugebende Version sein. Falls inzwischen
weitere Commits auf `main` liegen, `$releaseCommit` ausdrücklich auf den geprüften
vollständigen Commit setzen. Für die folgenden Schritte muss der lokale Checkout
dessen Version und Builder-Dateien haben; nötigenfalls im sauberen Arbeitsverzeichnis
`git switch --detach $releaseCommit` verwenden. Nach Abschluss mit `git switch main`
zurückkehren. Der ausgewählte Commit muss weiterhin in der Historie von `origin/main`
liegen. Vor dem Upload die Freigabe für genau diesen Stand abschließen.

**Taggen, bauen und prüfen:**

```powershell
npm run release:tag -- --commit $releaseCommit
git cat-file -t "refs/tags/$releaseTag"
git rev-parse "refs/tags/$releaseTag^{commit}"
npm run release:build

$artifacts = Join-Path $PWD "dist/release/$releaseTag"
$metadata = Get-Content (Join-Path $artifacts "release-metadata.json") -Raw | ConvertFrom-Json
$archive = Join-Path $artifacts $metadata.archiveName
$archiveHash = (Get-FileHash $archive -Algorithm SHA256).Hash.ToLowerInvariant()
if ($archiveHash -ne $metadata.sha256) { throw "Archiv-Prüfsumme stimmt nicht." }
$sums = (Get-Content (Join-Path $artifacts "SHA256SUMS") -Raw).Trim()
if ($sums -ne "$archiveHash  $($metadata.archiveName)") { throw "SHA256SUMS stimmt nicht." }
node --input-type=module -e 'import { verifyArtifacts } from "./scripts/release/release-workflow.mjs"; verifyArtifacts(process.cwd()); console.log("Paket und Metadaten geprüft.");'
tar -xOf $archive "paolo-sms-$releaseTag/RELEASE.json"
```

Erwartet werden Tag-Typ `tag`, der ausgewählte Commit, ein erfolgreicher Paketbau
und passende Metadaten. Ein erneuter `npm run release:build` unter demselben
Werkzeugstand muss dieselbe SHA-256 liefern. Die lokale Inhaltsprüfung verwendet
keinen GitHub-Zugriff.

**Entwurf und ausdrückliche Veröffentlichung:**

```powershell
npm run release:draft
gh release view $releaseTag --repo github.com/peterkreutz2-ctrl/paolo-sms --json tagName,name,isDraft,isPrerelease,assets,body
```

In der Upload-Vorschau Ziel, Tag, Commit und alle drei Dateien kontrollieren.
`j` bestätigt den Tag-Push und Entwurfsupload; `n` bricht mit Exit-Code 1 ab,
bevor etwas gepusht oder hochgeladen wird. Für einen bewusst unbeaufsichtigten
Upload stattdessen `npm run release:draft -- --yes` verwenden. Bei einem Abbruch
während des Uploads denselben Aufruf wiederholen: Fehlende Dateien werden ergänzt,
abweichende vorhandene Dateien werden nicht überschrieben.

Der Entwurf muss `isDraft: true` und bei einer Ergänzung `isPrerelease: true`
anzeigen. Nach abschließender menschlicher Freigabe entweder in der GitHub-
Oberfläche veröffentlichen oder ausdrücklich:

```powershell
gh release edit $releaseTag --repo github.com/peterkreutz2-ctrl/paolo-sms --draft=false
gh release view $releaseTag --repo github.com/peterkreutz2-ctrl/paolo-sms --json tagName,isDraft,isPrerelease,assets
```

Danach ist `isDraft: false`; ein Prerelease bleibt ein Prerelease. Das Release
bleibt privat. Die öffentliche Bereitstellung folgt getrennt im Abschnitt
„Öffentliche Website und spätere Stufen“.

**Weitere Entwicklung:** Nach der Tag-Erstellung muss der nächste nach `main`
übernommene Entwicklungsstand eine neue Version führen. Dazu auf einem neuen
Branch beispielsweise `npm run release:version -- 1.2.4-ib` ausführen, beide
JSON-Dateien committen und über den üblichen geprüften Pull Request übernehmen.
`npm run release:check-main` prüft den jeweiligen committeten Stand auch lokal;
es verändert keine Dateien und setzt keinen Tag. Ohne passenden neuen Tag verweigert
`release:build` den Bau dieser Entwicklungsversion.

### Verbrauchte Versionen auf main

Ein Release-Tag bindet seine Version ab Erstellung an genau einen Commit. Ein
späterer Stand auf `main` benötigt eine neue Version, beispielsweise `1.2.4-ib`
nach `R1.2.3`. `1.2.3-ib` wäre dagegen semantisch älter als `1.2.3`. Eine neue,
noch nicht getaggte Version darf über mehrere Commits unverändert bleiben.

Die CI lädt bei jedem Push auf `main` alle Remote-Tags und prüft den aktuellen
Commit: Existiert der aus seiner Version abgeleitete Tag, muss er auf genau
diesen Commit zeigen. Annotierte Tags werden zum Commit aufgelöst. Ein
Verstoß macht den Lauf rot; wegen der fehlenden Branch Protection verhindert
dies technisch keinen Merge. Es gibt weder automatische Versionsänderungen
noch einen Pre-Commit-Hook oder eine zusätzliche Prüfung von Feature-Branches.
Noch nicht gepushte lokale Tags sind für GitHub unsichtbar und werden durch
die lokalen Werkzeuge berücksichtigt. Die historische Pilotkennung bleibt
bis zur nächsten Versionsvorbereitung in der CI erlaubt; neue Tags verlangen
das neue Format.

### Korrektur und Unveränderlichkeit

Normale Release-Befehle verschieben oder überschreiben keine Tags. Ein falscher
rein lokaler Tag kann ausdrücklich gelöscht und am richtigen Commit neu erstellt
werden; daraus gebaute falsche Artefakte verwerfen. Bei einem bereits gepushten,
unveröffentlichten Tag gehören auch Remote-Tag und Entwurf samt Dateien zu einem
gesondert autorisierten Korrekturvorgang. Es gibt keine automatische Reparatur.

Nach Veröffentlichung oder Weitergabe bleiben Tag und Paket unverändert.
Codekorrekturen erhalten eine neue Version und einen neuen Tag. Weitere Commits
ändern einen bestehenden Release nicht. Beschreibungen auf GitHub und Texte der
Website dürfen separat korrigiert werden, ohne Paketidentität oder Prüfsummen zu
verändern.

### Öffentliche Website und spätere Stufen

GitHub Releases und GitHub Pages sind getrennt. Zunächst werden das geprüfte
Archiv und die Prüfsumme manuell ins Website-Repository nach `public/downloads/`
übernommen und der Eintrag in `src/data/materials.ts` aus den Metadaten aktualisiert.
Die generische `SHA256SUMS` erhält dort einen versionsbezogenen Dateinamen.
Versionsanzeige, Commit, Größe, Lizenz und Prüfsumme müssen zum Paket passen;
das tatsächliche Veröffentlichungsdatum wird ausdrücklich ergänzt. Release-Notes
und Vorabversionshinweis werden übernommen. Website-Prüfung, Freigabe und Pages-
Deployment folgen den dortigen Regeln. Nach dem Upload die öffentlichen Dateien
herunterladen und bytegenau vergleichen. GitHubs automatische Quellarchive ersetzen
das gefilterte Quellpaket nicht.

Die aktuelle Website zeigt genau ein aktives Quellpaket an. Beim Wechsel auf eine
neue Version müssen die bisherigen Download-Dateien in der Freigabeliste von
`scripts/release-check.mjs` ausdrücklich erhalten bleiben, damit alte veröffentlichte
Adressen weiter funktionieren. Die neue aktive Version wird über `releasePackage`
automatisch zur Freigabeliste hinzugefügt. `release-metadata.json` wird derzeit
nicht öffentlich kopiert, sondern als Quelle für die manuelle Pflege verwendet.

Das folgende PowerShell-Beispiel setzt die Variablen `$releaseTag`, `$artifacts`,
`$archive` und `$metadata` aus dem vorherigen Ablauf voraus. Den tatsächlichen Pfad
des separaten Website-Checkouts setzen und dort nur mit sauberem Arbeitsverzeichnis
fortfahren:

```powershell
$websiteDir = "C:\Projekte\paolo-sms-website"
Set-Location -LiteralPath $websiteDir
git status --short
git switch main
git pull --ff-only origin main
git switch -c "codex/publish-$releaseTag"

$checksumName = "paolo-sms-$releaseTag.SHA256SUMS"
Copy-Item -LiteralPath $archive -Destination (Join-Path $PWD "public/downloads/$($metadata.archiveName)")
Copy-Item -LiteralPath (Join-Path $artifacts "SHA256SUMS") -Destination (Join-Path $PWD "public/downloads/$checksumName")
notepad src/data/materials.ts
notepad scripts/release-check.mjs
```

In `releasePackage` folgende Werte eintragen; bestehende Beschreibung und weitere
Felder bewusst prüfen:

| Website-Feld | Quelle |
|---|---|
| `version` | `releaseTag`, einschließlich großem `R` |
| `stand` | tatsächlich gewähltes Veröffentlichungsdatum, nicht `commitDate` |
| `packageFile`, `packageHref` | `archiveName`, beziehungsweise `/downloads/` davor |
| `checksumFile`, `checksumHref` | `$checksumName`, beziehungsweise `/downloads/` davor |
| `commit`, `sha256`, `license` | gleichnamige Metadatenwerte |
| `size`, `format` | lesbare Darstellung von `size` in Bytes; Format `TAR.GZ` |
| `notice` | Vorabversions-/Testdatenhinweis bei `prerelease: true`; sonst ausdrücklich freigegebener Hinweis |

Die bisherigen Paket- und Prüfsummenpfade als zwei explizite Einträge in
`allowedAssets` erhalten. Bei der ersten Umstellung sind das
`downloads/paolo-sms-0.2.0-pilot.1.tar.gz` und
`downloads/paolo-sms-0.2.0-pilot.1.SHA256SUMS`. Die alten Dateien bleiben unverändert.
Release-Notes als öffentliche Zusammenfassung auf der Materialseite pflegen und
etwaige Versionshinweise auf der Mitmachen-Seite nachziehen. Keine Links zum
privaten Anwendungsrepository oder interne Freigabeunterlagen auf die Website
übernehmen. Änderungen an Bildern oder Marken sind kein Teil dieses Schritts.

```powershell
notepad src/pages/materialien.astro
notepad src/pages/mitmachen.astro
npm ci
npm run verify
git diff -- src/data/materials.ts scripts/release-check.mjs src/pages/materialien.astro src/pages/mitmachen.astro
git status --short
git add src/data/materials.ts scripts/release-check.mjs src/pages/materialien.astro src/pages/mitmachen.astro
git add "public/downloads/$($metadata.archiveName)" "public/downloads/$checksumName"
git commit -m "Quellpaket $releaseTag veröffentlichen"
git push -u origin "codex/publish-$releaseTag"
gh pr create --base main --head "codex/publish-$releaseTag"
$websitePr = gh pr view --json number --jq .number
gh pr checks $websitePr
```

Zusätzlich die Darstellung nach den Website-Regeln prüfen. Erst nach Freigabe des
Website-Betreibers zusammenführen und das Pages-Deployment kontrollieren:

```powershell
gh pr merge $websitePr --merge --delete-branch
$websiteRun = gh run list --branch main --workflow deploy.yml --limit 1 --json databaseId --jq '.[0].databaseId'
gh run watch $websiteRun --exit-status
```

Falls der neue Deployment-Lauf noch nicht erscheint, die Abfrage wiederholen und
vor `watch` prüfen, dass sie zum eben gemergten Stand gehört. Nach erfolgreichem
Deployment das tatsächlich ausgelieferte Archiv und die Prüfsumme prüfen:

```powershell
$downloadCheck = Join-Path ([System.IO.Path]::GetTempPath()) ("paolo-download-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $downloadCheck | Out-Null
$downloadedArchive = Join-Path $downloadCheck $metadata.archiveName
Invoke-WebRequest -Uri "https://paolo-sms.de/downloads/$($metadata.archiveName)" -OutFile $downloadedArchive
Invoke-WebRequest -Uri "https://paolo-sms.de/downloads/$checksumName" -OutFile (Join-Path $downloadCheck $checksumName)
$downloadedHash = (Get-FileHash $downloadedArchive -Algorithm SHA256).Hash.ToLowerInvariant()
if ($downloadedHash -ne $metadata.sha256) { throw "Öffentliches Archiv hat eine abweichende Prüfsumme." }
$publishedSums = (Get-Content (Join-Path $downloadCheck $checksumName) -Raw).Trim()
if ($publishedSums -ne "$downloadedHash  $($metadata.archiveName)") { throw "Öffentliche Prüfsummendatei weicht ab." }
```

Auch den sichtbaren Versions-, Vorabversions- und Prüfsummenhinweis auf der
Website kontrollieren. Einen echten Upload oder eine Veröffentlichung ersetzt die
lokale Probe nicht; bis zur ersten Ausführung bleiben diese Schritte unerprobt.

Die nächste Automatisierung setzt bei den bereits geprüften, ausdrücklich
veröffentlichten Artefakten an. Der Bau und die Vorbereitung des Releases bleiben
zunächst lokal angestoßen, damit Änderungen am Prüf- und Freigabeablauf weiterhin
gezielt begleitet werden können.

- **Stufe 2 (als Nächstes):** Die Veröffentlichung des privaten GitHub Releases startet
  einen Website-Pull-Request mit genau dessen geprüften Artefakten und Metadaten.
  Kein erneuter Paketbau. Nach Freigabe veröffentlicht der bestehende Pages-Prozess;
  automatisches Zusammenführen bedarf einer gesonderten Entscheidung.
- **Stufe 3 (danach):** Gepushte `R*`-Tags starten nach vollständiger Validierung
  dieselben Bau- und Entwurfsschritte. Keine Änderung der Versionsdateien;
  Veröffentlichung weiterhin ausdrücklich durch einen Menschen.

Diese späteren Workflows und repositoryübergreifenden Zugangsdaten sind noch
nicht eingerichtet.

## Grundsätze

- **Ein Paket entsteht aus genau einem Commit.** Der Build liest nur Objekte
  dieses Commits aus der Git-Datenbank. Geänderte, vorgemerkte und
  unversionierte Dateien im Arbeitsverzeichnis haben keinen Einfluss.
- **Der Inhalt des Archivs ist reproduzierbar:** sortierte Einträge, feste
  Zeitstempel (Commit-Zeit), feste Eigentümer und Modi, feste gzip-Kopfdaten.
  Auf demselben Werkzeugstand (Node.js und zlib) ergibt derselbe Commit auch
  dasselbe Archiv Byte für Byte. Die komprimierten Bytes können sich zwischen
  zlib-Versionen unterscheiden; **maßgeblich für den Inhalt ist `FILES.sha256`** im
  Paket, die SHA-256 des Archivs gilt für die veröffentlichte Datei.
- **Eine Positivliste entscheidet über den Inhalt.** Sie steht in
  [`scripts/release/package-manifest.json`](../scripts/release/package-manifest.json)
  und wird aus dem Commit gelesen, nicht aus dem Arbeitsverzeichnis.
- **Die Version steht in `package.json`.** Sie muss mit `package-lock.json`
  übereinstimmen und eine gültige SemVer-Version sein.

## Positivliste

Jede versionierte Datei gehört zu genau einem Eintrag im Abschnitt `include`
oder `exclude`; ein Eintrag ist ein Dateipfad oder ein Verzeichnis (endet auf
`/`) mit einer kurzen Begründung. Der Build bricht ab, wenn

- eine Datei in keinem Eintrag vorkommt,
- eine Datei in `include` und `exclude` zugleich vorkommt,
- ein Eintrag keine Datei mehr trifft,
- eine Pflichtdatei fehlt (`package.json`, `package-lock.json`, `LICENSE`,
  `NOTICE`, `BRAND-USAGE.md`, `THIRD-PARTY-NOTICES.md`, `README.md`),
- ein eingeschlossener Pfad ein Symlink ist, wie `.env`, `*.pem` oder `*.key`
  heißt (Vorlagen `*.example` ausgenommen) oder einen privaten Schlüssel
  enthält.

Eine neue Datei **außerhalb** der freigegebenen Verzeichnisse verlangt damit eine
bewusste Entscheidung, ob sie ins Paket gehört. Unter den freigegebenen
Verzeichnissen (`app/`, `lib/`, `components/`, `docs/help/`, `drizzle/`, `public/`,
`deploy/`, `scripts/release/`) nimmt die Positivliste neue Dateien dagegen
automatisch auf; dort greift die Kontrolle des Paketinhalts. Ausgeschlossen sind insbesondere `security/`, `tests/`, `.github/`,
`.agents/`, `AGENTS.md`, `CLAUDE.md`, das Entwicklungsprotokoll und die
Testunterlagen.

## Kontrolle des Paketinhalts

Die Datei [`scripts/release/package-files.txt`](../scripts/release/package-files.txt)
listet jede Datei, die das Paket enthalten darf. Der Build vergleicht den
tatsächlichen Paketinhalt des Commits mit dieser Liste und bricht ab, sobald eine
Datei neu im Paket ist oder fehlt. Eine neue Datei unter einem freigegebenen
Verzeichnis erscheint damit als Zeile in der Diff dieser Liste und ist im Review
sichtbar, bevor sie ausgeliefert wird.

- Freigeben oder aktualisieren: `node scripts/release/build-source-package.mjs --commit <ref> --update-file-list`
  schreibt die Liste neu; die Änderung prüfen und mit dem Commit versionieren.
- Vor einer Veröffentlichung: `--since <früherer-ref>` zeigt, welche Dateien
  gegenüber dem Paket des früheren Stands neu sind oder fehlen. Diese Diff wird vor
  dem Upload durchgesehen und in der Freigabe vermerkt.
- Zusätzlich lehnt der Build Dateinamen für Zugangsdaten ab (`.env*`, `.npmrc`,
  `.netrc`, `.pgpass`, `.htpasswd`, `credentials.json`, `*.pem`, `*.key`, `*.p12`,
  `*.pfx`, `*.jks`, `*.keystore`, `id_rsa*` und Verwandte) sowie Inhalte mit
  privaten Schlüsseln, age-Identitäten, AWS-Zugangsschlüsseln, GitHub-, Slack- und
  `sk_live_`-Token.

Die Kontrolle ersetzt nicht die inhaltliche Durchsicht der Dateien: Sie stellt sicher,
dass jede ausgelieferte Datei bewusst in der Liste steht.

## Commitbasierter Entwicklungsbau

Dieser Einstieg dient Entwicklungs- und Vergleichsprüfungen. Er prüft keine
Tag-Zuordnung und erzeugt weder die externe Metadatendatei noch einen GitHub-
Entwurf. Für Releases den oben beschriebenen `npm run release:build` verwenden.

```bash
node scripts/release/build-source-package.mjs --commit <ref> [--out-dir dist/release]
```

Der Commit ist Pflicht. Der Build prüft zuerst, dass die Dateien des Builders
(`scripts/release/*`, `scripts/license-allowlist.mjs`) im Arbeitsverzeichnis
und im Commit identisch sind. Andernfalls hinge das Ergebnis vom lokalen
Skriptstand ab, und der Build bricht ab; er ist dann mit einem Checkout des
Commits auszuführen.

Ein veröffentlichtes Paket entsteht aus einem ausdrücklich ausgewählten,
getaggten Commit in der Historie von `main`: `RELEASE.json` trägt den Commit,
und er muss dem geprüften Stand entsprechen. Das Skript `tests/release/source-package.test.ts` prüft den
Builder gegen `HEAD`; bei ungesicherten Änderungen an `scripts/release/*` zuerst
committen, dann testen oder bauen.

Ausgabe in `dist/release/` (nicht versioniert):

| Datei | Inhalt |
|---|---|
| `paolo-sms-R<version>.tar.gz` | das Paket, alle Pfade unter `paolo-sms-R<version>/` |
| `SHA256SUMS` | SHA-256 des Archivs im `sha256sum`-Format |

## Zusätzliche Dateien im Paket

Der Build ergänzt drei erzeugte Dateien, die nicht im Repository stehen dürfen:

- `RELEASE.json`: Name, Version, Release-Tag (`releaseTag`, bei der historischen
  Pilotkennung `null`), vollständiger Commit, Commit-Datum, Lizenz,
  höchste Migration (`latestMigration`), Anzahl der Migrationen,
  `backupSchemaVersion` aus `lib/backup/constants.ts` und die SHA-256 der
  Positivliste. Bei der historischen Pilotkennung beschreibt `null` nur den
  heutigen Entwicklungsbau; die bereits veröffentlichte Datei bleibt unverändert.
- `FILES.sha256`: SHA-256 jeder Datei im Paket außer ihr selbst.
- `THIRD-PARTY-LIST.md`: Pakete mit Lizenz und Verwendung, erzeugt aus dem
  `package-lock.json` des Commits.

## Paket prüfen

```bash
sha256sum -c SHA256SUMS
tar -xzf paolo-sms-R<version>.tar.gz
cd paolo-sms-R<version> && sha256sum -c FILES.sha256 --quiet
```

`RELEASE.json` nennt den Commit. Mit dem Entwicklungsrepository lässt sich das
Paket aus diesem Commit neu bauen. Unter demselben Node.js-/zlib-Werkzeugstand
muss dieselbe SHA-256 entstehen; bei anderer zlib-Version die Dateiinhalte über
`FILES.sha256` vergleichen.

## Lizenz und Drittanbieterhinweise

- `LICENSE`, `NOTICE`, `BRAND-USAGE.md` und `THIRD-PARTY-NOTICES.md` werden
  unverändert aus dem Commit übernommen. Die Logos, die `NOTICE` von der
  GPL-Gewähr ausnimmt, liegen wie im Docker-Image unter `public/` und als
  `app/icon.png` vor. Interne Gestaltungs- und Herkunftsunterlagen gehören
  weder zum Repository noch zum Paket.
- `THIRD-PARTY-LIST.md` gehört zum Lockfile desselben Commits. Der Build
  bricht ab, wenn das Lockfile ein Paket ohne Lizenzangabe oder mit einer
  Lizenz außerhalb von
  [`scripts/license-allowlist.mjs`](../scripts/license-allowlist.mjs) enthält.
  Die Liste gilt für alle Pakete im Lockfile, also auch Entwicklungs- und
  optionale Plattformpakete. Die Allowlist wird auch von
  `npm run licenses:check` verwendet und nur nach Prüfung erweitert.
- Die Lizenztexte der Pakete liegen in den Paketverzeichnissen, die `npm ci`
  installiert; das Paket enthält sie nicht selbst.

## Datenbank und Rücknahme eines Updates

Das Paket enthält den vollständigen, geprüften Migrationssatz
(`drizzle/`, `scripts/migrate.psql`). `RELEASE.json` nennt dessen letzte
Migration. Ein Wechsel auf eine ältere Paketversion macht keine
Datenbankmigration rückgängig: Der Anwendungscode läuft dann gegen ein neueres
Schema. Das ist **nur** zulässig, wenn die Kompatibilität der älteren Version
mit dem migrierten Schema nachgewiesen ist, etwa bei rein additiven
Änderungen, die der ältere Code nicht benötigt. Andernfalls bleibt die
Wiederherstellung von Datenbank und Anhängen aus der Sicherung vor dem Update
(siehe [`backup-restore.md`](backup-restore.md) und
[`runbooks/production-docker-update.md`](runbooks/production-docker-update.md)).
Das Update-Konzept für Pakete muss dies je Release festhalten.

## Bekannte Grenzen

- `package.json` enthält Skripte für Entwicklungswerkzeuge, die im Paket fehlen
  (`e2e:*`, `demo:rebuild`, `help:generate`, `test:*`). Für den Betrieb gelten die
  Befehle der Anleitungen.
- Relative Markdown-Verweise im Paket zeigen nur auf Dateien im Paket; ein Test
  prüft das am echten Repository. Der Build meldet Abweichungen zusätzlich als Hinweis.
- Die Erstinstallation aus dem Paket steht in
  [`install-from-package.md`](install-from-package.md). Das Update aus dem Paket
  beschreibt [`update-from-package.md`](update-from-package.md);
  `runbooks/production-docker-update.md` gilt für Git-Installationen.
- Anhänge sind in der Sicherung nicht enthalten (siehe `backup-restore.md`).
- Das Paket ist nicht signiert; die SHA-256 sichert nur die Unversehrtheit
  gegenüber einem getrennt veröffentlichten Wert.
