# Rollen: Zweck, Aufgaben und Grenzen (fachlich)

Fachliche Soll-Beschreibung der fünf Zugriffsstufen von PAOLO SMS
(unangemeldeter Melder, Benutzer/Mitglied, Safety Assistant, Safety Manager,
Administrator) — je Rolle Zweck, typische Aufgaben, dafür notwendige Rechte und
bewusste Grenzen. Fachliche Verantwortung und technische Berechtigung sind
getrennt geführt, damit die Beschreibung gegen die aus dem Code erhobene
Berechtigungsmatrix abgeglichen werden kann.

Die Beschreibung stammt aus dem SMS-Wiki des Projekts. Verweise auf reine
Wiki-Seiten (ICAO-Herleitung, DHV-Rückmeldungen, Begriffsdiskussionen) sind
hier zu Klartext aufgelöst; verlinkt ist, wo es ein Gegenstück im Repository
gibt.

## Verhältnis zu den anderen Rollendokumenten

Drei Dokumente beschreiben Rollen, aus drei verschiedenen Richtungen:

| Dokument | Frage | Verbindlichkeit |
|---|---|---|
| dieses Dokument | Wozu ist eine Rolle da, und welche Rechte braucht sie dafür? | fachliches **Soll**, keine Durchsetzung |
| [`roles-and-permissions.md`](roles-and-permissions.md) | Welches Modell setzt der Code um, und warum so? | **Ist**, aus dem Code beschrieben |
| [`permission-matrix.md`](permission-matrix.md) | Welche Rolle darf welche einzelne Aktion? | **Ist**, Referenztabelle je Berechtigung |

Weicht dieses Dokument von den beiden anderen ab, ist das ein Befund — entweder
eine offene Anforderung oder ein Fehler in der Beschreibung. Maßgeblich für die
Durchsetzung ist immer der Code. Die Bedienung aus Rollensicht steht in
[`help/`](help/README.md).

---

## Zweck und Lesart dieser Seite

Diese Seite beschreibt, **wozu** eine Rolle da ist und **welche Rechte sie dafür braucht** — nicht, welche Rechte sie technisch hat. Der Ist-Stand liegt als erhobene Berechtigungsmatrix im Repo ([`permission-matrix.md`](permission-matrix.md), 55 atomare Berechtigungen, erhoben mit `main` @ `aee7715` vom 2026-08-25); maßgeblich für die Durchsetzung ist die Fähigkeitentabelle `ROLE_CAPABILITIES` in `lib/constants/roles.ts`.

Zwei Trennungen ziehen sich durch alle Beschreibungen:

- **Fachliche Verantwortung ≠ technische Berechtigung.** Eine Aufgabe kann fachlich zur Rolle gehören, ohne dass PAOLO dafür ein Recht vorsieht (Beispiel: Sicherheitsbesprechungen durchführen), und ein Recht kann technisch bestehen, ohne fachlich vorgesehen zu sein (Beispiel: der Administrator kann alle Meldungen lesen).
- **Konto ≠ Rolle.** Ein angemeldetes Konto **ohne** zugewiesene PAOLO-Rolle sieht exakt dasselbe wie ein anonymer Besucher. Erst die Rollenzuweisung über `/dashboard/users` erzeugt Zugriff. (Siehe „Konten ohne Rolle" in [`roles-and-permissions.md`](roles-and-permissions.md).)

| Fachliche Rolle | Technische Rolle | Anmeldung |
|---|---|---|
| Melder (jede Person) | — (öffentliches Formular) | nein |
| Benutzer / Mitglied | `member` | ja |
| Safety Assistant | `instructor` | ja |
| Safety Manager | `safety_manager` | ja |
| Administrator (SysAdmin) | `admin` | ja |
| Accountable Executive | **keine** | — |

Der Accountable Executive (verantwortliche Leitung) ist bewusst **keine** PAOLO-Rolle: Er trägt die übergeordnete Verantwortung für die organisatorischen Voraussetzungen und die Funktionsfähigkeit des SMS (Sicherheitsrichtlinie, Mittelzuteilung, Festlegung der akzeptablen Risikogrenzen), nicht die Verantwortung für die Sicherheit jedes einzelnen Fluges. Im Verein kann ein entsprechend benanntes Vorstandsmitglied die Funktion wahrnehmen, in der Flugschule etwa der Geschäftsführer oder Ausbildungsleiter, jeweils im Rahmen der bestehenden Befugnisse. Sie wird organisatorisch, nicht per Software wahrgenommen. Die dokumentarische Erfassung der Benennung unter `/dashboard/settings` erzeugt ausdrücklich keine Programmberechtigung und ersetzt keine organisatorische Bestellung.

---

## 1. Melder — jede Person, ohne Anmeldung

**Zweck**: Die Meldeschwelle so niedrig wie möglich halten. Für das Abgeben einer Sicherheitsmeldung ist **keinerlei Berechtigung** nötig — das ist eine bewusste Entscheidung, keine Lücke. Sie stützt sich auf die ICAO-Systematik freiwilliger Meldesysteme und die Redlichkeitskultur.

**Typische Aufgaben**

- Sicherheitsmeldung abgeben (sechs Meldetypen; Pflichtfelder nur Kurzbeschreibung und Beschreibung).
- Melderangaben freiwillig ergänzen — leer lassen heißt anonym melden.
- Öffentliche Sicherheitsinformationen lesen (`/communications`).

**Notwendige Rechte in PAOLO**

- Meldung anlegen über das öffentliche Formular (`/submit-report`) — ohne Sitzung.
- Lesen von SMS-Dokumenten der Sichtbarkeitsstufe **exakt `public`** auf `/communications`.
- Download **ausdrücklich freigegebener** Anhänge öffentlicher Mitteilungen.

**Bewusste Grenzen**

- **Kein Datei-Upload** ohne Anmeldung — bewusst zur Verkleinerung der Angriffsfläche. Anhänge laufen über den Safety Manager; der Umweg per E-Mail hebt die Anonymität auf.
- **Rate Limit** (Voreinstellung fünf angenommene Meldungen je Anschluss und Stunde, pseudonymisierter Identifier); ist die Prüfung selbst nicht möglich, lehnt das System sicherheitshalber ab. Betrieb und Konfiguration: [`runbooks/public-report-rate-limit.md`](runbooks/public-report-rate-limit.md).
- Kein Zugriff auf die eigene Meldung nach dem Absenden, kein Statuseinblick, keine individuelle Rückmeldung.
- Ein Anhang wird **nicht** automatisch öffentlich, wenn die Mitteilung öffentlich wird — beides sind getrennte Freigaben.

**[offen] Melder-Rückkanal.** ICAO verlangt Rückmeldung an Meldende **ohne Größenvorbehalt** (Doc 9859 9.4.4.7); PAOLO hat dafür bisher nur die statische Vorlage „Rückmeldung an Melder", keine Funktion. Beim anonymen Meldeweg ist der individuelle Rückkanal technisch ausgeschlossen; der gangbare Ersatz ist die **öffentliche** Rückmeldung über `/communications`.

---

## 2. Benutzer / Mitglied (`member`)

**Zweck**: Mitglieder der Organisation, die aufgrund bekundeten Interesses ein Konto **und eine zugewiesene Rolle** erhalten haben. Nutzen der Anmeldung ist der Zugang zu Sicherheitsinformationen, die nur für Mitglieder bestimmt sind — nicht die Mitarbeit im SMS.

**Typische Aufgaben**

- Melden wie jede Person (siehe Rolle 1) — die Anmeldung ändert daran nichts.
- Interne Sicherheitsinformationen der Stufe **Mitglieder** lesen und deren Anhänge herunterladen.

**Notwendige Rechte in PAOLO**

- Alles aus Rolle 1.
- Lesen von SMS-Dokumenten der Stufen `public` **und** `members` auf `/communications`.
- Download der Anhänge dieser Dokumente (Anhänge erben die Sichtbarkeit ihres Dokuments).

**Bewusste Grenzen**

- **Kein Dashboard-Zugang.** Die internen Seiten sind über `hasReportReadRole` geschützt (Maßnahmen über `hasMeasureReadRole`, Zugangs- und Rollenverwaltung über `canManageRoles` — für `member` mit derselben Wirkung); der Aufruf endet mit HTTP 404 und einer deutschen Erklärseite samt Abmelde-Button.
- Kein Zugriff auf `staff`- oder `confidential`-Dokumente, keine Bearbeitung, keine Rollenverwaltung.
- Die Stufe `members` ist **offener** als `staff`: Sie adressiert die gesamte angemeldete Mitgliedschaft, `staff` nur den Bearbeiterkreis.

**[offen] Reduzierte Meldenden-Ansicht.** Eine Ansicht „eigene Meldungen einsehen, vervollständigen, eigene Anhänge hochladen" ist beschrieben, aber nicht umgesetzt (siehe „Bekannte Einschränkungen" in [`roles-and-permissions.md`](roles-and-permissions.md)). Sie ist der naheliegende zweite Nutzen der Anmeldung und hängt fachlich mit dem Rückkanal aus Rolle 1 zusammen.

---

## 3. Safety Assistant (`instructor`)

**Zweck**: Eine bewusst ausgewählte, vertrauenswürdige und kompetente Ansprechperson in der Organisation, die den Stand des Sicherheitsmanagements **kennen** muss, um im Ausbildungs- und Flugbetrieb danach zu handeln — ohne selbst am SMS-Regelkreis mitzuarbeiten. Der Kreis soll klein bleiben; das ist eine organisatorische Festlegung, die PAOLO nicht erzwingt.

**Grundsatz: einsehen, nicht bearbeiten.** Klassifizieren, Bewerten, Freigeben und Veröffentlichen bleiben beim Safety Manager.

**Typische Aufgaben**

- Melden wie jede Person; zusätzlich Material zu bestehenden Meldungen beisteuern.
- Sich über Meldungslage, offene und überfällige Maßnahmen sowie den Stand der Sicherheitsbesprechung informieren.
- Interne SMS-Dokumente lesen und im Betrieb anwenden (Notfallpläne, Checklisten, Sicherheitsrichtlinie).
- Neuen Mitgliedern die Mitglieds-Rolle geben.

**Notwendige Rechte in PAOLO**

- Alles aus Rolle 2.
- `reports.read`, `measures.read`, `documents.read` — internes Dashboard, Meldungsliste und -detail, Maßnahmen, Dokumente.
- Lesen der Dokumentstufen `staff`, `members`, `public` — **nicht** `confidential`.
- `attachments.access`: Anhänge **an Meldungen** hoch- und herunterladen (Bilder, Videos, IGC-/GPS-Tracks).
- `roles.manage`, begrenzt auf die Zielrolle `member`. Die Zugangsaktion „Anmeldelink erneuern“ (`accounts.access`) gehört **nicht** dazu.

**Ausdrücklich nicht** — Ü1 aus Issue #50, entschieden:

- `reports.reporter.read` — die strukturierte Melderidentität (Name, Rolle, Kontakt).
- `reports.notes.read` — interne Notizen und Nachträge.

Beide liegen auf `EDITORS`. Es entsteht dadurch **keine fünfte Rollenmenge**; die dokumentierte Invariante bleibt.

**Bewusste Grenzen**

- Keine Bearbeitung: Meldungen und Maßnahmen weder ändern noch klassifizieren, ausblenden oder löschen; Dokumente weder anlegen noch in der Sichtbarkeit ändern.
- **Anhänge an SMS-Dokumenten/Mitteilungen kann er nicht verwalten** — anders als bei Meldungs-Anhängen erfordern Hochladen, Löschen und Freigeben `hasSafetyEditRole`; der Verwaltungsbereich wird dem Safety Assistant gar nicht angezeigt. **Herunterladen** kann er sie im Rahmen der geerbten Dokumentsichtbarkeit (`canServeToSession`, also bis einschließlich `staff`).
- Keine vertraulichen Dokumente, keine Einstellungen, kein Audit-Log, keine Datenschutzprozesse, kein CSV-Import/-Export, kein Hard Delete.
- Keine Kontoanlage und keine Zugangsaktionen. Bestehenden, verwaltbaren Konten darf die Rolle Benutzer zugewiesen werden.
- Rollenverwaltung nur nach unten: `safety_manager` oder `instructor` kann er nicht vergeben.

**Rollenbegriff — entschieden.** Die Rolle heißt **Safety Assistant**. „Fluglehrer" passte nicht für Vereine ohne Fluglehrer und legte zudem eine fachliche Funktion nahe, die die Rolle nicht voraussetzt. Gegen eine kontextabhängige Beschriftung (Flugschule: *Fluglehrer*, Verein: *Safety Assistant*) spricht, dass ein konfigurierbares Label denselben Rechteumfang unter wechselnden Namen ausliefert. Der notierte Einwand gegen „Safety Assistant" (Verwechslung mit einem KI-Assistenten) wurde abgewogen und zurückgestellt. Der technische Schlüssel bleibt `instructor` (siehe unten).

**Ü1 Rechteumfang — entschieden.** Die Rolle sieht **keine** strukturierte Melderidentität und **keine** internen Notizen.

Die Begründung liegt nicht in der Person, sondern in der Aufgabe. Vertrauenswürdigkeit senkt das Risiko eines Missbrauchs, begründet aber keinen Zweck; erforderlich ist, was die Aufgabe verlangt. Diese Rolle klassifiziert nicht, bewertet nicht, entscheidet nicht und meldet nicht an die meldende Person zurück — für keinen dieser Schritte braucht sie deren Identität. Hinzu kommt: Der Interessenkonflikt „ist häufig selbst Gegenstand einer Meldung" ist hier **vermeidbar**, anders als beim Safety Manager, der die Meldung bearbeiten muss.

Interne Notizen tragen den Bearbeitungsdiskurs — Verdachtsmomente, Bewertungen von Personen, Namen Dritter — und nennen ihren Verfasser. Was der Safety Assistant kennen soll, gehört in Beschreibung, Klassifikation, Maßnahme oder Sicherheitshinweis, nicht in eine interne Notiz.

**Was die Entscheidung nicht leistet.** Freitexte, Anhänge und das Feld `assignedToText` an Maßnahmen können weiterhin Personen erkennbar machen; darauf behält die Rolle Zugriff, weil das der sicherheitsfachliche Inhalt ist. Entfallen ist die **mühelose, strukturierte** Identifikation und der Bearbeitungsdiskurs — nicht jede Erkennbarkeit. Der Rest bleibt eine Frage der Schreibdisziplin und der Datenschutzprüfung nach Abschluss.

**Nebenwirkung, bewusst in Kauf genommen.** Fragt jemand die Ansprechperson „ist meine Meldung angekommen?", kann sie die Meldung inhaltlich finden, das Melderfeld aber nicht bestätigen. Die Rückfrage gehört zum Safety Manager.

---

## 4. Safety Manager (`safety_manager`)

**Zweck**: Die vom Accountable Executive beauftragte Person für die **operative Umsetzung und Aufrechterhaltung des SMS** — Planung, Durchführung und Überwachung aller Maßnahmen zur **Flugsicherheit** der Organisation (ICAO Annex 19 App. 2 §1.3). Die Verantwortung ist delegierbar (*responsibility*); die Führungsverantwortung für das System bleibt beim Accountable Executive (*accountability*).

### Fachliche Verantwortung (unabhängig von PAOLO)

- Sich **proaktiv** für die Sicherheit einsetzen und Ansprechpartner für Sicherheitsfragen sein.
- Meldungen entgegennehmen, ihre Vervollständigung unterstützen, sie analysieren und klassifizieren.
- Gefahrenerkennung und Risikoanalyse durchführen oder moderieren.
- Regelmäßige Sicherheitsbesprechungen vorbereiten, dokumentieren und nachhalten; dafür sorgen, dass dort Maßnahmen beschlossen und umgesetzt werden.
- Umsetzung der Maßnahmen verfolgen und nach angemessener Zeit ihre **Wirksamkeit** prüfen, gegebenenfalls nachsteuern.
- Richtlinien, Checklisten und Notfallpläne entsprechend anpassen.
- Sicherheitsinformationen an die betroffenen Zielgruppen kommunizieren.
- **Unabhängig** in Sicherheitsfragen beraten und Branchenthemen verfolgen (DHV-Sicherheitsmitteilungen, Unfallberichte, [FIDA](fida-source-mapping.md)-Auswertungen).
- Datenschutz und Dokumentation des SMS sicherstellen.

**Abgrenzung nach oben — nicht seine Entscheidung**: die Festlegung der akzeptablen Risikogrenzen, die Zuteilung von Mitteln und die Befugnis, den Flugbetrieb oder eine Veranstaltung einzustellen. Diese liegen beim Accountable Executive und sind nicht delegierbar (Doc 9859 9.3.5.6). Der Safety Manager bereitet solche Entscheidungen vor und setzt sie um.

**Leitung der Sicherheitsbesprechung**: ICAO empfiehlt ausdrücklich, dass der **Accountable Executive** die regelmäßigen Sicherheitsbesprechungen **selbst leitet** — das ist der wirksamste Ausdruck sichtbarer Führungsverpflichtung (Doc 9859 9.3.4.1). Der Safety Manager organisiert, bereitet vor und protokolliert. **[offen]** — wird es im Verein bewusst anders gehandhabt, sollte das in der Sicherheitsrichtlinie begründet stehen, statt stillschweigend zu passieren.

**Interessenkonflikt**: Im Luftsport ist der Safety Manager in aller Regel selbst aktiver Pilot, oft Fluglehrer oder Geländeverantwortlicher — der von ICAO genannte dritte Konfliktfall (operative Rolle *und* Bewertung des eigenen Bereichs) ist damit **Normalzustand, nicht Ausnahme**. Er ist zu benennen, nicht wegzudefinieren; für heikle Fälle ist externe Beteiligung vorzusehen.

**Begriffliche Grenze**: „Sicherheit **und Gesundheitsschutz**" beschreibt den deutschen Arbeitsschutz (Fachkraft für Arbeitssicherheit, ArbSchG/DGUV) — eine andere Rolle mit anderer Rechtsgrundlage. Der Safety Manager nach ICAO ist für die **Flugsicherheit** zuständig. Beide Funktionen können in einer Person zusammenfallen, sollten aber nicht in einer Beschreibung vermischt werden.

### Notwendige Rechte in PAOLO

- Alles aus Rolle 3 — **plus vollständige Bearbeitung** (`hasSafetyEditRole`).
- Meldungen bearbeiten, klassifizieren, Status und Priorität setzen, Notizen führen, Melderangaben ergänzen.
- Risikobewertung (ICAO-5×5-Matrix) eintragen.
- Maßnahmen anlegen, zuordnen, mit Verantwortlichem, Frist und Status verfolgen, abschließen.
- Sicherheitsbesprechungen anlegen und protokollieren (deterministische Protokoll-Vorausfüllung).
- SMS-Dokumente anlegen, bearbeiten, Sichtbarkeit setzen (alle vier Stufen), löschen; **Anhänge an Mitteilungen** hochladen und einzeln öffentlich freigeben — mit Checkliste und Freigabevermerk (mind. 10 Zeichen), beides protokolliert.
- Vertrauliche Dokumente lesen.
- Datenschutzfunktionen: Melder-Anonymisierung, Datenschutzvorfälle, Betroffenenanfragen, rechtliche Angaben, Aufbewahrungsprüfung — Betrieb siehe [`privacy-operations.md`](privacy-operations.md).
- Einstellungen und Audit-Log; Soft Delete, Papierkorb und kontrollierter Hard Delete.
- FIDA-JSON-Export (bewusst auch für diese Rolle freigegeben, anders als der CSV-Export).
- Rollenverwaltung: `instructor` und `member` verwalten, bis `safety_manager` heraufstufen.

### Bewusste Grenzen

- **Kein CSV-Import und -Export** — Admin-only.
- **Keine Administrator-Rolle vergeben** und **die `safety_manager`-Rolle nicht entziehen**.
- Kein Backup-/Restore-Bereich, keine systemtechnische Verwaltung.
- `staff`- und `confidential`-Dokumente erscheinen **unter keinen Umständen** auf `/communications` — auch nicht für ihn.

---

## 5. Administrator / SysAdmin (`admin`)

**Zweck**: Zuständig für Installation, technische Betreuung und den reibungslosen Betrieb der PAOLO-SMS-Instanz. Die Rolle ist **fachlich eine Betriebsrolle, technisch die Vollzugriffsrolle**.

**Typische Aufgaben**

- Installation, Konfiguration und Aktualisierung der Instanz (Docker/nativ, Auth-Provider, Dateispeicher).
- Backups einrichten, überwachen und im Ernstfall zurückspielen.
- Kontenanlage im Verzeichnisdienst (Clerk/Better Auth) und Vergabe der Rollen, die der Safety Manager nicht vergeben darf.
- Datenübernahme per CSV-Import/-Export.
- Störungsbehebung.

**Notwendige Rechte in PAOLO**

- `admin.only`: CSV-Import (`/dashboard/import`) und -Export (`/api/export/reports`). Der Backup-Bereich (`/dashboard/admin/backup`) läuft über die eigene Prüfkette `requireGlobalAdmin`, die sich aus `hasAdminRole` ableitet, aber über globale Rollen liest.
- Alle Rollen zuweisen und entfernen (einschließlich `admin` und Entzug von `safety_manager`), im Rahmen des Last-Admin-Schutzes.
- Technisch zusätzlich alles, was der Safety Manager kann: Die Fähigkeitentabelle kennt nur drei Rollenmengen (`{admin}`, `{admin, safety_manager}`, `{admin, safety_manager, instructor}`) — eine rein technische Rolle ohne fachlichen Datenzugriff ist darin **nicht** vorgesehen.

**Bewusste Grenzen**

- **Fachlich soll der Administrator nicht am SMS-Regelkreis mitarbeiten** — Klassifizierung, Risikobewertung, Veröffentlichung und Datenschutzentscheidungen gehören dem Safety Manager. Diese Grenze ist **organisatorisch**, nicht technisch durchgesetzt. **[offen]**: ob das so bleibt oder ein Betriebskonto ohne inhaltlichen Datenzugriff eingeführt wird.
- **Restore läuft ausschließlich über eine bestätigungsgeschützte CLI**, nicht über das Web-UI; Backups enthalten **keine Anhänge** (`attachmentsIncluded: false`) und sind zwingend `age`-verschlüsselt. Ablauf: [`backup-restore.md`](backup-restore.md).
- Kontoanlage liegt im Verzeichnisdienst **außerhalb** der PAOLO-Datenbank und kann nicht mit der Rollenzuweisung zusammen zurückgerollt werden — scheitert die Zuweisung, bleibt ein rollenloses Konto zurück (auffindbar in der Kontenliste mit dem Status „Ohne Rolle").
- **Konten lassen sich ändern und löschen** (#114): Administrator und Safety Manager im Zuständigkeitsbereich der Rollenverwaltung, nicht der Safety Assistant, nie das eigene Konto, die Löschung nie bei einer Administratorrolle.
- **PAOLO kennt kein Konzept „Konto deaktivieren"**; der Entzug der letzten Rolle ist gesperrt und wird ausdrücklich nicht als Ersatz verwendet.
- `staff`/`confidential` erscheinen auch für den Administrator nie auf `/communications`.

**[offen] Mandantenfähigkeit.** Die Annahme „falls die Instanz mehrere Organisationen umfasst, ist der Administrator mandantenübergreifend zuständig" beschreibt einen Zustand, den es **nicht gibt**: Org-Scoping ist im Datenmodell vorbereitet (`user_roles.organization_id`, NULL = global), nach Rücksprache mit dem DHV aber **bewusst zurückgestellt** (Rechtsunsicherheit bei Verantwortlichkeit/Auftragsverarbeitung, fehlende Betriebskapazität). Alle Rollen sind derzeit **global**. Der Satz sollte entfallen oder ausdrücklich als Zukunftsfall markiert werden — Analyse in [`organization-scoping.md`](organization-scoping.md).

---

## Register offener Rollenfragen

**Dies ist die einzige Sammelstelle für offene Fragen zu Rollen und
Berechtigungen im Projekt.** Weder
[`roles-and-permissions.md`](roles-and-permissions.md) noch
[`permission-matrix.md`](permission-matrix.md) führen solche Punkte — beide
beschreiben den Ist-Zustand und begründen ihn, ohne ihn zu bewerten. Auch
[`data-protection-concept.md`](data-protection-concept.md) verweist für den
offenen Rollenumfang hierher.

Der vollständige Abgleich von Soll, Matrix und Code vom 27.08.2026 hat elf
Abweichungen ergeben. Sie sind in **Issue #50** erfasst, getrennt nach „braucht
eine fachliche Entscheidung" (acht) und „risikoarm direkt ableitbar" (zwei);
eine ist erledigt. Die Tabelle unten führt die Fragen, die schon vor diesem
Abgleich offen waren — Issue #50 ergänzt sie.

| # | Punkt | Rolle | Verweis |
|---|---|---|---|
| 1 | ~~Rechteumfang von `instructor`~~ — Ü1 entschieden: keine Melderidentität, keine internen Notizen. Der Begriff ist mit *Safety Assistant* entschieden. **Ü3 ist mit #128 entschieden:** keine Kontoanlage durch Safety Assistants; nur Rollenzuweisung an bestehende, verwaltbare Konten. **Offen bleibt U1** (eigenen Fehl-Upload zurücknehmen). | 3 | Issue #50 |
| 2 | Melder-Rückkanal — ICAO-Anforderung ohne Größenvorbehalt, in PAOLO nur als Vorlage | 1 | SMS-Wiki: Sicherheitskommunikation |
| 3 | Reduzierte Meldenden-Ansicht für angemeldete Melder | 2 | [`roles-and-permissions.md`](roles-and-permissions.md) |
| 4 | Leitung der Sicherheitsbesprechung: Accountable Executive (ICAO-Empfehlung) oder Safety Manager | 4 | SMS-Wiki: Accountable Executive |
| 5 | Administrator: fachliche Enthaltsamkeit organisatorisch regeln oder technisch trennen? | 5 | — |
| 6 | Mandantenfähigkeit — zurückgestellt, im Entwurf aber vorausgesetzt | 5 | [`organization-scoping.md`](organization-scoping.md) |

---

## Pflegehinweis

Dieses Dokument beschreibt das fachliche Soll und wird **nicht** automatisch mit
dem Code aktualisiert. Ändert sich eine Berechtigung, gehören
[`roles-and-permissions.md`](roles-and-permissions.md) und
[`permission-matrix.md`](permission-matrix.md) zwingend mitgezogen; diese Seite
nur dann, wenn sich die fachliche Absicht ändert oder ein hier als „[offen]"
markierter Punkt entschieden wird.

Bei Abweichungen zwischen dieser Seite und den beiden Ist-Dokumenten gilt der
Code. Eine Abweichung ist trotzdem festzuhalten und nicht durch Angleichen der
Beschreibung stillzulegen — sie ist meist eine unerledigte Anforderung.
