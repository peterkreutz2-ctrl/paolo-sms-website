# Nutzung von Name und Logo

Die GNU General Public License, Version 3 oder später, gilt für die Software
PAOLO SMS, nicht jedoch für den Namen „PAOLO“, den Namen „PAOLO SMS“ oder die
PAOLO-SMS-Logos. Der Vorbehalt und die betroffenen Dateien stehen in
[`NOTICE`](NOTICE).

Diese Richtlinie erteilt eine eigenständige, unentgeltliche und bedingte
Erlaubnis zur Nutzung von Name und unverändertem Logo. Sie ist keine
Erweiterung der GPL.

## Erlaubte Nutzung

Name und unverändertes Logo dürfen für einen Fork von PAOLO SMS verwendet
werden, wenn alle folgenden Voraussetzungen erfüllt sind:

- Der Fork wird als Safety Management System für einen Gleitschirmverein oder
  eine Flugschule eingesetzt.
- Er dient weiterhin einer niederschwelligen, nicht-punitiven Meldekultur und
  der strukturierten Sicherheitsarbeit.
- Die Abweichungen dienen organisationsspezifischen Anforderungen oder
  technischen Betriebsentscheidungen, beispielsweise einem anderen
  Authentifizierungsverfahren oder Dateispeicher.
- Der Betreiber kennzeichnet die Fassung als eigene Anpassung und erweckt
  nicht den Eindruck, sie werde vom offiziellen PAOLO-SMS-Projekt betrieben,
  geprüft, zertifiziert oder unterstützt.

Die Erlaubnis gilt auch für beauftragte IT-Dienstleister und für deren
entgeltliche Entwicklung oder Betreuung einer solchen Installation.

## Herkunfts- und Abgrenzungshinweis

Der folgende Hinweis muss mindestens in der Projektdokumentation und im
Impressum oder an einer vergleichbar gut auffindbaren Stelle der Anwendung
erscheinen:

> Diese Anwendung basiert auf PAOLO SMS. Name und Logo werden gemäß der
> PAOLO-SMS-Nutzungsrichtlinie verwendet. Diese angepasste Fassung wird
> eigenständig betrieben und nicht vom offiziellen PAOLO-SMS-Projekt betreut
> oder unterstützt.

„PAOLO SMS“ muss dabei auf das offizielle Repository
<https://github.com/peterkreutz2-ctrl/paolo-sms> verweisen.

## Zulässige technische Anpassungen

Das Logo darf proportional skaliert und technisch in ein anderes Dateiformat
umgewandelt werden. Farben, Wort-/Bildgestaltung und Anordnung seiner
Bestandteile dürfen nicht verändert werden. Der Name einer Organisation darf
getrennt neben oder unter dem Logo stehen, darf aber nicht als Bestandteil des
PAOLO-SMS-Logos erscheinen.

Eine veränderte Logoform darf nicht als offizielles PAOLO-SMS-Logo bezeichnet
oder verwendet werden.

## Grenzen

Die Erlaubnis gilt nicht

- für ein vom PAOLO-SMS-Code unabhängiges Produkt,
- für einen sachfremden Einsatz,
- für einen Einsatz, der der nicht-punitiven Sicherheitskultur widerspricht,
  oder
- wenn Herkunft, Verantwortlichkeit oder offizielle Unterstützung irreführend
  dargestellt werden.

Wer die Voraussetzungen nicht mehr erfüllt, muss Name und Logo aus seiner
nächsten Veröffentlichung und aus den von ihm betriebenen Darstellungen
entfernen.

## Keine Rechteprüfung oder Gewähr

Für Name und Logo wurde weder eine Marke oder ein Design angemeldet noch eine
Kollisionsrecherche zu möglichen Rechten Dritter durchgeführt. Es wird nicht
gewährleistet, dass keine Rechte Dritter bestehen. Betreiber, Forks und
Dienstleister tragen das Risiko ihrer konkreten Nutzung selbst.

Eine konkrete Beanstandung durch einen möglichen Rechteinhaber wird von den
PAOLO-SMS-Maintainern neu geprüft. Diese Richtlinie trifft keine Entscheidung
über eine solche Beanstandung.
