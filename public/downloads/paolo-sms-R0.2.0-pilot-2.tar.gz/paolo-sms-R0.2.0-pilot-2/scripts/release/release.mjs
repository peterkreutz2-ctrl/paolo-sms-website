import path from "node:path"
import { fileURLToPath } from "node:url"
import { createInterface } from "node:readline/promises"
import { buildRelease, checkMainVersion, confirmDraft, createTag, draftRelease, prepareVersion } from "./release-workflow.mjs"

const repo = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../..")
const [action, ...args] = process.argv.slice(2)

try {
  switch (action) {
    case "version":
      if (args.length !== 1) throw new Error("Aufruf: npm run release:version -- <version>")
      prepareVersion(repo, args[0])
      console.log("Version vorbereitet. Änderungen prüfen und committen; es wurde kein Tag erstellt.")
      break
    case "tag":
      if (args.length !== 2 || args[0] !== "--commit") throw new Error("Aufruf: npm run release:tag -- --commit <commit>")
      console.log(createTag(repo, args[1]))
      break
    case "build":
      if (args.length) throw new Error("Aufruf: npm run release:build")
      buildRelease(repo)
      break
    case "draft":
      if (args.length && (args.length !== 1 || args[0] !== "--yes")) throw new Error("Aufruf: npm run release:draft [-- --yes]")
      await draftRelease(repo, {
        yes: args.includes("--yes"),
        confirm: async ({ yes }) => confirmDraft({ yes, ask: async () => {
          const input = createInterface({ input: process.stdin, output: process.stdout })
          try { return await input.question("Tag pushen und Release-Dateien hochladen? [j/N] ") }
          finally { input.close() }
        } }),
      })
      break
    case "check-main":
      if (args.length) throw new Error("check-main erwartet keine Argumente.")
      console.log(checkMainVersion(repo))
      break
    default:
      throw new Error("Erwartet: version, tag, build, draft oder check-main.")
  }
} catch (error) {
  console.error(error instanceof Error ? error.message : error)
  process.exitCode = 1
}
