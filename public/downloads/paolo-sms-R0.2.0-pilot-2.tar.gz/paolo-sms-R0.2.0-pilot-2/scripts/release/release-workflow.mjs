import { spawnSync } from "node:child_process"
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmdirSync, rmSync, writeFileSync } from "node:fs"
import { tmpdir } from "node:os"
import path from "node:path"
import { gunzipSync } from "node:zlib"
import { buildSourcePackage, git, resolveCommit, sha256 } from "./source-package-core.mjs"
import { packageVersion, releaseTag, validateVersion } from "./release-policy.mjs"

export const RELEASE_REPOSITORY = "peterkreutz2-ctrl/paolo-sms"

export function command(repo, executable, args, { allowFailure = false, inherit = false } = {}) {
  const result = spawnSync(executable, args, {
    cwd: repo,
    stdio: inherit ? "inherit" : "pipe",
    maxBuffer: 128 * 1024 * 1024,
    windowsHide: true,
  })
  if (!allowFailure && (result.error || result.status !== 0)) {
    // Keine Provider-Antworten oder moeglicherweise sensible Argumente ausgeben.
    throw new Error(`${executable}: Vorgang fehlgeschlagen (Exit ${result.status ?? "unbekannt"}).`)
  }
  return result
}

export function localVersion(repo) {
  return packageVersion(
    JSON.parse(readFileSync(path.join(repo, "package.json"), "utf8")),
    JSON.parse(readFileSync(path.join(repo, "package-lock.json"), "utf8")),
  )
}

export function committedVersion(repo, ref, { allowLegacy = false } = {}) {
  const { sha } = resolveCommit(repo, ref)
  return packageVersion(
    JSON.parse(git(repo, ["show", `${sha}:package.json`]).toString()),
    JSON.parse(git(repo, ["show", `${sha}:package-lock.json`]).toString()),
    { allowLegacy },
  )
}

export function tagCommit(repo, tag) {
  const ref = `refs/tags/${tag}`
  const present = command(repo, "git", ["show-ref", "--verify", "--quiet", ref], { allowFailure: true })
  if (present.status === 1) return null
  if (present.status !== 0) throw new Error("Git-Tags konnten nicht geprüft werden.")
  return resolveCommit(repo, ref).sha
}

export function assertVersionAvailable(repo, version, commit = null) {
  const tag = releaseTag(version)
  const existing = tagCommit(repo, tag)
  if (existing && existing !== commit) {
    throw new Error(`${tag} ist durch Commit ${existing} verbraucht. Eine neue Version ist erforderlich.`)
  }
  return tag
}

export function checkMainVersion(repo, ref = "HEAD") {
  const sha = resolveCommit(repo, ref).sha
  // Die historische Pilotkennung bleibt bis zur naechsten Versionsvorbereitung erlaubt.
  const version = committedVersion(repo, sha, { allowLegacy: true })
  const tag = `R${version}`
  const existing = tagCommit(repo, tag)
  if (existing && existing !== sha) {
    throw new Error(`${tag} ist durch Commit ${existing} verbraucht; main (${sha}) benötigt eine neue Version, zum Beispiel die nächste Patch-Version mit -ib.`)
  }
  return { version, tag, sha }
}

export function prepareVersion(repo, version, { npmCli = process.env.npm_execpath } = {}) {
  validateVersion(version)
  assertVersionAvailable(repo, version)
  if (!npmCli || !existsSync(npmCli)) throw new Error("Bitte über npm run release:version aufrufen.")
  command(repo, process.execPath, [npmCli, "version", version, "--no-git-tag-version"], { inherit: true })
  if (localVersion(repo) !== version) throw new Error("Ein npm-Folgeschritt hat die Zielversion verändert.")
  assertVersionAvailable(repo, version)
}

export function releaseNotes(repo, sha, tag) {
  const notesPath = `docs/release-notes/${tag}.md`
  const notes = git(repo, ["show", `${sha}:${notesPath}`]).toString("utf8")
  if (!notes.trim()) throw new Error(`Release-Notes fehlen: ${notesPath}`)
  return notes
}

export function createTag(repo, ref) {
  if (!ref) throw new Error("--commit <commit> ist erforderlich.")
  const sha = resolveCommit(repo, ref).sha
  const version = committedVersion(repo, sha)
  const tag = assertVersionAvailable(repo, version, sha)
  releaseNotes(repo, sha, tag)
  git(repo, ["fetch", "--no-tags", "origin", "+refs/heads/main:refs/remotes/origin/main"])
  const ancestor = command(repo, "git", ["merge-base", "--is-ancestor", sha, "refs/remotes/origin/main"], { allowFailure: true })
  if (ancestor.status !== 0) throw new Error("Der ausgewählte Commit liegt nicht in origin/main.")
  assertRemoteTag(repo, tag, sha)
  if (!tagCommit(repo, tag)) git(repo, ["tag", "-a", tag, sha, "-m", tag])
  return { version, tag, sha }
}

// Abfrage aktualisiert absichtlich keine lokalen Tags und verschiebt keine Referenzen.
export function assertRemoteTag(repo, tag, sha, run = command) {
  const ref = `refs/tags/${tag}`
  // Fetch- und Push-URL koennen verschieden sein. Massgeblich ist das Uploadziel.
  const remote = git(repo, ["remote", "get-url", "--push", "origin"]).toString().trim()
  const lines = run(repo, "git", ["ls-remote", "--tags", remote, ref, `${ref}^{}`]).stdout.toString().trim()
  if (!lines) return false
  const refs = new Map(lines.split("\n").map((line) => {
    const [object, name] = line.trim().split(/\s+/)
    return [name, object]
  }))
  const remoteSha = refs.get(`${ref}^{}`) ?? refs.get(ref)
  if (remoteSha !== sha) throw new Error(`Remote-Tag ${tag} zeigt auf einen anderen Commit; keine Änderung vorgenommen.`)
  return true
}

export function selectedRelease(repo) {
  const version = localVersion(repo)
  const tag = releaseTag(version)
  const sha = tagCommit(repo, tag)
  if (!sha) throw new Error(`Lokaler Tag ${tag} fehlt. Zuerst release:tag ausführen.`)
  if (committedVersion(repo, sha) !== version) throw new Error(`Version im Tag ${tag} stimmt nicht mit package.json überein.`)
  const notes = releaseNotes(repo, sha, tag)
  return { version, tag, sha, notes }
}

export function describeRelease(repo, selected, log = console.log) {
  log(`Version: ${selected.version}\nTag: ${selected.tag}\nQuellcommit: ${selected.sha}`)
  if (resolveCommit(repo, "HEAD").sha !== selected.sha) {
    log("Hinweis: Der lokale Entwicklungsstand weicht ab. Gebaut bzw. hochgeladen wird ausschließlich der getaggte Stand, einschließlich seiner Release-Notes.")
  }
}

export function artifactNames(tag) {
  return [`paolo-sms-${tag}.tar.gz`, "SHA256SUMS", "release-metadata.json"]
}

function metadataFor(pkg, selected, archive) {
  return {
    version: selected.version,
    releaseTag: selected.tag,
    commit: selected.sha,
    commitDate: pkg.commitDate,
    archiveName: pkg.fileName,
    size: archive.length,
    sha256: sha256(archive),
    license: "GPL-3.0-or-later",
    prerelease: selected.version.includes("-"),
    releaseNotes: selected.notes,
  }
}

export function buildRelease(repo, { log = console.log } = {}) {
  const selected = selectedRelease(repo)
  describeRelease(repo, selected, log)
  const pkg = buildSourcePackage({ repo, ref: `refs/tags/${selected.tag}`, root: repo })
  const metadata = metadataFor(pkg, selected, pkg.archive)
  const outputs = new Map([
    [pkg.fileName, pkg.archive],
    ["SHA256SUMS", Buffer.from(`${pkg.archiveSha256}  ${pkg.fileName}\n`)],
    ["release-metadata.json", Buffer.from(JSON.stringify(metadata, null, 2) + "\n")],
  ])
  const dir = path.join(repo, "dist", "release", selected.tag)
  // Erst alle vorhandenen Dateien pruefen, dann schreiben.
  for (const [name, data] of outputs) {
    const target = path.join(dir, name)
    if (existsSync(target) && !readFileSync(target).equals(data)) throw new Error(`${name} existiert mit anderem Inhalt; keine Datei überschrieben.`)
  }
  mkdirSync(dir, { recursive: true })
  for (const [name, data] of outputs) if (!existsSync(path.join(dir, name))) writeFileSync(path.join(dir, name), data, { flag: "wx" })
  log(`Paket: ${path.join(dir, pkg.fileName)}\nSHA-256: ${pkg.archiveSha256}`)
  return { ...selected, dir, metadata }
}

export function verifyArtifacts(repo, selected = selectedRelease(repo)) {
  const dir = path.join(repo, "dist", "release", selected.tag)
  const archive = readFileSync(path.join(dir, artifactNames(selected.tag)[0]))
  const metadata = JSON.parse(readFileSync(path.join(dir, "release-metadata.json"), "utf8"))
  const expected = buildSourcePackage({ repo, ref: `refs/tags/${selected.tag}`, root: repo })
  // Inhalt gegen den Quellcommit pruefen, ohne ein neues Upload-Artefakt zu erzeugen.
  // Komprimierte Bytes duerfen zwischen zlib-Versionen abweichen.
  if (!gunzipSync(archive).equals(gunzipSync(expected.archive))) throw new Error("Paketinhalt einschließlich Archivstruktur weicht vom Quellcommit ab.")
  const expectedMetadata = metadataFor(expected, selected, archive)
  if (JSON.stringify(metadata) !== JSON.stringify(expectedMetadata)) throw new Error("Release-Metadaten stimmen nicht mit Paket und Tag überein.")
  const sums = readFileSync(path.join(dir, "SHA256SUMS"), "utf8")
  if (sums !== `${metadata.sha256}  ${metadata.archiveName}\n`) throw new Error("SHA256SUMS stimmt nicht mit dem Paket überein.")
  return { dir, metadata }
}

/** @param {{ yes?: boolean, interactive?: boolean, ask?: () => Promise<string> }} [options] */
export async function confirmDraft({ yes = false, interactive = Boolean(process.stdin.isTTY && process.stdout.isTTY), ask } = {}) {
  if (yes) return
  if (!interactive) throw new Error("Keine interaktive Bestätigung möglich. Mit --yes ausdrücklich bestätigen.")
  if (!ask || !/^(j|ja)$/i.test((await ask()).trim())) throw new Error("Upload abgebrochen.")
}

export async function draftRelease(repo, { yes = false, confirm = confirmDraft, run = command, log = console.log } = {}) {
  const selected = selectedRelease(repo)
  const { dir, metadata } = verifyArtifacts(repo, selected)
  const gh = (args, options) => run(repo, "gh", args[0] === "api" ? ["api", "--hostname", "github.com", ...args.slice(1)] : args, options)
  const api = (endpoint) => JSON.parse(gh(["api", endpoint]).stdout.toString())
  // Ausschliesslich das bekannte private Anwendungsrepository; kein Upload in Forks.
  const remote = git(repo, ["remote", "get-url", "--push", "origin"]).toString().trim()
  if (!/^(?:https:\/\/github\.com\/|git@github\.com:|ssh:\/\/git@github\.com\/)peterkreutz2-ctrl\/paolo-sms(?:\.git)?\/?$/.test(remote)) {
    throw new Error("origin ist nicht das private Anwendungsrepository.")
  }
  const target = api(`repos/${RELEASE_REPOSITORY}`)
  if (target.full_name !== RELEASE_REPOSITORY || target.private !== true) throw new Error("Zielrepository ist nicht das erwartete private Repository.")
  assertRemoteTag(repo, selected.tag, selected.sha, run)
  // Der REST-Endpunkt /releases/tags/<tag> garantiert nur veroeffentlichte
  // Releases. Die vollstaendige Liste liefert mit Schreibrechten auch Entwuerfe.
  const findRelease = () => {
    const releases = JSON.parse(gh(["api", "--paginate", "--slurp", `repos/${RELEASE_REPOSITORY}/releases?per_page=100`]).stdout.toString()).flat()
    const matches = releases.filter((item) => item.tag_name === selected.tag)
    if (matches.length > 1) throw new Error("Mehrere Releases verwenden denselben Tag; manuelle Prüfung erforderlich.")
    return matches[0] ?? null
  }
  let release = findRelease()
  const names = artifactNames(selected.tag)
  const missing = []
  if (release) {
    if (!release.draft) throw new Error("Das GitHub Release ist bereits veröffentlicht; keine Änderungen vorgenommen.")
    if (release.tag_name !== selected.tag || release.name !== selected.tag || release.body !== selected.notes || release.prerelease !== metadata.prerelease) {
      throw new Error("Vorhandener Release-Entwurf hat abweichende Metadaten; keine Änderungen vorgenommen.")
    }
    // API-Paginierung: Auch ein Entwurf mit mehr als 100 Anhaengen wird vollstaendig geprueft.
    const assets = JSON.parse(gh(["api", "--paginate", "--slurp", `repos/${RELEASE_REPOSITORY}/releases/${release.id}/assets?per_page=100`]).stdout.toString()).flat()
    if (assets.some((asset) => !names.includes(asset.name))) throw new Error("Release-Entwurf enthält unerwartete Dateien.")
    for (const name of names) {
      const matches = assets.filter((asset) => asset.name === name)
      if (matches.length > 1) throw new Error(`Mehrere GitHub-Dateien heißen ${name}.`)
      if (!matches.length) { missing.push(name); continue }
      const asset = matches[0]
      const bytes = gh(["api", "-H", "Accept: application/octet-stream", `repos/${RELEASE_REPOSITORY}/releases/assets/${asset.id}`]).stdout
      if (!bytes.equals(readFileSync(path.join(dir, name)))) throw new Error(`GitHub-Datei ${name} hat anderen Inhalt; kein Überschreiben.`)
    }
  } else missing.push(...names)
  log(`Zielrepository: ${RELEASE_REPOSITORY} (privat)`)
  describeRelease(repo, selected, log)
  log(`Dateien:\n${names.map((name) => `  ${path.join(dir, name)}`).join("\n")}\nAktion: Tag gegebenenfalls pushen und privaten Release-Entwurf anlegen/ergänzen.`)
  await confirm({ yes })
  // Nach der Rueckfrage lokale Dateien und Remote-Tag erneut pruefen.
  const current = selectedRelease(repo)
  if (current.sha !== selected.sha || current.tag !== selected.tag) throw new Error("Release-Auswahl wurde während der Bestätigung verändert.")
  verifyArtifacts(repo, selected)
  const checkedTarget = api(`repos/${RELEASE_REPOSITORY}`)
  if (checkedTarget.full_name !== RELEASE_REPOSITORY || checkedTarget.private !== true) throw new Error("Zielrepository ist nicht mehr das erwartete private Repository.")
  if (!assertRemoteTag(repo, selected.tag, selected.sha, run)) run(repo, "git", ["push", "origin", `refs/tags/${selected.tag}:refs/tags/${selected.tag}`])
  if (!release) {
    const temp = mkdtempSync(path.join(tmpdir(), "paolo-release-notes-"))
    try {
      const notesFile = path.join(temp, "notes.md")
      writeFileSync(notesFile, selected.notes)
      gh(["release", "create", selected.tag, "--repo", `github.com/${RELEASE_REPOSITORY}`, "--verify-tag", "--draft", "--title", selected.tag, "--notes-file", notesFile, ...(metadata.prerelease ? ["--prerelease"] : [])])
    } finally {
      rmSync(path.join(temp, "notes.md"), { force: true })
      rmdirSync(temp)
    }
  }
  // Nicht aktualisieren, falls ein anderer Benutzer den Entwurf inzwischen veroeffentlicht hat.
  const checkedRelease = findRelease()
  if (!checkedRelease?.draft) throw new Error("Release fehlt oder wurde inzwischen veröffentlicht; Upload abgebrochen.")
  if (checkedRelease.tag_name !== selected.tag || checkedRelease.name !== selected.tag || checkedRelease.body !== selected.notes || checkedRelease.prerelease !== metadata.prerelease) {
    throw new Error("Release-Entwurf wurde inzwischen verändert; Upload abgebrochen.")
  }
  if (missing.length) gh(["release", "upload", selected.tag, "--repo", `github.com/${RELEASE_REPOSITORY}`, ...missing.map((name) => path.join(dir, name))])
  log("Privater Release-Entwurf vorbereitet. Veröffentlichung erfolgt ausdrücklich über GitHub oder gh.")
}
