// Gemeinsame Versionsregeln, ohne npm-Abhaengigkeit.
export const LEGACY_VERSION = "0.2.0-pilot.1"
const NUMBER = "(?:0|[1-9][0-9]*)"
const VERSION = new RegExp(`^${NUMBER}\\.${NUMBER}\\.${NUMBER}(?:-([A-Za-z0-9-]{1,10}))?$`)

export function validateVersion(version, { allowLegacy = false } = {}) {
  if (allowLegacy && version === LEGACY_VERSION) return version
  const match = typeof version === "string" && VERSION.exec(version)
  if (!match || match[0] !== version || (match[1] && /^0[0-9]+$/.test(match[1]))) {
    throw new Error(`Ungültige Release-Version: ${version}. Erwartet: major.minor.patch[-Ergänzung], ohne R; Ergänzung höchstens zehn ASCII-Buchstaben, Ziffern oder Bindestriche.`)
  }
  return version
}

export function packageVersion(pkg, lock, options) {
  const version = validateVersion(pkg.version, options)
  if (lock.version !== version || lock.packages?.[""]?.version !== version) {
    throw new Error("Version in package-lock.json weicht von package.json ab.")
  }
  return version
}

export function releaseTag(version) {
  return `R${validateVersion(version)}`
}

export function packageLabel(version) {
  return version === LEGACY_VERSION ? version : releaseTag(version)
}
