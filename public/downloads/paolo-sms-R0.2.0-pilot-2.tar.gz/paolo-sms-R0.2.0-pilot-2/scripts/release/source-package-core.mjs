// Kern des Quellpaket-Builds. Liest ausschliesslich aus dem Git-Objektspeicher
// eines festen Commits (nie aus dem Arbeitsverzeichnis) und erzeugt daraus
// byte-identische Ergebnisse: sortierte Eintraege, feste Zeitstempel, feste
// Eigentuemer und Modi, feste gzip-Kopfdaten.

import { createHash } from "node:crypto"
import { spawnSync } from "node:child_process"
import { gzipSync } from "node:zlib"

import { COMPATIBLE } from "../license-allowlist.mjs"
import { packageLabel, packageVersion, LEGACY_VERSION } from "./release-policy.mjs"

export const PACKAGE_NAME = "paolo-sms"
export const MANIFEST_PATH = "scripts/release/package-manifest.json"
// Dateien des Builders selbst. Sie muessen im Commit und im Arbeitsverzeichnis
// identisch sein, sonst haengt das Ergebnis vom lokalen Skriptstand ab.
export const BUILDER_PATHS = [
  "scripts/release/build-source-package.mjs",
  "scripts/release/source-package-core.mjs",
  "scripts/release/release-policy.mjs",
  "scripts/release/release-workflow.mjs",
  "scripts/release/release.mjs",
  MANIFEST_PATH,
  "scripts/license-allowlist.mjs",
]
// Muessen im Paket vorhanden sein: GPL-Lizenztext und Hinweise sowie die
// Bedingungen fuer die mitgelieferten, vom GPL-Grant ausgenommenen Marken.
export const REQUIRED_FILES = [
  "package.json",
  "package-lock.json",
  "LICENSE",
  "NOTICE",
  "BRAND-USAGE.md",
  "THIRD-PARTY-NOTICES.md",
  "README.md",
]
// Erzeugte Dateien; duerfen nicht im Repository stehen.
export const GENERATED_FILES = ["RELEASE.json", "THIRD-PARTY-LIST.md", "FILES.sha256"]

// Sicherheitsnetz zusaetzlich zur Positivliste.
const FORBIDDEN_NAME = /(^|\/)(\.env(\..*)?|\.npmrc|\.netrc|\.pgpass|\.htpasswd|\.git-credentials|credentials(\.json)?|.*\.(pem|key|p12|pfx|jks|keystore|kdbx)|id_(rsa|dsa|ecdsa|ed25519).*)$/i
const ALLOWED_ENV_NAME = /(^|\/)\.env[^/]*\.example$|(^|\/)\.env\.example$/
const PRIVATE_KEY = /-----BEGIN [A-Z ]*PRIVATE KEY-----/
// Zugangsdaten mit eindeutiger Form (wenig Fehlalarme). Muster, keine Werte.
const SECRET_PATTERNS = [
  { name: "age-Identitaet", pattern: /AGE-SECRET-KEY-1[A-Z0-9]{50,}/ },
  { name: "AWS-Zugangsschluessel", pattern: /\b(AKIA|ASIA)[0-9A-Z]{16}\b/ },
  { name: "GitHub-Token", pattern: /\bgh[pousr]_[A-Za-z0-9]{36,}\b/ },
  { name: "Slack-Token", pattern: /\bxox[baprs]-[0-9A-Za-z-]{10,}/ },
  { name: "Live-Geheimschluessel (sk_live_)", pattern: /\bsk_live_[0-9A-Za-z]{16,}/ },
  { name: "Google-API-Schluessel", pattern: /\bAIza[0-9A-Za-z_-]{35}\b/ },
]
export const FILE_LIST_PATH = "scripts/release/package-files.txt"

export function git(repo, args, input) {
  const result = spawnSync("git", ["-C", repo, ...args], {
    input,
    maxBuffer: 1024 * 1024 * 1024,
  })
  if (result.status !== 0) {
    throw new Error(`git ${args.join(" ")} fehlgeschlagen: ${result.stderr?.toString().trim()}`)
  }
  return result.stdout
}

export function sha256(data) {
  return createHash("sha256").update(data).digest("hex")
}

export function resolveCommit(repo, ref) {
  const sha = git(repo, ["rev-parse", "--verify", "--end-of-options", `${ref}^{commit}`])
    .toString()
    .trim()
  const commitTime = Number(git(repo, ["show", "-s", "--format=%ct", sha]).toString().trim())
  return { sha, commitTime }
}

export function listTree(repo, sha) {
  const raw = git(repo, ["ls-tree", "-r", "-z", "--full-tree", sha]).toString("utf8")
  return raw
    .split("\0")
    .filter(Boolean)
    .map((line) => {
      const tab = line.indexOf("\t")
      const [mode, type, object] = line.slice(0, tab).split(" ")
      return { mode, type, object, path: line.slice(tab + 1) }
    })
}

// Liest viele Blobs mit einem einzigen git-Aufruf.
export function readBlobs(repo, objects) {
  const out = git(repo, ["cat-file", "--batch"], objects.map((o) => `${o}\n`).join(""))
  const blobs = new Map()
  let offset = 0
  for (const object of objects) {
    const eol = out.indexOf(0x0a, offset)
    const [, type, size] = out.subarray(offset, eol).toString().split(" ")
    if (type !== "blob") throw new Error(`Objekt ${object} ist kein Blob`)
    const start = eol + 1
    blobs.set(object, out.subarray(start, start + Number(size)))
    offset = start + Number(size) + 1
  }
  return blobs
}

export function assertBuilderMatchesCommit(repo, sha, root) {
  for (const path of BUILDER_PATHS) {
    let committed
    try {
      committed = git(repo, ["rev-parse", "--verify", `${sha}:${path}`]).toString().trim()
    } catch {
      throw new Error(`${path} fehlt im Commit ${sha}; das Paket kann aus diesem Commit nicht gebaut werden.`)
    }
    const local = git(repo, ["hash-object", "--", `${root}/${path}`]).toString().trim()
    if (local !== committed) {
      throw new Error(
        `${path} weicht vom Commit ${sha.slice(0, 12)} ab. Den Build mit dem ` +
          "Skriptstand des Commits ausfuehren (Checkout dieses Commits), nicht mit lokalen Aenderungen."
      )
    }
  }
}

function matches(entry, path) {
  return entry.endsWith("/") ? path.startsWith(entry) : path === entry
}

// Ordnet jede versionierte Datei genau einem Eintrag zu.
export function classify(manifest, paths) {
  const include = Object.keys(manifest.include)
  const exclude = Object.keys(manifest.exclude)
  const included = []
  const excluded = []
  const unclassified = []
  const ambiguous = []
  const used = new Set()
  for (const path of paths) {
    const inc = include.filter((e) => matches(e, path))
    const exc = exclude.filter((e) => matches(e, path))
    inc.concat(exc).forEach((e) => used.add(e))
    if (inc.length + exc.length === 0) unclassified.push(path)
    else if (inc.length > 0 && exc.length > 0) ambiguous.push(path)
    else if (inc.length > 0) included.push(path)
    else excluded.push(path)
  }
  const unused = [...include, ...exclude].filter((e) => !used.has(e))
  return { included, excluded, unclassified, ambiguous, unused }
}

export function parseManifest(text) {
  const manifest = JSON.parse(text)
  if (!manifest.include || !manifest.exclude) {
    throw new Error("package-manifest.json braucht die Abschnitte include und exclude.")
  }
  return manifest
}

// THIRD-PARTY-LIST.md aus dem Lockfile des Commits. Schlaegt bei einer Lizenz
// ausserhalb der Positivliste fehl.
export function buildLicenseList(lock, sha) {
  const rows = []
  for (const [key, meta] of Object.entries(lock.packages ?? {})) {
    if (key === "") continue
    const name = key.slice(key.lastIndexOf("node_modules/") + "node_modules/".length)
    const license = typeof meta.license === "string" ? meta.license : null
    const scope = meta.dev || meta.devOptional ? "Entwicklung" : meta.optional ? "optional" : "Produktion"
    rows.push({ id: `${name}@${meta.version ?? "?"}`, license, scope })
  }
  const problems = rows.filter((r) => !r.license || !COMPATIBLE.has(r.license))
  if (problems.length > 0) {
    throw new Error(
      "Lizenz fehlt oder steht nicht in scripts/license-allowlist.mjs:\n" +
        problems.map((r) => `  ${r.id}  ${r.license ?? "UNKNOWN"}`).join("\n")
    )
  }
  rows.sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0))
  const histogram = new Map()
  for (const r of rows) histogram.set(r.license, (histogram.get(r.license) ?? 0) + 1)
  const lines = [
    "# Third-party list",
    "",
    "PAOLO SMS steht unter GPL-3.0-or-later (siehe `LICENSE` und `NOTICE`). Diese",
    `Liste gibt die Pakete aus \`package-lock.json\` des Commits ${sha} wieder.`,
    "Sie wird beim Bau des Quellpakets erzeugt und gehoert zu genau diesem Stand.",
    "Alle aufgefuehrten Lizenzen sind als GPLv3-vertraeglich geprueft",
    "(`scripts/license-allowlist.mjs`). Die Lizenztexte liegen in den Paketen, die",
    "`npm ci` installiert. Wer Build-Artefakte weitergibt (Docker-Image, Standalone-Build),",
    "erhaelt die Hinweise der enthaltenen Pakete und gibt diese Liste mit.",
    "",
    "## Uebersicht",
    "",
    "| Lizenz | Pakete |",
    "|---|---:|",
    ...[...histogram].sort((a, b) => b[1] - a[1] || (a[0] < b[0] ? -1 : 1)).map(([l, n]) => `| ${l} | ${n} |`),
    "",
    `Gesamt: ${rows.length} Eintraege im Lockfile (davon Plattformvarianten optionaler Pakete).`,
    "",
    "## Pakete",
    "",
    "| Paket | Lizenz | Verwendung |",
    "|---|---|---|",
    ...rows.map((r) => `| \`${r.id}\` | ${r.license} | ${r.scope} |`),
    "",
  ]
  return lines.join("\n")
}

// Relative Markdown-Verweise, die im Paket ins Leere laufen.
export function findBrokenLinks(files) {
  const known = new Set(files.keys())
  const exists = (p) => known.has(p) || [...known].some((k) => k.startsWith(`${p}/`))
  const broken = []
  for (const [path, data] of files) {
    if (!path.endsWith(".md")) continue
    const text = data.toString("utf8").replace(/```[\s\S]*?```/g, "")
    for (const m of text.matchAll(/\]\(([^)\s#]+)(?:#[^)]*)?\)/g)) {
      const target = m[1]
      if (/^[a-z][a-z0-9+.-]*:/i.test(target) || target.startsWith("/")) continue
      const parts = path.split("/").slice(0, -1)
      for (const seg of decodeURIComponent(target).split("/")) {
        if (seg === "..") parts.pop()
        else if (seg !== "." && seg !== "") parts.push(seg)
      }
      if (!exists(parts.join("/"))) broken.push({ file: path, target })
    }
  }
  return broken
}

// ---- tar.gz ---------------------------------------------------------------

function octal(value, width) {
  return value.toString(8).padStart(width - 1, "0") + "\0"
}

function header(path, size, mode, mtime) {
  let name = path
  let prefix = ""
  if (Buffer.byteLength(path) > 100) {
    const cut = [...path.matchAll(/\//g)]
      .map((m) => m.index)
      .find((i) => Buffer.byteLength(path.slice(0, i)) <= 155 && Buffer.byteLength(path.slice(i + 1)) <= 100)
    if (cut === undefined) throw new Error(`Pfad zu lang fuer ustar: ${path}`)
    prefix = path.slice(0, cut)
    name = path.slice(cut + 1)
  }
  const block = Buffer.alloc(512)
  block.write(name, 0, "utf8")
  block.write(octal(mode, 8), 100, "ascii")
  block.write(octal(0, 8), 108, "ascii")
  block.write(octal(0, 8), 116, "ascii")
  block.write(octal(size, 12), 124, "ascii")
  block.write(octal(mtime, 12), 136, "ascii")
  block.write("        ", 148, "ascii")
  block.write("0", 156, "ascii")
  block.write("ustar\0" + "00", 257, "ascii")
  block.write(prefix, 345, "utf8")
  const sum = block.reduce((a, b) => a + b, 0)
  block.write(sum.toString(8).padStart(6, "0") + "\0 ", 148, "ascii")
  return block
}

// entries: [{ path, data, executable }], in beliebiger Reihenfolge.
export function buildTarGz(entries, mtime) {
  const sorted = [...entries].sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0))
  const parts = []
  for (const e of sorted) {
    parts.push(header(e.path, e.data.length, e.executable ? 0o755 : 0o644, mtime))
    parts.push(e.data)
    const pad = (512 - (e.data.length % 512)) % 512
    if (pad) parts.push(Buffer.alloc(pad))
  }
  parts.push(Buffer.alloc(1024))
  const gz = Buffer.from(gzipSync(Buffer.concat(parts), { level: 9 }))
  // Kopf festschreiben: keine Zeit, Betriebssystem "Unix" (Node setzt es je
  // nach Plattform unterschiedlich).
  gz.writeUInt32LE(0, 4)
  gz[9] = 3
  return gz
}

export function readTar(tar) {
  const files = new Map()
  let offset = 0
  while (offset + 512 <= tar.length) {
    const block = tar.subarray(offset, offset + 512)
    if (block.every((b) => b === 0)) break
    const str = (from, len) => block.subarray(from, from + len).toString("utf8").replace(/\0.*$/s, "")
    const prefix = str(345, 155)
    const path = prefix ? `${prefix}/${str(0, 100)}` : str(0, 100)
    const size = parseInt(str(124, 12), 8)
    const mode = parseInt(str(100, 8), 8)
    const mtime = parseInt(str(136, 12), 8)
    const uid = parseInt(str(108, 8), 8)
    if (files.has(path)) throw new Error(`Doppelter Pfad im Archiv: ${path}`)
    files.set(path, { data: tar.subarray(offset + 512, offset + 512 + size), mode, mtime, uid })
    offset += 512 + Math.ceil(size / 512) * 512
  }
  return files
}

// ---- Gesamtablauf -----------------------------------------------------------

// Ordnet die Dateien eines Commits anhand der Positivliste dieses Commits ein.
export function planPackage(repo, sha) {
  const tree = listTree(repo, sha)
  const byPath = new Map(tree.map((t) => [t.path, t]))
  const manifestEntry = byPath.get(MANIFEST_PATH)
  if (!manifestEntry) throw new Error(`${MANIFEST_PATH} fehlt im Commit ${sha}.`)
  const manifest = parseManifest(readBlobs(repo, [manifestEntry.object]).values().next().value.toString("utf8"))
  const result = classify(manifest, tree.map((t) => t.path))
  return { tree, byPath, manifest, result, manifestObject: manifestEntry.object }
}

// Sortierte Pfadliste des Pakets (ohne erzeugte Dateien) im Format von package-files.txt.
export function packageFileListText(result) {
  return `${[...result.included].sort().join("\n")}\n`
}

// Fuer --since: hinzugekommene und entfernte Paketdateien gegenueber einem frueheren Commit.
export function diffFileLists(previous, current) {
  const before = new Set(previous)
  const after = new Set(current)
  return {
    added: current.filter((p) => !before.has(p)).sort(),
    removed: previous.filter((p) => !after.has(p)).sort(),
  }
}

export function buildSourcePackage({ repo, ref, root }) {
  const { sha, commitTime } = resolveCommit(repo, ref)
  assertBuilderMatchesCommit(repo, sha, root)

  const { byPath, result } = planPackage(repo, sha)

  const problems = []
  if (result.unclassified.length) problems.push(`Nicht in package-manifest.json eingeordnet:\n  ${result.unclassified.join("\n  ")}`)
  if (result.ambiguous.length) problems.push(`In include und exclude zugleich:\n  ${result.ambiguous.join("\n  ")}`)
  if (result.unused.length) problems.push(`Eintraege ohne Datei (veraltet):\n  ${result.unused.join("\n  ")}`)
  for (const path of result.included) {
    const t = byPath.get(path)
    if (t.type !== "blob" || t.mode === "120000") problems.push(`Symlink oder Submodul im Paket nicht erlaubt: ${path}`)
    if (FORBIDDEN_NAME.test(path) && !ALLOWED_ENV_NAME.test(path)) problems.push(`Verbotener Dateiname im Paket: ${path}`)
    if (GENERATED_FILES.includes(path)) problems.push(`Reservierter Name im Repository: ${path}`)
  }
  for (const path of REQUIRED_FILES) {
    if (!result.included.includes(path)) problems.push(`Pflichtdatei fehlt im Paket: ${path}`)
  }
  // Kontrolle des tatsaechlichen Paketinhalts: Jede Datei im Paket steht in einer
  // eingecheckten, im Review sichtbaren Liste. Eine neue Datei unter einem freigegebenen
  // Verzeichnis faellt damit auf, bevor sie ausgeliefert wird.
  const listEntry = byPath.get(FILE_LIST_PATH)
  if (!listEntry) {
    problems.push(`${FILE_LIST_PATH} fehlt. Erzeugen mit: node scripts/release/build-source-package.mjs --commit <ref> --update-file-list`)
  } else {
    const approved = readBlobs(repo, [listEntry.object]).values().next().value.toString("utf8").split("\n").filter(Boolean)
    const { added, removed } = diffFileLists(approved, result.included)
    if (added.length || removed.length) {
      problems.push(
        "Der Paketinhalt weicht von der freigegebenen Dateiliste (" + FILE_LIST_PATH + ") ab.\n" +
          (added.length ? `  Neu im Paket, nicht freigegeben:\n    ${added.join("\n    ")}\n` : "") +
          (removed.length ? `  In der Liste, aber nicht mehr im Paket:\n    ${removed.join("\n    ")}\n` : "") +
          "  Pruefen, ob jede Datei ausgeliefert werden darf, dann die Liste aktualisieren: node scripts/release/build-source-package.mjs --commit <ref> --update-file-list",
      )
    }
  }
  if (problems.length) throw new Error(problems.join("\n"))

  const blobs = readBlobs(repo, [...new Set(result.included.map((p) => byPath.get(p).object))])
  const files = new Map()
  const executable = new Map()
  for (const path of result.included) {
    const t = byPath.get(path)
    const data = blobs.get(t.object)
    const text = data.toString("latin1")
    if (PRIVATE_KEY.test(text)) throw new Error(`Privater Schluessel in ${path}`)
    for (const { name, pattern } of SECRET_PATTERNS) {
      if (pattern.test(text)) throw new Error(`Moegliche Zugangsdaten (${name}) in ${path}`)
    }
    files.set(path, data)
    executable.set(path, t.mode === "100755")
  }

  const pkg = JSON.parse(files.get("package.json").toString("utf8"))
  const lock = JSON.parse(files.get("package-lock.json").toString("utf8"))
  const version = packageVersion(pkg, lock, { allowLegacy: true })
  const releaseTag = version === LEGACY_VERSION ? null : packageLabel(version)

  const migrations = result.included.filter((p) => /^drizzle\/\d{4}_.+\.sql$/.test(p)).sort()
  if (migrations.length === 0) throw new Error("Keine Migrationen im Paket.")
  const schemaVersion = files.has("lib/backup/constants.ts")
    ? (files.get("lib/backup/constants.ts").toString("utf8").match(/PAOLO_SCHEMA_VERSION\s*=\s*"(\d{4})"/)?.[1] ?? null)
    : null

  files.set("THIRD-PARTY-LIST.md", Buffer.from(buildLicenseList(lock, sha)))
  const commitDate = new Date(commitTime * 1000).toISOString()
  files.set(
    "RELEASE.json",
    Buffer.from(
      JSON.stringify(
        {
          name: PACKAGE_NAME,
          version,
          releaseTag,
          commit: sha,
          commitDate,
          license: "GPL-3.0-or-later",
          // Jede Version mit Vorabkennung (SemVer-Prerelease) ist nicht fuer den Produktivbetrieb freigegeben.
          releaseStatus: version.includes("-") ? "Vorabversion - nicht fuer den Produktivbetrieb freigegeben" : "Release",
          latestMigration: migrations.at(-1).slice("drizzle/".length, -".sql".length),
          migrationCount: migrations.length,
          backupSchemaVersion: schemaVersion,
          manifestSha256: sha256(readBlobs(repo, [byPath.get(MANIFEST_PATH).object]).values().next().value),
        },
        null,
        2
      ) + "\n"
    )
  )
  const sums = [...files.keys()].sort().map((p) => `${sha256(files.get(p))}  ${p}`)
  files.set("FILES.sha256", Buffer.from(sums.join("\n") + "\n"))

  const top = `${PACKAGE_NAME}-${packageLabel(version)}`
  const entries = [...files].map(([path, data]) => ({
    path: `${top}/${path}`,
    data,
    executable: executable.get(path) ?? false,
  }))
  const archive = buildTarGz(entries, commitTime)
  const links = findBrokenLinks(files)
  return {
    version,
    releaseTag,
    sha,
    commitDate,
    fileName: `${top}.tar.gz`,
    archive,
    archiveSha256: sha256(archive),
    files: [...files.keys()].sort(),
    excluded: result.excluded,
    brokenLinks: links,
  }
}
