import { Pool } from "pg"

import { databaseDisplayTarget, getDatabaseUrl } from "../lib/backup/config"
import { PAOLO_DATA_FORMAT, PAOLO_SCHEMA_VERSION } from "../lib/backup/constants"
import { loadValidBackup } from "../lib/backup/filesystem"
import { decryptBackupToTemporaryFile } from "../lib/backup/encryption"
import { describeSchemaVersionMismatch, importPaoloData } from "../lib/backup/paolo-data"
import { requireRestoreConfirmation, validateBackupId } from "../lib/backup/security"

function argument(name: string): string | undefined {
  return process.argv.slice(2).find((value) => value.startsWith(`${name}=`))?.slice(name.length + 1)
}

async function main() {
  const backupId = validateBackupId(process.argv[2] ?? "")
  const target = databaseDisplayTarget()
  console.log(`Ziel: ${target.host}/${target.database}`)
  console.warn("WARNUNG: Nur eine leere, bereits auf diese PAOLO-Version migrierte Datenbank ist zulässig. Dateianhänge werden nicht wiederhergestellt.")
  requireRestoreConfirmation(target.database, argument("--confirm"))

  const { manifest, dataPath } = await loadValidBackup(backupId, true)
  if (manifest.engine !== "paolo_data" || manifest.archiveFormat !== PAOLO_DATA_FORMAT) {
    throw new Error("Backup ist kein unterstütztes PAOLO-Datenarchiv.")
  }
  if (manifest.schemaVersion !== PAOLO_SCHEMA_VERSION) {
    throw new Error(describeSchemaVersionMismatch(manifest.schemaVersion, PAOLO_SCHEMA_VERSION))
  }

  const decrypted = await decryptBackupToTemporaryFile({ manifest, encryptedPath: dataPath, identityPath: argument("--identity") })
  const pool = new Pool({ connectionString: getDatabaseUrl().toString(), max: 1 })
  try {
    const rowCounts = await importPaoloData(pool, decrypted.path, PAOLO_SCHEMA_VERSION)
    const total = Object.values(rowCounts).reduce((sum, count) => sum + count, 0)
    console.log(`Restore ${backupId} abgeschlossen (${total} Datensätze). Anwendung und Datenbank jetzt fachlich prüfen.`)
  } finally {
    try {
      await pool.end()
    } finally {
      await decrypted.cleanup()
    }
  }
}

main().catch((error) => {
  console.error(`[backup:restore-data] ${error instanceof Error ? error.message : "Unbekannter Fehler."}`)
  process.exitCode = 1
})
