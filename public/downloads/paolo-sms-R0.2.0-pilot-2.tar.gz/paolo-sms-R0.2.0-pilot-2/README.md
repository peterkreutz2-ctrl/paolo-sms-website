# PAOLO SMS

> **Vorabversion – nicht für den Produktivbetrieb freigegeben.** Nur Testdaten
> verwenden; siehe [`VORABVERSION.md`](VORABVERSION.md).

<p align="center">
  <img src="public/paolo-sms-logo.png" alt="PAOLO SMS" width="360" align="center" />
</p>

**Pilot Awareness and Occurrence Learning Online**

PAOLO SMS ist ein webbasiertes Safety-Management-System für
Gleitschirmflugschulen und Vereine. Es unterstützt eine niederschwellige,
nicht-punitive Meldekultur sowie die strukturierte Bearbeitung und
Nachverfolgung sicherheitsrelevanter Ereignisse, Beobachtungen, Risiken und
Maßnahmen.

Das Projekt wird MVP-orientiert und inkrementell entwickelt.

Weitere Informationen zu PAOLO SMS für Flugschulen, Vereine und Nutzer stehen auf
[`paolo-sms.de`](https://paolo-sms.de/).


## Funktionsumfang

### Öffentlich

- Informationen zu Zweck und Meldekultur
- anonyme oder namentliche Sicherheitsmeldungen
- öffentliche Dokumente sowie Impressum und Datenschutzerklärung
- optionale Melder-, Ereignis-, Flug-, Schweregrad- und Ortsangaben

### Intern

- Dashboard mit Kennzahlen und operativen Hinweisen
- Meldungsliste, Detailansicht, Workflow, Priorität und Risikobewertung
- interne Notizen, Dateianhänge und Folgemaßnahmen
- Sicherheitsbesprechungen und SMS-Dokumente
- Datenschutzwerkzeuge, Lösch-/Anonymisierungsabläufe und
  Datenschutzprüfungen
- Benutzerverwaltung und rollenbasierte Zugriffe für Administrator,
  Safety Manager, Instructor und Member
- Audit-Log, CSV-Import/-Export und FIDA-Export
- manuelle und geplante Datenbank-Backups

Die Bedienung aus Sicht der jeweiligen Rollen ist unter
[`docs/help/`](docs/help/README.md) beschrieben. Fachliche und betriebliche
Grenzen stehen in
[`docs/production-readiness.md`](docs/production-readiness.md).

## Betriebsmodell

PAOLO SMS ist keine zentral betriebene SaaS-Anwendung. Flugschulen, Vereine
oder beauftragte IT-Dienstleister installieren und betreiben jeweils
unabhängige Instanzen. Jede Betreiberinstallation hat damit eine eigene
Verantwortung für Hosting, Authentifizierung, Datenbank, Storage, Backups,
Updates und Datenschutz.

Die verfügbaren Betriebsoptionen sind bewusst flexibel: Betreiber können
verwaltete Dienste wie Clerk, Neon oder Vercel Blob nutzen oder
Authentifizierung, PostgreSQL und Dateispeicher selbst betreiben. Die
Entscheidung hängt von Datenhoheit, gewünschtem Funktionsumfang, technischem
Know-how, Betriebsaufwand und Kosten ab. Clerk ist der technische
Installationsdefault; Better Auth ist eine optionale selbst betriebene
Alternative.

Das Projektteam betreibt ausschließlich eine produktionsnahe
Referenzinstallation („Reference Prod") mit Spiel- und Testdaten. Sie dient
der Erprobung von Installation, Updates, Migrationen, Backups und
Betriebsabläufen, ist aber keine echte Betreiber-Produktivinstanz.
Betreiberinstanzen werden vom Projektteam nicht ohne ausdrücklichen Auftrag
verändert.

Die aktuelle Anwendung ist auf eine Organisation pro Installation
ausgerichtet. Ein echter zentraler Mehrorganisationen-/Mandantenbetrieb wird
derzeit nicht unterstützt. Eine mögliche spätere zentrale Bereitstellung,
beispielsweise durch den DHV, wäre eine größere eigenständige Produkt-,
Sicherheits-, Datenschutz- und Architekturentscheidung nach der
Friends-&-Family-Phase.

Die ausführliche Betreiberabwägung steht im
[Installations- und Entscheidungsleitfaden](docs/installation-decision-guide.md).

## Technischer Überblick

- Next.js 16 App Router, React 19 und TypeScript
- Tailwind CSS 4 und lokale shadcn-orientierte UI-Komponenten
- PostgreSQL mit Drizzle ORM
- Server Actions für Mutationen
- Zod und React Hook Form
- Authentifizierung über `AUTH_MODE`:
  - `clerk` — Standard, verwalteter externer Dienst
  - `betterauth` — selbst betriebenes E-Mail-/Passwort-Login in PostgreSQL
  - `file` — ausschließlich lokale Entwicklung, in Produktion abgelehnt
- Dateispeicher über Vercel Blob oder lokales Dateisystem
- Deployment über Vercel oder Docker; eine native Ubuntu-Installation ist als
  Sonderpfad dokumentiert

Details und Trade-offs beschreibt der
[Installations- und Entscheidungsleitfaden](docs/installation-decision-guide.md).

## Lokale Entwicklung

### Voraussetzungen

- Node.js 24 LTS
- eine PostgreSQL-Datenbank
- zum gewählten `AUTH_MODE` passende Konfiguration
- optional ein Vercel-Blob-Token; alternativ lokaler Storage

### Schnellstart

```bash
npm install
cp .env.example .env.local
npm run dev
```

Anschließend ist die Anwendung unter `http://localhost:3000` erreichbar.
Die Werte in `.env.local` müssen vor dem Start an die gewählte Datenbank,
Authentifizierung und Storage-Variante angepasst werden. Echte Secrets und
`.env`-Dateien dürfen nicht committed werden.

Die Datenbank muss zum aktuellen Schema passen. Das verbindliche Verfahren für
frische Datenbanken und bestehende Installationen steht in
[`docs/database-migrations.md`](docs/database-migrations.md). Beide verwenden
denselben idempotenten Voll-Lauf mit `psql -X -d <Ziel> -f scripts/migrate.psql`;
vorhandene Daten bleiben erhalten. Insbesondere
werden `drizzle-kit generate`, `drizzle-kit migrate` und `drizzle-kit push`
nicht als Produktionsverfahren verwendet.

Das Docker-App-Image enthält den SQL-Satz und `scripts/migrate.sh`. Updates
führen den Einstieg manuell aus dem neu gebauten Image aus, bevor die neue App
startet; Ablauf und Sicherheitsprüfungen stehen im
[Docker-Update-Runbook](docs/runbooks/production-docker-update.md).

Eine frische Installation erhält Organisation und ersten globalen
Administrator anschließend mit `npm run setup:initialize`. Der geführte,
bestätigungspflichtige Befehl unterstützt Clerk und Better Auth, läuft auch aus
dem Docker-App-Image und verweigert bereits oder teilweise initialisierte
Datenbanken. Details stehen in
[`docs/docker-setup.md`, Abschnitt 6.2](docs/docker-setup.md#62-bootstrap-nach-fresh-init-organisation--erster-admin).

Optional kann ein Betreiber anschließend einen synthetischen Spieldatensatz
(nur docker, VMS Betrieb) laden und ihn nach der Erprobung mit einem
bestätigungspflichtigen Operator-One-off vollständig zurücksetzen. Der Reset
erhält Organisation, Konten und
Rollenzuweisungen, löscht aber ausdrücklich auch Anhänge und lokale Backups.
Vorgehen und Sicherheitsgrenzen stehen in
[`docs/operator-demo-data.md`](docs/operator-demo-data.md).

### Wichtige Befehle

```bash
npm run dev
npm run lint
npm run build
npm run setup:initialize
npm run operator:data -- seed
npm run operator:data -- reset
npm run e2e:install
npm run e2e:reset
npm run e2e:test
```

Die E2E-Harness verwendet eine eigene Umgebung und dedizierte PostgreSQL-
Datenbank. `e2e:reset` ist destruktiv und darf niemals gegen eine Betreiber-
oder Reference-Prod-Datenbank ausgeführt werden. Einrichtung, Auth-Modi,
Testprojekte und Abdeckung beschreibt
`docs/end-2-end-test-overview.md` (Entwicklungsunterlage, nicht im Quellpaket).

## Installation und Betrieb

| Ziel | Maßgebliche Anleitung |
|---|---|
| Einstieg für Vereine und Flugschulen: von der Entscheidung bis zum laufenden Betrieb | [`docs/operator-guide.md`](docs/operator-guide.md) |
| Betreiberentscheidung: Hosting, Auth, Datenbank | [`docs/installation-decision-guide.md`](docs/installation-decision-guide.md) |
| Lokales/experimentelles Docker Compose | [`docs/docker-setup.md`](docs/docker-setup.md) |
| AWS-Konto und EC2-Host bereitstellen | [`docs/runbooks/aws-account-and-ec2-provisioning.md`](docs/runbooks/aws-account-and-ec2-provisioning.md) |
| Installation aus dem Quellpaket (Docker/VM, ohne Git) | [`docs/install-from-package.md`](docs/install-from-package.md) |
| Docker auf einer Ubuntu-VM installieren | [`docs/docker-vm-deployment.md`](docs/docker-vm-deployment.md) |
| Native Ubuntu-Installation | [`docs/setup-ubuntu.md`](docs/setup-ubuntu.md) |
| Docker-Produktionsupdate | [`docs/runbooks/production-docker-update.md`](docs/runbooks/production-docker-update.md) |
| Clerk auf Better Auth umstellen | [`docs/runbooks/switch-clerk-to-better-auth.md`](docs/runbooks/switch-clerk-to-better-auth.md) |
| Missbrauchsschutz öffentlicher Meldungen und Downloads betreiben | [`docs/runbooks/public-report-rate-limit.md`](docs/runbooks/public-report-rate-limit.md) |
| Backup und Restore | [`docs/backup-restore.md`](docs/backup-restore.md) |
| Spieldaten laden und Installation zurücksetzen (nur docker, VMS Betrieb) | [`docs/operator-demo-data.md`](docs/operator-demo-data.md) |

## Dokumentation

| Dokument | Inhalt |
|---|---|
| [`docs/glossar.md`](docs/glossar.md) | Verbindliche Terminologie; einzige Quelle, aus der die Onlinehilfe abgeleitet wird |
| [`docs/operator-guide.md`](docs/operator-guide.md) | Betreiberleitfaden: Einführung und Betrieb eines SMS mit PAOLO |
| [`docs/help/README.md`](docs/help/README.md) | Benutzer- und rollenbezogene Hilfe |
| [`docs/production-readiness.md`](docs/production-readiness.md) | Sicherheitsstand, Annahmen und bekannte Grenzen |
| [`docs/permission-matrix.md`](docs/permission-matrix.md) | Berechtigungsmatrix je Rolle, aus dem Code erhoben |
| [`docs/database-migrations.md`](docs/database-migrations.md) | Verbindliche Migrationsstrategie und Historie |
| [`docs/operator-demo-data.md`](docs/operator-demo-data.md) | Betreiber-Spieldaten und vollständiger Datenreset (nur docker, VMS Betrieb) |
| [`docs/release-checklist.md`](docs/release-checklist.md) | Release-Owner-Checkliste bei Schemaänderungen |
| [`docs/release-package.md`](docs/release-package.md) | Versionierung, Release-Tags, Paketbau, privates GitHub Release und öffentliche Bereitstellung |
| [`docs/privacy-operations.md`](docs/privacy-operations.md) | Betrieb der Datenschutzfunktionen |
| [`docs/data-protection-concept.md`](docs/data-protection-concept.md) | Datenschutzkonzept |
| [`docs/roles-and-permissions.md`](docs/roles-and-permissions.md) | Rollen- und Berechtigungsmodell |
| [`docs/role-responsibilities.md`](docs/role-responsibilities.md) | Fachliche Rollenbeschreibung: Zweck, Aufgaben, Grenzen |
| [`docs/organization-scoping.md`](docs/organization-scoping.md) | Organisationsbezug und aktuelle Grenzen |
| [`docs/requirements-report-model.md`](docs/requirements-report-model.md) | Fachliche Anforderungen an Meldungen |
| [`docs/containerization-roadmap.md`](docs/containerization-roadmap.md) | Historie und Roadmap der Containerisierung |

Operator-Runbooks sind unter
[`docs/runbooks/`](docs/runbooks/README.md) zusammengefasst.


## Lizenz

PAOLO SMS steht unter der **GNU General Public License, Version 3 oder später**
(`GPL-3.0-or-later`). Der vollständige Lizenztext liegt in
[`LICENSE`](LICENSE), die projektspezifischen Hinweise in [`NOTICE`](NOTICE).

Was das bedeutet:

- Kommerzielle Nutzung, Verkauf, Hosting und der Betrieb als SaaS sind
  ausdrücklich erlaubt.
- Wer PAOLO SMS **weitergibt** — auch verändert, auch als Docker-Image —, gibt
  den Quellcode mit weiter, und die Weitergabe erfolgt wieder unter der GPL.
- Wer PAOLO SMS nur **betreibt**, auch mit eigenen Anpassungen, muss nichts
  offenlegen. Die GPL kennt kein Netzwerk-Copyleft.
- Eine Einbettung in ein geschlossenes, proprietäres Produkt ist nicht möglich;
  das ist beabsichtigt.

Nicht von der Lizenz erfasst sind der Name „PAOLO“ und die Logos — siehe den
Markenabschnitt in [`NOTICE`](NOTICE). Zweckentsprechende Betreiberfassungen
und Forks dürfen Name und unverändertes Logo unter den Bedingungen der
[`PAOLO-SMS-Nutzungsrichtlinie`](BRAND-USAGE.md) verwenden. Andere Forks
ersetzen sie durch eigene Marken.

Zu den Lizenzen der Abhängigkeiten siehe
[`THIRD-PARTY-NOTICES.md`](THIRD-PARTY-NOTICES.md).

Beiträge sind willkommen; Näheres in [`CONTRIBUTING.md`](CONTRIBUTING.md).
