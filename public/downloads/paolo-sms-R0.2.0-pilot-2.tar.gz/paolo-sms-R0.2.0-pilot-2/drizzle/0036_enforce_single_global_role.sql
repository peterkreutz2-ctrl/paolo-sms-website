-- One global role per account. Explicitly authorized consolidation (#128):
-- lower roles add no capabilities; retain the highest role and its original row.
-- Unknown values must be reviewed rather than silently discarded.
LOCK TABLE user_roles IN SHARE ROW EXCLUSIVE MODE;
DO $$ BEGIN
  IF EXISTS (
    SELECT 1 FROM user_roles ur JOIN roles r ON r.id = ur.role_id
    WHERE ur.organization_id IS NULL
      AND r.key NOT IN ('admin', 'safety_manager', 'instructor', 'member')
      AND (SELECT count(*) FROM user_roles other
           WHERE other.clerk_user_id = ur.clerk_user_id
             AND other.organization_id IS NULL) > 1
  ) THEN
    RAISE EXCEPTION 'Unknown role in multiple global assignments; manual review required';
  END IF;
END $$;
WITH ranked AS (
  SELECT ur.id, row_number() OVER (
    PARTITION BY ur.clerk_user_id
    ORDER BY CASE r.key WHEN 'admin' THEN 1 WHEN 'safety_manager' THEN 2
      WHEN 'instructor' THEN 3 WHEN 'member' THEN 4 ELSE 5 END,
      ur.created_at, ur.id
  ) AS position
  FROM user_roles ur JOIN roles r ON r.id = ur.role_id
  WHERE ur.organization_id IS NULL
)
DELETE FROM user_roles WHERE id IN (SELECT id FROM ranked WHERE position > 1);
CREATE UNIQUE INDEX IF NOT EXISTS user_roles_single_global_unique
  ON user_roles (clerk_user_id) WHERE organization_id IS NULL;
