# Beiträge zu PAOLO SMS

Danke für dein Interesse. PAOLO SMS ist ein Safety-Management-System für
Gleitschirmschulen und -vereine und wird MVP-orientiert und inkrementell
entwickelt.

## Lizenz deiner Beiträge

PAOLO SMS steht unter [GPL-3.0-or-later](LICENSE). Wer einen Pull Request
einreicht, stellt seinen Beitrag unter dieselbe Lizenz und bestätigt damit, dass
er die dafür nötigen Rechte hat — dass der Beitrag also entweder von ihm selbst
stammt oder unter einer damit verträglichen Lizenz steht, und dass ihm keine
Verpflichtungen Dritter entgegenstehen, etwa aus einem Arbeitsverhältnis.

Bitte kopiere keinen Code und keine Texte aus fremden Quellen in einen Beitrag,
ohne die Herkunft im Pull Request zu nennen. Das gilt ausdrücklich auch für
Inhalte der SMS-Dokumentvorlagen unter `lib/constants/`.

## Vorgehen

1. Für eine Issue-Arbeit einen Branch `feature/issue-<nummer>` anlegen.
2. Änderungen umsetzen und die passenden Prüfungen laufen lassen:

   ```bash
   npm run lint
   npm run build
   npm run test:node
   ```

   Bei Änderungen an SQL zusätzlich `npm run test:migrations`, bei Änderungen an
   der Anwendung die betroffenen E2E-Specs, vor dem Merge die vollständige
   Suite (`npm run e2e:test`).
3. Pull Request eröffnen und darin Umsetzungsweg, Kontext und relevante
   Abwägungen beschreiben.
4. Nach dem Merge einen Eintrag in `docs/development-log.md` (nur im Repository)
   ergänzen — neueste Einträge stehen oben.

Für größere Feature-Issues gehören User Need, Akzeptanzkriterien, technischer
Kontext, Randbedingungen und nicht-funktionale Anforderungen in die
Issue-Beschreibung. Fehlt etwas davon, bitte nachfragen statt annehmen.

## Was im Repo gilt

Die verbindlichen Konventionen — Architektur, Domäneninvarianten,
Migrationsregeln, Teststufen und der Weg nach `main` — stehen in
`AGENTS.md` (nur im Repository). Bitte vor dem ersten Beitrag lesen.

Ein paar Punkte, die erfahrungsgemäß auffallen:

- Autorisierung wird serverseitig durchgesetzt; ausgeblendete UI ist keine
  Berechtigungsprüfung.
- Öffentlicher und interner Bereich bleiben getrennt, der Ton im öffentlichen
  Meldeweg bleibt niederschwellig und nicht-punitiv.
- Rollen-, Status- und Workflow-Werte kommen aus `lib/constants/`; keine
  Duplikate anlegen.
- Migrationen werden von Hand geschrieben, sind idempotent und beim Replay der
  gesamten geordneten Menge zerstörungsfrei. `drizzle-kit generate|migrate|push`
  wird nicht verwendet.
- Keine Secrets und keine `.env`-Dateien committen.

## Abhängigkeiten

Neue Abhängigkeiten müssen mit GPL-3.0-or-later verträglich sein. Prüfen mit:

```bash
npm run licenses:check
```

Der Befehl endet mit Exit-Code 1, wenn ein Paket ohne Lizenzangabe oder mit
einer nicht hinterlegten Lizenz auftaucht. Hintergrund in
[`THIRD-PARTY-NOTICES.md`](THIRD-PARTY-NOTICES.md).

## Marken

Name und Logos „PAOLO“ sind nicht Teil der Lizenz — siehe den Markenabschnitt
in [`NOTICE`](NOTICE). Zweckentsprechende Betreiberfassungen und Forks dürfen
Name und unverändertes Logo unter den Bedingungen von
[`BRAND-USAGE.md`](BRAND-USAGE.md) verwenden. Andere Forks ersetzen sie durch
eigene Marken.
