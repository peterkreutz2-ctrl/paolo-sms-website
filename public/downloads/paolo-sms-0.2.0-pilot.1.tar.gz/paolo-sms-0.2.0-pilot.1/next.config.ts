import type { NextConfig } from "next";

import { SECURITY_HEADERS, servesSecurityHeadersFromApp } from "./lib/security-headers";

const nextConfig: NextConfig = {
  // Eigenständiger Build (.next/standalone) für schlanke Docker-Images.
  output: "standalone",
  // Sicherheitsheader wie in der Nginx-Vorlage, nur auf Vercel (#107). Im
  // Docker-Pfad setzt sie Nginx; hier zusätzlich gesetzt, kämen sie doppelt.
  async headers() {
    if (!servesSecurityHeadersFromApp()) return [];
    return [{ source: "/:path*", headers: [...SECURITY_HEADERS] }];
  },
  experimental: {
    // Interne Transportgrenze, bewusst OBERHALB des Produktlimits: Anhaenge
    // sind auf 4 MiB begrenzt (MAX_FILE_SIZE_BYTES in
    // lib/constants/attachment-file-types.ts), der Request traegt zusaetzlich
    // Multipart-Metadaten. 5mb laesst dafuer Luft, ohne selbst zur wirksamen
    // Schranke zu werden.
    //
    // Massgeblich fuer die Aussenwelt ist nicht dieser Wert, sondern das
    // Request-Limit von Vercel (4,5 MB, infrastrukturseitig). Unter dieser
    // Grenze bleibt das PRODUKTLIMIT von 4 MiB — nicht dieser Transportwert.
    // Ein Upload, der 5mb ausschoepfen wuerde, waere von PAOLO ohnehin schon
    // abgelehnt.
    //
    // Vorher standen hier 26mb bzw. 30mb: Werte, die ein Limit vorgaukelten,
    // das die Plattform nicht zulaesst.
    serverActions: {
      bodySizeLimit: "5mb",
    },
    // proxy.ts puffert Request-Bodies. Gleicher Wert wie oben und wie
    // `client_max_body_size` in deploy/nginx/conf.d/snippets/app.conf (5m),
    // damit ein gueltiger Anhang die Server Action vollstaendig erreicht.
    proxyClientMaxBodySize: "5mb",
  },
};

export default nextConfig;
