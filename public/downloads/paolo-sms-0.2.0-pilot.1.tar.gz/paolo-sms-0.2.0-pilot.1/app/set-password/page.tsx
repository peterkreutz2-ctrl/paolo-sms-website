import type { Metadata } from "next"
import { notFound } from "next/navigation"

import { usesBetterAuth } from "@/lib/auth/mode"

import { SetPasswordForm } from "./set-password-form"

// Nur bei Better Auth: Clerk meldet sich ueber seinen eigenen Link an, und eine
// Seite zum Festlegen eines Passworts gibt es dort nicht.
//
// Das Token steht im URL-Fragment (#…), nicht im Pfad oder in der Abfrage — es
// erreicht den Server also nie beim Laden der Seite und taucht weder in
// Serverprotokollen noch im Referer-Feld auf. Die Seite soll auch nicht in
// Suchmaschinen und nicht mit Referer verlassen werden.
export const metadata: Metadata = {
  title: "Passwort festlegen",
  referrer: "no-referrer",
  robots: { index: false, follow: false },
}

export default function SetPasswordPage() {
  if (!usesBetterAuth()) notFound()

  return (
    <main className="flex min-h-screen items-center justify-center p-4">
      <div className="w-full max-w-md rounded-lg border bg-card p-6 shadow-sm">
        <h1 className="text-xl font-semibold">Passwort festlegen</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Legen Sie ein neues Passwort für Ihr Konto fest. Der Link, den Sie dafür
          erhalten haben, kann nur einmal verwendet werden.
        </p>
        <SetPasswordForm />
      </div>
    </main>
  )
}
