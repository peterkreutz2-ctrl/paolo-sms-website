"use client"

import Link from "next/link"
import { useActionState, useEffect, useSyncExternalStore } from "react"

import { setPasswordWithToken, type SetPasswordState } from "@/lib/auth/better-auth-actions"
import { Button } from "@/components/ui/button"

const initialState: SetPasswordState = { success: false, message: "" }

function subscribeToHash(onChange: () => void) {
  window.addEventListener("hashchange", onChange)
  return () => window.removeEventListener("hashchange", onChange)
}
const subscribeNever = () => () => {}

export function SetPasswordForm() {
  const [state, formAction, isPending] = useActionState(setPasswordWithToken, initialState)

  // Das Token kommt aus dem Fragment der Adresse. Es bleibt dort stehen, bis
  // das Passwort gesetzt ist — ein Fehlversuch (etwa ein Tippfehler bei der
  // Wiederholung) soll mit demselben Link wiederholbar sein. Nach Erfolg ist es
  // verbraucht und wird aus der Adresszeile entfernt.
  const hash = useSyncExternalStore(subscribeToHash, () => window.location.hash, () => "")
  const hydrated = useSyncExternalStore(subscribeNever, () => true, () => false)
  const token = hash.replace(/^#/, "")

  useEffect(() => {
    if (state.success) window.history.replaceState(null, "", window.location.pathname)
  }, [state.success])

  if (state.success) {
    return (
      <div className="mt-6 space-y-4">
        <p role="status" className="rounded-md border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-900 dark:border-emerald-800 dark:bg-emerald-950 dark:text-emerald-200">
          {state.message}
        </p>
        <Button asChild className="w-full">
          <Link href="/sign-in">Zur Anmeldung</Link>
        </Button>
      </div>
    )
  }

  if (!hydrated) return null

  if (!token) {
    return (
      <p role="alert" className="mt-6 rounded-md border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive">
        Dieser Link ist unvollständig oder wurde bereits geöffnet. Bitte bei der
        Administration einen neuen Link anfordern.
      </p>
    )
  }

  return (
    <form action={formAction} className="mt-6 space-y-4">
      <input type="hidden" name="token" value={token} />
      <div className="space-y-2">
        <label htmlFor="password" className="text-sm font-medium">Neues Passwort</label>
        <input id="password" name="password" type="password" autoComplete="new-password" minLength={8} maxLength={128} required className="w-full rounded-md border bg-background px-3 py-2 text-sm" />
        <p className="text-xs text-muted-foreground">Mindestens 8 Zeichen.</p>
      </div>
      <div className="space-y-2">
        <label htmlFor="passwordConfirm" className="text-sm font-medium">Passwort wiederholen</label>
        <input id="passwordConfirm" name="passwordConfirm" type="password" autoComplete="new-password" minLength={8} maxLength={128} required className="w-full rounded-md border bg-background px-3 py-2 text-sm" />
      </div>
      {state.message ? (
        <p role="alert" className="rounded-md border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive">
          {state.message}
        </p>
      ) : null}
      <Button type="submit" className="w-full" disabled={isPending || !token}>
        {isPending ? "Wird gespeichert…" : "Passwort festlegen"}
      </Button>
    </form>
  )
}
