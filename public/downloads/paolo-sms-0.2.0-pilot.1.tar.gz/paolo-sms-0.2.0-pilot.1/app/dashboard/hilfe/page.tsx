import { notFound, redirect } from "next/navigation"
import Link from "next/link"

import { appAuth } from "@/lib/auth"
import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { hasReportReadRole, ROLE_LABELS } from "@/lib/constants/roles"
import { resolveHelpDocument } from "@/lib/help"

import { DocumentMarkdownView } from "@/app/dashboard/documents/document-markdown-view"
import { Card, CardContent } from "@/components/ui/card"
import { PageHeader } from "@/components/ui/page-header"

export default async function HelpPage() {
  const { userId } = await appAuth()
  if (!userId) redirect("/sign-in")

  const roleKeys = await getCurrentUserRoles()
  // Dieselbe Schwelle wie der uebrige interne Bereich: Die Anleitungen
  // beschreiben interne Ablaeufe und nennen interne Routen.
  if (!hasReportReadRole(roleKeys)) notFound()

  const helpDocument = resolveHelpDocument(roleKeys)
  const roleLabel =
    roleKeys.length > 0
      ? roleKeys.map((key) => ROLE_LABELS[key]).join(", ")
      : "Keine Rolle"

  return (
    <main className="mx-auto max-w-3xl space-y-6 px-4 py-8 sm:px-8 sm:py-10">
      {/* Nur eine Ueberschrift auf dieser Seite: Die Anleitung bringt ihre
          eigene H1 mit. Ein zusaetzlicher Kartentitel wuerde denselben Namen
          ein zweites Mal sagen — und ein zweites <h1> erzeugen. */}
      <PageHeader
        title={helpDocument.title}
        subtitle={`Angezeigt wird die Anleitung für Ihre Rolle: ${roleLabel}.`}
      />

      <p className="text-sm text-muted-foreground">
        Diese Seite beschreibt die Bedienung. Verbindlich für den tatsächlichen
        Berechtigungsumfang ist die{" "}
        <Link
          href="/dashboard/hilfe/permission-matrix"
          className="font-medium text-sky-700 underline underline-offset-2 hover:text-sky-900 dark:text-sky-400 dark:hover:text-sky-300"
        >
          Berechtigungsmatrix
        </Link>
        . Was die Fachbegriffe bedeuten, steht im{" "}
        <Link
          href="/dashboard/hilfe/glossar"
          className="font-medium text-sky-700 underline underline-offset-2 hover:text-sky-900 dark:text-sky-400 dark:hover:text-sky-300"
        >
          Glossar
        </Link>
        .
      </p>

      <Card className="bg-muted/40">
        <CardContent className="pt-6">
          {/* Derselbe Renderer wie bei den SMS-Dokumenten: react-markdown ohne
              rehype-raw, also kein rohes HTML aus dem Inhalt. Der Text stammt
              hier ohnehin aus dem Repository und nicht aus einer Eingabe —
              zwei Renderer fuer dasselbe Format waeren trotzdem eine Quelle
              fuer Abweichungen. */}
          <DocumentMarkdownView content={helpDocument.markdown} />
        </CardContent>
      </Card>

      <p className="text-sm text-muted-foreground">
        Etwas fehlt oder stimmt nicht mehr? Die Anleitungen liegen im Repository
        unter <code className="text-xs">docs/help/</code> und werden dort
        gepflegt. Wozu eine Rolle fachlich da ist und welche Fragen dazu offen
        sind, steht unter{" "}
        <Link
          href="/dashboard/hilfe/role-responsibilities"
          className="font-medium text-sky-700 underline underline-offset-2 hover:text-sky-900 dark:text-sky-400 dark:hover:text-sky-300"
        >
          Rollen: Zweck, Aufgaben und Grenzen
        </Link>
        .
      </p>

      <Link
        href="/dashboard"
        className="inline-block text-sm text-blue-800 underline-offset-4 hover:text-blue-900 hover:underline focus-visible:rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        Zurück zur Übersicht
      </Link>
    </main>
  )
}
