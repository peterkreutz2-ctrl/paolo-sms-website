import { notFound, redirect } from "next/navigation"
import Link from "next/link"

import { appAuth } from "@/lib/auth"
import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { hasReportReadRole } from "@/lib/constants/roles"
import { findHelpReference } from "@/lib/help"

import { DocumentMarkdownView } from "@/app/dashboard/documents/document-markdown-view"
import { Card, CardContent } from "@/components/ui/card"

// ─── Nachschlagedokumente der Hilfe ──────────────────────────────────────────
//
// Die Rollenanleitungen berufen sich ausdruecklich auf die Berechtigungsmatrix
// und verweisen auf einige weitere Unterlagen. Bis hierher waren das im
// Repository richtige, in der Anwendung aber tote Verweise: "../permission-
// matrix.md" loest im Browser gegen /dashboard/hilfe zu "/permission-matrix.md"
// auf — keine Route, Fehlerseite.
//
// Diese Seite macht daraus ein Ziel innerhalb der Anwendung. Sie liest
// ausschliesslich die erzeugte Kopie aus lib/help/; docs/ liegt im
// Produktionsbuild nicht vor.
//
// Berechtigung: dieselbe Schwelle wie /dashboard/hilfe (`hasReportReadRole`) —
// kein eigenes Praedikat und keine oeffentliche Auslieferung. Die Unterlagen
// beschreiben die Funktionsweise der Anwendung, nicht die Daten einer
// Organisation; sie gehoeren damit in denselben internen Bereich wie die
// Anleitungen, die auf sie verweisen.

export default async function HelpReferencePage({
  params,
}: {
  params: Promise<{ doc: string }>
}) {
  const { userId } = await appAuth()
  if (!userId) redirect("/sign-in")

  const roleKeys = await getCurrentUserRoles()
  if (!hasReportReadRole(roleKeys)) notFound()

  const { doc } = await params
  const reference = findHelpReference(doc)
  // Ein unbekannter Schluessel ist ein 404 und keine leere Seite: Sonst
  // entstuende genau der Eindruck, den diese Aenderung beseitigen soll —
  // ein Verweis, der irgendwohin fuehrt, wo nichts steht.
  if (!reference) notFound()

  return (
    <main className="mx-auto max-w-3xl space-y-6 px-4 py-8 sm:px-8 sm:py-10">
      {/* Bewusst ohne PageHeader-Titel: Jedes dieser Dokumente beginnt mit
          seiner eigenen H1. Ein Seitentitel daneben saehe nicht nur doppelt
          aus, er erzeugte auch eine zweite H1 auf derselben Seite. */}
      <p className="text-sm text-muted-foreground">
        <Link
          href="/dashboard/hilfe"
          className="font-medium text-sky-700 underline underline-offset-2 hover:text-sky-900 dark:text-sky-400 dark:hover:text-sky-300"
        >
          Zurück zur Hilfe
        </Link>{" "}
        · Nachschlagedokument aus der Projektdokumentation
      </p>

      <Card className="bg-muted/40">
        <CardContent className="pt-6">
          {/* Derselbe Renderer wie fuer die Anleitungen und die
              SMS-Dokumente — kein rohes HTML aus dem Inhalt. */}
          <DocumentMarkdownView content={reference.markdown} />
        </CardContent>
      </Card>

      <p className="text-sm text-muted-foreground">
        Gepflegt wird dieses Dokument im Repository unter{" "}
        <code className="text-xs">docs/{doc}.md</code>. Die Anzeige hier ist
        eine erzeugte Kopie.
      </p>
    </main>
  )
}
