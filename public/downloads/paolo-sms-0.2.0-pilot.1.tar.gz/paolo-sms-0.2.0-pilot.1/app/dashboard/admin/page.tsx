import { appAuth } from "@/lib/auth"
import Link from "next/link"
import { notFound, redirect } from "next/navigation"

import { getCurrentUserGlobalRoles, getCurrentUserRoles } from "@/lib/auth/user-roles"
import { hasAdminRole, hasSafetyEditRole } from "@/lib/constants/roles"
import {
  Card,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { PageHeader } from "@/components/ui/page-header"

type AdminTile = {
  href: string
  title: string
  description: string
  /** Externe Route (CSV-Export) — kein Client-seitiger Wechsel. */
  external?: boolean
}

function AdminTiles({ tiles }: { tiles: AdminTile[] }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      {tiles.map((tile) => {
        const card = (
          <Card className="h-full transition-shadow hover:shadow-md">
            <CardHeader>
              <CardTitle className="text-base">{tile.title}</CardTitle>
              <CardDescription>{tile.description}</CardDescription>
            </CardHeader>
          </Card>
        )
        const className =
          "block rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"

        return tile.external ? (
          <a key={tile.href} href={tile.href} className={className}>
            {card}
          </a>
        ) : (
          <Link key={tile.href} href={tile.href} className={className}>
            {card}
          </Link>
        )
      })}
    </div>
  )
}

export default async function AdminPage() {
  const { userId } = await appAuth()
  if (!userId) redirect("/sign-in")

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) notFound()

  const isAdmin = hasAdminRole(roleKeys)
  const isGlobalAdmin = hasAdminRole(await getCurrentUserGlobalRoles())

  // Zwei Gruppen statt eines Rasters aus bis zu neun gleichwertigen Kacheln.
  // Der Safety Manager erkennt dadurch seine drei Alltagswege sofort; alles
  // Uebrige bleibt erreichbar, steht aber sichtbar getrennt darunter.
  //
  // Die Zuordnung ist Benutzerfuehrung, keine Berechtigung: Welche Kachel
  // erscheint, entscheidet weiterhin die Rolle, und jede Zielseite guardet
  // selbst.
  const laufendeAufgaben: AdminTile[] = [
    {
      href: "/dashboard/users",
      title: "Zugangs- und Rollenverwaltung",
      description:
        "Angemeldete Personen anlegen, Rollen zuweisen, Zugangslinks erzeugen.",
    },
    {
      href: "/dashboard/settings",
      title: "Organisationseinstellungen",
      description:
        "Turnus der Sicherheitsbesprechungen, Verantwortliche, Rückmeldungen",
    },
    {
      href: "/dashboard/audit",
      title: "Audit-Log",
      description:
        "Sicherheitsrelevante Änderungen und Aktionen nachvollziehen.",
    },
  ]

  const betriebRechtDatenschutz: AdminTile[] = [
    {
      href: "/dashboard/admin/legal",
      title: "Rechtliche Angaben",
      description:
        "Betreiberangaben für Impressum und Datenschutzerklärung pflegen.",
    },
    {
      href: "/dashboard/privacy",
      title: "Datenschutzprozesse",
      description:
        "Löschanfragen, Anonymisierung und Datenschutzvorfälle organisatorisch bearbeiten.",
    },
    {
      href: "/dashboard/export/fida",
      title: "FIDA-JSON-Export",
      description: "Meldungen eines Ereigniszeitraums ohne Anhänge exportieren.",
    },
    ...(isGlobalAdmin
      ? [
          {
            href: "/dashboard/admin/backup",
            title: "Datenbank-Backups",
            description:
              "Manuelle PostgreSQL-Backups erstellen und herunterladen.",
          },
        ]
      : []),
    ...(isAdmin
      ? [
          {
            href: "/dashboard/import",
            title: "Import",
            description: "Meldungen aus CSV-Dateien importieren.",
          },
          {
            href: "/api/export/reports",
            title: "Export",
            description: "Alle aktiven Meldungen als CSV-Datei exportieren.",
            external: true,
          },
        ]
      : []),
  ]

  return (
    <main className="mx-auto max-w-4xl space-y-8 px-4 py-8 sm:px-8">
      <PageHeader
        title="Administration"
        subtitle="Verwaltungs- und Kontrollfunktionen für Administratoren und Safety Manager."
      />

      <section aria-label="Laufende Aufgaben" className="space-y-3">
        <div>
          <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Laufende Aufgaben
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Was im Alltag gebraucht wird.
          </p>
        </div>
        <AdminTiles tiles={laufendeAufgaben} />
      </section>

      <section aria-label="Betrieb, Recht und Datenschutz" className="space-y-3">
        <div>
          <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Betrieb, Recht und Datenschutz
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Seltener gebraucht, dafür mit Vorbereitung — teils dem Administrator
            vorbehalten.
          </p>
        </div>
        <AdminTiles tiles={betriebRechtDatenschutz} />
      </section>
    </main>
  )
}
