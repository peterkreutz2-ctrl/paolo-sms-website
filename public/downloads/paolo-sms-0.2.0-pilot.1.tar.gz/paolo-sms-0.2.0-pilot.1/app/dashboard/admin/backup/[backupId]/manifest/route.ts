import { createReadStream } from "node:fs"
import { stat } from "node:fs/promises"
import { Readable } from "node:stream"

import { auditBackupEvent } from "@/lib/backup/audit"
import { BackupAuthorizationError, requireGlobalAdmin } from "@/lib/backup/authorization"
import { loadValidBackup, manifestPath } from "@/lib/backup/filesystem"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

export async function GET(_: Request, { params }: { params: Promise<{ backupId: string }> }) {
  let userId: string
  try { userId = await requireGlobalAdmin() } catch (error) {
    if (error instanceof BackupAuthorizationError) return new Response(error.reason === "unauthenticated" ? "Nicht autorisiert." : "Keine Berechtigung.", { status: error.reason === "unauthenticated" ? 401 : 403 })
    throw error
  }
  try {
    const { manifest } = await loadValidBackup((await params).backupId)
    const filePath = manifestPath(manifest.backupId)
    const fileStat = await stat(filePath)
    await auditBackupEvent({ userId, backupId: manifest.backupId, action: "BACKUP_MANIFEST_DOWNLOADED", changes: { attachmentsIncluded: false } })
    return new Response(Readable.toWeb(createReadStream(filePath)) as ReadableStream, { headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Content-Disposition": `attachment; filename="${manifest.backupId}.manifest.json"`,
      "Cache-Control": "private, no-store, max-age=0",
      "X-Content-Type-Options": "nosniff",
      "Content-Length": String(fileStat.size),
    } })
  } catch (error) {
    console.error("[backup] Manifest download failed:", error)
    return new Response("Manifest nicht gefunden.", { status: 404 })
  }
}

