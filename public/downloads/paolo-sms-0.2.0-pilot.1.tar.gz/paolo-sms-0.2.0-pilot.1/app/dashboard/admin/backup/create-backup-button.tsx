"use client"

import { useActionState } from "react"
import { LoaderCircle } from "lucide-react"

import { createBackupAction, type CreateBackupState } from "@/lib/actions/backups"
import { Button } from "@/components/ui/button"

const initialState: CreateBackupState = { success: false, message: "" }

export function CreateBackupButton() {
  const [state, action, pending] = useActionState(createBackupAction, initialState)
  return (
    <div className="space-y-2">
      <form action={action}>
        <Button type="submit" disabled={pending}>
          {pending ? <LoaderCircle className="animate-spin" aria-hidden="true" /> : null}
          {pending ? "Backup wird erstellt …" : "Backup jetzt erstellen"}
        </Button>
      </form>
      {state.message ? (
        <p className={`text-sm ${state.success ? "text-foreground" : "text-destructive"}`} role="status">
          {state.message}
        </p>
      ) : null}
    </div>
  )
}

