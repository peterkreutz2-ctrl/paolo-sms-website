import { notFound, redirect } from "next/navigation"

import { appAuth } from "@/lib/auth"
import { getCurrentUserGlobalRoles } from "@/lib/auth/user-roles"
import { listValidBackups } from "@/lib/backup/filesystem"
import { databaseDisplayTarget } from "@/lib/backup/config"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { PageHeader } from "@/components/ui/page-header"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

import { CreateBackupButton } from "./create-backup-button"
import { hasAdminRole } from "@/lib/constants/roles"

export const dynamic = "force-dynamic"

const dateFormatter = new Intl.DateTimeFormat("de-DE", { dateStyle: "medium", timeStyle: "medium" })
const sizeFormatter = new Intl.NumberFormat("de-DE", { style: "unit", unit: "megabyte", maximumFractionDigits: 2 })

export default async function BackupPage() {
  const { userId } = await appAuth()
  if (!userId) redirect("/sign-in")
  if (!hasAdminRole(await getCurrentUserGlobalRoles())) notFound()

  const backups = await listValidBackups()
  let targetDatabase = "<datenbank>"
  try { targetDatabase = databaseDisplayTarget().database || targetDatabase } catch { /* page can still explain configuration */ }

  return (
    <main className="mx-auto max-w-6xl space-y-8 px-4 py-8 sm:px-8">
      <PageHeader title="Datenbank-Backups" subtitle="Manuelle PostgreSQL-Sicherungen für globale Administratoren." />

      <Card>
        <CardHeader>
          <CardTitle>Backup erstellen</CardTitle>
          <CardDescription>Gesichert werden PostgreSQL-Daten. Dateianhänge sind in diesem MVP ausdrücklich nicht enthalten.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="rounded-md border border-destructive/30 bg-destructive/5 p-4 text-sm">
            <p className="font-medium">Vertrauliche und personenbezogene Daten</p>
            <p className="mt-1 text-muted-foreground">Archive werden mit age für die konfigurierten öffentlichen Empfänger verschlüsselt. Private Schlüssel dürfen nicht auf dem App-Server liegen. Bewahre zusätzlich eine sichere externe Kopie auf.</p>
          </div>
          <CreateBackupButton />
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Vorhandene Backups</CardTitle><CardDescription>Nur vollständige Paare aus Archiv und gültigem Manifest werden angezeigt.</CardDescription></CardHeader>
        <CardContent>
          {backups.length === 0 ? <p className="text-sm text-muted-foreground">Noch keine gültigen Backups vorhanden.</p> : (
            <Table>
              <TableHeader><TableRow><TableHead>Erstellt</TableHead><TableHead>Größe</TableHead><TableHead>Format</TableHead><TableHead>Verschlüsselung</TableHead><TableHead>SHA-256</TableHead><TableHead>Anhänge</TableHead><TableHead>Download</TableHead></TableRow></TableHeader>
              <TableBody>{backups.map((backup) => (
                <TableRow key={backup.backupId}>
                  <TableCell>{dateFormatter.format(new Date(backup.createdAt))}</TableCell>
                  <TableCell>{sizeFormatter.format(backup.fileSize / 1_000_000)}</TableCell>
                  <TableCell>{backup.engine} / {backup.archiveFormat}</TableCell>
                  <TableCell>age ({backup.encryption.recipientHints.length} Empfänger)</TableCell>
                  <TableCell><code>{backup.sha256.slice(0, 12)}…</code></TableCell>
                  <TableCell>Nein</TableCell>
                  <TableCell><div className="flex gap-2"><Button asChild size="sm" variant="outline"><a href={`/dashboard/admin/backup/${backup.backupId}/archive`}>Archiv</a></Button><Button asChild size="sm" variant="outline"><a href={`/dashboard/admin/backup/${backup.backupId}/manifest`}>Manifest</a></Button></div></TableCell>
                </TableRow>
              ))}</TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Wiederherstellung nur per CLI</CardTitle><CardDescription>Es gibt bewusst keine Wiederherstellung über die Weboberfläche.</CardDescription></CardHeader>
        <CardContent className="space-y-3 text-sm">
          <p>Vorher Wartungsmodus herstellen, Schreibzugriffe stoppen und die Hinweise in <code>docs/backup-restore.md</code> befolgen. Anhänge werden nicht wiederhergestellt.</p>
          <pre className="overflow-x-auto rounded-md bg-muted p-3"><code>{`npm run backup:restore -- <backup-id> --identity=<schlüsseldatei> --confirm=RESTORE:${targetDatabase}`}</code></pre>
          <pre className="overflow-x-auto rounded-md bg-muted p-3"><code>{`npm run backup:restore-data -- <backup-id> --identity=<schlüsseldatei> --confirm=RESTORE:${targetDatabase}`}</code></pre>
        </CardContent>
      </Card>
    </main>
  )
}
