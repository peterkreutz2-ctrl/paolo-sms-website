import { createReadStream } from "node:fs"
import { Readable } from "node:stream"

import { auditBackupEvent } from "@/lib/backup/audit"
import { BackupAuthorizationError, requireGlobalAdmin } from "@/lib/backup/authorization"
import { loadValidBackup } from "@/lib/backup/filesystem"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

export async function GET(_: Request, { params }: { params: Promise<{ backupId: string }> }) {
  let userId: string
  try { userId = await requireGlobalAdmin() } catch (error) {
    if (error instanceof BackupAuthorizationError) return new Response(error.reason === "unauthenticated" ? "Nicht autorisiert." : "Keine Berechtigung.", { status: error.reason === "unauthenticated" ? 401 : 403 })
    throw error
  }
  try {
    const { manifest, dataPath } = await loadValidBackup((await params).backupId)
    await auditBackupEvent({ userId, backupId: manifest.backupId, action: "BACKUP_DOWNLOADED", changes: { engine: manifest.engine, attachmentsIncluded: false } })
    return new Response(Readable.toWeb(createReadStream(dataPath)) as ReadableStream, { headers: {
      "Content-Type": "application/octet-stream",
      "Content-Disposition": `attachment; filename="${manifest.databaseFileName}"`,
      "Cache-Control": "private, no-store, max-age=0",
      "X-Content-Type-Options": "nosniff",
      "Content-Length": String(manifest.fileSize),
    } })
  } catch (error) {
    console.error("[backup] Archive download failed:", error)
    return new Response("Backup nicht gefunden.", { status: 404 })
  }
}

