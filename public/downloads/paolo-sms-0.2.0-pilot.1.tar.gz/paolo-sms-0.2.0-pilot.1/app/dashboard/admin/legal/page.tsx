import { appAuth } from "@/lib/auth"
import { eq } from "drizzle-orm"
import { notFound, redirect } from "next/navigation"

import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { hasSafetyEditRole } from "@/lib/constants/roles"
import { db } from "@/lib/db"
import { organizationLegalSettings, organizations } from "@/lib/db/schema"
import { LEGAL_SETTINGS_FIELDS, type LegalSettingsFieldKey } from "@/lib/validations/legal-settings"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { PageHeader } from "@/components/ui/page-header"

import { LegalSettingsForm } from "./legal-settings-form"

export default async function LegalSettingsPage() {
  const { userId } = await appAuth()
  if (!userId) redirect("/sign-in")

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) notFound()

  const [organization] = await db.select().from(organizations).limit(1)
  if (!organization) notFound()

  const [legal] = await db
    .select()
    .from(organizationLegalSettings)
    .where(eq(organizationLegalSettings.organizationId, organization.id))
    .limit(1)

  const legalValues = Object.fromEntries(
    LEGAL_SETTINGS_FIELDS.map((key) => [
      key,
      (legal?.[key] as string | null | undefined) ?? "",
    ])
  ) as Record<LegalSettingsFieldKey, string>

  return (
    <main className="mx-auto max-w-2xl space-y-8 px-4 py-8 sm:px-8">
      <PageHeader
        title="Rechtliche Angaben"
        subtitle="Betreiberangaben für Impressum und Datenschutzerklärung."
      />

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Rechtliche Angaben</CardTitle>
          <CardDescription>
            Betreiberangaben für Impressum und Datenschutzerklärung. Diese
            Angaben erscheinen auf den öffentlichen Seiten <code>/impressum</code>{" "}
            und <code>/datenschutz</code>. Sie müssen vom Betreiber der Instanz
            geprüft und vervollständigt werden — PAOLO leistet keine
            Rechtsberatung. Leere Felder sind erlaubt.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <LegalSettingsForm values={legalValues} />
        </CardContent>
      </Card>
    </main>
  )
}
