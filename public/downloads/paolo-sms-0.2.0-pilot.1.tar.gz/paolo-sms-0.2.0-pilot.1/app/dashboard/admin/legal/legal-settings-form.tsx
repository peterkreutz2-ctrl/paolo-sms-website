"use client"

import { useActionState, useState } from "react"

import {
  updateLegalSettings,
  type LegalSettingsActionState,
} from "@/lib/actions/legal-settings"
import { PRIVACY_POLICY_TEMPLATE } from "@/lib/constants/privacy-policy-template"
import type { LegalSettingsFieldKey } from "@/lib/validations/legal-settings"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

type FieldConfig = {
  name: LegalSettingsFieldKey
  label: string
  hint?: string
  kind?: "input" | "textarea"
  type?: string
}

type Group = {
  title: string
  description?: string
  fields: FieldConfig[]
}

const GROUPS: Group[] = [
  {
    title: "Impressum",
    description:
      "Angaben zum Betreiber dieser Instanz. Sie erscheinen öffentlich auf /impressum.",
    fields: [
      { name: "operatorName", label: "Betreiber / Organisation" },
      { name: "operatorLegalForm", label: "Rechtsform" },
      { name: "operatorAddress", label: "Anschrift", kind: "textarea" },
      { name: "operatorEmail", label: "Kontakt-E-Mail", type: "email" },
      { name: "operatorPhone", label: "Telefon (optional)", type: "tel" },
      { name: "representedBy", label: "Vertretungsberechtigte Person(en)" },
      {
        name: "registerInfo",
        label: "Registerangaben",
        hint: "z. B. Registergericht und Registernummer, falls vorhanden.",
      },
      {
        name: "vatId",
        label: "Umsatzsteuer-ID",
        hint: "Falls nicht vorhanden, „nicht vorhanden“ oder „nicht einschlägig“ eintragen.",
      },
      {
        name: "legalExtraText",
        label: "Zusätzliche Angaben (Impressum)",
        kind: "textarea",
        hint: "Nur bei einschlägigen Tätigkeiten: z. B. Aufsichtsbehörde oder „Verantwortlich für den Inhalt“. Die Datenschutz-Aufsichtsbehörde bitte im Datenschutz-Abschnitt eintragen.",
      },
    ],
  },
  {
    title: "Datenschutz",
    description: "Angaben für die Datenschutzerklärung.",
    fields: [
      { name: "privacyResponsibleName", label: "Verantwortlicher" },
      {
        name: "privacyContactEmail",
        label: "Datenschutzkontakt (E-Mail)",
        type: "email",
      },
      { name: "dataProtectionOfficer", label: "Datenschutzbeauftragter" },
      {
        name: "supervisoryAuthority",
        label: "Zuständige Datenschutz-Aufsichtsbehörde",
        hint: "Datenschutzaufsicht am Sitz des Betreibers. Wird in der Datenschutzerklärung ausgewiesen, nicht als allgemeine Impressums-Aufsicht.",
      },
      {
        name: "hostingProviderInfo",
        label: "Empfänger / Dienstleister / Hosting",
        kind: "textarea",
      },
      {
        name: "dataRetentionInfo",
        label: "Speicherdauer",
        kind: "textarea",
      },
      {
        name: "privacyExtraText",
        label: "Zusätzliche Angaben (Datenschutz)",
        kind: "textarea",
      },
    ],
  },
]

type Props = {
  values: Record<LegalSettingsFieldKey, string>
}

const initialState: LegalSettingsActionState = {
  success: false,
  message: "",
}

export function LegalSettingsForm({ values }: Props) {
  const [state, formAction, isPending] = useActionState(
    updateLegalSettings,
    initialState
  )

  // Der Datenschutzerklärungs-Volltext ist bewusst kontrolliert, damit der
  // „PAOLO-Vorschlag übernehmen"-Button den Text füllen kann.
  const [policyText, setPolicyText] = useState(values.privacyPolicyText ?? "")

  function applyTemplate() {
    if (
      policyText.trim().length > 0 &&
      !window.confirm(
        "Vorhandenen Text durch den PAOLO-Vorschlag ersetzen? Der aktuelle Text geht dabei verloren."
      )
    ) {
      return
    }
    setPolicyText(PRIVACY_POLICY_TEMPLATE)
  }

  return (
    <form action={formAction} className="space-y-8">
      {GROUPS.map((group) => (
        <fieldset key={group.title} className="space-y-4">
          <legend className="text-sm font-semibold text-foreground">
            {group.title}
          </legend>
          {group.description ? (
            <p className="-mt-2 text-sm text-muted-foreground">
              {group.description}
            </p>
          ) : null}

          {group.fields.map((field) => (
            <div key={field.name} className="space-y-1.5">
              <label htmlFor={field.name} className="text-sm font-medium">
                {field.label}
              </label>
              {field.hint ? (
                <p className="text-xs text-muted-foreground">{field.hint}</p>
              ) : null}
              {field.kind === "textarea" ? (
                <Textarea
                  id={field.name}
                  name={field.name}
                  rows={3}
                  defaultValue={values[field.name]}
                  className="bg-white"
                />
              ) : (
                <Input
                  id={field.name}
                  name={field.name}
                  type={field.type ?? "text"}
                  defaultValue={values[field.name]}
                  className="bg-white"
                />
              )}
            </div>
          ))}
        </fieldset>
      ))}

      <fieldset className="space-y-4">
        <legend className="text-sm font-semibold text-foreground">
          Datenschutzerklärung (Volltext)
        </legend>
        <p className="-mt-2 text-sm text-muted-foreground">
          Vollständiger Text der Datenschutzerklärung, der öffentlich auf{" "}
          <code>/datenschutz</code> angezeigt wird. Dieser Text ist ein
          unverbindlicher Vorschlag und muss vor Echtdatenbetrieb geprüft und
          angepasst werden. PAOLO leistet keine Rechtsberatung. Solange kein Text
          gespeichert ist, gilt die Datenschutzerklärung als nicht
          vervollständigt.
        </p>

        <div className="flex flex-wrap items-center gap-3">
          <Button type="button" variant="outline" onClick={applyTemplate}>
            PAOLO-Vorschlag übernehmen
          </Button>
          <span className="text-xs text-muted-foreground">
            Fügt den Vorschlagstext in das Feld ein; er wird erst durch
            „Speichern“ zur Betreiberfassung.
          </span>
        </div>

        <div className="space-y-1.5">
          <label htmlFor="privacyPolicyText" className="text-sm font-medium">
            Text der Datenschutzerklärung
          </label>
          <Textarea
            id="privacyPolicyText"
            name="privacyPolicyText"
            rows={16}
            value={policyText}
            onChange={(e) => setPolicyText(e.target.value)}
            className="bg-white font-mono text-xs leading-relaxed"
            placeholder="Noch kein Text hinterlegt. Vorschlag übernehmen oder eigenen Text einfügen."
          />
        </div>
      </fieldset>

      <div className="flex items-center gap-3">
        <Button type="submit" disabled={isPending}>
          {isPending ? "Speichert..." : "Speichern"}
        </Button>
        {state.message ? (
          <p
            className={`text-sm ${state.success ? "text-emerald-600" : "text-destructive"}`}
          >
            {state.message}
          </p>
        ) : null}
      </div>
    </form>
  )
}
