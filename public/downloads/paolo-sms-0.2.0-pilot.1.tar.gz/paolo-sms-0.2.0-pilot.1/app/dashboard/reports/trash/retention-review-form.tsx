"use client"

import { useActionState, useEffect, useRef, useState } from "react"

import { logRetentionReview } from "@/lib/actions/reports"
import { REPORT_RETENTION_REVIEW_DECISION_LABELS } from "@/lib/constants/report-retention"

import { Button } from "@/components/ui/button"

import {
  buildAnonymizationChecklistLabel,
  decisionLabel,
  NEUTRAL_DECISION_VALUE,
  SELECTABLE_RETENTION_REVIEW_DECISION_VALUES,
  type RetentionReviewEntry,
} from "../[reportId]/retention-review"

const initialState = { success: false, message: "" }

// Kompakte, aufklappbare Variante der Datenschutzprüfung für den Papierkorb.
// Die normale Detailseite (../[reportId]/page.tsx) ist für soft-gelöschte
// Reports bewusst nicht erreichbar (Query filtert `isNull(deletedAt)`).
// "Gelöscht" wird hier bewusst nicht mehr zur Auswahl angeboten (vermischt
// Papierkorb-/Lösch-Workflow mit der Datenschutzprüfung, siehe
// SELECTABLE_RETENTION_REVIEW_DECISION_VALUES) — historische Einträge mit
// diesem Wert bleiben über decisionLabel() weiterhin korrekt sichtbar.
// Nutzt dieselbe, unveränderte Server Action wie die Detailseite.
export function TrashRetentionReviewForm({
  reportId,
  history,
  minPostponedUntil,
}: {
  reportId: string
  history: RetentionReviewEntry[]
  minPostponedUntil: string
}) {
  const [open, setOpen] = useState(false)
  const [state, formAction, isPending] = useActionState(
    logRetentionReview,
    initialState
  )
  const [decision, setDecision] = useState(NEUTRAL_DECISION_VALUE)
  const [confirmNoPersonalData, setConfirmNoPersonalData] = useState(false)
  const decisionSelectRef = useRef<HTMLSelectElement>(null)
  const confirmCheckboxRef = useRef<HTMLInputElement>(null)
  // Siehe ../[reportId]/retention-review.tsx: React setzt das <select> nach
  // JEDER Aktionsausführung (Erfolg oder Fehler) nativ auf die erste Option
  // zurueck, unabhaengig vom React-State — auch ein Remount hilft nicht, da
  // die native Reset-Semantik am "selected"-Attribut haengt, das React fuer
  // kontrollierte Selects nie setzt. "decision"/"confirmNoPersonalData"
  // werden deshalb beim Absenden explizit aus dem React-State in verdeckte
  // Felder uebertragen (sichert die tatsaechlich gesendeten Daten ab).
  //
  // Fuer die Anzeige: bei Erfolg wird der lokale Auswahl-State auf den
  // Ausgangszustand zurueckgesetzt; bei einem Fehler bleibt er unveraendert
  // (echte Auswahl bleibt erhalten). In beiden Faellen wird der DOM-Wert des
  // Selects per Effekt explizit auf den aktuellen "decision"-State
  // zurueckgesetzt, da React bei unveraendertem State-Wert die
  // DOM-Neuschreibung sonst überspringt (Bail-out der Diffing-Optimierung).
  const [prevState, setPrevState] = useState(state)
  if (state !== prevState) {
    setPrevState(state)
    if (state.success) {
      setDecision(NEUTRAL_DECISION_VALUE)
      setConfirmNoPersonalData(false)
    }
  }

  // Gleiches gilt fuer die Bestaetigungs-Checkbox: der native Reset nimmt den
  // Haken weg, waehrend "confirmNoPersonalData" im State gesetzt bleibt.
  useEffect(() => {
    if (decisionSelectRef.current) {
      decisionSelectRef.current.value = decision
    }
    if (confirmCheckboxRef.current) {
      confirmCheckboxRef.current.checked = confirmNoPersonalData
    }
  }, [state, decision, confirmNoPersonalData])

  const syncHiddenFields = (form: HTMLFormElement) => {
    const decisionInput = form.elements.namedItem("decision") as HTMLInputElement
    const confirmInput = form.elements.namedItem(
      "confirmNoPersonalData"
    ) as HTMLInputElement
    decisionInput.value = decision
    confirmInput.value = confirmNoPersonalData ? "1" : ""
  }

  return (
    <div className="space-y-2">
      <Button
        type="button"
        variant="outline"
        size="sm"
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
      >
        {open
          ? "Datenschutzprüfung verbergen"
          : `Datenschutzprüfung (${history.length})`}
      </Button>

      {open ? (
        <div className="space-y-4 rounded-md border bg-muted/40 p-4 text-sm">
          <form
            action={formAction}
            onSubmit={(e) => syncHiddenFields(e.currentTarget)}
            className="space-y-3"
          >
            <input type="hidden" name="reportId" value={reportId} />
            <input type="hidden" name="decision" defaultValue={NEUTRAL_DECISION_VALUE} />
            <input type="hidden" name="confirmNoPersonalData" defaultValue="" />

            <div className="space-y-1.5">
              <label
                htmlFor={`rr-trash-decision-${reportId}`}
                className="text-sm font-medium"
              >
                Entscheidung
              </label>
              <select
                ref={decisionSelectRef}
                id={`rr-trash-decision-${reportId}`}
                value={decision}
                onChange={(e) => setDecision(e.target.value)}
                required
                className="h-9 w-full rounded-md border bg-white px-3 text-sm"
              >
                {/* Siehe ../[reportId]/retention-review.tsx: bewusst NICHT
                    disabled, sonst waehlt der native Formular-Reset nach
                    dem Speichern faelschlich die naechste, nicht-disabled
                    Option statt dieses neutralen Platzhalters. */}
                <option value={NEUTRAL_DECISION_VALUE}>
                  Bitte Entscheidung auswählen …
                </option>
                {SELECTABLE_RETENTION_REVIEW_DECISION_VALUES.map((value) => (
                  <option key={value} value={value}>
                    {REPORT_RETENTION_REVIEW_DECISION_LABELS[value]}
                  </option>
                ))}
              </select>
              {decision === "anonymized" ? (
                <p className="text-xs text-muted-foreground">
                  &bdquo;Vollständig anonymisiert&ldquo; setzt voraus, dass die
                  Melderdaten bereits über die Funktion &bdquo;Personenbezogene
                  Melderdaten entfernen&ldquo; entfernt wurden. Diese Aktion
                  protokolliert nur die Entscheidung, sie führt keine
                  Anonymisierung selbst aus.
                </p>
              ) : null}
            </div>

            {decision === "anonymized" ? (
              <div className="space-y-2 rounded-md border border-amber-200 bg-amber-50 p-3 dark:border-amber-800 dark:bg-amber-950/30">
                <label className="flex items-start gap-2 text-sm">
                  <input
                    ref={confirmCheckboxRef}
                    type="checkbox"
                    checked={confirmNoPersonalData}
                    onChange={(e) => setConfirmNoPersonalData(e.target.checked)}
                    className="mt-0.5"
                  />
                  <span>{buildAnonymizationChecklistLabel()}</span>
                </label>
              </div>
            ) : null}

            {decision === "postponed" ? (
              <div className="space-y-1.5">
                <label
                  htmlFor={`rr-trash-postponed-${reportId}`}
                  className="text-sm font-medium"
                >
                  Zurückstellen bis
                </label>
                <input
                  id={`rr-trash-postponed-${reportId}`}
                  name="postponedUntil"
                  type="date"
                  min={minPostponedUntil}
                  className="h-9 rounded-md border bg-white px-3 text-sm"
                />
              </div>
            ) : null}

            <div className="space-y-1.5">
              <label
                htmlFor={`rr-trash-reason-${reportId}`}
                className="text-sm font-medium"
              >
                {decision === "anonymized" && confirmNoPersonalData
                  ? "Prüfvermerk (verpflichtend bei vollständiger Bestätigung)"
                  : "Prüfvermerk (optional)"}
              </label>
              <p className="text-xs text-muted-foreground">
                Ergebnis der Prüfung bzw. Begründung der Entscheidung.
              </p>
              <textarea
                id={`rr-trash-reason-${reportId}`}
                name="reason"
                rows={2}
                maxLength={500}
                required={decision === "anonymized" && confirmNoPersonalData}
                placeholder="Keine personenbezogenen Daten eintragen"
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
              />
            </div>

            <div className="flex items-center gap-3">
              <Button
                type="submit"
                variant="outline"
                size="sm"
                disabled={isPending}
              >
                {isPending ? "Speichert…" : "Entscheidung dokumentieren"}
              </Button>
              {state.message ? (
                <p
                  className={`text-sm ${state.success ? "text-emerald-600" : "text-destructive"}`}
                >
                  {state.message}
                </p>
              ) : null}
            </div>
          </form>

          <div className="space-y-2 border-t pt-3">
            <p className="text-sm font-medium text-foreground">
              Prüfhistorie
            </p>
            {history.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                Noch keine Prüfentscheidung dokumentiert.
              </p>
            ) : (
              <ul className="space-y-2">
                {history.map((entry) => (
                  <li
                    key={entry.id}
                    className="rounded-md border bg-background px-3 py-2 text-sm"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="font-medium">
                        {decisionLabel(entry.decision)}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {entry.createdAt} · {entry.reviewerName}
                      </span>
                    </div>
                    {entry.postponedUntil ? (
                      <p className="mt-1 text-xs text-muted-foreground">
                        Zurückgestellt bis {entry.postponedUntil}
                      </p>
                    ) : null}
                    {entry.reason ? (
                      <p className="mt-1 text-muted-foreground">
                        {entry.reason}
                      </p>
                    ) : null}
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      ) : null}
    </div>
  )
}
