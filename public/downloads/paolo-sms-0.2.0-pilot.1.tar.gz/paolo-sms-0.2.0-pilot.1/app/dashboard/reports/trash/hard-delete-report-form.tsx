"use client"

import { useActionState, useEffect, useState } from "react"
import { useRouter } from "next/navigation"

import {
  hardDeleteReport,
  type HardDeleteReportState,
} from "@/lib/actions/reports"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

const REQUIRED_CONFIRM = "ENDGÜLTIG LÖSCHEN"

const initialState: HardDeleteReportState = {
  success: false,
  message: "",
}

type Props = {
  reportId: string
}

export function HardDeleteReportForm({ reportId }: Props) {
  const router = useRouter()
  const [state, formAction, isPending] = useActionState(
    hardDeleteReport,
    initialState
  )
  const [confirmText, setConfirmText] = useState("")

  useEffect(() => {
    if (state.success) {
      router.refresh()
    }
  }, [state.success, router])

  const canSubmit = confirmText === REQUIRED_CONFIRM

  return (
    <form
      action={formAction}
      className="mt-4 space-y-3 rounded-md border border-destructive/30 bg-destructive/5 p-3"
      onSubmit={(e) => {
        if (!canSubmit) {
          e.preventDefault()
        }
      }}
    >
      <p className="text-sm text-muted-foreground">
        Diese Aktion löscht den Bericht, alle Maßnahmen und alle Anhänge
        endgültig. Sie kann nicht rückgängig gemacht werden.
      </p>
      <input type="hidden" name="reportId" value={reportId} />
      <div className="space-y-1">
        <label
          htmlFor={`hard-delete-${reportId}`}
          className="text-sm font-medium"
        >
          Zur Bestätigung bitte exakt{" "}
          <span className="font-mono">{REQUIRED_CONFIRM}</span> eingeben:
        </label>
        <Input
          id={`hard-delete-${reportId}`}
          name="confirmText"
          value={confirmText}
          onChange={(e) => setConfirmText(e.target.value)}
          autoComplete="off"
          spellCheck={false}
          disabled={isPending}
          className="font-mono text-sm"
        />
      </div>
      <Button
        type="submit"
        variant="destructive"
        size="sm"
        disabled={isPending || !canSubmit}
      >
        {isPending ? "Wird gelöscht…" : "Endgültig löschen"}
      </Button>
      {state.message ? (
        <p
          className={`text-sm ${
            state.success ? "text-emerald-600" : "text-destructive"
          }`}
        >
          {state.message}
        </p>
      ) : null}
    </form>
  )
}
