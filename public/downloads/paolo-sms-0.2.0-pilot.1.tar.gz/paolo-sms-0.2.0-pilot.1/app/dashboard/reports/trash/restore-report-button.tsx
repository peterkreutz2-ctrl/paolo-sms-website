"use client"

import { useActionState } from "react"

import {
  restoreReport,
  type RestoreReportState,
} from "@/lib/actions/reports"

import { Button } from "@/components/ui/button"

const initialState: RestoreReportState = {
  success: false,
  message: "",
}

type Props = {
  reportId: string
}

export function RestoreReportButton({ reportId }: Props) {
  const [state, formAction, isPending] = useActionState(
    restoreReport,
    initialState
  )

  return (
    <form action={formAction} className="flex flex-wrap items-center gap-3">
      <input type="hidden" name="reportId" value={reportId} />
      <Button type="submit" variant="outline" size="sm" disabled={isPending}>
        {isPending ? "Wird wiederhergestellt…" : "Wiederherstellen"}
      </Button>
      {state.message ? (
        <p
          className={`text-sm ${
            state.success ? "text-emerald-600" : "text-destructive"
          }`}
        >
          {state.message}
        </p>
      ) : null}
    </form>
  )
}
