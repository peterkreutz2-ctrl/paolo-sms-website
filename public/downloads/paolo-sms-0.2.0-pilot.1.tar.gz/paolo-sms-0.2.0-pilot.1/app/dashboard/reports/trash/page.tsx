import { appAuth } from "@/lib/auth"
import Link from "next/link"
import { notFound, redirect } from "next/navigation"

import { desc, inArray, isNotNull } from "drizzle-orm"

import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { listDirectoryUsers } from "@/lib/auth/user-directory"
import { hasSafetyEditRole } from "@/lib/constants/roles"
import { computeMinPostponedUntil } from "@/lib/constants/report-retention"
import {
  PUBLIC_REPORT_TYPE_LABELS,
  PUBLIC_REPORT_TYPE_VALUES,
  type PublicReportType,
} from "@/lib/constants/public-report-types"
import {
  REPORT_STATUS_LABELS,
  REPORT_STATUS_VALUES,
  type ReportStatus,
} from "@/lib/constants/report-workflow"
import { db } from "@/lib/db"
import { reportRetentionReviews, reports } from "@/lib/db/schema"
import type { RetentionReviewEntry } from "../[reportId]/retention-review"

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"

import { HardDeleteReportForm } from "./hard-delete-report-form"
import { RestoreReportButton } from "./restore-report-button"
import { TrashRetentionReviewForm } from "./retention-review-form"

const deletedAtFormatter = new Intl.DateTimeFormat("de-DE", {
  dateStyle: "medium",
  timeStyle: "short",
})

function formatDate(date: Date) {
  return date.toLocaleString("de-CH", { dateStyle: "medium", timeStyle: "short" })
}

function reportTypeLabel(value: string): string {
  return PUBLIC_REPORT_TYPE_VALUES.includes(value as PublicReportType)
    ? PUBLIC_REPORT_TYPE_LABELS[value as PublicReportType]
    : value
}

function statusLabel(value: string): string {
  return REPORT_STATUS_VALUES.includes(value as ReportStatus)
    ? REPORT_STATUS_LABELS[value as ReportStatus]
    : value
}

export default async function ReportsTrashPage() {
  const { userId } = await appAuth()

  if (!userId) {
    redirect("/sign-in")
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    notFound()
  }

  const rows = await db
    .select()
    .from(reports)
    .where(isNotNull(reports.deletedAt))
    .orderBy(desc(reports.deletedAt))

  const reportIds = rows.map((r) => r.id)
  const retentionReviews = reportIds.length
    ? await db
        .select()
        .from(reportRetentionReviews)
        .where(inArray(reportRetentionReviews.reportId, reportIds))
        .orderBy(desc(reportRetentionReviews.createdAt), desc(reportRetentionReviews.id))
    : []

  // Reviewer-Namen analog zur Detailseite auflösen (Best-Effort).
  const reviewerIds = [...new Set(retentionReviews.map((r) => r.reviewedByClerkUserId))]
  const reviewerNames: Record<string, string> = {}
  if (reviewerIds.length > 0) {
    try {
      const users = await listDirectoryUsers({ ids: reviewerIds, limit: reviewerIds.length + 1 })
      for (const user of users) reviewerNames[user.id] = user.displayName
    } catch {
      // Clerk/Better Auth/File-Auth nicht erreichbar — Fallback auf gekuerzte ID unten
    }
  }

  const minPostponedUntil = computeMinPostponedUntil()

  const historyByReport = new Map<string, RetentionReviewEntry[]>()
  for (const entry of retentionReviews) {
    const list = historyByReport.get(entry.reportId) ?? []
    list.push({
      id: entry.id,
      decision: entry.decision,
      reason: entry.reason,
      postponedUntil: entry.postponedUntil,
      createdAt: formatDate(entry.createdAt),
      reviewerName:
        reviewerNames[entry.reviewedByClerkUserId] ??
        `${entry.reviewedByClerkUserId.slice(0, 12)}…`,
    })
    historyByReport.set(entry.reportId, list)
  }

  return (
    <main className="mx-auto max-w-4xl p-8">
      <p className="mb-6 text-sm text-muted-foreground">
        <Link
          href="/dashboard/reports"
          className="text-foreground underline-offset-4 hover:underline focus-visible:rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          Zurück zur Meldungsliste
        </Link>
      </p>

      <Card>
        <CardHeader>
          <CardTitle>Papierkorb (ausgeblendete Meldungen)</CardTitle>
          <CardDescription>
            Nur ausgeblendete Meldungen. Wiederherstellen macht sie in der
            normalen Liste sichtbar.
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          {rows.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              Keine ausgeblendeten Meldungen.
            </p>
          ) : (
            <div className="space-y-4">
              {rows.map((report) => (
                <div
                  key={report.id}
                  className="space-y-3 rounded-md border p-4 text-sm"
                >
                  <div>
                    <p className="font-medium text-base text-foreground">
                      {report.shortDescription}
                    </p>
                    <p className="mt-2 text-muted-foreground">
                      Typ: {reportTypeLabel(report.reportType)}
                    </p>
                    <p className="mt-1 text-muted-foreground">
                      Status: {statusLabel(report.status)}
                    </p>
                    <p className="mt-1 text-muted-foreground">
                      Ausgeblendet am:{" "}
                      {report.deletedAt
                        ? deletedAtFormatter.format(report.deletedAt)
                        : "—"}
                    </p>
                    <p className="mt-1 text-muted-foreground">
                      Ausgeblendet von (Clerk-ID):{" "}
                      {report.deletedBy ?? "—"}
                    </p>
                    <p className="mt-1 text-muted-foreground">
                      Grund: {report.deleteReason ?? "—"}
                    </p>
                  </div>
                  <div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap sm:items-start">
                    <RestoreReportButton reportId={report.id} />
                  </div>
                  <TrashRetentionReviewForm
                    reportId={report.id}
                    history={historyByReport.get(report.id) ?? []}
                    minPostponedUntil={minPostponedUntil}
                  />
                  <HardDeleteReportForm reportId={report.id} />
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </main>
  )
}
