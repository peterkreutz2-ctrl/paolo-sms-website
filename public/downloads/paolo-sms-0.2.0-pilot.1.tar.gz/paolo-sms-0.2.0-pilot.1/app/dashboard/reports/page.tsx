import { appAuth } from "@/lib/auth"
import Link from "next/link"
import { notFound, redirect } from "next/navigation"

import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { hasReportReadRole, hasSafetyEditRole } from "@/lib/constants/roles"
import { db } from "@/lib/db"
import { organizations } from "@/lib/db/schema"
import { getDueReportIds } from "@/lib/queries/report-retention"
import {
  listReports,
  normalizePageParam,
  normalizeSearchTerm,
  REPORT_LIST_PAGE_SIZE,
} from "@/lib/queries/report-list"
import {
  REPORT_PRIORITY_LABELS,
  REPORT_PRIORITY_VALUES,
  REPORT_STATUS_LABELS,
  REPORT_STATUS_VALUES,
  type ReportPriority,
  type ReportStatus,
} from "@/lib/constants/report-workflow"
import {
  PUBLIC_REPORT_TYPE_LABELS,
  PUBLIC_REPORT_TYPE_VALUES,
  type PublicReportType,
} from "@/lib/constants/public-report-types"

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

type Props = {
  searchParams: Promise<{
    status?: string
    priority?: string
    retention?: string
    q?: string
    page?: string
  }>
}

/**
 * Baut eine Listen-URL und behaelt dabei alle aktiven Filter bei.
 *
 * Ohne das verliert jeder Blaetterschritt die eingestellte Sicht — der
 * haeufigste Fehler bei nachtraeglich eingebauter Paginierung.
 */
function buildListHref(params: {
  status: string
  priority: string
  retention: string
  search: string | null
  page: number
}): string {
  const query = new URLSearchParams()
  if (params.status !== "all") query.set("status", params.status)
  if (params.priority !== "all") query.set("priority", params.priority)
  if (params.retention !== "all") query.set("retention", params.retention)
  if (params.search) query.set("q", params.search)
  if (params.page > 1) query.set("page", String(params.page))
  const suffix = query.toString()
  return suffix ? `/dashboard/reports?${suffix}` : "/dashboard/reports"
}

export default async function ReportsPage({ searchParams }: Props) {
  const { userId } = await appAuth()
  const { status, priority, retention, q, page: pageParam } = await searchParams
  const selectedStatus: ReportStatus | "all" | "open_all" =
    status === "open_all"
      ? "open_all"
      : REPORT_STATUS_VALUES.includes(status as ReportStatus)
        ? (status as ReportStatus)
        : "all"
  const selectedPriority = REPORT_PRIORITY_VALUES.includes(priority as ReportPriority)
    ? (priority as ReportPriority)
    : "all"
  const selectedRetention = retention === "due" ? "due" : "all"
  const searchTerm = normalizeSearchTerm(q)

  if (!userId) {
    redirect("/sign-in")
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasReportReadRole(roleKeys)) {
    notFound()
  }

  const canManageTrash = hasSafetyEditRole(roleKeys)

  let dueReportIds: string[] | null = null
  if (selectedRetention === "due" && canManageTrash) {
    const [organization] = await db
      .select({
        id: organizations.id,
        reportRetentionReviewIntervalMonths:
          organizations.reportRetentionReviewIntervalMonths,
      })
      .from(organizations)
      .limit(1)

    dueReportIds = organization
      ? await getDueReportIds(
          organization.id,
          organization.reportRetentionReviewIntervalMonths
        )
      : []
  }

  // Die Seitenzahl wird zweimal begrenzt: hier grob gegen offensichtlichen
  // Unsinn aus der URL, und in listReports noch einmal gegen die tatsaechliche
  // Trefferzahl — die kennt erst die Abfrage.
  const requestedPage = normalizePageParam(pageParam, Number.MAX_SAFE_INTEGER)

  const { rows, total, page, pageCount } = await listReports({
    status: selectedStatus,
    priority: selectedPriority,
    dueReportIds,
    search: searchTerm,
    page: requestedPage,
  })

  const hrefFor = (targetPage: number) =>
    buildListHref({
      status: selectedStatus,
      priority: selectedPriority,
      retention: selectedRetention,
      search: searchTerm,
      page: targetPage,
    })

  const firstOnPage = total === 0 ? 0 : (page - 1) * REPORT_LIST_PAGE_SIZE + 1
  const lastOnPage = (page - 1) * REPORT_LIST_PAGE_SIZE + rows.length

  return (
    <main className="max-w-4xl mx-auto p-8">
      <Card className="bg-muted/40">
        <CardHeader>
          <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
            <div>
              <CardTitle>Gespeicherte Meldungen</CardTitle>
              <CardDescription className="mt-1">
                Meldungen sichten, nach Status und Priorität filtern, Detailseite zur Bearbeitung öffnen. Kritische und überfällige Themen sollten prioritär gesichtet werden.
              </CardDescription>
            </div>
            {canManageTrash ? (
              <Link
                href="/dashboard/reports/trash"
                className="text-sm text-blue-800 hover:text-blue-900 hover:underline underline-offset-4 focus-visible:rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                Papierkorb (ausgeblendete Meldungen)
              </Link>
            ) : null}
          </div>
          {/* CSV-Import/-Export und FIDA-Export standen frueher hier im Kopf der
              wichtigsten Arbeitsliste — und zusaetzlich als Kacheln unter
              /dashboard/admin. Doppelt gefuehrt und jahresselten gebraucht;
              die Administration ist der richtige und bereits vorhandene Ort. */}
        </CardHeader>

        <CardContent className="space-y-4">
          <form method="GET" className="flex flex-wrap items-end gap-3">
            {/* Die Suche steht vorn: Bei mehr als einer Handvoll Meldungen ist
                sie der schnellste Weg zur gesuchten, schneller als jeder
                Filter. Gesucht wird in der Kurzbeschreibung — dem Feld, das
                die Liste auch anzeigt. */}
            <div className="flex flex-col gap-1">
              <label htmlFor="q" className="text-sm text-muted-foreground">
                Suche
              </label>
              <Input
                id="q"
                name="q"
                type="search"
                defaultValue={searchTerm ?? ""}
                placeholder="Kurzbeschreibung…"
                maxLength={120}
                className="h-9 w-56 bg-white"
              />
            </div>

            <label htmlFor="status" className="mb-2 text-sm text-muted-foreground">
              Status
            </label>

            <select
              id="status"
              name="status"
              defaultValue={selectedStatus}
              className="mb-0.5 h-9 rounded-md border bg-white px-3 text-sm"
            >
              <option value="all">Alle</option>
              <option value="open_all">Offen gesamt</option>
              {REPORT_STATUS_VALUES.map((statusOption) => (
                <option key={statusOption} value={statusOption}>
                  {REPORT_STATUS_LABELS[statusOption]}
                </option>
              ))}
            </select>

            <label htmlFor="priority" className="mb-2 text-sm text-muted-foreground">
              Priorität
            </label>

            <select
              id="priority"
              name="priority"
              defaultValue={selectedPriority}
              className="mb-0.5 h-9 rounded-md border bg-white px-3 text-sm"
            >
              <option value="all">Alle Prioritäten</option>
              {REPORT_PRIORITY_VALUES.map((p) => (
                <option key={p} value={p}>
                  {REPORT_PRIORITY_LABELS[p]}
                </option>
              ))}
            </select>

            {canManageTrash ? (
              <>
                <label htmlFor="retention" className="mb-2 text-sm text-muted-foreground">
                  Datenschutzprüfung
                </label>

                <select
                  id="retention"
                  name="retention"
                  defaultValue={selectedRetention}
                  className="mb-0.5 h-9 rounded-md border bg-white px-3 text-sm"
                >
                  <option value="all">Alle</option>
                  <option value="due">Prüfung fällig</option>
                </select>
              </>
            ) : null}

            <Button type="submit" variant="outline" size="sm" className="mb-0.5">
              Anwenden
            </Button>
          </form>

          {/* Trefferzahl und Ausschnitt stehen ueber der Liste: Ohne sie ist
              nach dem Filtern oder Suchen nicht erkennbar, ob man alles sieht
              oder nur die erste Seite. */}
          <p className="text-sm text-muted-foreground" aria-live="polite">
            {total === 0 ? (
              searchTerm ? (
                <>Keine Meldung enthält {"„"}{searchTerm}{"“"} in der Kurzbeschreibung.</>
              ) : (
                <>Keine Meldung entspricht der aktuellen Auswahl.</>
              )
            ) : (
              <>
                {total === 1 ? "1 Meldung" : `${total} Meldungen`}
                {pageCount > 1 ? ` · angezeigt ${firstOnPage}–${lastOnPage}` : ""}
                {searchTerm ? ` · Suche: „${searchTerm}"` : ""}
              </>
            )}
          </p>

          {rows.length === 0 ? (
            searchTerm ? (
              <p className="text-muted-foreground">
                Die Suche prüft nur die Kurzbeschreibung.{" "}
                <Link
                  href={buildListHref({
                    status: selectedStatus,
                    priority: selectedPriority,
                    retention: selectedRetention,
                    search: null,
                    page: 1,
                  })}
                  className="text-blue-800 hover:text-blue-900 hover:underline underline-offset-4"
                >
                  Suche zurücksetzen
                </Link>
              </p>
            ) : null
          ) : (
            <div className="space-y-4">
              {rows.map((report) => (
                <div
                  key={report.id}
                  className="rounded-md border p-4"
                >
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge variant="secondary" className="text-xs font-normal">
                      {PUBLIC_REPORT_TYPE_LABELS[
                        (PUBLIC_REPORT_TYPE_VALUES.includes(
                          report.reportType as PublicReportType
                        )
                          ? report.reportType
                          : "other") as PublicReportType
                      ]}
                    </Badge>
                  </div>

                  <h2 className="mt-2 font-medium">
                    <Link
                      href={`/dashboard/reports/${report.id}`}
                      className="text-blue-800 hover:text-blue-900 hover:underline"
                    >
                      {report.shortDescription}
                    </Link>
                  </h2>

                  {/* Gekuerzt wird serverseitig, nicht per CSS — die
                      vollstaendige Beschreibung faellt sonst trotzdem im
                      ausgelieferten HTML an. Sie steht auf der Detailseite. */}
                  <p className="mt-2 text-sm text-muted-foreground">
                    {report.descriptionExcerpt}
                    {report.descriptionTruncated ? "…" : ""}
                  </p>

                  <p className="mt-2 text-xs text-muted-foreground">
                    Status:{" "}
                    {
                      REPORT_STATUS_LABELS[
                        (REPORT_STATUS_VALUES.includes(report.status as ReportStatus)
                          ? report.status
                          : "new") as ReportStatus
                      ]
                    }{" "}
                    · Priorität:{" "}
                    {
                      REPORT_PRIORITY_LABELS[
                        (REPORT_PRIORITY_VALUES.includes(
                          report.priority as ReportPriority
                        )
                          ? report.priority
                          : "medium") as ReportPriority
                      ]
                    }
                  </p>
                </div>
              ))}
            </div>
          )}

          {pageCount > 1 ? (
            <nav
              aria-label="Seiten der Meldungsliste"
              className="flex flex-wrap items-center justify-between gap-3 border-t pt-4"
            >
              <span className="text-sm text-muted-foreground">
                Seite {page} von {pageCount}
              </span>
              <div className="flex items-center gap-2">
                {page > 1 ? (
                  <Button asChild variant="outline" size="sm">
                    <Link href={hrefFor(page - 1)} rel="prev">
                      Zurück
                    </Link>
                  </Button>
                ) : (
                  <Button variant="outline" size="sm" disabled>
                    Zurück
                  </Button>
                )}
                {page < pageCount ? (
                  <Button asChild variant="outline" size="sm">
                    <Link href={hrefFor(page + 1)} rel="next">
                      Weiter
                    </Link>
                  </Button>
                ) : (
                  <Button variant="outline" size="sm" disabled>
                    Weiter
                  </Button>
                )}
              </div>
            </nav>
          ) : null}
        </CardContent>
      </Card>
    </main>
  )
}
