import { and, eq } from "drizzle-orm"
import { appAuth } from "@/lib/auth"

import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { buildAttachmentDeliveryHeaders } from "@/lib/constants/attachment-visibility"

import { db } from "@/lib/db"
import { attachments, reports } from "@/lib/db/schema"
import { downloadFile } from "@/lib/storage"
import { hasAttachmentAccessRole } from "@/lib/constants/roles"

type Props = {
  params: Promise<{
    reportId: string
    attachmentId: string
  }>
}

export async function GET(_: Request, { params }: Props) {
  const { userId } = await appAuth()
  if (!userId) {
    return new Response("Nicht autorisiert.", { status: 401 })
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasAttachmentAccessRole(roleKeys)) {
    return new Response("Keine Berechtigung.", { status: 403 })
  }

  const { reportId, attachmentId } = await params

  const [reportRow] = await db
    .select({ deletedAt: reports.deletedAt })
    .from(reports)
    .where(eq(reports.id, reportId))
    .limit(1)

  if (!reportRow || reportRow.deletedAt != null) {
    return new Response("Meldung nicht gefunden.", { status: 404 })
  }

  const [attachment] = await db
    .select()
    .from(attachments)
    .where(
      and(
        eq(attachments.id, attachmentId),
        eq(attachments.reportId, reportId)
      )
    )
    .limit(1)

  if (!attachment) {
    return new Response("Anhang nicht gefunden.", { status: 404 })
  }

  const file = await downloadFile(attachment.storageKey)
  if (!file) {
    return new Response("Datei nicht gefunden.", { status: 404 })
  }

  return new Response(file.stream, {
    status: 200,
    // Gleiche Regeln wie bei SMS-Dokumenten: Bilder und Videos
    // inline, damit die Detailseite sie darstellen kann; alles andere bleibt
    // Download. Bei Video zusaetzlich Content-Length aus dem gespeicherten
    // fileSize, damit der Player die Dauer kennt.
    headers: buildAttachmentDeliveryHeaders({
      mimeType: attachment.mimeType,
      fileName: attachment.originalFileName,
      fileSize: attachment.fileSize,
      fallbackContentType: file.contentType,
      cacheControl: "private, no-store",
    }),
  })
}
