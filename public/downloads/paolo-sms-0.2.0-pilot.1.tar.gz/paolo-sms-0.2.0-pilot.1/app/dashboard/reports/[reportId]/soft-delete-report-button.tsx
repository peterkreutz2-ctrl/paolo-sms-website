"use client"

import { useActionState } from "react"

import {
  softDeleteReport,
  type SoftDeleteReportState,
} from "@/lib/actions/reports"

import { Button } from "@/components/ui/button"

const initialState: SoftDeleteReportState = {
  success: false,
  message: "",
}

type Props = {
  reportId: string
}

export function SoftDeleteReportButton({ reportId }: Props) {
  const [state, formAction, isPending] = useActionState(
    softDeleteReport,
    initialState
  )

  return (
    <form action={formAction} className="flex flex-wrap items-center gap-3">
      <input type="hidden" name="reportId" value={reportId} />
      <Button
        type="submit"
        variant="outline"
        disabled={isPending}
        className="border-destructive/50 text-destructive hover:bg-destructive/10"
      >
        {isPending ? "Wird ausgeblendet…" : "In den Papierkorb"}
      </Button>
      {state.message ? (
        <p
          className={`text-sm ${
            state.success ? "text-emerald-600" : "text-destructive"
          }`}
        >
          {state.message}
        </p>
      ) : null}
    </form>
  )
}
