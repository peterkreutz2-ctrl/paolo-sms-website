"use client"

import { useActionState, useEffect } from "react"
import { useRouter } from "next/navigation"

import {
  createReportNote,
  type CreateReportNoteState,
} from "@/lib/actions/report-notes"
import {
  NOTE_TYPE_LABELS,
  NOTE_TYPE_VALUES,
  type NoteType,
} from "@/lib/constants/report-notes"
import { Button } from "@/components/ui/button"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

type ReportNote = {
  id: string
  authorClerkUserId: string
  noteType: string
  content: string
  createdAt: Date
}

type Props = {
  reportId: string
  notes: ReportNote[]
  authorNames: Record<string, string>
  canAdd: boolean
}

const initialState: CreateReportNoteState = { success: false, message: "" }

function formatDate(date: Date) {
  return date.toLocaleString("de-CH", { dateStyle: "medium", timeStyle: "short" })
}

function noteTypeLabel(noteType: string): string {
  return NOTE_TYPE_LABELS[noteType as NoteType] ?? noteType
}

function truncateClerkId(id: string): string {
  if (id.length <= 12) return id
  return `${id.slice(0, 9)}…${id.slice(-3)}`
}

function resolveAuthor(clerkId: string, authorNames: Record<string, string>): string {
  return authorNames[clerkId] ?? truncateClerkId(clerkId)
}

function CreateNoteForm({ reportId }: { reportId: string }) {
  const router = useRouter()
  const [state, formAction, isPending] = useActionState(createReportNote, initialState)

  useEffect(() => {
    if (state.success) router.refresh()
  }, [state, router])

  return (
    <div className="space-y-4">
      <p className="text-sm font-semibold text-foreground">Neue Notiz erfassen</p>
      <form action={formAction} className="space-y-4">
        <input type="hidden" name="reportId" value={reportId} />

        <div className="space-y-2">
          <label htmlFor="note-noteType" className="text-sm font-medium">
            Typ
          </label>
          <Select name="noteType" defaultValue="internal_note">
            <SelectTrigger id="note-noteType" className="w-full sm:w-64">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {NOTE_TYPE_VALUES.map((v) => (
                <SelectItem key={v} value={v}>
                  {NOTE_TYPE_LABELS[v]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <label htmlFor="note-content" className="text-sm font-medium">
            Inhalt
          </label>
          <Textarea
            id="note-content"
            name="content"
            rows={4}
            className="min-h-[6rem]"
            placeholder="Notiz eingeben…"
          />
        </div>

        <div className="flex items-center gap-3">
          <Button type="submit" disabled={isPending}>
            {isPending ? "Speichert..." : "Notiz speichern"}
          </Button>
          {state.message ? (
            <p className={`text-sm ${state.success ? "text-emerald-600" : "text-destructive"}`}>
              {state.message}
            </p>
          ) : null}
        </div>
      </form>
    </div>
  )
}

export function ReportNotesSection({ reportId, notes, authorNames, canAdd }: Props) {
  return (
    <div className={`space-y-4 rounded-md p-4 ${canAdd ? "border bg-muted/40" : "bg-muted/40"}`}>
      <p className="text-sm font-semibold text-foreground">
        Notizen / Nachträge{notes.length > 0 ? ` (${notes.length})` : ""}
      </p>

      {/* Leerer Abschnitt: eine Zeile statt eines Platzhalterblocks. */}
      {notes.length === 0 ? (
        canAdd ? null : (
          <p className="text-sm italic text-muted-foreground">Keine Notizen erfasst.</p>
        )
      ) : (
        <div className="space-y-3">
          {notes.map((note) => (
            <div key={note.id} className="rounded-md bg-muted/40 px-4 py-3 text-sm space-y-1">
              <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                <span className="font-medium text-foreground">
                  {noteTypeLabel(note.noteType)}
                </span>
                <span>·</span>
                <span>{resolveAuthor(note.authorClerkUserId, authorNames)}</span>
                <span>·</span>
                <span>{formatDate(note.createdAt)}</span>
              </div>
              <p className="whitespace-pre-wrap text-foreground">{note.content}</p>
            </div>
          ))}
        </div>
      )}

      {canAdd ? <CreateNoteForm reportId={reportId} /> : null}
    </div>
  )
}
