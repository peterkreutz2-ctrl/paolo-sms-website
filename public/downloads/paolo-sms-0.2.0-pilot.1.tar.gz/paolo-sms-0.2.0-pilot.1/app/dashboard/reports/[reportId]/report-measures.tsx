"use client"

import { useActionState, useState } from "react"

import { createMeasure, updateMeasure } from "@/lib/actions/measures"
import type { MeasureActionState } from "@/lib/actions/measures"
import {
  MEASURE_DISCARD_REASON_MIN_LENGTH,
  MEASURE_STATUS_LABELS,
  MEASURE_STATUS_VALUES,
  requiresDiscardReason,
  type MeasureStatus,
} from "@/lib/constants/measure-workflow"
import { measures } from "@/lib/db/schema"

import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

type MeasureRow = typeof measures.$inferSelect

const emptyActionState: MeasureActionState = {
  success: false,
  message: "",
}

const dueDateDisplay = new Intl.DateTimeFormat("de-DE", {
  timeZone: "UTC",
  dateStyle: "medium",
})

function normalizeStatus(value: string): MeasureStatus {
  return MEASURE_STATUS_VALUES.includes(value as MeasureStatus)
    ? (value as MeasureStatus)
    : "open"
}

function formatDateInput(date: Date | null): string {
  if (!date) return ""
  return date.toISOString().slice(0, 10)
}

function ActionMessage({ state }: { state: MeasureActionState }) {
  if (!state.message) return null
  return (
    <p
      className={`text-sm ${
        state.success ? "text-emerald-600" : "text-destructive"
      }`}
    >
      {state.message}
    </p>
  )
}

function CreateMeasureForm({ reportId }: { reportId: string }) {
  const [state, formAction, isPending] = useActionState(
    createMeasure,
    emptyActionState
  )

  return (
    <form action={formAction} className="space-y-4 rounded-lg border p-4">
      <input type="hidden" name="reportId" value={reportId} />
      <p className="text-sm font-medium">Neue Maßnahme</p>

      <div className="space-y-2">
        <label htmlFor="measure-title" className="text-sm font-medium">
          Titel <span className="text-destructive">*</span>
        </label>
        <Input
          id="measure-title"
          name="title"
          required
          maxLength={200}
          placeholder="Kurzer Titel der Maßnahme"
        />
      </div>

      <div className="space-y-2">
        <label htmlFor="measure-description" className="text-sm font-medium">
          Beschreibung (optional)
        </label>
        <Textarea
          id="measure-description"
          name="description"
          rows={3}
          placeholder="Details, falls noetig"
        />
      </div>

      <div className="space-y-2">
        <label htmlFor="measure-assigned" className="text-sm font-medium">
          Verantwortlich (optional)
        </label>
        <Input
          id="measure-assigned"
          name="assignedToText"
          placeholder="Name oder Funktion"
        />
      </div>

      <div className="space-y-2">
        <label htmlFor="measure-due" className="text-sm font-medium">
          Faellig am (optional)
        </label>
        <Input id="measure-due" name="dueDate" type="date" />
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <Button type="submit" disabled={isPending}>
          {isPending ? "Speichert..." : "Maßnahme anlegen"}
        </Button>
        <ActionMessage state={state} />
      </div>
    </form>
  )
}

// Vorhandene Massnahmen stehen als Lesezeile; das Formular erscheint erst auf
// „Bearbeiten". Vorher rendete jede Massnahme ein vollstaendiges Formular —
// fuenf Massnahmen bedeuteten fuenf geoeffnete Formulare untereinander, ohne
// dass eine davon bearbeitet werden sollte. Nach erfolgreichem Speichern
// klappt die Zeile wieder zu.
function MeasureRow({
  reportId,
  measure,
}: {
  reportId: string
  measure: MeasureRow
}) {
  const [state, formAction, isPending] = useActionState(
    updateMeasure,
    emptyActionState
  )
  const [isEditing, setIsEditing] = useState(false)
  const status = normalizeStatus(measure.status)

  // Der ausgewaehlte Status wird mitgefuehrt, damit das Begruendungsfeld
  // erscheinen kann, sobald „Verworfen" gewaehlt ist. Angepasst wird waehrend
  // des Renderns (dasselbe Muster wie beim Zuklappen unten), wenn der Server
  // einen neuen Status liefert.
  const [draftStatus, setDraftStatus] = useState<MeasureStatus>(status)
  const [knownStatus, setKnownStatus] = useState<MeasureStatus>(status)
  if (status !== knownStatus) {
    setKnownStatus(status)
    setDraftStatus(status)
  }

  const askForDiscardReason = requiresDiscardReason(status, draftStatus)
  const [discardReason, setDiscardReason] = useState("")
  const discardReasonLongEnough =
    discardReason.trim().length >= MEASURE_DISCARD_REASON_MIN_LENGTH

  // Nach erfolgreichem Speichern klappt die Zeile zu und zeigt die neuen Werte
  // — die Action revalidiert den Pfad, die Leseansicht bekommt also frische
  // Props. Angepasst wird waehrend des Renderns statt in einem Effect: React
  // startet den Render dann sofort neu, ohne zwischendurch zu zeichnen (siehe
  // „Adjusting state when props change"). Ein Effect waere hier ein
  // kaskadierender Zusatzrender — und die Lint-Regel react-hooks/
  // set-state-in-effect verbietet ihn zu Recht.
  //
  // Verglichen wird die Objektidentitaet, weil useActionState je Ergebnis ein
  // neues Objekt liefert: Ein erneutes Aufklappen nach dem Speichern wuerde
  // sonst sofort wieder zuklappen.
  const [handledState, setHandledState] = useState(state)
  if (state !== handledState) {
    setHandledState(state)
    if (state.success) setIsEditing(false)
  }

  if (!isEditing) {
    return (
      <div className="space-y-2">
        <MeasureSummary
          measure={measure}
          action={
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setIsEditing(true)}
            >
              Bearbeiten
            </Button>
          }
        />
        <ActionMessage state={state} />
      </div>
    )
  }

  return (
    <form action={formAction} className="space-y-4 rounded-lg border p-4">
      <input type="hidden" name="measureId" value={measure.id} />
      <input type="hidden" name="reportId" value={reportId} />

      <div className="space-y-2">
        <label htmlFor={`title-${measure.id}`} className="text-sm font-medium">
          Titel <span className="text-destructive">*</span>
        </label>
        <Input
          id={`title-${measure.id}`}
          name="title"
          required
          maxLength={200}
          defaultValue={measure.title}
        />
      </div>

      <div className="space-y-2">
        <label htmlFor={`desc-${measure.id}`} className="text-sm font-medium">
          Beschreibung (optional)
        </label>
        <Textarea
          id={`desc-${measure.id}`}
          name="description"
          rows={3}
          defaultValue={measure.description ?? ""}
        />
      </div>

      <div className="space-y-2">
        <label htmlFor={`assigned-${measure.id}`} className="text-sm font-medium">
          Verantwortlich (optional)
        </label>
        <Input
          id={`assigned-${measure.id}`}
          name="assignedToText"
          defaultValue={measure.assignedToText ?? ""}
          placeholder="Name oder Funktion"
        />
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <label htmlFor={`due-${measure.id}`} className="text-sm font-medium">
            Fällig am (optional)
          </label>
          <Input
            id={`due-${measure.id}`}
            name="dueDate"
            type="date"
            defaultValue={formatDateInput(measure.dueDate)}
          />
        </div>

        <div className="space-y-2">
          <label
            className="text-sm font-medium"
            htmlFor={`status-${measure.id}`}
          >
            Status
          </label>
          <Select
            key={status}
            name="status"
            value={draftStatus}
            onValueChange={(next) => setDraftStatus(normalizeStatus(next))}
          >
            <SelectTrigger id={`status-${measure.id}`} className="w-full">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              {MEASURE_STATUS_VALUES.map((s) => (
                <SelectItem key={s} value={s}>
                  {MEASURE_STATUS_LABELS[s]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {askForDiscardReason ? (
        <div className="space-y-2 rounded-lg border border-amber-300 bg-amber-50/60 p-3 dark:border-amber-800 dark:bg-amber-950/20">
          <label
            htmlFor={`discard-${measure.id}`}
            className="text-sm font-medium"
          >
            Warum wird diese Maßnahme verworfen?{" "}
            <span className="text-destructive">*</span>
          </label>
          <Textarea
            id={`discard-${measure.id}`}
            name="discardReason"
            rows={2}
            value={discardReason}
            onChange={(event) => setDiscardReason(event.target.value)}
            placeholder="z. B. doppelt angelegt, oder durch eine andere Maßnahme abgedeckt"
          />
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="text-xs text-muted-foreground">
              Der Vermerk wird im Audit-Log festgehalten — bitte keine
              personenbezogenen Angaben eintragen.
            </p>
            <p className="text-xs tabular-nums text-muted-foreground">
              {discardReason.trim().length} /{" "}
              {MEASURE_DISCARD_REASON_MIN_LENGTH} Zeichen
            </p>
          </div>
        </div>
      ) : null}

      <div className="flex flex-wrap items-center gap-3">
        <Button
          type="submit"
          disabled={isPending || (askForDiscardReason && !discardReasonLongEnough)}
        >
          {isPending
            ? "Speichert..."
            : askForDiscardReason
              ? "Verwerfen"
              : "Speichern"}
        </Button>
        <Button
          type="button"
          variant="outline"
          disabled={isPending}
          onClick={() => setIsEditing(false)}
        >
          Abbrechen
        </Button>
        <ActionMessage state={state} />
      </div>
    </form>
  )
}

type Props = {
  reportId: string
  measures: MeasureRow[]
  canEdit: boolean
}

/**
 * Die Leseansicht einer Massnahme — fuer Bearbeiter wie fuer Nur-Leser
 * dieselbe. Zwei getrennte Fassungen wuerden auseinanderlaufen, und dann
 * behaupten Bearbeitersicht und Leseansicht Verschiedenes ueber dieselbe
 * Massnahme.
 *
 * Der Container bleibt grau und randlos, wie es docs/ui-guidelines.md fuer
 * Ausgabebereiche vorsieht: Auch beim Bearbeiter ist diese Zeile zunaechst
 * reine Anzeige. Die Interaktion traegt der Knopf in `action`, nicht der
 * Rahmen.
 *
 * `role="group"` mit sprechendem Namen ist bewusst gesetzt: Er benennt die
 * Zeile fuer Screenreader und ist zugleich der stabile Zugriff der E2E-Tests
 * (siehe tests/e2e/support/measures.ts) — ein Selektor auf Tailwind-Klassen
 * waere an die Optik gekoppelt und wuerde beim naechsten Umbau still auf das
 * falsche Element zeigen.
 */
function MeasureSummary({
  measure,
  action,
}: {
  measure: MeasureRow
  action?: React.ReactNode
}) {
  const status = normalizeStatus(measure.status)
  return (
    <div
      role="group"
      aria-label={`Maßnahme: ${measure.title}`}
      className="rounded-lg bg-muted/40 p-4 text-sm"
    >
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0 space-y-1">
          <p className="font-medium">{measure.title}</p>
          {measure.description ? (
            <p className="text-muted-foreground whitespace-pre-wrap">
              {measure.description}
            </p>
          ) : null}
          <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground">
            <span>Status: {MEASURE_STATUS_LABELS[status]}</span>
            {measure.dueDate ? (
              <span>· Fällig: {dueDateDisplay.format(measure.dueDate)}</span>
            ) : null}
            {measure.assignedToText ? (
              <span>· Verantwortlich: {measure.assignedToText}</span>
            ) : null}
          </div>
        </div>
        {action ? <div className="shrink-0">{action}</div> : null}
      </div>
    </div>
  )
}

export function ReportMeasuresSection({ reportId, measures, canEdit }: Props) {
  // Verworfene Massnahmen stehen getrennt und zaehlen nicht mit: Der Zaehler
  // meint den Stand der Nachverfolgung, nicht die Zahl der jemals angelegten
  // Zeilen. Geloescht wird nichts — sie bleiben aufklappbar erreichbar.
  const active = measures.filter((m) => normalizeStatus(m.status) !== "discarded")
  const discarded = measures.filter((m) => normalizeStatus(m.status) === "discarded")

  const renderMeasure = (m: MeasureRow) =>
    canEdit ? (
      <MeasureRow key={m.id} reportId={reportId} measure={m} />
    ) : (
      <MeasureSummary key={m.id} measure={m} />
    )

  return (
    <section className="mt-10" aria-label="Maßnahmen">
      <Card className="bg-muted/40">
        <CardHeader>
          <CardTitle>
            Maßnahmen{active.length > 0 ? ` (${active.length})` : ""}
          </CardTitle>
          {/* Der Rollenhinweis steht einmal oben auf der Seite, nicht noch
              einmal hier — siehe Kommentar in page.tsx. */}
          <CardDescription>
            {active.length === 0
              ? canEdit
                ? "Keine Maßnahmen in der Nachverfolgung. Neue Maßnahmen zu dieser Meldung können hier angelegt werden."
                : "Keine Maßnahmen in der Nachverfolgung."
              : "Sicherheitsmassnahmen zu dieser Meldung."}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-8">
          {canEdit ? <CreateMeasureForm reportId={reportId} /> : null}

          {/* Leerer Abschnitt: keine Zwischenueberschrift und kein
              Platzhalterblock, der Zaehler steht im Kopf. */}
          {measures.length > 0 ? (
            <div className="space-y-3">
              <p className="text-sm font-medium">Vorhandene Maßnahmen</p>

              {/*
                Alle Zeilen stehen in EINEM Array, mit der Zwischenueberschrift
                als eigenem Eintrag darin.

                Zwei getrennte Listen — oder auch nur zwei getrennte
                JSX-Ausdruecke im selben Container — waeren die naheliegende
                Loesung und funktionieren nicht: React reconciliert jede
                Kindposition fuer sich. Wechselt eine Massnahme beim Verwerfen
                von der einen Liste in die andere, haengt React die Komponente
                ab und neu an — und mit ihr verschwindet der Zustand aus
                useActionState, also genau die Erfolgsmeldung „Massnahme wurde
                verworfen.", die der Nutzer in diesem Moment braucht.

                In einem gemeinsamen Array mit stabilen Schluesseln ist
                derselbe Vorgang eine Umsortierung, und der Zustand bleibt.

                Die Trennung leisten die Zwischenueberschrift, der eigene
                Zaehler und der Ausschluss aus dem Hauptzaehler — nicht die
                DOM-Struktur.
              */}
              <div className="space-y-4">
                {[
                  ...active.map((m) => renderMeasure(m)),
                  ...(discarded.length > 0
                    ? [
                        <p
                          key="__discarded-heading"
                          className="border-t pt-4 text-sm text-muted-foreground"
                        >
                          Verworfen ({discarded.length}) — bleibt in der
                          Historie, zählt nicht zur Nachverfolgung
                        </p>,
                      ]
                    : []),
                  ...discarded.map((m) => renderMeasure(m)),
                ]}
              </div>
            </div>
          ) : null}

        </CardContent>
      </Card>
    </section>
  )
}
