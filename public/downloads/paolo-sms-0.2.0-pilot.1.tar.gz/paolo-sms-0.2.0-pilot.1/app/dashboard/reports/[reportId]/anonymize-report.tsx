"use client"

import { useActionState, useState } from "react"

import {
  anonymizeReport,
  type AnonymizeReportState,
} from "@/lib/actions/reports"

import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"

const initialState: AnonymizeReportState = {
  success: false,
  message: "",
}

type Props = {
  reportId: string
  alreadyAnonymized: boolean
  anonymizedAtLabel: string | null
  anonymizationNote: string | null
}

export function AnonymizeReportSection({
  reportId,
  alreadyAnonymized,
  anonymizedAtLabel,
  anonymizationNote,
}: Props) {
  const [state, formAction, isPending] = useActionState(
    anonymizeReport,
    initialState
  )
  const [confirming, setConfirming] = useState(false)

  const done = alreadyAnonymized || state.success

  return (
    <Card className="border-amber-500/40">
      <CardHeader>
        <CardTitle className="text-base">
          1. Personenbezogene Melderdaten entfernen
        </CardTitle>
        <CardDescription>
          Dieser Schritt braucht nur ausgeführt zu werden, wenn Name, Rolle
          oder Kontaktdaten des Melders in den dafür vorgesehenen Feldern
          eingetragen sind. Dabei werden nur strukturierte Melderdaten
          entfernt. Freitexte, Notizen und Anhänge bleiben unverändert.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {done ? (
          <div
            className="rounded-r-lg border-l-2 border-emerald-500 bg-emerald-50 px-4 py-3 text-sm leading-relaxed text-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-300"
            role="status"
          >
            <p className="font-medium">
              Strukturierte Melderdaten wurden anonymisiert.
            </p>
            {anonymizedAtLabel ? (
              <p className="mt-0.5">Anonymisiert am {anonymizedAtLabel}.</p>
            ) : null}
            {anonymizationNote ? (
              <p className="mt-0.5 text-emerald-700 dark:text-emerald-400">
                Hinweis: {anonymizationNote}
              </p>
            ) : null}
            <p className="mt-1 text-emerald-700 dark:text-emerald-400">
              Freitexte und Anhänge bleiben manuell zu prüfen.
            </p>
          </div>
        ) : confirming ? (
          <form action={formAction} className="space-y-3">
            <input type="hidden" name="reportId" value={reportId} />
            <div
              className="rounded-r-lg border-l-2 border-amber-500 bg-amber-50 px-4 py-3 text-sm leading-relaxed text-amber-800 dark:bg-amber-950/30 dark:text-amber-300"
              role="note"
            >
              Die strukturierten Melderdaten (Name, Rolle, Kontakt) werden
              dauerhaft entfernt. Dieser Schritt kann nicht rückgängig gemacht
              werden.
            </div>
            <div className="space-y-1.5">
              <label
                htmlFor="anonymization-note"
                className="text-sm font-medium text-foreground"
              >
                Hinweis zur Anonymisierung (optional)
              </label>
              <textarea
                id="anonymization-note"
                name="note"
                rows={2}
                maxLength={500}
                placeholder="z. B. Grund oder Bezug zur Betroffenenanfrage"
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
              />
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <Button
                type="submit"
                variant="outline"
                disabled={isPending}
                className="border-amber-500/60 text-amber-700 hover:bg-amber-500/10 dark:text-amber-300"
              >
                {isPending ? "Wird anonymisiert…" : "Endgültig anonymisieren"}
              </Button>
              <Button
                type="button"
                variant="ghost"
                disabled={isPending}
                onClick={() => setConfirming(false)}
              >
                Abbrechen
              </Button>
            </div>
          </form>
        ) : (
          <Button
            type="button"
            variant="outline"
            className="border-amber-500/60 text-amber-700 hover:bg-amber-500/10 dark:text-amber-300"
            onClick={() => setConfirming(true)}
          >
            Melderdaten anonymisieren
          </Button>
        )}

        {state.message && !state.success ? (
          <p className="text-sm text-destructive">{state.message}</p>
        ) : null}
      </CardContent>
    </Card>
  )
}
