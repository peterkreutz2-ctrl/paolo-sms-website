"use client"

import { useActionState, useState } from "react"

import {
  uploadReportAttachment,
  type UploadAttachmentState,
} from "@/lib/actions/attachments"
import {
  ATTACHMENT_ACCEPT_ATTRIBUTE,
  ATTACHMENT_TYPES_LABEL,
  MAX_FILE_SIZE_MB,
} from "@/lib/constants/attachment-file-types"
import { isPlayableVideo } from "@/lib/constants/attachment-visibility"
import { attachments } from "@/lib/db/schema"

import {
  AttachmentVideoPlayer,
  VideoUploadHint,
} from "@/components/attachment-video"
import { Button } from "@/components/ui/button"
import { UploadSafetyNotice } from "@/components/upload-safety-notice"

import { validateAttachmentFile } from "../../attachment-file-check"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"

import { DeleteAttachmentButton } from "./delete-attachment-button"

type AttachmentRow = typeof attachments.$inferSelect

type Props = {
  reportId: string
  attachments: AttachmentRow[]
  canUpload: boolean
  canDeleteAttachment: boolean
}

const initialState: UploadAttachmentState = {
  success: false,
  message: "",
}

const dateFormatter = new Intl.DateTimeFormat("de-DE", {
  dateStyle: "medium",
  timeStyle: "short",
})

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}

function formatMimeType(mimeType: string): string {
  if (mimeType === "application/pdf") return "PDF-Dokument"
  if (isPlayableVideo(mimeType)) return "Video (MP4)"
  if (mimeType.startsWith("image/")) return "Bilddatei"
  if (mimeType === "text/plain") return "Textdatei"
  if (mimeType.includes("gpx")) return "GPX-Tracklog"
  if (mimeType.includes("kml")) return "KML-Datei"
  return "Datei"
}

function AttachmentUploadForm({ reportId }: { reportId: string }) {
  const [state, formAction, isPending] = useActionState(
    uploadReportAttachment,
    initialState
  )
  // Clientseitige Vorpruefung bei der Dateiauswahl. Ohne sie sieht der Nutzer
  // bei einer zu grossen Datei keinen PAOLO-Text, sondern einen rohen 413 der
  // Plattform: Vercel weist den Request ab, BEVOR die Server Action laeuft.
  // Geprueft wird mit derselben Funktion wie serverseitig, bei Video
  // zusaetzlich die Laufzeit — die laesst sich nur hier bestimmen.
  const [localError, setLocalError] = useState<string | null>(null)
  const [checking, setChecking] = useState(false)

  async function handleFileChange(file: File | undefined) {
    setLocalError(null)
    if (!file) return
    setChecking(true)
    try {
      setLocalError(await validateAttachmentFile(file))
    } finally {
      setChecking(false)
    }
  }

  return (
    <form
      action={formAction}
      className="space-y-4 rounded-lg border p-4"
      onSubmit={(e) => {
        // Letzter Riegel, falls die Pruefung noch laeuft oder fehlschlug.
        if (localError || checking) e.preventDefault()
      }}
    >
      <input type="hidden" name="reportId" value={reportId} />

      <div className="space-y-2">
        <label htmlFor="report-file" className="text-sm font-medium">
          Datei hochladen
        </label>
        <Input
          id="report-file"
          name="file"
          type="file"
          required
          accept={ATTACHMENT_ACCEPT_ATTRIBUTE}
          onChange={(e) => void handleFileChange(e.target.files?.[0])}
        />
        <p className="text-xs text-muted-foreground">
          Erlaubt: {ATTACHMENT_TYPES_LABEL} (max. {MAX_FILE_SIZE_MB} MB).
        </p>
        <VideoUploadHint />
        <UploadSafetyNotice />
      </div>

      <div className="flex items-center gap-3">
        <Button
          type="submit"
          disabled={isPending || checking || localError !== null}
        >
          {isPending ? "Lädt hoch…" : checking ? "Prüft…" : "Anhang hochladen"}
        </Button>
        {localError ?? state.message ? (
          <p
            className={`text-sm ${
              !localError && state.success
                ? "text-emerald-600"
                : "text-destructive"
            }`}
          >
            {localError ?? state.message}
          </p>
        ) : null}
      </div>
    </form>
  )
}

export function ReportAttachmentsSection({
  reportId,
  attachments: rows,
  canUpload,
  canDeleteAttachment,
}: Props) {
  return (
    <section className="mt-10" aria-label="Anhänge">
      <Card className="bg-muted/40">
        <CardHeader>
          <CardTitle>Anhänge{rows.length > 0 ? ` (${rows.length})` : ""}</CardTitle>
          <CardDescription>
            {rows.length === 0
              ? canUpload
                ? "Noch keine Anhänge. Interne Dateien zur Meldung (z. B. Bilder, PDF, Tracklogs) können hier hochgeladen werden."
                : "Noch keine Anhänge zu dieser Meldung."
              : "Interne Dateien zur Meldung (z. B. Bilder, PDF, Tracklogs)."}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {canUpload ? <AttachmentUploadForm reportId={reportId} /> : null}

          {/* Leerer Abschnitt: nur die Kopfzeile, kein Platzhalterblock. Der
              Zaehler steht im CardHeader, damit ein vorhandener Anhang nicht
              uebersehen wird. */}
          {rows.length > 0 ? (
            <div className="space-y-3">
              <p className="text-sm font-medium">Vorhandene Anhänge</p>
              <div className="space-y-3">
                {rows.map((file) => (
                  <div
                    key={file.id}
                    className="space-y-3 rounded-lg border p-3 text-sm sm:p-4"
                  >
                    <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                      <div className="min-w-0">
                        <p className="truncate font-medium">
                          {file.originalFileName}
                        </p>
                        <p className="text-muted-foreground">{formatMimeType(file.mimeType)}</p>
                        <p className="text-xs text-muted-foreground">
                          {formatBytes(file.fileSize)} ·{" "}
                          {dateFormatter.format(file.createdAt)}
                        </p>
                      </div>
                      <div className="flex flex-shrink-0 flex-col gap-3 sm:items-end">
                        <a
                          href={`/dashboard/reports/${reportId}/attachments/${file.id}/download`}
                          target="_blank"
                          rel="noreferrer"
                          className="text-sm text-blue-800 hover:text-blue-900 hover:underline underline-offset-4"
                        >
                          Öffnen / Download
                        </a>
                        {canDeleteAttachment ? (
                          <DeleteAttachmentButton
                            reportId={reportId}
                            attachmentId={file.id}
                          />
                        ) : null}
                      </div>
                    </div>

                    {/* Der Download-Link oben bleibt bestehen — er ist der
                        Rueckfallweg fuer Geraete, die nicht abspielen. */}
                    {isPlayableVideo(file.mimeType) ? (
                      <AttachmentVideoPlayer
                        src={`/dashboard/reports/${reportId}/attachments/${file.id}/download`}
                        fileName={file.originalFileName}
                      />
                    ) : null}
                  </div>
                ))}
              </div>
            </div>
          ) : null}
        </CardContent>
      </Card>
    </section>
  )
}
