"use client"

import { useActionState, useEffect, useRef, useState } from "react"
import { useRouter } from "next/navigation"

import {
  updateReportClassification,
  updateReportCore,
  updateReportReporterInfo,
  updateReportWorkflow,
} from "@/lib/actions/reports"
import {
  ACTIVITY_AREA_LABELS,
  ACTIVITY_AREA_VALUES,
  ACTIVITY_TYPE_LABELS,
  ACTIVITY_TYPE_VALUES,
  DAMAGE_SEVERITY_LABELS,
  DAMAGE_SEVERITY_VALUES,
  FLIGHT_PHASE_LABELS,
  FLIGHT_PHASE_VALUES,
  INJURY_SEVERITY_LABELS,
  INJURY_SEVERITY_VALUES,
  LAUNCH_TYPE_LABELS,
  LAUNCH_TYPE_VALUES,
  REPORTER_ROLE_LABELS,
  REPORTER_ROLE_VALUES,
  type ActivityArea,
  type ActivityType,
  type DamageSeverity,
  type FlightPhase,
  type InjurySeverity,
  type LaunchType,
  type ReporterRole,
} from "@/lib/constants/report-classification"
import {
  REPORT_PRIORITY_LABELS,
  REPORT_PRIORITY_VALUES,
  REPORT_STATUS_LABELS,
  REPORT_STATUS_VALUES,
  isClosedOrHidden,
  type ReportPriority,
  type ReportStatus,
} from "@/lib/constants/report-workflow"
import {
  PUBLIC_REPORT_TYPE_LABELS,
  PUBLIC_REPORT_TYPE_VALUES,
  type PublicReportType,
} from "@/lib/constants/public-report-types"
import {
  RISK_PROBABILITY_LABELS,
  RISK_PROBABILITY_ICAO,
  RISK_PROBABILITY_VALUES,
  RISK_SEVERITY_LABELS,
  RISK_SEVERITY_ICAO,
  RISK_SEVERITY_VALUES,
  formatRiskCode,
  type RiskProbability,
  type RiskSeverity,
} from "@/lib/constants/report-risk"
import { RiskMatrix } from "./risk-matrix"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

// ─── Types ───────────────────────────────────────────────────────────────────

export type ReportCoreSectionProps = {
  reportId: string
  initialReportType: PublicReportType
  initialShortDescription: string
  initialDetailedDescription: string
  initialIsAnonymous: boolean
  initialOccurredAt: Date | null
  initialLocationText: string | null
  initialActivityType: ActivityType | null
  initialFlightPhase: FlightPhase | null
  initialLaunchType: LaunchType | null
  initialInjurySeverity: InjurySeverity | null
  initialDamageSeverity: DamageSeverity | null
  canEdit: boolean
}

export type ClassificationSectionProps = {
  reportId: string
  initialActivityArea: ActivityArea | null
  initialIsReportableAccident: boolean | null
  initialRiskProbability: RiskProbability | null
  initialRiskSeverity: RiskSeverity | null
  canEdit: boolean
}

export type ReporterSectionProps = {
  reportId: string
  initialReporterName: string | null
  initialReporterRole: ReporterRole | null
  initialReporterContact: string | null
  canEdit: boolean
  alreadyAnonymized: boolean
  anonymizedAtLabel: string | null
}

type WorkflowFormProps = {
  reportId: string
  initialStatus: ReportStatus
  initialPriority: ReportPriority
  canEdit: boolean
  alreadyAnonymized: boolean
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

const coreInitialState = { success: false, message: "" }
const workflowInitialState = { success: false, message: "" }
const classificationInitialState = { success: false, message: "" }
const reporterInitialState = { success: false, message: "" }

function boolToSelectValue(v: boolean | null): string {
  if (v === true) return "true"
  if (v === false) return "false"
  return "__none"
}

function toDatetimeLocal(date: Date | null): string {
  if (!date) return ""
  const offset = date.getTimezoneOffset()
  const local = new Date(date.getTime() - offset * 60000)
  return local.toISOString().slice(0, 16)
}

function formatOccurredAt(date: Date | null): string {
  if (!date) return "—"
  return date.toLocaleString("de-DE", { dateStyle: "medium", timeStyle: "short" })
}

// Warum an jedem <Select> ein `key` aus dem Serverwert steht:
// React 19 setzt nach JEDER abgeschlossenen Form-Action ein natives form.reset().
// Radix-Select haengt an diesem reset-EVENT und stellt dabei den Wert wieder her,
// den es beim MOUNT hatte (intern eingefrorene Referenz) — nicht den neu
// gespeicherten. Ohne Remount zeigte das Feld nach dem Speichern also wieder den
// Stand vom Seitenaufbau. Der aus dem Serverwert abgeleitete `key` mountet genau
// das eine Select neu, sobald sich sein gespeicherter Wert geaendert hat.
//
// Bewusst pro Feld und NICHT pro Sektion/Seite: ein sektionsweiter Remount wuerde
// ungespeicherte Eingaben der uebrigen Felder verwerfen und zusaetzlich den
// useActionState-Zustand (und damit die Erfolgsmeldung) mitloeschen.
//
// Text-, Textarea- und Datumsfelder brauchen das nicht: fuer sie fuehrt React das
// value-Attribut vor dem Reset auf den neuen Serverwert nach.

// ─── Internal forms ───────────────────────────────────────────────────────────

function ReportCoreFormEditable(props: Omit<ReportCoreSectionProps, "canEdit">) {
  const router = useRouter()
  const [state, formAction, isPending] = useActionState(updateReportCore, coreInitialState)

  useEffect(() => {
    if (state.success) router.refresh()
  }, [state, router])

  return (
    <form action={formAction} className="space-y-4">
      <input type="hidden" name="reportId" value={props.reportId} />

      <div className="space-y-2">
        <label htmlFor="core-reportType" className="text-sm font-medium">
          Art der Meldung
        </label>
        <Select key={props.initialReportType} name="reportType" defaultValue={props.initialReportType}>
          <SelectTrigger id="core-reportType" className="w-full">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {PUBLIC_REPORT_TYPE_VALUES.map((v) => (
              <SelectItem key={v} value={v}>
                {PUBLIC_REPORT_TYPE_LABELS[v]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <label htmlFor="core-shortDescription" className="text-sm font-medium">
          Kurzbeschreibung{" "}
          <span className="font-normal text-muted-foreground">(max. 120 Zeichen)</span>
        </label>
        <Input
          id="core-shortDescription"
          name="shortDescription"
          defaultValue={props.initialShortDescription}
          maxLength={120}
        />
      </div>

      <div className="space-y-2">
        <label htmlFor="core-detailedDescription" className="text-sm font-medium">
          Ausführliche Beschreibung
        </label>
        <Textarea
          id="core-detailedDescription"
          name="detailedDescription"
          defaultValue={props.initialDetailedDescription}
          rows={6}
          className="min-h-[8rem]"
        />
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <label htmlFor="core-isAnonymous" className="text-sm font-medium">
            Anonym
          </label>
          <Select key={props.initialIsAnonymous ? "true" : "false"} name="isAnonymous" defaultValue={props.initialIsAnonymous ? "true" : "false"}>
            <SelectTrigger id="core-isAnonymous" className="w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="true">Ja (anonym)</SelectItem>
              <SelectItem value="false">Nein (namentlich)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <label htmlFor="core-occurredAt" className="text-sm font-medium">
            Ereigniszeitpunkt
          </label>
          <input
            id="core-occurredAt"
            name="occurredAt"
            type="datetime-local"
            defaultValue={toDatetimeLocal(props.initialOccurredAt)}
            className="flex h-10 w-full rounded-md border border-input bg-white px-3 py-2 text-sm outline-none transition-colors focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/40"
          />
        </div>

        <div className="space-y-2 sm:col-span-2">
          <label htmlFor="core-locationText" className="text-sm font-medium">
            Ort / Fluggebiet
          </label>
          <Input
            id="core-locationText"
            name="locationText"
            defaultValue={props.initialLocationText ?? ""}
            placeholder="— leer lassen zum Entfernen —"
          />
        </div>

        <div className="space-y-2">
          <label htmlFor="core-activityType" className="text-sm font-medium">
            Flugtyp
          </label>
          <Select key={props.initialActivityType ?? "__none"} name="activityType" defaultValue={props.initialActivityType ?? "__none"}>
            <SelectTrigger id="core-activityType" className="w-full">
              <SelectValue placeholder="— bitte wählen —" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__none">— keine Angabe —</SelectItem>
              {ACTIVITY_TYPE_VALUES.map((v) => (
                <SelectItem key={v} value={v}>
                  {ACTIVITY_TYPE_LABELS[v]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <label htmlFor="core-flightPhase" className="text-sm font-medium">
            Flugphase
          </label>
          <Select key={props.initialFlightPhase ?? "__none"} name="flightPhase" defaultValue={props.initialFlightPhase ?? "__none"}>
            <SelectTrigger id="core-flightPhase" className="w-full">
              <SelectValue placeholder="— bitte wählen —" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__none">— keine Angabe —</SelectItem>
              {FLIGHT_PHASE_VALUES.map((v) => (
                <SelectItem key={v} value={v}>
                  {FLIGHT_PHASE_LABELS[v]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <label htmlFor="core-launchType" className="text-sm font-medium">
            Startart
          </label>
          <Select key={props.initialLaunchType ?? "__none"} name="launchType" defaultValue={props.initialLaunchType ?? "__none"}>
            <SelectTrigger id="core-launchType" className="w-full">
              <SelectValue placeholder="— bitte wählen —" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__none">— keine Angabe —</SelectItem>
              {LAUNCH_TYPE_VALUES.map((v) => (
                <SelectItem key={v} value={v}>
                  {LAUNCH_TYPE_LABELS[v]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <label htmlFor="core-injurySeverity" className="text-sm font-medium">
            Verletzungsschwere
          </label>
          <Select key={props.initialInjurySeverity ?? "__none"} name="injurySeverity" defaultValue={props.initialInjurySeverity ?? "__none"}>
            <SelectTrigger id="core-injurySeverity" className="w-full">
              <SelectValue placeholder="— bitte wählen —" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__none">— keine Angabe —</SelectItem>
              {INJURY_SEVERITY_VALUES.map((v) => (
                <SelectItem key={v} value={v}>
                  {INJURY_SEVERITY_LABELS[v]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <label htmlFor="core-damageSeverity" className="text-sm font-medium">
            Sachschadenschwere
          </label>
          <Select key={props.initialDamageSeverity ?? "__none"} name="damageSeverity" defaultValue={props.initialDamageSeverity ?? "__none"}>
            <SelectTrigger id="core-damageSeverity" className="w-full">
              <SelectValue placeholder="— bitte wählen —" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__none">— keine Angabe —</SelectItem>
              {DAMAGE_SEVERITY_VALUES.map((v) => (
                <SelectItem key={v} value={v}>
                  {DAMAGE_SEVERITY_LABELS[v]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <Button type="submit" disabled={isPending}>
          {isPending ? "Speichert..." : "Speichern"}
        </Button>

        {state.message ? (
          <p className={`text-sm ${state.success ? "text-emerald-600" : "text-destructive"}`}>
            {state.message}
          </p>
        ) : null}
      </div>
    </form>
  )
}

function ReportClassificationFormEditable({
  reportId,
  initialActivityArea,
  initialIsReportableAccident,
  initialRiskProbability,
  initialRiskSeverity,
}: Pick<
  ClassificationSectionProps,
  | "reportId"
  | "initialActivityArea"
  | "initialIsReportableAccident"
  | "initialRiskProbability"
  | "initialRiskSeverity"
>) {
  const router = useRouter()
  const [state, formAction, isPending] = useActionState(
    updateReportClassification,
    classificationInitialState
  )

  useEffect(() => {
    if (state.success) router.refresh()
  }, [state, router])

  return (
    <form action={formAction} className="space-y-4">
      <input type="hidden" name="reportId" value={reportId} />

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <label htmlFor="cl-activityArea" className="text-sm font-medium">
            Tätigkeitsbereich
          </label>
          <Select key={initialActivityArea ?? "__none"} name="activityArea" defaultValue={initialActivityArea ?? "__none"}>
            <SelectTrigger id="cl-activityArea" className="w-full">
              <SelectValue placeholder="— bitte wählen —" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__none">— keine Angabe —</SelectItem>
              {ACTIVITY_AREA_VALUES.map((v) => (
                <SelectItem key={v} value={v}>
                  {ACTIVITY_AREA_LABELS[v]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <label htmlFor="cl-isReportableAccident" className="text-sm font-medium">
            Meldepflichtiger Unfall (LuftVO)
          </label>
          <Select
            key={boolToSelectValue(initialIsReportableAccident)}
            name="isReportableAccident"
            defaultValue={boolToSelectValue(initialIsReportableAccident)}
          >
            <SelectTrigger id="cl-isReportableAccident" className="w-full">
              <SelectValue placeholder="— bitte wählen —" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__none">— nicht bewertet —</SelectItem>
              <SelectItem value="true">Ja – meldepflichtig</SelectItem>
              <SelectItem value="false">Nein – nicht meldepflichtig</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-3 rounded-md border border-dashed p-4">
        <div className="space-y-1">
          <p className="text-sm font-semibold text-foreground">
            Risikobewertung (ICAO)
          </p>
          <p className="text-sm text-muted-foreground">
            Strukturierte Bewertung Eintrittswahrscheinlichkeit × Schweregrad.
            Ergänzt die Bearbeitungspriorität, ersetzt sie nicht. „nicht
            bewertet“ ist zulässig.
          </p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <label htmlFor="cl-riskProbability" className="text-sm font-medium">
              Eintrittswahrscheinlichkeit
            </label>
            <Select key={initialRiskProbability ?? "__none"} name="riskProbability" defaultValue={initialRiskProbability ?? "__none"}>
              <SelectTrigger id="cl-riskProbability" className="w-full">
                <SelectValue placeholder="— nicht bewertet —" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__none">— nicht bewertet —</SelectItem>
                {RISK_PROBABILITY_VALUES.map((v) => (
                  <SelectItem key={v} value={v}>
                    {v} – {RISK_PROBABILITY_LABELS[v]} ({RISK_PROBABILITY_ICAO[v]})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label htmlFor="cl-riskSeverity" className="text-sm font-medium">
              Schweregrad
            </label>
            <Select key={initialRiskSeverity ?? "__none"} name="riskSeverity" defaultValue={initialRiskSeverity ?? "__none"}>
              <SelectTrigger id="cl-riskSeverity" className="w-full">
                <SelectValue placeholder="— nicht bewertet —" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__none">— nicht bewertet —</SelectItem>
                {RISK_SEVERITY_VALUES.map((v) => (
                  <SelectItem key={v} value={v}>
                    {v} – {RISK_SEVERITY_LABELS[v]} ({RISK_SEVERITY_ICAO[v]})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <p className="text-sm text-muted-foreground">
          Gespeicherter Risikocode:{" "}
          <span className="font-medium text-foreground">
            {formatRiskCode(initialRiskProbability, initialRiskSeverity) ??
              "nicht bewertet"}
          </span>
        </p>

        <RiskMatrix
          probability={initialRiskProbability}
          severity={initialRiskSeverity}
        />
      </div>

      <div className="flex items-center gap-3">
        <Button type="submit" disabled={isPending}>
          {isPending ? "Speichert..." : "Speichern"}
        </Button>

        {state.message ? (
          <p className={`text-sm ${state.success ? "text-emerald-600" : "text-destructive"}`}>
            {state.message}
          </p>
        ) : null}
      </div>
    </form>
  )
}

function ReportReporterInfoFormEditable({
  reportId,
  initialReporterName,
  initialReporterRole,
  initialReporterContact,
}: Pick<ReporterSectionProps, "reportId" | "initialReporterName" | "initialReporterRole" | "initialReporterContact">) {
  const router = useRouter()
  const [state, formAction, isPending] = useActionState(updateReportReporterInfo, reporterInitialState)

  useEffect(() => {
    if (state.success) router.refresh()
  }, [state, router])

  return (
    <form action={formAction} className="space-y-4">
      <input type="hidden" name="reportId" value={reportId} />

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <label htmlFor="rep-reporterName" className="text-sm font-medium">
            Name
          </label>
          <Input
            id="rep-reporterName"
            name="reporterName"
            defaultValue={initialReporterName ?? ""}
            placeholder="Name der meldenden Person"
          />
        </div>

        <div className="space-y-2">
          <label htmlFor="rep-reporterRole" className="text-sm font-medium">
            Rolle
          </label>
          <Select key={initialReporterRole ?? "__none"} name="reporterRole" defaultValue={initialReporterRole ?? "__none"}>
            <SelectTrigger id="rep-reporterRole" className="w-full">
              <SelectValue placeholder="— bitte wählen —" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__none">— keine Angabe —</SelectItem>
              {REPORTER_ROLE_VALUES.map((v) => (
                <SelectItem key={v} value={v}>
                  {REPORTER_ROLE_LABELS[v]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2 sm:col-span-2">
          <label htmlFor="rep-reporterContact" className="text-sm font-medium">
            Kontakt
          </label>
          <Input
            id="rep-reporterContact"
            name="reporterContact"
            defaultValue={initialReporterContact ?? ""}
            placeholder="E-Mail oder Telefonnummer"
          />
        </div>
      </div>

      <div className="flex items-center gap-3">
        <Button type="submit" disabled={isPending}>
          {isPending ? "Speichert..." : "Speichern"}
        </Button>

        {state.message ? (
          <p className={`text-sm ${state.success ? "text-emerald-600" : "text-destructive"}`}>
            {state.message}
          </p>
        ) : null}
      </div>
    </form>
  )
}

function ReportWorkflowFormEditable({
  reportId,
  initialStatus,
  initialPriority,
  alreadyAnonymized,
}: Pick<
  WorkflowFormProps,
  "reportId" | "initialStatus" | "initialPriority" | "alreadyAnonymized"
>) {
  const router = useRouter()
  const [state, formAction, isPending] = useActionState(updateReportWorkflow, workflowInitialState)
  const formRef = useRef<HTMLFormElement>(null)
  const anonInputRef = useRef<HTMLInputElement>(null)
  const [dialogOpen, setDialogOpen] = useState(false)

  useEffect(() => {
    if (state.success) router.refresh()
  }, [state, router])

  function submitWith(anonymize: boolean) {
    if (anonInputRef.current) {
      anonInputRef.current.value = anonymize ? "1" : ""
    }
    setDialogOpen(false)
    formRef.current?.requestSubmit()
  }

  // Beim Wechsel auf "closed"/"hidden" zuerst zur Anonymisierungspruefung
  // auffordern — es sei denn, die Melderdaten sind bereits anonymisiert.
  function handleSubmitClick() {
    const form = formRef.current
    if (!form) return
    // FormData liefert FormDataEntryValue | null; die Regel nimmt bewusst nur
    // einen String, damit ihre Signatur nicht fuer eine Aufrufstelle aufweicht.
    const status = new FormData(form).get("status")
    const isGroupStatus = typeof status === "string" && isClosedOrHidden(status)
    if (isGroupStatus && !alreadyAnonymized) {
      setDialogOpen(true)
    } else {
      submitWith(false)
    }
  }

  return (
    <form
      ref={formRef}
      action={formAction}
      className="space-y-4 rounded-md border bg-muted/40 p-4"
    >
      <p className="text-sm font-semibold text-foreground">Workflow-Bearbeitung</p>
      <input type="hidden" name="reportId" value={reportId} />
      <input ref={anonInputRef} type="hidden" name="anonymizeReporter" defaultValue="" />

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <label htmlFor="status" className="text-sm font-medium">
            Status
          </label>
          <Select key={initialStatus} name="status" defaultValue={initialStatus}>
            <SelectTrigger id="status" className="w-full">
              <SelectValue placeholder="Status wählen" />
            </SelectTrigger>
            <SelectContent>
              {REPORT_STATUS_VALUES.map((status) => (
                <SelectItem key={status} value={status}>
                  {REPORT_STATUS_LABELS[status]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <label htmlFor="priority" className="text-sm font-medium">
            Priorität
          </label>
          <Select key={initialPriority} name="priority" defaultValue={initialPriority}>
            <SelectTrigger id="priority" className="w-full">
              <SelectValue placeholder="Priorität wählen" />
            </SelectTrigger>
            <SelectContent>
              {REPORT_PRIORITY_VALUES.map((priority) => (
                <SelectItem key={priority} value={priority}>
                  {REPORT_PRIORITY_LABELS[priority]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <Button type="button" onClick={handleSubmitClick} disabled={isPending}>
          {isPending ? "Speichert..." : "Speichern"}
        </Button>

        {state.message ? (
          <p className={`text-sm ${state.success ? "text-emerald-600" : "text-destructive"}`}>
            {state.message}
          </p>
        ) : null}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent showCloseButton={false} className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Anonymisierung prüfen</DialogTitle>
            <DialogDescription>
              Diese Meldung wird abgeschlossen oder ausgeblendet. Bitte prüfe, ob
              personenbezogene Daten entfernt oder reduziert werden müssen.
              Strukturierte Melderdaten können jetzt anonymisiert werden.
              Freitexte und Anhänge müssen manuell geprüft werden.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="sm:flex-col sm:justify-stretch sm:gap-2">
            <Button
              type="button"
              onClick={() => submitWith(true)}
              className="w-full"
            >
              Status speichern und strukturierte Melderdaten jetzt anonymisieren
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => submitWith(false)}
              className="w-full"
            >
              Status speichern, Anonymisierung später manuell prüfen
            </Button>
            <Button
              type="button"
              variant="ghost"
              onClick={() => setDialogOpen(false)}
              className="w-full"
            >
              Abbrechen
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </form>
  )
}

// ─── Exports ──────────────────────────────────────────────────────────────────

export function ReportCoreSection(props: ReportCoreSectionProps) {
  if (!props.canEdit) {
    const reportTypeLabel = props.initialReportType
      ? (PUBLIC_REPORT_TYPE_LABELS[props.initialReportType] ?? props.initialReportType)
      : null
    const activityTypeLabel = props.initialActivityType
      ? (ACTIVITY_TYPE_LABELS[props.initialActivityType] ?? null)
      : null
    const flightPhaseLabel = props.initialFlightPhase
      ? (FLIGHT_PHASE_LABELS[props.initialFlightPhase] ?? null)
      : null
    const launchTypeLabel = props.initialLaunchType
      ? (LAUNCH_TYPE_LABELS[props.initialLaunchType] ?? null)
      : null
    const injurySeverityLabel = props.initialInjurySeverity
      ? (INJURY_SEVERITY_LABELS[props.initialInjurySeverity] ?? null)
      : null
    const damageSeverityLabel = props.initialDamageSeverity
      ? (DAMAGE_SEVERITY_LABELS[props.initialDamageSeverity] ?? null)
      : null

    const rows: Array<{ label: string; value: string | null; long?: boolean }> = [
      { label: "Art der Meldung", value: reportTypeLabel },
      { label: "Kurzbeschreibung", value: props.initialShortDescription || null },
      { label: "Ausführliche Beschreibung", value: props.initialDetailedDescription || null, long: true },
      { label: "Anonym", value: props.initialIsAnonymous ? "Ja" : "Nein" },
      { label: "Ereigniszeitpunkt", value: formatOccurredAt(props.initialOccurredAt) },
      { label: "Ort / Fluggebiet", value: props.initialLocationText || null },
      { label: "Flugtyp", value: activityTypeLabel },
      { label: "Flugphase", value: flightPhaseLabel },
      { label: "Startart", value: launchTypeLabel },
      { label: "Verletzungsschwere", value: injurySeverityLabel },
      { label: "Sachschadenschwere", value: damageSeverityLabel },
    ]

    return (
      <div className="space-y-3 rounded-md bg-muted/40 p-4">
        <p className="text-sm font-semibold text-foreground">Meldungsdaten</p>
        <dl className="space-y-1.5 text-sm">
          {rows.map(({ label, value, long }) => (
            <div key={label} className={long ? "space-y-0.5" : "flex flex-wrap gap-x-2"}>
              <dt className="shrink-0 text-muted-foreground">{label}:</dt>
              <dd className={long ? "whitespace-pre-wrap text-foreground" : "text-foreground"}>
                {value ?? "—"}
              </dd>
            </div>
          ))}
        </dl>
      </div>
    )
  }

  return (
    <div className="space-y-4 rounded-md border bg-muted/40 p-4">
      <p className="text-sm font-semibold text-foreground">Meldungsdaten</p>
      <ReportCoreFormEditable {...props} />
    </div>
  )
}

export function ReportClassificationSection({
  reportId,
  initialActivityArea,
  initialIsReportableAccident,
  initialRiskProbability,
  initialRiskSeverity,
  canEdit,
}: ClassificationSectionProps) {
  const riskCode = formatRiskCode(initialRiskProbability, initialRiskSeverity)

  return (
    <div className={`space-y-4 rounded-md p-4 ${canEdit ? "border bg-muted/40" : "bg-muted/40"}`}>
      <p className="text-sm font-semibold text-foreground">Klassifikation</p>

      {canEdit ? (
        <ReportClassificationFormEditable
          reportId={reportId}
          initialActivityArea={initialActivityArea}
          initialIsReportableAccident={initialIsReportableAccident}
          initialRiskProbability={initialRiskProbability}
          initialRiskSeverity={initialRiskSeverity}
        />
      ) : (
        <div className="space-y-1 text-sm text-muted-foreground">
          {initialActivityArea ? (
            <p>Tätigkeitsbereich: {ACTIVITY_AREA_LABELS[initialActivityArea]}</p>
          ) : null}
          {initialIsReportableAccident !== null ? (
            <p>
              Meldepflichtiger Unfall:{" "}
              {initialIsReportableAccident ? "Ja – meldepflichtig" : "Nein – nicht meldepflichtig"}
            </p>
          ) : null}
          <p>
            Eintrittswahrscheinlichkeit:{" "}
            {initialRiskProbability
              ? `${initialRiskProbability} – ${RISK_PROBABILITY_LABELS[initialRiskProbability]}`
              : "nicht bewertet"}
          </p>
          <p>
            Schweregrad:{" "}
            {initialRiskSeverity
              ? `${initialRiskSeverity} – ${RISK_SEVERITY_LABELS[initialRiskSeverity]}`
              : "nicht bewertet"}
          </p>
          {riskCode ? <p>Risikocode: {riskCode}</p> : null}
          <div className="pt-2">
            <RiskMatrix
              probability={initialRiskProbability}
              severity={initialRiskSeverity}
            />
          </div>
          {!initialActivityArea && initialIsReportableAccident === null ? (
            <p className="italic">Keine Klassifikation erfasst.</p>
          ) : null}
        </div>
      )}
    </div>
  )
}

export function ReportReporterSection({
  reportId,
  initialReporterName,
  initialReporterRole,
  initialReporterContact,
  canEdit,
  alreadyAnonymized,
  anonymizedAtLabel,
}: ReporterSectionProps) {
  // Nach Anonymisierung sind Melderdaten gesperrt — unabhängig von canEdit.
  // Das Formular wird durch eine reine Anzeige mit Anonymisierungshinweis
  // ersetzt, konsistent mit dem serverseitigen Guard in updateReportReporterInfo.
  const editable = canEdit && !alreadyAnonymized

  return (
    <div className={`space-y-4 rounded-md p-4 ${editable ? "border bg-muted/40" : "bg-muted/40"}`}>
      <p className="text-sm font-semibold text-foreground">Melder-Informationen</p>

      {alreadyAnonymized ? (
        <div className="space-y-2 text-sm">
          <p className="text-muted-foreground">
            Melderdaten wurden anonymisiert
            {anonymizedAtLabel ? ` am ${anonymizedAtLabel}` : ""}. Diese Angaben
            können nicht erneut gesetzt werden.
          </p>
          <p className="italic text-muted-foreground">Anonym</p>
        </div>
      ) : editable ? (
        <ReportReporterInfoFormEditable
          reportId={reportId}
          initialReporterName={initialReporterName}
          initialReporterRole={initialReporterRole}
          initialReporterContact={initialReporterContact}
        />
      ) : (
        <div className="space-y-1 text-sm text-muted-foreground">
          {initialReporterName ? (
            <p>Name: {initialReporterName}</p>
          ) : (
            <p className="italic">Anonym</p>
          )}
          {initialReporterRole ? (
            <p>Rolle: {REPORTER_ROLE_LABELS[initialReporterRole]}</p>
          ) : null}
          {initialReporterContact ? (
            <p>Kontakt: {initialReporterContact}</p>
          ) : null}
        </div>
      )}
    </div>
  )
}

export function ReportWorkflowForm({
  reportId,
  initialStatus,
  initialPriority,
  canEdit,
  alreadyAnonymized,
}: WorkflowFormProps) {
  if (!canEdit) {
    // Der Rollenhinweis steht einmal oben auf der Seite und nicht noch einmal
    // hier — siehe Kommentar in page.tsx.
    return (
      <div className="space-y-2 rounded-md bg-muted/40 p-4 text-sm">
        <p className="font-medium text-foreground">Workflow</p>
        <p>Status: {REPORT_STATUS_LABELS[initialStatus]}</p>
        <p>Priorität: {REPORT_PRIORITY_LABELS[initialPriority]}</p>
      </div>
    )
  }

  return (
    <ReportWorkflowFormEditable
      reportId={reportId}
      initialStatus={initialStatus}
      initialPriority={initialPriority}
      alreadyAnonymized={alreadyAnonymized}
    />
  )
}
