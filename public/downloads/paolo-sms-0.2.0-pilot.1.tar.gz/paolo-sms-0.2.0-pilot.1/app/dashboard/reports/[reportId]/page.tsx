import { appAuth } from "@/lib/auth"
import { and, desc, eq, isNull } from "drizzle-orm"
import { notFound, redirect } from "next/navigation"

import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { listDirectoryUsers } from "@/lib/auth/user-directory"
import { db } from "@/lib/db"
import {
  attachments,
  measures,
  organizations,
  reportNotes,
  reportRetentionReviews,
  reports,
} from "@/lib/db/schema"
import {
  hasAttachmentAccessRole,
  hasReportNotesReadRole,
  hasReportReadRole,
  hasReporterIdentityReadRole,
  hasSafetyEditRole,
} from "@/lib/constants/roles"
import {
  computeMinPostponedUntil,
  computeRetentionReviewDueAt,
  computeRetentionReviewStatus,
  RETENTION_REVIEW_STATUS_LABELS,
} from "@/lib/constants/report-retention"
import {
  ACTIVITY_AREA_VALUES,
  ACTIVITY_TYPE_VALUES,
  DAMAGE_SEVERITY_VALUES,
  FLIGHT_PHASE_VALUES,
  INJURY_SEVERITY_VALUES,
  LAUNCH_TYPE_VALUES,
  REPORTER_ROLE_VALUES,
  type ActivityArea,
  type ActivityType,
  type DamageSeverity,
  type FlightPhase,
  type InjurySeverity,
  type LaunchType,
  type ReporterRole,
} from "@/lib/constants/report-classification"
import {
  REPORT_PRIORITY_VALUES,
  REPORT_STATUS_VALUES,
  SOURCE_CHANNEL_LABELS,
  SOURCE_CHANNEL_VALUES,
  isClosedOrHidden,
  type ReportPriority,
  type ReportStatus,
  type SourceChannel,
} from "@/lib/constants/report-workflow"
import {
  PUBLIC_REPORT_TYPE_LABELS,
  PUBLIC_REPORT_TYPE_VALUES,
  type PublicReportType,
} from "@/lib/constants/public-report-types"
import {
  isRiskProbability,
  isRiskSeverity,
} from "@/lib/constants/report-risk"

import { ReportMeasuresSection } from "./report-measures"
import { ReportAttachmentsSection } from "./report-attachments"
import { ReportNotesSection } from "./report-notes"
import {
  ReportClassificationSection,
  ReportCoreSection,
  ReportReporterSection,
  ReportWorkflowForm,
} from "./workflow-form"
import { SoftDeleteReportButton } from "./soft-delete-report-button"
import { AnonymizeReportSection } from "./anonymize-report"
import { RetentionReviewSection, type RetentionReviewEntry } from "./retention-review"

type Props = {
  params: Promise<{
    reportId: string
  }>
}

function formatDate(date: Date) {
  return date.toLocaleString("de-CH", { dateStyle: "medium", timeStyle: "short" })
}

export default async function ReportDetailPage({
  params,
}: Props) {
  const { reportId } = await params

  const { userId } = await appAuth()
  if (!userId) {
    redirect("/sign-in")
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasReportReadRole(roleKeys)) {
    notFound()
  }

  // Ue1 (#50): Beides wird VOR den Abfragen bestimmt, damit die Daten fuer eine
  // Rolle ohne die Faehigkeit gar nicht erst geladen werden. Ein bloss nicht
  // gerendertes Feld waere zu spaet — es laege im ausgelieferten HTML.
  const canReadReporterIdentity = hasReporterIdentityReadRole(roleKeys)
  const canReadNotes = hasReportNotesReadRole(roleKeys)

  const [
    reportRows,
    reportMeasures,
    reportAttachments,
    notes,
    retentionReviews,
    organizationRows,
    reporterIdentityRows,
  ] =
    await Promise.all([
      // Ue1 (#50): Spalten einzeln statt select(). reporterName, reporterRole
      // und reporterContact fehlen hier bewusst — sie kommen nur ueber die
      // bedingte Abfrage weiter unten, und nur fuer Rollen, die sie lesen
      // duerfen. reporterLessonsLearned und reporterSuggestedMeasures bleiben:
      // Das ist sicherheitsfachlicher Inhalt der meldenden Person, keine
      // Identitaet. Gleiches Muster wie in lib/queries/report-list.ts.
      db
        .select({
          id: reports.id,
          shortDescription: reports.shortDescription,
          detailedDescription: reports.detailedDescription,
          reportType: reports.reportType,
          sourceChannel: reports.sourceChannel,
          status: reports.status,
          priority: reports.priority,
          occurredAt: reports.occurredAt,
          locationText: reports.locationText,
          activityType: reports.activityType,
          activityArea: reports.activityArea,
          flightPhase: reports.flightPhase,
          launchType: reports.launchType,
          injurySeverity: reports.injurySeverity,
          damageSeverity: reports.damageSeverity,
          isReportableAccident: reports.isReportableAccident,
          isAnonymous: reports.isAnonymous,
          riskProbability: reports.riskProbability,
          riskSeverity: reports.riskSeverity,
          reporterLessonsLearned: reports.reporterLessonsLearned,
          reporterSuggestedMeasures: reports.reporterSuggestedMeasures,
          anonymizedAt: reports.anonymizedAt,
          anonymizationNote: reports.anonymizationNote,
          retentionReviewEligibleAt: reports.retentionReviewEligibleAt,
          createdAt: reports.createdAt,
          updatedAt: reports.updatedAt,
        })
        .from(reports)
        .where(and(eq(reports.id, reportId), isNull(reports.deletedAt)))
        .limit(1),
      db
        .select()
        .from(measures)
        .where(eq(measures.reportId, reportId))
        .orderBy(desc(measures.createdAt)),
      db
        .select()
        .from(attachments)
        .where(eq(attachments.reportId, reportId))
        .orderBy(desc(attachments.createdAt)),
      // Ue1 (#50): Ohne die Faehigkeit wird die Abfrage nicht ausgefuehrt.
      canReadNotes
        ? db
            .select()
            .from(reportNotes)
            .where(eq(reportNotes.reportId, reportId))
            .orderBy(desc(reportNotes.createdAt))
        : Promise.resolve([]),
      // Deterministisch nach createdAt, bei Gleichstand nach id (absteigend).
      db
        .select()
        .from(reportRetentionReviews)
        .where(eq(reportRetentionReviews.reportId, reportId))
        .orderBy(desc(reportRetentionReviews.createdAt), desc(reportRetentionReviews.id)),
      db
        .select({
          id: organizations.id,
          reportRetentionReviewIntervalMonths:
            organizations.reportRetentionReviewIntervalMonths,
        })
        .from(organizations)
        .limit(1),
      // Ue1 (#50): Die strukturierte Melderidentitaet liegt in einer eigenen,
      // bedingten Abfrage. Ohne die Faehigkeit verlaesst sie die Datenbank
      // nicht — sie wird nicht bloss ausgeblendet.
      canReadReporterIdentity
        ? db
            .select({
              reporterName: reports.reporterName,
              reporterRole: reports.reporterRole,
              reporterContact: reports.reporterContact,
            })
            .from(reports)
            .where(and(eq(reports.id, reportId), isNull(reports.deletedAt)))
            .limit(1)
        : Promise.resolve([]),
    ])

  const [report] = reportRows
  const [organization] = organizationRows
  const [reporterIdentity] = reporterIdentityRows

  // Resolve note author names from Clerk (best-effort, falls back to truncated ID in component)
  const authorIds = [...new Set(notes.map((n) => n.authorClerkUserId))]
  const authorNames: Record<string, string> = {}
  if (authorIds.length > 0) {
    try {
      const users = await listDirectoryUsers({ ids: authorIds, limit: authorIds.length + 1 })
      for (const user of users) authorNames[user.id] = user.displayName
    } catch {
      // Clerk unavailable — component faellt auf gekuerzte IDs zurueck
    }
  }

  // Resolve retention-reviewer names from Clerk (gleiches Best-Effort-Muster)
  const reviewerIds = [...new Set(retentionReviews.map((r) => r.reviewedByClerkUserId))]
  const reviewerNames: Record<string, string> = {}
  if (reviewerIds.length > 0) {
    try {
      const users = await listDirectoryUsers({ ids: reviewerIds, limit: reviewerIds.length + 1 })
      for (const user of users) reviewerNames[user.id] = user.displayName
    } catch {
      // Clerk unavailable — Fallback auf gekuerzte ID unten
    }
  }

  if (!report) {
    notFound()
  }

  const status = REPORT_STATUS_VALUES.includes(report.status as ReportStatus)
    ? (report.status as ReportStatus)
    : "new"
  const priority = REPORT_PRIORITY_VALUES.includes(report.priority as ReportPriority)
    ? (report.priority as ReportPriority)
    : "medium"
  const sourceChannel = SOURCE_CHANNEL_VALUES.includes(report.sourceChannel as SourceChannel)
    ? (report.sourceChannel as SourceChannel)
    : null
  const reportType = PUBLIC_REPORT_TYPE_VALUES.includes(report.reportType as PublicReportType)
    ? (report.reportType as PublicReportType)
    : null

  const activityArea = ACTIVITY_AREA_VALUES.includes(report.activityArea as ActivityArea)
    ? (report.activityArea as ActivityArea)
    : null
  const activityType = ACTIVITY_TYPE_VALUES.includes(report.activityType as ActivityType)
    ? (report.activityType as ActivityType)
    : null
  const flightPhase = FLIGHT_PHASE_VALUES.includes(report.flightPhase as FlightPhase)
    ? (report.flightPhase as FlightPhase)
    : null
  const launchType = LAUNCH_TYPE_VALUES.includes(report.launchType as LaunchType)
    ? (report.launchType as LaunchType)
    : null
  const injurySeverity = INJURY_SEVERITY_VALUES.includes(report.injurySeverity as InjurySeverity)
    ? (report.injurySeverity as InjurySeverity)
    : null
  const damageSeverity = DAMAGE_SEVERITY_VALUES.includes(report.damageSeverity as DamageSeverity)
    ? (report.damageSeverity as DamageSeverity)
    : null
  const reporterRole = REPORTER_ROLE_VALUES.includes(
    reporterIdentity?.reporterRole as ReporterRole
  )
    ? (reporterIdentity?.reporterRole as ReporterRole)
    : null
  const riskProbability = isRiskProbability(report.riskProbability)
    ? report.riskProbability
    : null
  const riskSeverity = isRiskSeverity(report.riskSeverity)
    ? report.riskSeverity
    : null

  const canSafetyEdit = hasSafetyEditRole(roleKeys)
  const canUploadAttachment = hasAttachmentAccessRole(roleKeys)

  const retentionIntervalMonths = organization?.reportRetentionReviewIntervalMonths ?? null
  const retentionReviewStatus = computeRetentionReviewStatus(
    report.retentionReviewEligibleAt,
    retentionIntervalMonths
  )
  const retentionReviewDueAt = computeRetentionReviewDueAt(
    report.retentionReviewEligibleAt,
    retentionIntervalMonths
  )
  const retentionReviewHistory: RetentionReviewEntry[] = retentionReviews.map((entry) => ({
    id: entry.id,
    decision: entry.decision,
    reason: entry.reason,
    postponedUntil: entry.postponedUntil,
    createdAt: formatDate(entry.createdAt),
    reviewerName:
      reviewerNames[entry.reviewedByClerkUserId] ??
      `${entry.reviewedByClerkUserId.slice(0, 12)}…`,
  }))

  const minPostponedUntil = computeMinPostponedUntil()

  return (
    <main className="max-w-3xl mx-auto space-y-6 p-8">

      {/* 1. Title */}
      <h1 className="text-2xl font-semibold">{report.shortDescription}</h1>

      {/* Ein Rollenhinweis pro Seite, nicht pro Abschnitt. Vorher stand
          „Nur Administratoren und Safety Manager können …" zusaetzlich im
          Workflow- und im Massnahmen-Block; fuer einen Safety Assistant war
          dieselbe Absage bis zu viermal auf einer Seite zu lesen. */}
      <div className="rounded-md bg-muted/40 px-4 py-3 text-sm text-muted-foreground">
        {canSafetyEdit ? (
          <p>Status, Priorität, Notizen und Maßnahmen können hier bearbeitet werden. Alle Änderungen werden im Audit-Log festgehalten.</p>
        ) : (
          <p>Diese Meldung wird nur angezeigt. Klassifikation, Status, Priorität und Maßnahmen bearbeiten Administratoren und Safety Manager; dort liegen auch die Angaben zur meldenden Person und die internen Notizen. Anhänge können Sie hochladen.</p>
        )}
      </div>

      {/* 2. Report type + timestamps */}
      <div className="text-sm text-muted-foreground space-y-0.5">
        {reportType ? (
          <p className="font-medium text-foreground">
            {PUBLIC_REPORT_TYPE_LABELS[reportType]}
          </p>
        ) : null}
        <p>Eingegangen: {formatDate(report.createdAt)}</p>
        <p>Zuletzt geändert: {formatDate(report.updatedAt)}</p>
      </div>

      {/* 3. Source */}
      {sourceChannel ? (
        <div className="text-sm text-muted-foreground">
          <p>Erfassungskanal: {SOURCE_CHANNEL_LABELS[sourceChannel]}</p>
        </div>
      ) : null}

      {/* 4. Core fields (Safety Manager edit) */}
      <ReportCoreSection
        reportId={report.id}
        initialReportType={reportType ?? "other"}
        initialShortDescription={report.shortDescription}
        initialDetailedDescription={report.detailedDescription}
        initialIsAnonymous={report.isAnonymous}
        initialOccurredAt={report.occurredAt ?? null}
        initialLocationText={report.locationText ?? null}
        initialActivityType={activityType}
        initialFlightPhase={flightPhase}
        initialLaunchType={launchType}
        initialInjurySeverity={injurySeverity}
        initialDamageSeverity={damageSeverity}
        canEdit={canSafetyEdit}
      />

      {/* 5. Reporter info — Ue1 (#50): nur fuer den Bearbeiterkreis.
          Ohne die Faehigkeit wurde die Identitaet oben schon nicht geladen;
          hier steht bewusst gar nichts statt eines leeren Blocks, damit die
          Seite nicht andeutet, es gebe etwas zu sehen. */}
      {canReadReporterIdentity ? (
        <ReportReporterSection
          reportId={report.id}
          initialReporterName={reporterIdentity?.reporterName ?? null}
          initialReporterRole={reporterRole}
          initialReporterContact={reporterIdentity?.reporterContact ?? null}
          canEdit={canSafetyEdit}
          alreadyAnonymized={Boolean(report.anonymizedAt)}
          anonymizedAtLabel={report.anonymizedAt ? formatDate(report.anonymizedAt) : null}
        />
      ) : null}

      {/* 6. Classification */}
      <ReportClassificationSection
        reportId={report.id}
        initialActivityArea={activityArea}
        initialIsReportableAccident={report.isReportableAccident ?? null}
        initialRiskProbability={riskProbability}
        initialRiskSeverity={riskSeverity}
        canEdit={canSafetyEdit}
      />

      {/* 7. Workflow (status, priority) */}
      <ReportWorkflowForm
        reportId={report.id}
        initialStatus={status}
        initialPriority={priority}
        canEdit={canSafetyEdit}
        alreadyAnonymized={Boolean(report.anonymizedAt)}
      />

      {/* 9. Lessons learned */}
      {report.reporterLessonsLearned ? (
        <div>
          <p className="text-sm font-medium text-foreground">Was habe ich gelernt?</p>
          <p className="mt-1 whitespace-pre-wrap text-sm text-muted-foreground">
            {report.reporterLessonsLearned}
          </p>
        </div>
      ) : null}

      {/* 10. Suggested measures */}
      {report.reporterSuggestedMeasures ? (
        <div>
          <p className="text-sm font-medium text-foreground">Vorgeschlagene Maßnahme</p>
          <p className="mt-1 whitespace-pre-wrap text-sm text-muted-foreground">
            {report.reporterSuggestedMeasures}
          </p>
        </div>
      ) : null}

      {/* 11. Notes / Nachträge — Ue1 (#50): nur fuer den Bearbeiterkreis.
          Notizen tragen den Bearbeitungsdiskurs und nennen ihren Verfasser. */}
      {canReadNotes ? (
        <ReportNotesSection
          reportId={report.id}
          notes={notes}
          authorNames={authorNames}
          canAdd={canSafetyEdit}
        />
      ) : null}

      {/* 12. Attachments */}
      <ReportAttachmentsSection
        reportId={report.id}
        attachments={reportAttachments}
        canUpload={canUploadAttachment}
        canDeleteAttachment={canSafetyEdit}
      />

      {/* 13. Measures */}
      <ReportMeasuresSection reportId={report.id} measures={reportMeasures} canEdit={canSafetyEdit} />

      {/* 14. Anonymisierung strukturierter Melderdaten (abgeschlossene oder ausgeblendete Meldungen) */}
      {canSafetyEdit && isClosedOrHidden(status) ? (
        <AnonymizeReportSection
          reportId={report.id}
          alreadyAnonymized={Boolean(report.anonymizedAt)}
          anonymizedAtLabel={report.anonymizedAt ? formatDate(report.anonymizedAt) : null}
          anonymizationNote={report.anonymizationNote ?? null}
        />
      ) : null}

      {/* 15. Datenschutzpruefung (Retention Review) — nur wenn der Anker gesetzt ist */}
      {canSafetyEdit && report.retentionReviewEligibleAt ? (
        <RetentionReviewSection
          reportId={report.id}
          canEdit={canSafetyEdit}
          status={retentionReviewStatus}
          statusLabel={RETENTION_REVIEW_STATUS_LABELS[retentionReviewStatus]}
          dueAtLabel={retentionReviewDueAt ? formatDate(retentionReviewDueAt) : null}
          history={retentionReviewHistory}
          minPostponedUntil={minPostponedUntil}
        />
      ) : null}

      {canSafetyEdit ? (
        <div>
          <SoftDeleteReportButton reportId={report.id} />
        </div>
      ) : null}
    </main>
  )
}
