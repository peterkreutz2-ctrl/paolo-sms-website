import {
  RISK_PROBABILITY_LABELS,
  RISK_PROBABILITY_VALUES,
  RISK_SEVERITY_LABELS,
  RISK_SEVERITY_VALUES,
  RISK_TOLERANCE_LABELS,
  RISK_TOLERANCE_VALUES,
  formatRiskCode,
  getRiskTolerance,
  type RiskProbability,
  type RiskSeverity,
  type RiskTolerance,
} from "@/lib/constants/report-risk"

type Props = {
  probability: RiskProbability | null
  severity: RiskSeverity | null
}

// Farbklassen je Bereich (Presentation). Farbe ist nie die einzige Information:
// jede Zelle traegt zusaetzlich den Code als Text und ein aria-label mit dem
// Toleranznamen; die Legende ist beschriftet.
const TOLERANCE_CELL_CLASSES: Record<RiskTolerance, string> = {
  intolerable: "bg-red-200 text-red-950",
  tolerable: "bg-amber-200 text-amber-950",
  acceptable: "bg-emerald-200 text-emerald-950",
}

export function RiskMatrix({ probability, severity }: Props) {
  const isAssessed = probability !== null && severity !== null
  const activeCode = formatRiskCode(probability, severity)
  const activeTolerance = getRiskTolerance(probability, severity)
  const activeLabel = activeTolerance
    ? RISK_TOLERANCE_LABELS[activeTolerance]
    : null

  return (
    <div className="space-y-3">
      <div className="space-y-0.5">
        <p className="text-sm font-medium text-foreground">Risikomatrix (ICAO)</p>
        {isAssessed && activeCode ? (
          <p className="text-sm text-muted-foreground">
            Aktuelle Bewertung:{" "}
            <span className="font-medium text-foreground">{activeCode}</span>
            {activeLabel ? ` – ${activeLabel}` : null}
          </p>
        ) : (
          <p className="text-sm text-muted-foreground">Risikomatrix nicht bewertet</p>
        )}
      </div>

      <div className="overflow-x-auto">
        <table className="border-collapse text-center text-xs">
          <caption className="sr-only">
            ICAO-Risikomatrix: Eintrittswahrscheinlichkeit (Zeilen 5 bis 1) mal
            Schweregrad (Spalten A bis E)
          </caption>
          <thead>
            <tr>
              <th className="p-1" scope="col">
                <span className="sr-only">Wahrscheinlichkeit \ Schweregrad</span>
              </th>
              {RISK_SEVERITY_VALUES.map((s) => (
                <th
                  key={s}
                  scope="col"
                  title={RISK_SEVERITY_LABELS[s]}
                  className="w-10 p-1 font-semibold text-muted-foreground"
                >
                  {s}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {RISK_PROBABILITY_VALUES.map((p) => (
              <tr key={p}>
                <th
                  scope="row"
                  title={RISK_PROBABILITY_LABELS[p]}
                  className="p-1 font-semibold text-muted-foreground"
                >
                  {p}
                </th>
                {RISK_SEVERITY_VALUES.map((s) => {
                  const tolerance = getRiskTolerance(p, s)
                  const code = `${p}${s}`
                  const isActive = isAssessed && code === activeCode
                  const toleranceLabel = tolerance
                    ? RISK_TOLERANCE_LABELS[tolerance]
                    : ""
                  return (
                    <td key={s} className="p-0.5">
                      <div
                        aria-label={`${code}: ${toleranceLabel}${
                          isActive ? ", aktuelle Bewertung" : ""
                        }`}
                        aria-current={isActive ? "true" : undefined}
                        className={`flex h-8 w-10 items-center justify-center rounded-sm ${
                          tolerance ? TOLERANCE_CELL_CLASSES[tolerance] : "bg-muted"
                        } ${
                          isActive
                            ? "font-bold ring-2 ring-foreground ring-offset-1"
                            : "font-medium"
                        }`}
                      >
                        {code}
                        {isActive ? (
                          <span className="sr-only"> (aktuell)</span>
                        ) : null}
                      </div>
                    </td>
                  )
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <ul className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
        {RISK_TOLERANCE_VALUES.map((t) => (
          <li key={t} className="flex items-center gap-1.5">
            <span
              aria-hidden="true"
              className={`inline-block h-3 w-3 rounded-sm ${TOLERANCE_CELL_CLASSES[t]}`}
            />
            {RISK_TOLERANCE_LABELS[t]}
          </li>
        ))}
      </ul>
    </div>
  )
}
