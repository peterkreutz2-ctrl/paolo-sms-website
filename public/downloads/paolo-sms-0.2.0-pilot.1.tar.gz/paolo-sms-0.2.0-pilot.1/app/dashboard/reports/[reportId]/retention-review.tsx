"use client"

import { useActionState, useEffect, useRef, useState } from "react"

import {
  logRetentionReview,
  type LogRetentionReviewState,
} from "@/lib/actions/reports"
import {
  REPORT_RETENTION_REVIEW_DECISION_LABELS,
  REPORT_RETENTION_REVIEW_DECISION_VALUES,
  type RetentionReviewStatus,
} from "@/lib/constants/report-retention"

import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"

const initialState: LogRetentionReviewState = {
  success: false,
  message: "",
}

export type RetentionReviewEntry = {
  id: string
  decision: string
  reason: string | null
  postponedUntil: string | null
  createdAt: string
  reviewerName: string
}

type Props = {
  reportId: string
  canEdit: boolean
  status: RetentionReviewStatus
  statusLabel: string
  dueAtLabel: string | null
  history: RetentionReviewEntry[]
  minPostponedUntil: string
}

const STATUS_CLASSNAMES: Record<RetentionReviewStatus, string> = {
  not_configured: "text-muted-foreground",
  not_eligible: "text-muted-foreground",
  current: "text-emerald-600 dark:text-emerald-400",
  soon: "text-amber-600 dark:text-amber-400",
  overdue: "text-red-600 dark:text-red-400",
}

export function decisionLabel(value: string): string {
  return (
    REPORT_RETENTION_REVIEW_DECISION_LABELS[
      value as keyof typeof REPORT_RETENTION_REVIEW_DECISION_LABELS
    ] ?? value
  )
}

// "deleted" ist fachlich kein sinnvolles Ergebnis der Datenschutzprüfung
// (dokumentiert nur einen bereits erfolgten Soft-Delete, loescht/anonymisiert
// selbst nichts) und wird deshalb nicht mehr zur Auswahl angeboten. Der Wert
// bleibt in REPORT_RETENTION_REVIEW_DECISION_VALUES/-LABELS bestehen, damit
// historische Prüfeinträge (siehe decisionLabel oben) weiterhin korrekt
// angezeigt werden.
export const SELECTABLE_RETENTION_REVIEW_DECISION_VALUES =
  REPORT_RETENTION_REVIEW_DECISION_VALUES.filter((value) => value !== "deleted")

// Neutraler Ausgangszustand des Entscheidungsfelds — bewusst KEIN Wert aus
// REPORT_RETENTION_REVIEW_DECISION_VALUES und damit vom bestehenden
// Zod-Enum in logRetentionReviewSchema ohnehin nie akzeptiert (kein
// zusaetzlicher Validierungscode noetig). Dient nur der Anzeige, bis der
// Nutzer bewusst eine echte Entscheidung waehlt.
export const NEUTRAL_DECISION_VALUE = ""

// Baut den Bestaetigungstext fuer den vollstaendigen Personenbezugs-Check.
// Strukturierte Melderdaten sind zu diesem Zeitpunkt bereits ueber Schritt 1
// entfernt — der Text bezieht sich deshalb bewusst nur auf die verbleibenden
// Inhalte der Meldung.
//
// Der Text ist absichtlich unabhaengig davon, ob die Meldung tatsaechlich
// Notizen oder Anhaenge hat: Bestaetigt wird, dass ALLE verbleibenden Inhalte
// geprueft wurden. Frueher nahm die Funktion dafuer zwei Flags entgegen und
// verwendete sie nicht — sie sind samt ihrer Zulieferkette entfallen.
export function buildAnonymizationChecklistLabel(): string {
  return "Die verbleibenden Inhalte der Meldung, insbesondere Freitexte, Notizen und Anhänge, wurden auf Personenbezug geprüft. Es sind keine personenbezogenen Daten mehr erkennbar."
}

export function RetentionReviewSection({
  reportId,
  canEdit,
  status,
  statusLabel,
  dueAtLabel,
  history,
  minPostponedUntil,
}: Props) {
  const [state, formAction, isPending] = useActionState(
    logRetentionReview,
    initialState
  )
  const [decision, setDecision] = useState(NEUTRAL_DECISION_VALUE)
  const [confirmNoPersonalData, setConfirmNoPersonalData] = useState(false)
  const decisionSelectRef = useRef<HTMLSelectElement>(null)
  const confirmCheckboxRef = useRef<HTMLInputElement>(null)
  // React setzt das <select> nach JEDER Aktionsausführung (Erfolg oder
  // Fehler — logRetentionReview wirft nie, sondern liefert bei einem
  // Validierungsfehler nur success:false zurueck, weshalb React aus seiner
  // Sicht in beiden Faellen "erfolgreich abgeschlossen" sieht und den nativen
  // Formular-Reset ausloest) auf die erste Option zurueck. Bei <select> ist
  // diese Reset-Semantik an das "selected"-Attribut gebunden, das React fuer
  // kontrollierte Selects nie setzt — deshalb hilft auch ein Remount des
  // Elements nicht: der native Reset trifft jeden neuen Knoten erneut.
  //
  // Damit eine erneute Abgabe (z. B. nach einem Validierungsfehler, ohne die
  // Auswahl zu wiederholen) nicht lautlos die falsche Entscheidung sendet,
  // werden "decision"/"confirmNoPersonalData" beim Absenden explizit aus dem
  // React-State in verdeckte Felder uebertragen (syncHiddenFields) — das
  // sichert die tatsaechlich gesendeten Daten ab, unabhaengig vom
  // Anzeigezustand des Selects.
  //
  // Fuer die ANZEIGE nach der Aktion gilt getrennt:
  // - Bei ERFOLG wird der lokale Auswahl-State bewusst auf den
  //   Ausgangszustand zurueckgesetzt (damit z. B. "Zurückstellen bis" nach
  //   dem Speichern nicht widerspruechlich zur (bereits zurueckgesetzten)
  //   Sichtbar-Auswahl bleibt).
  // - Bei einem FEHLER bleibt der React-State ("decision" etc.) unveraendert
  //   stehen (die echte Auswahl bleibt fachlich erhalten). Das native Reset
  //   veraendert aber trotzdem den DOM-Wert des <select> — deshalb wird der
  //   DOM-Wert nach jeder Aktion (Erfolg wie Fehler) per Effekt explizit auf
  //   den aktuellen "decision"-State zurueckgesetzt (imperativ, weil React
  //   bei unveraendertem State-Wert die DOM-Neuschreibung sonst überspringt
  //   — Bail-out der Diffing-Optimierung).
  const [prevState, setPrevState] = useState(state)
  if (state !== prevState) {
    setPrevState(state)
    if (state.success) {
      setDecision(NEUTRAL_DECISION_VALUE)
      setConfirmNoPersonalData(false)
    }
  }

  // Dasselbe gilt fuer die Bestaetigungs-Checkbox: Der native Reset nimmt den
  // Haken weg, waehrend "confirmNoPersonalData" im State gesetzt bleibt (und
  // ueber syncHiddenFields auch so gesendet wuerde). Nach einem
  // Validierungsfehler sah die Pruefung sonst unbestaetigt aus, obwohl sie es
  // nicht war.
  useEffect(() => {
    if (decisionSelectRef.current) {
      decisionSelectRef.current.value = decision
    }
    if (confirmCheckboxRef.current) {
      confirmCheckboxRef.current.checked = confirmNoPersonalData
    }
  }, [state, decision, confirmNoPersonalData])

  const syncHiddenFields = (form: HTMLFormElement) => {
    const decisionInput = form.elements.namedItem("decision") as HTMLInputElement
    const confirmInput = form.elements.namedItem(
      "confirmNoPersonalData"
    ) as HTMLInputElement
    decisionInput.value = decision
    confirmInput.value = confirmNoPersonalData ? "1" : ""
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">2. Datenschutzprüfung abschließen</CardTitle>
        <CardDescription>
          Prüfen Sie anschließend die gesamte Meldung auf weitere
          personenbezogene Daten, insbesondere Freitexte, Notizen und
          Anhänge, und dokumentieren Sie das Ergebnis. Fachliche
          Sicherheitsinformationen sollen erhalten bleiben.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-xs text-muted-foreground">
          Wenn keine Melderdaten vorhanden sind, können Sie direkt mit Schritt
          2 beginnen.
        </p>

        <dl className="grid gap-3 text-sm sm:grid-cols-2">
          <div>
            <dt className="mb-1 text-xs text-muted-foreground">Status</dt>
            <dd className={`font-semibold ${STATUS_CLASSNAMES[status]}`}>
              {statusLabel}
            </dd>
          </div>
          <div>
            <dt className="mb-1 text-xs text-muted-foreground">
              Fälligkeitsdatum
            </dt>
            <dd className="font-medium">{dueAtLabel ?? "—"}</dd>
          </div>
        </dl>

        {canEdit ? (
          <form
            action={formAction}
            onSubmit={(e) => syncHiddenFields(e.currentTarget)}
            className="space-y-3 rounded-md border bg-muted/40 p-4"
          >
            <input type="hidden" name="reportId" value={reportId} />
            <input type="hidden" name="decision" defaultValue={NEUTRAL_DECISION_VALUE} />
            <input type="hidden" name="confirmNoPersonalData" defaultValue="" />

            <div className="space-y-1.5">
              <label htmlFor="rr-decision" className="text-sm font-medium">
                Entscheidung
              </label>
              <select
                ref={decisionSelectRef}
                id="rr-decision"
                value={decision}
                onChange={(e) => setDecision(e.target.value)}
                required
                className="h-9 w-full rounded-md border bg-white px-3 text-sm"
              >
                {/* Bewusst NICHT disabled: Browser waehlen bei einem
                    Formular-Reset (auch nach erfolgreichem Speichern) immer
                    die erste NICHT-disabled Option, wenn keine Option das
                    "selected"-Attribut traegt. Mit "disabled" wuerde der
                    native Reset also faelschlich auf die naechste Option
                    ("Keine personenbezogenen Daten vorhanden") statt auf
                    diesen neutralen Platzhalter zurueckspringen. */}
                <option value={NEUTRAL_DECISION_VALUE}>
                  Bitte Entscheidung auswählen …
                </option>
                {SELECTABLE_RETENTION_REVIEW_DECISION_VALUES.map((value) => (
                  <option key={value} value={value}>
                    {REPORT_RETENTION_REVIEW_DECISION_LABELS[value]}
                  </option>
                ))}
              </select>
              {decision === "anonymized" ? (
                <p className="text-xs text-muted-foreground">
                  &bdquo;Vollständig anonymisiert&ldquo; setzt voraus, dass die
                  Melderdaten bereits über die Funktion &bdquo;Personenbezogene
                  Melderdaten entfernen&ldquo; entfernt wurden. Diese Aktion
                  protokolliert nur die Entscheidung, sie führt keine
                  Anonymisierung selbst aus.
                </p>
              ) : null}
            </div>

            {decision === "anonymized" ? (
              <div className="space-y-2 rounded-md border border-amber-200 bg-amber-50 p-3 dark:border-amber-800 dark:bg-amber-950/30">
                <label className="flex items-start gap-2 text-sm">
                  <input
                    ref={confirmCheckboxRef}
                    type="checkbox"
                    checked={confirmNoPersonalData}
                    onChange={(e) => setConfirmNoPersonalData(e.target.checked)}
                    className="mt-0.5"
                  />
                  <span>{buildAnonymizationChecklistLabel()}</span>
                </label>
              </div>
            ) : null}

            {decision === "postponed" ? (
              <div className="space-y-1.5">
                <label htmlFor="rr-postponedUntil" className="text-sm font-medium">
                  Zurückstellen bis
                </label>
                <input
                  id="rr-postponedUntil"
                  name="postponedUntil"
                  type="date"
                  min={minPostponedUntil}
                  className="h-9 rounded-md border bg-white px-3 text-sm"
                />
              </div>
            ) : null}

            <div className="space-y-1.5">
              <label htmlFor="rr-reason" className="text-sm font-medium">
                {decision === "anonymized" && confirmNoPersonalData
                  ? "Prüfvermerk (verpflichtend bei vollständiger Bestätigung)"
                  : "Prüfvermerk (optional)"}
              </label>
              <p className="text-xs text-muted-foreground">
                Ergebnis der Prüfung bzw. Begründung der Entscheidung.
              </p>
              <textarea
                id="rr-reason"
                name="reason"
                rows={2}
                maxLength={500}
                required={decision === "anonymized" && confirmNoPersonalData}
                placeholder="Keine personenbezogenen Daten eintragen"
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
              />
            </div>

            <div className="flex items-center gap-3">
              <Button type="submit" variant="outline" size="sm" disabled={isPending}>
                {isPending ? "Speichert…" : "Entscheidung dokumentieren"}
              </Button>
              {state.message ? (
                <p
                  className={`text-sm ${state.success ? "text-emerald-600" : "text-destructive"}`}
                >
                  {state.message}
                </p>
              ) : null}
            </div>
          </form>
        ) : null}

        <div className="space-y-2">
          <p className="text-sm font-medium text-foreground">Prüfhistorie</p>
          {history.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              Noch keine Prüfentscheidung dokumentiert.
            </p>
          ) : (
            <ul className="space-y-2">
              {history.map((entry) => (
                <li
                  key={entry.id}
                  className="rounded-md border bg-muted/40 px-3 py-2 text-sm"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-medium">{decisionLabel(entry.decision)}</span>
                    <span className="text-xs text-muted-foreground">
                      {entry.createdAt} · {entry.reviewerName}
                    </span>
                  </div>
                  {entry.postponedUntil ? (
                    <p className="mt-1 text-xs text-muted-foreground">
                      Zurückgestellt bis {entry.postponedUntil}
                    </p>
                  ) : null}
                  {entry.reason ? (
                    <p className="mt-1 text-muted-foreground">{entry.reason}</p>
                  ) : null}
                </li>
              ))}
            </ul>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
