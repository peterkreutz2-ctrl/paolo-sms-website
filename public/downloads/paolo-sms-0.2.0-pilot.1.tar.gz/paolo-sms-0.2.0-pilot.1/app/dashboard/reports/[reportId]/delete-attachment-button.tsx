"use client"

import { useActionState } from "react"

import {
  deleteAttachment,
  type DeleteAttachmentState,
} from "@/lib/actions/attachments"

import { Button } from "@/components/ui/button"

const CONFIRM_MESSAGE =
  "Diesen Anhang endgültig löschen? Diese Aktion kann nicht rückgängig gemacht werden."

const initialState: DeleteAttachmentState = {
  success: false,
  message: "",
}

type Props = {
  reportId: string
  attachmentId: string
}

export function DeleteAttachmentButton({ reportId, attachmentId }: Props) {
  const [state, formAction, isPending] = useActionState(
    deleteAttachment,
    initialState
  )

  return (
    <form
      action={formAction}
      className="flex flex-col items-start gap-2"
      onSubmit={(e) => {
        if (!window.confirm(CONFIRM_MESSAGE)) {
          e.preventDefault()
        }
      }}
    >
      <input type="hidden" name="reportId" value={reportId} />
      <input type="hidden" name="attachmentId" value={attachmentId} />
      <Button
        type="submit"
        variant="outline"
        size="sm"
        disabled={isPending}
        className="border-destructive/50 text-destructive hover:bg-destructive/10"
      >
        {isPending ? "Wird gelöscht…" : "Anhang endgültig löschen"}
      </Button>
      {state.message ? (
        <p
          className={`text-sm ${
            state.success ? "text-emerald-600" : "text-destructive"
          }`}
        >
          {state.message}
        </p>
      ) : null}
    </form>
  )
}
