import { appAuth } from "@/lib/auth"
import Link from "next/link"
import { notFound, redirect } from "next/navigation"
import { and, desc, eq, isNotNull, isNull, lt, notInArray, sql } from "drizzle-orm"

import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { db } from "@/lib/db"
import { measures, reports } from "@/lib/db/schema"
import {
  MEASURE_STATUS_LABELS,
  MEASURE_STATUS_VALUES,
  type MeasureStatus,
} from "@/lib/constants/measure-workflow"

import { Badge } from "@/components/ui/badge"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { PageHeader } from "@/components/ui/page-header"
import { hasMeasureReadRole } from "@/lib/constants/roles"

const MEASURE_DONE: MeasureStatus[] = ["completed", "discarded"]

const VALID_FILTERS = [
  "open",
  "overdue",
  "in_progress",
  "completed",
  "discarded",
] as const
type FilterValue = (typeof VALID_FILTERS)[number]

const FILTER_LABELS: Record<FilterValue, string> = {
  open: "Offen",
  overdue: "Überfällig",
  in_progress: "In Bearbeitung",
  completed: "Erledigt",
  discarded: "Verworfen",
}

function startOfUtcToday(): Date {
  const now = new Date()
  return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()))
}

const dueDateFormatter = new Intl.DateTimeFormat("de-DE", {
  timeZone: "UTC",
  dateStyle: "medium",
})

const createdAtFormatter = new Intl.DateTimeFormat("de-DE", {
  dateStyle: "short",
})

function statusLabel(value: string): string {
  return MEASURE_STATUS_VALUES.includes(value as MeasureStatus)
    ? MEASURE_STATUS_LABELS[value as MeasureStatus]
    : value
}

type Props = {
  searchParams: Promise<{ filter?: string }>
}

export default async function MeasuresPage({ searchParams }: Props) {
  const { userId } = await appAuth()
  if (!userId) redirect("/sign-in")

  const roleKeys = await getCurrentUserRoles()
  if (!hasMeasureReadRole(roleKeys)) notFound()

  const { filter } = await searchParams
  const activeFilter = VALID_FILTERS.includes(filter as FilterValue)
    ? (filter as FilterValue)
    : undefined

  const startTodayUtc = startOfUtcToday()

  const filterCondition = (() => {
    if (!activeFilter) return undefined
    if (activeFilter === "overdue") {
      return and(
        isNotNull(measures.dueDate),
        lt(measures.dueDate, startTodayUtc),
        notInArray(measures.status, MEASURE_DONE)
      )
    }
    return eq(measures.status, activeFilter)
  })()

  const rows = await db
    .select({
      id: measures.id,
      title: measures.title,
      status: measures.status,
      assignedToText: measures.assignedToText,
      dueDate: measures.dueDate,
      createdAt: measures.createdAt,
      reportId: measures.reportId,
      reportTitle: reports.shortDescription,
    })
    .from(measures)
    .innerJoin(reports, eq(measures.reportId, reports.id))
    .where(and(isNull(reports.deletedAt), filterCondition))
    .orderBy(sql`${measures.dueDate} ASC NULLS LAST`, desc(measures.createdAt))

  return (
    <main className="mx-auto max-w-5xl space-y-6 px-4 py-8 sm:px-8 sm:py-10">
      <PageHeader
        title="Maßnahmen"
        subtitle="Organisationsweite Übersicht aller Maßnahmen."
      />

      <div className="rounded-md bg-muted/40 px-4 py-3 text-sm text-muted-foreground">
        <p>Fälligkeiten prüfen und überfällige Maßnahmen prioritär bearbeiten. Maßnahmenstatus aktuell halten, damit der Überblick im Dashboard korrekt bleibt. Maßnahmen werden über die jeweilige Meldungs-Detailseite angelegt.</p>
      </div>

      <nav className="flex flex-wrap gap-2" aria-label="Maßnahmen filtern">
        <Link
          href="/dashboard/measures"
          className={`rounded-md border px-3 py-1.5 text-sm transition-colors ${
            !activeFilter
              ? "border-foreground bg-foreground text-background"
              : "border-border hover:bg-muted"
          }`}
        >
          Alle
        </Link>
        {VALID_FILTERS.map((f) => (
          <Link
            key={f}
            href={`/dashboard/measures?filter=${f}`}
            className={`rounded-md border px-3 py-1.5 text-sm transition-colors ${
              activeFilter === f
                ? "border-foreground bg-foreground text-background"
                : "border-border hover:bg-muted"
            }`}
          >
            {FILTER_LABELS[f]}
          </Link>
        ))}
      </nav>

      <Card className="bg-muted/40">
        <CardHeader>
          <CardTitle>
            {activeFilter ? FILTER_LABELS[activeFilter] : "Alle Maßnahmen"}
          </CardTitle>
          <CardDescription>
            {rows.length} Maßnahme{rows.length !== 1 ? "n" : ""}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {rows.length === 0 ? (
            <p className="rounded-lg border border-dashed px-4 py-6 text-center text-sm text-muted-foreground">
              Keine Maßnahmen gefunden.
            </p>
          ) : (
            <ul className="divide-y rounded-lg border">
              {rows.map((row) => {
                const isOverdue =
                  row.dueDate !== null &&
                  !MEASURE_DONE.includes(row.status as MeasureStatus) &&
                  row.dueDate < startTodayUtc

                return (
                  <li key={row.id}>
                    <Link
                      href={`/dashboard/reports/${row.reportId}`}
                      className="flex flex-col gap-1 px-4 py-3 transition-colors hover:bg-muted/50 sm:flex-row sm:items-center sm:justify-between"
                    >
                      <div className="min-w-0">
                        <p className="font-medium text-blue-800">{row.title}</p>
                        <p className="truncate text-sm text-muted-foreground">
                          Meldung: {row.reportTitle}
                        </p>
                        {row.assignedToText ? (
                          <p className="truncate text-sm text-muted-foreground">
                            Verantwortlich: {row.assignedToText}
                          </p>
                        ) : null}
                      </div>
                      <span className="flex flex-shrink-0 flex-wrap items-center gap-x-3 gap-y-1 text-sm sm:justify-end">
                        <Badge variant="secondary" className="font-normal">
                          {statusLabel(row.status)}
                        </Badge>
                        <span
                          className={
                            isOverdue
                              ? "text-amber-600 dark:text-amber-400"
                              : "text-muted-foreground"
                          }
                        >
                          {row.dueDate
                            ? `Fällig: ${dueDateFormatter.format(row.dueDate)}`
                            : "Kein Fälligkeitsdatum"}
                        </span>
                        <span className="text-muted-foreground">
                          {createdAtFormatter.format(row.createdAt)}
                        </span>
                      </span>
                    </Link>
                  </li>
                )
              })}
            </ul>
          )}
        </CardContent>
      </Card>
    </main>
  )
}
