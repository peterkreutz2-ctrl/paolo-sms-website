import { appAuth } from "@/lib/auth"
import Link from "next/link"
import { notFound, redirect } from "next/navigation"

import { and, count, desc, eq, isNotNull, isNull, lt, notInArray, sql } from "drizzle-orm"

import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { hasReportReadRole, hasSafetyEditRole } from "@/lib/constants/roles"
import { db } from "@/lib/db"
import { measures, organizations, reports, safetyMeetings } from "@/lib/db/schema"
import { getDueReportIds } from "@/lib/queries/report-retention"
import {
  MEASURE_STATUS_LABELS,
  MEASURE_STATUS_VALUES,
  type MeasureStatus,
} from "@/lib/constants/measure-workflow"
import {
  CLOSED_OR_HIDDEN_STATUSES,
  REPORT_PRIORITY_LABELS,
  REPORT_PRIORITY_VALUES,
  REPORT_STATUS_LABELS,
  REPORT_STATUS_VALUES,
  type ReportPriority,
  type ReportStatus,
} from "@/lib/constants/report-workflow"

import { Badge } from "@/components/ui/badge"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { PageHeader } from "@/components/ui/page-header"

import { SafetyMeetingForm } from "./_components/safety-meeting-form"

const dateFormatter = new Intl.DateTimeFormat("de-DE", {
  dateStyle: "short",
  timeStyle: "short",
})

const measureDueFormatter = new Intl.DateTimeFormat("de-DE", {
  timeZone: "UTC",
  dateStyle: "medium",
})

const MEASURE_DONE: MeasureStatus[] = ["completed", "discarded"]

function startOfUtcToday(): Date {
  const now = new Date()
  return new Date(
    Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate())
  )
}

function measureStatusLabel(value: string): string {
  return MEASURE_STATUS_VALUES.includes(value as MeasureStatus)
    ? MEASURE_STATUS_LABELS[value as MeasureStatus]
    : value
}

function statusLabel(value: string): string {
  return REPORT_STATUS_VALUES.includes(value as ReportStatus)
    ? REPORT_STATUS_LABELS[value as ReportStatus]
    : value
}

function priorityLabel(value: string): string {
  return REPORT_PRIORITY_VALUES.includes(value as ReportPriority)
    ? REPORT_PRIORITY_LABELS[value as ReportPriority]
    : value
}

function addMonths(dateStr: string, months: number): string {
  const [year, month, day] = dateStr.split("-").map(Number)
  const d = new Date(Date.UTC(year, month - 1 + months, day))
  return d.toISOString().slice(0, 10)
}

function addDaysToYMD(dateStr: string, days: number): string {
  const [year, month, day] = dateStr.split("-").map(Number)
  const d = new Date(Date.UTC(year, month - 1, day + days))
  return d.toISOString().slice(0, 10)
}

function dateToYMD(d: Date): string {
  return d.toISOString().slice(0, 10)
}

function parseYMD(dateStr: string): Date {
  const [year, month, day] = dateStr.split("-").map(Number)
  return new Date(Date.UTC(year, month - 1, day))
}

export default async function DashboardPage() {
  const { userId } = await appAuth()

  if (!userId) {
    redirect("/sign-in")
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasReportReadRole(roleKeys)) {
    notFound()
  }

  const startTodayUtc = startOfUtcToday()

  const [
    [newCountRow],
    [inReviewCountRow],
    [criticalOpenCountRow],
    [openTotalRow],
    [openMeasuresCountRow],
    [overdueMeasuresCountRow],
    latestReports,
    openMeasuresPreview,
  ] = await Promise.all([
    db
      .select({ n: count() })
      .from(reports)
      .where(and(isNull(reports.deletedAt), eq(reports.status, "new"))),
    db
      .select({ n: count() })
      .from(reports)
      .where(and(isNull(reports.deletedAt), eq(reports.status, "in_review"))),
    db
      .select({ n: count() })
      .from(reports)
      .where(
        and(
          isNull(reports.deletedAt),
          eq(reports.priority, "critical"),
          notInArray(reports.status, [...CLOSED_OR_HIDDEN_STATUSES])
        )
      ),
    db
      .select({ n: count() })
      .from(reports)
      .where(
        and(
          isNull(reports.deletedAt),
          notInArray(reports.status, [...CLOSED_OR_HIDDEN_STATUSES])
        )
      ),
    db
      .select({ n: count() })
      .from(measures)
      .innerJoin(reports, eq(measures.reportId, reports.id))
      .where(
        and(eq(measures.status, "open"), isNull(reports.deletedAt))
      ),
    db
      .select({ n: count() })
      .from(measures)
      .innerJoin(reports, eq(measures.reportId, reports.id))
      .where(
        and(
          isNull(reports.deletedAt),
          isNotNull(measures.dueDate),
          lt(measures.dueDate, startTodayUtc),
          notInArray(measures.status, MEASURE_DONE)
        )
      ),
    db
      .select({
        id: reports.id,
        shortDescription: reports.shortDescription,
        status: reports.status,
        priority: reports.priority,
        createdAt: reports.createdAt,
      })
      .from(reports)
      .where(isNull(reports.deletedAt))
      .orderBy(desc(reports.createdAt))
      .limit(8),
    db
      .select({
        id: measures.id,
        title: measures.title,
        status: measures.status,
        dueDate: measures.dueDate,
        reportId: measures.reportId,
        reportTitle: reports.shortDescription,
      })
      .from(measures)
      .innerJoin(reports, eq(measures.reportId, reports.id))
      .where(
        and(notInArray(measures.status, MEASURE_DONE), isNull(reports.deletedAt))
      )
      .orderBy(
        sql`${measures.dueDate} ASC NULLS LAST`,
        desc(measures.createdAt)
      )
      .limit(10),
  ])

  const canEditSafety = hasSafetyEditRole(roleKeys)

  let safetyInfo: {
    intervalMonths: number
    lastMeetingDate: string | null
    nextDue: string
    status: "overdue" | "soon" | "current"
  } | null = null

  let retentionReviewInfo: {
    intervalMonths: number | null
    dueCount: number
  } | null = null

  if (canEditSafety) {
    const [organization] = await db
      .select({
        id: organizations.id,
        createdAt: organizations.createdAt,
        safetyMeetingIntervalMonths: organizations.safetyMeetingIntervalMonths,
        reportRetentionReviewIntervalMonths:
          organizations.reportRetentionReviewIntervalMonths,
      })
      .from(organizations)
      .limit(1)

    if (organization) {
      const dueReportIds = organization.reportRetentionReviewIntervalMonths
        ? await getDueReportIds(
            organization.id,
            organization.reportRetentionReviewIntervalMonths
          )
        : []
      retentionReviewInfo = {
        intervalMonths: organization.reportRetentionReviewIntervalMonths,
        dueCount: dueReportIds.length,
      }

      const [lastMeeting] = await db
        .select({ meetingDate: safetyMeetings.meetingDate })
        .from(safetyMeetings)
        .where(eq(safetyMeetings.organizationId, organization.id))
        .orderBy(desc(safetyMeetings.meetingDate))
        .limit(1)

      const baseDate = lastMeeting
        ? lastMeeting.meetingDate
        : dateToYMD(organization.createdAt)
      const nextDue = addMonths(baseDate, organization.safetyMeetingIntervalMonths)
      const todayStr = new Date().toISOString().slice(0, 10)
      const soonThreshold = addDaysToYMD(nextDue, -30)

      let status: "overdue" | "soon" | "current"
      if (todayStr > nextDue) {
        status = "overdue"
      } else if (todayStr >= soonThreshold) {
        status = "soon"
      } else {
        status = "current"
      }

      safetyInfo = {
        intervalMonths: organization.safetyMeetingIntervalMonths,
        lastMeetingDate: lastMeeting?.meetingDate ?? null,
        nextDue,
        status,
      }
    }
  }

  const kpis = [
    {
      title: "Neue Meldungen",
      value: newCountRow?.n ?? 0,
      description: `Status: ${REPORT_STATUS_LABELS.new}`,
      href: "/dashboard/reports?status=new",
      warning: false,
    },
    {
      title: REPORT_STATUS_LABELS.in_review,
      value: inReviewCountRow?.n ?? 0,
      description: `Status: ${REPORT_STATUS_LABELS.in_review}`,
      href: "/dashboard/reports?status=in_review",
      warning: false,
    },
    {
      title: "Kritisch (offen)",
      value: criticalOpenCountRow?.n ?? 0,
      description: `Priorität ${REPORT_PRIORITY_LABELS.critical}, offen`,
      href: "/dashboard/reports?priority=critical",
      warning: true,
    },
    {
      title: "Offen gesamt",
      value: openTotalRow?.n ?? 0,
      description: `Ohne ${REPORT_STATUS_LABELS.closed} / ${REPORT_STATUS_LABELS.hidden}`,
      href: "/dashboard/reports?status=open_all",
      warning: false,
    },
  ]

  return (
    <main className="mx-auto max-w-5xl space-y-10 px-4 py-8 sm:px-8 sm:py-10">
      <PageHeader
        title="Sicherheits-Dashboard"
        subtitle="Aktueller Stand der Meldungen, offene Maßnahmen und Handlungsbedarf im Überblick."
      />

      <div className="rounded-md bg-muted/40 px-4 py-3 text-sm text-muted-foreground">
        {canEditSafety ? (
          <p>Als Safety Manager oder Administrator sichten Sie hier eingehende Meldungen, verwalten Maßnahmen und dokumentieren Sicherheitsbesprechungen. Alle Änderungen werden im Audit-Log festgehalten.</p>
        ) : (
          <p>Sie können Meldungen und Maßnahmen einsehen sowie Anhänge zu Meldungen hochladen. Die Bearbeitung von Status und Priorität ist Aufgabe des Safety Managers.</p>
        )}
      </div>

      {canEditSafety && safetyInfo && (
        <section aria-label="Sicherheitsbesprechung">
          {/* Bei "Aktuell" eine Zeile mit Aufklapper, sonst wie bisher offen.
              Der Block stand vorher in elf von zwoelf Monaten unveraendert
              prominent ueber den Kennzahlen, obwohl nichts zu tun war. Der
              Status wird ohnehin schon berechnet — nur die Darstellung war
              zustandsblind.

              Bewusst als natives <details>: kein Client-Bundle, und der Inhalt
              bleibt im Markup, also auch fuer Suche und Screenreader
              erreichbar. Bei "Bald faellig" und "Ueberfaellig" ist es
              standardmaessig offen. */}
          <details
            open={safetyInfo.status !== "current"}
            className="group rounded-lg border bg-muted/40"
          >
            <summary className="flex cursor-pointer list-none flex-wrap items-center gap-x-3 gap-y-1 rounded-lg px-4 py-3 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring [&::-webkit-details-marker]:hidden">
              <span className="font-semibold uppercase tracking-wide text-muted-foreground">
                Sicherheitsbesprechung
              </span>
              <span className="text-muted-foreground">
                Nächste fällig am{" "}
                {measureDueFormatter.format(parseYMD(safetyInfo.nextDue))}
              </span>
              <span
                className={
                  safetyInfo.status === "overdue"
                    ? "font-semibold text-red-600 dark:text-red-400"
                    : safetyInfo.status === "soon"
                    ? "font-semibold text-amber-600 dark:text-amber-400"
                    : "font-semibold text-emerald-600 dark:text-emerald-400"
                }
              >
                {safetyInfo.status === "overdue"
                  ? "Überfällig"
                  : safetyInfo.status === "soon"
                  ? "Bald fällig"
                  : "Aktuell"}
              </span>
              {/* Gleicher Zustandswechsel wie bei den Dokumentkategorien auf
                  /dashboard/documents: die Beschriftung benennt die naechste
                  Aktion, das Chevron zeigt die Richtung. Vorher stand hier nur
                  „Eintragen", das im offenen Zustand verschwand — der
                  Zusammenklapper war damit weder benannt noch wieder
                  auffindbar. Der native Marker weicht dem Chevron, damit nicht
                  zwei Indikatoren dasselbe sagen. */}
              <span className="ml-auto flex shrink-0 items-center gap-1.5 text-sm text-muted-foreground">
                <span className="group-open:hidden">Aufklappen</span>
                <span className="hidden group-open:inline">Zuklappen</span>
                <svg
                  aria-hidden="true"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-4 w-4 transition-transform group-open:rotate-180"
                >
                  <path d="m6 9 6 6 6-6" />
                </svg>
              </span>
            </summary>

            <div className="space-y-4 border-t px-4 pb-4 pt-4">
              <dl className="grid gap-3 text-sm sm:grid-cols-3">
                <div>
                  <dt className="mb-1 text-xs text-muted-foreground">Letzte Besprechung</dt>
                  <dd className="font-medium">
                    {safetyInfo.lastMeetingDate
                      ? measureDueFormatter.format(parseYMD(safetyInfo.lastMeetingDate))
                      : "Noch keine"}
                  </dd>
                </div>
                <div>
                  <dt className="mb-1 text-xs text-muted-foreground">Nächste fällig</dt>
                  <dd className="font-medium">
                    {measureDueFormatter.format(parseYMD(safetyInfo.nextDue))}
                  </dd>
                </div>
                <div>
                  <dt className="mb-1 text-xs text-muted-foreground">Turnus</dt>
                  <dd className="font-medium">
                    {safetyInfo.intervalMonths} Monate
                  </dd>
                </div>
              </dl>
              <SafetyMeetingForm />
            </div>
          </details>
        </section>
      )}

      <section aria-label="Kennzahlen Meldungen">
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
          Meldungen
        </h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {kpis.map((kpi) => {
            const card = (
              <Card
                size="sm"
                className={`bg-muted/40${kpi.href ? " transition-opacity hover:opacity-80" : ""}`}
              >
                <CardHeader className="pb-0">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    {kpi.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-2">
                  <p className={`text-3xl font-semibold tabular-nums ${kpi.warning && kpi.value > 0 ? "text-orange-500 dark:text-orange-400" : "text-blue-900"}`}>
                    {kpi.value}
                  </p>
                  <CardDescription className="mt-1 text-xs">
                    {kpi.description}
                  </CardDescription>
                </CardContent>
              </Card>
            )
            if (kpi.href) {
              return (
                <Link
                  key={kpi.title}
                  href={kpi.href}
                  className="block rounded-xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                >
                  {card}
                </Link>
              )
            }
            return <div key={kpi.title}>{card}</div>
          })}
        </div>
      </section>

      <section aria-label="Kennzahlen Maßnahmen">
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
          Maßnahmen
        </h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <Link
            href="/dashboard/measures?filter=open"
            className="block rounded-xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
          >
            <Card size="sm" className="bg-muted/40 transition-opacity hover:opacity-80">
              <CardHeader className="pb-0">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Offene Maßnahmen
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-2">
                <p className="text-3xl font-semibold tabular-nums text-blue-900">
                  {openMeasuresCountRow?.n ?? 0}
                </p>
                <CardDescription className="mt-1 text-xs">
                  Status: {MEASURE_STATUS_LABELS.open}
                </CardDescription>
              </CardContent>
            </Card>
          </Link>
          <Link
            href="/dashboard/measures?filter=overdue"
            className="block rounded-xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
          >
            <Card
              size="sm"
              className={`bg-muted/40 transition-opacity hover:opacity-80 ${
                (overdueMeasuresCountRow?.n ?? 0) > 0
                  ? "border-amber-300 dark:border-amber-700"
                  : ""
              }`}
            >
              <CardHeader className="pb-0">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Überfällige Maßnahmen
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-2">
                <p
                  className={`text-3xl font-semibold tabular-nums ${
                    (overdueMeasuresCountRow?.n ?? 0) > 0
                      ? "text-amber-600 dark:text-amber-400"
                      : "text-blue-900"
                  }`}
                >
                  {overdueMeasuresCountRow?.n ?? 0}
                </p>
                <CardDescription className="mt-1 text-xs">
                  Fällig vor heute, nicht {MEASURE_STATUS_LABELS.completed} /{" "}
                  {MEASURE_STATUS_LABELS.discarded}
                </CardDescription>
              </CardContent>
            </Card>
          </Link>
        </div>
      </section>

      <section aria-label="Neueste Meldungen">
        <Card className="bg-muted/40">
          <CardHeader>
            <CardTitle>Neueste Meldungen</CardTitle>
            <CardDescription>
              Die zuletzt eingegangenen Meldungen, sortiert nach Eingang.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {latestReports.length === 0 ? (
              <p className="rounded-lg border border-dashed px-4 py-6 text-center text-sm text-muted-foreground">
                Noch keine Meldungen eingegangen. Der Link zur öffentlichen
                Meldeseite ist im Menü oben.
              </p>
            ) : (
              <ul className="divide-y rounded-lg border">
                {latestReports.map((report) => (
                  <li key={report.id}>
                    <Link
                      href={`/dashboard/reports/${report.id}`}
                      className="flex flex-col gap-1 px-4 py-3 transition-colors hover:bg-muted/50 sm:flex-row sm:items-center sm:justify-between"
                    >
                      <span className="font-medium text-blue-800">
                        {report.shortDescription}
                      </span>
                      <span className="flex flex-shrink-0 flex-wrap items-center gap-2">
                        <Badge variant="secondary" className="font-normal">
                          {statusLabel(report.status)}
                        </Badge>
                        <Badge variant="outline" className="font-normal">
                          {priorityLabel(report.priority)}
                        </Badge>
                        <time
                          dateTime={report.createdAt.toISOString()}
                          className="text-xs text-muted-foreground"
                        >
                          {dateFormatter.format(report.createdAt)}
                        </time>
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </section>

      <section aria-label="Offene Maßnahmen">
        <Card className="bg-muted/40">
          <CardHeader>
            <div className="flex items-start justify-between gap-4">
              <div>
                <CardTitle>Offene Maßnahmen</CardTitle>
                <CardDescription>
                  Noch zu erledigende Maßnahmen, sortiert nach Fälligkeit (ohne
                  erledigt / verworfen).
                </CardDescription>
              </div>
              <Link
                href="/dashboard/measures"
                className="shrink-0 text-sm text-blue-800 hover:text-blue-900 hover:underline underline-offset-4 focus-visible:rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                Alle anzeigen
              </Link>
            </div>
          </CardHeader>
          <CardContent>
            {openMeasuresPreview.length === 0 ? (
              <p className="rounded-lg border border-dashed px-4 py-6 text-center text-sm text-muted-foreground">
                Keine offenen Maßnahmen — alles erledigt oder noch keine
                angelegt.
              </p>
            ) : (
              <ul className="divide-y rounded-lg border">
                {openMeasuresPreview.map((row) => (
                  <li key={row.id}>
                    <Link
                      href={`/dashboard/reports/${row.reportId}`}
                      className="flex flex-col gap-1 px-4 py-3 transition-colors hover:bg-muted/50 sm:flex-row sm:items-center sm:justify-between"
                    >
                      <div className="min-w-0">
                        <p className="font-medium text-blue-800">{row.title}</p>
                        <p className="truncate text-sm text-muted-foreground">
                          Meldung: {row.reportTitle}
                        </p>
                      </div>
                      <span className="flex flex-shrink-0 flex-wrap items-center gap-x-3 gap-y-1 text-sm text-muted-foreground sm:justify-end">
                        <span>{measureStatusLabel(row.status)}</span>
                        <span aria-hidden="true">·</span>
                        <span>
                          {row.dueDate
                            ? `Fällig: ${measureDueFormatter.format(row.dueDate)}`
                            : "Kein Fälligkeitsdatum"}
                        </span>
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </section>

      {canEditSafety && retentionReviewInfo && (
        <section aria-label="Datenschutzprüfung" className="pt-2">
          {retentionReviewInfo.intervalMonths === null ? (
            <Link
              href="/dashboard/settings"
              className="text-xs text-muted-foreground hover:text-foreground hover:underline underline-offset-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            >
              Datenschutzprüfung (Prüfung personenbezogener Daten): Prüfturnus nicht konfiguriert
            </Link>
          ) : (
            <Link
              href="/dashboard/reports?retention=due"
              className="inline-flex items-center gap-2 rounded-md text-xs text-muted-foreground hover:text-foreground hover:underline underline-offset-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            >
              <span>Datenschutzprüfung (Prüfung personenbezogener Daten)</span>
              <Badge variant="outline" className="font-normal">
                {retentionReviewInfo.dueCount} fällig
              </Badge>
            </Link>
          )}
        </section>
      )}
    </main>
  )
}
