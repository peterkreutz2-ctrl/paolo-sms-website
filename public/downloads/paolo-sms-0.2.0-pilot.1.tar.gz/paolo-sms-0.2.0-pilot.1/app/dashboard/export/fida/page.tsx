import { appAuth } from "@/lib/auth"
import { notFound, redirect } from "next/navigation"

import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { hasSafetyEditRole } from "@/lib/constants/roles"

function defaultRange(): { from: string; to: string } {
  const to = new Date()
  to.setUTCDate(to.getUTCDate() + 1)
  const from = new Date(to)
  from.setUTCMonth(from.getUTCMonth() - 1)
  return {
    from: from.toISOString().slice(0, 10),
    to: to.toISOString().slice(0, 10),
  }
}

export default async function FidaExportPage() {
  const { userId } = await appAuth()
  if (!userId) redirect("/sign-in")

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) notFound()
  const range = defaultRange()

  return (
    <main className="mx-auto max-w-2xl space-y-8 p-8">
      <div>
        <h1 className="text-2xl font-semibold">FIDA-JSON-Export</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Aktive Meldungen anhand ihres Ereigniszeitpunkts exportieren; maßgeblich ist
          der Tag. Das Enddatum ist exklusiv; Meldungen ohne Ereigniszeitpunkt
          werden nicht berücksichtigt.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Zeitraum auswählen</CardTitle>
          <CardDescription>
            Der Zeitraum darf höchstens ein Jahr umfassen. Anhänge, Maßnahmen,
            Notizen und Melderdaten sind nicht Bestandteil des Exports.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form action="/api/export/fida" method="GET" className="space-y-5">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <label htmlFor="from" className="text-sm font-medium">
                  Von einschließlich
                </label>
                <Input id="from" name="from" type="date" defaultValue={range.from} required />
              </div>
              <div className="space-y-2">
                <label htmlFor="to" className="text-sm font-medium">
                  Bis ausschließlich
                </label>
                <Input id="to" name="to" type="date" defaultValue={range.to} required />
              </div>
            </div>
            <Button type="submit">FIDA-JSON herunterladen</Button>
          </form>
        </CardContent>
      </Card>
    </main>
  )
}
