"use client"

import { useActionState, useEffect, useRef, useState } from "react"
import { useRouter } from "next/navigation"

import {
  createSmsDocument,
  deleteSmsDocument,
  prefillMeetingMinutes,
  updateSmsDocument,
  type SmsDocumentActionState,
} from "@/lib/actions/sms-documents"
import { renderTemplate } from "@/lib/documents/template-tokens"
import { useRestoreAfterFormReset } from "@/lib/hooks/use-restore-after-form-reset"

import {
  SMS_DOCUMENT_CATEGORY_LABELS,
  SMS_DOCUMENT_MEETING_MINUTES_MEMBERS_HINT,
  SMS_DOCUMENT_PUBLIC_DOWNGRADE_HINT,
  SMS_DOCUMENT_VISIBILITY_HINTS,
  SMS_DOCUMENT_VISIBILITY_LABELS,
  SMS_DOCUMENT_VISIBILITY_VALUES,
  type SmsDocumentCategory,
  type SmsDocumentVisibility,
} from "@/lib/constants/sms-documents"
import { getTemplatesForCategory } from "@/lib/constants/sms-document-templates"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

const initialState: SmsDocumentActionState = { success: false, message: "" }

const labelClass = "text-sm font-medium text-foreground"
const fieldWrap = "space-y-1.5"

function Message({ state }: { state: SmsDocumentActionState }) {
  if (!state.message) return null
  return (
    <p
      className={`text-sm ${
        state.success ? "text-emerald-600" : "text-destructive"
      }`}
    >
      {state.message}
    </p>
  )
}

// Kategorie-Auswahl (bei nur einer erlaubten Kategorie als verstecktes Feld).
// Kontrolliert, damit das Formular die gewählte Kategorie kennt (für die
// kategoriegenaue Vorlagenauswahl). name="category" bleibt erhalten, sodass das
// FormData unverändert funktioniert.
function CategoryField({
  idPrefix,
  categories,
  value,
  onChange,
}: {
  idPrefix: string
  categories: readonly SmsDocumentCategory[]
  value: SmsDocumentCategory
  onChange: (value: SmsDocumentCategory) => void
}) {
  if (categories.length <= 1) {
    return <input type="hidden" name="category" value={value} />
  }
  return (
    <div className={fieldWrap}>
      <label htmlFor={`${idPrefix}-category`} className={labelClass}>
        Kategorie
      </label>
      <Select
        name="category"
        value={value}
        onValueChange={(v) => onChange(v as SmsDocumentCategory)}
      >
        <SelectTrigger id={`${idPrefix}-category`} className="w-full sm:w-80">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {categories.map((c) => (
            <SelectItem key={c} value={c}>
              {SMS_DOCUMENT_CATEGORY_LABELS[c]}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}

// Sichtbarkeit bewusst als natives <select> (kontrolliert): Der Wert landet
// dadurch zuverlässig im FormData — unabhängig vom Hidden-Input-/Hydration-
// Verhalten der Radix-Select-Komponente. Dreistufig: Vertraulich / Intern /
// Öffentlich. Der Wechsel auf „Öffentlich" wird über einen Bestätigungsdialog
// abgesichert; solange „Öffentlich" gewählt ist, erscheint ein Datenschutz-
// hinweis. Das Zurückziehen (public → staff/confidential) braucht keine
// Bestätigung.
//
// Der Dialog bestätigt ausdrücklich nur die AUSWAHL — gespeichert wird erst
// über „Speichern". Solange die Auswahl vom gespeicherten Serverwert abweicht,
// weist das Feld sie als ungespeichert aus und der Datenschutzhinweis steht im
// Futur; erst der gespeicherte Zustand rechtfertigt den Indikativ.
function VisibilityField({
  idPrefix,
  category,
  defaultValue,
  saving = false,
}: {
  idPrefix: string
  category: SmsDocumentCategory
  defaultValue: SmsDocumentVisibility
  saving?: boolean
}) {
  const [value, setValue] = useState<SmsDocumentVisibility>(defaultValue)
  // Die zur Bestaetigung anstehende Auswahl, oder null. Zwei Stufen brauchen
  // eine ausdrueckliche Kenntnisnahme, bevor sie ueberhaupt in das Feld
  // wandern: Oeffentlich immer, Mitglieder bei Protokollen von
  // Sicherheitsbesprechungen.
  const [pending, setPending] = useState<SmsDocumentVisibility | null>(null)
  const selectRef = useRef<HTMLSelectElement>(null)

  // `defaultValue` ist der gespeicherte Serverwert: Das Feld wird bei jedem
  // Öffnen des Formulars neu gemountet, und nach dem Speichern liefert die
  // revalidierte Seite den neuen Wert nach. Weicht die lokale Auswahl davon ab,
  // ist sie ein blosser Entwurf — und muss als solcher gekennzeichnet sein,
  // weil auf derselben Seite serverbasierte Anzeigen (Sichtbarkeits-Badge des
  // Dokuments, Status der Anhänge) weiterhin den gespeicherten Zustand zeigen.
  // Ohne Kennzeichnung stehen beide Wahrheiten unvermittelt nebeneinander.
  //
  // Während des Speicherns unterdrückt: sonst stünde der Hinweis für die Dauer
  // der Aktion neben der Erfolgsmeldung und widerspräche ihr.
  const isDraft = value !== defaultValue && !saving

  // Ohne diesen Sync zeigte das Feld nach jedem Speichern "Vertraulich" (erste
  // Option), obwohl gespeicherter Wert und React-State weiterhin z. B.
  // "Oeffentlich" sind — eine datenschutzkritisch irrefuehrende Anzeige.
  useRestoreAfterFormReset(selectRef, () => {
    if (selectRef.current) selectRef.current.value = value
  })

  // Protokolle enthalten haeufig personenbezogene Angaben; die Stufe
  // Mitglieder vergroessert den Empfaengerkreis dort erheblich (siehe
  // Datenschutzabschnitt in Issue #36).
  const needsMinutesConfirmation =
    category === "safety_meeting_minutes" && value !== "members"

  function handleChange(next: SmsDocumentVisibility) {
    if (next === value) return
    // Erst nach ausdrücklicher Bestätigung übernehmen; select bleibt solange
    // auf dem bisherigen (kontrollierten) Wert.
    if (next === "public") {
      setPending("public")
      return
    }
    if (next === "members" && needsMinutesConfirmation) {
      setPending("members")
      return
    }
    setValue(next)
  }

  // Die Herabstufung selbst braucht keine Bestaetigung — aber der Nutzer muss
  // wissen, dass sie bestehende Anhang-Freigaben mitnimmt
  // (lib/actions/sms-documents.ts).
  const revokesAttachmentReleases =
    defaultValue === "public" && value !== "public"

  return (
    <div className={fieldWrap}>
      <label htmlFor={`${idPrefix}-visibility`} className={labelClass}>
        Sichtbarkeit
      </label>
      <select
        ref={selectRef}
        id={`${idPrefix}-visibility`}
        name="visibility"
        value={value}
        onChange={(e) => handleChange(e.target.value as SmsDocumentVisibility)}
        className="flex h-10 w-full rounded-md border border-input bg-white px-3 py-2 text-sm outline-none focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/40 sm:w-64"
      >
        {SMS_DOCUMENT_VISIBILITY_VALUES.map((v) => (
          <option key={v} value={v}>
            {SMS_DOCUMENT_VISIBILITY_LABELS[v]}
          </option>
        ))}
      </select>
      <p className="text-xs text-muted-foreground">
        {SMS_DOCUMENT_VISIBILITY_HINTS[value]}
      </p>

      {isDraft ? (
        <p
          className="text-xs font-medium text-amber-700 dark:text-amber-400"
          role="status"
        >
          Ungespeicherte Änderung – wird erst mit „Speichern“ wirksam.
        </p>
      ) : null}

      {category === "safety_meeting_minutes" && value === "members" ? (
        <div
          className="rounded-r-lg border-l-2 border-amber-500 bg-amber-50 px-3 py-2 text-xs leading-relaxed text-amber-800 dark:bg-amber-950/30 dark:text-amber-300"
          role="note"
        >
          {SMS_DOCUMENT_MEETING_MINUTES_MEMBERS_HINT}
        </div>
      ) : null}

      {revokesAttachmentReleases ? (
        <div
          className="rounded-r-lg border-l-2 border-amber-500 bg-amber-50 px-3 py-2 text-xs leading-relaxed text-amber-800 dark:bg-amber-950/30 dark:text-amber-300"
          role="note"
        >
          {SMS_DOCUMENT_PUBLIC_DOWNGRADE_HINT}
        </div>
      ) : null}

      {value === "public" ? (
        <div
          className="rounded-r-lg border-l-2 border-amber-500 bg-amber-50 px-3 py-2 text-xs leading-relaxed text-amber-800 dark:bg-amber-950/30 dark:text-amber-300"
          role="note"
        >
          {isDraft ? (
            <>
              <strong className="font-medium">
                Nach dem Speichern öffentlich sichtbar:
              </strong>{" "}
              Titel und Inhalt werden dann ohne Anmeldung im Internet unter{" "}
              <span className="font-mono">/communications</span> angezeigt. Vor
              dem Speichern prüfen: keine personenbezogenen Daten,
              vertraulichen Kontaktdaten, internen Telefonnummern,
              identifizierenden Falldetails oder sonstigen nicht für die
              Öffentlichkeit bestimmten Angaben.
            </>
          ) : (
            <>
              <strong className="font-medium">Öffentlich sichtbar:</strong>{" "}
              Titel und Inhalt werden ohne Anmeldung im Internet unter{" "}
              <span className="font-mono">/communications</span> angezeigt. Vor
              der Freigabe prüfen: keine personenbezogenen Daten, vertraulichen
              Kontaktdaten, internen Telefonnummern, identifizierenden
              Falldetails oder sonstigen nicht für die Öffentlichkeit
              bestimmten Angaben.
            </>
          )}
        </div>
      ) : null}

      <Dialog
        open={pending !== null}
        onOpenChange={(open) => {
          if (!open) setPending(null)
        }}
      >
        <DialogContent showCloseButton={false}>
          <DialogHeader>
            <DialogTitle>
              {pending === "members"
                ? "Protokoll für angemeldete Personen freigeben?"
                : "Für Veröffentlichung vormerken?"}
            </DialogTitle>
            <DialogDescription>
              {pending === "members" ? (
                SMS_DOCUMENT_MEETING_MINUTES_MEMBERS_HINT
              ) : (
                <>
                  Hiermit wird zunächst nur die Auswahl übernommen. Öffentlich
                  sichtbar wird das Dokument erst nach „Speichern“ — Titel und
                  Inhalt sind dann ohne Anmeldung im Internet unter
                  „/communications“ abrufbar. Bitte vorher sicherstellen, dass
                  keine personenbezogenen oder vertraulichen Angaben enthalten
                  sind. Die Veröffentlichung lässt sich später jederzeit
                  zurücknehmen.
                </>
              )}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => setPending(null)}
            >
              Abbrechen
            </Button>
            <Button
              type="button"
              size="sm"
              onClick={() => {
                if (pending) setValue(pending)
                setPending(null)
              }}
            >
              {pending === "members"
                ? "Verstanden, für angemeldete Personen vormerken"
                : "Für Veröffentlichung vormerken"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ─── Vorlagenauswahl ─────────────────────────────────────────────────────────
// Bietet optional eine kategoriepassende Vorlage an, aber NUR wenn das
// Inhaltsfeld leer ist und mindestens eine passende Vorlage existiert. Bei
// leerer Vorlagenliste bleibt die UI unsichtbar. Die Übernahme überschreibt
// niemals vorhandenen Text (Doppelabsicherung: gerendert nur bei leerem Inhalt +
// erneute Leer-Prüfung im onApply des Formulars) und prüft, dass die gewählte
// Vorlage zur aktuellen Kategorie gehört.
//
// Der Aufrufer gibt `key={category}` mit: Bei Kategorienwechsel wird die
// Komponente neu gemountet und eine ggf. unpassende Vorlagenauswahl damit
// automatisch zurückgesetzt (ohne setState im Effect).
function TemplatePicker({
  idPrefix,
  category,
  contentIsEmpty,
  onApply,
}: {
  idPrefix: string
  category: SmsDocumentCategory
  contentIsEmpty: boolean
  onApply: (category: SmsDocumentCategory, content: string) => void
}) {
  const templates = getTemplatesForCategory(category)
  const [selectedKey, setSelectedKey] = useState("")

  // Unsichtbar, solange Inhalt vorhanden ist oder es keine passende Vorlage gibt.
  if (!contentIsEmpty || templates.length === 0) return null

  const selected =
    templates.find((t) => t.templateKey === selectedKey) ?? null

  return (
    <div className="space-y-2 rounded-md border border-dashed bg-background p-3">
      <div className={fieldWrap}>
        <label htmlFor={`${idPrefix}-template`} className={labelClass}>
          Vorlage übernehmen (optional)
        </label>
        <select
          id={`${idPrefix}-template`}
          value={selectedKey}
          onChange={(e) => setSelectedKey(e.target.value)}
          className="flex h-10 w-full rounded-md border border-input bg-white px-3 py-2 text-sm outline-none focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/40"
        >
          <option value="">Keine Vorlage</option>
          {templates.map((t) => (
            <option key={t.templateKey} value={t.templateKey}>
              {t.label}
            </option>
          ))}
        </select>
        {selected?.description ? (
          <p className="text-xs text-muted-foreground">{selected.description}</p>
        ) : null}
      </div>
      <Button
        type="button"
        variant="outline"
        size="sm"
        disabled={!selected}
        onClick={() => {
          if (selected && selected.category === category) {
            // Token-Platzhalter ({{key|Fallback}}) ohne Daten rendern → es
            // bleiben die Fallback-Texte stehen, nie rohe {{…}}-Tokens.
            onApply(category, renderTemplate(selected.content, {}))
          }
        }}
      >
        Vorlage übernehmen
      </Button>
    </div>
  )
}

// ─── Protokoll mit PAOLO-Daten vorausfüllen ──────────────────────────────────
// Nur für die Kategorie "safety_meeting_minutes" und nur bei leerem Inhaltsfeld.
// Holt deterministische Stammdaten serverseitig (Variante A) und übergibt den
// gerenderten Markdown-Text über onApply (das seinerseits vorhandenen Inhalt
// nicht überschreibt). Kein KI-Schritt.
function MeetingMinutesPrefill({
  category,
  contentIsEmpty,
  onApply,
}: {
  category: SmsDocumentCategory
  contentIsEmpty: boolean
  onApply: (category: SmsDocumentCategory, content: string) => void
}) {
  const [pending, setPending] = useState(false)
  const [error, setError] = useState("")

  if (category !== "safety_meeting_minutes" || !contentIsEmpty) return null

  return (
    <div className="flex flex-wrap items-center gap-2">
      <Button
        type="button"
        variant="outline"
        size="sm"
        disabled={pending}
        onClick={async () => {
          setPending(true)
          setError("")
          try {
            const res = await prefillMeetingMinutes()
            if (res.success) {
              onApply(category, res.content)
            } else {
              setError(res.message)
            }
          } catch {
            setError("Vorbefüllen fehlgeschlagen.")
          } finally {
            setPending(false)
          }
        }}
      >
        {pending ? "Füllt…" : "Mit PAOLO-Daten vorausfüllen"}
      </Button>
      {error ? <span className="text-sm text-destructive">{error}</span> : null}
    </div>
  )
}

// ─── Anlegen ─────────────────────────────────────────────────────────────────

export function CreateDocumentForm({
  categories,
}: {
  categories: readonly SmsDocumentCategory[]
}) {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [category, setCategory] = useState<SmsDocumentCategory>(categories[0])
  const [content, setContent] = useState("")
  // Reset erfolgt bewusst in der Action (ereignisgesteuert), nicht in einem
  // Effect: Nach erfolgreichem Anlegen werden alle Create-Felder auf saubere
  // Standardwerte zurückgesetzt. Der kontrollierte Inhalt und die Kategorie
  // leben im State dieser Komponente (bleiben sonst über das nächste Anlegen
  // erhalten) und werden hier explizit geleert; Titel (uncontrolled),
  // Sichtbarkeit und die Vorlagen-/Vorausfüllauswahl liegen im bedingt
  // gerenderten Formular und werden beim Schließen + erneuten Öffnen frisch
  // gemountet.
  const [state, formAction, isPending] = useActionState(
    async (prev: SmsDocumentActionState, formData: FormData) => {
      const res = await createSmsDocument(prev, formData)
      if (res.success) {
        setContent("")
        setCategory(categories[0])
        setOpen(false)
        router.refresh()
      }
      return res
    },
    initialState
  )

  if (!open) {
    return (
      <Button type="button" size="sm" onClick={() => setOpen(true)}>
        Dokument anlegen
      </Button>
    )
  }

  return (
    <form
      action={formAction}
      className="space-y-4 rounded-md border bg-muted/40 p-4"
    >
      <p className="text-sm font-semibold text-foreground">Neues Dokument</p>

      <CategoryField
        idPrefix="new"
        categories={categories}
        value={category}
        onChange={setCategory}
      />

      <div className={fieldWrap}>
        <label htmlFor="new-title" className={labelClass}>
          Titel
        </label>
        <Input id="new-title" name="title" maxLength={200} required />
      </div>

      <div className={fieldWrap}>
        <label htmlFor="new-content" className={labelClass}>
          Inhalt (Text / Markdown)
        </label>
        <Textarea
          id="new-content"
          name="content"
          rows={10}
          value={content}
          onChange={(e) => setContent(e.target.value)}
          required
        />
      </div>

      <TemplatePicker
        key={category}
        idPrefix="new"
        category={category}
        contentIsEmpty={content.trim() === ""}
        onApply={(tplCategory, tplContent) =>
          setContent((prev) =>
            prev.trim() === "" && tplCategory === category ? tplContent : prev
          )
        }
      />

      <MeetingMinutesPrefill
        category={category}
        contentIsEmpty={content.trim() === ""}
        onApply={(tplCategory, tplContent) =>
          setContent((prev) =>
            prev.trim() === "" && tplCategory === category ? tplContent : prev
          )
        }
      />

      <VisibilityField
        idPrefix="new"
        category={category}
        defaultValue="confidential"
      />

      <div className="flex flex-wrap items-center gap-3">
        <Button type="submit" size="sm" disabled={isPending}>
          {isPending ? "Speichert…" : "Dokument speichern"}
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          disabled={isPending}
          onClick={() => setOpen(false)}
        >
          Abbrechen
        </Button>
        <Message state={state} />
      </div>
    </form>
  )
}

// ─── Bearbeiten ──────────────────────────────────────────────────────────────

type EditProps = {
  documentId: string
  category: SmsDocumentCategory
  title: string
  content: string
  visibility: SmsDocumentVisibility
  categories: readonly SmsDocumentCategory[]
}

export function DocumentEditForm(props: EditProps) {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [category, setCategory] = useState<SmsDocumentCategory>(props.category)
  const [content, setContent] = useState(props.content)
  const [state, formAction, isPending] = useActionState(
    updateSmsDocument,
    initialState
  )

  useEffect(() => {
    if (state.success) router.refresh()
  }, [state, router])

  if (!open) {
    return (
      <Button
        type="button"
        variant="outline"
        size="sm"
        onClick={() => setOpen(true)}
      >
        Bearbeiten
      </Button>
    )
  }

  // Das geöffnete Formular ist ein Kind der Aktionszeile von DocumentView
  // (flex flex-wrap): `order-last` hält Anzeigen/Drucken/Löschen zusammen in der
  // Aktionszeile, `basis-full` setzt das Formular in voller Breite darunter,
  // `min-w-0` hält die Breite unabhängig vom Inhalt. Ausserhalb eines
  // Flex-Containers sind die drei Klassen wirkungslos.
  return (
    <form
      action={formAction}
      className="order-last min-w-0 basis-full space-y-4 rounded-md border bg-background p-4"
    >
      <input type="hidden" name="documentId" value={props.documentId} />

      {/* key aus dem gespeicherten Serverwert: mountet das Radix-Select nach dem
          Speichern neu, sonst faellt es beim Form-Reset auf den Wert vom
          Seitenaufbau zurueck (siehe Kommentar in workflow-form.tsx). */}
      <CategoryField
        key={`category-${props.category}`}
        idPrefix={`edit-${props.documentId}`}
        categories={props.categories}
        value={category}
        onChange={setCategory}
      />

      <div className={fieldWrap}>
        <label
          htmlFor={`edit-title-${props.documentId}`}
          className={labelClass}
        >
          Titel
        </label>
        <Input
          id={`edit-title-${props.documentId}`}
          name="title"
          maxLength={200}
          defaultValue={props.title}
          required
        />
      </div>

      <div className={fieldWrap}>
        <label
          htmlFor={`edit-content-${props.documentId}`}
          className={labelClass}
        >
          Inhalt (Text / Markdown)
        </label>
        <Textarea
          id={`edit-content-${props.documentId}`}
          name="content"
          rows={10}
          value={content}
          onChange={(e) => setContent(e.target.value)}
          required
        />
      </div>

      <TemplatePicker
        key={category}
        idPrefix={`edit-${props.documentId}`}
        category={category}
        contentIsEmpty={content.trim() === ""}
        onApply={(tplCategory, tplContent) =>
          setContent((prev) =>
            prev.trim() === "" && tplCategory === category ? tplContent : prev
          )
        }
      />

      <MeetingMinutesPrefill
        category={category}
        contentIsEmpty={content.trim() === ""}
        onApply={(tplCategory, tplContent) =>
          setContent((prev) =>
            prev.trim() === "" && tplCategory === category ? tplContent : prev
          )
        }
      />

      <VisibilityField
        idPrefix={`edit-${props.documentId}`}
        category={category}
        defaultValue={props.visibility}
        saving={isPending}
      />

      <div className="flex flex-wrap items-center gap-3">
        <Button type="submit" size="sm" disabled={isPending}>
          {isPending ? "Speichert…" : "Speichern"}
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          disabled={isPending}
          onClick={() => setOpen(false)}
        >
          Abbrechen
        </Button>
        <Message state={state} />
      </div>
    </form>
  )
}

// ─── Löschen ─────────────────────────────────────────────────────────────────

export function DocumentDeleteForm({
  documentId,
  title,
}: {
  documentId: string
  title: string
}) {
  const router = useRouter()
  const [state, formAction, isPending] = useActionState(
    deleteSmsDocument,
    initialState
  )

  useEffect(() => {
    if (state.success) router.refresh()
  }, [state, router])

  return (
    <form
      action={formAction}
      onSubmit={(e) => {
        if (
          !window.confirm(
            `Dokument „${title}" wirklich löschen? Dies kann nicht rückgängig gemacht werden.`
          )
        ) {
          e.preventDefault()
        }
      }}
      className="inline-flex items-center gap-2"
    >
      <input type="hidden" name="documentId" value={documentId} />
      <Button
        type="submit"
        variant="ghost"
        size="sm"
        disabled={isPending}
        className="text-destructive hover:text-destructive"
      >
        {isPending ? "Löscht…" : "Löschen"}
      </Button>
      {!state.success && state.message ? (
        <span className="text-sm text-destructive">{state.message}</span>
      ) : null}
    </form>
  )
}
