"use client"

import ReactMarkdown, { type Components } from "react-markdown"
import remarkGfm from "remark-gfm"

// Sichere, formatierte Anzeige der SMS-Dokumentinhalte (nur Anzeige, keine
// Bearbeitung). Der gespeicherte Markdown-Text wird unverändert übergeben und
// rein clientseitig gerendert.
//
// Sicherheit:
// - KEIN rehype-raw und KEIN allowDangerousHtml. react-markdown rendert ohne
//   diese Plugins grundsätzlich KEIN rohes HTML aus dem Inhalt – etwaige
//   <script>/<img>/<div>-Fragmente werden als Text behandelt, nicht ausgeführt.
//   Damit ist HTML-/Script-Injection über Dokumentinhalte ausgeschlossen.
// - Nur remark-gfm (Tabellen, Aufgabenlisten, Durchstreichen) als Erweiterung.
// - react-markdown normalisiert Link-URLs (blockt z. B. javascript:-URLs).
// - Externe Links (http/https) öffnen in neuem Tab mit
//   rel="noopener noreferrer nofollow".

function isExternal(href?: string): boolean {
  return typeof href === "string" && /^https?:\/\//i.test(href)
}

const components: Components = {
  h1: ({ children }) => (
    <h1 className="mt-6 mb-3 font-heading text-xl font-semibold leading-snug text-foreground first:mt-0">
      {children}
    </h1>
  ),
  h2: ({ children }) => (
    <h2 className="mt-6 mb-2 font-heading text-lg font-semibold leading-snug text-foreground first:mt-0">
      {children}
    </h2>
  ),
  h3: ({ children }) => (
    <h3 className="mt-5 mb-2 text-base font-semibold text-foreground first:mt-0">
      {children}
    </h3>
  ),
  h4: ({ children }) => (
    <h4 className="mt-4 mb-1.5 text-sm font-semibold text-foreground first:mt-0">
      {children}
    </h4>
  ),
  p: ({ children }) => (
    <p className="my-2 leading-relaxed text-foreground">{children}</p>
  ),
  ul: ({ children }) => (
    <ul className="my-2 list-disc space-y-1 pl-6 text-foreground">{children}</ul>
  ),
  ol: ({ children }) => (
    <ol className="my-2 list-decimal space-y-1 pl-6 text-foreground">
      {children}
    </ol>
  ),
  li: ({ children }) => <li className="leading-relaxed">{children}</li>,
  a: ({ href, children }) => {
    const external = isExternal(href)
    return (
      <a
        href={href}
        className="font-medium text-sky-700 underline underline-offset-2 hover:text-sky-900 dark:text-sky-400 dark:hover:text-sky-300"
        {...(external
          ? { target: "_blank", rel: "noopener noreferrer nofollow" }
          : {})}
      >
        {children}
      </a>
    )
  },
  strong: ({ children }) => (
    <strong className="font-semibold text-foreground">{children}</strong>
  ),
  em: ({ children }) => <em className="italic">{children}</em>,
  blockquote: ({ children }) => (
    <blockquote className="my-3 border-l-2 border-sky-500 bg-muted/50 py-1 pl-4 text-muted-foreground">
      {children}
    </blockquote>
  ),
  code: ({ children }) => (
    <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-[0.85em] text-foreground">
      {children}
    </code>
  ),
  pre: ({ children }) => (
    <pre className="my-3 overflow-x-auto rounded-md bg-muted p-3 font-mono text-xs text-foreground">
      {children}
    </pre>
  ),
  hr: () => <hr className="my-4 border-border" />,
  // Tabellen in einen horizontal scrollbaren Container wickeln, damit breite
  // Tabellen (z. B. die Protokollvorlage) auf schmalen Screens lesbar bleiben.
  table: ({ children }) => (
    <div className="my-4 overflow-x-auto rounded-md border">
      <table className="w-full border-collapse text-left text-sm">
        {children}
      </table>
    </div>
  ),
  thead: ({ children }) => <thead className="bg-muted/60">{children}</thead>,
  tbody: ({ children }) => <tbody>{children}</tbody>,
  tr: ({ children }) => (
    <tr className="border-b border-border last:border-0">{children}</tr>
  ),
  th: ({ children }) => (
    <th className="whitespace-nowrap px-3 py-2 font-semibold text-foreground">
      {children}
    </th>
  ),
  td: ({ children }) => (
    <td className="px-3 py-2 align-top text-foreground">{children}</td>
  ),
}

export function DocumentMarkdownView({ content }: { content: string }) {
  return (
    <div className="text-sm text-foreground">
      <ReactMarkdown remarkPlugins={[remarkGfm]} components={components}>
        {content}
      </ReactMarkdown>
    </div>
  )
}
