"use client"

import { useActionState, useRef, useState } from "react"

import {
  publishSmsDocumentAttachment,
  type AttachmentReleaseState,
} from "@/lib/actions/attachments"
import { useRestoreAfterFormReset } from "@/lib/hooks/use-restore-after-form-reset"
import {
  ATTACHMENT_RELEASE_WARNING,
  getRequiredChecklistItems,
  RELEASE_NOTE_MAX_LENGTH,
  RELEASE_NOTE_MIN_LENGTH,
} from "@/lib/constants/attachment-release"
import {
  buildSessionAttachmentPath,
  isInlineDisplayableImage,
} from "@/lib/constants/attachment-visibility"

import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

// Freigabedialog. Bringt bewusst drei Dinge an EINER Stelle zusammen, statt
// den Hinweis irgendwo in der Dokumentation zu verstecken:
//
//   1. die Vorschau genau dieser Datei — ohne gesehenen Inhalt keine Freigabe,
//   2. den Hinweis auf die zu pruefenden Rechtspositionen,
//   3. Checkliste und Freigabevermerk als Sperre vor dem Absenden.
//
// Der Absenden-Knopf bleibt gesperrt, bis alle Punkte bestaetigt sind und der
// Vermerk lang genug ist. Das ist reine Bedienerfuehrung — die verbindliche
// Pruefung findet in der Server Action statt.

const initialState: AttachmentReleaseState = { success: false, message: "" }

// Eigene Komponente, damit Ref und Reset-Listener genau so lange leben wie das
// <fieldset> selbst.
//
// Der Listener MUSS hier sitzen und nicht im Dialog darueber: Der Dialoginhalt
// wird erst beim Oeffnen gerendert. Ein Effekt im Elternteil laeuft schon beim
// Mount des geschlossenen Dialogs, findet dann kein Formular — und lief bei
// jedem spaeteren Durchlauf Gefahr, den Listener im Cleanup wieder abzuhaengen,
// ohne einen neuen zu setzen. Genau das war der Fall: Der Listener war zum
// Zeitpunkt des Resets nicht mehr registriert, und die Wiederherstellung blieb
// wirkungslos (Issue #26).
//
// Wozu das Ganze: Nach einem FEHLGESCHLAGENEN Absenden bleibt der Dialog
// stehen, React 19 setzt das Formular trotzdem zurueck und nimmt alle Haken
// weg — waehrend `confirmed` sie weiter als bestaetigt fuehrt und der
// Freigabe-Button aktiv bleibt. Eine Freigabepruefung darf nicht unbestaetigt
// aussehen, wenn sie es nicht ist. Im Erfolgsfall stellt sich die Frage nicht:
// Dort revalidiert die Action, die Serverkomponente tauscht den Dialog gegen
// „Freigabe zuruecknehmen", und alles hier unmountet.
function ReleaseChecklist({
  items,
  confirmed,
  onToggle,
}: {
  items: readonly { key: string; label: string }[]
  confirmed: Set<string>
  onToggle: (key: string) => void
}) {
  const checklistRef = useRef<HTMLFieldSetElement>(null)

  useRestoreAfterFormReset(checklistRef, () => {
    const fieldset = checklistRef.current
    if (!fieldset) return
    for (const box of fieldset.querySelectorAll<HTMLInputElement>(
      'input[type="checkbox"]'
    )) {
      box.checked = confirmed.has(box.value)
    }
  })

  return (
    <fieldset ref={checklistRef} className="space-y-2">
      <legend className="text-sm font-medium">Freigabeprüfung bestätigen</legend>
      {items.map((item) => (
        <label
          key={item.key}
          className="flex cursor-pointer items-start gap-2 rounded-md border p-2 text-xs leading-relaxed hover:bg-muted/40"
        >
          <input
            type="checkbox"
            name="checklist"
            value={item.key}
            checked={confirmed.has(item.key)}
            onChange={() => onToggle(item.key)}
            className="mt-0.5 h-4 w-4 flex-shrink-0"
          />
          <span>{item.label}</span>
        </label>
      ))}
    </fieldset>
  )
}

type Props = {
  documentId: string
  attachmentId: string
  fileName: string
  mimeType: string
  documentIsPublic: boolean
}

export function AttachmentReleaseDialog({
  documentId,
  attachmentId,
  fileName,
  mimeType,
  documentIsPublic,
}: Props) {
  const [open, setOpen] = useState(false)
  const [confirmed, setConfirmed] = useState<Set<string>>(new Set())
  const [note, setNote] = useState("")
  const [state, formAction, isPending] = useActionState(
    publishSmsDocumentAttachment,
    initialState
  )

  const items = getRequiredChecklistItems(fileName)
  const allConfirmed = items.every((item) => confirmed.has(item.key))
  const noteLongEnough = note.trim().length >= RELEASE_NOTE_MIN_LENGTH
  const canSubmit = allConfirmed && noteLongEnough && !isPending

  const previewUrl = buildSessionAttachmentPath(documentId, attachmentId)

  function toggle(key: string) {
    setConfirmed((prev) => {
      const next = new Set(prev)
      if (next.has(key)) next.delete(key)
      else next.add(key)
      return next
    })
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        setOpen(next)
        // Beim Schliessen zuruecksetzen: eine halb ausgefuellte Pruefung darf
        // beim naechsten Oeffnen nicht schon bestaetigt aussehen.
        if (!next) {
          setConfirmed(new Set())
          setNote("")
        }
      }}
    >
      <DialogTrigger asChild>
        <Button type="button" variant="outline" size="sm">
          Öffentlich freigeben…
        </Button>
      </DialogTrigger>

      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Anhang öffentlich freigeben</DialogTitle>
          <DialogDescription className="break-all">{fileName}</DialogDescription>
        </DialogHeader>

        <form action={formAction} className="space-y-5">
          <input type="hidden" name="documentId" value={documentId} />
          <input type="hidden" name="attachmentId" value={attachmentId} />

          {/* 1. Inhalt ansehen */}
          <section className="space-y-2">
            <p className="text-sm font-medium">Inhalt prüfen</p>
            {isInlineDisplayableImage(mimeType) ? (
              /* Die Datei liegt hinter einer geschuetzten Route; der
                 Optimierer von next/image kann sie nicht abrufen. */
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={previewUrl}
                alt={`Vorschau: ${fileName}`}
                className="max-h-72 w-auto rounded-md border bg-muted/40 object-contain"
              />
            ) : (
              <p className="text-sm text-muted-foreground">
                Für diesen Dateityp gibt es keine Vorschau.{" "}
                <a
                  href={previewUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="font-medium text-blue-800 underline underline-offset-4"
                >
                  Datei öffnen
                </a>{" "}
                und vor der Freigabe vollständig ansehen.
              </p>
            )}
          </section>

          {/* 2. Hinweis unmittelbar an der Freigabe */}
          <div
            className="rounded-r-lg border-l-2 border-amber-500 bg-amber-50 px-3 py-2 text-xs leading-relaxed text-amber-800 dark:bg-amber-950/30 dark:text-amber-300"
            role="note"
          >
            {ATTACHMENT_RELEASE_WARNING}
          </div>

          {!documentIsPublic ? (
            <div
              className="rounded-r-lg border-l-2 border-sky-500 bg-sky-50 px-3 py-2 text-xs leading-relaxed text-sky-800 dark:bg-sky-950/30 dark:text-sky-300"
              role="note"
            >
              Dieses Dokument ist derzeit nicht öffentlich. Der Anhang wird
              erst dann öffentlich abrufbar, wenn auch das Dokument selbst
              auf „Öffentlich&quot; gesetzt wird.
            </div>
          ) : null}

          {/* 3. Checkliste */}
          <ReleaseChecklist items={items} confirmed={confirmed} onToggle={toggle} />

          {/* 4. Freigabevermerk */}
          <div className="space-y-2">
            <label
              htmlFor={`release-note-${attachmentId}`}
              className="text-sm font-medium"
            >
              {/* Die Mindestlaenge kommt aus derselben Konstante wie die
                  Zod-Regel — sie steht nirgends ein zweites Mal. */}
              Freigabevermerk (Pflicht, mindestens {RELEASE_NOTE_MIN_LENGTH}{" "}
              Zeichen)
            </label>
            <textarea
              id={`release-note-${attachmentId}`}
              name="releaseNote"
              rows={3}
              required
              minLength={RELEASE_NOTE_MIN_LENGTH}
              maxLength={RELEASE_NOTE_MAX_LENGTH}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Keine unzulässigen personenbezogenen Daten enthalten; erforderliche Bildrechte liegen vor."
              className="w-full rounded-md border border-input bg-white px-3 py-2 text-sm outline-none focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/40"
            />
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <p className="text-xs text-muted-foreground">
                Kurz in eigenen Worten: woraus ergibt sich, dass diese Datei
                veröffentlicht werden darf? Der Vermerk wird am Anhang
                gespeichert.
              </p>
              {/* Gezaehlt wird die getrimmte Laenge — genau das prueft auch
                  das Zod-Schema. Sonst zeigte das Feld bei zehn Leerzeichen
                  eine erfuellte Mindestlaenge an und das Absenden schluege
                  trotzdem fehl. */}
              <p
                aria-live="polite"
                className={`shrink-0 text-xs tabular-nums ${
                  noteLongEnough ? "text-muted-foreground" : "text-amber-700 dark:text-amber-400"
                }`}
              >
                {note.trim().length} / {RELEASE_NOTE_MIN_LENGTH} Zeichen
              </p>
            </div>
          </div>

          {state.message ? (
            <p
              className={`text-sm ${
                state.success ? "text-emerald-600" : "text-destructive"
              }`}
            >
              {state.message}
            </p>
          ) : null}

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setOpen(false)}
            >
              Abbrechen
            </Button>
            <Button type="submit" size="sm" disabled={!canSubmit}>
              {isPending ? "Wird freigegeben…" : "Öffentlich freigeben"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
