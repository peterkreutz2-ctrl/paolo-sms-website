"use client"

import { useActionState, useState } from "react"

import {
  deleteSmsDocumentAttachment,
  unpublishSmsDocumentAttachment,
  uploadSmsDocumentAttachment,
  type AttachmentReleaseState,
  type DeleteAttachmentState,
  type UploadAttachmentState,
} from "@/lib/actions/attachments"
import {
  ATTACHMENT_ACCEPT_ATTRIBUTE,
  ATTACHMENT_TYPES_LABEL,
  MAX_FILE_SIZE_MB,
} from "@/lib/constants/attachment-file-types"
import {
  attachmentReachLabel,
  buildSessionAttachmentPath,
  describeAttachmentReach,
  isInlineDisplayableImage,
  isPlayableVideo,
} from "@/lib/constants/attachment-visibility"
import { attachments } from "@/lib/db/schema"

import {
  AttachmentVideoPlayer,
  VideoUploadHint,
} from "@/components/attachment-video"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { UploadSafetyNotice } from "@/components/upload-safety-notice"
import { Input } from "@/components/ui/input"

import { validateAttachmentFile } from "../attachment-file-check"
import { AttachmentReleaseDialog } from "./attachment-release-dialog"

// Anhaenge eines SMS-Dokuments. Darstellung bewusst identisch zur
// Anhangsliste einer Meldung (app/dashboard/reports/[reportId]/
// report-attachments.tsx) — gleiche Angaben, gleiche Reihenfolge, gleicher
// Download-Link. Keine eigene Viewer-Komponente und keine Inline-Vorschau:
// beides braucht es erst zusammen mit der oeffentlichen Freigabe.

type AttachmentRow = typeof attachments.$inferSelect

const uploadInitialState: UploadAttachmentState = {
  success: false,
  message: "",
}

const deleteInitialState: DeleteAttachmentState = {
  success: false,
  message: "",
}

const releaseInitialState: AttachmentReleaseState = {
  success: false,
  message: "",
}

const dateTimeFormatter = new Intl.DateTimeFormat("de-DE", {
  dateStyle: "medium",
  timeStyle: "short",
})

const CONFIRM_MESSAGE =
  "Diesen Anhang endgültig löschen? Diese Aktion kann nicht rückgängig gemacht werden."

const dateFormatter = new Intl.DateTimeFormat("de-DE", {
  dateStyle: "medium",
  timeStyle: "short",
})

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}

function formatMimeType(mimeType: string, fileName: string): string {
  if (mimeType === "application/pdf") return "PDF-Dokument"
  if (isPlayableVideo(mimeType)) return "Video (MP4)"
  if (mimeType.startsWith("image/")) return "Bilddatei"
  if (mimeType === "text/plain") return "Textdatei"
  if (mimeType.includes("gpx")) return "GPX-Tracklog"
  if (mimeType.includes("kml")) return "KML-Datei"
  // IGC-Dateien kommen ohne eigenen MIME-Typ an (siehe
  // lib/constants/attachment-file-types.ts); die Endung ist hier die einzige
  // verlaessliche Angabe.
  if (fileName.toLowerCase().endsWith(".igc")) return "IGC-Tracklog"
  return "Datei"
}

function UploadForm({ documentId }: { documentId: string }) {
  const [state, formAction, isPending] = useActionState(
    uploadSmsDocumentAttachment,
    uploadInitialState
  )
  // Siehe report-attachments.tsx: dieselbe Vorpruefung mit derselben Funktion,
  // damit der Nutzer nicht einen rohen 413 der Plattform sieht — bei Video
  // zusaetzlich die Laufzeit.
  const [localError, setLocalError] = useState<string | null>(null)
  const [checking, setChecking] = useState(false)

  const fieldId = `document-file-${documentId}`

  async function handleFileChange(file: File | undefined) {
    setLocalError(null)
    if (!file) return
    setChecking(true)
    try {
      setLocalError(await validateAttachmentFile(file))
    } finally {
      setChecking(false)
    }
  }

  return (
    <form
      action={formAction}
      className="space-y-3 rounded-md border p-3"
      onSubmit={(e) => {
        if (localError || checking) e.preventDefault()
      }}
    >
      <input type="hidden" name="documentId" value={documentId} />

      <div className="space-y-2">
        <label htmlFor={fieldId} className="text-sm font-medium">
          Datei hochladen
        </label>
        <Input
          id={fieldId}
          name="file"
          type="file"
          required
          accept={ATTACHMENT_ACCEPT_ATTRIBUTE}
          onChange={(e) => void handleFileChange(e.target.files?.[0])}
        />
        <p className="text-xs text-muted-foreground">
          Erlaubt: {ATTACHMENT_TYPES_LABEL} (max. {MAX_FILE_SIZE_MB} MB).
        </p>
        <VideoUploadHint />
        <UploadSafetyNotice />
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <Button
          type="submit"
          size="sm"
          disabled={isPending || checking || localError !== null}
        >
          {isPending ? "Lädt hoch…" : checking ? "Prüft…" : "Anhang hochladen"}
        </Button>
        {localError ?? state.message ? (
          <p
            className={`text-sm ${
              !localError && state.success
                ? "text-emerald-600"
                : "text-destructive"
            }`}
          >
            {localError ?? state.message}
          </p>
        ) : null}
      </div>
    </form>
  )
}

function DeleteButton({
  documentId,
  attachmentId,
}: {
  documentId: string
  attachmentId: string
}) {
  const [state, formAction, isPending] = useActionState(
    deleteSmsDocumentAttachment,
    deleteInitialState
  )

  return (
    <form
      action={formAction}
      className="flex flex-col items-start gap-2"
      onSubmit={(e) => {
        if (!window.confirm(CONFIRM_MESSAGE)) {
          e.preventDefault()
        }
      }}
    >
      <input type="hidden" name="documentId" value={documentId} />
      <input type="hidden" name="attachmentId" value={attachmentId} />
      <Button
        type="submit"
        variant="outline"
        size="sm"
        disabled={isPending}
        className="border-destructive/50 text-destructive hover:bg-destructive/10"
      >
        {isPending ? "Wird gelöscht…" : "Anhang endgültig löschen"}
      </Button>
      {state.message ? (
        <p
          className={`text-sm ${
            state.success ? "text-emerald-600" : "text-destructive"
          }`}
        >
          {state.message}
        </p>
      ) : null}
    </form>
  )
}

function UnpublishButton({
  documentId,
  attachmentId,
}: {
  documentId: string
  attachmentId: string
}) {
  const [state, formAction, isPending] = useActionState(
    unpublishSmsDocumentAttachment,
    releaseInitialState
  )

  return (
    // Kein Bestaetigungsdialog: das Zuruecknehmen ist die sichere Richtung
    // und muss schnell gehen. Gleiche Logik wie beim Zurueckziehen der
    // Dokument-Sichtbarkeit.
    <form action={formAction} className="flex flex-col items-start gap-2">
      <input type="hidden" name="documentId" value={documentId} />
      <input type="hidden" name="attachmentId" value={attachmentId} />
      <Button type="submit" variant="outline" size="sm" disabled={isPending}>
        {isPending ? "Wird zurückgenommen…" : "Freigabe zurücknehmen"}
      </Button>
      {state.message ? (
        <p
          className={`text-sm ${
            state.success ? "text-emerald-600" : "text-destructive"
          }`}
        >
          {state.message}
        </p>
      ) : null}
    </form>
  )
}

export function DocumentAttachmentsSection({
  documentId,
  documentTitle,
  documentVisibility,
  attachments: rows,
}: {
  documentId: string
  documentTitle: string
  documentVisibility: string
  attachments: AttachmentRow[]
}) {
  const documentIsPublic = documentVisibility === "public"
  return (
    <section
      aria-label={`Anhänge: ${documentTitle}`}
      className="space-y-3 rounded-md border bg-muted/40 p-3"
    >
      <div className="space-y-1">
        <p className="text-sm font-medium">Anhänge</p>
        <p className="text-xs text-muted-foreground">
          Dateien zu diesem SMS-Dokument (z. B. Bilder, PDF, Tracklogs). Sie
          erben die Sichtbarkeit des Dokuments: Wer es lesen
          darf, kann die Dateien herunterladen. Ohne Anmeldung abrufbar wird
          eine Datei erst durch eine eigene Freigabe. Hochladen und Löschen
          bleiben Administrator und Safety Manager vorbehalten.
        </p>
      </div>

      <UploadForm documentId={documentId} />

      {rows.length === 0 ? (
        <p className="text-sm text-muted-foreground">
          Noch keine Anhänge hochgeladen.
        </p>
      ) : (
        <div className="space-y-3">
          {rows.map((file) => {
            const href = buildSessionAttachmentPath(documentId, file.id)
            const isImage = isInlineDisplayableImage(file.mimeType)

            return (
              <div
                key={file.id}
                className="space-y-3 rounded-md border bg-card p-3 text-sm"
              >
                <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                  <div className="min-w-0 space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="truncate font-medium">
                        {file.originalFileName}
                      </p>
                      {/* Status unmittelbar am Anhang, nicht in einer
                          Legende irgendwo daneben. Drei Zustaende statt zwei:
                          eine Freigabe an einem nicht oeffentlichen Dokument
                          waere als "Öffentlich freigegeben" irrefuehrend —
                          die Datei ist dann gerade NICHT erreichbar.
                          Ohne Freigabe nennt das Abzeichen die geerbte Stufe
                          des Dokuments statt pauschal "Nur intern": Bei
                          'members' erreicht die Datei jedes angemeldete
                          Mitglied, nicht nur den Bearbeiterkreis. */}
                      <Badge
                        variant={
                          file.isPublic && documentIsPublic
                            ? "default"
                            : file.isPublic
                              ? "secondary"
                              : "outline"
                        }
                        className="font-normal"
                      >
                        {attachmentReachLabel(
                          describeAttachmentReach({
                            isPublic: file.isPublic,
                            documentVisibility,
                          })
                        )}
                      </Badge>
                    </div>
                    <p className="text-muted-foreground">
                      {formatMimeType(file.mimeType, file.originalFileName)}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {formatBytes(file.fileSize)} ·{" "}
                      {dateFormatter.format(file.createdAt)}
                    </p>
                  </div>

                  {isImage ? (
                    /* Interne Vorschau: die geschuetzte Route liefert Bilder
                       inline aus. eslint-disable, weil der Optimierer von
                       next/image die geschuetzte Route nicht abrufen kann. */
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={href}
                      alt={`Vorschau: ${file.originalFileName}`}
                      className="h-20 w-auto flex-shrink-0 rounded border bg-muted/40 object-contain"
                    />
                  ) : null}
                </div>

                {/* Ohne gesehenen Inhalt keine Freigabe — deshalb muss auch
                    ein Video vor der Freigabe abspielbar sein. Der
                    Download-Link unten bleibt daneben bestehen. */}
                {isPlayableVideo(file.mimeType) ? (
                  <AttachmentVideoPlayer
                    src={href}
                    fileName={file.originalFileName}
                  />
                ) : null}

                {file.isPublic && file.publicReleasedAt ? (
                  <div className="rounded-md bg-muted/60 p-2 text-xs leading-relaxed text-muted-foreground">
                    <p>
                      Freigegeben am{" "}
                      {dateTimeFormatter.format(file.publicReleasedAt)}
                    </p>
                    {file.publicReleaseNote ? (
                      <p className="mt-1">
                        <span className="font-medium">Freigabevermerk:</span>{" "}
                        {file.publicReleaseNote}
                      </p>
                    ) : null}
                    {!documentIsPublic ? (
                      <p className="mt-1 font-medium text-amber-700 dark:text-amber-400">
                        Noch nicht öffentlich erreichbar: Dieses Dokument steht
                        nicht auf „Öffentlich“. Der Anhang wird erst abrufbar,
                        wenn die Sichtbarkeit des Dokuments umgestellt wird.
                      </p>
                    ) : null}
                  </div>
                ) : null}

                <div className="flex flex-wrap items-start gap-3">
                  <a
                    href={href}
                    target="_blank"
                    rel="noreferrer"
                    className="text-sm text-blue-800 underline-offset-4 hover:text-blue-900 hover:underline"
                  >
                    Öffnen / Download
                  </a>

                  {file.isPublic ? (
                    <UnpublishButton
                      documentId={documentId}
                      attachmentId={file.id}
                    />
                  ) : (
                    <AttachmentReleaseDialog
                      documentId={documentId}
                      attachmentId={file.id}
                      fileName={file.originalFileName}
                      mimeType={file.mimeType}
                      documentIsPublic={documentIsPublic}
                    />
                  )}

                  <DeleteButton documentId={documentId} attachmentId={file.id} />
                </div>
              </div>
            )
          })}
        </div>
      )}
    </section>
  )
}
