"use client"

import { useState } from "react"

import { Button } from "@/components/ui/button"
import {
  SMS_DOCUMENT_VISIBILITY_LABELS,
  SMS_DOCUMENT_VISIBILITY_VALUES,
  type SmsDocumentVisibility,
} from "@/lib/constants/sms-documents"

import { DocumentMarkdownView } from "./document-markdown-view"

// Gemeinsame Präsentationskomponenten für die Dokumentanzeige. Bewusst frei von
// Server-Action-Importen, damit sie sowohl im internen Bereich
// (/dashboard/documents) als auch auf der öffentlichen Seite (/communications)
// verwendet werden können, ohne den Editor-/Mutations-Code in das öffentliche
// Bundle zu ziehen. So ist die Bedienung („Aufklappen/Zuklappen" der Bereiche,
// „Anzeigen/Verbergen" der Inhalte) auf beiden Seiten identisch.

// ─── Aufklappbarer Bereich ───────────────────────────────────────────────────
// Klappt einen Dokumentbereich auf/zu (lokaler State, kein Package). Geschlossen
// bleiben Titel, Anzahl und ein optionaler Hinweis auf veröffentlichte/interne
// Dokumente sichtbar. Barrierearm: Button mit aria-expanded und klarer
// Beschriftung „Aufklappen"/„Zuklappen".
// Aufschlüsselung je Sichtbarkeitsstufe. Vorher fasste die Zeile alles
// Nicht-Öffentliche als „intern" zusammen — das verschweigt seit dem
// Vier-Stufen-Modell den Unterschied zwischen „Vertraulich", „Intern" und
// „Mitglieder", und „intern" ist zugleich die Bezeichnung genau einer dieser
// Stufen. Die Beschriftung kommt deshalb aus SMS_DOCUMENT_VISIBILITY_LABELS.
//
// Reihenfolge von offen nach geschlossen: Wie viel öffentlich steht, ist die
// Angabe mit den größten Folgen und gehört nach vorn.
function sectionSummary(
  count: number,
  visibilityCounts?: Partial<Record<SmsDocumentVisibility, number>>
): string {
  if (count === 0) return "Keine Dokumente"
  const noun = count === 1 ? "Dokument" : "Dokumente"
  if (!visibilityCounts) return `${count} ${noun}`

  const parts = [...SMS_DOCUMENT_VISIBILITY_VALUES]
    .reverse()
    .flatMap((visibility) => {
      const n = visibilityCounts[visibility] ?? 0
      return n > 0 ? [`${n} ${SMS_DOCUMENT_VISIBILITY_LABELS[visibility]}`] : []
    })

  return parts.length > 0
    ? `${count} ${noun} · ${parts.join(", ")}`
    : `${count} ${noun}`
}

export function CollapsibleDocumentSection({
  title,
  description,
  count,
  visibilityCounts,
  summary,
  defaultOpen,
  children,
}: {
  title: string
  // Optional: die öffentliche Seite gruppiert nach Kategorie ohne eigene
  // Bereichsbeschreibung.
  description?: string
  count: number
  // Optional: Ohne Angabe zeigt die Zeile nur die Anzahl. Die öffentliche
  // Seite nutzt das — dort sagt eine Aufschlüsselung nichts, was die
  // Kennzeichnung am einzelnen Dokument nicht schon sagt.
  visibilityCounts?: Partial<Record<SmsDocumentVisibility, number>>
  // Optional: ersetzt die Zusammenfassungszeile vollstaendig. sectionSummary
  // zaehlt in „Dokumenten"; die Box mit den oeffentlichen Statusrueckmeldungen
  // zaehlt etwas anderes und bringt ihre eigene Formulierung mit.
  summary?: string
  defaultOpen: boolean
  children: React.ReactNode
}) {
  const [open, setOpen] = useState(defaultOpen)

  return (
    <div className="flex flex-col gap-4 overflow-hidden rounded-xl bg-card py-4 text-sm text-card-foreground ring-1 ring-foreground/10">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="flex w-full items-start justify-between gap-4 px-4 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        <span className="min-w-0">
          <span className="block font-heading text-base font-medium leading-snug">
            {title}
          </span>
          <span className="mt-1 block text-sm text-muted-foreground">
            {summary ?? sectionSummary(count, visibilityCounts)}
          </span>
        </span>
        <span className="flex shrink-0 items-center gap-1.5 text-sm text-muted-foreground">
          <span>{open ? "Zuklappen" : "Aufklappen"}</span>
          <svg
            aria-hidden="true"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className={`h-4 w-4 transition-transform ${open ? "rotate-180" : ""}`}
          >
            <path d="m6 9 6 6 6-6" />
          </svg>
        </span>
      </button>

      {open ? (
        <div className="space-y-4 border-t px-4 pt-4">
          {description ? (
            <p className="text-sm text-muted-foreground">{description}</p>
          ) : null}
          {children}
        </div>
      ) : null}
    </div>
  )
}

// ─── Anzeigen (aufklappbar) ──────────────────────────────────────────────────
// Der Inhalt wird nicht automatisch angezeigt. Über „Anzeigen" wird er per
// lokalem Zustand ein-/ausgeklappt. Optionale Aktions-Schaltflächen (z. B.
// Bearbeiten, Löschen, Drucken im internen Bereich) werden als children in
// dieselbe Zeile gereicht; auf der öffentlichen Seite bleibt nur „Anzeigen"
// (children = null). Die Zeile ist flex-wrap: Schaltflächen umbrechen bei wenig
// Platz; ein Kind, das eine eigene Zeile braucht (z. B. das geöffnete
// Bearbeitungsformular), setzt dafür selbst `order-last basis-full`.
export function DocumentView({
  title,
  content,
  children,
}: {
  title: string
  content: string
  children?: React.ReactNode
}) {
  const [open, setOpen] = useState(false)

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <Button
          type="button"
          variant="outline"
          size="sm"
          aria-expanded={open}
          aria-label={`${open ? "Verbergen" : "Anzeigen"}: ${title}`}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? "Verbergen" : "Anzeigen"}
        </Button>
        {children}
      </div>

      {open ? (
        <div className="rounded-md border bg-muted/40 p-4">
          <DocumentMarkdownView content={content} />
        </div>
      ) : null}
    </div>
  )
}
