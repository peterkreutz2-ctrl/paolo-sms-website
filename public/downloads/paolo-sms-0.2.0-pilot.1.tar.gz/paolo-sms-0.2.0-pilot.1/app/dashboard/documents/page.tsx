import { appAuth } from "@/lib/auth"
import { and, desc, eq, inArray } from "drizzle-orm"
import { notFound, redirect } from "next/navigation"

import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { hasDocumentReadRole, hasSafetyEditRole } from "@/lib/constants/roles"
import { db } from "@/lib/db"
import { attachments, organizations, smsDocuments } from "@/lib/db/schema"
import {
  getReadableVisibilityDbValues,
  normalizeVisibility,
  SMS_DOCUMENT_CATEGORY_LABELS,
  SMS_DOCUMENT_SECTIONS,
  SMS_DOCUMENT_VISIBILITY_LABELS,
  type SmsDocumentCategory,
  type SmsDocumentVisibility,
} from "@/lib/constants/sms-documents"

import { Badge } from "@/components/ui/badge"
import { buttonVariants } from "@/components/ui/button"
import { PageHeader } from "@/components/ui/page-header"

import { DocumentAttachmentsSection } from "./document-attachments"
import {
  CollapsibleDocumentSection,
  DocumentView,
} from "./document-collapsibles"
import {
  CreateDocumentForm,
  DocumentDeleteForm,
  DocumentEditForm,
} from "./document-forms"

const dtFormatter = new Intl.DateTimeFormat("de-DE", { dateStyle: "medium" })

function categoryLabel(v: string): string {
  return SMS_DOCUMENT_CATEGORY_LABELS[v as SmsDocumentCategory] ?? v
}
function visibilityLabel(v: string): string {
  return SMS_DOCUMENT_VISIBILITY_LABELS[normalizeVisibility(v)]
}

// Badge-Darstellung je Stufe. „Öffentlich" bleibt optisch am stärksten, weil
// es die einzige anmeldefrei sichtbare Stufe ist; die Unterscheidung zwischen
// „Mitglieder" und „Intern" trägt der Text.
const VISIBILITY_BADGE_VARIANT: Record<
  SmsDocumentVisibility,
  "default" | "secondary" | "outline"
> = {
  public: "default",
  members: "secondary",
  staff: "secondary",
  confidential: "outline",
}

type DocumentRow = typeof smsDocuments.$inferSelect
type AttachmentRow = typeof attachments.$inferSelect

export default async function DocumentsPage() {
  const { userId } = await appAuth()
  if (!userId) redirect("/sign-in")

  const roleKeys = await getCurrentUserRoles()
  if (!hasDocumentReadRole(roleKeys)) notFound()

  const canEdit = hasSafetyEditRole(roleKeys)

  const [organization] = await db.select().from(organizations).limit(1)
  if (!organization) notFound()

  // Leselogik ausschließlich über die eine Regel in
  // lib/constants/sms-documents.ts. `null` heißt „keine Einschränkung" und
  // gilt für admin/safety_manager — nur so bleibt auch ein unbekannter
  // Sichtbarkeitswert sichtbar, der laut normalizeVisibility als
  // 'confidential' gilt und damit in diesen Lesekreis gehört.
  // TODO Cleanup nach 0023: 'published' aus
  // SMS_DOCUMENT_STAFF_VISIBLE_DB_VALUES entfernen.
  const readableDbValues = getReadableVisibilityDbValues(roleKeys)
  const documents = await db
    .select()
    .from(smsDocuments)
    .where(
      readableDbValues === null
        ? eq(smsDocuments.organizationId, organization.id)
        : and(
            eq(smsDocuments.organizationId, organization.id),
            inArray(smsDocuments.visibility, [...readableDbValues])
          )
    )
    .orderBy(desc(smsDocuments.updatedAt))

  const byCategory = new Map<string, DocumentRow[]>()
  for (const doc of documents) {
    const list = byCategory.get(doc.category) ?? []
    list.push(doc)
    byCategory.set(doc.category, list)
  }

  // Anhaenge nur fuer Bearbeitungsberechtigte laden: nur sie duerfen sie
  // verwalten und herunterladen (siehe Download-Route). Ein Query fuer alle
  // sichtbaren Dokumente statt eines Queries je Dokument.
  const attachmentsByDocument = new Map<string, AttachmentRow[]>()
  if (canEdit && documents.length > 0) {
    const attachmentRows = await db
      .select()
      .from(attachments)
      .where(
        inArray(
          attachments.smsDocumentId,
          documents.map((doc) => doc.id)
        )
      )
      .orderBy(desc(attachments.createdAt))

    for (const row of attachmentRows) {
      if (!row.smsDocumentId) continue
      const list = attachmentsByDocument.get(row.smsDocumentId) ?? []
      list.push(row)
      attachmentsByDocument.set(row.smsDocumentId, list)
    }
  }

  return (
    <main className="mx-auto max-w-4xl space-y-8 px-4 py-8 sm:px-8">
      <PageHeader title="Dokumente" />

      {/* Dezenter Hinweis: der Editor bleibt bewusst reines Markdown (kein
          WYSIWYG). Für komfortablere Formatierung können externe Werkzeuge
          genutzt werden; es findet KEINE automatische Datenübertragung an diese
          Dienste statt (nur externe Links, keine Integration). */}
      <p className="text-xs leading-relaxed text-muted-foreground">
        Aus Sicherheitsgründen lassen sich die SMS-Dokumente hier nur als
        Markdown-Text bearbeiten. Für eine komfortablere Vorbereitung und
        Formatierung können externe Werkzeuge wie{" "}
        <a
          href="https://word2md.com/"
          target="_blank"
          rel="noopener noreferrer"
          className="font-medium text-sky-700 underline underline-offset-2 hover:text-sky-900 dark:text-sky-400 dark:hover:text-sky-300"
        >
          Word2MD&#8202;&#8599;
        </a>{" "}
        oder{" "}
        <a
          href="https://stackedit.io/app"
          target="_blank"
          rel="noopener noreferrer"
          className="font-medium text-sky-700 underline underline-offset-2 hover:text-sky-900 dark:text-sky-400 dark:hover:text-sky-300"
        >
          StackEdit&#8202;&#8599;
        </a>{" "}
        verwendet werden. Der fertige Markdown-Text kann anschließend in das
        Inhaltsfeld übernommen werden. Bitte keine personenbezogenen oder
        vertraulichen Inhalte in externe Werkzeuge eingeben.
      </p>

      {!canEdit ? (
        <div
          className="rounded-r-lg border-l-2 border-sky-500 bg-sky-50 px-4 py-3 text-sm leading-relaxed text-sky-800 dark:bg-sky-950/30 dark:text-sky-300"
          role="note"
        >
          Sie sehen hier Dokumente der Stufen „Intern“, „Angemeldete
          Personen“ und „Öffentlich“ — keine vertraulichen. Die Bearbeitung liegt bei
          Administrator und Safety Manager.
        </div>
      ) : null}

      {SMS_DOCUMENT_SECTIONS.map((section) => {
        const sectionDocs = section.categories.flatMap(
          (c) => byCategory.get(c) ?? []
        )
        const visibilityCounts = sectionDocs.reduce<
          Partial<Record<SmsDocumentVisibility, number>>
        >((acc, doc) => {
          const level = normalizeVisibility(doc.visibility)
          acc[level] = (acc[level] ?? 0) + 1
          return acc
        }, {})

        return (
          <section key={section.key} aria-label={section.title}>
            {/* Alle Bereiche starten zugeklappt; erst über „Aufklappen" wird der
                jeweilige Bereich geöffnet. */}
            <CollapsibleDocumentSection
              title={section.title}
              description={section.description}
              count={sectionDocs.length}
              visibilityCounts={visibilityCounts}
              defaultOpen={false}
            >
              {sectionDocs.length === 0 ? (
                  <p className="rounded-lg border border-dashed px-4 py-6 text-center text-sm text-muted-foreground">
                    {canEdit
                      ? "Noch keine Dokumente in diesem Bereich."
                      : "Keine veröffentlichten Dokumente in diesem Bereich."}
                  </p>
                ) : (
                  sectionDocs.map((doc) => (
                    <div
                      key={doc.id}
                      className="space-y-3 rounded-md border p-4"
                    >
                      <div className="flex flex-wrap items-start justify-between gap-2">
                        <p className="font-medium text-foreground">
                          {doc.title}
                        </p>
                        <div className="flex flex-wrap gap-1.5">
                          <Badge variant="secondary" className="font-normal">
                            {categoryLabel(doc.category)}
                          </Badge>
                          <Badge
                            variant={
                              VISIBILITY_BADGE_VARIANT[
                                normalizeVisibility(doc.visibility)
                              ]
                            }
                            className="font-normal"
                          >
                            {visibilityLabel(doc.visibility)}
                          </Badge>
                        </div>
                      </div>

                      <p className="text-xs text-muted-foreground">
                        Aktualisiert am {dtFormatter.format(doc.updatedAt)}
                      </p>

                      {/* Inhalt wird nicht mehr automatisch angezeigt, sondern
                          erst über „Anzeigen" aufgeklappt. Bearbeiten/Löschen
                          stehen für Berechtigte in derselben Aktionszeile. */}
                      <DocumentView title={doc.title} content={doc.content}>
                        <a
                          href={`/documents/${doc.id}/print`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className={buttonVariants({
                            variant: "outline",
                            size: "sm",
                          })}
                        >
                          Drucken
                        </a>
                        {canEdit ? (
                          <>
                            <DocumentEditForm
                              documentId={doc.id}
                              category={doc.category as SmsDocumentCategory}
                              title={doc.title}
                              content={doc.content}
                              visibility={normalizeVisibility(doc.visibility)}
                              categories={section.categories}
                            />
                            <DocumentDeleteForm
                              documentId={doc.id}
                              title={doc.title}
                            />
                          </>
                        ) : null}
                      </DocumentView>

                      {/* Anhaenge stehen bewusst unter dem Inhalt und nicht in
                          der Aktionszeile: sie sind eigener Inhalt des
                          Dokuments, keine Aktion darauf. Nur fuer
                          Bearbeitungsberechtigte. */}
                      {canEdit ? (
                        <DocumentAttachmentsSection
                          documentId={doc.id}
                          documentTitle={doc.title}
                          documentVisibility={normalizeVisibility(
                            doc.visibility
                          )}
                          attachments={attachmentsByDocument.get(doc.id) ?? []}
                        />
                      ) : null}
                    </div>
                  ))
                )}

                {canEdit ? (
                  <CreateDocumentForm categories={section.categories} />
                ) : null}
            </CollapsibleDocumentSection>
          </section>
        )
      })}
    </main>
  )
}
