"use client"

import { useActionState } from "react"

import { updateAccountData, type UserRoleActionState } from "@/lib/actions/user-roles"
import { Button } from "@/components/ui/button"

const initialState: UserRoleActionState = { success: false, message: "" }

type Props = {
  clerkUserId: string
  currentName: string
  currentEmail: string
  // Better Auth: ja. Clerk: Die E-Mail-Adresse bleibt dem Benutzerprofil des
  // Anbieters vorbehalten (siehe updateAccountData).
  emailEditable: boolean
}

const inputClass = "w-full rounded-md border bg-background px-2 py-1 text-sm"

export function EditAccountForm({ clerkUserId, currentName, currentEmail, emailEditable }: Props) {
  const [state, formAction, isPending] = useActionState(updateAccountData, initialState)

  return (
    <details className="text-sm">
      <summary className="cursor-pointer underline-offset-4 hover:underline">Kontodaten ändern</summary>
      {/* key: Nach dem Speichern zeigt das Formular die neu geladenen Werte. */}
      <form
        key={`${currentName}|${currentEmail}`}
        action={formAction}
        className="mt-2 max-w-md space-y-2 rounded-md border p-3"
      >
        <input type="hidden" name="clerkUserId" value={clerkUserId} />
        <div className="space-y-1">
          <label htmlFor={`name-${clerkUserId}`} className="text-xs font-medium">Name</label>
          <input
            id={`name-${clerkUserId}`}
            name="name"
            defaultValue={currentName}
            maxLength={120}
            required
            className={inputClass}
          />
        </div>
        {emailEditable ? (
          <div className="space-y-1">
            <label htmlFor={`email-${clerkUserId}`} className="text-xs font-medium">E-Mail-Adresse</label>
            <input
              id={`email-${clerkUserId}`}
              name="email"
              type="email"
              defaultValue={currentEmail}
              required
              className={inputClass}
            />
            <p className="text-xs text-muted-foreground">
              Die Person meldet sich danach mit der neuen Adresse an. Eine Benachrichtigung
              wird nicht verschickt.
            </p>
          </div>
        ) : (
          <p className="text-xs text-muted-foreground">
            Die E-Mail-Adresse ändert die Person selbst im Benutzerprofil des Anmeldedienstes.
          </p>
        )}
        <div className="flex flex-wrap items-center gap-2">
          <Button type="submit" size="sm" disabled={isPending}>
            {isPending ? "Wird gespeichert…" : "Speichern"}
          </Button>
          {state.message ? (
            <p className={`text-xs ${state.success ? "text-emerald-600" : "text-destructive"}`}>
              {state.message}
            </p>
          ) : null}
        </div>
      </form>
    </details>
  )
}
