"use client"

import { useActionState } from "react"

import { removeRole, type UserRoleActionState } from "@/lib/actions/user-roles"

const initialState: UserRoleActionState = { success: false, message: "" }

type Props = {
  userRoleId: string
}

export function RemoveRoleButton({ userRoleId }: Props) {
  const [state, formAction, isPending] = useActionState(removeRole, initialState)

  return (
    <form action={formAction} className="flex flex-col items-end gap-1">
      <input type="hidden" name="userRoleId" value={userRoleId} />
      <button
        type="submit"
        disabled={isPending}
        className="text-sm text-destructive underline-offset-4 hover:underline disabled:opacity-50"
      >
        {isPending ? "Wird entfernt…" : "Entfernen"}
      </button>
      {state.message && !state.success ? (
        <p className="text-xs text-destructive">{state.message}</p>
      ) : null}
    </form>
  )
}
