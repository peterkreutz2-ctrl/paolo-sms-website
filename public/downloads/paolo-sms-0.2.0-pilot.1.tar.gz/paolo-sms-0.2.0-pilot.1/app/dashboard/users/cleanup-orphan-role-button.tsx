"use client"

import { useActionState } from "react"

import { removeOrphanedRole, type UserRoleActionState } from "@/lib/actions/user-roles"
import { Button } from "@/components/ui/button"

const initialState: UserRoleActionState = { success: false, message: "" }

type Props = {
  userRoleId: string
}

export function CleanupOrphanRoleButton({ userRoleId }: Props) {
  const [state, formAction, isPending] = useActionState(removeOrphanedRole, initialState)

  return (
    <form action={formAction} className="flex flex-wrap items-center gap-2">
      <input type="hidden" name="userRoleId" value={userRoleId} />
      <Button type="submit" size="sm" variant="outline" disabled={isPending}>
        {isPending ? "Wird bereinigt…" : "Rolle bereinigen"}
      </Button>
      {state.message && !state.success ? (
        <p className="text-xs text-destructive">{state.message}</p>
      ) : null}
    </form>
  )
}
