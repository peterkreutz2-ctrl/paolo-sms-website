"use client"

import { useActionState } from "react"

import { createUserWithRole, type UserRoleActionState } from "@/lib/actions/user-roles"
import { type AppRoleKey, ROLE_LABELS } from "@/lib/constants/roles"
import { Button } from "@/components/ui/button"

import { AccessLinkNotice } from "./access-link-notice"

type Props = {
  assignableRoles: AppRoleKey[]
  betterAuth: boolean
}

const initialState: UserRoleActionState = { success: false, message: "" }

export function CreateUserForm({ assignableRoles, betterAuth }: Props) {
  const [state, formAction, isPending] = useActionState(
    createUserWithRole,
    initialState
  )

  return (
    <form action={formAction} className="space-y-4">
      <div className="space-y-2">
        <label htmlFor="newUserEmail" className="text-sm font-medium">
          E-Mail-Adresse
        </label>
        <input
          id="newUserEmail"
          name="email"
          type="email"
          required
          placeholder="benutzer@beispiel.de"
          className="w-full rounded-md border bg-background px-3 py-2 text-sm"
        />
      </div>

      {betterAuth ? (
        <>
          <div className="space-y-2"><label htmlFor="newUserName" className="text-sm font-medium">Name</label><input id="newUserName" name="name" required className="w-full rounded-md border bg-background px-3 py-2 text-sm" /></div>
          <div className="space-y-2"><label htmlFor="newUserPassword" className="text-sm font-medium">Passwort</label><input id="newUserPassword" name="password" type="password" minLength={8} autoComplete="new-password" required className="w-full rounded-md border bg-background px-3 py-2 text-sm" /><p className="text-xs text-muted-foreground">Mindestens 8 Zeichen.</p></div>
        </>
      ) : null}

      <div className="space-y-2">
        <label htmlFor="newUserRoleKey" className="text-sm font-medium">
          Rolle
        </label>
        <select
          id="newUserRoleKey"
          name="roleKey"
          required
          className="w-full rounded-md border bg-background px-3 py-2 text-sm"
        >
          {assignableRoles.map((key) => (
            <option key={key} value={key}>
              {ROLE_LABELS[key]}
            </option>
          ))}
        </select>
      </div>

      <div className="flex items-center gap-3">
        <Button type="submit" disabled={isPending}>
          {isPending ? "Wird angelegt…" : "Benutzer anlegen"}
        </Button>

        {state.message ? (
          <p
            className={`text-sm ${state.success ? "text-emerald-600" : "text-destructive"}`}
          >
            {state.message}
          </p>
        ) : null}
      </div>

      {state.signInUrl ? (
        <AccessLinkNotice url={state.signInUrl} kind={state.linkKind ?? "sign-in"} />
      ) : null}
    </form>
  )
}
