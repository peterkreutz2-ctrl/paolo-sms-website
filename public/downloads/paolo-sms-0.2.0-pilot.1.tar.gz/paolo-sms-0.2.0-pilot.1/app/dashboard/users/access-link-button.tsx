"use client"

import { useActionState } from "react"

import { issueAccessLink, type UserRoleActionState } from "@/lib/actions/user-roles"
import { Button } from "@/components/ui/button"

import { AccessLinkNotice } from "./access-link-notice"

const initialState: UserRoleActionState = { success: false, message: "" }

type Props = {
  clerkUserId: string
}

export function AccessLinkButton({ clerkUserId }: Props) {
  const [state, formAction, isPending] = useActionState(issueAccessLink, initialState)

  return (
    <form action={formAction} className="flex flex-col items-start gap-2">
      <input type="hidden" name="clerkUserId" value={clerkUserId} />
      <Button type="submit" size="sm" variant="outline" disabled={isPending}>
        {isPending ? "Wird erstellt…" : "Anmeldelink erneuern"}
      </Button>
      {state.message && !state.success ? (
        <p className="text-xs text-destructive">{state.message}</p>
      ) : null}
      {state.success && state.signInUrl ? (
        <AccessLinkNotice url={state.signInUrl} kind={state.linkKind ?? "sign-in"} />
      ) : null}
    </form>
  )
}
