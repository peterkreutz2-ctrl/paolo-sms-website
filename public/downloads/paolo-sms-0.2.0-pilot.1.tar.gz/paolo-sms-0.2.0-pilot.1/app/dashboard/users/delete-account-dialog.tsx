"use client"

import { useActionState, useState } from "react"

import { deleteAccount, type UserRoleActionState } from "@/lib/actions/user-roles"
import { emailsMatch } from "@/lib/auth/account-lifecycle"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

const initialState: UserRoleActionState = { success: false, message: "" }

type Props = {
  clerkUserId: string
  displayName: string
  email: string
}

// Endgültige Löschung (#114). Die Bestätigung verlangt die vollständige E-Mail-
// Adresse des Kontos; der Server prüft sie erneut. Das ist die Sicherung gegen
// einen Fehlgriff, besonders bei einer Clerk-Instanz, die mehrere Umgebungen teilen.
export function DeleteAccountDialog({ clerkUserId, displayName, email }: Props) {
  const [open, setOpen] = useState(false)
  const [typed, setTyped] = useState("")
  const [state, formAction, isPending] = useActionState(deleteAccount, initialState)
  const confirmed = emailsMatch(typed, email)

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        setOpen(next)
        if (!next) setTyped("")
      }}
    >
      <DialogTrigger asChild>
        <Button type="button" size="sm" variant="destructive">
          Konto löschen
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Konto endgültig löschen?</DialogTitle>
          <DialogDescription>
            Das Konto von {displayName} ({email}) wird beim Anmeldedienst gelöscht, ebenso seine
            Sitzungen und seine Rolle. Meldungen, Notizen, Besprechungen und Audit-Einträge
            bleiben unverändert und zeigen danach nur noch eine gekürzte Kennung. Das lässt sich
            nicht rückgängig machen.
          </DialogDescription>
        </DialogHeader>
        <form action={formAction} className="space-y-3">
          <input type="hidden" name="clerkUserId" value={clerkUserId} />
          <div className="space-y-1">
            <label htmlFor={`confirm-${clerkUserId}`} className="text-sm font-medium">
              Zur Bestätigung die vollständige E-Mail-Adresse eingeben
            </label>
            <input
              id={`confirm-${clerkUserId}`}
              name="confirmEmail"
              value={typed}
              onChange={(event) => setTyped(event.target.value)}
              autoComplete="off"
              spellCheck={false}
              className="w-full rounded-md border bg-background px-3 py-2 text-sm"
            />
          </div>
          {state.message && !state.success ? (
            <p role="alert" className="text-sm text-destructive">{state.message}</p>
          ) : null}
          <DialogFooter>
            <DialogClose asChild>
              <Button type="button" variant="outline">Abbrechen</Button>
            </DialogClose>
            <Button type="submit" variant="destructive" disabled={!confirmed || isPending}>
              {isPending ? "Wird gelöscht…" : "Endgültig löschen"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
