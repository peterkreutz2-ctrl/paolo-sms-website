import type { UserRoleActionState } from "@/lib/actions/user-roles"

type Props = {
  url: string
  kind: NonNullable<UserRoleActionState["linkKind"]>
}

// Der Link erscheint genau hier, in der Antwort der Aktion — er wird nirgends
// gespeichert, geloggt oder auditiert (#111). Wer die Seite verlaesst, muss einen
// neuen Link erzeugen.
export function AccessLinkNotice({ url, kind }: Props) {
  const isPassword = kind === "password"

  return (
    <div className="space-y-2 rounded-md border border-amber-200 bg-amber-50 p-4 text-sm dark:border-amber-800 dark:bg-amber-950">
      <p className="font-medium text-amber-800 dark:text-amber-200">
        {isPassword
          ? "Link zum Festlegen eines Passworts (gültig 7 Tage, einmal verwendbar)"
          : "Einmaliger Anmeldelink (gültig 7 Tage)"}
      </p>
      <input
        readOnly
        value={url}
        aria-label={isPassword ? "Link zum Festlegen eines Passworts" : "Anmeldelink"}
        onClick={(e) => (e.target as HTMLInputElement).select()}
        className="w-full rounded border bg-background px-2 py-1 font-mono text-xs"
      />
      <p className="text-amber-700 dark:text-amber-300">
        Diesen Link nur an die betreffende Person weitergeben und hier nicht
        erneut anzeigen lassen können: Er erlaubt den Zugriff auf das Konto.
        Ältere Links für dieses Konto bleiben bis zu ihrem Ablauf gültig.
      </p>
    </div>
  )
}
