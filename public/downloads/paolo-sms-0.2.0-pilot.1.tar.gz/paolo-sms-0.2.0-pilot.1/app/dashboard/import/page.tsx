import { appAuth } from "@/lib/auth"
import { notFound, redirect } from "next/navigation"

import { getCurrentUserRoles } from "@/lib/auth/user-roles"

import { ImportForm } from "./import-form"
import { hasAdminRole } from "@/lib/constants/roles"

export default async function ImportPage() {
  const { userId } = await appAuth()
  if (!userId) redirect("/sign-in")

  const roleKeys = await getCurrentUserRoles()
  if (!hasAdminRole(roleKeys)) notFound()

  return (
    <main className="mx-auto max-w-2xl space-y-8 p-8">
      <div>
        <h1 className="text-2xl font-semibold">Report-Import</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          CSV-Datei im PAOLO-Exportformat importieren. Nur für Administratoren. Daten vor dem Import prüfen — ein Import ersetzt keine fachliche Sichtung durch den Safety Manager.
        </p>
      </div>

      <ImportForm />
    </main>
  )
}
