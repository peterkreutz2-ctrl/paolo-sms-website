"use client"

import { useActionState } from "react"

import {
  importReports,
  type ImportReportsState,
} from "@/lib/actions/import-reports"
import { Button } from "@/components/ui/button"
import { UploadSafetyNotice } from "@/components/upload-safety-notice"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"

const initialState: ImportReportsState = {
  success: false,
  message: "",
}

const MAX_ERRORS_SHOWN = 20

export function ImportForm() {
  const [state, formAction, isPending] = useActionState(importReports, initialState)

  return (
    <Card>
      <CardHeader>
        <CardTitle>CSV-Datei importieren</CardTitle>
        <CardDescription>
          Kompatibel mit dem PAOLO-Exportformat (Semikolon, UTF-8 mit BOM, alle Felder gequotet).
          Jede gültige Zeile wird als neue Meldung mit einer neuen PAOLO-ID angelegt.
          Anhänge und Maßnahmen werden nicht importiert.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <form action={formAction} className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="import-file" className="text-sm font-medium">
              CSV-Datei
            </label>
            <Input
              id="import-file"
              name="file"
              type="file"
              accept=".csv,text/csv"
              required
            />
            <p className="text-xs text-muted-foreground">
              Erlaubte Felder: reportType, status, priority, shortDescription,
              detailedDescription, isAnonymous. Status &quot;hidden&quot; wird abgelehnt.
            </p>
            <UploadSafetyNotice />
          </div>

          <Button type="submit" disabled={isPending}>
            {isPending ? "Importiert…" : "Importieren"}
          </Button>
        </form>

        {state.message && (
          <div
            className={`rounded-lg border p-4 ${
              state.success
                ? "border-emerald-200 bg-emerald-50 dark:border-emerald-800 dark:bg-emerald-950/30"
                : "border-destructive/30 bg-destructive/5"
            }`}
          >
            <p
              className={`text-sm font-medium ${
                state.success
                  ? "text-emerald-700 dark:text-emerald-400"
                  : "text-destructive"
              }`}
            >
              {state.message}
            </p>

            {state.total !== undefined && (
              <dl className="mt-3 grid grid-cols-3 gap-4 text-sm">
                <div>
                  <dt className="text-xs text-muted-foreground">Eingelesen</dt>
                  <dd className="font-medium">{state.total}</dd>
                </div>
                <div>
                  <dt className="text-xs text-muted-foreground">Eingefügt</dt>
                  <dd className="font-medium">{state.inserted ?? 0}</dd>
                </div>
                <div>
                  <dt className="text-xs text-muted-foreground">Übersprungen</dt>
                  <dd className="font-medium">{state.skipped ?? 0}</dd>
                </div>
              </dl>
            )}

            {state.errors && state.errors.length > 0 && (
              <div className="mt-4">
                <p className="text-xs font-medium text-muted-foreground">
                  Fehler ({state.errors.length}):
                </p>
                <ul className="mt-1 space-y-0.5">
                  {state.errors.slice(0, MAX_ERRORS_SHOWN).map((e, i) => (
                    <li key={i} className="text-xs text-muted-foreground">
                      Zeile {e.line}: {e.message}
                    </li>
                  ))}
                  {state.errors.length > MAX_ERRORS_SHOWN && (
                    <li className="text-xs text-muted-foreground">
                      … und {state.errors.length - MAX_ERRORS_SHOWN} weitere Fehler
                    </li>
                  )}
                </ul>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
