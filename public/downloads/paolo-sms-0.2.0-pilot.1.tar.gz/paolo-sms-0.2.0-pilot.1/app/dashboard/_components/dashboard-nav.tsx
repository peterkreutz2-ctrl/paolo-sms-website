"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"

import { cn } from "@/lib/utils"

// Jeder Eintrag wird an die Leseberechtigung seines Ziels gebunden. Vorher
// standen „Übersicht", „Meldungen" und „Maßnahmen" fuer jedes angemeldete
// Konto — auch fuer `member`, fuer den alle drei auf die Kein-Zugriff-Seite
// fuehren. Das war kein Sicherheitsproblem (die Guards sitzen serverseitig),
// aber drei tote Links als erster Eindruck nach der Anmeldung.
const overviewLink = { href: "/dashboard", label: "Übersicht", exact: true }
const reportsLink = { href: "/dashboard/reports", label: "Meldungen", exact: false }
const measuresLink = { href: "/dashboard/measures", label: "Maßnahmen", exact: false }
const documentsLink = { href: "/dashboard/documents", label: "Dokumente", exact: false }
const adminLink = { href: "/dashboard/admin", label: "Administration", exact: false }
// Die Hilfe steht bewusst ganz rechts: Sie ist der seltenste Weg und soll die
// Arbeitswege nicht verdraengen.
const helpLink = { href: "/dashboard/hilfe", label: "Hilfe", exact: false }

type Props = {
  showReports?: boolean
  showMeasures?: boolean
  showDocuments?: boolean
  showAdmin?: boolean
  showHelp?: boolean
  className?: string
}

export function DashboardNav({
  showReports = false,
  showMeasures = false,
  showDocuments = false,
  showAdmin = false,
  showHelp = false,
  className,
}: Props) {
  const pathname = usePathname()

  const navLinks = [
    ...(showReports ? [overviewLink, reportsLink] : []),
    ...(showMeasures ? [measuresLink] : []),
    ...(showDocuments ? [documentsLink] : []),
    ...(showAdmin ? [adminLink] : []),
    ...(showHelp ? [helpLink] : []),
  ]

  if (navLinks.length === 0) return null

  return (
    <nav
      aria-label="Dashboard-Hauptnavigation"
      className={cn("flex flex-wrap items-center gap-0.5 text-sm", className)}
    >
      {navLinks.map(({ href, label, exact }) => {
        const isActive = exact
          ? pathname === href
          : pathname.startsWith(href)
        return (
          <Link
            key={href}
            href={href}
            className={cn(
              "rounded-md px-3 py-1.5 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
              isActive
                ? "bg-muted font-medium text-foreground"
                : "text-muted-foreground hover:bg-muted/60 hover:text-foreground"
            )}
          >
            {label}
          </Link>
        )
      })}
    </nav>
  )
}
