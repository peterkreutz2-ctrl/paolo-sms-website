"use client"

import { useActionState, useEffect } from "react"
import { useRouter } from "next/navigation"

import {
  createSafetyMeeting,
  type SafetyMeetingActionState,
} from "@/lib/actions/safety-meetings"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

const initialState: SafetyMeetingActionState = { success: false, message: "" }

export function SafetyMeetingForm() {
  const router = useRouter()
  const [state, formAction, isPending] = useActionState(createSafetyMeeting, initialState)

  useEffect(() => {
    if (state.success) router.refresh()
  }, [state, router])

  return (
    <div className="space-y-3 border-t pt-4">
      <p className="text-sm font-semibold text-foreground">Sicherheitsbesprechung eintragen</p>
      <form action={formAction} className="space-y-3">
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1.5">
            <label htmlFor="sm-meetingDate" className="text-sm font-medium">
              Datum <span className="text-destructive">*</span>
            </label>
            <Input id="sm-meetingDate" name="meetingDate" type="date" required />
          </div>
          <div className="space-y-1.5">
            <label htmlFor="sm-title" className="text-sm font-medium">
              Titel (optional)
            </label>
            <Input
              id="sm-title"
              name="title"
              maxLength={200}
              placeholder="z. B. Jahresbesprechung 2026"
            />
          </div>
        </div>
        <div className="space-y-1.5">
          <label htmlFor="sm-notes" className="text-sm font-medium">
            Notiz (optional)
          </label>
          <Textarea
            id="sm-notes"
            name="notes"
            rows={3}
            placeholder="Kurze Notiz zur Besprechung"
          />
        </div>
        <div className="flex items-center gap-3">
          <Button type="submit" disabled={isPending}>
            {isPending ? "Speichert..." : "Sicherheitsbesprechung eintragen"}
          </Button>
          {state.message ? (
            <p className={`text-sm ${state.success ? "text-emerald-600" : "text-destructive"}`}>
              {state.message}
            </p>
          ) : null}
        </div>
      </form>
    </div>
  )
}