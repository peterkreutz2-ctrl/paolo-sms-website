import { appCurrentUser, usesBetterAuth, usesFileAuth } from "@/lib/auth"
import { AuthUserButton } from "@/lib/auth/auth-user-button"

import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { ROLE_LABELS } from "@/lib/constants/roles"
import { cn } from "@/lib/utils"

export async function UserNav({ className }: { className?: string } = {}) {
  const [user, roleKeys] = await Promise.all([
    appCurrentUser(),
    getCurrentUserRoles(),
  ])

  if (!user) return null

  const displayName =
    [user.firstName, user.lastName].filter(Boolean).join(" ").trim() ||
    user.emailAddresses[0]?.emailAddress ||
    "Angemeldet"

  const roleLabel =
    roleKeys.length > 0
      ? roleKeys.map((k) => ROLE_LABELS[k]).join(", ")
      : "Keine Rollen"

  return (
    <div className={cn("flex items-center gap-4", className)}>
      {/* Unter sm nur für Screenreader: Name und Rolle würden dem
          Organisationsnamen in der ersten Kopfzeile den Platz nehmen (#119). */}
      <div className="sr-only text-right text-sm leading-tight sm:not-sr-only">
        <p className="font-medium text-foreground">{displayName}</p>
        <p className="text-xs text-muted-foreground">{roleLabel}</p>
      </div>
      <AuthUserButton fileAuth={usesFileAuth()} betterAuth={usesBetterAuth()} />
    </div>
  )
}
