import Image from "next/image"
import Link from "next/link"
import { redirect } from "next/navigation"

import { appAuth } from "@/lib/auth"
import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { getOrganizationDisplayName } from "@/lib/queries/organization-display-name"
import { OrganizationNameTag } from "@/components/organization-name-tag"
import {
  hasDocumentReadRole,
  hasMeasureReadRole,
  hasReportReadRole,
  hasSafetyEditRole,
} from "@/lib/constants/roles"

import { DashboardNav } from "./_components/dashboard-nav"
import { UserNav } from "./_components/user-nav"

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { userId } = await appAuth()
  if (!userId) redirect("/sign-in")

  const roleKeys = await getCurrentUserRoles()
  const showAdmin = hasSafetyEditRole(roleKeys)
  const showDocuments = hasDocumentReadRole(roleKeys)
  const showReports = hasReportReadRole(roleKeys)
  const showMeasures = hasMeasureReadRole(roleKeys)
  // Die Hilfe folgt der Schwelle des internen Bereichs.
  const showHelp = hasReportReadRole(roleKeys)
  const organizationName = await getOrganizationDisplayName()

  return (
    <div className="min-h-screen">
      <nav className="border-b bg-card px-4 sm:px-8">
        {/*
          Unter xl (1280 px) zwei Zeilen: Logo, Organisationsname und Konto in
          der ersten, die umbrechende Navigation darunter (#119). Gemessen
          (Administrator): Die Navigation ist 577 px breit; Logo, Navigation
          und Konto passen erst ab 1024 px in eine Zeile, darunter lief die
          Seite über (894 px bei 360 px, 910 px bei 768 px). Auch bei 1024 px
          blieb dem Namen daneben nur ein Rest (etwa 45 px, „Flu…“); mit dem
          Platz für einen Namen von etwa 190 px reicht eine Zeile erst ab
          1280 px. Ab xl bleibt alles wie zuvor in einer Zeile von 3,5 rem Höhe.

          `order` stellt die Reihenfolge Logo, Konto, Navigation her, ohne die
          Struktur im Quelltext zu ändern. Das Logo trägt min-w-[5.5rem] (seine
          Breite) und wächst in die Zeile; der Name schrumpft zuerst.
        */}
        <div className="flex min-h-14 flex-wrap items-center gap-x-4 gap-y-1 py-2 xl:flex-nowrap">
          <div className="order-1 flex min-w-[5.5rem] flex-1 items-center gap-2 xl:flex-initial">
            <Link
              href="/"
              aria-label="PAOLO SMS, zur Startseite"
              className="shrink-0 focus-visible:rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            >
              <Image
                src="/paolo-logo-horizontal.png"
                alt="PAOLO SMS"
                width={600}
                height={194}
                className="h-7 w-auto"
                priority
              />
            </Link>
            <OrganizationNameTag name={organizationName} />
          </div>

          <DashboardNav
            className="order-3 basis-full xl:order-2 xl:mr-auto xl:basis-auto xl:shrink-0 xl:flex-nowrap"
            showReports={showReports}
            showMeasures={showMeasures}
            showDocuments={showDocuments}
            showAdmin={showAdmin}
            showHelp={showHelp}
          />
          <UserNav className="order-2 shrink-0 xl:order-3" />
        </div>
      </nav>

      {children}
    </div>
  )
}
