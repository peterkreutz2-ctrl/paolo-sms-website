import { appAuth } from "@/lib/auth"
import { listDirectoryUsers } from "@/lib/auth/user-directory"
import { desc, inArray } from "drizzle-orm"
import { notFound, redirect } from "next/navigation"

import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { hasSafetyEditRole } from "@/lib/constants/roles"
import {
  ACTIVITY_AREA_LABELS,
  ACTIVITY_TYPE_LABELS,
  DAMAGE_SEVERITY_LABELS,
  FLIGHT_PHASE_LABELS,
  INJURY_SEVERITY_LABELS,
  LAUNCH_TYPE_LABELS,
  REPORTER_ROLE_LABELS,
} from "@/lib/constants/report-classification"
import { MEASURE_STATUS_LABELS } from "@/lib/constants/measure-workflow"
import {
  INCIDENT_NOTIFICATION_DECISION_LABELS,
  INCIDENT_RISK_LABELS,
  INCIDENT_STATUS_LABELS,
} from "@/lib/constants/privacy-incidents"
import { NOTE_TYPE_LABELS, type NoteType } from "@/lib/constants/report-notes"
import {
  normalizeVisibility,
  SMS_DOCUMENT_CATEGORY_LABELS,
  SMS_DOCUMENT_VISIBILITY_LABELS,
  type SmsDocumentCategory,
} from "@/lib/constants/sms-documents"
import {
  PUBLIC_REPORT_TYPE_LABELS,
  type PublicReportType,
} from "@/lib/constants/public-report-types"
import { SOURCE_CHANNEL_LABELS, type SourceChannel } from "@/lib/constants/report-workflow"
import { db } from "@/lib/db"
import { auditLogs, reports } from "@/lib/db/schema"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"

const dateFormatter = new Intl.DateTimeFormat("de-DE", {
  dateStyle: "short",
  timeStyle: "medium",
})

const AI_INTAKE_PROVIDER_LABELS: Record<string, string> = {
  openai: "OpenAI",
}

const AI_INTAKE_ROLLOUT_MODE_LABELS: Record<string, string> = {
  off: "Deaktiviert",
  internal: "Nur intern",
  public: "Öffentlich",
}

const AI_DIALOG_INTAKE_MODE_LABELS: Record<string, string> = {
  text: "Textdialog",
  voice: "Sprachdialog",
}

const AI_DIALOG_SESSION_STATUS_LABELS: Record<string, string> = {
  active: "Aktiv",
  extraction_generated: "Extraktion erzeugt",
  report_created: "Meldung erstellt",
  abandoned: "Abgebrochen",
  discarded: "Verworfen",
  failed: "Fehlgeschlagen",
}

const ACTION_LABELS: Record<string, string> = {
  REPORT_CREATED: "Neue Meldung eingereicht",
  REPORT_CORE_UPDATED: "Meldungsdaten geändert",
  REPORT_WORKFLOW_UPDATED: "Status/Priorität geändert",
  REPORT_CLASSIFICATION_UPDATED: "Klassifikation geändert",
  REPORT_REPORTER_INFO_UPDATED: "Melder-Informationen geändert",
  REPORT_SOFT_DELETED: "Meldung ausgeblendet",
  REPORT_RESTORED: "Meldung wiederhergestellt",
  REPORT_HARD_DELETED: "Meldung endgültig gelöscht",
  REPORT_ANONYMIZED: "Melderdaten anonymisiert",
  REPORT_NOTE_CREATED: "Nachtrag zur Meldung erstellt",
  MEASURE_CREATED: "Maßnahme angelegt",
  MEASURE_UPDATED: "Maßnahme bearbeitet",
  MEASURE_DISCARDED: "Maßnahme verworfen",
  REPORTS_EXPORTED: "Meldungen exportiert",
  REPORTS_IMPORTED: "Meldungen importiert",
  BACKUP_CREATED: "Datenbank-Backup erstellt",
  BACKUP_CRON_REJECTED: "Geplantes Datenbank-Backup abgewiesen",
  BACKUP_CRON_FAILED: "Geplantes Datenbank-Backup fehlgeschlagen",
  BACKUP_RETENTION_APPLIED: "Backup-Aufbewahrung angewendet",
  BACKUP_RETENTION_FAILED: "Backup-Aufbewahrung fehlgeschlagen",
  BACKUP_DOWNLOADED: "Datenbank-Backup heruntergeladen",
  BACKUP_MANIFEST_DOWNLOADED: "Backup-Manifest heruntergeladen",
  ROLE_ASSIGNED: "Rolle vergeben",
  ROLE_REMOVED: "Rolle entzogen",
  ACCESS_LINK_ISSUED: "Anmeldelink erstellt",
  ACCOUNT_DATA_UPDATED: "Kontodaten geändert",
  ACCOUNT_DELETED: "Konto gelöscht",
  SAFETY_MEETING_CREATED: "Sicherheitsbesprechung eingetragen",
  SMS_DOCUMENT_CREATED: "SMS-Dokument erstellt",
  SMS_DOCUMENT_UPDATED: "SMS-Dokument geändert",
  SMS_DOCUMENT_DELETED: "SMS-Dokument gelöscht",
  PRIVACY_INCIDENT_CREATED: "Datenschutzvorfall erfasst",
  PRIVACY_INCIDENT_UPDATED: "Datenschutzvorfall aktualisiert",
  ORG_DISPLAY_NAME_CHANGED: "Anzeigename der Organisation geändert",
  ORG_PUBLIC_REPORT_STATUS_VISIBILITY_CHANGED:
    "Öffentliche Statusrückmeldungen ein-/ausgeschaltet",
  ORG_PUBLIC_REPORT_PRIVACY_CONSENT_ENABLED_CHANGED:
    "Einwilligungsabfrage im Meldeformular ein-/ausgeschaltet",
  ORG_PUBLIC_REPORT_PRIVACY_CONSENT_TEXT_CHANGED:
    "Einwilligungstext im Meldeformular geändert",
  DEMO_DATA_LOADED: "Spieldaten geladen",
  INSTALLATION_DATA_RESET: "Installationsdaten zurückgesetzt",
  AI_INTAKE_SETTINGS_UPDATED: "KI-Erfassung konfiguriert",
  AI_DIALOG_SESSION_STARTED: "KI-Dialog gestartet",
  AI_DIALOG_EXTRACTION_GENERATED: "KI-Extraktion erzeugt",
  AI_DIALOG_REPORT_CREATED: "Meldung aus KI-Dialog erstellt",
  AI_DIALOG_SESSION_FAILED: "KI-Dialog fehlgeschlagen",
  AI_DIALOG_SESSION_ABANDONED: "KI-Dialog abgebrochen",
  AI_DIALOG_SESSION_DISCARDED: "KI-Entwurf verworfen",
  AI_PUBLIC_RATE_LIMIT_HIT: "Öffentliche KI-Rate-Limitierung",
  AI_USAGE_RECORDED: "KI-Nutzung erfasst",
  AI_USAGE_FAILED: "KI-Nutzung fehlgeschlagen",
}

const STATUS_LABELS: Record<string, string> = {
  new: "offen",
  in_progress: "in Bearbeitung",
  closed: "abgeschlossen",
}

const PRIORITY_LABELS: Record<string, string> = {
  low: "niedrig",
  medium: "mittel",
  high: "hoch",
  critical: "kritisch",
}

const RESOURCE_LABELS: Record<string, string> = {
  report: "Meldung",
  report_note: "Nachtrag",
  user_role: "Benutzerrolle",
  measure: "Maßnahme",
  attachment: "Anhang",
  organization: "Organisation",
  safety_meeting: "Sicherheitsbesprechung",
  sms_document: "SMS-Dokument",
  privacy_incident: "Datenschutzvorfall",
  backup: "Datenbank-Backup",
  ai_dialog_session: "KI-Dialog",
}

const AI_USAGE_SCOPE_LABELS: Record<string, string> = {
  internal_text_dialog: "Interner Textdialog",
  internal_report_extraction: "Interne Extraktion",
  public_text_dialog: "Öffentlicher Textdialog",
  public_report_extraction: "Öffentliche Extraktion",
  public_ai_session_start: "Öffentlicher Dialogstart",
  public_ai_message: "Öffentliche Dialognachricht",
  public_ai_extraction: "Öffentliche Extraktion",
  public_ai_confirmation: "Öffentliche Bestätigung",
}

function l(map: Record<string, string>, key: string): string {
  return map[key] ?? key
}

function safeChanges(changes: unknown): Record<string, unknown> | null {
  if (changes === null || changes === undefined || typeof changes !== "object" || Array.isArray(changes)) {
    return null
  }
  return changes as Record<string, unknown>
}

function renderDetails(action: string, changes: unknown) {
  const c = safeChanges(changes)
  if (!c) return <span className="text-xs text-muted-foreground">—</span>

  switch (action) {
    case "ORG_DISPLAY_NAME_CHANGED": {
      // Der Anzeigename ist ohnehin öffentlich; alter und neuer Wert stehen im
      // Klartext im Protokoll (React maskiert die Ausgabe).
      const from = typeof c.from === "string" ? c.from : null
      const to = typeof c.to === "string" ? c.to : null
      return (
        <p className="text-xs">
          Anzeigename: {from ? `„${from}“` : "—"} → {to ? `„${to}“` : "—"}
        </p>
      )
    }
    case "REPORT_WORKFLOW_UPDATED": {
      const o = c.old as Record<string, string> | undefined
      const n = c.new as Record<string, string> | undefined
      if (!o || !n) break
      const lines: string[] = []
      if (o.status !== n.status)
        lines.push(`Status: ${l(STATUS_LABELS, o.status)} → ${l(STATUS_LABELS, n.status)}`)
      if (o.priority !== n.priority)
        lines.push(`Priorität: ${l(PRIORITY_LABELS, o.priority)} → ${l(PRIORITY_LABELS, n.priority)}`)
      if (lines.length === 0)
        return <span className="text-xs text-muted-foreground">Keine Änderung</span>
      return (
        <div className="space-y-0.5 text-xs">
          {lines.map((line) => <p key={line}>{line}</p>)}
        </div>
      )
    }
    case "REPORT_CLASSIFICATION_UPDATED": {
      const o = c.old as Record<string, unknown> | undefined
      const n = c.new as Record<string, unknown> | undefined
      if (!o || !n) break
      const fieldMeta: Array<{ key: string; label: string; map: Record<string, string> }> = [
        { key: "activityArea", label: "Tätigkeitsbereich", map: ACTIVITY_AREA_LABELS },
      ]
      const lines: string[] = []
      for (const { key, label, map } of fieldMeta) {
        const oldVal = (o[key] as string | null | undefined) ?? null
        const newVal = (n[key] as string | null | undefined) ?? null
        if (oldVal === newVal) continue
        const oldLabel = oldVal ? (map[oldVal] ?? oldVal) : "—"
        const newLabel = newVal ? (map[newVal] ?? newVal) : "—"
        lines.push(`${label}: ${oldLabel} → ${newLabel}`)
      }
      // isReportableAccident: boolean | null — handle separately
      const oldAccident = o.isReportableAccident
      const newAccident = n.isReportableAccident
      if (oldAccident !== newAccident) {
        const fmt = (v: unknown) =>
          v === true ? "Ja – meldepflichtig" : v === false ? "Nein – nicht meldepflichtig" : "—"
        lines.push(`Meldepflichtiger Unfall: ${fmt(oldAccident)} → ${fmt(newAccident)}`)
      }
      if (lines.length === 0)
        return <span className="text-xs text-muted-foreground">Keine Änderung</span>
      return (
        <div className="space-y-0.5 text-xs">
          {lines.map((line) => <p key={line}>{line}</p>)}
        </div>
      )
    }
    case "REPORT_REPORTER_INFO_UPDATED": {
      const o = c.old as Record<string, string | null> | undefined
      const n = c.new as Record<string, string | null> | undefined
      if (!o || !n) break
      const lines: string[] = []
      if (o.reporterName !== n.reporterName) {
        lines.push(`Name: ${o.reporterName ?? "—"} → ${n.reporterName ?? "—"}`)
      }
      if (o.reporterRole !== n.reporterRole) {
        const fmt = (v: string | null) =>
          v ? (REPORTER_ROLE_LABELS[v as keyof typeof REPORTER_ROLE_LABELS] ?? v) : "—"
        lines.push(`Rolle: ${fmt(o.reporterRole)} → ${fmt(n.reporterRole)}`)
      }
      if (o.reporterContact !== n.reporterContact) {
        lines.push(`Kontakt: ${o.reporterContact ?? "—"} → ${n.reporterContact ?? "—"}`)
      }
      if (lines.length === 0)
        return <span className="text-xs text-muted-foreground">Keine Änderung</span>
      return (
        <div className="space-y-0.5 text-xs">
          {lines.map((line) => <p key={line}>{line}</p>)}
        </div>
      )
    }
    case "REPORT_CORE_UPDATED": {
      const o = c.old as Record<string, unknown> | undefined
      const n = c.new as Record<string, unknown> | undefined
      if (!o || !n) break
      const lines: string[] = []
      if (o.reportType !== n.reportType) {
        lines.push(`Meldungstyp: ${o.reportType ?? "—"} → ${n.reportType ?? "—"}`)
      }
      if (o.shortDescription !== n.shortDescription) {
        lines.push(`Kurzbeschreibung: „${o.shortDescription ?? "—"}" → „${n.shortDescription ?? "—"}"`)
      }
      if (o.detailedDescription !== n.detailedDescription) {
        lines.push("Beschreibung: geändert")
      }
      if (o.isAnonymous !== n.isAnonymous) {
        const fmt = (v: unknown) => v === true ? "Ja" : v === false ? "Nein" : "—"
        lines.push(`Anonym: ${fmt(o.isAnonymous)} → ${fmt(n.isAnonymous)}`)
      }
      if (o.occurredAt !== n.occurredAt) {
        lines.push(`Ereigniszeitpunkt: ${o.occurredAt ?? "—"} → ${n.occurredAt ?? "—"}`)
      }
      if (o.locationText !== n.locationText) {
        lines.push(`Ort: ${o.locationText ?? "—"} → ${n.locationText ?? "—"}`)
      }
      const coreEnumMeta: Array<{ key: string; label: string; map: Record<string, string> }> = [
        { key: "activityType", label: "Flugtyp", map: ACTIVITY_TYPE_LABELS },
        { key: "flightPhase", label: "Flugphase", map: FLIGHT_PHASE_LABELS },
        { key: "launchType", label: "Startart", map: LAUNCH_TYPE_LABELS },
        { key: "injurySeverity", label: "Verletzungsschwere", map: INJURY_SEVERITY_LABELS },
        { key: "damageSeverity", label: "Sachschadenschwere", map: DAMAGE_SEVERITY_LABELS },
      ]
      for (const { key, label, map } of coreEnumMeta) {
        const oldVal = (o[key] as string | null | undefined) ?? null
        const newVal = (n[key] as string | null | undefined) ?? null
        if (oldVal === newVal) continue
        lines.push(`${label}: ${oldVal ? (map[oldVal] ?? oldVal) : "—"} → ${newVal ? (map[newVal] ?? newVal) : "—"}`)
      }
      if (lines.length === 0)
        return <span className="text-xs text-muted-foreground">Keine Änderung</span>
      return (
        <div className="space-y-0.5 text-xs">
          {lines.map((line) => <p key={line}>{line}</p>)}
        </div>
      )
    }
    case "REPORT_SOFT_DELETED":
      return (
        <div className="space-y-0.5 text-xs">
          <p>Meldung wurde ausgeblendet</p>
          {typeof c.deleteReason === "string" && c.deleteReason && (
            <p className="text-muted-foreground">Grund: {c.deleteReason}</p>
          )}
        </div>
      )
    case "REPORT_RESTORED":
      return <p className="text-xs">Meldung wurde wiederhergestellt</p>
    case "REPORT_HARD_DELETED": {
      // Der Umfang des Verlusts gehoert in den Eintrag: Nach dem Loeschen
      // laesst sich sonst nicht mehr sagen, ob an der Meldung gearbeitet
      // wurde. Bewusst nur Zahlen — Massnahmen- und Notiztexte sind Freitext.
      const counts = (
        [
          ["Anhänge", c.attachmentCount],
          ["Maßnahmen", c.measureCount],
          ["Notizen", c.noteCount],
        ] as const
      ).filter(([, value]) => typeof value === "number" && value > 0)

      return (
        <div className="space-y-0.5 text-xs">
          <p>Meldung wurde endgültig gelöscht</p>
          {counts.length > 0 ? (
            <p className="text-muted-foreground">
              {counts.map(([label, value]) => `${label}: ${value}`).join(" · ")}
            </p>
          ) : null}
        </div>
      )
    }
    case "REPORT_ANONYMIZED": {
      const fieldLabels: Record<string, string> = {
        reporterName: "Name",
        reporterRole: "Rolle",
        reporterContact: "Kontakt",
      }
      const cleared = Array.isArray(c.clearedFields)
        ? (c.clearedFields as unknown[]).filter(
            (f): f is string => typeof f === "string"
          )
        : []
      const clearedLabels = cleared.map((f) => fieldLabels[f] ?? f)
      return (
        <div className="space-y-0.5 text-xs">
          <p>Strukturierte Melderdaten anonymisiert</p>
          <p className="text-muted-foreground">
            Entfernte Felder:{" "}
            {clearedLabels.length > 0 ? clearedLabels.join(", ") : "keine"}
          </p>
          <p className="text-muted-foreground">
            Freitexte und Anhänge bleiben manuell zu prüfen.
          </p>
          {typeof c.note === "string" && c.note ? (
            <p className="text-muted-foreground">Hinweis: {c.note}</p>
          ) : null}
        </div>
      )
    }
    case "REPORTS_EXPORTED": {
      const count = typeof c.count === "number" ? c.count : null
      const format = typeof c.format === "string" ? c.format.toUpperCase() : "—"
      return (
        <div className="space-y-0.5 text-xs">
          <p>{count !== null ? `${count} Meldung(en)` : "Meldungen"} exportiert</p>
          <p className="text-muted-foreground">Format: {format}</p>
        </div>
      )
    }
    case "REPORTS_IMPORTED": {
      const total = typeof c.total === "number" ? c.total : null
      const inserted = typeof c.inserted === "number" ? c.inserted : null
      const skipped = typeof c.skipped === "number" ? c.skipped : null
      const format = typeof c.format === "string" ? c.format.toUpperCase() : "—"
      return (
        <div className="space-y-0.5 text-xs">
          <p className="text-muted-foreground">Format: {format}</p>
          {total !== null && <p>Eingelesen: {total}</p>}
          {inserted !== null && <p>Eingefügt: {inserted}</p>}
          {skipped !== null && <p>Übersprungen: {skipped}</p>}
        </div>
      )
    }
    case "DEMO_DATA_LOADED": {
      return (
        <div className="space-y-0.5 text-xs">
          <p>Fixture-Version: {String(c.fixtureVersion ?? "—")}</p>
          <p className="text-muted-foreground">
            Meldungen: {String(c.reports ?? 0)} · Maßnahmen: {String(c.measures ?? 0)} ·
            Notizen: {String(c.reportNotes ?? 0)} · Besprechungen: {String(c.safetyMeetings ?? 0)}
          </p>
        </div>
      )
    }
    case "INSTALLATION_DATA_RESET": {
      const external = safeChanges(c.external)
      const deleted = safeChanges(c.deleted)
      const deletedRows = deleted
        ? Object.values(deleted).reduce<number>(
            (total, value) => total + (typeof value === "number" ? value : 0),
            0
          )
        : 0
      return (
        <div className="space-y-0.5 text-xs">
          <p>Reset-Version: {String(c.resetVersion ?? "—")}</p>
          <p className="text-muted-foreground">
            Datenbankzeilen: {deletedRows} · Attachment-Dateien: {String(external?.attachmentFiles ?? 0)} ·
            Backup-Dateien: {String(external?.backupFiles ?? 0)}
          </p>
        </div>
      )
    }
    case "ROLE_ASSIGNED":
      return (
        <div className="space-y-0.5 text-xs">
          <p>Neue Rolle: {String(c.newRoleKey ?? "—")}</p>
          {c.previousRoleKey != null && (
            <p className="text-muted-foreground">Vorherige Rolle: {String(c.previousRoleKey)}</p>
          )}
        </div>
      )
    case "ROLE_REMOVED":
      return (
        <p className="text-xs">
          Entfernte Rolle: {String(c.removedRoleKey ?? "—")}
          {c.orphaned === true ? " (Konto beim Anmeldedienst nicht mehr vorhanden)" : ""}
        </p>
      )
    case "ACCOUNT_DATA_UPDATED":
      // Nur welche Felder — nie Namen oder Adressen (#114).
      return (
        <p className="text-xs">
          Geändert:{" "}
          {Array.isArray(c.changedFields)
            ? c.changedFields.map((field) => (field === "email" ? "E-Mail" : "Name")).join(", ")
            : "—"}
        </p>
      )
    case "ACCOUNT_DELETED":
      return (
        <p className="text-xs">
          Bisherige Rolle: {c.previousRoleKey ? String(c.previousRoleKey) : "keine"}
        </p>
      )
    case "ACCESS_LINK_ISSUED":
      // Nur dass und fuer wen — nie der Link oder sein Token (#111).
      return (
        <p className="text-xs">
          {c.linkKind === "password" ? "Link zum Festlegen eines Passworts" : "Anmeldelink"}
        </p>
      )
    case "REPORT_NOTE_CREATED": {
      const typeLabel =
        typeof c.noteType === "string"
          ? (NOTE_TYPE_LABELS[c.noteType as NoteType] ?? c.noteType)
          : "—"
      return (
        <div className="space-y-0.5 text-xs">
          <p>Typ: {typeLabel}</p>
          {typeof c.shortDescription === "string" && c.shortDescription ? (
            <p className="text-muted-foreground">Meldung: {c.shortDescription}</p>
          ) : null}
        </div>
      )
    }
    case "MEASURE_DISCARDED": {
      // Eigener Zweig: Beim Verwerfen ist die Begruendung die eigentliche
      // Information — sie steht nur hier, weil die Tabelle keine Spalte dafuer
      // hat (siehe lib/actions/measures.ts).
      return (
        <div className="space-y-0.5 text-xs">
          {typeof c.title === "string" && <p>{`Titel: „${c.title}"`}</p>}
          <p>
            Aus der Nachverfolgung genommen
            {typeof c.previousStatus === "string"
              ? ` (vorher: ${
                  MEASURE_STATUS_LABELS[
                    c.previousStatus as keyof typeof MEASURE_STATUS_LABELS
                  ] ?? c.previousStatus
                })`
              : ""}
          </p>
          {typeof c.discardReason === "string" && c.discardReason ? (
            <p className="whitespace-pre-wrap">{`Begründung: „${c.discardReason}"`}</p>
          ) : null}
          {typeof c.reportShortDescription === "string" && (
            <p className="text-muted-foreground">{`Meldung: ${c.reportShortDescription}`}</p>
          )}
        </div>
      )
    }

    case "MEASURE_CREATED":
    case "MEASURE_UPDATED": {
      const statusLabel =
        typeof c.status === "string"
          ? (MEASURE_STATUS_LABELS[c.status as keyof typeof MEASURE_STATUS_LABELS] ?? c.status)
          : "—"
      return (
        <div className="space-y-0.5 text-xs">
          {typeof c.title === "string" && (
            <p>{`Titel: „${c.title}"`}</p>
          )}
          <p>Status: {statusLabel}</p>
          {typeof c.dueDate === "string" && c.dueDate ? (
            <p>Fällig: {c.dueDate}</p>
          ) : (
            <p className="text-muted-foreground">Kein Fälligkeitsdatum</p>
          )}
          {c.descriptionChanged === true && (
            <p className="text-muted-foreground">Beschreibung: geändert</p>
          )}
          {typeof c.assignedToText === "string" && c.assignedToText ? (
            <p>Verantwortlich: {c.assignedToText}</p>
          ) : null}
          {typeof c.reportShortDescription === "string" && c.reportShortDescription && (
            <p className="text-muted-foreground">Meldung: {c.reportShortDescription}</p>
          )}
        </div>
      )
    }
    case "SAFETY_MEETING_CREATED": {
      const dateStr = typeof c.meetingDate === "string" ? c.meetingDate : null
      const title = typeof c.title === "string" && c.title ? c.title : null
      return (
        <div className="space-y-0.5 text-xs">
          {dateStr && <p>Datum: {dateStr.split("-").reverse().join(".")}</p>}
          {title && <p>Titel: {title}</p>}
        </div>
      )
    }
    case "SMS_DOCUMENT_CREATED":
    case "SMS_DOCUMENT_DELETED": {
      const title = typeof c.title === "string" ? c.title : null
      const category =
        typeof c.category === "string"
          ? SMS_DOCUMENT_CATEGORY_LABELS[c.category as SmsDocumentCategory] ??
            c.category
          : null
      const visibility =
        typeof c.visibility === "string"
          ? SMS_DOCUMENT_VISIBILITY_LABELS[normalizeVisibility(c.visibility)]
          : null
      return (
        <div className="space-y-0.5 text-xs">
          {title && <p>Titel: {title}</p>}
          {category && (
            <p className="text-muted-foreground">Kategorie: {category}</p>
          )}
          {visibility && (
            <p className="text-muted-foreground">Sichtbarkeit: {visibility}</p>
          )}
        </div>
      )
    }
    case "SMS_DOCUMENT_UPDATED": {
      const title = typeof c.title === "string" ? c.title : null
      const o = c.old as Record<string, string> | undefined
      const n = c.new as Record<string, string> | undefined
      const visLabel = (v?: string) =>
        v ? SMS_DOCUMENT_VISIBILITY_LABELS[normalizeVisibility(v)] : "—"
      return (
        <div className="space-y-0.5 text-xs">
          {title && <p>Titel: {title}</p>}
          {o && n && o.visibility !== n.visibility ? (
            <p>
              Sichtbarkeit: {visLabel(o.visibility)} → {visLabel(n.visibility)}
            </p>
          ) : null}
        </div>
      )
    }
    case "PRIVACY_INCIDENT_CREATED": {
      const risk = typeof c.riskAssessment === "string" ? c.riskAssessment : null
      return (
        <div className="space-y-0.5 text-xs">
          {typeof c.title === "string" && c.title ? <p>Titel: {c.title}</p> : null}
          {risk ? (
            <p className="text-muted-foreground">
              Risiko: {INCIDENT_RISK_LABELS[risk as keyof typeof INCIDENT_RISK_LABELS] ?? risk}
            </p>
          ) : null}
        </div>
      )
    }
    case "PRIVACY_INCIDENT_UPDATED": {
      const o = c.old as Record<string, string> | undefined
      const n = c.new as Record<string, string> | undefined
      const sLabel = (v: string | undefined) =>
        v ? INCIDENT_STATUS_LABELS[v as keyof typeof INCIDENT_STATUS_LABELS] ?? v : "—"
      return (
        <div className="space-y-0.5 text-xs">
          {typeof c.title === "string" && c.title ? <p>Titel: {c.title}</p> : null}
          {o && n && o.status !== n.status ? (
            <p>Status: {sLabel(o.status)} → {sLabel(n.status)}</p>
          ) : n ? (
            <p>Status: {sLabel(n.status)}</p>
          ) : null}
          {n?.riskAssessment ? (
            <p className="text-muted-foreground">
              Risiko:{" "}
              {INCIDENT_RISK_LABELS[n.riskAssessment as keyof typeof INCIDENT_RISK_LABELS] ??
                n.riskAssessment}
            </p>
          ) : null}
          {n?.notificationDecision ? (
            <p className="text-muted-foreground">
              Meldeentscheidung:{" "}
              {INCIDENT_NOTIFICATION_DECISION_LABELS[
                n.notificationDecision as keyof typeof INCIDENT_NOTIFICATION_DECISION_LABELS
              ] ?? n.notificationDecision}
            </p>
          ) : null}
        </div>
      )
    }
    case "AI_INTAKE_SETTINGS_UPDATED": {
      const n = c.new as Record<string, unknown> | undefined
      if (!n) break
      const rolloutMode =
        typeof n.rolloutMode === "string"
          ? AI_INTAKE_ROLLOUT_MODE_LABELS[n.rolloutMode] ?? n.rolloutMode
          : "—"
      const provider =
        typeof n.provider === "string"
          ? AI_INTAKE_PROVIDER_LABELS[n.provider] ?? n.provider
          : "—"
      const textEnabled = n.textIntakeEnabled === true ? "Ja" : "Nein"
      const voiceEnabled = n.voiceIntakeEnabled === true ? "Ja" : "Nein"
      return (
        <div className="space-y-0.5 text-xs">
          <p>Rollout: {rolloutMode}</p>
          <p>Anbieter: {provider}</p>
          <p>Modell: {typeof n.model === "string" ? n.model : "—"}</p>
          <p>
            Modi: Text {textEnabled}, Sprache {voiceEnabled}
          </p>
          <p className="text-muted-foreground">
            Credential:{" "}
            {typeof n.credentialEnvVarName === "string"
              ? n.credentialEnvVarName
              : "—"}
          </p>
        </div>
      )
    }
    case "AI_DIALOG_SESSION_STARTED":
    case "AI_DIALOG_EXTRACTION_GENERATED":
    case "AI_DIALOG_REPORT_CREATED":
    case "AI_DIALOG_SESSION_FAILED":
    case "AI_DIALOG_SESSION_ABANDONED":
    case "AI_DIALOG_SESSION_DISCARDED": {
      const mode =
        typeof c.intakeMode === "string"
          ? AI_DIALOG_INTAKE_MODE_LABELS[c.intakeMode] ?? c.intakeMode
          : "—"
      const status =
        typeof c.status === "string"
          ? AI_DIALOG_SESSION_STATUS_LABELS[c.status] ?? c.status
          : "—"
      const sourceChannel =
        typeof c.sourceChannel === "string"
          ? SOURCE_CHANNEL_LABELS[c.sourceChannel as SourceChannel] ??
            c.sourceChannel
          : null

      return (
        <div className="space-y-0.5 text-xs">
          <p>Modus: {mode}</p>
          <p>Status: {status}</p>
          {typeof c.provider === "string" && c.provider ? (
            <p>Anbieter: {AI_INTAKE_PROVIDER_LABELS[c.provider] ?? c.provider}</p>
          ) : null}
          {typeof c.model === "string" && c.model ? <p>Modell: {c.model}</p> : null}
          {typeof c.suggestedReportType === "string" && c.suggestedReportType ? (
            <p>
              Vorgeschlagener Meldungstyp:{" "}
              {PUBLIC_REPORT_TYPE_LABELS[
                c.suggestedReportType as PublicReportType
              ] ?? c.suggestedReportType}
            </p>
          ) : null}
          {typeof c.turnCount === "number" ? <p>Turns: {c.turnCount}</p> : null}
          {typeof c.confidence === "number" ? (
            <p>Konfidenz: {Math.round(c.confidence * 100)}%</p>
          ) : null}
          {typeof c.reportShortDescription === "string" && c.reportShortDescription ? (
            <p className="text-muted-foreground">Meldung: {c.reportShortDescription}</p>
          ) : null}
          {sourceChannel ? (
            <p className="text-muted-foreground">Erfassungskanal: {sourceChannel}</p>
          ) : null}
          {typeof c.reason === "string" && c.reason ? (
            <p className="text-muted-foreground">Grund: {c.reason}</p>
          ) : null}
        </div>
      )
    }
    case "AI_PUBLIC_RATE_LIMIT_HIT": {
      const scope = typeof c.scope === "string" ? c.scope : "—"
      return (
        <div className="space-y-0.5 text-xs">
          <p>Bereich: {AI_USAGE_SCOPE_LABELS[scope] ?? scope}</p>
          {typeof c.limit === "number" ? <p>Limit: {c.limit}</p> : null}
          {typeof c.windowSeconds === "number" ? (
            <p className="text-muted-foreground">
              Fenster: {Math.round(c.windowSeconds / 60)} Minuten
            </p>
          ) : null}
        </div>
      )
    }
    case "AI_USAGE_RECORDED":
    case "AI_USAGE_FAILED": {
      const scope = typeof c.scope === "string" ? c.scope : "—"
      const rolloutMode =
        typeof c.rolloutMode === "string"
          ? AI_INTAKE_ROLLOUT_MODE_LABELS[c.rolloutMode] ?? c.rolloutMode
          : null
      return (
        <div className="space-y-0.5 text-xs">
          <p>Bereich: {AI_USAGE_SCOPE_LABELS[scope] ?? scope}</p>
          {rolloutMode ? <p>Rollout: {rolloutMode}</p> : null}
          {typeof c.provider === "string" && c.provider ? (
            <p>
              Anbieter:{" "}
              {AI_INTAKE_PROVIDER_LABELS[c.provider] ?? c.provider}
            </p>
          ) : null}
          {typeof c.model === "string" && c.model ? <p>Modell: {c.model}</p> : null}
          {typeof c.totalTokens === "number" ? (
            <p>Tokens gesamt: {c.totalTokens}</p>
          ) : null}
          {typeof c.estimatedCostMicros === "number" ? (
            <p>
              Kostenschaetzung: {(c.estimatedCostMicros / 1_000_000).toFixed(4)}
            </p>
          ) : null}
          {typeof c.errorCode === "string" && c.errorCode ? (
            <p className="text-muted-foreground">Fehler: {c.errorCode}</p>
          ) : null}
        </div>
      )
    }
    case "ORG_PUBLIC_REPORT_PRIVACY_CONSENT_ENABLED_CHANGED": {
      if (typeof c.from !== "boolean" || typeof c.to !== "boolean") break
      const onOff = (value: boolean) => (value ? "Ein" : "Aus")
      return (
        <p className="text-xs">
          Einwilligungsabfrage: {onOff(c.from)} → {onOff(c.to)}
        </p>
      )
    }
    case "ORG_PUBLIC_REPORT_PRIVACY_CONSENT_TEXT_CHANGED": {
      if (typeof c.from !== "string" || typeof c.to !== "string") break
      const kind = (isDefault: unknown) =>
        isDefault === true ? "Standardtext" : "eigener Text"
      return (
        <div className="space-y-1 text-xs">
          <p>
            {kind(c.fromIsDefault)} → {kind(c.toIsDefault)}
          </p>
          <details>
            <summary className="cursor-pointer text-muted-foreground">
              Wortlaut vorher und nachher
            </summary>
            <p className="mt-1 whitespace-pre-line">
              <span className="font-medium">Vorher:</span> {c.from}
            </p>
            <p className="mt-1 whitespace-pre-line">
              <span className="font-medium">Nachher:</span> {c.to}
            </p>
          </details>
        </div>
      )
    }
    default:
      break
  }

  // Fallback for unknown actions
  const keys = Object.keys(c).filter((k) => k !== "shortDescription").slice(0, 3)
  return (
    <p className="text-xs text-muted-foreground">
      {keys.map((k) => {
        const v = c[k]
        return `${k}: ${typeof v === "object" ? "…" : String(v)}`
      }).join(" · ")}
      {Object.keys(c).length > 3 && " …"}
    </p>
  )
}

export default async function AuditPage() {
  const { userId } = await appAuth()
  if (!userId) redirect("/sign-in")

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) notFound()

  const rows = await db
    .select()
    .from(auditLogs)
    .orderBy(desc(auditLogs.createdAt))
    .limit(100)

  // --- Resolve Clerk user IDs to display names (bearbeiter + role-action targets) ---
  const clerkIdSet = new Set<string>()
  for (const row of rows) {
    if (row.clerkUserId) clerkIdSet.add(row.clerkUserId)
    if (row.action === "ROLE_ASSIGNED" || row.action === "ROLE_REMOVED" || row.action === "ACCESS_LINK_ISSUED" || row.action === "ACCOUNT_DATA_UPDATED" || row.action === "ACCOUNT_DELETED") {
      const c = safeChanges(row.changes)
      if (typeof c?.targetClerkUserId === "string") clerkIdSet.add(c.targetClerkUserId)
    }
  }

  const userMap = new Map<string, string>()
  if (clerkIdSet.size > 0) {
    try {
      const users = await listDirectoryUsers({ limit: 500 })
      for (const user of users) userMap.set(user.id, user.displayName)
    } catch {
      // Clerk unavailable — fall back to "Unbekannter Benutzer"
    }
  }

  // --- Fetch short descriptions for report resources (best-effort) ---
  const reportResourceIds = [
    ...new Set(rows.filter((r) => r.resourceType === "report").map((r) => r.resourceId)),
  ]
  const reportMap = new Map<string, string>()
  if (reportResourceIds.length > 0) {
    const reportRows = await db
      .select({ id: reports.id, shortDescription: reports.shortDescription })
      .from(reports)
      .where(inArray(reports.id, reportResourceIds))
    for (const r of reportRows) reportMap.set(r.id, r.shortDescription)
  }

  return (
    <main className="mx-auto max-w-6xl space-y-8 p-8">
      <div>
        <h1 className="text-2xl font-semibold">Audit-Log</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Protokoll aller sicherheitsrelevanten Aktionen: Statusänderungen, Maßnahmen, Rollenvergaben und Sicherheitsbesprechungen. Dient der Nachvollziehbarkeit und internen Prüfung. Nur lesend — die neuesten 100 Einträge, neueste zuerst.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Ereignisse</CardTitle>
          <CardDescription>
            {rows.length === 0 ? "Noch keine Einträge vorhanden." : `${rows.length} Einträge`}
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {rows.length === 0 ? (
            <p className="px-6 py-8 text-center text-sm text-muted-foreground">
              Noch keine Audit-Log-Einträge vorhanden.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/40 text-left text-xs text-muted-foreground">
                    <th className="px-4 py-2 font-medium">Zeitpunkt</th>
                    <th className="px-4 py-2 font-medium">Ereignis</th>
                    <th className="px-4 py-2 font-medium">Betroffen</th>
                    <th className="px-4 py-2 font-medium">Bearbeiter</th>
                    <th className="px-4 py-2 font-medium">Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {rows.map((row) => {
                    const c = safeChanges(row.changes)

                    // Betroffen: report label
                    let reportLabel: string | null = null
                    if (row.resourceType === "report") {
                      if (reportMap.has(row.resourceId)) {
                        reportLabel = reportMap.get(row.resourceId)!
                      } else if (typeof c?.shortDescription === "string" && c.shortDescription) {
                        reportLabel = c.shortDescription + " (gelöscht)"
                      } else {
                        reportLabel = "gelöschte Meldung"
                      }
                    }

                    // Betroffen: report_note — short description aus changes
                    let noteReportLabel: string | null = null
                    if (row.resourceType === "report_note") {
                      if (typeof c?.shortDescription === "string" && c.shortDescription) {
                        noteReportLabel = c.shortDescription
                      }
                    }

                    // Betroffen: measure — report short description aus changes
                    let measureReportLabel: string | null = null
                    if (row.resourceType === "measure") {
                      if (typeof c?.reportShortDescription === "string" && c.reportShortDescription) {
                        measureReportLabel = c.reportShortDescription
                      }
                    }

                    // Betroffen: user_role target
                    let roleTargetLabel: string | null = null
                    if (row.resourceType === "user_role" || row.resourceType === "user_account") {
                      const targetId = typeof c?.targetClerkUserId === "string" ? c.targetClerkUserId : null
                      if (targetId) {
                        roleTargetLabel = userMap.get(targetId) ?? "Unbekannter Benutzer"
                      }
                    }

                    return (
                      <tr key={row.id} className="align-top hover:bg-muted/20">
                        <td className="whitespace-nowrap px-4 py-3 tabular-nums text-muted-foreground">
                          {dateFormatter.format(row.createdAt)}
                        </td>
                        <td className="whitespace-nowrap px-4 py-3 font-medium">
                          {ACTION_LABELS[row.action] ?? row.action}
                        </td>
                        <td className="px-4 py-3">
                          <p className="font-medium">
                            {RESOURCE_LABELS[row.resourceType] ?? row.resourceType}
                          </p>
                          {reportLabel && (
                            <p className="text-xs text-muted-foreground">{reportLabel}</p>
                          )}
                          {noteReportLabel && (
                            <p className="text-xs text-muted-foreground">{noteReportLabel}</p>
                          )}
                          {measureReportLabel && (
                            <p className="text-xs text-muted-foreground">{measureReportLabel}</p>
                          )}
                          {roleTargetLabel && (
                            <p className="text-xs text-muted-foreground">{roleTargetLabel}</p>
                          )}
                        </td>
                        <td className="px-4 py-3">
                          {row.clerkUserId ? (
                            <p>{userMap.get(row.clerkUserId) ?? "Unbekannter Benutzer"}</p>
                          ) : (
                            <p className="text-muted-foreground">Anonym / öffentlich</p>
                          )}
                        </td>
                        <td className="max-w-xs px-4 py-3">
                          {renderDetails(row.action, row.changes)}
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </main>
  )
}
