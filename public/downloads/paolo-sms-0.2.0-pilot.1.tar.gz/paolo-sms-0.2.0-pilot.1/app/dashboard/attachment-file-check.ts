// Clientseitige Vorpruefung fuer Anhang-Uploads. Wird von beiden
// Upload-Formularen verwendet (Meldungen und SMS-Dokumente), damit
// die Regeln dort nicht auseinanderlaufen.
//
// Zwei Ebenen:
//   1. checkUploadedFile() — dieselbe Funktion, die auch der Server anwendet:
//      Groesse, Typ und bei MP4 die Dateisignatur. Sie bleibt die verbindliche
//      Grenze; hier laeuft sie nur vorab, damit der Nutzer eine verstaendliche
//      Meldung bekommt statt eines rohen Plattformfehlers.
//   2. Die Videodauer — die laesst sich NUR hier pruefen. Serverseitig
//      muesste dafuer der MP4-Container geparst werden (der moov-Block liegt
//      bei Kamera-Aufnahmen meist am Dateiende). Diese Pruefung ist damit
//      umgehbar; sie richtet sich an die internen Rollen, die ohnehin
//      hochladen duerfen, und die Groesse als eigentliche Schutzgrenze bleibt
//      serverseitig erzwungen.

import {
  checkUploadedFile,
  isVideoFileName,
  videoDurationError,
} from "@/lib/constants/attachment-file-types"

/**
 * Liest die Laufzeit eines Videos ueber ein <video>-Element aus den Metadaten.
 * Liefert null, wenn sie sich nicht bestimmen laesst — etwa weil der Browser
 * den Codec nicht kennt.
 */
function readVideoDurationSeconds(file: File): Promise<number | null> {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file)
    const video = document.createElement("video")

    const finish = (value: number | null) => {
      URL.revokeObjectURL(url)
      video.removeAttribute("src")
      resolve(value)
    }

    video.preload = "metadata"
    video.onloadedmetadata = () => {
      const { duration } = video
      finish(Number.isFinite(duration) && duration > 0 ? duration : null)
    }
    video.onerror = () => finish(null)
    video.src = url
  })
}

/**
 * Prueft eine ausgewaehlte Datei. Liefert die Fehlermeldung oder null, wenn
 * alles passt.
 */
export async function validateAttachmentFile(
  file: File
): Promise<string | null> {
  const check = await checkUploadedFile(file)
  if (!check.ok) return check.message

  if (!isVideoFileName(file.name)) return null

  // Laesst sich die Dauer nicht bestimmen, wird nicht abgelehnt — die
  // Begruendung steht bei videoDurationError().
  return videoDurationError(await readVideoDurationSeconds(file))
}
