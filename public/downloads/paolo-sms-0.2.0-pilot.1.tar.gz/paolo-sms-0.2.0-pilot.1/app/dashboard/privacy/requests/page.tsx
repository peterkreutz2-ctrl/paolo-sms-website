import { appAuth } from "@/lib/auth"
import Link from "next/link"
import { notFound, redirect } from "next/navigation"

import { desc, ilike, inArray, or } from "drizzle-orm"

import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { hasSafetyEditRole } from "@/lib/constants/roles"
import { db } from "@/lib/db"
import { measures, reportNotes, reports } from "@/lib/db/schema"
import {
  REPORTER_ROLE_LABELS,
  type ReporterRole,
} from "@/lib/constants/report-classification"
import { NOTE_TYPE_LABELS, type NoteType } from "@/lib/constants/report-notes"

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { PageHeader } from "@/components/ui/page-header"

const RESULT_LIMIT = 50

type Props = {
  searchParams: Promise<{
    q?: string
  }>
}

type Hit = {
  kind: "Meldung" | "Notiz" | "Maßnahme"
  reportShort: string
  inTrash: boolean
  matched: string[]
  href: string | null
}

function contains(value: string | null | undefined, needle: string): boolean {
  return value != null && value.toLowerCase().includes(needle)
}

function reportHref(reportId: string, inTrash: boolean): string {
  return inTrash ? "/dashboard/reports/trash" : `/dashboard/reports/${reportId}`
}

export default async function DataSubjectRequestsPage({ searchParams }: Props) {
  const { userId } = await appAuth()
  if (!userId) redirect("/sign-in")

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) notFound()

  const { q } = await searchParams
  const query = (q ?? "").trim()
  const hasQuery = query.length > 0
  const needle = query.toLowerCase()

  const hits: Hit[] = []

  if (hasQuery) {
    const like = `%${query}%`

    const [reportHits, noteHits, measureHits] = await Promise.all([
      db
        .select()
        .from(reports)
        .where(
          or(
            ilike(reports.reporterName, like),
            ilike(reports.reporterRole, like),
            ilike(reports.reporterContact, like),
            ilike(reports.shortDescription, like),
            ilike(reports.detailedDescription, like)
          )
        )
        .orderBy(desc(reports.createdAt))
        .limit(RESULT_LIMIT),
      db
        .select({
          id: reportNotes.id,
          reportId: reportNotes.reportId,
          noteType: reportNotes.noteType,
        })
        .from(reportNotes)
        .where(ilike(reportNotes.content, like))
        .limit(RESULT_LIMIT),
      db
        .select({
          id: measures.id,
          reportId: measures.reportId,
          title: measures.title,
          description: measures.description,
          assignedToText: measures.assignedToText,
        })
        .from(measures)
        .where(
          or(
            ilike(measures.title, like),
            ilike(measures.description, like),
            ilike(measures.assignedToText, like)
          )
        )
        .limit(RESULT_LIMIT),
    ])

    // Kontext (Kurzbeschreibung + Papierkorb-Status) der betroffenen Meldungen
    // für Notiz-/Maßnahmen-Treffer nachladen.
    const parentIds = [
      ...new Set([
        ...noteHits.map((n) => n.reportId),
        ...measureHits.map((m) => m.reportId),
      ]),
    ]
    const parentMap = new Map<string, { short: string; inTrash: boolean }>()
    if (parentIds.length > 0) {
      const parents = await db
        .select({
          id: reports.id,
          short: reports.shortDescription,
          deletedAt: reports.deletedAt,
        })
        .from(reports)
        .where(inArray(reports.id, parentIds))
      for (const p of parents) {
        parentMap.set(p.id, { short: p.short, inTrash: p.deletedAt !== null })
      }
    }

    for (const r of reportHits) {
      const inTrash = r.deletedAt !== null
      const matched: string[] = []
      if (contains(r.reporterName, needle)) matched.push(`Name: ${r.reporterName}`)
      if (contains(r.reporterRole, needle)) {
        const label =
          REPORTER_ROLE_LABELS[r.reporterRole as ReporterRole] ?? r.reporterRole
        matched.push(`Rolle: ${label}`)
      }
      if (contains(r.reporterContact, needle))
        matched.push(`Kontakt: ${r.reporterContact}`)
      if (contains(r.shortDescription, needle)) matched.push("Kurzbeschreibung")
      if (contains(r.detailedDescription, needle))
        matched.push("Ausführliche Beschreibung (Freitext)")
      hits.push({
        kind: "Meldung",
        reportShort: r.shortDescription,
        inTrash,
        matched,
        href: reportHref(r.id, inTrash),
      })
    }

    for (const n of noteHits) {
      const parent = parentMap.get(n.reportId)
      const typeLabel = NOTE_TYPE_LABELS[n.noteType as NoteType] ?? n.noteType
      hits.push({
        kind: "Notiz",
        reportShort: parent?.short ?? "—",
        inTrash: parent?.inTrash ?? false,
        matched: [`Notiz-Inhalt (${typeLabel}, Freitext)`],
        href: reportHref(n.reportId, parent?.inTrash ?? false),
      })
    }

    for (const m of measureHits) {
      const parent = parentMap.get(m.reportId)
      const matched: string[] = []
      if (contains(m.title, needle)) matched.push(`Titel: ${m.title}`)
      if (contains(m.description, needle)) matched.push("Beschreibung (Freitext)")
      if (contains(m.assignedToText, needle))
        matched.push(`Verantwortlich: ${m.assignedToText}`)
      hits.push({
        kind: "Maßnahme",
        reportShort: parent?.short ?? "—",
        inTrash: parent?.inTrash ?? false,
        matched,
        href: reportHref(m.reportId, parent?.inTrash ?? false),
      })
    }
  }

  return (
    <main className="mx-auto max-w-4xl space-y-8 px-4 py-8 sm:px-8">
      <PageHeader
        title="Betroffenenanfrage vorbereiten"
        subtitle="Such- und Prüfhilfe für Auskunfts- und Löschanfragen nach DSGVO."
      />

      <div
        className="rounded-r-lg border-l-2 border-amber-500 bg-amber-50 px-4 py-3 text-sm leading-relaxed text-amber-800 dark:bg-amber-950/30 dark:text-amber-300"
        role="note"
      >
        <ul className="space-y-1">
          <li>
            Diese Suche ist ein Hilfsmittel für Betroffenenanfragen. Sie{" "}
            <span className="font-medium">löscht keine Daten</span>.
          </li>
          <li>
            Vor einer Löschung oder Anonymisierung müssen Aufbewahrungsgründe
            geprüft werden.
          </li>
          <li>Freitexte und Anhänge sind manuell zu prüfen.</li>
        </ul>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Suche</CardTitle>
          <CardDescription>
            Suche nach personenbezogenen Bezügen in strukturierten Feldern und
            relevanten Freitexten. Die Suche startet nur nach expliziter Eingabe.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          <form method="GET" className="flex flex-wrap items-end gap-3">
            <div className="flex-1 space-y-1.5">
              <label htmlFor="q" className="text-sm font-medium">
                Suchbegriff
              </label>
              <input
                id="q"
                name="q"
                defaultValue={query}
                placeholder="Name, E-Mail, Telefonnummer oder sonstiger Kontaktbezug"
                className="h-10 w-full rounded-md border border-input bg-white px-3 text-sm outline-none focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/40"
              />
            </div>
            <Button type="submit">Suchen</Button>
          </form>
          <p className="text-xs text-muted-foreground">
            Durchsucht: Melder-Name/-Rolle/-Kontakt, Kurzbeschreibung und
            ausführliche Beschreibung von Meldungen, Notiz-Inhalte sowie
            Maßnahmen (Titel, Beschreibung, Verantwortliche).
          </p>
        </CardContent>
      </Card>

      {hasQuery ? (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">
              Ergebnisse ({hits.length})
            </CardTitle>
            <CardDescription>
              Treffer für „{query}“. Angezeigt wird die auslösende Datenstelle,
              ohne lange Freitextauszüge.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {hits.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                Keine Treffer in den durchsuchten strukturierten Feldern und
                Freitexten. Anhänge und weitere Freitexte sind zusätzlich manuell
                zu prüfen.
              </p>
            ) : (
              <ul className="space-y-3">
                {hits.map((hit, index) => (
                  <li
                    key={`${hit.kind}-${index}`}
                    className="rounded-md border p-4"
                  >
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge variant="secondary" className="text-xs font-normal">
                        {hit.kind}
                      </Badge>
                      {hit.inTrash ? (
                        <Badge
                          variant="outline"
                          className="text-xs font-normal text-muted-foreground"
                        >
                          im Papierkorb
                        </Badge>
                      ) : null}
                    </div>
                    <p className="mt-2 font-medium">
                      {hit.href ? (
                        <Link
                          href={hit.href}
                          className="text-blue-800 hover:text-blue-900 hover:underline"
                        >
                          {hit.reportShort}
                        </Link>
                      ) : (
                        hit.reportShort
                      )}
                    </p>
                    {hit.matched.length > 0 ? (
                      <p className="mt-1 text-xs text-muted-foreground">
                        Treffer in: {hit.matched.join(" · ")}
                      </p>
                    ) : null}
                  </li>
                ))}
              </ul>
            )}

            <div
              className="rounded-r-lg border-l-2 border-sky-500 bg-sky-50 px-4 py-3 text-sm leading-relaxed text-sky-900 dark:bg-sky-950/30 dark:text-sky-200"
              role="note"
            >
              Anhänge werden nicht inhaltlich durchsucht und müssen manuell
              geprüft werden.
            </div>
          </CardContent>
        </Card>
      ) : null}

      <p className="text-sm text-muted-foreground">
        <Link
          href="/dashboard/privacy"
          className="underline underline-offset-4 hover:text-foreground"
        >
          Zurück zu den Datenschutzprozessen
        </Link>
      </p>
    </main>
  )
}
