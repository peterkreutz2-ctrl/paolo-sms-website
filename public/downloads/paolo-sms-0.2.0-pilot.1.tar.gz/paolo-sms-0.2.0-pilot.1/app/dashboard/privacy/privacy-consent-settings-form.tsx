"use client"

import { useActionState, useState } from "react"

import {
  updatePublicReportPrivacyConsentSettings,
  type PrivacyConsentSettingsState,
} from "@/lib/actions/privacy-consent-settings"
import {
  DEFAULT_PUBLIC_REPORT_PRIVACY_CONSENT_TEXT,
  PRIVACY_CONSENT_LINK_MARKER,
  PRIVACY_CONSENT_TEXT_MAX_LENGTH,
} from "@/lib/constants/public-report-privacy-consent"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"

const initialState: PrivacyConsentSettingsState = {
  success: false,
  message: "",
}

// Die Felder werden nach jedem abgeschlossenen Vorgang neu aufgebaut (`key`),
// mit den Werten, die der Server zurueckgibt — aus demselben Grund wie beim
// Schalter fuer die Statusrueckmeldung (app/dashboard/settings/settings-form.tsx):
// React setzt das Formular nach einer Form-Action zurueck, und ohne frischen
// Knoten fiele die Anzeige auf das urspruengliche Server-Rendering zurueck.
function PrivacyConsentSettingsFields({
  enabled,
  text,
}: {
  enabled: boolean
  text: string
}) {
  const [checked, setChecked] = useState(enabled)
  const [draft, setDraft] = useState(text)
  const isDefault = draft.trim() === DEFAULT_PUBLIC_REPORT_PRIVACY_CONSENT_TEXT

  return (
    <div className="space-y-6">
      <div className="flex items-start gap-3">
        <input
          id="publicReportPrivacyConsentEnabled"
          name="publicReportPrivacyConsentEnabled"
          type="checkbox"
          defaultChecked={enabled}
          onChange={(event) => setChecked(event.target.checked)}
          className="mt-1 h-4 w-4 rounded border-input accent-primary"
        />
        <div className="space-y-1">
          <label
            htmlFor="publicReportPrivacyConsentEnabled"
            className="text-sm font-medium text-foreground"
          >
            Einwilligung im Meldeformular abfragen
          </label>
          <p className="text-sm text-muted-foreground">
            {checked
              ? "Das Meldeformular zeigt ein leeres Pflicht-Kontrollkästchen mit dem Einwilligungstext. Absenden ist erst nach Zustimmung möglich."
              : "Das Meldeformular zeigt keine Einwilligung. Zu neuen Meldungen wird kein Einwilligungsnachweis gespeichert."}
          </p>
        </div>
      </div>

      <div className="space-y-2">
        <label
          htmlFor="publicReportPrivacyConsentText"
          className="text-sm font-medium text-foreground"
        >
          Einwilligungstext
        </label>
        <p
          id="publicReportPrivacyConsentTextHint"
          className="text-sm text-muted-foreground"
        >
          {PRIVACY_CONSENT_LINK_MARKER} muss genau einmal enthalten bleiben –
          an dieser Stelle erscheint im Meldeformular der Link zur
          Datenschutzerklärung. Höchstens{" "}
          {PRIVACY_CONSENT_TEXT_MAX_LENGTH.toLocaleString("de-DE")} Zeichen.
        </p>
        <Textarea
          id="publicReportPrivacyConsentText"
          name="publicReportPrivacyConsentText"
          value={draft}
          onChange={(event) => setDraft(event.target.value)}
          rows={7}
          maxLength={PRIVACY_CONSENT_TEXT_MAX_LENGTH}
          aria-describedby="publicReportPrivacyConsentTextHint"
        />
        <div className="flex flex-wrap items-center gap-3">
          <p className="text-xs text-muted-foreground">
            {isDefault ? "Standardtext" : "Eigener Text"}
          </p>
          {!isDefault ? (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setDraft(DEFAULT_PUBLIC_REPORT_PRIVACY_CONSENT_TEXT)}
            >
              Standardtext einsetzen
            </Button>
          ) : null}
        </div>
      </div>
    </div>
  )
}

export function PrivacyConsentSettingsForm({
  enabled,
  text,
}: {
  enabled: boolean
  text: string
}) {
  const [state, formAction, isPending] = useActionState(
    updatePublicReportPrivacyConsentSettings,
    initialState
  )

  const shownEnabled = state.enabled ?? enabled
  const shownText = state.text ?? text

  return (
    <form action={formAction} className="space-y-4">
      <PrivacyConsentSettingsFields
        key={state.resultId ?? 0}
        enabled={shownEnabled}
        text={shownText}
      />

      <div className="flex items-center gap-3">
        <Button type="submit" disabled={isPending}>
          {isPending ? "Wird gespeichert…" : "Speichern"}
        </Button>
        {state.message ? (
          <p
            className={
              state.success
                ? "text-sm text-emerald-700 dark:text-emerald-500"
                : "text-sm text-destructive"
            }
            role="status"
          >
            {state.message}
          </p>
        ) : null}
      </div>
    </form>
  )
}
