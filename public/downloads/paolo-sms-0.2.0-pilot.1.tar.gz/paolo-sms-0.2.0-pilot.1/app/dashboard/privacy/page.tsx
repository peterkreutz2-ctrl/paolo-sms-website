import { appAuth } from "@/lib/auth"
import Link from "next/link"
import { notFound, redirect } from "next/navigation"

import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { getLegalSettings } from "@/lib/legal-settings"
import { hasSafetyEditRole } from "@/lib/constants/roles"
import { resolvePrivacyConsentText } from "@/lib/constants/public-report-privacy-consent"
import { db } from "@/lib/db"
import { organizations } from "@/lib/db/schema"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { PageHeader } from "@/components/ui/page-header"
import { Button } from "@/components/ui/button"

import { PrivacyConsentSettingsForm } from "./privacy-consent-settings-form"

type Section = {
  id: string
  title: string
  description: string
  steps: string[]
  note: string
  techNote?: string[]
}

const SECTIONS: Section[] = [
  {
    id: "betroffenenanfragen",
    title: "A. Betroffenenanfragen",
    description:
      "Ablauf für Auskunfts- und Löschanfragen betroffener Personen.",
    steps: [
      "Anfrage entgegennehmen",
      "Identität / Berechtigung prüfen",
      "Betroffene Daten suchen",
      "Rechtliche / fachliche Aufbewahrung prüfen",
      "Löschen oder anonymisieren",
      "Anhänge gesondert prüfen",
      "Entscheidung dokumentieren",
      "Betroffene Person informieren",
    ],
    note: "Aktuell ist dies ein manueller Prozess. PAOLO löscht hier noch keine Daten automatisch.",
  },
  {
    id: "anonymisierung",
    title: "B. Anonymisierung nach Abschluss",
    description:
      "Personenbezug abgeschlossener Meldungen reduzieren, Sicherheitswissen erhalten.",
    steps: [
      "Abgeschlossene Reports prüfen",
      "Personenbezogene Melderdaten entfernen / reduzieren",
      "Freitexte manuell prüfen",
      "Anhänge manuell prüfen",
      "Fachliche Sicherheitsinformation erhalten",
      "Anonymisierung dokumentieren",
    ],
    note: "Automatische Freitext-Anonymisierung ist fehleranfällig und später gesondert zu entwickeln.",
    techNote: [
      "Beim Abschließen oder Ausblenden einer Meldung erscheint ein Hinweis zur Anonymisierungsprüfung.",
      "Per Klick können dabei nur strukturierte Melderdaten (Name, Rolle, Kontakt) anonymisiert werden.",
      "Freitexte und Anhänge bleiben unverändert und müssen manuell geprüft werden.",
      "Dies ist ein erster kontrollierter Schritt, keine Vollautomatik. Der Vorgang ist auch nachträglich auf der Meldungs-Detailseite verfügbar und wird im Audit-Log dokumentiert.",
    ],
  },
  {
    id: "incident-response",
    title: "C. Datenschutzvorfälle / Incident-Response",
    description:
      "Vorgehen bei einer (möglichen) Verletzung des Schutzes personenbezogener Daten.",
    steps: [
      "Vorfall erkennen",
      "Zugriff begrenzen / Sofortmaßnahmen",
      "Intern eskalieren",
      "Risiko für Betroffene bewerten",
      "Mögliche Meldepflicht prüfen",
      "Ggf. Aufsichtsbehörde informieren",
      "Ggf. Betroffene informieren",
      "Vorfall dokumentieren",
      "Technische Nachbereitung",
    ],
    note: "Fristen und Meldepflichten müssen Betreiber / Datenschutzbeauftragte prüfen.",
  },
]

const INCIDENT_EXAMPLES = [
  "Unberechtigter Zugriff auf eine Meldung",
  "Anhang versehentlich öffentlich zugänglich",
  "CSV-Export an eine falsche Person versendet",
  "Kompromittierter Benutzerzugang",
  "Falsche Rollen- oder Organisationszuordnung",
  "Personenbezogene Daten unbeabsichtigt gelöscht oder verändert",
]

const INCIDENT_INFO_CHECKLIST = [
  "Verantwortlicher / Kontakt",
  "Datenschutzkontakt / Datenschutzbeauftragte(r)",
  "Zeitpunkt der Kenntnisnahme",
  "Beschreibung des Vorfalls",
  "Betroffene Datenkategorien",
  "Geschätzte Zahl Betroffener",
  "Mögliche Folgen für Betroffene",
  "Sofortmaßnahmen",
  "Folgemaßnahmen",
  "Entscheidung und Begründung zur Meldepflicht",
]

export default async function PrivacyProcessesPage() {
  const { userId } = await appAuth()
  if (!userId) redirect("/sign-in")

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) notFound()

  const legal = await getLegalSettings()
  const supervisoryAuthority = legal?.supervisoryAuthority?.trim() || null

  const [organization] = await db
    .select({
      enabled: organizations.publicReportPrivacyConsentEnabled,
      storedText: organizations.publicReportPrivacyConsentText,
    })
    .from(organizations)
    .limit(1)
  const privacyConsentEnabled = organization?.enabled ?? true
  const privacyConsentText = resolvePrivacyConsentText(organization?.storedText)

  return (
    <main className="mx-auto max-w-4xl space-y-8 px-4 py-8 sm:px-8">
      <PageHeader
        title="Datenschutzprozesse"
        subtitle="Organisatorische Leitfäden für Betroffenenanfragen, Anonymisierung und Datenschutzvorfälle."
      />

      <p className="text-sm leading-relaxed text-muted-foreground">
        Diese Seite unterstützt Betreiber, Administratoren und Safety Manager bei
        den Datenschutzprozessen in PAOLO. Sie ersetzt keine Rechtsberatung.
        Fristen, Meldepflichten, Aufbewahrungsgründe und die zuständige
        Aufsichtsbehörde müssen Betreiber bzw. Datenschutzbeauftragte prüfen. Vor
        Pilot- oder Produktivbetrieb sollten die rechtlichen Angaben, die
        Datenschutzerklärung und die zuständige Aufsichtsbehörde unter
        Administration → Rechtliche Angaben geprüft und vervollständigt werden.
      </p>

      <div className="rounded-lg border border-primary/30 bg-primary/5 p-4">
        <p className="text-sm font-semibold text-foreground">
          Erste Schritte für Betreiber
        </p>
        <ol className="mt-2 space-y-1.5">
          {[
            "Rechtliche Angaben vervollständigen",
            "Impressum und Datenschutzerklärung prüfen lassen",
            "Zuständige Datenschutzaufsichtsbehörde hinterlegen",
            "Datenschutzkontakt festlegen",
            "Verfahren für Betroffenenanfragen und Datenschutzvorfälle intern klären",
          ].map((step, index) => (
            <li key={step} className="flex gap-3 text-sm">
              <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-medium text-primary">
                {index + 1}
              </span>
              <span className="leading-relaxed text-foreground">{step}</span>
            </li>
          ))}
        </ol>
        <Button asChild variant="outline" size="sm" className="mt-3">
          <Link href="/dashboard/admin/legal">
            Administration → Rechtliche Angaben
          </Link>
        </Button>
      </div>

      <div className="rounded-lg border bg-muted/40 p-4">
        <p className="text-sm font-medium text-foreground">
          Betroffenenanfrage bearbeiten
        </p>
        <p className="mt-1 text-sm text-muted-foreground">
          Such- und Prüfhilfe: personenbezogene Bezüge in Meldungen, Notizen und
          Maßnahmen finden. Löscht keine Daten.
        </p>
        <Button asChild variant="outline" size="sm" className="mt-3">
          <Link href="/dashboard/privacy/requests">
            Betroffenenanfrage vorbereiten
          </Link>
        </Button>
      </div>

      <div className="rounded-lg border bg-muted/40 p-4">
        <p className="text-sm font-medium text-foreground">
          Datenschutzvorfälle
        </p>
        <p className="mt-1 text-sm text-muted-foreground">
          Datenschutzvorfälle erfassen und nachverfolgen (Status, Risiko,
          Meldeentscheidung). PAOLO sendet keine automatische Meldung.
        </p>
        <Button asChild variant="outline" size="sm" className="mt-3">
          <Link href="/dashboard/privacy/incidents">
            Datenschutzvorfälle dokumentieren
          </Link>
        </Button>
      </div>

      <div className="rounded-lg border bg-muted/40 p-4">
        <p className="text-sm font-medium text-foreground">
          Rechtliche Angaben
        </p>
        <p className="mt-1 text-sm text-muted-foreground">
          Betreiber-, Datenschutz- und Aufsichtsbehörden-Angaben pflegen. Diese
          speisen Impressum und Datenschutzerklärung und werden unten für die
          Meldung von Vorfällen herangezogen.
        </p>
        <Button asChild variant="outline" size="sm" className="mt-3">
          <Link href="/dashboard/admin/legal">
            Administration → Rechtliche Angaben
          </Link>
        </Button>
      </div>

      <Card id="einwilligung" className="scroll-mt-8">
        <CardHeader>
          <CardTitle className="text-base">
            Einwilligung im Meldeformular
          </CardTitle>
          <CardDescription>
            Steuert die Datenschutz-Einwilligung auf „Sicherheitsmeldung
            einreichen“. Ist sie eingeschaltet, lässt sich eine Meldung erst
            nach Zustimmung absenden; mit jeder Meldung werden Zeitpunkt,
            Einwilligungstext und die zu diesem Zeitpunkt gültige
            Datenschutzerklärung als Nachweis gespeichert. Bereits vorhandene
            Meldungen bleiben unverändert.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <PrivacyConsentSettingsForm
            enabled={privacyConsentEnabled}
            text={privacyConsentText}
          />
        </CardContent>
      </Card>

      {SECTIONS.map((section) => (
        <Card key={section.id} id={section.id} className="scroll-mt-8">
          <CardHeader>
            <CardTitle className="text-base">{section.title}</CardTitle>
            <CardDescription>{section.description}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <ol className="space-y-2">
              {section.steps.map((step, index) => (
                <li key={step} className="flex gap-3 text-sm">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-medium text-primary">
                    {index + 1}
                  </span>
                  <span className="leading-relaxed text-foreground">
                    {step}
                  </span>
                </li>
              ))}
            </ol>

            <div
              className="rounded-r-lg border-l-2 border-amber-500 bg-amber-50 px-4 py-3 text-sm leading-relaxed text-amber-800 dark:bg-amber-950/30 dark:text-amber-300"
              role="note"
            >
              {section.note}
            </div>

            {section.techNote ? (
              <div
                className="rounded-r-lg border-l-2 border-sky-500 bg-sky-50 px-4 py-3 text-sm leading-relaxed text-sky-900 dark:bg-sky-950/30 dark:text-sky-200"
                role="note"
              >
                <p className="font-medium">Technische Umsetzung in PAOLO</p>
                <ul className="mt-1.5 space-y-1">
                  {section.techNote.map((line) => (
                    <li key={line} className="flex gap-2">
                      <span aria-hidden className="mt-0.5">
                        •
                      </span>
                      <span>{line}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
          </CardContent>
        </Card>
      ))}

      <div className="space-y-2">
        <h2 className="text-lg font-semibold text-foreground">
          Praxishinweise für Betreiber
        </h2>
        <p className="text-sm text-muted-foreground">
          Konkrete Orientierung für den Umgang mit Datenschutzvorfällen. Keine
          Rechtsberatung — die rechtliche Bewertung bleibt Betreiber bzw.
          Datenschutzbeauftragtem vorbehalten.
        </p>
      </div>

      <Card id="was-ist-vorfall" className="scroll-mt-8">
        <CardHeader>
          <CardTitle className="text-base">
            A. Was ist ein Datenschutzvorfall?
          </CardTitle>
          <CardDescription>Typische Beispiele aus dem Betrieb von PAOLO.</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-1.5 text-sm">
            {INCIDENT_EXAMPLES.map((ex) => (
              <li key={ex} className="flex gap-2">
                <span aria-hidden className="mt-0.5 text-amber-600">•</span>
                <span className="text-foreground">{ex}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <Card id="aufsichtsbehoerde" className="scroll-mt-8">
        <CardHeader>
          <CardTitle className="text-base">
            B. Zuständige Aufsichtsbehörde finden
          </CardTitle>
          <CardDescription>
            Wer im Meldefall zuständig ist, richtet sich nach dem Sitz des
            Verantwortlichen.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <ul className="space-y-1.5 text-sm">
            <li className="flex gap-2">
              <span aria-hidden className="mt-0.5 text-amber-600">•</span>
              <span className="text-foreground">
                Zuständig ist in der Regel die Datenschutzaufsichtsbehörde am Sitz
                des/der Verantwortlichen bzw. Betreibers.
              </span>
            </li>
            <li className="flex gap-2">
              <span aria-hidden className="mt-0.5 text-amber-600">•</span>
              <span className="text-foreground">
                Für Vereine und private Flugschulen ist dies meist die
                Landesdatenschutzaufsicht des jeweiligen Bundeslandes.
              </span>
            </li>
            <li className="flex gap-2">
              <span aria-hidden className="mt-0.5 text-amber-600">•</span>
              <span className="text-foreground">
                Die zuständige Behörde sollte in den Rechtlichen Angaben
                hinterlegt werden.
              </span>
            </li>
          </ul>

          {supervisoryAuthority ? (
            <div
              className="rounded-r-lg border-l-2 border-emerald-500 bg-emerald-50 px-4 py-3 text-sm leading-relaxed text-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-300"
              role="note"
            >
              <span className="font-medium">
                Hinterlegte zuständige Aufsichtsbehörde:
              </span>{" "}
              {supervisoryAuthority}
            </div>
          ) : (
            <div
              className="rounded-r-lg border-l-2 border-amber-500 bg-amber-50 px-4 py-3 text-sm leading-relaxed text-amber-800 dark:bg-amber-950/30 dark:text-amber-300"
              role="note"
            >
              Es ist noch keine zuständige Aufsichtsbehörde hinterlegt. Bitte unter{" "}
              <Link
                href="/dashboard/admin/legal"
                className="font-medium underline underline-offset-4"
              >
                Administration → Rechtliche Angaben
              </Link>{" "}
              ergänzen.
            </div>
          )}
        </CardContent>
      </Card>

      <Card id="informationen-bereithalten" className="scroll-mt-8">
        <CardHeader>
          <CardTitle className="text-base">
            C. Welche Informationen bereithalten?
          </CardTitle>
          <CardDescription>
            Diese Angaben erleichtern Bewertung und ggf. Meldung eines Vorfalls.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="grid gap-1.5 text-sm sm:grid-cols-2">
            {INCIDENT_INFO_CHECKLIST.map((item) => (
              <li key={item} className="flex gap-2">
                <span aria-hidden className="mt-0.5 text-primary">•</span>
                <span className="text-foreground">{item}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <Card id="72-stunden" className="scroll-mt-8">
        <CardHeader>
          <CardTitle className="text-base">D. 72-Stunden-Hinweis</CardTitle>
          <CardDescription>Orientierung, keine automatische Meldung.</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-1.5 text-sm">
            <li className="flex gap-2">
              <span aria-hidden className="mt-0.5 text-amber-600">•</span>
              <span className="text-foreground">
                Die 72-Stunden-Frist beginnt nach Kenntnisnahme des Vorfalls.
              </span>
            </li>
            <li className="flex gap-2">
              <span aria-hidden className="mt-0.5 text-amber-600">•</span>
              <span className="text-foreground">
                PAOLO zeigt bei Datenschutzvorfällen eine grobe Orientierung
                (Entdeckt am + 72 Stunden) an.
              </span>
            </li>
            <li className="flex gap-2">
              <span aria-hidden className="mt-0.5 text-amber-600">•</span>
              <span className="text-foreground">
                Ob, wann und an wen gemeldet wird, ist die rechtliche Bewertung
                des Betreibers bzw. der/des Datenschutzbeauftragten. PAOLO
                versendet keine automatische Meldung.
              </span>
            </li>
          </ul>
        </CardContent>
      </Card>

      <Card id="dokumentation-ohne-meldung" className="scroll-mt-8">
        <CardHeader>
          <CardTitle className="text-base">
            E. Dokumentation auch ohne Meldung
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-foreground">
            Auch wenn keine Meldung an die Aufsichtsbehörde erfolgt, sollten
            Entscheidung und Begründung dokumentiert werden (Rechenschaftspflicht).
            In PAOLO lässt sich dies je Vorfall unter{" "}
            <Link
              href="/dashboard/privacy/incidents"
              className="font-medium underline underline-offset-4"
            >
              Datenschutzvorfälle
            </Link>{" "}
            festhalten.
          </p>
        </CardContent>
      </Card>

      <p className="text-sm text-muted-foreground">
        <Link
          href="/dashboard/admin"
          className="underline underline-offset-4 hover:text-foreground"
        >
          Zurück zur Administration
        </Link>
      </p>
    </main>
  )
}
