"use client"

import { useActionState, useEffect, useState } from "react"
import { useRouter } from "next/navigation"

import {
  createPrivacyIncident,
  updatePrivacyIncident,
  type PrivacyIncidentActionState,
} from "@/lib/actions/privacy-incidents"
import {
  INCIDENT_NOTIFICATION_DECISION_LABELS,
  INCIDENT_NOTIFICATION_DECISION_VALUES,
  INCIDENT_RISK_LABELS,
  INCIDENT_RISK_VALUES,
  INCIDENT_STATUS_LABELS,
  INCIDENT_STATUS_VALUES,
  type IncidentNotificationDecision,
  type IncidentRisk,
  type IncidentStatus,
} from "@/lib/constants/privacy-incidents"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

const initialState: PrivacyIncidentActionState = { success: false, message: "" }

const labelClass = "text-sm font-medium text-foreground"
const fieldWrap = "space-y-1.5"

function Message({ state }: { state: PrivacyIncidentActionState }) {
  if (!state.message) return null
  return (
    <p
      className={`text-sm ${
        state.success ? "text-emerald-600" : "text-destructive"
      }`}
    >
      {state.message}
    </p>
  )
}

// ─── Erfassen ────────────────────────────────────────────────────────────────

export function CreateIncidentForm() {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [state, formAction, isPending] = useActionState(
    createPrivacyIncident,
    initialState
  )

  useEffect(() => {
    if (state.success) router.refresh()
  }, [state, router])

  if (!open) {
    return (
      <Button type="button" onClick={() => setOpen(true)}>
        Datenschutzvorfall erfassen
      </Button>
    )
  }

  return (
    <form action={formAction} className="space-y-4 rounded-md border bg-muted/40 p-4">
      <p className="text-sm font-semibold text-foreground">
        Neuen Datenschutzvorfall erfassen
      </p>

      <div className={fieldWrap}>
        <label htmlFor="inc-title" className={labelClass}>
          Titel
        </label>
        <Input id="inc-title" name="title" maxLength={200} required />
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div className={fieldWrap}>
          <label htmlFor="inc-discoveredAt" className={labelClass}>
            Entdeckt am
          </label>
          <input
            id="inc-discoveredAt"
            name="discoveredAt"
            type="datetime-local"
            className="flex h-10 w-full rounded-md border border-input bg-white px-3 py-2 text-sm outline-none focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/40"
          />
        </div>
        <div className={fieldWrap}>
          <label htmlFor="inc-discoveredByText" className={labelClass}>
            Entdeckt durch
          </label>
          <Input
            id="inc-discoveredByText"
            name="discoveredByText"
            maxLength={200}
            placeholder="Name / Rolle / Quelle"
          />
        </div>
      </div>

      <div className={fieldWrap}>
        <label htmlFor="inc-description" className={labelClass}>
          Beschreibung
        </label>
        <Textarea id="inc-description" name="description" rows={4} required />
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div className={fieldWrap}>
          <label htmlFor="inc-affectedDataCategories" className={labelClass}>
            Betroffene Datenkategorien
          </label>
          <Textarea
            id="inc-affectedDataCategories"
            name="affectedDataCategories"
            rows={2}
            placeholder="z. B. Name, Kontaktdaten, Meldungsinhalte"
          />
        </div>
        <div className={fieldWrap}>
          <label htmlFor="inc-affectedPersonsEstimate" className={labelClass}>
            Geschätzte Zahl Betroffener
          </label>
          <Input
            id="inc-affectedPersonsEstimate"
            name="affectedPersonsEstimate"
            maxLength={200}
            placeholder="z. B. ca. 20 oder unbekannt"
          />
        </div>
      </div>

      <div className={fieldWrap}>
        <label htmlFor="inc-immediateActions" className={labelClass}>
          Sofortmaßnahmen
        </label>
        <Textarea id="inc-immediateActions" name="immediateActions" rows={2} />
      </div>

      <div className={fieldWrap}>
        <label htmlFor="inc-riskAssessment" className={labelClass}>
          Risikobewertung
        </label>
        <Select name="riskAssessment" defaultValue="unknown">
          <SelectTrigger id="inc-riskAssessment" className="w-full sm:w-64">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {INCIDENT_RISK_VALUES.map((v) => (
              <SelectItem key={v} value={v}>
                {INCIDENT_RISK_LABELS[v]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <Button type="submit" disabled={isPending}>
          {isPending ? "Speichert…" : "Vorfall erfassen"}
        </Button>
        <Button
          type="button"
          variant="ghost"
          disabled={isPending}
          onClick={() => setOpen(false)}
        >
          Abbrechen
        </Button>
        <Message state={state} />
      </div>
    </form>
  )
}

// ─── Bearbeiten ──────────────────────────────────────────────────────────────

type EditProps = {
  incidentId: string
  status: IncidentStatus
  riskAssessment: IncidentRisk
  notificationDecision: IncidentNotificationDecision
  decisionReason: string | null
  followUpActions: string | null
}

export function IncidentEditForm(props: EditProps) {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [state, formAction, isPending] = useActionState(
    updatePrivacyIncident,
    initialState
  )

  // Status, Risiko und Meldeentscheidung stehen als Badges direkt ueber diesem
  // Formular — sie zeigen den gespeicherten Serverzustand. Die Auswahlfelder
  // zeigen daneben den lokalen Entwurf. Beides ist fuer sich korrekt, aber ohne
  // Kennzeichnung stehen zwei Wahrheiten unvermittelt nebeneinander.
  //
  // Die Selects bleiben unkontrolliert (defaultValue + `key` aus dem
  // Serverwert, siehe PR #23) — mitgeschrieben wird nur, was fuer den
  // Vergleich noetig ist. Die Freitextfelder bleiben bewusst aussen vor: Sie
  // haben keine Entsprechung in den Badges.
  const [status, setStatus] = useState<IncidentStatus>(props.status)
  const [risk, setRisk] = useState<IncidentRisk>(props.riskAssessment)
  const [notification, setNotification] =
    useState<IncidentNotificationDecision>(props.notificationDecision)

  // Aendert sich der gespeicherte Wert von aussen — etwa weil eine zweite
  // Person denselben Vorfall speichert und `router.refresh()` neue Props
  // liefert —, mountet das Select ueber seinen `key` auf den neuen Serverwert
  // um. Ohne diesen Abgleich blieben die Vergleichswerte auf der alten Auswahl
  // stehen, und der Hinweis stuende da, obwohl das Feld genau den gespeicherten
  // Wert zeigt (#30).
  //
  // Der Entwurf wird dabei bewusst verworfen statt gemeldet: Das `key`-Remount
  // ueberschreibt die sichtbare Auswahl ohnehin schon: Der Abgleich zieht nur
  // nach, was das Feld bereits anzeigt. Ein Konfliktdialog waere ein eigenes,
  // groesseres Thema.
  //
  // Zuweisung waehrend des Renderns statt im Effekt: React verwirft den
  // angefangenen Durchlauf und rendert sofort mit den neuen Werten neu, ohne
  // dass ein Zwischenzustand sichtbar wird. Dasselbe Muster nutzt bereits
  // `retention-review.tsx`.
  const [prevServerValues, setPrevServerValues] = useState({
    status: props.status,
    risk: props.riskAssessment,
    notification: props.notificationDecision,
  })
  if (
    prevServerValues.status !== props.status ||
    prevServerValues.risk !== props.riskAssessment ||
    prevServerValues.notification !== props.notificationDecision
  ) {
    setPrevServerValues({
      status: props.status,
      risk: props.riskAssessment,
      notification: props.notificationDecision,
    })
    setStatus(props.status)
    setRisk(props.riskAssessment)
    setNotification(props.notificationDecision)
  }

  // Waehrend des Speicherns unterdrueckt, damit der Hinweis nicht neben der
  // Erfolgsmeldung steht.
  const isDraft =
    !isPending &&
    (status !== props.status ||
      risk !== props.riskAssessment ||
      notification !== props.notificationDecision)

  useEffect(() => {
    if (state.success) router.refresh()
  }, [state, router])

  if (!open) {
    return (
      <Button type="button" variant="outline" size="sm" onClick={() => setOpen(true)}>
        Bearbeiten
      </Button>
    )
  }

  return (
    <form action={formAction} className="space-y-4 rounded-md border bg-background p-4">
      <input type="hidden" name="incidentId" value={props.incidentId} />

      <div className="grid gap-4 sm:grid-cols-3">
        <div className={fieldWrap}>
          <label htmlFor={`status-${props.incidentId}`} className={labelClass}>
            Status
          </label>
          <Select
            key={props.status}
            name="status"
            defaultValue={props.status}
            onValueChange={(v) => setStatus(v as IncidentStatus)}
          >
            <SelectTrigger id={`status-${props.incidentId}`} className="w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {INCIDENT_STATUS_VALUES.map((v) => (
                <SelectItem key={v} value={v}>
                  {INCIDENT_STATUS_LABELS[v]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className={fieldWrap}>
          <label htmlFor={`risk-${props.incidentId}`} className={labelClass}>
            Risiko
          </label>
          <Select
            key={props.riskAssessment}
            name="riskAssessment"
            defaultValue={props.riskAssessment}
            onValueChange={(v) => setRisk(v as IncidentRisk)}
          >
            <SelectTrigger id={`risk-${props.incidentId}`} className="w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {INCIDENT_RISK_VALUES.map((v) => (
                <SelectItem key={v} value={v}>
                  {INCIDENT_RISK_LABELS[v]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className={fieldWrap}>
          <label htmlFor={`notif-${props.incidentId}`} className={labelClass}>
            Meldeentscheidung
          </label>
          <Select
            key={props.notificationDecision}
            name="notificationDecision"
            defaultValue={props.notificationDecision}
            onValueChange={(v) =>
              setNotification(v as IncidentNotificationDecision)
            }
          >
            <SelectTrigger id={`notif-${props.incidentId}`} className="w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {INCIDENT_NOTIFICATION_DECISION_VALUES.map((v) => (
                <SelectItem key={v} value={v}>
                  {INCIDENT_NOTIFICATION_DECISION_LABELS[v]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {isDraft ? (
        <p
          className="text-xs font-medium text-amber-700 dark:text-amber-400"
          role="status"
        >
          Ungespeicherte Änderung – wird erst mit „Speichern“ wirksam.
        </p>
      ) : null}

      <div className={fieldWrap}>
        <label htmlFor={`reason-${props.incidentId}`} className={labelClass}>
          Begründung der Meldeentscheidung
        </label>
        <Textarea
          id={`reason-${props.incidentId}`}
          name="decisionReason"
          rows={2}
          defaultValue={props.decisionReason ?? ""}
        />
      </div>

      <div className={fieldWrap}>
        <label htmlFor={`followup-${props.incidentId}`} className={labelClass}>
          Folgemaßnahmen
        </label>
        <Textarea
          id={`followup-${props.incidentId}`}
          name="followUpActions"
          rows={2}
          defaultValue={props.followUpActions ?? ""}
        />
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <Button type="submit" size="sm" disabled={isPending}>
          {isPending ? "Speichert…" : "Speichern"}
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          disabled={isPending}
          onClick={() => setOpen(false)}
        >
          Abbrechen
        </Button>
        <Message state={state} />
      </div>
    </form>
  )
}
