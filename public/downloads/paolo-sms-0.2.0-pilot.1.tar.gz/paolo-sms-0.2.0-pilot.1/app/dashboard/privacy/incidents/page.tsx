import { appAuth } from "@/lib/auth"
import Link from "next/link"
import { notFound, redirect } from "next/navigation"
import { desc } from "drizzle-orm"

import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { hasSafetyEditRole } from "@/lib/constants/roles"
import { db } from "@/lib/db"
import { privacyIncidents } from "@/lib/db/schema"
import {
  INCIDENT_NOTIFICATION_DEADLINE_HOURS,
  INCIDENT_NOTIFICATION_DECISION_LABELS,
  INCIDENT_RISK_LABELS,
  INCIDENT_STATUS_LABELS,
  type IncidentNotificationDecision,
  type IncidentRisk,
  type IncidentStatus,
} from "@/lib/constants/privacy-incidents"

import { Badge } from "@/components/ui/badge"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { PageHeader } from "@/components/ui/page-header"

import { CreateIncidentForm, IncidentEditForm } from "./incident-forms"

const dtFormatter = new Intl.DateTimeFormat("de-DE", {
  dateStyle: "medium",
  timeStyle: "short",
})

// In Modul-Helper gekapselt, damit die Render-Purity-Regel nicht anschlägt.
function nowMs(): number {
  return Date.now()
}

function statusLabel(v: string): string {
  return INCIDENT_STATUS_LABELS[v as IncidentStatus] ?? v
}
function riskLabel(v: string): string {
  return INCIDENT_RISK_LABELS[v as IncidentRisk] ?? v
}
function notificationLabel(v: string): string {
  return (
    INCIDENT_NOTIFICATION_DECISION_LABELS[v as IncidentNotificationDecision] ?? v
  )
}

export default async function PrivacyIncidentsPage() {
  const { userId } = await appAuth()
  if (!userId) redirect("/sign-in")

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) notFound()

  const incidents = await db
    .select()
    .from(privacyIncidents)
    .orderBy(desc(privacyIncidents.createdAt))

  const now = nowMs()

  return (
    <main className="mx-auto max-w-4xl space-y-8 px-4 py-8 sm:px-8">
      <PageHeader
        title="Datenschutzvorfälle"
        subtitle="Dokumentation und Nachverfolgung von Datenschutzvorfällen (Incident-Response)."
      />

      <div
        className="rounded-r-lg border-l-2 border-amber-500 bg-amber-50 px-4 py-3 text-sm leading-relaxed text-amber-800 dark:bg-amber-950/30 dark:text-amber-300"
        role="note"
      >
        PAOLO dokumentiert Vorfälle nur. Ob eine Meldung an die Aufsichtsbehörde
        oder eine Benachrichtigung Betroffener erforderlich ist, muss der Betreiber
        bzw. die/der Datenschutzbeauftragte prüfen. Es wird{" "}
        <span className="font-medium">keine automatische Meldung</span> versendet.
        Die 72-Stunden-Frist (Art. 33 DSGVO) wird nur als grobe Orientierung
        angezeigt.
      </div>

      <CreateIncidentForm />

      <Card>
        <CardHeader>
          <CardTitle className="text-base">
            Erfasste Vorfälle ({incidents.length})
          </CardTitle>
          <CardDescription>Neueste zuerst.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {incidents.length === 0 ? (
            <p className="rounded-lg border border-dashed px-4 py-6 text-center text-sm text-muted-foreground">
              Noch keine Datenschutzvorfälle erfasst.
            </p>
          ) : (
            incidents.map((inc) => {
              const deadline = inc.discoveredAt
                ? new Date(
                    inc.discoveredAt.getTime() +
                      INCIDENT_NOTIFICATION_DEADLINE_HOURS * 60 * 60 * 1000
                  )
                : null
              const isOpen = inc.status !== "notified" && inc.status !== "closed"
              const deadlinePassed = deadline ? deadline.getTime() < now : false

              return (
                <div key={inc.id} className="space-y-3 rounded-md border p-4">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <p className="font-medium text-foreground">{inc.title}</p>
                    <div className="flex flex-wrap gap-1.5">
                      <Badge variant="secondary" className="font-normal">
                        {statusLabel(inc.status)}
                      </Badge>
                      <Badge variant="outline" className="font-normal">
                        Risiko: {riskLabel(inc.riskAssessment)}
                      </Badge>
                      <Badge variant="outline" className="font-normal">
                        {notificationLabel(inc.notificationDecision)}
                      </Badge>
                    </div>
                  </div>

                  <dl className="grid gap-x-4 gap-y-1 text-sm sm:grid-cols-2">
                    <div>
                      <dt className="inline text-muted-foreground">Entdeckt am: </dt>
                      <dd className="inline">
                        {inc.discoveredAt ? dtFormatter.format(inc.discoveredAt) : "—"}
                      </dd>
                    </div>
                    <div>
                      <dt className="inline text-muted-foreground">
                        Entdeckt durch:{" "}
                      </dt>
                      <dd className="inline">{inc.discoveredByText ?? "—"}</dd>
                    </div>
                    {deadline ? (
                      <div className="sm:col-span-2">
                        <dt className="inline text-muted-foreground">
                          72-Stunden-Frist (Orientierung):{" "}
                        </dt>
                        <dd
                          className={`inline ${
                            deadlinePassed && isOpen
                              ? "font-medium text-amber-600 dark:text-amber-400"
                              : ""
                          }`}
                        >
                          {dtFormatter.format(deadline)}
                          {deadlinePassed && isOpen ? " · überschritten" : ""}
                        </dd>
                      </div>
                    ) : null}
                  </dl>

                  <p className="whitespace-pre-wrap text-sm text-muted-foreground">
                    {inc.description}
                  </p>

                  <dl className="space-y-1 text-sm">
                    {inc.affectedDataCategories ? (
                      <div>
                        <dt className="inline text-muted-foreground">
                          Betroffene Datenkategorien:{" "}
                        </dt>
                        <dd className="inline whitespace-pre-wrap">
                          {inc.affectedDataCategories}
                        </dd>
                      </div>
                    ) : null}
                    {inc.affectedPersonsEstimate ? (
                      <div>
                        <dt className="inline text-muted-foreground">
                          Geschätzte Zahl Betroffener:{" "}
                        </dt>
                        <dd className="inline">{inc.affectedPersonsEstimate}</dd>
                      </div>
                    ) : null}
                    {inc.immediateActions ? (
                      <div>
                        <dt className="inline text-muted-foreground">
                          Sofortmaßnahmen:{" "}
                        </dt>
                        <dd className="inline whitespace-pre-wrap">
                          {inc.immediateActions}
                        </dd>
                      </div>
                    ) : null}
                    {inc.decisionReason ? (
                      <div>
                        <dt className="inline text-muted-foreground">
                          Begründung Meldeentscheidung:{" "}
                        </dt>
                        <dd className="inline whitespace-pre-wrap">
                          {inc.decisionReason}
                        </dd>
                      </div>
                    ) : null}
                    {inc.followUpActions ? (
                      <div>
                        <dt className="inline text-muted-foreground">
                          Folgemaßnahmen:{" "}
                        </dt>
                        <dd className="inline whitespace-pre-wrap">
                          {inc.followUpActions}
                        </dd>
                      </div>
                    ) : null}
                    {inc.closedAt ? (
                      <div>
                        <dt className="inline text-muted-foreground">
                          Abgeschlossen am:{" "}
                        </dt>
                        <dd className="inline">{dtFormatter.format(inc.closedAt)}</dd>
                      </div>
                    ) : null}
                  </dl>

                  <IncidentEditForm
                    incidentId={inc.id}
                    status={inc.status as IncidentStatus}
                    riskAssessment={inc.riskAssessment as IncidentRisk}
                    notificationDecision={
                      inc.notificationDecision as IncidentNotificationDecision
                    }
                    decisionReason={inc.decisionReason}
                    followUpActions={inc.followUpActions}
                  />
                </div>
              )
            })
          )}
        </CardContent>
      </Card>

      <p className="text-sm text-muted-foreground">
        <Link
          href="/dashboard/privacy"
          className="underline underline-offset-4 hover:text-foreground"
        >
          Zurück zu den Datenschutzprozessen
        </Link>
      </p>
    </main>
  )
}
