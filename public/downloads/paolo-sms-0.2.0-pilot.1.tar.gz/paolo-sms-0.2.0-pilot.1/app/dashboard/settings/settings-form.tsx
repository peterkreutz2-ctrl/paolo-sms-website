"use client"

import { useActionState, useState } from "react"

import {
  updateOrganizationDisplayName,
  updateOrganizationSettings,
  updatePublicReportStatusVisibility,
  updateSmsGovernanceSettings,
  type OrganizationSettingsActionState,
  type PublicReportStatusVisibilityState,
} from "@/lib/actions/organization-settings"
import { ORGANIZATION_DISPLAY_NAME_MAX_LENGTH } from "@/lib/constants/organization-display-name"
import {
  SAFETY_MEETING_INTERVAL_MAX_MONTHS,
  SAFETY_MEETING_INTERVAL_MIN_MONTHS,
  SAFETY_MEETING_INTERVAL_WARNING,
  shouldWarnAboutSafetyMeetingInterval,
} from "@/lib/constants/safety-meeting-interval"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

type Props = {
  currentValue: number
  currentRetentionReviewIntervalMonths: number | null
}

const initialState: OrganizationSettingsActionState = {
  success: false,
  message: "",
}

export function OrganizationSettingsForm({
  currentValue,
  currentRetentionReviewIntervalMonths,
}: Props) {
  const [state, formAction, isPending] = useActionState(
    updateOrganizationSettings,
    initialState
  )

  // Eigener Zustand nur fuer den Warnhinweis. Der Wert wird weiterhin ueber
  // FormData abgeschickt; die Eingabe ist kontrolliert, damit der Hinweis
  // schon beim Tippen erscheint und nicht erst nach dem Speichern.
  const [intervalMonths, setIntervalMonths] = useState(String(currentValue))
  const parsedInterval = Number.parseInt(intervalMonths, 10)
  const showIntervalWarning = shouldWarnAboutSafetyMeetingInterval(
    Number.isNaN(parsedInterval) ? null : parsedInterval
  )

  return (
    <form action={formAction} className="space-y-6">
      <fieldset className="space-y-1.5">
        <legend className="text-sm font-medium">
          Turnus Sicherheitsbesprechung (Monate)
        </legend>
        <p className="text-sm text-muted-foreground">
          Nach wie vielen Monaten spätestens eine Sicherheitsbesprechung
          stattfinden soll. Zulässig sind{" "}
          {SAFETY_MEETING_INTERVAL_MIN_MONTHS} bis{" "}
          {SAFETY_MEETING_INTERVAL_MAX_MONTHS} Monate.
        </p>
        <Input
          id="safetyMeetingIntervalMonths"
          name="safetyMeetingIntervalMonths"
          type="number"
          min={SAFETY_MEETING_INTERVAL_MIN_MONTHS}
          max={SAFETY_MEETING_INTERVAL_MAX_MONTHS}
          value={intervalMonths}
          onChange={(e) => setIntervalMonths(e.target.value)}
          aria-describedby={
            showIntervalWarning ? "safetyMeetingIntervalWarning" : undefined
          }
          className="w-32 bg-white"
          required
        />
        {/* Hinweis, keine Fehlermeldung: Der Wert bleibt zulaessig und
            speicherbar. Deshalb role="note" statt "alert" und amber statt
            destructive — die Entscheidung liegt beim Betreiber. */}
        {showIntervalWarning ? (
          <p
            id="safetyMeetingIntervalWarning"
            role="note"
            className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900 dark:border-amber-900/60 dark:bg-amber-950/40 dark:text-amber-200"
          >
            {SAFETY_MEETING_INTERVAL_WARNING}
          </p>
        ) : null}
      </fieldset>
      <fieldset className="space-y-1.5">
        <legend className="text-sm font-medium">
          Anonymisierungsprüfung nach Abschluss (Monate)
        </legend>
        <p className="text-sm text-muted-foreground">
          Nach wie vielen Monaten nach Abschluss/Ausblenden einer Meldung an
          eine Prüfung erinnert werden soll (Datenminimierung). Leer lassen,
          um die Erinnerung zu deaktivieren. Die konkrete Frist ist eine
          Betreiberentscheidung — PAOLO gibt sie nicht vor.
        </p>
        <Input
          id="reportRetentionReviewIntervalMonths"
          name="reportRetentionReviewIntervalMonths"
          type="number"
          min={1}
          max={600}
          defaultValue={currentRetentionReviewIntervalMonths ?? ""}
          placeholder="deaktiviert"
          className="w-32 bg-white"
        />
      </fieldset>
      <div className="flex items-center gap-3">
        <Button type="submit" disabled={isPending}>
          {isPending ? "Speichert..." : "Speichern"}
        </Button>
        {state.message ? (
          <p
            className={`text-sm ${state.success ? "text-emerald-600" : "text-destructive"}`}
          >
            {state.message}
          </p>
        ) : null}
      </div>
    </form>
  )
}

// ─── Anzeigename der Organisation (#117) ─────────────────────────────────────
//
// Textfeld mit defaultValue: Anders als das Kontrollkaestchen unten faellt es
// nach dem Zuruecksetzen des Formulars auf den zuletzt gerenderten Wert zurueck,
// und der ist nach revalidatePath der gespeicherte.
export function OrganizationDisplayNameForm({
  currentValue,
}: {
  currentValue: string
}) {
  const [state, formAction, isPending] = useActionState(
    updateOrganizationDisplayName,
    initialState
  )

  return (
    <form action={formAction} className="space-y-4">
      <div className="space-y-1.5">
        <label htmlFor="organizationDisplayName" className="text-sm font-medium">
          Anzeigename der Organisation
        </label>
        <Input
          id="organizationDisplayName"
          name="organizationDisplayName"
          defaultValue={currentValue}
          maxLength={ORGANIZATION_DISPLAY_NAME_MAX_LENGTH}
          placeholder="z. B. Flugschule Hot Sport"
          aria-describedby="organizationDisplayNameHint"
          autoComplete="off"
          className="bg-white"
        />
        <p
          id="organizationDisplayNameHint"
          className="text-sm text-muted-foreground"
        >
          Höchstens {ORGANIZATION_DISPLAY_NAME_MAX_LENGTH} Zeichen. Leer lassen,
          um nur „PAOLO SMS“ anzuzeigen.
        </p>
        {/* Hinweis, keine Fehlermeldung: Die Angabe ist zulaessig; der Betreiber
            soll aber wissen, wer sie sieht. */}
        <p
          role="note"
          className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900 dark:border-amber-900/60 dark:bg-amber-950/40 dark:text-amber-200"
        >
          Der Anzeigename ist öffentlich sichtbar: Er steht für alle Besucher,
          auch ohne Anmeldung, im Kopf der Anwendung. Bitte keine
          personenbezogenen oder vertraulichen Angaben eintragen.
        </p>
      </div>
      <div className="flex items-center gap-3">
        <Button type="submit" disabled={isPending}>
          {isPending ? "Speichert..." : "Speichern"}
        </Button>
        {state.message ? (
          <p
            role="status"
            className={`text-sm ${state.success ? "text-emerald-600" : "text-destructive"}`}
          >
            {state.message}
          </p>
        ) : null}
      </div>
    </form>
  )
}

export type SmsGovernanceValues = {
  accountableExecutiveName: string
  accountableExecutiveFunction: string
  accountableExecutiveContact: string
  accountableExecutiveTerm: string
  safetyManagerName: string
  safetyManagerFunction: string
  safetyManagerContact: string
  safetyManagerTerm: string
}

type GovernanceProps = {
  values: SmsGovernanceValues
}

function GovernanceField({
  id,
  name,
  label,
  defaultValue,
  placeholder,
}: {
  id: string
  name: string
  label: string
  defaultValue: string
  placeholder?: string
}) {
  return (
    <div className="space-y-1.5">
      <label htmlFor={id} className="text-sm font-medium">
        {label}
      </label>
      <Input
        id={id}
        name={name}
        defaultValue={defaultValue}
        placeholder={placeholder}
        maxLength={500}
        className="bg-white"
      />
    </div>
  )
}

export function SmsGovernanceForm({ values }: GovernanceProps) {
  const [state, formAction, isPending] = useActionState(
    updateSmsGovernanceSettings,
    initialState
  )

  return (
    <form action={formAction} className="space-y-6">
      <fieldset className="space-y-3">
        <legend className="text-sm font-semibold text-foreground">
          Accountable Executive (verantwortliche Leitung)
        </legend>
        <p className="text-sm text-muted-foreground">
          Trägt die übergeordnete Verantwortung für die organisatorischen
          Voraussetzungen und die Funktionsfähigkeit des SMS (Accountability /
          Führungsverantwortung), nicht für die Sicherheit jedes einzelnen
          Fluges. Im Verein kann ein entsprechend benanntes Vorstandsmitglied
          die Funktion wahrnehmen, in der Flugschule etwa der Geschäftsführer
          oder Ausbildungsleiter, jeweils im Rahmen der bestehenden Befugnisse.
        </p>
        <div className="grid gap-3 sm:grid-cols-2">
          <GovernanceField
            id="ae-name"
            name="accountableExecutiveName"
            label="Name"
            defaultValue={values.accountableExecutiveName}
          />
          <GovernanceField
            id="ae-function"
            name="accountableExecutiveFunction"
            label="Funktion"
            defaultValue={values.accountableExecutiveFunction}
            placeholder="z. B. Vorstand, Ausbildungsleiter"
          />
          <GovernanceField
            id="ae-contact"
            name="accountableExecutiveContact"
            label="Kontakt"
            defaultValue={values.accountableExecutiveContact}
            placeholder="E-Mail oder Telefon"
          />
          <GovernanceField
            id="ae-term"
            name="accountableExecutiveTerm"
            label="Zeitraum der Bestellung"
            defaultValue={values.accountableExecutiveTerm}
            placeholder="z. B. seit 01/2026, unbefristet"
          />
        </div>
      </fieldset>

      <fieldset className="space-y-3">
        <legend className="text-sm font-semibold text-foreground">
          Safety Manager
        </legend>
        <p className="text-sm text-muted-foreground">
          Übernimmt delegierbare operative SMS-Aufgaben (Responsibility /
          operative Verantwortlichkeit) und unterstützt Umsetzung, Bearbeitung
          und Nachverfolgung des SMS.
        </p>
        <div className="grid gap-3 sm:grid-cols-2">
          <GovernanceField
            id="sm-name"
            name="safetyManagerName"
            label="Name"
            defaultValue={values.safetyManagerName}
          />
          <GovernanceField
            id="sm-function"
            name="safetyManagerFunction"
            label="Funktion"
            defaultValue={values.safetyManagerFunction}
            placeholder="z. B. Sicherheitsbeauftragter"
          />
          <GovernanceField
            id="sm-contact"
            name="safetyManagerContact"
            label="Kontakt"
            defaultValue={values.safetyManagerContact}
            placeholder="E-Mail oder Telefon"
          />
          <GovernanceField
            id="sm-term"
            name="safetyManagerTerm"
            label="Zeitraum der Bestellung"
            defaultValue={values.safetyManagerTerm}
            placeholder="z. B. seit 01/2026, unbefristet"
          />
        </div>
      </fieldset>

      <div className="flex items-center gap-3">
        <Button type="submit" disabled={isPending}>
          {isPending ? "Speichert..." : "Speichern"}
        </Button>
        {state.message ? (
          <p
            className={`text-sm ${state.success ? "text-emerald-600" : "text-destructive"}`}
          >
            {state.message}
          </p>
        ) : null}
      </div>
    </form>
  )
}

// ─── Oeffentliche Statusrueckmeldungen ein-/ausschalten ──────────────────────
//
// Bewusst ein Kontrollkaestchen und kein neu gebauter Umschalter: Das Projekt
// hat keine Switch-Komponente, und ein Kontrollkaestchen mit Beschriftung ist
// mit Tastatur und Vorlesesoftware ohne Zusatzarbeit bedienbar.
//
// ─── Warum die Anzeige vom Server kommt ──────────────────────────────────────
//
// Beim lokalen Funktionstest zeigte das Kaestchen nach dem Speichern das
// GEGENTEIL der Auswahl, obwohl gespeicherter Wert und oeffentliche Seite
// stimmten. Ursache: React setzt ein Formular nach einer Form-Action zurueck.
// Das Kaestchen fiel dabei auf den Wert des urspruenglichen Server-Renderings
// zurueck, und der lokale Zustand wurde nie mit der Antwort abgeglichen — ein
// erneutes Rendern allein half nicht, weil sich der lokale Wert aus Sicht von
// React gar nicht geaendert hatte und die Zuruecksetzung im DOM deshalb stehen
// blieb.
//
// Die Anzeige richtet sich deshalb nach dem, was der Server zuletzt gesagt hat:
// nach dem Speichern der zurueckgegebene Wert, sonst der geladene. `key`
// erzwingt bei jedem abgeschlossenen Vorgang einen frischen Knoten — auch dann,
// wenn zweimal dasselbe gespeichert wurde und ein Wertvergleich nichts
// bemerken wuerde.

function PublicReportStatusVisibilityFields({ enabled }: { enabled: boolean }) {
  // Nur fuer den Erklaertext, damit er der Auswahl sofort folgt. Der
  // abgeschickte Wert kommt aus dem DOM, nicht von hier.
  const [checked, setChecked] = useState(enabled)

  return (
    <div className="flex items-start gap-3">
      <input
        id="publicReportStatusEnabled"
        name="publicReportStatusEnabled"
        type="checkbox"
        defaultChecked={enabled}
        onChange={(event) => setChecked(event.target.checked)}
        className="mt-1 h-4 w-4 rounded border-input accent-primary"
      />
      <div className="space-y-1">
        <label
          htmlFor="publicReportStatusEnabled"
          className="text-sm font-medium text-foreground"
        >
          Statusrückmeldungen öffentlich anzeigen
        </label>
        <p className="text-sm text-muted-foreground">
          {checked ? (
            <>
              Auf „Sicherheitsinformationen“ erscheint die Box „Status von
              Sicherheitsmeldungen“ mit Meldungscode und Bearbeitungsstatus.
              Meldungsinhalte, Namen und Datumsangaben werden dort nicht
              veröffentlicht.
            </>
          ) : (
            <>
              Die Box erscheint nicht, und es werden keine Statusdaten
              öffentlich bereitgestellt. Meldungen, Meldungscodes und der
              Bearbeitungsstand bleiben unverändert erhalten; die
              Dreimonatsfrist läuft weiter. Nach dem Wiedereinschalten sind die
              weiterhin gültigen Rückmeldungen wieder sichtbar.
            </>
          )}
        </p>
      </div>
    </div>
  )
}

export function PublicReportStatusVisibilityForm({
  enabled,
}: {
  enabled: boolean
}) {
  const [state, formAction, isPending] = useActionState(
    updatePublicReportStatusVisibility,
    initialState as PublicReportStatusVisibilityState
  )

  // Der zuletzt gespeicherte Wert schlaegt den beim Laden uebergebenen.
  const storedValue = state.enabled ?? enabled

  return (
    <form action={formAction} className="space-y-4">
      <PublicReportStatusVisibilityFields
        key={`${storedValue}-${state.resultId ?? 0}`}
        enabled={storedValue}
      />

      <div className="flex items-center gap-3">
        <Button type="submit" disabled={isPending}>
          {isPending ? "Wird gespeichert…" : "Speichern"}
        </Button>
        {state.message ? (
          <p
            className={
              state.success
                ? "text-sm text-emerald-700 dark:text-emerald-500"
                : "text-sm text-destructive"
            }
            role="status"
          >
            {state.message}
          </p>
        ) : null}
      </div>
    </form>
  )
}
