import { appAuth } from "@/lib/auth"
import { notFound, redirect } from "next/navigation"

import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { hasSafetyEditRole } from "@/lib/constants/roles"
import { db } from "@/lib/db"
import { organizations } from "@/lib/db/schema"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { PageHeader } from "@/components/ui/page-header"

import {
  OrganizationDisplayNameForm,
  OrganizationSettingsForm,
  PublicReportStatusVisibilityForm,
  SmsGovernanceForm,
} from "./settings-form"

export default async function SettingsPage() {
  const { userId } = await appAuth()
  if (!userId) redirect("/sign-in")

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) notFound()

  const [organization] = await db.select().from(organizations).limit(1)
  if (!organization) notFound()

  return (
    <main className="mx-auto max-w-2xl space-y-8 px-4 py-8 sm:px-8">
      <PageHeader
        title="Organisationseinstellungen"
        subtitle="Allgemeine Einstellungen der Organisation."
      />

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Anzeigename</CardTitle>
          <CardDescription>
            Erscheint neben „PAOLO SMS“ im Kopf der Anwendung, damit
            verschiedene Installationen unterscheidbar sind – zum Beispiel
            „Flugschule Hot Sport“ oder „Verein Albatros“.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <OrganizationDisplayNameForm
            currentValue={organization.displayName ?? ""}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Fristen &amp; Erinnerungen</CardTitle>
          <CardDescription>
            Turnus der Sicherheitsbesprechung sowie optionale Erinnerung zur
            datenschutzrechtlichen Prüfung abgeschlossener Meldungen.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <OrganizationSettingsForm
            currentValue={organization.safetyMeetingIntervalMonths}
            currentRetentionReviewIntervalMonths={
              organization.reportRetentionReviewIntervalMonths ?? null
            }
          />
        </CardContent>
      </Card>

      {/* Position laut Antrag: unterhalb von „Fristen & Erinnerungen“ und
          oberhalb von „SMS-Verantwortung“. */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">
            Öffentliche Statusrückmeldungen
          </CardTitle>
          <CardDescription>
            Steuert die Box „Status von Sicherheitsmeldungen“ auf der
            öffentlichen Seite „Sicherheitsinformationen“. Dort erscheinen
            ausschließlich der neutrale Meldungscode und der Bearbeitungsstatus
            — damit Meldende sehen, dass ihre Meldung ankommt und bearbeitet
            wird. Abgeschlossene Meldungen verschwinden drei Monate nach dem
            Abschluss, ausgeblendete sofort.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <PublicReportStatusVisibilityForm
            enabled={organization.publicReportStatusEnabled}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">
            SMS-Verantwortung (dokumentarisch)
          </CardTitle>
          <CardDescription>
            Hält fest, wer im SMS benannt ist. Die Angaben dienen nur der
            Dokumentation und Erinnerung, erzeugen keine Programmberechtigung und
            ersetzen keine organisatorische Bestellung, Unterschrift oder
            rechtliche Benennung. Die Rollen im Programm bleiben unverändert:
            admin, safety_manager, instructor, member.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="rounded-md bg-muted/40 p-4 text-sm text-muted-foreground">
            <p className="mb-2 font-medium text-foreground">
              Accountability vs. Responsibility
            </p>
            <ul className="list-disc space-y-1 pl-5">
              <li>
                <span className="font-medium text-foreground">
                  Accountable Executive (verantwortliche Leitung)
                </span>{" "}
                trägt die übergeordnete Verantwortung für die organisatorischen
                Voraussetzungen und die Funktionsfähigkeit des SMS
                (Accountability / Führungsverantwortung) – nicht für die
                Sicherheit jedes einzelnen Fluges. Im Verein kann ein
                entsprechend benanntes Vorstandsmitglied die Funktion
                wahrnehmen, in der Flugschule etwa der Geschäftsführer oder
                Ausbildungsleiter, jeweils im Rahmen der bestehenden Befugnisse.
              </li>
              <li>
                <span className="font-medium text-foreground">
                  Safety Manager
                </span>{" "}
                übernimmt delegierbare operative SMS-Aufgaben (Responsibility /
                operative Verantwortlichkeit) und unterstützt Umsetzung,
                Bearbeitung und Nachverfolgung des SMS.
              </li>
              <li>
                PAOLO bildet die Benennung nur ab und macht sie sichtbar. Es
                entsteht keine zusätzliche Programmberechtigung.
              </li>
            </ul>
          </div>

          <SmsGovernanceForm
            values={{
              accountableExecutiveName:
                organization.accountableExecutiveName ?? "",
              accountableExecutiveFunction:
                organization.accountableExecutiveFunction ?? "",
              accountableExecutiveContact:
                organization.accountableExecutiveContact ?? "",
              accountableExecutiveTerm:
                organization.accountableExecutiveTerm ?? "",
              safetyManagerName: organization.safetyManagerName ?? "",
              safetyManagerFunction: organization.safetyManagerFunction ?? "",
              safetyManagerContact: organization.safetyManagerContact ?? "",
              safetyManagerTerm: organization.safetyManagerTerm ?? "",
            }}
          />
        </CardContent>
      </Card>
    </main>
  )
}
