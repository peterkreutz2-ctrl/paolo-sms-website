import Link from "next/link"

import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { ROLE_LABELS, hasReportReadRole } from "@/lib/constants/roles"

import { PageHeader } from "@/components/ui/page-header"

/**
 * Not-Found-Boundary für den gesamten Dashboard-Bereich. Sie liegt bewusst in
 * `app/dashboard/`, damit sie innerhalb von `app/dashboard/layout.tsx` gerendert
 * wird: Ohne diese Datei greift die Root-Boundary, der Dashboard-Header samt
 * Abmelde-Button verschwindet und angemeldete Benutzer sitzen auf der
 * englischen Next.js-Standardseite fest.
 *
 * Das Berechtigungsverhalten bleibt unverändert: Seiten rufen weiterhin
 * `notFound()` auf, der HTTP-Status bleibt 404. Hier wird nur erklärt, warum.
 */
export default async function DashboardNotFound() {
  const roleKeys = await getCurrentUserRoles()
  const hasDashboardAccess = hasReportReadRole(roleKeys)

  if (hasDashboardAccess) {
    return (
      <main className="mx-auto max-w-3xl space-y-6 px-4 py-8 sm:px-8 sm:py-10">
        <PageHeader
          title="Seite nicht gefunden"
          subtitle="Diese Seite oder dieser Eintrag existiert nicht (mehr). Möglicherweise wurde der Eintrag gelöscht oder der Link ist veraltet."
        />
        <Link
          href="/dashboard"
          className="inline-block text-sm text-blue-800 underline-offset-4 hover:text-blue-900 hover:underline focus-visible:rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          Zurück zur Übersicht
        </Link>
      </main>
    )
  }

  const roleLabel =
    roleKeys.length > 0
      ? roleKeys.map((k) => ROLE_LABELS[k]).join(", ")
      : null

  return (
    <main className="mx-auto max-w-3xl space-y-6 px-4 py-8 sm:px-8 sm:py-10">
      <PageHeader
        title="Kein Zugriff auf das interne Dashboard"
        subtitle={
          roleLabel
            ? `Für deine Rolle (${roleLabel}) ist der interne Bereich derzeit nicht verfügbar.`
            : "Für dein Konto ist noch keine Rolle hinterlegt, deshalb ist der interne Bereich derzeit nicht verfügbar."
        }
      />

      <div className="space-y-3 rounded-md bg-muted/40 px-4 py-3 text-sm leading-relaxed text-muted-foreground">
        <p>
          Das ist kein Fehler deines Kontos: Die Bearbeitung von Meldungen,
          Maßnahmen und Dokumenten ist Administratoren, Safety Managern und
          Safety Assistants vorbehalten. Eine eigene Ansicht für angemeldete Meldende
          ist in Vorbereitung.
        </p>
        <p>
          Wenn du internen Zugang benötigst, wende dich an die Administration
          deines Vereins oder deiner Flugschule.
        </p>
        <p>
          Über den Button oben rechts kannst du dich jederzeit abmelden.
        </p>
      </div>

      <div className="flex flex-wrap gap-4 text-sm">
        <Link
          href="/submit-report"
          className="text-blue-800 underline-offset-4 hover:text-blue-900 hover:underline focus-visible:rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          Meldung erfassen
        </Link>
        <Link
          href="/communications"
          className="text-blue-800 underline-offset-4 hover:text-blue-900 hover:underline focus-visible:rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          Sicherheitsinformationen
        </Link>
        <Link
          href="/"
          className="text-blue-800 underline-offset-4 hover:text-blue-900 hover:underline focus-visible:rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          Zur Startseite
        </Link>
      </div>
    </main>
  )
}
