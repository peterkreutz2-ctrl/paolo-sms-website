import type { Metadata } from "next"
import { AuthProvider } from "@/lib/auth/auth-provider"
import { appAuth, usesBetterAuth, usesFileAuth } from "@/lib/auth"
import { Inter } from "next/font/google"

import { getOrganizationDisplayName } from "@/lib/queries/organization-display-name"

import { DemoBanner } from "@/components/demo-banner"
import { SiteHeader } from "@/components/site-header"
import { isDemoMode } from "@/lib/demo/mode"

import "./globals.css"

const inter = Inter({ subsets: ["latin"], variable: "--font-sans", display: "swap" })

// Funktion statt Konstante, damit die Demo-Installation (DEMO_MODE) zur Laufzeit
// aus Suchmaschinen herausgehalten wird. Sonst ist das Ergebnis unveraendert.
export function generateMetadata(): Metadata {
  return {
    title: "PAOLO SMS",
    description: "Safety Management System",
    ...(isDemoMode() ? { robots: { index: false, follow: false } } : {}),
  }
}

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  // Ob eine Sitzung besteht, weiss nur die Serverseite. Der SiteHeader ist eine
  // Client-Komponente (er braucht den Pfad) und bekommt die Antwort deshalb als
  // Prop — statt sie, wie bisher, an einer Liste von Seitenpfaden zu raten.
  //
  // Preis dieser Zeile: Die Startseite war bisher statisch vorgerendert und
  // wird jetzt je Aufruf serverseitig gerendert. Das ist der einzige
  // Unterschied im Routenbaum. Ein Anmeldeknopf, der die Sitzung nicht kennt,
  // waere die Alternative gewesen — und fuer angemeldete Nutzer schlicht
  // falsch.
  const { userId } = await appAuth()
  const organizationName = await getOrganizationDisplayName()

  return (
    <AuthProvider>
      <html
        lang="de"
        className={inter.variable}
        suppressHydrationWarning={process.env.NODE_ENV === "development"}
      >
        <body>
          <DemoBanner />
          <SiteHeader
            signedIn={Boolean(userId)}
            fileAuth={usesFileAuth()}
            betterAuth={usesBetterAuth()}
            organizationName={organizationName}
          />

          {children}
        </body>
      </html>
    </AuthProvider>
  )
}
