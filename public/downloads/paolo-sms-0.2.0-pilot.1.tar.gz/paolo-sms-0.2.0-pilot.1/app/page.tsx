import Image from "next/image"
import Link from "next/link"

import { PublicLegalLinks } from "@/components/public-legal-links"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  PUBLIC_REPORT_TYPE_LABELS,
  PUBLIC_REPORT_TYPE_VALUES,
} from "@/lib/constants/public-report-types"

// Die Startseite zählt auf, was gemeldet werden kann. Diese Liste war früher
// hier fest verdrahtet und ist dabei vom Meldeformular abgewichen: Sie nannte
// fünf Arten, darunter ein „Vorfall“, den es im Formular nie gab. Sie kommt
// deshalb jetzt aus derselben Quelle wie das Formular — damit kann sie nicht
// erneut auseinanderlaufen.
const reportableItems = PUBLIC_REPORT_TYPE_VALUES.map(
  (value) => PUBLIC_REPORT_TYPE_LABELS[value]
)

export default function HomePage() {
  return (
    <main className="mx-auto max-w-4xl space-y-10 px-4 py-10 sm:px-6 sm:py-14">

      {/* Hero: two-column on desktop */}
      <div className="grid gap-8 lg:grid-cols-[1fr_260px] lg:items-center lg:gap-12">

        {/* Left: intro text + disclaimer + CTA */}
        <div className="space-y-8">
          <header className="space-y-3">
            <p className="text-sm font-medium text-muted-foreground">PAOLO SMS</p>
            <h1 className="text-balance text-2xl font-semibold tracking-tight sm:text-3xl">
              Sicherheit gemeinsam verbessern
            </h1>
            <p className="text-pretty text-base leading-relaxed text-muted-foreground">
              Das digitale Sicherheitsmanagementsystem für Gleitschirmflugschulen
              und Vereine — Meldungen sammeln, auswerten und daraus lernen, bevor
              Zwischenfälle zu Unfällen werden.
            </p>
          </header>

          <div className="space-y-2 rounded-lg border border-border/60 bg-muted/20 px-4 py-3 text-sm leading-relaxed text-muted-foreground">
            <p>
              <strong className="font-medium text-foreground">Nicht zurechtweisend:</strong>{" "}
              Es geht nicht um Schuld, sondern um Verständnis und Verbesserung.
              Meldungen sind intern und vertraulich.
            </p>
            <p>
              <strong className="font-medium text-foreground">Kein Ersatz für offizielle Wege:</strong>{" "}
              Dieses Formular ersetzt keine Notrufe (112 / 1414) und keine
              amtlichen Unfallberichte.
            </p>
          </div>

          <div className="flex flex-col items-stretch gap-3 sm:items-start">
            <Button asChild size="lg" className="h-11 w-full text-base sm:w-auto sm:min-w-[16rem]">
              <Link href="/submit-report">Sicherheitsmeldung einreichen</Link>
            </Button>
            <p className="text-center text-xs text-muted-foreground sm:text-left">
              Ohne Anmeldung — nur wenige Pflichtfelder.
            </p>
          </div>

          {/* Der Satz nannte frueher nur Safety Assistants, Safety Manager und
              Administratoren. Seit der Sichtbarkeitsstufe „Mitglieder" (#36)
              hat auch die Rolle Benutzer einen eigenen Nutzen von der
              Anmeldung — er war damit enger als das Zugriffsmodell. */}
          <p className="text-sm text-muted-foreground">
            Wer ein Konto hat, kann sich{" "}
            <Link href="/sign-in" className="text-blue-800 hover:text-blue-900 hover:underline underline-offset-4">
              anmelden
            </Link>
            : Benutzer sehen zusätzlich die internen
            Sicherheitsinformationen, Safety Assistants außerdem Meldungen und
            Maßnahmen. Safety Manager und Administratoren bearbeiten Meldungen,
            verwalten Maßnahmen und dokumentieren Sicherheitsbesprechungen.
          </p>
          <p className="text-sm text-muted-foreground">
            Konten legt die Administration Ihrer Flugschule oder Ihres Vereins
            an — eine Anmeldung ist zum Melden nicht nötig.
          </p>
        </div>

        {/* Right: SMS process diagram — no card, no caption */}
        <div className="flex justify-center">
          <Image
            src="/sms-cycle-diagram.png"
            alt="SMS-Kreislauf: Beobachtung und Ereignis, Meldung, Auswertung, Maßnahme ableiten"
            width={1254}
            height={1254}
            className="w-full max-w-[240px] lg:max-w-full"
          />
        </div>

      </div>

      {/* Info cards */}
      <Card className="bg-muted/40">
        <CardHeader>
          <CardTitle className="text-base">Was kann gemeldet werden?</CardTitle>
          <CardDescription>
            Alles, was für die Sicherheit im Betrieb relevant sein kann — sachlich
            und in eigenen Worten.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="grid gap-2 text-sm text-foreground sm:grid-cols-2">
            {reportableItems.map((item) => (
              <li
                key={item}
                className="rounded-md border border-border/60 bg-background/50 px-3 py-2"
              >
                {item}
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <Card className="bg-muted/40">
        <CardHeader>
          <CardTitle className="text-base">Warum melden?</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm leading-relaxed text-muted-foreground">
          <p>
            Aus Meldungen lassen sich Muster erkennen, bevor es zu schweren
            Zwischenfällen kommt. Je früher wir Hinweise erhalten, desto besser
            können wir Prävention und Abläufe anpassen.
          </p>
          <p>
            Jede Meldung kann dazu beitragen, dass andere von den Erfahrungen
            profitieren — ohne Einzelpersonen in den Mittelpunkt zu stellen.
          </p>
        </CardContent>
      </Card>

      <footer className="border-t border-border/60 pt-6">
        <PublicLegalLinks />
      </footer>

    </main>
  )
}
