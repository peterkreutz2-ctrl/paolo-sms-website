import { redirect } from "next/navigation"

export default function DocumentsRedirectPage() {
  redirect("/dashboard/documents")
}
