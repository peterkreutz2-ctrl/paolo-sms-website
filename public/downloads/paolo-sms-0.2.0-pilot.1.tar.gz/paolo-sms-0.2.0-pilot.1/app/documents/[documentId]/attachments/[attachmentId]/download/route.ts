import { and, eq } from "drizzle-orm"
import { z } from "zod"

import { appAuth } from "@/lib/auth"
import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import {
  buildAttachmentDeliveryHeaders,
  canServeToSession,
} from "@/lib/constants/attachment-visibility"
import { db } from "@/lib/db"
import { attachments, smsDocuments } from "@/lib/db/schema"
import { downloadFile } from "@/lib/storage"

// Auslieferung von Anhaengen an SMS-Dokumenten MIT Sitzung.
//
// Bewusst NICHT unter /dashboard: Ein Mitglied ohne internen Dashboard-Zugang
// laedt hier die Anhaenge eines 'members'-Dokuments herunter, das es auf
// /communications sieht. Der Pfad beschreibt die Ressource, nicht den Bereich,
// aus dem sie angezeigt wird.
//
// Die Sichtbarkeit wird vom Elterndokument geerbt — Anhaenge haben keine
// eigene Sichtbarkeitsspalte. Entschieden wird ausschliesslich ueber
// canServeToSession; is_public spielt hier keine Rolle und wird bewusst nicht
// einmal geladen (Begruendung in lib/constants/attachment-visibility.ts).
//
// Zusammen mit /communications/attachments/... bleibt es bei genau zwei
// Auslieferungswegen: einer anonym, einer mit Sitzung.
//
// Jede Ablehnung antwortet mit demselben nichtssagenden 404: ob eine ID
// existiert, aber nicht zugaenglich ist, darf von aussen nicht unterscheidbar
// sein. Auch die fehlende Anmeldung fuehrt deshalb zu 404 und nicht zu 401 —
// sonst wuerde die Existenz eines Anhangs anmeldefrei bestaetigt.

export const dynamic = "force-dynamic"

type Props = {
  params: Promise<{
    documentId: string
    attachmentId: string
  }>
}

const idSchema = z.string().uuid()

const NOT_FOUND = "Nicht gefunden."

function notFoundResponse(): Response {
  return new Response(NOT_FOUND, { status: 404 })
}

export async function GET(_: Request, { params }: Props) {
  const { documentId, attachmentId } = await params

  // Ungueltige IDs vor der Datenbank abfangen: eine kaputte UUID wuerde sonst
  // einen Datenbankfehler und damit 500 statt 404 erzeugen.
  const parsedDocumentId = idSchema.safeParse(documentId)
  const parsedAttachmentId = idSchema.safeParse(attachmentId)
  if (!parsedDocumentId.success || !parsedAttachmentId.success) {
    return notFoundResponse()
  }

  const { userId } = await appAuth()
  if (!userId) return notFoundResponse()

  const roleKeys = await getCurrentUserRoles()

  // Erstes Tor bereits in SQL: Der INNER JOIN auf sms_documents schliesst
  // Anhaenge von Meldungen (sms_document_id IS NULL) automatisch aus, die
  // Gleichheit auf documentId sichert die Zugehoerigkeit.
  const [row] = await db
    .select({
      smsDocumentId: attachments.smsDocumentId,
      documentVisibility: smsDocuments.visibility,
      mimeType: attachments.mimeType,
      originalFileName: attachments.originalFileName,
      fileSize: attachments.fileSize,
      storageKey: attachments.storageKey,
    })
    .from(attachments)
    .innerJoin(smsDocuments, eq(smsDocuments.id, attachments.smsDocumentId))
    .where(
      and(
        eq(attachments.id, parsedAttachmentId.data),
        eq(attachments.smsDocumentId, parsedDocumentId.data)
      )
    )
    .limit(1)

  if (!row) return notFoundResponse()

  // Zweites Tor auf der tatsaechlich geladenen Zeile — dieselbe reine Funktion,
  // die auch die Anzeige auf /communications steuert.
  if (
    !canServeToSession({
      roleKeys,
      smsDocumentId: row.smsDocumentId,
      documentVisibility: row.documentVisibility,
    })
  ) {
    return notFoundResponse()
  }

  const file = await downloadFile(row.storageKey)
  if (!file) return notFoundResponse()

  return new Response(file.stream, {
    status: 200,
    // Bilder und Videos inline, damit die interne Vorschau vor einer Freigabe
    // den Inhalt tatsaechlich zeigt. Nicht in Zwischencaches: eine
    // Herabstufung muss sofort wirken.
    headers: buildAttachmentDeliveryHeaders({
      mimeType: row.mimeType,
      fileName: row.originalFileName,
      fileSize: row.fileSize,
      fallbackContentType: file.contentType,
      cacheControl: "private, no-store",
    }),
  })
}
