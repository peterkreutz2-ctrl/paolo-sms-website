"use client"

import { Button } from "@/components/ui/button"

// Kleiner Auslöser für den Browser-Druckdialog. Wird im Druckergebnis
// ausgeblendet (print:hidden), damit auf dem Papier nur das Dokument erscheint.
// Kein PDF-Export, kein zusätzliches Chrome.
export function PrintButton() {
  return (
    <div className="print:hidden">
      <Button type="button" size="sm" onClick={() => window.print()}>
        Drucken
      </Button>
    </div>
  )
}
