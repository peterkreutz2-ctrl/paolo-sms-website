import { appAuth } from "@/lib/auth"
import { and, eq } from "drizzle-orm"
import { notFound, redirect } from "next/navigation"

import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { hasDocumentReadRole } from "@/lib/constants/roles"
import { db } from "@/lib/db"
import { organizations, smsDocuments } from "@/lib/db/schema"
import {
  canReadDocumentVisibility,
  normalizeVisibility,
  SMS_DOCUMENT_CATEGORY_LABELS,
  SMS_DOCUMENT_VISIBILITY_LABELS,
  type SmsDocumentCategory,
} from "@/lib/constants/sms-documents"

import { DocumentMarkdownView } from "@/app/dashboard/documents/document-markdown-view"

import { PrintButton } from "./print-button"

const dtFormatter = new Intl.DateTimeFormat("de-DE", { dateStyle: "medium" })

function categoryLabel(v: string): string {
  return SMS_DOCUMENT_CATEGORY_LABELS[v as SmsDocumentCategory] ?? v
}
function visibilityLabel(v: string): string {
  return SMS_DOCUMENT_VISIBILITY_LABELS[normalizeVisibility(v)]
}

// Eigenständige, chrome-freie Druckansicht für ein einzelnes SMS-Dokument.
// Bewusst außerhalb von /dashboard, damit weder die Dashboard-Navigation noch
// der globale SiteHeader erscheinen (SiteHeader blendet sich auf /documents/*
// /print zusätzlich aus). Zeigt nur Kopfdaten und den formatierten Inhalt.
// Rechte identisch zur Dokumentliste: admin/safety_manager alle Dokumente,
// instructor nur veröffentlichte, member kein Zugriff. Keine Aktionen, kein
// PDF-Export, kein rohes HTML (Markdown-Renderer wird wiederverwendet).
export default async function DocumentPrintPage({
  params,
}: {
  params: Promise<{ documentId: string }>
}) {
  const { documentId } = await params

  const { userId } = await appAuth()
  if (!userId) redirect("/sign-in")

  const roleKeys = await getCurrentUserRoles()
  if (!hasDocumentReadRole(roleKeys)) notFound()

  const [organization] = await db.select().from(organizations).limit(1)
  if (!organization) notFound()

  const [doc] = await db
    .select()
    .from(smsDocuments)
    .where(
      and(
        eq(smsDocuments.id, documentId),
        eq(smsDocuments.organizationId, organization.id)
      )
    )
    .limit(1)

  if (!doc) notFound()

  // Dieselbe Leseregel wie die interne Liste und die Anhang-Auslieferung —
  // `canReadDocumentVisibility` ist das dafuer vorgesehene zweite Tor auf einer
  // bereits geladenen Zeile. Vorher stand hier eine eigene Pruefung gegen
  // SMS_DOCUMENT_STAFF_VISIBLE_DB_VALUES: verhaltensgleich, aber eine vierte
  // Kopie der Regel, die einer Aenderung nicht gefolgt waere (Regelaudit F2).
  //
  // Der Unterschied im Detail: Die Funktion prueft Rohwert UND normalisierten
  // Wert. Ein unbekannter Sichtbarkeitswert normalisiert auf 'confidential' und
  // bleibt damit dem Bearbeiterkreis vorbehalten, statt nur zufaellig nicht in
  // einer Liste zu stehen.
  if (!canReadDocumentVisibility(roleKeys, doc.visibility)) notFound()

  return (
    <>
      {/* Angenehme Papierränder: seitlich ~22 mm, oben/unten ~18 mm. Gilt nur
          für diese eigenständige Druckroute (eigenes Dokument). Am Bildschirm
          wirkt weiterhin das Container-Padding unten. */}
      <style>{`@page { margin: 18mm 22mm; }`}</style>
      {/* Header, Inhalt und Footer liegen bewusst im selben <main>-Container und
          erben damit dieselbe Breite und dasselbe horizontale Padding (Bildschirm
          und Druck). So sind alle drei horizontal bündig. Die native Kopf-/
          Fußzeile des Browsers (URL/Datum/Seitenzahl) ist davon unabhängig und
          lässt sich im Druckdialog abschalten. */}
      <main className="mx-auto max-w-3xl px-6 py-8 print:max-w-none print:px-0 print:py-0">
        <header className="mb-6 flex items-start justify-between gap-4 border-b pb-4">
          <div className="min-w-0 space-y-1">
            <h1 className="font-heading text-2xl font-semibold leading-tight text-foreground">
              {doc.title}
            </h1>
            <p className="text-sm text-muted-foreground">
              {categoryLabel(doc.category)} · {visibilityLabel(doc.visibility)} ·
              Aktualisiert am {dtFormatter.format(doc.updatedAt)}
            </p>
          </div>
          <PrintButton />
        </header>

        <DocumentMarkdownView content={doc.content} />

        <footer className="mt-8 border-t pt-4 text-xs text-muted-foreground">
          {doc.title} · {categoryLabel(doc.category)} · Aktualisiert am{" "}
          {dtFormatter.format(doc.updatedAt)}
        </footer>
      </main>
    </>
  )
}
