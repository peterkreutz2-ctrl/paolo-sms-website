import { AuthScreen } from "@/lib/auth/auth-screen"
import { POST_SIGN_IN_PARAM } from "@/lib/auth/redirect-targets"

// Der Rueckweg kommt als Query-Parameter herein und wird in AuthScreen gegen
// die Positivliste geprueft; ungueltige Werte fallen dort auf /dashboard
// zurueck.
export default async function Page({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>
}) {
  const params = await searchParams
  const requested = params[POST_SIGN_IN_PARAM]

  return (
    <main className="flex min-h-screen items-center justify-center">
      <AuthScreen
        kind="sign-in"
        redirectTo={Array.isArray(requested) ? requested[0] : requested}
        error={Array.isArray(params.error) ? params.error[0] : params.error}
      />
    </main>
  )
}
