import { and, desc, eq, inArray } from "drizzle-orm"

import { db } from "@/lib/db"
import { attachments, organizations, smsDocuments } from "@/lib/db/schema"
import {
  attachmentReachLabel,
  buildPublicAttachmentPath,
  buildSessionAttachmentPath,
  canServePublicly,
  canServeToSession,
  describeAttachmentReach,
  isInlineDisplayableImage,
  isPlayableVideo,
} from "@/lib/constants/attachment-visibility"
import {
  IGC_VIEWER_HINT_NAME,
  IGC_VIEWER_HINT_URL,
  isIgcFileName,
} from "@/lib/constants/igc-viewer"
import {
  getCommunicationsVisibilityDbValues,
  normalizeVisibility,
  SMS_DOCUMENT_CATEGORY_GROUP_LABELS,
  SMS_DOCUMENT_SECTIONS,
  SMS_DOCUMENT_VISIBILITY_LABELS,
  type SmsDocumentCategory,
} from "@/lib/constants/sms-documents"

import { appAuth } from "@/lib/auth"
import { getCurrentUserRoles } from "@/lib/auth/user-roles"

import { Badge } from "@/components/ui/badge"

import { AttachmentVideoPlayer } from "@/components/attachment-video"
import { PublicLegalLinks } from "@/components/public-legal-links"
import {
  CollapsibleDocumentSection,
  DocumentView,
} from "@/app/dashboard/documents/document-collapsibles"
import { normalizePublicReportStatusLimit } from "@/lib/constants/public-report-status"
import { getPublicReportStatusList } from "@/lib/queries/public-report-status"
import {
  PublicReportStatusBox,
  PUBLIC_REPORT_STATUS_PARAM,
} from "./public-report-status-box"

// Öffentliche Seite mit zwei Sichten:
//
//   ohne Anmeldung          ausschließlich Dokumente mit exakt 'public'
//   angemeldet mit Rolle    zusätzlich Dokumente mit 'members'
//
// 'staff' und 'confidential' erscheinen hier unter keinen Umständen — auch
// nicht für Administrator oder Safety Manager. Diese Seite ist eine
// Darstellungsfläche, keine zweite Berechtigungsregel; welche Stufen eine
// Rollenmenge sehen darf, entscheidet allein
// getCommunicationsVisibilityDbValues (lib/constants/sms-documents.ts).
//
// Die Sichtbarkeitsliste wird ausschließlich serverseitig aus der Sitzung
// abgeleitet — nie aus Query-Parametern, Headern oder Props. Ein angemeldetes
// Konto ohne zugewiesene PAOLO-Rolle sieht deshalb genau das, was ein anonymer
// Besucher sieht.
//
// force-dynamic: pro Aufruf frisch (kein DB-Zugriff zur Build-Zeit), passend
// zu revalidatePath("/communications") — und zwingend, seit der Inhalt von der
// Sitzung abhängt. Kein statisches Rendern, kein revalidate.
//
// Der globale SiteHeader blendet den Account-Button auf dieser Seite bewusst
// aus (ANONYMOUS_PAGES); die Seite rendert ihn deshalb selbst, für Angemeldete
// als Abmelde-Weg und für anonyme Besucher als Anmelde-Einstieg.
export const dynamic = "force-dynamic"

export const metadata = {
  title: "Sicherheitsinformationen",
}

const dtFormatter = new Intl.DateTimeFormat("de-DE", { dateStyle: "medium" })

// Öffentliche Reihenfolge: Sicherheitsinformationen zuerst, danach die übrigen
// Kategorien in der Reihenfolge der internen Bereiche.
const PUBLIC_CATEGORY_ORDER: readonly SmsDocumentCategory[] = [
  "safety_information",
  ...SMS_DOCUMENT_SECTIONS.flatMap((s) => s.categories).filter(
    (c) => c !== "safety_information"
  ),
]

type DocumentRow = typeof smsDocuments.$inferSelect

type CommunicationsAttachmentRow = {
  id: string
  originalFileName: string
  mimeType: string
  // Fertiger Auslieferungspfad. Welcher der beiden Wege es ist — anonym oder
  // mit Sitzung — entscheidet die Sichtbarkeit des Elterndokuments und wird
  // beim Aufbau der Liste einmal festgelegt, nicht hier in der Darstellung.
  href: string
  // Gesetzt, wenn dieser Anhang WENIGER weit reicht, als das Abzeichen des
  // Dokuments vermuten laesst — konkret: ein nicht freigegebener Anhang an
  // einer oeffentlichen Mitteilung. Ohne den Hinweis stuende er unter einem
  // „Oeffentlich"-Abzeichen, waere aber nur mit Anmeldung abrufbar.
  restrictedNote: string | null
}

/**
 * Hinweis an einem Anhang, der weniger weit reicht als das Abzeichen seiner
 * Mitteilung. Beschriftung und Bedingung stammen aus
 * `describeAttachmentReach` / `attachmentReachLabel` — dieselbe Quelle, die
 * auch der interne Anhangsbereich fuer seine Abzeichen benutzt.
 */
function RestrictedNote({ note }: { note: string | null }) {
  if (!note) return null
  return <p className="text-xs text-muted-foreground">{note}</p>
}

// Bilder werden direkt angezeigt, alles andere als Link angeboten. Die Route
// liefert Bilder inline aus (enge Positivliste JPEG/PNG/WebP) und alles
// uebrige als Download.
function CommunicationsAttachments({
  files,
}: {
  files: CommunicationsAttachmentRow[]
}) {
  if (files.length === 0) return null

  const images = files.filter((f) => isInlineDisplayableImage(f.mimeType))
  const videos = files.filter((f) => isPlayableVideo(f.mimeType))
  const others = files.filter(
    (f) => !isInlineDisplayableImage(f.mimeType) && !isPlayableVideo(f.mimeType)
  )

  return (
    <div className="space-y-3 border-t border-border/60 pt-3">
      <p className="text-xs font-medium text-muted-foreground">Anhänge</p>

      {images.length > 0 ? (
        <div className="flex flex-wrap gap-3">
          {images.map((file) => (
            <div key={file.id} className="space-y-1">
              <a href={file.href} target="_blank" rel="noreferrer" className="block">
                {/* eslint-disable-next-line @next/next/no-img-element -- Die
                    Datei wird von einer dynamischen Route ausgeliefert, die der
                    Bildoptimierer nicht vorab abrufen kann. */}
                <img
                  src={file.href}
                  alt={file.originalFileName}
                  loading="lazy"
                  className="max-h-64 w-auto rounded-md border bg-muted/40 object-contain"
                />
              </a>
              <RestrictedNote note={file.restrictedNote} />
            </div>
          ))}
        </div>
      ) : null}

      {videos.length > 0 ? (
        <div className="space-y-3">
          {videos.map((file) => {
            const path = file.href
            return (
              <div key={file.id} className="space-y-1">
                <AttachmentVideoPlayer
                  src={path}
                  fileName={file.originalFileName}
                />
                {/* Der Download bleibt immer erreichbar — auf iOS spielt
                    Safari die Datei voraussichtlich nicht ab. */}
                <a
                  href={path}
                  className="text-sm text-blue-800 underline-offset-4 hover:underline dark:text-blue-300"
                >
                  {file.originalFileName} herunterladen
                </a>
                <RestrictedNote note={file.restrictedNote} />
              </div>
            )
          })}
        </div>
      ) : null}

      {others.length > 0 ? (
        <ul className="space-y-2">
          {others.map((file) => {
            const path = file.href

            return (
              <li key={file.id} className="space-y-1">
                <a
                  href={path}
                  className="text-sm text-blue-800 underline-offset-4 hover:underline dark:text-blue-300"
                >
                  {file.originalFileName}
                </a>
                <RestrictedNote note={file.restrictedNote} />

                {isIgcFileName(file.originalFileName) ? (
                  // Reiner Hinweis. Es wird KEINE PAOLO-URL uebergeben und
                  // kein externer Dienst kontaktiert — weder beim Laden der
                  // Seite noch beim Klick auf diesen Link. Der Nutzer laedt
                  // die Datei herunter und oeffnet sie dort selbst.
                  <p className="text-xs leading-relaxed text-muted-foreground">
                    Tracklog: Datei zuerst herunterladen und anschließend in
                    einem IGC-Viewer öffnen, zum Beispiel{" "}
                    <a
                      href={IGC_VIEWER_HINT_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="font-medium text-sky-700 underline underline-offset-2 hover:text-sky-900 dark:text-sky-400"
                    >
                      {IGC_VIEWER_HINT_NAME}&#8202;&#8599;
                    </a>
                    . Der Viewer verarbeitet die Datei ausschließlich im
                    Browser; sie wird dabei nicht hochgeladen.
                  </p>
                ) : null}
              </li>
            )
          })}
        </ul>
      ) : null}
    </div>
  )
}

export default async function CommunicationsPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>
}) {
  const resolvedSearchParams = await searchParams
  const rawLimit = resolvedSearchParams[PUBLIC_REPORT_STATUS_PARAM]

  // Die oeffentliche Statusliste darf die uebrige Seite nicht mitreissen: Wer
  // hierherkommt, will oft nur die Sicherheitsinformationen lesen. Faellt die
  // Abfrage aus, entfaellt die Box und der Rest der Seite steht.
  let publicReportStatusList
  try {
    publicReportStatusList = await getPublicReportStatusList(
      normalizePublicReportStatusLimit(
        Array.isArray(rawLimit) ? rawLimit[0] : rawLimit
      )
    )
  } catch (error) {
    console.error(
      "[public-report-status] Statusrückmeldungen konnten nicht geladen werden:",
      error
    )
    publicReportStatusList = { enabled: false as const }
  }

  // Rollen ausschließlich aus der Sitzung. getCurrentUserRoles() liefert für
  // anonyme Besucher und für angemeldete Konten ohne zugewiesene Rolle
  // gleichermaßen eine leere Liste — beide bekommen deshalb dieselbe Sicht.
  const [{ userId }, roleKeys, [organization]] = await Promise.all([
    appAuth(),
    getCurrentUserRoles(),
    db.select().from(organizations).limit(1),
  ])

  // Die eine Leseregel, auf die Darstellungsfläche dieser Seite eingeschränkt.
  // Ohne Rolle ergibt das exakt ['public'] — dieselbe harte Filterung wie
  // bisher, ohne Normalisierung von Altwerten.
  const visibleDbValues = getCommunicationsVisibilityDbValues(roleKeys)
  const canSeeMembersDocuments = visibleDbValues.includes("members")

  const documents: DocumentRow[] = organization
    ? await db
        .select()
        .from(smsDocuments)
        .where(
          and(
            eq(smsDocuments.organizationId, organization.id),
            inArray(smsDocuments.visibility, [...visibleDbValues])
          )
        )
        .orderBy(desc(smsDocuments.updatedAt))
    : []

  const byCategory = new Map<string, DocumentRow[]>()
  for (const doc of documents) {
    const list = byCategory.get(doc.category) ?? []
    list.push(doc)
    byCategory.set(doc.category, list)
  }

  // Anhaenge nach den zwei Auslieferungswegen getrennt laden:
  //
  //   'public'-Dokumente   nur ausdruecklich freigegebene Anhaenge
  //                        (attachments.is_public), anonym abrufbar.
  //   'members'-Dokumente  alle Anhaenge — die Sichtbarkeit wird vom
  //                        Elterndokument geerbt, nur mit Sitzung abrufbar.
  //
  // Die beiden Richtungen werden bewusst nicht vermischt: is_public bleibt
  // allein das Ergebnis der Einzelfreigabe, und ein 'members'-Dokument gibt
  // keinen Anhang oeffentlich frei (siehe attachment-visibility.ts).
  //
  // Fuer anonyme Besucher ist memberDocumentIds immer leer; die Bedingung
  // reduziert sich dann auf exakt den bisherigen Filter.
  // Welche Anhaenge erscheinen, entscheiden dieselben beiden Funktionen wie
  // die Auslieferung selbst: canServePublicly fuer den anmeldefreien Weg,
  // canServeToSession fuer den Weg mit Sitzung.
  //
  // Vorher baute diese Seite die Auswahl als eigenes SQL: fuer oeffentliche
  // Dokumente nur freigegebene Anhaenge, fuer Mitglieder-Dokumente alle. Der
  // zweite Zweig stimmte, der erste war ENGER als die Auslieferung — ein
  // angemeldeter Besucher durfte einen nicht freigegebenen Anhang einer
  // oeffentlichen Mitteilung sehr wohl laden, sah ihn hier aber nicht
  // (Regelaudit F3). Kein Leck, aber die Oberflaeche behauptete eine andere
  // Reichweite als die Route.
  //
  // Jetzt wird ungefiltert geladen, was zu den sichtbaren Dokumenten gehoert,
  // und anschliessend mit den Regelfunktionen entschieden. Die Menge ist
  // klein — es sind die Anhaenge der ohnehin angezeigten Mitteilungen.
  const visibleDocumentVisibility = new Map(
    documents.map((doc) => [doc.id, doc.visibility])
  )

  const attachmentsByDocument = new Map<
    string,
    CommunicationsAttachmentRow[]
  >()

  if (documents.length > 0) {
    const rows = await db
      .select({
        id: attachments.id,
        smsDocumentId: attachments.smsDocumentId,
        isPublic: attachments.isPublic,
        originalFileName: attachments.originalFileName,
        mimeType: attachments.mimeType,
      })
      .from(attachments)
      .where(
        inArray(
          attachments.smsDocumentId,
          documents.map((doc) => doc.id)
        )
      )
      .orderBy(attachments.createdAt)

    for (const row of rows) {
      if (!row.smsDocumentId) continue
      const documentVisibility =
        visibleDocumentVisibility.get(row.smsDocumentId) ?? null

      const access = {
        smsDocumentId: row.smsDocumentId,
        documentVisibility,
      }
      const servePublicly = canServePublicly({ ...access, isPublic: row.isPublic })
      // Der Weg mit Sitzung setzt eine Sitzung voraus — die Route antwortet
      // ohne sie mit 404. Ohne diese Bedingung wuerde die Liste anonymen
      // Besuchern Dateien anbieten, die sie nicht laden koennen.
      const serveToSession =
        Boolean(userId) && canServeToSession({ ...access, roleKeys })

      if (!servePublicly && !serveToSession) continue

      const reach = describeAttachmentReach({
        isPublic: row.isPublic,
        documentVisibility: documentVisibility ?? "",
      })

      const list = attachmentsByDocument.get(row.smsDocumentId) ?? []
      list.push({
        id: row.id,
        originalFileName: row.originalFileName,
        mimeType: row.mimeType,
        href: servePublicly
          ? buildPublicAttachmentPath(row.id, row.originalFileName)
          : buildSessionAttachmentPath(row.smsDocumentId, row.id),
        // Nur der eine irrefuehrende Fall bekommt einen Hinweis: nicht
        // freigegeben, aber an einer oeffentlichen Mitteilung. Bei einer
        // Mitteilung der Stufe „Mitglieder" sagt bereits das Abzeichen des
        // Dokuments dasselbe — ein zweiter Hinweis waere Rauschen.
        restrictedNote:
          reach.kind === "inherited" && reach.visibility === "public"
            ? attachmentReachLabel(reach)
            : null,
      })
      attachmentsByDocument.set(row.smsDocumentId, list)
    }
  }

  const sections = PUBLIC_CATEGORY_ORDER.map((category) => ({
    category,
    docs: byCategory.get(category) ?? [],
  })).filter((section) => section.docs.length > 0)


  return (
    <main className="mx-auto max-w-4xl space-y-8 px-4 py-8 sm:px-8">
      <header className="flex items-start justify-between gap-4">
        <div className="space-y-2">
          <h1 className="font-heading text-2xl font-semibold tracking-tight text-foreground">
            Sicherheitsinformationen
          </h1>
          {/* Untertitel sitzungsabhängig: Er beschreibt, was tatsächlich zu
              sehen ist. Anonym benennt er zusätzlich, dass eine Anmeldung mehr
              freischaltet — sonst bliebe der Unterschied unsichtbar. */}
          <p className="text-sm leading-relaxed text-muted-foreground">
            {canSeeMembersDocuments ? (
              <>
                Öffentlich freigegebene sowie interne, nur für angemeldete
                Personen bestimmte Sicherheitsinformationen. Als „Angemeldete
                Personen“ gekennzeichnete Inhalte sind nicht zur Weitergabe
                bestimmt.
              </>
            ) : (
              <>
                Öffentlich freigegebene Sicherheitsinformationen und Dokumente –
                ohne Anmeldung einsehbar. Nach der Anmeldung sind zusätzlich
                interne Inhalte für angemeldete Personen sichtbar.
              </>
            )}
          </p>
        </div>
        {/* Der Anmelde- bzw. Abmeldezugang steht im globalen SiteHeader und
            wird hier nicht mehr zusaetzlich gebaut. Diese Seite war die
            einzige, die ihn selbst mitbrachte — weil der Header ihn fuer
            /communications pauschal ausblendete. */}
      </header>

      <PublicReportStatusBox list={publicReportStatusList} />

      {sections.length === 0 ? (
        <p className="rounded-lg border border-dashed px-4 py-10 text-center text-sm text-muted-foreground">
          {canSeeMembersDocuments
            ? "Derzeit sind keine Sicherheitsinformationen für dich verfügbar."
            : "Derzeit sind keine öffentlichen Sicherheitsinformationen verfügbar."}
        </p>
      ) : (
        sections.map(({ category, docs }) => (
          <section
            key={category}
            aria-label={SMS_DOCUMENT_CATEGORY_GROUP_LABELS[category]}
          >
            {/* Gleiche Darstellung wie /dashboard/documents: jede Kategorie ist
                eine auf-/zuklappbare Box, jedes Dokument eine eigene Box. Der
                Titel ist nicht mehr das Bedienelement zum Aufklappen; der Inhalt
                wird ausschließlich über „Anzeigen"/„Verbergen" ein-/ausgeblendet
                und ist initial verborgen. Alle Dokumente sind öffentlich, daher
                werden weder Sichtbarkeits-Zähler noch Aktionen (Bearbeiten/
                Löschen/Drucken) angezeigt. */}
            <CollapsibleDocumentSection
              title={SMS_DOCUMENT_CATEGORY_GROUP_LABELS[category]}
              count={docs.length}
              defaultOpen={false}
            >
              {docs.map((doc) => (
                <div key={doc.id} className="space-y-3 rounded-md border p-4">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="font-medium text-foreground">{doc.title}</p>
                      {/* Kennzeichnung je Dokument: erkennbar machen, was
                          weitergegeben werden darf und was nicht. Nur diese
                          beiden Stufen können hier stehen — 'staff' und
                          'confidential' erscheinen auf dieser Seite nie.

                          Der Text kommt zwingend aus
                          SMS_DOCUMENT_VISIBILITY_LABELS: Eine eigene Wortwahl
                          hatte „Intern" für 'members' gesetzt — das ist dort
                          aber die Bezeichnung von 'staff'. Dasselbe Wort stand
                          damit je nach Seite für zwei verschiedene Stufen. */}
                      <Badge
                        variant={
                          doc.visibility === "public" ? "outline" : "secondary"
                        }
                      >
                        {
                          SMS_DOCUMENT_VISIBILITY_LABELS[
                            normalizeVisibility(doc.visibility)
                          ]
                        }
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Aktualisiert am {dtFormatter.format(doc.updatedAt)}
                    </p>
                  </div>

                  <DocumentView title={doc.title} content={doc.content} />

                  <CommunicationsAttachments
                    files={attachmentsByDocument.get(doc.id) ?? []}
                  />
                </div>
              ))}
            </CollapsibleDocumentSection>
          </section>
        ))
      )}

      <footer className="border-t border-border/60 pt-6">
        <PublicLegalLinks />
      </footer>
    </main>
  )
}
