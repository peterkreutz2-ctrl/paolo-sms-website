import Link from "next/link"

import { Badge } from "@/components/ui/badge"
import { CollapsibleDocumentSection } from "@/app/dashboard/documents/document-collapsibles"
import type { PublicReportStatusList } from "@/lib/queries/public-report-status"

// ─── Box „Status von Sicherheitsmeldungen" ───────────────────────────────────
//
// Zeigt je Zeile ausschliesslich Meldungscode und Bearbeitungsstatus. Was hier
// nicht steht, steht auch nicht im ausgelieferten Markup: Die Abfrage in
// lib/queries/public-report-status.ts liest nur diese beiden Spalten.
//
// Server-Komponente ohne eigenen Zustand. „Weitere anzeigen" ist deshalb ein
// Verweis und kein Skript — er funktioniert ohne JavaScript, ist teilbar und
// die Zurueck-Taste tut das Erwartete.

export const PUBLIC_REPORT_STATUS_PARAM = "rueckmeldungen"

/** Sprungziel fuer „Weitere anzeigen", damit der Verweis nicht oben landet. */
export const PUBLIC_REPORT_STATUS_ANCHOR = "statusrueckmeldungen"

function summaryText(count: number, hasMore: boolean): string {
  if (count === 0) return "Keine Rückmeldungen"
  const noun = count === 1 ? "Rückmeldung" : "Rückmeldungen"
  return hasMore ? `${count} ${noun} (weitere vorhanden)` : `${count} ${noun}`
}

export function PublicReportStatusBox({
  list,
}: {
  list: PublicReportStatusList
}) {
  // Ausgeschaltet: gar keine Box. Bewusst nicht der Leerzustand — sonst
  // behauptete eine Organisation mit abgeschalteter Anzeige oeffentlich, es
  // gebe keine Rueckmeldungen.
  if (!list.enabled) return null

  return (
    <section
      id={PUBLIC_REPORT_STATUS_ANCHOR}
      aria-label="Status von Sicherheitsmeldungen"
    >
      <CollapsibleDocumentSection
        title="Status von Sicherheitsmeldungen"
        count={list.entries.length}
        summary={summaryText(list.entries.length, list.hasMore)}
        // Zugeklappt wie die Dokumentboxen darunter. Die Anzahl in der
        // Zusammenfassungszeile bleibt sichtbar, sodass erkennbar ist, ob es
        // ueberhaupt Rueckmeldungen gibt, ohne die Seite mit einer langen
        // Liste zu eroeffnen.
        defaultOpen={false}
      >
        <p className="text-sm leading-relaxed text-muted-foreground">
          Hast du eine Meldung abgegeben, findest du hier unter deinem
          Meldungscode den Bearbeitungsstand. Die Codes werden zufällig
          vergeben; weder ihre Reihenfolge noch ihre Häufigkeit sagt etwas über
          eine Meldung aus. Meldungsinhalte, Namen und Datumsangaben werden hier
          nicht veröffentlicht.
        </p>

        {list.entries.length === 0 ? (
          <p className="rounded-lg border border-dashed px-4 py-8 text-center text-sm text-muted-foreground">
            Derzeit sind keine öffentlichen Statusrückmeldungen verfügbar.
          </p>
        ) : (
          <>
            <ul className="divide-y divide-border/60 rounded-md border">
              {list.entries.map((entry) => (
                <li
                  key={entry.code}
                  className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5"
                >
                  <span className="font-mono text-sm font-medium text-foreground">
                    {entry.code}
                  </span>
                  <Badge variant="secondary">{entry.statusLabel}</Badge>
                </li>
              ))}
            </ul>

            {list.hasMore ? (
              <p className="text-sm">
                <Link
                  href={`/communications?${PUBLIC_REPORT_STATUS_PARAM}=${list.nextLimit}#${PUBLIC_REPORT_STATUS_ANCHOR}`}
                  className="underline underline-offset-2"
                >
                  Weitere anzeigen
                </Link>
              </p>
            ) : null}
          </>
        )}
      </CollapsibleDocumentSection>
    </section>
  )
}
