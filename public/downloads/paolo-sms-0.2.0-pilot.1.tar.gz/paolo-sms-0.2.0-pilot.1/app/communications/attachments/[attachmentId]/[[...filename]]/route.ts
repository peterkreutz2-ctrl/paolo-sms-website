import { and, eq } from "drizzle-orm"
import { z } from "zod"

import {
  buildAttachmentDeliveryHeaders,
  canServePublicly,
} from "@/lib/constants/attachment-visibility"
import { db } from "@/lib/db"
import { attachments, smsDocuments } from "@/lib/db/schema"
import { consumePublicAttachmentRateLimit } from "@/lib/public-attachment-rate-limit"
import { downloadFile } from "@/lib/storage"

// Oeffentliche, anmeldefreie Auslieferung freigegebener Anhaenge von
// SMS-Dokumenten. Einziger Pfad in PAOLO, der Dateiinhalte ohne
// Anmeldung herausgibt — entsprechend eng gefasst.
//
// Warum ueberhaupt eine eigene Route und keine oeffentlichen Blob-URLs:
//   - Ein oeffentliches Vercel-Blob waere dauerhaft und CDN-gecacht; eine
//     zuruecckgenommene Freigabe bliebe abrufbar. Hier entscheidet jeder
//     einzelne Abruf neu anhand des aktuellen Datenbankstands, ein Widerruf
//     wirkt also sofort.
//   - Der lokale Storage-Provider kennt gar keine oeffentlichen Direktlinks
//     (siehe lib/storage/local-file-storage.ts). Nur ueber diese Route
//     funktioniert die Auslieferung provider-neutral.
// Die Bytes kommen deshalb ausschliesslich ueber downloadFile() aus der
// Storage-Abstraktion; attachments.publicUrl wird bewusst nie an den Client
// gegeben.
//
// Jede Ablehnung antwortet mit 404 und identischem Text: ob eine ID existiert,
// aber nicht freigegeben ist, darf von aussen nicht unterscheidbar sein.

export const dynamic = "force-dynamic"

// Der optionale letzte Pfadabschnitt traegt den Dateinamen:
//   /communications/attachments/<id>            (funktioniert weiterhin)
//   /communications/attachments/<id>/flug.igc   (endet auf .igc)
//
// Er ist rein dekorativ und wird bewusst NICHT ausgewertet — weder fuer die
// Berechtigung noch fuer den Content-Type oder den Dateinamen der Antwort.
// Massgeblich bleibt allein die Attachment-ID; der angezeigte Dateiname kommt
// weiterhin aus der Datenbank. Zweck des Abschnitts ist ausschliesslich, dass
// die URL auf ".igc" endet: externe Viewer erkennen das Format teilweise an
// der Endung, und ein serverseitiger Abruf soll daran nicht scheitern.
type Props = {
  params: Promise<{ attachmentId: string; filename?: string[] }>
}

const attachmentIdSchema = z.string().uuid()

const NOT_FOUND = "Nicht gefunden."

export async function GET(request: Request, { params }: Props) {
  const { attachmentId } = await params

  // Ungueltige IDs vor der Datenbank abfangen: eine kaputte UUID wuerde sonst
  // einen Datenbankfehler und damit einen 500er statt eines 404 erzeugen.
  const parsed = attachmentIdSchema.safeParse(attachmentId)
  if (!parsed.success) {
    return new Response(NOT_FOUND, { status: 404 })
  }

  // Erstes Tor: die Bedingungen stehen bereits in der WHERE-Klausel, damit
  // nicht freigegebene Zeilen die Datenbank gar nicht erst verlassen. Der
  // INNER JOIN schliesst Anhaenge von Meldungen automatisch aus.
  const [row] = await db
    .select({
      isPublic: attachments.isPublic,
      smsDocumentId: attachments.smsDocumentId,
      documentVisibility: smsDocuments.visibility,
      organizationId: smsDocuments.organizationId,
      mimeType: attachments.mimeType,
      originalFileName: attachments.originalFileName,
      fileSize: attachments.fileSize,
      storageKey: attachments.storageKey,
    })
    .from(attachments)
    .innerJoin(smsDocuments, eq(smsDocuments.id, attachments.smsDocumentId))
    .where(
      and(
        eq(attachments.id, parsed.data),
        eq(attachments.isPublic, true),
        // Hart auf exakt 'public', ohne Normalisierung von Altwerten.
        eq(smsDocuments.visibility, "public")
      )
    )
    .limit(1)

  if (!row) {
    return new Response(NOT_FOUND, { status: 404 })
  }

  // Zweites Tor auf der tatsaechlich geladenen Zeile. Redundant zur
  // WHERE-Klausel und genau deshalb wertvoll: die Regel ist als reine Funktion
  // vollstaendig getestet und greift auch dann noch, wenn die Query spaeter
  // versehentlich aufgeweicht wird.
  if (
    !canServePublicly({
      isPublic: row.isPublic,
      smsDocumentId: row.smsDocumentId,
      documentVisibility: row.documentVisibility,
    })
  ) {
    return new Response(NOT_FOUND, { status: 404 })
  }

  // Rate-Begrenzung erst NACH der Zugriffspruefung: nicht freigegebene oder
  // erfundene IDs sollen kein Kontingent verbrauchen, sonst liesse sich ein
  // Nutzer durch Aufrufe unbeteiligter IDs aussperren. Grosszuegig bemessen,
  // weil eine Mitteilung mit mehreren Bildern pro Seitenaufruf mehrere Abrufe
  // erzeugt; die Grenze zielt auf massenhaftes Absaugen, nicht auf Lesen.
  const rateLimit = await consumePublicAttachmentRateLimit(
    row.organizationId,
    request.headers
  )
  if (!rateLimit.allowed) {
    return new Response("Zu viele Anfragen.", {
      status: 429,
      headers: {
        "Retry-After": String(rateLimit.retryAfterSeconds),
        "Cache-Control": "no-store, max-age=0",
      },
    })
  }

  const file = await downloadFile(row.storageKey)
  if (!file) {
    return new Response(NOT_FOUND, { status: 404 })
  }

  return new Response(file.stream, {
    status: 200,
    // Bilder und Videos inline, damit die oeffentliche Seite sie in einem
    // <img> bzw. <video> darstellen kann; alles andere bleibt Download.
    // Kein Caching: eine zurueckgenommene Freigabe muss sofort wirken.
    headers: buildAttachmentDeliveryHeaders({
      mimeType: row.mimeType,
      fileName: row.originalFileName,
      fileSize: row.fileSize,
      fallbackContentType: file.contentType,
      cacheControl: "no-store, max-age=0",
    }),
  })
}
