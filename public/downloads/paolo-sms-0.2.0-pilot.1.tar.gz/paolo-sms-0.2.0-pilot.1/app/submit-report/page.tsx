import { connection } from "next/server"

import { db } from "@/lib/db"
import { organizations } from "@/lib/db/schema"
import { loadPublicReportPrivacyConsentState } from "@/lib/queries/public-report-privacy-consent"

import { SubmitReportForm, type PrivacyConsentConfig } from "./submit-report-form"

export default async function SubmitReportPage() {
  await connection()

  // Die Einwilligungsabfrage richtet sich nach der Organisation (#101). Ins
  // Formular gehen nur Schalter, Text und Fingerabdruck — der Snapshot der
  // Datenschutzerklaerung bleibt auf dem Server.
  const [organization] = await db
    .select({
      publicReportPrivacyConsentEnabled: organizations.publicReportPrivacyConsentEnabled,
      publicReportPrivacyConsentText: organizations.publicReportPrivacyConsentText,
    })
    .from(organizations)
    .limit(1)

  // Ohne Organisation lehnt createReport ohnehin ab; das Formular zeigt dann
  // die Voreinstellung "Ein" mit dem Standardtext.
  const state = await loadPublicReportPrivacyConsentState(
    organization ?? {
      publicReportPrivacyConsentEnabled: true,
      publicReportPrivacyConsentText: null,
    }
  )

  const privacyConsent: PrivacyConsentConfig = {
    enabled: state.enabled,
    text: state.consentText,
    fingerprint: state.fingerprint,
  }

  return <SubmitReportForm privacyConsent={privacyConsent} />
}
