"use client"

import { useRouter } from "next/navigation"
import { useState } from "react"

import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  buildPublicReportSummary,
  publicReportSummaryFileName,
  type PublicReportSummaryInput,
} from "@/lib/reports/public-report-summary"

// ─── Bestaetigungsdialog nach erfolgreichem Speichern ────────────────────────
//
// Er ersetzt die frueher am Seitenende stehende Textzeile: Die Bestaetigung
// stand ausserhalb des sichtbaren Bereichs, und das gleichzeitig geleerte
// Formular sah aus, als seien die Eingaben verloren.
//
// Alle Schliesswege fuehren zur Startseite. Sie werden bewusst NICHT einzeln
// behandelt: Radix leitet Schaltflaeche, Schliessen-Symbol, Escape und Klick
// ausserhalb allesamt durch `onOpenChange(false)`. Ein Weg, eine Regel — sonst
// waere der vierte der, den man vergisst.
//
// Der Download loest kein `onOpenChange` aus; er baut eine Datei im Speicher
// und klickt einen unsichtbaren Verweis an. Der Dialog bleibt danach offen.

export type SubmissionConfirmation = {
  /** null = es konnte ausnahmsweise kein Code vergeben werden (Notfallweg). */
  publicCode: string | null
  /** Zeigt die Organisation Statusrueckmeldungen oeffentlich an? */
  publicStatusEnabled: boolean
  /**
   * Beim Absenden festgehaltene Kopie der uebermittelten Angaben. Spaetere
   * Aenderungen am Formular duerfen die Zusammenfassung nicht veraendern —
   * deshalb eine Kopie und nicht der lebende Formularzustand.
   */
  submitted: PublicReportSummaryInput
  submittedAt: Date
  /** true = dieselbe Einreichung wurde bereits verarbeitet. */
  duplicate: boolean
  /**
   * Meldepflicht-Hinweis (schwere Verletzung, Todesfall, zerstoertes Geraet).
   * Er hing frueher an der Erfolgsmeldung am Seitenende und wandert mit ihr in
   * den Dialog — er ist der einzige Teil dieser Rueckmeldung, der ueber PAOLO
   * hinausweist: Der DHV ist die gesetzliche Unfallmeldestelle, und eine
   * PAOLO-Meldung ersetzt die Meldung dorthin nicht.
   */
  showReportabilityHint: boolean
}

export function SubmissionConfirmationDialog({
  confirmation,
}: {
  confirmation: SubmissionConfirmation | null
}) {
  const router = useRouter()
  const [downloadError, setDownloadError] = useState(false)

  function goHome() {
    router.push("/")
  }

  function handleDownload() {
    if (!confirmation) return
    setDownloadError(false)
    try {
      const text = buildPublicReportSummary({
        data: confirmation.submitted,
        publicCode: confirmation.publicCode,
        publicStatusEnabled: confirmation.publicStatusEnabled,
        submittedAt: confirmation.submittedAt,
      })

      // BOM, damit auch der Windows-Editor die Umlaute richtig zeigt —
      // dasselbe Mittel, das der CSV-Export benutzt.
      const blob = new Blob([`﻿${text}`], {
        type: "text/plain;charset=utf-8",
      })
      const url = URL.createObjectURL(blob)
      const link = document.createElement("a")
      link.href = url
      link.download = publicReportSummaryFileName(confirmation.publicCode)
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      // Erst im naechsten Arbeitsschritt freigeben: Manche Browser starten den
      // Download sonst nicht mehr.
      window.setTimeout(() => URL.revokeObjectURL(url), 0)
    } catch {
      // Die Meldung ist gespeichert — ein misslungener Download aendert daran
      // nichts und darf nicht wie ein Fehlschlag aussehen.
      setDownloadError(true)
    }
  }

  if (!confirmation) return null

  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) goHome()
      }}
    >
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>
            {confirmation.duplicate
              ? "Diese Meldung liegt bereits vor."
              : "Vielen Dank. Deine Meldung wurde gespeichert."}
          </DialogTitle>
          <DialogDescription>
            {confirmation.duplicate
              ? "Diese Einreichung wurde bereits verarbeitet. Es wurde keine zweite Meldung erstellt."
              : "Deine Meldung steht dem Safety Manager zur Bearbeitung bereit."}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 text-sm leading-relaxed">
          {confirmation.publicCode ? (
            <p className="rounded-md border bg-muted/40 px-4 py-3 text-base font-medium text-foreground">
              Dein Meldungscode:{" "}
              <span className="font-mono" data-testid="public-report-code">
                {confirmation.publicCode}
              </span>
            </p>
          ) : (
            <p className="rounded-md border bg-muted/40 px-4 py-3 text-foreground">
              Für diese Meldung konnte ausnahmsweise kein Meldungscode vergeben
              werden. Deine Meldung ist gespeichert und liegt dem Safety Manager
              vor; sie erhält lediglich keinen öffentlichen Eintrag.
            </p>
          )}

          {confirmation.publicCode && confirmation.publicStatusEnabled ? (
            <p className="text-muted-foreground">
              Auf der Seite „Sicherheitsinformationen“ kannst du unter diesem
              Code den Bearbeitungsstatus deiner Meldung einsehen. Öffentlich
              angezeigt werden ausschließlich der Code und der
              Bearbeitungsstatus.
            </p>
          ) : confirmation.publicCode ? (
            <p className="text-muted-foreground">
              Die öffentliche Anzeige des Bearbeitungsstatus ist derzeit
              deaktiviert.
            </p>
          ) : null}

          <p className="text-muted-foreground">
            Du kannst jetzt eine Zusammenfassung deiner Meldung einschließlich
            des Codes herunterladen. Wenn du dieses Fenster schließt, gelangst du
            zur PAOLO-SMS-Homepage.
          </p>

          {confirmation.showReportabilityHint ? (
            <div
              className="rounded-r-lg border-l-2 border-amber-500 bg-amber-50 px-4 py-3 dark:bg-amber-950/30"
              role="alert"
            >
              <p className="font-medium text-amber-800 dark:text-amber-300">
                Hinweis: Meldepflicht prüfen
              </p>
              <p className="mt-1 text-amber-700 dark:text-amber-400">
                Dieser Unfall ist meldepflichtig.{" "}
                <a
                  href="https://www.dhv.de/sicherheit/unfallmeldung/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="underline underline-offset-2"
                >
                  Unfallmeldestelle ist der DHV.
                </a>
              </p>
            </div>
          ) : null}

          {downloadError ? (
            <p className="text-destructive" role="alert">
              Der Download hat nicht geklappt. Deine Meldung ist trotzdem
              gespeichert
              {confirmation.publicCode
                ? ` — notiere dir bei Bedarf den Code ${confirmation.publicCode}.`
                : "."}
            </p>
          ) : null}
        </div>

        <DialogFooter className="sm:justify-between">
          {/* Kein DialogClose: Der Download darf den Dialog nicht schliessen. */}
          <Button type="button" variant="outline" onClick={handleDownload}>
            Zusammenfassung herunterladen
          </Button>
          <Button type="button" onClick={goHome}>
            Zur PAOLO-SMS-Homepage
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
