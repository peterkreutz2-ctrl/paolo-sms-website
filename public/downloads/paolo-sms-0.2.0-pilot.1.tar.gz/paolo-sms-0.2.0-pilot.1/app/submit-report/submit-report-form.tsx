"use client"

import Link from "next/link"
import { useRouter } from "next/navigation"
import { useEffect, useRef, useState, useTransition, type FormEvent } from "react"
import { useForm, useWatch } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { AlertTriangle, ArrowLeft, Lock, ShieldCheck } from "lucide-react"

import { createReport } from "@/lib/actions/reports"
import {
  ACTIVITY_TYPE_LABELS,
  ACTIVITY_TYPE_VALUES,
  DAMAGE_SEVERITY_LABELS,
  DAMAGE_SEVERITY_VALUES,
  FLIGHT_PHASE_LABELS,
  FLIGHT_PHASE_VALUES,
  INJURY_SEVERITY_LABELS,
  INJURY_SEVERITY_VALUES,
  LAUNCH_TYPE_LABELS,
  LAUNCH_TYPE_VALUES,
  REPORTER_ROLE_LABELS,
  REPORTER_ROLE_VALUES,
} from "@/lib/constants/report-classification"
import {
  getPublicReportGuidanceGroup,
  PUBLIC_REPORT_GUIDANCE,
  PUBLIC_REPORT_SHORT_DESCRIPTION_PLACEHOLDERS,
  PUBLIC_REPORT_TYPE_LABELS,
  PUBLIC_REPORT_TYPE_VALUES,
  type PublicReportType,
} from "@/lib/constants/public-report-types"
import {
  PRIVACY_CONSENT_LINK_HREF,
  PRIVACY_CONSENT_LINK_LABEL,
  splitPrivacyConsentText,
} from "@/lib/constants/public-report-privacy-consent"
import { createReportSchema, type CreateReportInput } from "@/lib/validations/report"
import {
  SubmissionConfirmationDialog,
  type SubmissionConfirmation,
} from "./submission-confirmation-dialog"

import { PublicLegalLinks } from "@/components/public-legal-links"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { PageHeader } from "@/components/ui/page-header"
import { PageShell } from "@/components/ui/page-shell"
import { Textarea } from "@/components/ui/textarea"

function createPublicSubmissionId() {
  if (typeof crypto !== "undefined") {
    if ("randomUUID" in crypto && typeof crypto.randomUUID === "function") {
      return crypto.randomUUID()
    }

    if ("getRandomValues" in crypto) {
      const bytes = new Uint8Array(16)
      crypto.getRandomValues(bytes)
      bytes[6] = (bytes[6] & 0x0f) | 0x40
      bytes[8] = (bytes[8] & 0x3f) | 0x80

      const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("")
      return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`
    }
  }

  const createHexSegment = (length: number) =>
    Array.from({ length }, () => Math.floor(Math.random() * 16).toString(16)).join("")

  return `${createHexSegment(8)}-${createHexSegment(4)}-4${createHexSegment(3)}-${["8", "9", "a", "b"][Math.floor(Math.random() * 4)]}${createHexSegment(3)}-${createHexSegment(12)}`
}

/**
 * Einwilligungsabfrage der Organisation, vom Server beim Laden ermittelt (#101).
 * `fingerprint` geht unveraendert zurueck an createReport; dort wird geprueft,
 * ob genau dieser Stand noch gilt.
 */
export type PrivacyConsentConfig = {
  enabled: boolean
  text: string
  fingerprint: string
}

const PRIVACY_CONSENT_HINT_ID = "privacy-consent-hint"

function createDefaultFormValues(
  publicSubmissionId: string,
  privacyConsentFingerprint: string
): CreateReportInput {
  return {
    publicSubmissionId,
    reportType: "accident",
    shortDescription: "",
    description: "",
    occurredAt: "",
    locationText: "",
    reporterLessonsLearned: "",
    reporterSuggestedMeasures: "",
    activityType: undefined,
    flightPhase: undefined,
    launchType: undefined,
    reporterName: "",
    reporterRole: undefined,
    reporterContact: "",
    injurySeverity: undefined,
    damageSeverity: undefined,
    // Initial leer: Eine Zustimmung muss ausdruecklich erteilt werden.
    privacyConsentGiven: false,
    privacyConsentFingerprint,
  }
}

export function SubmitReportForm({
  privacyConsent,
}: {
  privacyConsent: PrivacyConsentConfig
}) {
  const router = useRouter()
  const [isPending, startTransition] = useTransition()
  const submittingRef = useRef(false)
  // Einmal je geladenem Formular. Frueher wurde nach jedem Erfolg eine neue
  // Kennung erzeugt, weil das Formular fuer die naechste Meldung geleert
  // wurde. Jetzt fuehrt der Bestaetigungsdialog zur Startseite — und die
  // gleichbleibende Kennung ist genau das, was eine Wiederholung nach
  // ausgebliebener Antwort dieselbe Meldung treffen laesst, statt eine zweite
  // anzulegen.
  const [publicSubmissionId] = useState(createPublicSubmissionId)
  const [feedback, setFeedback] = useState<{
    ok: boolean
    message: string
    resultCode?: string
    retryAfterSeconds?: number
    showReportabilityHint?: boolean
  } | null>(null)
  // Steht ein Wert drin, ist die Meldung gespeichert und der
  // Bestaetigungsdialog offen. Er erscheint ausschliesslich nach einer
  // bestaetigten Speicherung — bei jedem Fehlerfall bleibt er zu und das
  // Formular behaelt seine Eingaben.
  const [confirmation, setConfirmation] =
    useState<SubmissionConfirmation | null>(null)

  const {
    register,
    handleSubmit,
    control,
    setValue,
    formState: { errors },
  } = useForm<CreateReportInput>({
    resolver: zodResolver(createReportSchema),
    defaultValues: createDefaultFormValues(
      publicSubmissionId,
      privacyConsent.fingerprint
    ),
  })

  useEffect(() => {
    setValue("publicSubmissionId", publicSubmissionId)
  }, [publicSubmissionId, setValue])

  // Neuer Einwilligungsstand vom Server (nach "Einwilligung neu laden"): Der
  // neue Fingerabdruck gilt, und eine fruehere Zustimmung bezog sich auf einen
  // anderen Text — sie wird zurueckgesetzt. Alle uebrigen Eingaben bleiben.
  useEffect(() => {
    setValue("privacyConsentFingerprint", privacyConsent.fingerprint)
    setValue("privacyConsentGiven", false)
  }, [privacyConsent.fingerprint, setValue])

  const privacyConsentGiven = useWatch({
    control,
    name: "privacyConsentGiven",
    defaultValue: false,
  })
  const submitBlockedByConsent =
    privacyConsent.enabled && privacyConsentGiven !== true
  const privacyConsentParts = splitPrivacyConsentText(privacyConsent.text)

  function reloadPrivacyConsent() {
    setFeedback(null)
    router.refresh()
  }

  const reportType = useWatch({
    control,
    name: "reportType",
    defaultValue: "accident",
  })
  const guidance = PUBLIC_REPORT_GUIDANCE[
    getPublicReportGuidanceGroup(reportType ?? "accident")
  ]
  const shortDescriptionPlaceholder =
    PUBLIC_REPORT_SHORT_DESCRIPTION_PLACEHOLDERS[
      (reportType ?? "accident") as PublicReportType
    ]

  const showReflectionFields =
    reportType === "accident" || reportType === "near_miss"
  const showAccidentSeverityFields = reportType === "accident"

  function onSubmit(data: CreateReportInput) {
    if (submittingRef.current) return
    submittingRef.current = true
    setFeedback(null)
    startTransition(async () => {
      try {
        const basePayload = showReflectionFields
          ? data
          : {
              ...data,
              occurredAt: undefined,
              locationText: undefined,
              reporterLessonsLearned: undefined,
              reporterSuggestedMeasures: undefined,
              activityType: undefined,
              flightPhase: undefined,
              launchType: undefined,
            }
        // Reporter fields are always included — filtering only for accident-only severity fields
        const payload = showAccidentSeverityFields
          ? basePayload
          : {
              ...basePayload,
              injurySeverity: undefined,
              damageSeverity: undefined,
            }

        const result = await createReport(payload)
        const resultCode = "resultCode" in result ? result.resultCode : undefined

        if (
          result.success &&
          (resultCode === "created" || resultCode === "duplicate_submission")
        ) {
          // Das Formular wird NICHT mehr geleert. Frueher liess das die
          // Eingaben wie verloren wirken; jetzt fuehrt der Dialog ohnehin zur
          // Startseite weiter, und bis dahin sieht der Meldende, was er
          // abgeschickt hat.
          //
          // Die Zusammenfassung speist sich aus `payload` — der Kopie dessen,
          // was tatsaechlich uebermittelt wurde. Sie enthaelt damit genau die
          // Felder, die der Server bekommen hat, und aendert sich nicht mehr,
          // wenn im Formular noch etwas angefasst wird.
          setConfirmation({
            publicCode:
              "publicCode" in result ? (result.publicCode ?? null) : null,
            publicStatusEnabled:
              "publicStatusEnabled" in result
                ? Boolean(result.publicStatusEnabled)
                : false,
            submitted: payload,
            submittedAt: new Date(),
            duplicate: resultCode === "duplicate_submission",
            showReportabilityHint:
              "showReportabilityHint" in result
                ? Boolean(result.showReportabilityHint)
                : false,
          })
          setFeedback(null)
          return
        }

        setFeedback({
          ok: result.success,
          message: result.message,
          resultCode,
          retryAfterSeconds: "retryAfterSeconds" in result
            ? result.retryAfterSeconds
            : undefined,
          showReportabilityHint: "showReportabilityHint" in result
            ? (result as { showReportabilityHint?: boolean }).showReportabilityHint
            : false,
        })
      } catch {
        setFeedback({
          ok: false,
          message: "Deine Meldung konnte gerade nicht übermittelt werden. Bitte versuche es später erneut oder wende dich direkt an die Sicherheitsverantwortlichen.",
        })
      } finally {
        submittingRef.current = false
      }
    })
  }

  function handleFormSubmit(event: FormEvent<HTMLFormElement>) {
    // Doppelte Absicherung zur Button-Sperre, etwa fuer Enter in einem Feld.
    // Verbindlich prueft ohnehin der Server.
    if (submitBlockedByConsent) {
      event.preventDefault()
      return
    }
    void handleSubmit(onSubmit)(event)
  }

  return (
    <PageShell variant="wide">
      <p className="mb-8">
        <Link
          href="/"
          className="inline-flex items-center gap-1.5 text-sm text-muted-foreground underline-offset-4 hover:text-foreground hover:underline focus-visible:rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Zurück zur Startseite
        </Link>
      </p>

      <div className="grid gap-10 lg:grid-cols-[2fr_3fr] lg:items-start lg:gap-16">

        {/* Left column: intro and trust content */}
        <div className="space-y-8">
          <PageHeader
            title="Sicherheitsmeldung einreichen"
            subtitle="Melde Unfälle, Beinahe-Ereignisse, Gefahrenquellen oder Hinweise zur Verbesserung der Sicherheit."
          />

          <p className="text-base leading-relaxed text-muted-foreground">
            Jede Meldung zählt: Beinahe-Ereignisse, Beobachtungen und Hinweise
            helfen, Muster zu erkennen und Risiken zu verringern — bevor
            ernsthafte Unfälle entstehen.
          </p>

          <ul className="space-y-4">
            {[
              {
                icon: ShieldCheck,
                title: "Nicht zurechtweisend",
                body: "Meldungen dienen dem gemeinsamen Lernen, nicht der Schuldzuweisung. Es geht darum zu verstehen, was passiert ist — nicht darum, Einzelne zu bewerten.",
              },
              {
                icon: AlertTriangle,
                title: "Kein offizieller Bericht",
                body: "Dieses Formular ersetzt keine Notrufe (112 / 1414) und keine amtlichen Unfallberichte.",
              },
              {
                icon: Lock,
                title: "Anonym möglich",
                body: "Meldungen können ohne Anmeldung eingereicht werden. Die Auswertung erfolgt intern im Sicherheitsmanagementsystem.",
              },
            ].map(({ icon: Icon, title, body }) => (
              <li key={title} className="flex gap-3">
                <div className="mt-0.5 shrink-0 rounded-md bg-primary/10 p-1.5 text-primary">
                  <Icon className="h-4 w-4" />
                </div>
                <div className="text-sm leading-relaxed">
                  <p className="font-medium text-foreground">{title}</p>
                  <p className="mt-0.5 text-muted-foreground">{body}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>

        {/* Right column: form card */}
        <Card className="shadow-md bg-muted">
          <CardHeader className="space-y-1 px-6 pt-7 sm:px-8 sm:pt-8">
            <CardTitle className="text-base font-semibold">
              Angaben zur Meldung
            </CardTitle>
            <CardDescription>
              Nur wenige Pflichtfelder — in deinen eigenen Worten, so ausführlich
              wie nötig.
            </CardDescription>
          </CardHeader>

          <CardContent className="px-6 pb-8 sm:px-8">
            <form
              onSubmit={handleFormSubmit}
              className="space-y-10 sm:space-y-12"
              noValidate
            >
              <input type="hidden" {...register("publicSubmissionId")} />
              <section
                className="space-y-4"
                aria-labelledby="section-report-type"
              >
                <div>
                  <h2
                    id="section-report-type"
                    className="text-base font-semibold tracking-tight text-foreground"
                  >
                    Was möchtest du melden?
                  </h2>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Wähle die passende Kategorie — du kannst Details im nächsten
                    Abschnitt ergänzen.
                  </p>
                </div>

                <div className="space-y-2">
                  <label
                    htmlFor="reportType"
                    className="text-sm font-medium leading-none"
                  >
                    Art der Meldung
                  </label>
                  <select
                    id="reportType"
                    className="flex h-10 w-full rounded-lg border border-input bg-white px-3 py-2 text-base outline-none transition-colors focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/40 md:text-sm"
                    {...register("reportType")}
                  >
                    {PUBLIC_REPORT_TYPE_VALUES.map((value) => (
                      <option key={value} value={value}>
                        {PUBLIC_REPORT_TYPE_LABELS[value]}
                      </option>
                    ))}
                  </select>
                  {errors.reportType ? (
                    <p className="text-sm text-destructive" role="alert">
                      {errors.reportType.message}
                    </p>
                  ) : null}
                </div>

                <div
                  className="rounded-r-lg border-l-2 border-primary/50 bg-primary/5 px-4 py-3 text-sm leading-relaxed text-muted-foreground"
                  role="note"
                >
                  <p className="font-medium text-foreground">
                    {guidance.infoBoxTitle}
                  </p>
                  <p className="mt-2">{guidance.infoBoxBody}</p>
                </div>
              </section>

              <section
                className="space-y-4 border-t border-border pt-10"
                aria-labelledby="section-what-happened"
              >
                <div>
                  <h2
                    id="section-what-happened"
                    className="text-base font-semibold tracking-tight text-foreground"
                  >
                    {guidance.detailsSectionTitle}
                  </h2>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {guidance.detailsSectionLead}
                  </p>
                </div>

                <div className="space-y-2">
                  <label
                    htmlFor="shortDescription"
                    className="text-sm font-medium leading-none"
                  >
                    Kurzbeschreibung{" "}
                    <span className="font-normal text-muted-foreground">
                      (Pflicht, max. 120 Zeichen)
                    </span>
                  </label>
                  <Input
                    id="shortDescription"
                    placeholder={shortDescriptionPlaceholder}
                    maxLength={120}
                    autoComplete="off"
                    aria-invalid={errors.shortDescription ? true : undefined}
                    className="text-base md:text-sm"
                    {...register("shortDescription")}
                  />
                  <p className="text-xs text-muted-foreground">
                    {guidance.shortHelper}
                  </p>
                  {errors.shortDescription ? (
                    <p className="text-sm text-destructive" role="alert">
                      {errors.shortDescription.message}
                    </p>
                  ) : null}
                </div>

                <div className="space-y-2">
                  <label
                    htmlFor="description"
                    className="text-sm font-medium leading-none"
                  >
                    Ausführliche Beschreibung{" "}
                    <span className="font-normal text-muted-foreground">
                      (Pflicht)
                    </span>
                  </label>
                  <Textarea
                    id="description"
                    maxLength={10000}
                    placeholder={guidance.detailPlaceholder}
                    rows={8}
                    className="min-h-[10rem] text-base md:text-sm"
                    {...register("description")}
                  />
                  <p className="whitespace-pre-line text-xs text-muted-foreground">
                    {guidance.detailHelper}
                  </p>
                  {errors.description ? (
                    <p className="text-sm text-destructive" role="alert">
                      {errors.description.message}
                    </p>
                  ) : null}
                </div>
              </section>

              <section
                className="space-y-4 border-t border-border pt-10"
                aria-labelledby="section-reporter"
              >
                <div>
                  <h2
                    id="section-reporter"
                    className="text-base font-semibold tracking-tight text-foreground"
                  >
                    Angaben zur meldenden Person{" "}
                    <span className="text-sm font-normal text-muted-foreground">
                      (freiwillig)
                    </span>
                  </h2>
                  {/* Ue1 (#50): Der Empfaengerkreis wird ausdruecklich benannt.
                      Vorher stand hier nur „freiwillig" — wer sich entscheidet,
                      sollte wissen, wer die Angaben sieht. Die Aufzaehlung
                      entspricht hasReporterIdentityReadRole in
                      lib/constants/roles.ts; aendert sich die Faehigkeit,
                      aendert sich dieser Satz mit. */}
                  <p className="mt-1 text-sm text-muted-foreground">
                    Diese Angaben sind freiwillig. Ohne Namen bleibt die Meldung anonym.
                  </p>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Wenn Sie sie machen, sehen sie ausschließlich Safety Manager
                    und Administrator der Organisation. Andere angemeldete
                    Personen sehen die Meldung, aber nicht, von wem sie stammt.
                    Was Sie in die Beschreibung schreiben oder als Datei
                    anhängen, ist davon nicht erfasst — dort genannte Namen sind
                    für alle internen Rollen lesbar.
                  </p>
                </div>

                <div className="space-y-2">
                  <label
                    htmlFor="reporterName"
                    className="text-sm font-medium leading-none"
                  >
                    Name
                  </label>
                  <Input
                    id="reporterName"
                    maxLength={200}
                    placeholder="Dein Name (optional)"
                    autoComplete="name"
                    className="text-base md:text-sm"
                    {...register("reporterName")}
                  />
                </div>

                <div className="space-y-2">
                  <label
                    htmlFor="reporterRole"
                    className="text-sm font-medium leading-none"
                  >
                    Rolle
                  </label>
                  <select
                    id="reporterRole"
                    className="flex h-10 w-full rounded-lg border border-input bg-white px-3 py-2 text-base outline-none transition-colors focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/40 md:text-sm"
                    {...register("reporterRole")}
                  >
                    <option value="">— bitte wählen —</option>
                    {REPORTER_ROLE_VALUES.map((v) => (
                      <option key={v} value={v}>
                        {REPORTER_ROLE_LABELS[v]}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-2">
                  <label
                    htmlFor="reporterContact"
                    className="text-sm font-medium leading-none"
                  >
                    Kontakt
                  </label>
                  <Input
                    id="reporterContact"
                    maxLength={320}
                    placeholder="E-Mail oder Telefonnummer (optional)"
                    autoComplete="off"
                    className="text-base md:text-sm"
                    {...register("reporterContact")}
                  />
                </div>
              </section>

              {showReflectionFields ? (
                <>
                  <section
                    className="space-y-4 border-t border-border pt-10"
                  >
                    <p className="text-sm text-muted-foreground">
                      Die folgenden Angaben helfen, das Ereignis einzuordnen — sind aber nicht verpflichtend.
                    </p>

                    <div className="space-y-2">
                      <label
                        htmlFor="occurredAt"
                        className="text-sm font-medium leading-none"
                      >
                        Datum und Uhrzeit des Ereignisses
                      </label>
                      <input
                        id="occurredAt"
                        type="datetime-local"
                        className="flex h-10 w-full rounded-lg border border-input bg-white px-3 py-2 text-base outline-none transition-colors focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/40 md:text-sm"
                        {...register("occurredAt")}
                      />
                    </div>

                    <div className="space-y-2">
                      <label
                        htmlFor="locationText"
                        className="text-sm font-medium leading-none"
                      >
                        Ort / Fluggebiet
                      </label>
                      <Input
                        id="locationText"
                        maxLength={500}
                        placeholder="z. B. Startplatz Grente, Landeplatz, Thermikgebiet"
                        autoComplete="off"
                        className="text-base md:text-sm"
                        {...register("locationText")}
                      />
                    </div>

                    <div className="space-y-2">
                      <label
                        htmlFor="activityType"
                        className="text-sm font-medium leading-none"
                      >
                        Flugtyp
                      </label>
                      <select
                        id="activityType"
                        className="flex h-10 w-full rounded-lg border border-input bg-white px-3 py-2 text-base outline-none transition-colors focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/40 md:text-sm"
                        {...register("activityType")}
                      >
                        <option value="">— bitte wählen —</option>
                        {ACTIVITY_TYPE_VALUES.map((v) => (
                          <option key={v} value={v}>
                            {ACTIVITY_TYPE_LABELS[v]}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-2">
                      <label
                        htmlFor="flightPhase"
                        className="text-sm font-medium leading-none"
                      >
                        Flugphase
                      </label>
                      <select
                        id="flightPhase"
                        className="flex h-10 w-full rounded-lg border border-input bg-white px-3 py-2 text-base outline-none transition-colors focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/40 md:text-sm"
                        {...register("flightPhase")}
                      >
                        <option value="">— bitte wählen —</option>
                        {FLIGHT_PHASE_VALUES.map((v) => (
                          <option key={v} value={v}>
                            {FLIGHT_PHASE_LABELS[v]}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-2">
                      <label
                        htmlFor="launchType"
                        className="text-sm font-medium leading-none"
                      >
                        Startart
                      </label>
                      <select
                        id="launchType"
                        className="flex h-10 w-full rounded-lg border border-input bg-white px-3 py-2 text-base outline-none transition-colors focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/40 md:text-sm"
                        {...register("launchType")}
                      >
                        <option value="">— bitte wählen —</option>
                        {LAUNCH_TYPE_VALUES.map((v) => (
                          <option key={v} value={v}>
                            {LAUNCH_TYPE_LABELS[v]}
                          </option>
                        ))}
                      </select>
                    </div>

                    {showAccidentSeverityFields ? (
                      <>
                        <div className="space-y-2">
                          <label
                            htmlFor="injurySeverity"
                            className="text-sm font-medium leading-none"
                          >
                            Verletzungsschwere
                          </label>
                          <select
                            id="injurySeverity"
                            className="flex h-10 w-full rounded-lg border border-input bg-white px-3 py-2 text-base outline-none transition-colors focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/40 md:text-sm"
                            {...register("injurySeverity")}
                          >
                            <option value="">— bitte wählen —</option>
                            {INJURY_SEVERITY_VALUES.map((v) => (
                              <option key={v} value={v}>
                                {INJURY_SEVERITY_LABELS[v]}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div className="space-y-2">
                          <label
                            htmlFor="damageSeverity"
                            className="text-sm font-medium leading-none"
                          >
                            Sachschadenschwere
                          </label>
                          <select
                            id="damageSeverity"
                            className="flex h-10 w-full rounded-lg border border-input bg-white px-3 py-2 text-base outline-none transition-colors focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/40 md:text-sm"
                            {...register("damageSeverity")}
                          >
                            <option value="">— bitte wählen —</option>
                            {DAMAGE_SEVERITY_VALUES.map((v) => (
                              <option key={v} value={v}>
                                {DAMAGE_SEVERITY_LABELS[v]}
                              </option>
                            ))}
                          </select>
                        </div>
                      </>
                    ) : null}
                  </section>

                  <section
                    className="space-y-4 border-t border-border pt-10"
                    aria-labelledby="section-reflection"
                  >
                    <div>
                      <h2
                        id="section-reflection"
                        className="text-base font-semibold tracking-tight text-foreground"
                      >
                        Reflexion{" "}
                        <span className="text-sm font-normal text-muted-foreground">
                          (freiwillig)
                        </span>
                      </h2>
                      <p className="mt-1 text-sm text-muted-foreground">
                        Es geht nicht um Schuld, sondern um gemeinsames Lernen. Deine Einschätzung ist wertvoll — auch wenn du nicht alle Antworten kennst.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <label
                        htmlFor="reporterLessonsLearned"
                        className="text-sm font-medium leading-none"
                      >
                        Was hast du aus dem Ereignis gelernt?
                      </label>
                      <Textarea
                        id="reporterLessonsLearned"
                        maxLength={5000}
                        placeholder="Was würdest du beim nächsten Mal anders machen — oder was hat sich bewährt?"
                        rows={4}
                        className="min-h-[6rem] text-base md:text-sm"
                        {...register("reporterLessonsLearned")}
                      />
                      <p className="text-xs text-muted-foreground">
                        Deine persönliche Einschätzung — kein Muss, aber sehr hilfreich.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <label
                        htmlFor="reporterSuggestedMeasures"
                        className="text-sm font-medium leading-none"
                      >
                        Welche Maßnahme schlägst du vor?
                      </label>
                      <Textarea
                        id="reporterSuggestedMeasures"
                        maxLength={5000}
                        placeholder="z. B. eine Änderung im Ablauf, eine Schulung, eine technische Anpassung"
                        rows={4}
                        className="min-h-[6rem] text-base md:text-sm"
                        {...register("reporterSuggestedMeasures")}
                      />
                      <p className="text-xs text-muted-foreground">
                        Auch eine grobe Idee ist willkommen — du musst keine fertige Lösung haben.
                      </p>
                    </div>
                  </section>
                </>
              ) : null}

              <section
                className="space-y-4 border-t border-border pt-10"
                aria-labelledby="section-more"
              >
                <div>
                  <h2
                    id="section-more"
                    className="text-base font-semibold tracking-tight text-foreground"
                  >
                    Weitere Angaben
                  </h2>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Ohne Anmeldung ist es nicht möglich, Anhänge wie Bilder,
                    Videos oder Tracks hochzuladen. Diese können aber sehr
                    hilfreich sein. Leite sie bitte an einen Verantwortlichen
                    weiter.
                  </p>
                </div>

                {/* createReport begrenzt gespeicherte Meldungen je IP-Identifier;
                    Nginx begrenzt zusaetzlich POST-Spitzen und Request-Groesse. */}

                {privacyConsent.enabled ? (
                  <div className="flex items-start gap-3 rounded-lg border border-border bg-background/60 p-4">
                    <input
                      id="privacyConsentGiven"
                      type="checkbox"
                      {...register("privacyConsentGiven")}
                      className="mt-1 h-4 w-4 shrink-0 rounded border-input accent-primary"
                    />
                    <label
                      htmlFor="privacyConsentGiven"
                      className="text-sm leading-relaxed text-foreground"
                    >
                      {privacyConsentParts.before}
                      {/* Neuer Tab: Das Formular haelt seine Eingaben nur im
                          Browser, ein Seitenwechsel wuerde sie verwerfen. */}
                      <a
                        href={PRIVACY_CONSENT_LINK_HREF}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="font-medium underline underline-offset-2 hover:text-primary"
                      >
                        {PRIVACY_CONSENT_LINK_LABEL}
                      </a>
                      {privacyConsentParts.after}
                    </label>
                  </div>
                ) : null}

                <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
                    <Button
                      type="submit"
                      size="lg"
                      className="w-full sm:w-auto"
                      disabled={isPending || submitBlockedByConsent}
                      aria-describedby={
                        submitBlockedByConsent ? PRIVACY_CONSENT_HINT_ID : undefined
                      }
                    >
                      {isPending ? "Wird gesendet…" : "Meldung absenden"}
                    </Button>
                    {submitBlockedByConsent ? (
                      <p
                        id={PRIVACY_CONSENT_HINT_ID}
                        className="text-sm text-muted-foreground"
                      >
                        Zum Absenden bitte zuerst die Einwilligung zum
                        Datenschutz bestätigen.
                      </p>
                    ) : null}
                  </div>
                </div>

                {feedback ? (
                  <div className="space-y-3">
                    <p
                      className={
                        feedback.ok
                          ? "text-sm text-emerald-700 dark:text-emerald-500"
                          : "text-sm text-destructive"
                      }
                      role="status"
                    >
                      {feedback.message}
                    </p>

                    {feedback.resultCode === "privacy_consent_stale" ? (
                      <Button
                        type="button"
                        variant="outline"
                        onClick={reloadPrivacyConsent}
                      >
                        Einwilligung neu laden
                      </Button>
                    ) : null}

                    {feedback.retryAfterSeconds ? (
                      <p className="text-sm text-muted-foreground">
                        Freigabe in etwa {Math.ceil(feedback.retryAfterSeconds / 60)} Minuten.
                      </p>
                    ) : null}

                    {feedback.showReportabilityHint ? (
                      <div
                        className="rounded-r-lg border-l-2 border-amber-500 bg-amber-50 px-4 py-3 text-sm leading-relaxed dark:bg-amber-950/30"
                        role="alert"
                      >
                        <p className="font-medium text-amber-800 dark:text-amber-300">
                          Hinweis: Meldepflicht prüfen
                        </p>
                        <p className="mt-1 text-amber-700 dark:text-amber-400">
                          Dieser Unfall ist meldepflichtig.{" "}
                          <a
                            href="https://www.dhv.de/sicherheit/unfallmeldung/"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="underline underline-offset-2"
                          >
                            Unfallmeldestelle ist der DHV.
                          </a>
                        </p>
                      </div>
                    ) : null}
                  </div>
                ) : null}
              </section>
            </form>
          </CardContent>
        </Card>

      </div>

      <footer className="mt-10 border-t border-border/60 pt-6">
        <PublicLegalLinks />
      </footer>

      <SubmissionConfirmationDialog confirmation={confirmation} />
    </PageShell>
  )
}
