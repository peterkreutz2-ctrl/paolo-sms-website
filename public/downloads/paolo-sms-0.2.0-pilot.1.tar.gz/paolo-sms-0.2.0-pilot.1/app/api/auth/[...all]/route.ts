import { getBetterAuth } from "@/auth"
import { isAllowedAuthRoute } from "@/lib/auth/auth-route-allowlist"
import { consumeBetterAuthLoginRateLimit } from "@/lib/auth/better-auth-login-rate-limit"
import { usesBetterAuth, usesClerkAuth } from "@/lib/auth/mode"
import { toNextJsHandler } from "better-auth/next-js"

// Im Clerk-Modus gibt es keine Better-Auth-Endpunkte (#105): Die Route
// antwortet mit 404, bevor Better Auth ueberhaupt erzeugt wird. Der Handler
// entsteht deshalb erst beim ersten Aufruf ausserhalb des Clerk-Modus.
let handler: ReturnType<typeof toNextJsHandler> | undefined

function betterAuthHandler() {
  handler ??= toNextJsHandler(getBetterAuth())
  return handler
}

function notFound(): Response {
  return new Response("Not Found", { status: 404 })
}

// Nur die in lib/auth/auth-route-allowlist.ts genannten Pfade erreichen Better
// Auth. Alles andere — insbesondere der Passwort-Reset — antwortet mit 404 (#111).
export async function GET(request: Request): Promise<Response> {
  if (usesClerkAuth()) return notFound()
  if (!isAllowedAuthRoute("GET", new URL(request.url).pathname)) return notFound()
  return betterAuthHandler().GET(request)
}

export async function POST(request: Request): Promise<Response> {
  if (usesClerkAuth()) return notFound()

  const pathname = new URL(request.url).pathname
  if (!isAllowedAuthRoute("POST", pathname)) return notFound()
  if (usesBetterAuth() && pathname === "/api/auth/sign-in/email") {
    let email = ""
    try {
      const body = await request.clone().json() as { email?: unknown }
      if (typeof body.email === "string") email = body.email
    } catch {
      // Better Auth beantwortet ungültige Bodies selbst; der Netz-Zähler bleibt
      // trotzdem vor einem möglichen Passwortpfad wirksam.
    }

    const decision = await consumeBetterAuthLoginRateLimit(email, request.headers)
    if (!decision.allowed) {
      return Response.json(
        { message: "Zu viele Anmeldeversuche. Bitte warten Sie einige Minuten und versuchen Sie es dann erneut." },
        {
          status: 429,
          headers: {
            "Retry-After": String(decision.retryAfterSeconds),
            "Cache-Control": "no-store",
          },
        }
      )
    }
  }

  return betterAuthHandler().POST(request)
}
