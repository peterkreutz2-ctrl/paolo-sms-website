import { appAuth } from "@/lib/auth"
import { and, asc, gte, isNotNull, isNull, lt } from "drizzle-orm"

import { logAuditEvent } from "@/lib/audit"
import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { hasSafetyEditRole } from "@/lib/constants/roles"
import { db } from "@/lib/db"
import { organizations, reports } from "@/lib/db/schema"
import { createFidaExport } from "@/lib/export/fida/mapping"
import { parseFidaExportRange } from "@/lib/export/fida/range"

export const runtime = "nodejs"

export async function GET(request: Request): Promise<Response> {
  const { userId } = await appAuth()
  if (!userId) return Response.json({ error: "Unauthorized." }, { status: 401 })

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return Response.json({ error: "Forbidden." }, { status: 403 })
  }

  let range: ReturnType<typeof parseFidaExportRange>
  try {
    const url = new URL(request.url)
    range = parseFidaExportRange(url.searchParams.get("from"), url.searchParams.get("to"))
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Ungültiger Exportzeitraum." },
      { status: 400 },
    )
  }

  const rows = await db
    .select({
      id: reports.id,
      occurredAt: reports.occurredAt,
      locationText: reports.locationText,
      activityArea: reports.activityArea,
      flightPhase: reports.flightPhase,
      injurySeverity: reports.injurySeverity,
      detailedDescription: reports.detailedDescription,
      createdAt: reports.createdAt,
      updatedAt: reports.updatedAt,
    })
    .from(reports)
    .where(and(
      isNull(reports.deletedAt),
      isNotNull(reports.occurredAt),
      gte(reports.occurredAt, range.from),
      lt(reports.occurredAt, range.to),
    ))
    .orderBy(asc(reports.occurredAt), asc(reports.id))

  const payload = createFidaExport(
    rows.map((row) => ({ ...row, occurredAt: row.occurredAt! })),
  )

  const [organization] = await db.select({ id: organizations.id }).from(organizations).limit(1)
  if (organization) {
    await logAuditEvent({
      organizationId: organization.id,
      clerkUserId: userId,
      action: "REPORTS_EXPORTED",
      resourceType: "organization",
      resourceId: organization.id,
      changes: {
        count: rows.length,
        format: "fida-json",
        schemaVersion: payload.schema_version,
        from: range.fromDate,
        toExclusive: range.toDate,
        attachmentsIncluded: false,
      },
    })
  }

  const body = `${JSON.stringify(payload, null, 2)}\n`
  return new Response(body, {
    headers: {
      "Cache-Control": "private, no-store",
      "Content-Type": "application/json; charset=utf-8",
      "Content-Disposition": `attachment; filename="paolo-fida-${range.fromDate}_${range.toDate}-exclusive.json"`,
      "X-Content-Type-Options": "nosniff",
    },
  })
}
