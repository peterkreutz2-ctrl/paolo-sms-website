import { appAuth } from "@/lib/auth"
import { isNull } from "drizzle-orm"

import { logAuditEvent } from "@/lib/audit"
import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { db } from "@/lib/db"
import { organizations, reports } from "@/lib/db/schema"
import { hasAdminRole } from "@/lib/constants/roles"

// Always-quoted cell: handles embedded quotes, semicolons, newlines, and umlauts
function csvCell(value: string | boolean | Date | null | undefined): string {
  if (value === null || value === undefined) return '""'
  const s = value instanceof Date ? value.toISOString() : String(value)
  return `"${s.replace(/"/g, '""')}"`
}

const SEP = ";"
const CRLF = "\r\n"
const BOM = "﻿" // UTF-8 BOM: Excel opens the file as UTF-8 without a manual import dialog

const HEADERS = [
  "id",
  "reportType",
  "status",
  "priority",
  "shortDescription",
  "detailedDescription",
  "isAnonymous",
  "occurredAt",
  "locationText",
  "reporterLessonsLearned",
  "reporterSuggestedMeasures",
  "sourceChannel",
  "activityArea",
  "activityType",
  "flightPhase",
  "launchType",
  "severity",
  "reporterName",
  "reporterRole",
  "reporterContact",
  "injurySeverity",
  "damageSeverity",
  "isReportableAccident",
  "createdAt",
  "updatedAt",
]

export async function GET() {
  const { userId } = await appAuth()
  if (!userId) {
    return new Response("Unauthorized", { status: 401 })
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasAdminRole(roleKeys)) {
    return new Response("Forbidden", { status: 403 })
  }

  const rows = await db
    .select({
      id: reports.id,
      reportType: reports.reportType,
      status: reports.status,
      priority: reports.priority,
      shortDescription: reports.shortDescription,
      detailedDescription: reports.detailedDescription,
      isAnonymous: reports.isAnonymous,
      occurredAt: reports.occurredAt,
      locationText: reports.locationText,
      reporterLessonsLearned: reports.reporterLessonsLearned,
      reporterSuggestedMeasures: reports.reporterSuggestedMeasures,
      sourceChannel: reports.sourceChannel,
      activityArea: reports.activityArea,
      activityType: reports.activityType,
      flightPhase: reports.flightPhase,
      launchType: reports.launchType,
      severity: reports.severity,
      reporterName: reports.reporterName,
      reporterRole: reports.reporterRole,
      reporterContact: reports.reporterContact,
      injurySeverity: reports.injurySeverity,
      damageSeverity: reports.damageSeverity,
      isReportableAccident: reports.isReportableAccident,
      createdAt: reports.createdAt,
      updatedAt: reports.updatedAt,
    })
    .from(reports)
    .where(isNull(reports.deletedAt))

  const body = rows
    .map((r) =>
      [
        r.id,
        r.reportType,
        r.status,
        r.priority,
        r.shortDescription,
        r.detailedDescription,
        r.isAnonymous,
        r.occurredAt,
        r.locationText,
        r.reporterLessonsLearned,
        r.reporterSuggestedMeasures,
        r.sourceChannel,
        r.activityArea,
        r.activityType,
        r.flightPhase,
        r.launchType,
        r.severity,
        r.reporterName,
        r.reporterRole,
        r.reporterContact,
        r.injurySeverity,
        r.damageSeverity,
        r.isReportableAccident,
        r.createdAt,
        r.updatedAt,
      ]
        .map(csvCell)
        .join(SEP)
    )
    .join(CRLF)

  const csv = BOM + HEADERS.join(SEP) + CRLF + body + CRLF

  const today = new Date().toISOString().slice(0, 10)

  // Audit: logAuditEvent requires a non-null UUID for resourceId.
  // No single report is targeted here, so we use the organization ID as the resource ID.
  const [org] = await db.select({ id: organizations.id }).from(organizations).limit(1)
  if (org) {
    await logAuditEvent({
      organizationId: org.id,
      clerkUserId: userId,
      action: "REPORTS_EXPORTED",
      resourceType: "organization",
      resourceId: org.id,
      changes: { count: rows.length, format: "csv", scope: "all_active_reports" },
    })
  }

  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="reports-${today}.csv"`,
    },
  })
}
