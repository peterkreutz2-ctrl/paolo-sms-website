import { auditBackupEvent } from "@/lib/backup/audit"
import {
  claimBackupCronRun,
  completeBackupCronRun,
  failBackupCronRun,
  isValidBackupCronAuthorization,
} from "@/lib/backup/cron"
import { createBackup } from "@/lib/backup/service"
import { applyBackupRetentionAndAudit } from "@/lib/backup/retention"

export const runtime = "nodejs"

const noStoreHeaders = {
  "Cache-Control": "no-store",
  "Content-Type": "application/json",
}

function json(body: Record<string, unknown>, status: number, headers: Record<string, string> = {}): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...noStoreHeaders, ...headers },
  })
}

export async function POST(request: Request): Promise<Response> {
  if (!isValidBackupCronAuthorization(request.headers.get("authorization"))) {
    console.warn("[backup:cron] Unauthorized scheduled backup request rejected.")
    return json({ success: false, error: "Unauthorized." }, 401, {
      "WWW-Authenticate": "Bearer",
    })
  }

  let claim: Awaited<ReturnType<typeof claimBackupCronRun>>
  try {
    claim = await claimBackupCronRun()
  } catch (error) {
    console.error("[backup:cron] Could not claim scheduled backup run:", error)
    return json({ success: false, error: "Scheduled backup unavailable." }, 503)
  }

  if (!claim.acquired) {
    await auditBackupEvent({
      userId: null,
      backupId: claim.attemptId,
      action: "BACKUP_CRON_REJECTED",
      changes: { reason: claim.reason, retryAfterSeconds: claim.retryAfterSeconds },
    })
    return json(
      { success: false, error: claim.reason === "in_progress" ? "Backup already in progress." : "Backup rate limit active." },
      claim.reason === "in_progress" ? 409 : 429,
      { "Retry-After": String(claim.retryAfterSeconds) },
    )
  }

  try {
    const manifest = await createBackup("system:backup-cron")
    await completeBackupCronRun(manifest.backupId)
    await auditBackupEvent({
      userId: null,
      backupId: manifest.backupId,
      action: "BACKUP_CREATED",
      changes: {
        trigger: "cron",
        engine: manifest.engine,
        fileSize: manifest.fileSize,
        sha256: manifest.sha256,
        encryption: "age",
        attachmentsIncluded: false,
      },
    })
    await applyBackupRetentionAndAudit({ backupId: manifest.backupId, userId: null })
    return json({ success: true, backupId: manifest.backupId, createdAt: manifest.createdAt }, 201)
  } catch (error) {
    await failBackupCronRun().catch((stateError) => {
      console.error("[backup:cron] Could not release failed scheduled backup lease:", stateError)
    })
    await auditBackupEvent({
      userId: null,
      backupId: claim.attemptId,
      action: "BACKUP_CRON_FAILED",
      changes: { reason: "creation_failed" },
    })
    console.error("[backup:cron] Scheduled backup creation failed:", error)
    return json({ success: false, error: "Backup creation failed." }, 500)
  }
}
