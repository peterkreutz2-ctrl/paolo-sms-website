import Link from "next/link"

import { PRIVACY_POLICY_TEMPLATE } from "@/lib/constants/privacy-policy-template"
import { getLegalSettings } from "@/lib/legal-settings"
import {
  buildEffectivePrivacyPolicy,
  PRIVACY_POLICY_MISSING_OPTIONAL_TEXT,
  PRIVACY_POLICY_MISSING_REQUIRED_TEXT,
  PRIVACY_POLICY_TEMPLATE_HEADING,
} from "@/lib/privacy-policy"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { PageHeader } from "@/components/ui/page-header"
import { PageShell } from "@/components/ui/page-shell"

export const dynamic = "force-dynamic"

export const metadata = {
  title: "Datenschutzerklärung – PAOLO SMS",
}

export default async function DatenschutzPage() {
  const legal = await getLegalSettings()

  // Dieselbe Ableitung speist den Snapshot, der mit jeder Datenschutz-
  // Einwilligung an der Meldung gespeichert wird (lib/privacy-policy.ts).
  const { fields, missingRequired, policyText, isIncomplete } =
    buildEffectivePrivacyPolicy(legal)
  const hasPolicyText = policyText !== null

  return (
    <PageShell variant="narrow">
      <div className="space-y-8">
        <PageHeader
          title="Datenschutzerklärung"
          subtitle="Informationen zur Verarbeitung personenbezogener Daten in dieser PAOLO-Instanz."
        />

        <div
          className="rounded-r-lg border-l-2 border-amber-500 bg-amber-50 px-4 py-3 text-sm leading-relaxed dark:bg-amber-950/30"
          role="note"
        >
          <p className="font-medium text-amber-800 dark:text-amber-300">
            {isIncomplete
              ? "Datenschutzerklärung unvollständig – prüfpflichtig"
              : "Vom Betreiber gepflegte Angaben – prüfpflichtig"}
          </p>
          <p className="mt-1 text-amber-700 dark:text-amber-400">
            Die Angaben und der Text dieser Datenschutzerklärung werden vom
            Betreiber der Instanz gepflegt und verantwortet. Sie müssen vor
            Echtdatenbetrieb geprüft und angepasst werden. PAOLO leistet keine
            Rechtsberatung.
          </p>
          {isIncomplete ? (
            <p className="mt-2 text-amber-700 dark:text-amber-400">
              Offen:{" "}
              <span className="font-medium">
                {[
                  ...missingRequired,
                  ...(hasPolicyText ? [] : ["Text der Datenschutzerklärung"]),
                ].join(", ")}
              </span>
              .
            </p>
          ) : null}
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">
              Verantwortlicher und Kontakt (Betreiberangaben)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <dl className="space-y-4">
              {fields.map(({ label, value, required }) => (
                <div key={label}>
                  <dt className="text-sm font-medium text-foreground">
                    {label}
                  </dt>
                  <dd className="mt-0.5 whitespace-pre-line text-sm text-muted-foreground">
                    {value ? (
                      value
                    ) : required ? (
                      <span className="text-amber-700 dark:text-amber-400">
                        {PRIVACY_POLICY_MISSING_REQUIRED_TEXT}
                      </span>
                    ) : (
                      <span className="italic">
                        {PRIVACY_POLICY_MISSING_OPTIONAL_TEXT}
                      </span>
                    )}
                  </dd>
                </div>
              ))}
            </dl>
          </CardContent>
        </Card>

        {hasPolicyText ? (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Datenschutzerklärung</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="whitespace-pre-line text-sm leading-relaxed text-muted-foreground">
                {policyText}
              </div>
            </CardContent>
          </Card>
        ) : (
          <>
            <Card>
              <CardHeader>
                <CardTitle className="text-base">
                  Datenschutzerklärung noch nicht vervollständigt
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Die Datenschutzerklärung wurde vom Betreiber noch nicht
                  vervollständigt. Der nachstehende PAOLO-Vorschlag ist{" "}
                  <span className="font-medium">unverbindlich</span> und ersetzt
                  keine geprüfte Datenschutzerklärung. Der Betreiber übernimmt und
                  prüft ihn in den Einstellungen (Rechtliche Angaben).
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">
                  {PRIVACY_POLICY_TEMPLATE_HEADING}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="whitespace-pre-line text-sm leading-relaxed text-muted-foreground">
                  {PRIVACY_POLICY_TEMPLATE}
                </div>
              </CardContent>
            </Card>
          </>
        )}

        <p className="text-sm text-muted-foreground">
          Zum{" "}
          <Link
            href="/impressum"
            className="underline underline-offset-4 hover:text-foreground"
          >
            Impressum
          </Link>
          {" · "}
          <Link
            href="/"
            className="underline underline-offset-4 hover:text-foreground"
          >
            Zur Startseite
          </Link>
        </p>
      </div>
    </PageShell>
  )
}
