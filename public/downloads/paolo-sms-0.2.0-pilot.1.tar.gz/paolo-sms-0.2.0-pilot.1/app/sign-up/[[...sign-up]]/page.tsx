import { AuthScreen } from "@/lib/auth/auth-screen"

export default function Page() {
  return (
    <main className="flex min-h-screen items-center justify-center">
      <AuthScreen kind="sign-up" />
    </main>
  )
}
