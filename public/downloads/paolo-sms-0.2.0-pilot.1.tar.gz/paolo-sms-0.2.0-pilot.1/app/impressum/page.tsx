import Link from "next/link"

import { getLegalSettings } from "@/lib/legal-settings"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { PageHeader } from "@/components/ui/page-header"
import { PageShell } from "@/components/ui/page-shell"

export const dynamic = "force-dynamic"

export const metadata = {
  title: "Impressum – PAOLO SMS",
}

type Field = {
  label: string
  value: string | null | undefined
  required?: boolean
}

function FieldList({ fields }: { fields: Field[] }) {
  return (
    <dl className="space-y-4">
      {fields.map(({ label, value, required }) => (
        <div key={label}>
          <dt className="text-sm font-medium text-foreground">{label}</dt>
          <dd className="mt-0.5 whitespace-pre-line text-sm text-muted-foreground">
            {value && value.length > 0 ? (
              value
            ) : required ? (
              <span className="text-amber-700 dark:text-amber-400">
                Diese Angabe muss vor Echtdatenbetrieb vom Betreiber ergänzt und
                geprüft werden.
              </span>
            ) : (
              <span className="italic">nicht angegeben</span>
            )}
          </dd>
        </div>
      ))}
    </dl>
  )
}

export default async function ImpressumPage() {
  const legal = await getLegalSettings()

  const operator: Field[] = [
    { label: "Betreiber / Organisation", value: legal?.operatorName, required: true },
    { label: "Rechtsform", value: legal?.operatorLegalForm },
    { label: "Anschrift", value: legal?.operatorAddress, required: true },
    {
      label: "Vertretungsberechtigte Person(en)",
      value: legal?.representedBy,
    },
    { label: "Kontakt (E-Mail)", value: legal?.operatorEmail, required: true },
    { label: "Telefon", value: legal?.operatorPhone },
  ]

  const registerAndTax: Field[] = [
    { label: "Registerangaben", value: legal?.registerInfo },
    { label: "Umsatzsteuer-ID", value: legal?.vatId },
  ]

  const additional: Field[] = [
    { label: "Zusätzliche Angaben", value: legal?.legalExtraText },
  ]

  // Solange Kernangaben fehlen, bleibt der Prüfhinweis sichtbar.
  const missingRequired = operator
    .filter((f) => f.required && !(f.value && f.value.length > 0))
    .map((f) => f.label)
  const isIncomplete = missingRequired.length > 0

  return (
    <PageShell variant="narrow">
      <div className="space-y-8">
        <PageHeader
          title="Impressum"
          subtitle="Angaben zum Betreiber dieser PAOLO-Instanz."
        />

        <div
          className="rounded-r-lg border-l-2 border-amber-500 bg-amber-50 px-4 py-3 text-sm leading-relaxed dark:bg-amber-950/30"
          role="note"
        >
          <p className="font-medium text-amber-800 dark:text-amber-300">
            {isIncomplete
              ? "Angaben unvollständig – prüfpflichtig"
              : "Vom Betreiber gepflegte Angaben – prüfpflichtig"}
          </p>
          <p className="mt-1 text-amber-700 dark:text-amber-400">
            Diese Angaben werden vom Betreiber der jeweiligen PAOLO-Instanz
            gepflegt und verantwortet und müssen vor Echtdatenbetrieb ergänzt und
            rechtlich geprüft werden. PAOLO stellt nur die Struktur bereit und
            leistet keine Rechtsberatung.
          </p>
          {isIncomplete ? (
            <p className="mt-2 text-amber-700 dark:text-amber-400">
              Es fehlen noch Pflichtangaben:{" "}
              <span className="font-medium">{missingRequired.join(", ")}</span>.
            </p>
          ) : null}
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Betreiber und Kontakt</CardTitle>
          </CardHeader>
          <CardContent>
            <FieldList fields={operator} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Register und Steuer</CardTitle>
          </CardHeader>
          <CardContent>
            <FieldList fields={registerAndTax} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Weitere Angaben</CardTitle>
          </CardHeader>
          <CardContent>
            <FieldList fields={additional} />
            <p className="mt-4 text-xs text-muted-foreground">
              Weitere impressumspflichtige Angaben (z. B. eine Aufsichtsbehörde
              oder „Verantwortlich für den Inhalt“) sind nur bei einschlägigen
              Tätigkeiten erforderlich und können vom Betreiber unter
              „Zusätzliche Angaben“ ergänzt werden. Die Datenschutz-Aufsichts­behörde
              wird ausschließlich in der{" "}
              <Link
                href="/datenschutz"
                className="underline underline-offset-4 hover:text-foreground"
              >
                Datenschutzerklärung
              </Link>{" "}
              ausgewiesen.
            </p>
          </CardContent>
        </Card>

        <p className="text-sm text-muted-foreground">
          Zur{" "}
          <Link
            href="/datenschutz"
            className="underline underline-offset-4 hover:text-foreground"
          >
            Datenschutzerklärung
          </Link>
          {" · "}
          <Link
            href="/"
            className="underline underline-offset-4 hover:text-foreground"
          >
            Zur Startseite
          </Link>
        </p>
      </div>
    </PageShell>
  )
}
