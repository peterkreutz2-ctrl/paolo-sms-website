import Link from "next/link"

import { cn } from "@/lib/utils"

type Props = {
  className?: string
}

// Öffentliche Rechts-Links (Impressum, Datenschutz). Bewusst leichtgewichtig,
// damit sie lokal auf öffentlichen Seiten eingebunden werden können, ohne ein
// globales Footer-Layout einzuführen.
export function PublicLegalLinks({ className }: Props) {
  return (
    <nav
      aria-label="Rechtliche Hinweise"
      className={cn(
        "flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground",
        className
      )}
    >
      <Link
        href="/impressum"
        className="underline-offset-4 hover:text-foreground hover:underline focus-visible:rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        Impressum
      </Link>
      <Link
        href="/datenschutz"
        className="underline-offset-4 hover:text-foreground hover:underline focus-visible:rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        Datenschutz
      </Link>
    </nav>
  )
}
