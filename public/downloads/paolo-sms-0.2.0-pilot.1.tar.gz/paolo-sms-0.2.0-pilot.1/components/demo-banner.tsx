import { DEMO_BANNER_TEXT, isDemoMode } from "@/lib/demo/mode"

// Hinweis der Demo-Installation. Steht im Root-Layout und erscheint damit auf
// jeder Seite, auch auf den oeffentlichen und im Dashboard, dessen eigene
// Navigation den globalen Kopf ausblendet. In regulaeren Installationen
// rendert die Komponente nichts.
export function DemoBanner() {
  if (!isDemoMode()) return null

  return (
    <div
      role="note"
      className="w-full border-b border-amber-300 bg-amber-100 px-4 py-2 text-center text-sm font-medium text-amber-950 dark:border-amber-700 dark:bg-amber-950 dark:text-amber-100"
    >
      {DEMO_BANNER_TEXT}
    </div>
  )
}
