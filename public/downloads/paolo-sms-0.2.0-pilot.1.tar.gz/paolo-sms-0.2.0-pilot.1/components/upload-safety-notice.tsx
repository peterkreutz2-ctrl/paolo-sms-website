import { UPLOAD_MALWARE_NOTICE } from "@/lib/constants/upload-safety"

// Geteilter Sicherheitshinweis fuer Upload-Formulare.
//
// Bewusst eine Komponente statt kopiertem Markup: Der Hinweis soll an jeder
// Upload-Stelle gleich aussehen und gleich lauten, und eine neue Upload-Stelle
// soll ihn durch einen Import bekommen — nicht durch Abschreiben.
// tests/attachments/upload-notice.test.ts haelt fest, dass jede Datei mit
// einem Datei-Eingabefeld diese Komponente einbindet.
//
// Darstellung wie die uebrigen Warnhinweise der Anwendung (amberfarbener
// Randbalken, role="note"), damit er sich vom neutralen Hinweis auf erlaubte
// Dateitypen und Groessengrenze abhebt.
export function UploadSafetyNotice() {
  return (
    <p
      role="note"
      className="rounded-r-lg border-l-2 border-amber-500 bg-amber-50 px-3 py-2 text-xs leading-relaxed text-amber-800 dark:bg-amber-950/30 dark:text-amber-300"
    >
      {UPLOAD_MALWARE_NOTICE}
    </p>
  )
}
