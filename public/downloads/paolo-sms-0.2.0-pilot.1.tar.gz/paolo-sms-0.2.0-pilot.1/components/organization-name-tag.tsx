/**
 * Anzeigename der Organisation neben dem Produktnamen (#117): `· Name`.
 *
 * Einzeilig und der einzige Teil des Kopfes, der schrumpft: `min-w-0` erlaubt
 * dem Flex-Kind, unter seine Textbreite zu gehen, `truncate` kuerzt dann mit
 * Auslassungspunkten. Logo, Navigation und Anmeldeknopf bleiben `shrink-0`
 * bzw. behalten ihre Breite. Trenner und Name stehen in einem Element, damit
 * bei voelliger Verdraengung kein einzelner Punkt uebrig bleibt.
 *
 * Der Name wird als React-Text ausgegeben und damit maskiert. Der volle Wortlaut
 * steht im `title`, falls gekuerzt wurde.
 */
export function OrganizationNameTag({ name }: { name: string | null }) {
  if (!name) return null

  return (
    <span
      data-testid="organization-name"
      title={name}
      className="min-w-0 truncate text-sm font-medium text-muted-foreground"
    >
      <span aria-hidden="true">· </span>
      {name}
    </span>
  )
}
