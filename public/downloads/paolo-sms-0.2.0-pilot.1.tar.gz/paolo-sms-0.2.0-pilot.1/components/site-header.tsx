"use client"

import { AuthUserButton } from "@/lib/auth/auth-user-button"
import { buildSignInPath } from "@/lib/auth/redirect-targets"
import Image from "next/image"
import Link from "next/link"
import { usePathname } from "next/navigation"

import { OrganizationNameTag } from "@/components/organization-name-tag"
import { buttonVariants } from "@/components/ui/button"

// Auf der Anmelde- und der Registrierungsseite waere ein „Anmelden"-Knopf
// sinnlos — dort ist man bereits.
const AUTH_PAGES = ["/sign-in", "/sign-up"]

export function SiteHeader({
  signedIn,
  fileAuth,
  betterAuth,
  organizationName,
}: {
  signedIn: boolean
  fileAuth: boolean
  betterAuth: boolean
  // Anzeigename der Organisation (#117) oder null. Kommt von der Serverseite;
  // diese Komponente kennt weder Tabelle noch Abfrage.
  organizationName: string | null
}) {
  const pathname = usePathname()

  // Dashboard has its own complete nav — no global header needed there
  if (pathname.startsWith("/dashboard")) return null

  // Print view of an SMS document is intentionally chrome-free (letterhead-free)
  if (pathname.startsWith("/documents/") && pathname.endsWith("/print"))
    return null

  const isHome = pathname === "/"
  const isAuthPage = AUTH_PAGES.some((page) => pathname.startsWith(page))

  // Bei schmaler Breite rutscht der rechte Block in eine zweite Zeile, statt
  // den Organisationsnamen (#117) zu verdraengen: Der linke Block hat eine
  // Basisbreite, die Logo plus lesbaren Namen fasst. Wo der rechte Block
  // daneben passt (Meldeformular, breite Bildschirme), bleibt es bei einer
  // Zeile von 3,5 rem Hoehe.
  return (
    <header className="flex min-h-14 flex-wrap items-center justify-between gap-x-3 gap-y-2 border-b bg-card px-4 py-2 sm:gap-x-4 sm:px-6">
      {/* Logo behaelt seine Breite (shrink-0), nur der Organisationsname
          schrumpft und wird gekuerzt. */}
      <div
        className={`flex min-w-0 items-center gap-2 ${
          // Ohne Namen bleibt das Verhalten wie vorher.
          organizationName ? "flex-[1_1_14rem]" : "flex-1"
        }`}
      >
        {isHome ? (
          <div aria-current="page" className="shrink-0">
            <Image
              src="/paolo-logo-horizontal.png"
              alt="PAOLO SMS"
              width={600}
              height={194}
              className="h-8 w-auto"
              priority
            />
          </div>
        ) : (
          <Link
            href="/"
            aria-label="PAOLO SMS, zur Startseite"
            className="inline-block shrink-0 focus-visible:rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
          >
            <Image
              src="/paolo-logo-horizontal.png"
              alt="PAOLO SMS"
              width={600}
              height={194}
              className="h-8 w-auto"
              priority
            />
          </Link>
        )}
        <OrganizationNameTag name={organizationName} />
      </div>

      <div className="ml-auto flex max-w-full flex-wrap items-center justify-end gap-x-3 gap-y-1">
        {isHome ? (
          <>
            <Link
              href="/communications"
              className="text-xs text-muted-foreground underline-offset-4 hover:text-foreground hover:underline focus-visible:rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              Sicherheitsinformationen
            </Link>
            <Link
              href="/dashboard"
              className="text-xs text-muted-foreground underline-offset-4 hover:text-foreground hover:underline focus-visible:rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              Internes Dashboard
            </Link>
          </>
        ) : null}

        {/*
          Der Zugang zum Konto haengt an der Sitzung, nicht an der Seite.

          Vorher blendete eine Liste ANONYMOUS_PAGES den Knopf auf „/",
          „/submit-report" und „/communications" pauschal aus — mit drei Folgen:
          Ein angemeldeter Nutzer kam sich auf Startseite und Meldeformular
          nicht abmelden, ein anonymer Besucher fand dort keinen
          Anmeldeeinstieg, und /communications musste sich beides selbst bauen.

          Auf den uebrigen Seiten war es nicht besser: Bei AUTH_MODE=clerk
          rendert der UserButton fuer Anonyme nichts, bei file/betterauth stand
          dagegen ein „Abmelden" auch ohne Sitzung.

          Jetzt entscheidet allein `signedIn`, das die Serverseite im Layout
          ermittelt.
        */}
        {isAuthPage ? null : signedIn ? (
          <AuthUserButton fileAuth={fileAuth} betterAuth={betterAuth} />
        ) : (
          // Bewusst kein Hinweis auf eine Selbstregistrierung: Konten legt die
          // Administration an. Der Rueckweg ist auf eine Positivliste begrenzt
          // (lib/auth/redirect-targets.ts) — von /communications fuehrt er
          // dorthin zurueck, von ueberall sonst auf das Standardziel.
          <a
            href={buildSignInPath(pathname)}
            className={buttonVariants({ variant: "outline", size: "sm" })}
          >
            Anmelden
          </a>
        )}
      </div>
    </header>
  )
}
