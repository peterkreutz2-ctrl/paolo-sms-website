import { DEMO_ACCOUNTS, DEMO_PASSWORD } from "@/lib/demo/accounts"
import { isDemoMode } from "@/lib/demo/mode"
import { ROLE_LABELS } from "@/lib/constants/roles"

// Veroeffentlichte Zugangsdaten auf der Anmeldeseite der Demo. Die Konten
// stehen absichtlich offen; es gibt kein Administratorkonto.
export function DemoCredentials() {
  if (!isDemoMode()) return null

  return (
    <div className="mt-6 rounded-md border border-amber-300 bg-amber-50 p-4 text-sm text-amber-950 dark:border-amber-700 dark:bg-amber-950/40 dark:text-amber-100">
      <p className="font-medium">Zugangsdaten für die Demo</p>
      <dl className="mt-2 space-y-2">
        {DEMO_ACCOUNTS.map((account) => (
          <div key={account.email}>
            <dt className="font-medium">{ROLE_LABELS[account.role]}</dt>
            <dd className="font-mono text-xs">{account.email}</dd>
          </div>
        ))}
      </dl>
      <p className="mt-2">
        Passwort für beide Konten: <span className="font-mono">{DEMO_PASSWORD}</span>
      </p>
    </div>
  )
}
