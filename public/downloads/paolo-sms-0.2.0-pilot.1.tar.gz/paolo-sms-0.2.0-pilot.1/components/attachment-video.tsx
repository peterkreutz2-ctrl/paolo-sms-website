import {
  MAX_FILE_SIZE_MB,
  MAX_VIDEO_DURATION_SECONDS,
} from "@/lib/constants/attachment-file-types"

// Videodarstellung und Video-Hinweis fuer Anhaenge.
//
// Bewusst ohne Player-Framework und ohne eigene Medien-Infrastruktur: ein
// nacktes <video controls>. `preload="none"` laedt erst beim Abspielen — das
// spart Bandbreite auf Seiten mit mehreren Anhaengen und ist auf der
// oeffentlichen Seite auch eine Datenschutzfrage: die Datei wird nur geholt,
// wenn jemand sie wirklich ansehen will.
//
// Keine Range-Unterstuetzung in den Auslieferungsrouten: bei maximal 4 MiB ist
// der Puffer sofort voll, und Chrome, Edge und Firefox spielen eine
// 200-Antwort ohne Range ab. Safari verlangt 206 und spielt deshalb
// voraussichtlich nicht — auf iOS ist das die einzige Engine. Genau deshalb
// steht neben dem Player IMMER der Download-Link; er ist kein Beiwerk,
// sondern der Rueckfallweg fuer diese Geraete.

export function AttachmentVideoPlayer({
  src,
  fileName,
  className,
}: {
  src: string
  fileName: string
  className?: string
}) {
  return (
    <video
      controls
      preload="none"
      className={className ?? "max-h-64 w-full max-w-lg rounded-md border bg-black"}
      // Kein autoplay, kein loop, kein muted-autostart: ein Sicherheitsvideo
      // laeuft nur auf ausdrueckliche Bedienung.
    >
      <source src={src} type="video/mp4" />
      {/* Fallback fuer Browser, die das Element oder den Codec nicht
          unterstuetzen — insbesondere iOS/Safari. */}
      Ihr Browser kann dieses Video nicht abspielen. Bitte die Datei
      herunterladen: {fileName}
    </video>
  )
}

/** Hinweiszeile unter dem Upload-Feld. Nennt die harten Grenzen und die
 * Empfehlungen — ohne zu behaupten, die Wiedergabe funktioniere ueberall. */
export function VideoUploadHint() {
  return (
    <p className="text-xs leading-relaxed text-muted-foreground">
      Videos: nur MP4, max. {MAX_FILE_SIZE_MB} MB und{" "}
      {MAX_VIDEO_DURATION_SECONDS} Sekunden. Empfohlen 720p bei 30 Bildern pro
      Sekunde und möglichst ohne Ton. Größere Aufnahmen vorher kürzen und
      komprimieren – PAOLO wandelt Videos nicht um. Die Wiedergabe im Browser
      hängt vom Gerät ab; der Download steht immer zur Verfügung.
    </p>
  )
}
