import { cn } from "@/lib/utils"

type Variant = "narrow" | "default" | "wide"

const variantClasses: Record<Variant, string> = {
  narrow: "max-w-2xl",
  default: "max-w-4xl",
  wide: "max-w-6xl",
}

type Props = {
  children: React.ReactNode
  variant?: Variant
  className?: string
}

export function PageShell({ children, variant = "default", className }: Props) {
  return (
    <main
      className={cn(
        "mx-auto px-4 py-8 sm:px-6 sm:py-12",
        variantClasses[variant],
        className
      )}
    >
      {children}
    </main>
  )
}
