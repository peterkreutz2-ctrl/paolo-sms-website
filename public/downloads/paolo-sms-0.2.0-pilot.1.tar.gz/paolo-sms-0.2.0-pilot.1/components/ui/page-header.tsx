import { cn } from "@/lib/utils"

type Props = {
  title: string
  subtitle?: string
  children?: React.ReactNode
  className?: string
}

export function PageHeader({ title, subtitle, children, className }: Props) {
  return (
    <div className={cn("space-y-2", className)}>
      <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">
        {title}
      </h1>
      {subtitle ? (
        <p className="text-base leading-relaxed text-muted-foreground">
          {subtitle}
        </p>
      ) : null}
      {children ? <div className="mt-1">{children}</div> : null}
    </div>
  )
}
