import { betterAuth } from "better-auth"
import { drizzleAdapter } from "better-auth/adapters/drizzle"
import { nextCookies } from "better-auth/next-js"

import { ACCESS_LINK_TTL_SECONDS, recordResetToken } from "@/lib/auth/access-link"
import { usesBetterAuth, usesClerkAuth } from "@/lib/auth/mode"
import { db } from "@/lib/db"
import {
  betterAuthAccounts,
  betterAuthSessions,
  betterAuthUsers,
  betterAuthVerifications,
} from "@/lib/db/schema"

// Better Auth wird erst bei Bedarf erzeugt und im Clerk-Modus nie (#105).
//
// Frueher stand hier `export const auth = betterAuth({...})` auf Modulebene.
// lib/auth/index.ts importiert dieses Modul in jedem Modus, also entstand die
// Instanz auch in Clerk-Installationen. Ohne BETTER_AUTH_SECRET faellt Better
// Auth dort auf sein bekanntes Standard-Secret zurueck und wirft in Produktion
// einen BetterAuthError — als unhandledRejection in den Fehlerlogs jeder
// Clerk-Installation, und /api/auth/* antwortete mit 500.
//
// BETTER_AUTH_SECRET im Clerk-Modus zu setzen, waere kein Ersatz: Better Auth
// liefe dann tatsaechlich an, und /api/auth/* waere funktionsfaehig erreichbar.
function createBetterAuth() {
  return betterAuth({
    appName: "PAOLO SMS",
    baseURL:
      process.env.BETTER_AUTH_URL ??
      process.env.APP_BASE_URL ??
      "http://localhost:3000",
    basePath: "/api/auth",
    secret: process.env.BETTER_AUTH_SECRET ?? process.env.AUTH_SECRET,
    database: drizzleAdapter(db, {
      provider: "pg",
      schema: {
        user: betterAuthUsers,
        session: betterAuthSessions,
        account: betterAuthAccounts,
        verification: betterAuthVerifications,
      },
    }),
    emailAndPassword: {
      enabled: usesBetterAuth(),
      disableSignUp: true,
      // Passwort festlegen ueber einen Link, den ein Administrator oder Safety
      // Manager im Dashboard erzeugt (#111) — ohne E-Mail-Dienst. Das Token wird
      // nur abgefangen, wenn der aufrufende Code es verlangt
      // (lib/auth/access-link.ts); die oeffentliche HTTP-Route fuer diesen Ablauf
      // ist gesperrt (lib/auth/auth-route-allowlist.ts).
      resetPasswordTokenExpiresIn: ACCESS_LINK_TTL_SECONDS,
      revokeSessionsOnPasswordReset: true,
      sendResetPassword: async ({ token }) => {
        recordResetToken(token)
      },
    },
    // Der Anmeldeendpunkt wird vor dem Better-Auth-Handler durch den
    // PostgreSQL-Zähler geschützt. Die eingebaute Sonderregel wäre pro Prozess
    // speicherlokal und würde eine abweichende Wartezeit liefern.
    rateLimit: {
      customRules: {
        "/sign-in/email": false,
      },
    },
    session: {
      expiresIn: 60 * 60 * 12,
      updateAge: 60 * 60,
    },
    plugins: [nextCookies()],
  })
}

type BetterAuthInstance = ReturnType<typeof createBetterAuth>

let instance: BetterAuthInstance | undefined

/**
 * Die Better-Auth-Instanz dieser Installation. Im Clerk-Modus ein Fehler:
 * Aufrufer pruefen den Modus vorher (appAuth, Server Actions, Route).
 * Im Better-Auth- und im Datei-Modus wie bisher verfuegbar.
 */
export function getBetterAuth(): BetterAuthInstance {
  if (usesClerkAuth()) {
    throw new Error("Better Auth ist im Clerk-Modus nicht aktiv.")
  }
  instance ??= createBetterAuth()
  return instance
}
