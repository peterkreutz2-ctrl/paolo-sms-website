# Lizenzentscheidung PAOLO SMS

**Status: abgeschlossen und in Kraft.** Beschlossen am 2026-08-30 von Peter
Kreutz, Thomas Behrens und Rainer Poppl.

## 1. Entscheidung

PAOLO SMS steht unter der **GNU General Public License, Version 3 oder später**
— SPDX: `GPL-3.0-or-later`.

- Kommerzielle Nutzung, Verkauf, Hosting und Betrieb als SaaS sind erlaubt.
- Eine proprietäre Einbettung von PAOLO-Code in ein geschlossenes kommerzielles
  Gesamtprodukt ist nicht gewünscht und durch die GPL ausgeschlossen.
- Kein zusätzliches Netzwerk-Copyleft; die AGPL wurde deshalb verworfen.
- Peter, Rainer und Thomas stimmen der Veröffentlichung unter
  GPL-3.0-or-later zu.
- Karls Textbeiträge werden als normale Projektbeiträge behandelt.
- Name und Logo werden separat und später behandelt; bis dahin gilt der
  Vorbehalt in [`NOTICE`](../NOTICE).

Der Geltungsbereich ist einheitlich: Die GPL deckt den Programmcode, die
Dokumentation unter `docs/` **und** die mitgelieferten Dokumentvorlagen. Es
gibt keine Sonderlizenz für einzelne Inhalte.

## 2. Begründung

| Anforderung | GPLv3 | Fundstelle |
|---|---|---|
| Echtes Open Source | erfüllt | OSI-approved, FSF-frei |
| Kommerzielle Nutzung, Verkauf | erfüllt | §0/§4 — keine Einschränkung des Einsatzzwecks |
| Kommerzielles Hosting, SaaS | erfüllt | Betrieb ist kein „conveying“ (§2) |
| Keine proprietäre Einbettung | erfüllt | §5(c) — das kombinierte Werk ist bei Weitergabe insgesamt GPLv3 |
| Änderungen bei Weitergabe offenlegen | erfüllt | §5/§6 |
| Kein Netzwerk-Copyleft | erfüllt | GPLv3 hat kein §13 der AGPLv3 |
| Marken- und Logo-Vorbehalt möglich | erfüllt | §7(e) erlaubt das ausdrücklich als Zusatzbedingung |

Verworfene Alternativen, jeweils mit dem Grund:

- **AGPLv3** — §13 ist genau das nicht gewünschte Netzwerk-Copyleft.
- **MIT / Apache-2.0** — kein Offenlegungszwang bei Weitergabe.
- **BSL / Elastic / Commons Clause** — kein Open Source; verbietet das
  gewünschte kommerzielle Hosting.
- **EUPL-1.2** — ihr Verbreitungsbegriff umfasst das Online-Zugänglichmachen
  und wirkt damit ähnlich wie die AGPL.
- **MPL-2.0 / EPL-2.0** — erlauben die proprietäre Einbettung, die nicht
  gewünscht ist.
- **GPLv2** — technisch ausgeschlossen: `drizzle-orm`, `@vercel/blob` und
  `typescript` stehen unter Apache-2.0, das mit GPLv2 unvereinbar ist. Das war
  der ausschlaggebende technische Grund für Version 3.

## 3. Was die Lizenz für wen bedeutet

| Rolle | Folge |
|---|---|
| **Betreiber** (Verein, Flugschule) | Eigener Betrieb, auch mit eigenen Anpassungen, löst keine Pflichten aus, solange nichts weitergegeben wird (§2). |
| **Dienstleister** | Passt er PAOLO für einen Kunden an und **liefert ihm die Software aus**, ist das eine Weitergabe: Der Kunde erhält Quellcode und GPL-Rechte und darf ihn danach für sich behalten. |
| **Weitergabe von Docker-Images** | Ein Image mit PAOLO ist ein Conveying. Quellcode und Lizenztext gehören dazu — der Lizenztext liegt seit dieser Änderung im Image (siehe 4). |
| **Fork** | Darf alles, ersetzt aber Name und Logos durch eigene. |
| **Betreiberdokumente aus den Vorlagen** | Die Vorlagen stehen unter GPL. Wer ein daraus erstelltes Dokument weitergibt, gibt es unter der GPL weiter. |

Eine Randbemerkung, die keine Entscheidung mehr auslöst, aber in der
Kommunikation gegenüber Betreibern zählt: PAOLO liefert als Next.js-Anwendung
JavaScript an den Browser aus. Ob das ein Conveying ist, ist ungeklärt; die FSF
sieht es so. Deshalb sollte gegenüber Betreibern nicht zugesichert werden, dass
Anpassungen für den Eigenbetrieb *garantiert* privat bleiben.

## 4. Umgesetzte Repo-Änderungen

| Datei | Änderung |
|---|---|
| [`LICENSE`](../LICENSE) | Unveränderter GPLv3-Volltext (674 Zeilen, 35 149 Byte, kanonische Fassung der FSF). Der frühere DRAFT-/0BSD-Zustand ist vollständig beseitigt. |
| [`NOTICE`](../NOTICE) | Copyright-Zeile, GPL-Standardhinweis, Geltungsbereich, Marken- und Logo-Vorbehalt nach §7(e) mit namentlicher Auflistung der ausgenommenen Dateien, Verweis auf die Drittanbieter-Hinweise. |
| `package.json` | `"license": "GPL-3.0-or-later"`; `name` von `sms-mvp` auf `paolo-sms`; `description`, `homepage`, `repository`, `bugs`, `contributors` ergänzt. `"private": true` bleibt — es verhindert nur ein versehentliches `npm publish`. |
| `README.md` | Abschnitt „Lizenz“ mit den praktischen Folgen und den Verweisen. |
| [`CONTRIBUTING.md`](../CONTRIBUTING.md) | Neu. Inbound = outbound: Beiträge stehen unter derselben Lizenz, der Beitragende bestätigt die nötigen Rechte. Dazu Vorgehen, Prüfbefehle und der Hinweis, fremde Herkunft im Pull Request zu nennen. |
| [`THIRD-PARTY-NOTICES.md`](../THIRD-PARTY-NOTICES.md) | Neu. Prüfstand der Abhängigkeiten und Anleitung, wie die Liste für ein Release erzeugt wird. |
| `scripts/third-party-notices.mjs` | Neu. Erzeugt die Drittanbieter-Liste aus dem installierten Baum und prüft gegen eine Positivliste GPLv3-verträglicher Lizenzen. |
| `Dockerfile` | `LICENSE` und `NOTICE` werden in die Runner-Stage kopiert. **Das war eine echte Lücke:** Ein weitergegebenes Image hätte den Lizenztext nicht enthalten, obwohl GPLv3 §4 und §6 ihn verlangen. |
| `AGENTS.md` | Abschnitt „License“ mit den Regeln, die bei Änderungen am Repo gelten. |

Neue npm-Skripte:

```bash
npm run licenses:check                                  # Exit 1 bei unbekannter oder unverträglicher Lizenz
npm run licenses:notices -- --out THIRD-PARTY-LIST.md   # Liste für ein Release
```

## 5. Abhängigkeiten

818 Pakete im installierten Baum, direkt und transitiv geprüft. **Keines ohne
Lizenzangabe, keines GPLv3-unverträglich.**

| Lizenz | Pakete |
|---|---:|
| MIT | 723 |
| Apache-2.0 | 34 |
| ISC | 28 |
| BSD-2-Clause / BSD-3-Clause | 22 |
| MPL-2.0 (nur Dev-Baum) | 3 |
| BlueOak-1.0.0 | 2 |
| Apache-2.0 AND LGPL-3.0-or-later (`@img/sharp-*` via `next`) | 1 |
| Python-2.0, CC-BY-4.0, CC0-1.0, Unlicense, 0BSD | je 1 |

Seit diesem Prüfstand enthält der Lockfile-Baum zusätzlich das nur über
plattformspezifische optionale Sharp-Abhängigkeiten installierte
`@img/sharp-wasm32@0.35.5`. Die Kombination
`Apache-2.0 AND LGPL-3.0-or-later AND MIT` wurde in Issue #95 als mit
GPL-3.0-or-later verträglich bestätigt. Die Prüfung ist automatisiert und
wiederholbar: `npm run licenses:check`. Details in
[`THIRD-PARTY-NOTICES.md`](../THIRD-PARTY-NOTICES.md).

## 6. Erledigte Punkte aus der früheren Prüfung

Die frühere Blockerliste B1–B9 ist abgearbeitet:

| # | Ausgang |
|---|---|
| B1 | Entschieden: kommerzielle Weitergabe ja, proprietäre Einbettung nein. |
| B2 | Zustimmung von Peter, Rainer und Thomas liegt vor. |
| B3, B9 | Karls Textbeiträge und die Vorlagenherkunft werden als normale Projektbeiträge behandelt. Keine weitere urheberrechtliche Klärung. |
| B5 | `AnforderungSMS-System.docx` stammt aus dem Projektkreis und fällt unter dieselbe Behandlung. |
| B6 | Keine Sonderlizenz für die Vorlagen; sie laufen unter der GPL mit. |
| B7 | Zwei Scans über `git log -p --all` — Anbieter-Tokenmuster und private Schlüssel, sowie lange Werte an `*_SECRET`, `*_KEY`, `*_TOKEN`, `PASSWORD` — fanden ausschließlich Platzhalter. Ein unabhängiger Lauf mit `gitleaks` bleibt vor dem Umschalten auf öffentlich empfehlenswert. |
| B8 | In der Dokumentation stehen zwei Klarnamen Dritter, beide im Kontext ihrer Projektbeiträge. Als normale Beitragsnennung behandelt. |
| B4 | Der Marken- und Logo-Vorbehalt in `NOTICE` nimmt die Logodateien vom Lizenzgrant aus. Die Herkunftsfrage reist mit dem Markenthema und blockiert die Lizenz nicht. |

## 7. Optional, nicht erledigt

Keiner dieser Punkte hindert die GPL-Veröffentlichung. Sie sind hier notiert,
damit sie nicht verloren gehen:

- **Lizenz-Header je Quelldatei.** Die FSF empfiehlt in „How to Apply These
  Terms“ einen kurzen Kopf in jeder Datei. Für die Wirksamkeit der Lizenz ist
  er nicht nötig — `LICENSE` plus `NOTICE` genügen. Es wäre ein mechanischer
  Eingriff in mehrere hundert Dateien; bewusst nicht gemacht.
- **Lizenzhinweis im `/impressum`.** GPLv3 §5(d) verlangt „Appropriate Legal
  Notices“ nur für Programme, die interaktiv Kommandos einlesen — das trifft
  auf eine Webanwendung nicht zu. Ein Hinweis auf Lizenz und Quellcode wäre
  trotzdem eine Geste an die Nutzer.
- **`app/icon.png` ist byte-identisch mit `public/paolo-logo-symbol.png`**
  (gleiche MD5, 517 KB für ein Favicon). Reine Hygiene, kein Lizenzthema.
- **Marke und Logo.** Markenanmeldung, Inhaberschaft und eine mögliche
  Markenrichtlinie bleiben offen. Der Vorbehalt in `NOTICE` hält den Status bis
  dahin.
- **Rechteinhaberschaft.** `NOTICE` nennt „PAOLO SMS contributors“. Sobald eine
  Trägerstruktur feststeht, kann die Zeile präzisiert werden.
- **Vor dem Umschalten auf öffentlich:** unabhängiger Secret-Scan (`gitleaks`
  oder `trufflehog`) als Gegenprobe zu B7.

---

Dieses Dokument ist keine Rechtsberatung. Für die Markenfrage ist eine
anwaltliche Prüfung weiterhin ratsam.

## 7. Entscheidung zu Logo-, Schrift- und Markenrechten für das erste Pilot-Release

Stand 26.10.2026, Entscheidung von Peter Kreutz: Die weitere Klärung der Logo-,
Schrift- und Markenrechte ist für das erste Pilot-Release nicht erforderlich. PAOLO ist
ein ehrenamtliches, kostenloses und nichtkommerzielles Hobbyprojekt; das verbleibende
rechtliche Restrisiko wird bewusst akzeptiert. Das Thema ist kein Release-Blocker.
Weitere Recherchen oder Maßnahmen dazu erfolgen nur bei einem konkreten neuen Anlass.
Der Vorbehalt in [`NOTICE`](../NOTICE) bleibt unverändert.
