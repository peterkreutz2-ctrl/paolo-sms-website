# Administrator – Hilfe

*Diese Seite beschreibt die Bedienung. Verbindlich für den Berechtigungsumfang
ist [`../permission-matrix.md`](../permission-matrix.md).
Die Bedeutung der hier verwendeten Fachbegriffe steht im [`../glossar.md`](../glossar.md).*

## Rolle des Administrators

Der Administrator hat vollständigen Zugriff auf alle Bereiche von PAOLO SMS. Er ist für die technische und organisatorische Einrichtung des Systems verantwortlich und unterstützt den Safety Manager bei administrativen Aufgaben.

## Administrationsübersicht

Alle Verwaltungs- und Kontrollfunktionen sind über `/dashboard/admin` erreichbar. Die Kacheln auf dieser Seite führen direkt zu den jeweiligen Bereichen; welche Kachel für welche Rolle erscheint, ergibt sich aus der Berechtigung der Zielseite — die vollständige Aufstellung steht in [`../permission-matrix.md`](../permission-matrix.md), Abschnitt „Seiten und Routen".

## Benutzer und Rollen verwalten

Unter `/dashboard/users` können Benutzer angelegt und Rollen zugewiesen werden.

Verfügbare Rollen sind Administrator, Safety Manager, Safety Assistant und Benutzer. Wozu jede Rolle da ist und wo ihre Grenzen liegen, steht in [`../role-responsibilities.md`](../role-responsibilities.md); was sie technisch darf, in [`../permission-matrix.md`](../permission-matrix.md).

Rollen werden in der PAOLO-Datenbank gespeichert. Clerk wird ausschließlich für die Authentifizierung (Login) verwendet. Die Rollenzuweisung erfolgt im Dashboard unter `/dashboard/users`.

### Kontenliste und Status

Die Liste „Angemeldete Personen" zeigt alle Konten der Installation, auch wenn es sehr viele sind. Pro Konto steht ein Status:

- **Aktiv** — das Konto besteht und hat eine Rolle.
- **Ohne Rolle** — das Konto kann sich anmelden, hat aber keinen internen Zugang. Dort lässt sich direkt eine Rolle zuweisen.
- **Konto fehlt** — für die Rolle gibt es beim Anmeldedienst kein Konto mehr (verwaiste Rolle). „Rolle bereinigen" entfernt sie. Eine verwaiste Administratorrolle zählt nicht als funktionsfähiger Administrator.
- **Konto nicht prüfbar** — der Anmeldedienst ist gerade nicht erreichbar. Die Liste kann dann unvollständig sein.

Es bleibt immer mindestens ein funktionsfähiger Administrator: Der letzte kann weder herabgestuft noch seiner Rolle beraubt werden. Ist der Anmeldedienst nicht erreichbar, lässt sich eine Administratorrolle vorübergehend nicht ändern.

### Anmeldelink erneuern

Ist ein Zugang verloren oder abgelaufen, erzeugt „Anmeldelink erneuern“ in der Zeile des Kontos einen neuen Link. Das geht für alle Konten außer dem eigenen und nur für Konten, die es noch gibt.

- **Clerk:** Der Link meldet die Person direkt an.
- **Better Auth:** Der Link führt zur Seite „Passwort festlegen“. Die Person legt dort selbst ein neues Passwort fest; danach sind ihre bisherigen Sitzungen beendet und das alte Passwort gilt nicht mehr.

Der Link gilt **sieben Tage**, erscheint **nur einmal** auf dem Bildschirm und wird nirgends gespeichert. Im Audit-Log steht, dass und für wen ein Link erstellt wurde — nie der Link selbst. Bitte nur an die betreffende Person weitergeben. **Ältere Links bleiben bis zu ihrem Ablauf gültig**; ein neuer Link macht sie nicht ungültig.

### Kontodaten ändern und Konto löschen

**Kontodaten ändern** (in der Zeile des Kontos): Der Name lässt sich bei Clerk und Better Auth ändern, die E-Mail-Adresse nur bei Better Auth. Bei Clerk ändert die Person ihre E-Mail-Adresse selbst im Benutzerprofil des Anmeldedienstes. Bei Better Auth meldet sich die Person danach mit der neuen Adresse an; eine Benachrichtigung wird nicht verschickt. Rolle und Passwort bleiben erhalten. Das eigene Konto ist ausgenommen.

**Konto löschen** entfernt das Konto beim Anmeldedienst, seine Sitzungen und seine Rolle endgültig — ohne vorherige Sperrung. Zur Bestätigung ist die vollständige E-Mail-Adresse einzugeben. Nicht möglich ist das für das eigene Konto und für Konten mit **Administratorrolle**: Dort zuerst die Rolle ändern (der letzte funktionsfähige Administrator bleibt geschützt). Meldungen, Notizen, Besprechungen, SMS-Dokumente und Audit-Einträge bleiben unverändert und zeigen danach nur noch eine gekürzte Kennung. Im Audit-Log stehen „Kontodaten geändert“ (nur welche Felder) und „Konto gelöscht“ (ohne Name und E-Mail).

Bei Clerk geschieht die Löschung in zwei Schritten. Scheitert der zweite, meldet PAOLO das ausdrücklich; die Rolle erscheint dann als „Konto fehlt“ und lässt sich mit „Rolle bereinigen“ entfernen. Löschanfragen nach DSGVO werden weiterhin über die Datenschutzprozesse bearbeitet. Nach einem Restore aus einem Backup sind gelöschte Konten wieder da (siehe `backup-restore.md`).

### Neuen Benutzer anlegen

Der Ablauf hängt vom Anmeldeverfahren der Installation ab; das Formular zeigt die jeweils nötigen Felder.

**Bei Clerk (Installationsstandard)**

1. E-Mail-Adresse und gewünschte Rolle eintragen und das Formular absenden.
2. PAOLO prüft, ob in Clerk bereits ein Benutzer mit dieser E-Mail existiert.
3. Falls nicht, wird ein Clerk-Benutzer ohne Passwortpflicht angelegt.
4. Die PAOLO-Rolle wird in der PAOLO-Datenbank gespeichert.
5. PAOLO erzeugt einen einmaligen Sign-in-Link (gültig 7 Tage).
6. Den Link kopieren und manuell an die betreffende Person senden.

Ist der Link abgelaufen, kann der Vorgang erneut ausgeführt werden. Da der Clerk-Benutzer bereits existiert, wird nur ein neuer Link erzeugt — Rolle und Konto bleiben erhalten.

**Bei Better Auth**

Das Formular verlangt zusätzlich **Name** und ein **Anfangspasswort mit mindestens 8 Zeichen**. Einen Sign-in-Link gibt es hier nicht: Konto und Rolle werden direkt in der PAOLO-Datenbank angelegt. Das Passwort auf sicherem Weg übermitteln; die Person sollte es nach der ersten Anmeldung ändern.

### GitHub-Zugriff und PAOLO-SMS-Zugriff

Beide Systeme sind voneinander unabhängig:

- GitHub-Kollaborateure erhalten nicht automatisch Zugriff auf das PAOLO-Dashboard.
- Ein PAOLO-Benutzer benötigt nicht zwingend GitHub-Zugriff.
- Dashboard-Zugriff erfordert immer eine PAOLO-Rolle, die unter `/dashboard/users` vergeben wird.

## Organisationseinstellungen

Erreichbar über `/dashboard/admin` → Organisationseinstellungen. Die Seite hat vier Bereiche: **Anzeigename**, **Fristen & Erinnerungen**, **Öffentliche Statusrückmeldungen** und **SMS-Verantwortung**.

Unter **Anzeigename** steht der „Anzeigename der Organisation“, zum Beispiel „Flugschule Hot Sport“. Er erscheint einzeilig neben „PAOLO SMS“ im Kopf der Anwendung, im öffentlichen Bereich und im Dashboard, und hilft, mehrere Installationen zu unterscheiden. Er ist **öffentlich sichtbar**, auch ohne Anmeldung – bitte keine personenbezogenen oder vertraulichen Angaben eintragen. Zulässig sind höchstens 100 Zeichen; Leerraum am Rand wird entfernt. Bleibt das Feld leer, steht im Kopf nur „PAOLO SMS“. Auf schmalen Bildschirmen wird nur der Anzeigename gekürzt. Bei einer neu eingerichteten Installation beginnt der Anzeigename mit dem Namen, der bei der Einrichtung eingegeben wurde; danach sind beide unabhängig. Jede Änderung steht mit altem und neuem Wert im Audit-Log.

Unter **Fristen & Erinnerungen** wird der Turnus für Sicherheitsbesprechungen eingestellt (Wert in Monaten, Minimum 1, Maximum 24). Der Standardwert ist 12 Monate. Dort steht außerdem der optionale Prüfturnus für die datenschutzrechtliche Prüfung abgeschlossener Meldungen.

Oberhalb von 12 Monaten blendet das Formular einen Hinweis ein: Sicherheitsbesprechungen sollten mindestens einmal jährlich, idealerweise vierteljährlich stattfinden; bei akuten Anlässen wie schweren Unfällen sollten zusätzlich außerordentliche Sicherheitsbesprechungen einberufen werden. Der Hinweis ist eine fachliche Empfehlung und verhindert das Speichern nicht.

Unter **Öffentliche Statusrückmeldungen** steht der Schalter „Statusrückmeldungen öffentlich anzeigen“ (Voreinstellung: eingeschaltet). Er steuert, ob auf der öffentlichen Seite „Sicherheitsinformationen“ die zugeklappte Box „Status von Sicherheitsmeldungen“ erscheint — dort stehen ausschließlich der neutrale Meldungscode und der Bearbeitungsstatus. Ist der Schalter aus, werden auch keine Statusdaten öffentlich bereitgestellt; Meldungen, Meldungscodes und der Bearbeitungsstand bleiben unverändert erhalten, und die Dreimonatsfrist läuft weiter. Jedes Umschalten steht im Audit-Log.

## Datenschutz-Einwilligung im Meldeformular

Erreichbar über `/dashboard/privacy` → **Einwilligung im Meldeformular**. Administratoren und Safety Manager können sie bedienen.

- **Einwilligung im Meldeformular abfragen** (Voreinstellung: eingeschaltet, auch nach einem Update bestehender Installationen): Das Meldeformular zeigt ein leeres Pflicht-Kontrollkästchen mit dem Einwilligungstext. „Meldung absenden“ ist erst nach Zustimmung möglich; der Server prüft das zusätzlich. Ausgeschaltet erscheint kein Kontrollkästchen.
- **Einwilligungstext:** Voreingestellt ist ein abgestimmter Standardtext. Ein eigener Text muss `[Datenschutzerklärung]` genau einmal enthalten; dort erscheint im Formular der Link zur Datenschutzerklärung (öffnet in neuem Tab). „Standardtext einsetzen“ stellt den Standard wieder her. Eine Textänderung sollte vorher rechtlich geprüft sein.
- Zu jeder Meldung mit Einwilligung speichert PAOLO den Zeitpunkt, den angezeigten Einwilligungstext und die zu diesem Zeitpunkt gültige Datenschutzerklärung. Bereits vorhandene Meldungen bleiben ohne diesen Nachweis.
- Wer Schalter, Text oder die rechtlichen Angaben ändert, während jemand gerade eine Meldung ausfüllt, löst dort eine Ablehnung aus: Die Einwilligung muss neu geladen und erneut bestätigt werden. Die übrigen Eingaben bleiben erhalten.
- Jede Änderung an Schalter und Text steht im Audit-Log.

Einzelheiten: [`../privacy-operations.md`](../privacy-operations.md).

## Import und Export

Beide Funktionen sind nur für Administratoren verfügbar und über `/dashboard/admin` erreichbar.

- **Import** (`/dashboard/import`): Vorhandene Meldungen aus einer CSV-Datei importieren. Nützlich bei der Ersteinrichtung oder Migration von Altdaten.
- **Export** (`/api/export/reports`): Alle aktiven Meldungen als CSV-Datei herunterladen. Geeignet für externe Auswertungen oder Archivierung.

## Technische und organisatorische Grenzen

- PAOLO SMS ist ein MVP. Nicht alle denkbaren Funktionen sind bereits implementiert.
- Dateianhänge werden je nach `STORAGE_PROVIDER` entweder über Vercel Blob oder im lokalen Dateisystem gespeichert. Nur bei `vercel-blob` wird ein gültiger `BLOB_READ_WRITE_TOKEN` benötigt; bei `local` genügt ein beschreibbares Verzeichnis (`LOCAL_STORAGE_DIR`), wie es die Docker-Installation verwendet.
- Anhänge sind auf **4 MB** je Datei begrenzt. Der Wert ergibt sich aus dem Request-Limit von Vercel und gilt einheitlich für beide Speicherarten. Größere Dateien erreichen die Anwendung nicht.
- **Die Datensicherung umfasst die Anhänge nicht.** Gesichert wird nur die Datenbank (`attachmentsIncluded: false`); nach einer Wiederherstellung verweisen die Datensätze auf Dateien, die fehlen. Die Dateien sind separat zu sichern – siehe [`backup-restore.md`](../backup-restore.md).
- Die Datenbank ist PostgreSQL; wo sie läuft, entscheidet der Betreiber (verwalteter Anbieter oder eigener Server). Für den Betrieb wird eine gültige `DATABASE_URL` benötigt.
- Das Anmeldeverfahren legt `AUTH_MODE` fest: `clerk` (Installationsstandard) oder `betterauth` (Selbstbetrieb ohne externen Dienst). Bei Clerk müssen die Clerk-Schlüssel stimmen, bei Better Auth ein eigenes `BETTER_AUTH_SECRET`. `file` ist ausschließlich für die Entwicklung und im Produktionsbetrieb gesperrt.

## Keine Secrets ins Repository

Environment-Variablen (Datenbankzugang, API-Keys, Tokens) dürfen nicht ins Git-Repository committet werden. Sie gehören in die Umgebung der jeweiligen Installation — lokal in `.env.local`, im Betrieb in die Umgebungsverwaltung der Plattform beziehungsweise in die Konfiguration des Containers.

## Typische administrative Aufgaben

- Neue Benutzer anlegen und Rollen zuweisen
- Turnus der Sicherheitsbesprechungen prüfen und bei Bedarf anpassen
- Entscheiden, ob Statusrückmeldungen öffentlich angezeigt werden
- CSV-Export zur Archivierung durchführen
- Audit-Log bei Unklarheiten einsehen
- Bei technischen Problemen: Umgebungsvariablen und Deploymentstatus prüfen
