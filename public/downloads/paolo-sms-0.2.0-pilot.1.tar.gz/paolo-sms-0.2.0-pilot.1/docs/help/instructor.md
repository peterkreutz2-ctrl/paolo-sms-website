# Safety Assistant (`instructor`) – Hilfe

*Diese Seite beschreibt die Bedienung. Verbindlich für den tatsächlichen
Berechtigungsumfang ist [`../permission-matrix.md`](../permission-matrix.md);
wozu die Rolle fachlich da ist und welche Fragen dazu offen sind, steht in
[`../role-responsibilities.md`](../role-responsibilities.md).
Die Bedeutung der hier verwendeten Fachbegriffe steht im [`../glossar.md`](../glossar.md).*

## Rolle im Sicherheitsprozess

Safety Assistants sind ein wichtiger Teil des Sicherheitsprozesses. Sie sind oft erste Ansprechperson am Startplatz und können sicherheitsrelevante Beobachtungen direkt einbringen. Im System haben Safety Assistants Lesezugriff auf Meldungen und können ergänzende Informationen und Anhänge beisteuern.

## Dashboard-Zugang

Safety Assistants können sich anmelden und das Dashboard nutzen. Sichtbar sind:

- Meldungsliste und Meldungsdetails
- Maßnahmenliste
- SMS-Dokumente der Stufen „Intern", „Angemeldete Personen" und „Öffentlich" — nicht „Vertraulich"

Bereiche, die nur für Safety Manager und Administratoren zugänglich sind (Audit-Log, Sicherheitsbesprechungen, Einstellungen, Datenschutzprozesse, Papierkorb), sind nicht sichtbar.

## Meldungen einsehen

Safety Assistants können alle Meldungen der Organisation einsehen, inkl. Detailseite mit Beschreibung, Status, Priorität und Maßnahmen. Die Bearbeitung von Status, Priorität und Workflow liegt beim Safety Manager.

**Nicht sichtbar sind die Angaben zur meldenden Person** (Name, Rolle, Kontakt) **und die internen Notizen und Nachträge.** Beides liegt beim Safety Manager und beim Administrator. Die Detailseite zeigt für diese Rolle keinen leeren Abschnitt, sondern gar keinen — die Daten werden serverseitig nicht einmal geladen.

> **Warum das so ist.** PAOLO trägt eine nicht-punitive Meldekultur, und der Safety Assistant ist häufig selbst die Person, über die gemeldet wird. Die Rolle soll den Stand des Sicherheitsmanagements kennen, arbeitet aber nicht am Regelkreis mit: Wer nicht klassifiziert, bewertet, entscheidet und nicht an die meldende Person zurückmeldet, braucht deren Identität für keine seiner Aufgaben. Vertrauenswürdigkeit ändert daran nichts — sie senkt das Risiko, begründet aber keinen Zweck. Entschieden als Ü1 zu [Issue #50](https://github.com/peterkreutz2-ctrl/paolo-sms/issues/50).

**Was das nicht bedeutet.** Beschreibungen, Anhänge und das Feld „Verantwortlich" an Maßnahmen können weiterhin Namen enthalten — das *ist* der sicherheitsfachliche Inhalt. Was Sie dort erfahren, gehört genauso vertraulich behandelt und nicht in Gespräche außerhalb des Sicherheitsprozesses.

## Ergänzende Informationen und Anhänge

Safety Assistants können Dateianhänge (Fotos, Dokumente) zu Meldungen hochladen. Das Löschen von Anhängen ist für Safety Assistants nicht möglich.

Erlaubt sind JPG, PNG, WEBP, PDF, TXT, IGC, GPX, KML und MP4, jeweils bis 4 MB. Videos zusätzlich: nur MP4 und höchstens 60 Sekunden, empfohlen 720p bei 30 Bildern pro Sekunde und möglichst ohne Ton. PAOLO wandelt Videos nicht um – längere oder größere Aufnahmen müssen vorher gekürzt und komprimiert werden. Passt eine Datei nicht, erscheint der Hinweis schon bei der Auswahl.

**Nicht möglich für Safety Assistants:** Anhänge an SMS-Dokumenten **verwalten**. Unter „Dokumente" wird der Anhangsbereich für diese Rolle nicht angezeigt; Hochladen, Löschen und die öffentliche Freigabe liegen ausschließlich bei Safety Manager und Administrator.

**Herunterladen** ist dagegen möglich, soweit das zugehörige Dokument für die Rolle lesbar ist (Stufen „Intern", „Angemeldete Personen", „Öffentlich"). Anhänge erben die Sichtbarkeit ihres Dokuments — sie haben keine eigene.

Notizen oder Nachträge zu Meldungen können Safety Assistants nicht hinzufügen – dies ist Aufgabe des Safety Managers.

## Benutzer- und Rollenverwaltung

Safety Assistants **haben** Zugriff auf die Zugangs- und Rollenverwaltung (`/dashboard/users`). Der Menüpunkt wird für die Rolle nicht angezeigt, die Seite ist aber über ihre Adresse erreichbar und serverseitig freigegeben.

Dort möglich:

- die Rolle **Benutzer** (`member`) vergeben — und nur diese
- ein neues Konto mit der Rolle Benutzer anlegen
- die Rolle Benutzer wieder entziehen, sofern der betroffenen Person dadurch nicht ihre einzige Rolle genommen wird
- eine verwaiste Rolle Benutzer bereinigen (Status „Konto fehlt"), wenn das Konto beim Anmeldedienst nicht mehr existiert

Nicht möglich: die Rollen Safety Assistant, Safety Manager oder Administrator vergeben oder entziehen. Auch „Anmeldelink erneuern“, „Kontodaten ändern“ und „Konto löschen“ stehen Safety Assistants nicht zur Verfügung; das übernehmen Safety Manager oder Administratoren.

Die Liste zeigt nur Konten, die Sie auch verwalten dürfen — Administratoren und Safety Manager erscheinen dort nicht, auch nicht als Verzeichnis-ID im Seitenquelltext.

> **Ein Punkt bleibt offen.** Dass die Rolle überhaupt Konten anlegen kann, geht über die vorgesehene Aufgabe („neuen Mitgliedern die Mitglieds-Rolle geben") hinaus und steht als offener Punkt in [`../role-responsibilities.md`](../role-responsibilities.md). Die Zugangs- und Rollenverwaltung sollte bis dahin nur für diesen einen Zweck genutzt werden.

## Öffentliche Statusrückmeldung

Meldungen aus dem öffentlichen Formular bekommen beim Speichern einen neutralen Meldungscode (zum Beispiel `Falke-12`). Auf der öffentlichen Seite „Sicherheitsinformationen“ steht dazu eine zugeklappte Box „Status von Sicherheitsmeldungen“ mit Code und Bearbeitungsstatus — sonst nichts.

Für Safety Assistants ist das reine Hintergrundinformation: **Sie können daran nichts ändern.** Die Anzeige folgt automatisch dem Status, den der Safety Manager setzt.

Zwei Dinge, nach denen am Startplatz gefragt werden könnte:

- **„Wo finde ich meinen Code?"** Er steht im Bestätigungsfenster direkt nach dem Absenden und in der Zusammenfassung, die sich dort herunterladen lässt. Wer beides verpasst hat, kann ihn nicht nachträglich abrufen — dann hilft nur eine neue Meldung.
- **„Meine Meldung ist verschwunden."** Abgeschlossene Meldungen verschwinden drei Monate nach dem Abschluss aus der Liste, ausgeblendete sofort. Die Meldung selbst bleibt im System.

Der Meldungscode ist **kein Zugang**: Wer ihn kennt, sieht damit weder Inhalte noch Melderangaben.

## Organisationseinstellungen

Safety Assistants haben keinen Zugriff auf die Einstellungsseite (`/dashboard/settings`).

## Zusammenarbeit mit dem Safety Manager

Wenn ein Safety Assistant eine relevante Beobachtung macht, die über eine Meldung hinausgeht (z. B. ein Muster bei Ereignissen oder ein dringender Handlungsbedarf), sollte er dies direkt mit dem Safety Manager besprechen. PAOLO SMS unterstützt die Kommunikation, ersetzt aber keine direkte Absprache.
