# PAOLO SMS – Hilfe-Dokumentation

Diese Dokumentation beschreibt die Nutzung von PAOLO SMS aus der Perspektive der verschiedenen Zielgruppen.

## Verweise auf andere Unterlagen

Die Anleitungen verweisen auf Dokumente ausserhalb dieses Verzeichnisses, allen
voran auf `../permission-matrix.md`. Solche relativen Verweise sind hier im
Repository richtig und bleiben so stehen.

Fuer die In-App-Hilfe schreibt `npm run help:generate` sie um:

- Ziel ist eines der mitausgelieferten Nachschlagedokumente
  (`HELP_REFERENCE_SOURCES` in `scripts/help/help-manifest.ts`)
  → `/dashboard/hilfe/<schluessel>`, ein Abschnittsanker bleibt erhalten.
- Ziel ist eine andere Repository-Datei → der Link entfaellt, der Text bleibt.
- Externe Adressen und reine Anker bleiben unveraendert.

Wer auf eine weitere Datei verweisen moechte, die in der Anwendung erreichbar
sein soll, traegt sie in `HELP_REFERENCE_SOURCES` ein. Ohne diesen Eintrag
erscheint der Verweis in der Hilfe als reiner Text — nie als toter Link.
`tests/help/help-links.test.ts` haelt das fest.

## Prinzip

Die Hilfe ist kontextspezifisch und rollenbezogen aufgebaut. Jede Zielgruppe bekommt genau die Informationen, die für ihre Aufgaben im System relevant sind.

## Zielgruppen

| Zielgruppe | Dokument |
|---|---|
| Meldende Personen (extern oder intern) | [`reporter.md`](reporter.md) |
| Safety Assistant (`instructor`) | [`instructor.md`](instructor.md) |
| Safety Manager | [`safety-manager.md`](safety-manager.md) |
| Administrator | [`admin.md`](admin.md) |

Für Besucher der öffentlichen Startseite: [`public-page.md`](public-page.md)

Diese Hilfe beschreibt die **Bedienung**. Wozu eine Rolle fachlich da ist,
welche Rechte sie dafür braucht und wo bewusste Grenzen liegen, steht in
[`../role-responsibilities.md`](../role-responsibilities.md).

## In-App-Hilfe

Die Anleitungen für **Administrator**, **Safety Manager** und **Safety Assistant**
werden in der Anwendung unter `/dashboard/hilfe` ausgeliefert; welche davon
erscheint, richtet sich nach der Rolle des angemeldeten Benutzers.

**Diese Dateien bleiben die einzige Quelle.** Die Anwendung liest sie aber
nicht zur Laufzeit, sondern bekommt eine erzeugte Kopie in
`lib/help/help-content.generated.ts`. Grund: Der Produktionsbuild ist
eigenständig (`output: "standalone"`), und das Docker-Image enthält `docs/`
nicht — ein Lesen zur Laufzeit hätte lokal funktioniert und erst im Betrieb
gefehlt.

**Nach jeder Änderung an `admin.md`, `safety-manager.md` oder
`instructor.md`:**

```bash
npm run help:generate
```

Das Ergebnis gehört mit in den Commit. Wer es vergisst, fällt in
`tests/help/help-content.test.ts` auf — nicht erst im Betrieb mit veralteter
Hilfe.

`reporter.md` und `public-page.md` sind bewusst **nicht** eingebunden: Sie
richten sich an den öffentlichen Bereich, und ihn mit einer Hilfeseite zu
versehen wäre eine eigene Entscheidung mit eigenem Ton.

## Einsatzorte

- Startseite `/` — allgemeine Erklärung des Systems
- Meldeformular `/submit-report` — Hilfetext für Meldende
- Dashboard `/dashboard` — kontextbezogene Hinweise für interne Nutzer
- Hilfeseite `/dashboard/hilfe` — die rollenbezogene Anleitung im System
- Später ggf. kontextuelle Tooltips

## Hinweis

Diese Dokumentation soll knapp, verständlich und wartbar bleiben. Neue Funktionen werden hier ergänzt, wenn sie produktiv verfügbar sind.
