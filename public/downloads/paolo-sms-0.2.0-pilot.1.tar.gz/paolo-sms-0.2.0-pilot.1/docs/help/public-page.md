# Öffentliche Startseite – Hilfe

## Was ist ein Safety-Management-System?

Ein Safety-Management-System (SMS) ist ein strukturiertes Verfahren zur systematischen Erfassung, Analyse und Bearbeitung sicherheitsrelevanter Ereignisse und Risiken. Ziel ist es, aus Beobachtungen und Ereignissen zu lernen und die Sicherheit dauerhaft zu verbessern.

## Wozu dient ein SMS im Gleitschirmsport?

Im Gleitschirmsport gibt es viele Situationen, die nicht zu einem Unfall führen, aber dennoch sicherheitsrelevant sind: Beinahe-Ereignisse, gefährliche Beobachtungen, technische Auffälligkeiten oder wiederkehrende Risiken. Ein SMS macht diese Ereignisse sichtbar und ermöglicht es einer Flugschule oder einem Verein, gezielt Gegenmaßnahmen zu ergreifen.

Der Ansatz ist non-punitive: Es geht nicht um Schuldzuweisung, sondern um das Verstehen von Ursachen und das Ableiten von Maßnahmen.

## Was ist PAOLO SMS?

PAOLO SMS ist ein webbasiertes Safety-Management-System für Gleitschirmflugschulen und Vereine. Es ermöglicht die strukturierte Erfassung von Sicherheitsmeldungen, deren interne Bearbeitung und die Nachverfolgung von Maßnahmen.

## Was kann man auf der Startseite tun?

**Sicherheitsmeldung erfassen**

Über den Link „Sicherheitsmeldung erfassen" gelangt man zum Meldeformular. Dort kann jede Person – auch ohne Anmeldung – eine Meldung einreichen.

**Zum Dashboard wechseln**

Wer ein Konto mit internen Zugriffsrechten hat (Safety Assistant, Safety Manager, Administrator), kann sich anmelden und zum Dashboard wechseln.

## Hinweis: Dateianhänge

Im aktuellen MVP können Dateianhänge nur von angemeldeten Nutzern mit entsprechender Rolle hochgeladen werden. Externe Meldende haben diese Möglichkeit derzeit noch nicht.

## Öffentliche Sicherheitsinformationen und ihre Anhänge

Unter „Sicherheitsinformationen" (`/communications`) stehen ohne Anmeldung diejenigen Mitteilungen, die der Safety Manager ausdrücklich öffentlich gestellt hat.

Solche Mitteilungen können Anhänge tragen – aber nur solche, die **einzeln und ausdrücklich** freigegeben wurden. Bilder und Videos erscheinen direkt in der Mitteilung, PDF- und Tracklog-Dateien als Download-Link. Jede Freigabe setzt eine dokumentierte Prüfung auf personenbezogene Daten, Persönlichkeits- und Bildrechte sowie Nutzungsrechte voraus und lässt sich jederzeit zurücknehmen; danach ist die Datei sofort nicht mehr abrufbar.

**Videos** spielen nicht auf allen Geräten ab – auf iPhone und iPad voraussichtlich nicht. Neben dem Player steht deshalb immer ein Link zum Herunterladen.

Bei **IGC-Tracklogs** gibt es zusätzlich einen Hinweis auf einen externen Viewer. Die Datei wird dabei **nicht** automatisch an einen fremden Dienst übertragen: Sie laden sie zuerst herunter und öffnen sie anschließend selbst im Viewer, der sie ausschließlich im Browser verarbeitet.

## Wichtige Grenze

PAOLO SMS ersetzt keine offiziellen Unfallmeldungen, Versicherungsmeldungen oder sonstigen gesetzlich vorgeschriebenen Meldungen. Bei einem Unfall sind die jeweiligen behördlichen und versicherungsrechtlichen Meldepflichten weiterhin zu erfüllen.
