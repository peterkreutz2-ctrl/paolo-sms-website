# Meldende – Hilfe

## Welche Ereignisse soll ich melden?

Melden lohnt sich immer dann, wenn etwas passiert ist oder aufgefallen ist, das die Sicherheit betrifft – auch wenn es glimpflich ausgegangen ist.

Das Formular bietet sechs Meldearten an:

- **Unfall** – tatsächlicher Schaden an Person oder Material
- **Beinahe-Ereignis oder kritische Situation** – es hätte fast einen Schaden gegeben
- **Gefahrenquelle oder Mangel** – ein Zustand, der gefährlich werden kann
- **Beobachtung oder Hinweis** – eine Auffälligkeit, die ein Risiko darstellen könnte
- **Idee zur Verbesserung der Sicherheit** – ein Vorschlag
- **Etwas anderes** – passt in keine der Kategorien

Die Auswahl steuert die Hilfetexte, die das Formular anzeigt. Wenn du danebengreifst, ist das kein Problem – der Safety Manager kann die Meldeart korrigieren.

Beinahe-Ereignisse, Gefahrenquellen und Beobachtungen sind besonders wertvoll: Sie geben die Möglichkeit, Risiken zu erkennen, bevor etwas passiert.

## Wie sieht eine gute Beschreibung aus?

- Was ist passiert oder aufgefallen?
- Wann und wo?
- Welche Bedingungen lagen vor (Wetter, Ausrüstung, Situation)?
- Was war aus deiner Sicht die Ursache oder ein beitragender Faktor?
- Was hättest du dir gewünscht oder was könnte helfen, es künftig zu vermeiden?

Eine kurze, sachliche Beschreibung ist ausreichend. Vollständigkeit ist wichtiger als Perfektion.

## Anonyme Meldung

Meldungen können anonym eingereicht werden. In diesem Fall werden keine personenbezogenen Angaben gespeichert.

Wer freiwillig Kontaktinformationen angibt, ermöglicht es dem Safety Manager, bei Rückfragen Kontakt aufzunehmen. Dies ist optional und hat keinen Einfluss auf die Bearbeitung der Meldung.

## Was passiert nach dem Absenden?

Die Meldung wird intern vom Safety Manager oder Administrator gesichtet. Sie wird bewertet, priorisiert und – falls notwendig – mit Maßnahmen versehen. Rückmeldungen an Meldende sind im aktuellen MVP nicht vorgesehen.

## Hinweis: Dateianhänge

Dateianhänge (z. B. Fotos oder Dokumente) können im aktuellen MVP nur von angemeldeten Nutzern mit entsprechender Rolle hochgeladen werden. Als externer Meldender besteht diese Möglichkeit derzeit nicht.

## Wichtige Grenze

PAOLO SMS ersetzt keine offiziellen Unfallmeldungen, Versicherungsmeldungen oder sonstigen gesetzlich vorgeschriebenen Meldungen. Bei einem Unfall sind die jeweiligen behördlichen und versicherungsrechtlichen Meldepflichten weiterhin eigenständig zu erfüllen.
