# FIDA-JSON-Export: PAOLO-Quellmapping

Der Export erzeugt Schema-Version `1.0`. Der Zeitraum bezieht sich auf
`reports.occurred_at`: Start einschließlich, Ende ausschließlich, maximal ein
Jahr. Gelöschte Meldungen und Meldungen ohne Ereigniszeitpunkt werden
ausgeschlossen.
Anhänge, Maßnahmen, Notizen und personenbezogene Melderdaten werden nicht
exportiert.

| FIDA-Ziel | PAOLO-Quelle | Transformation | Pflichtfeld |
|---|---|---|---|
| `api_uid` | `reports.id` | UUID als String | ja |
| `report_hash` | gemappte Fachdaten | SHA-256 über kanonisches JSON | ja |
| `heuristic_key` | Datum, Ort, Geräteart, Hersteller, Modell | NFKC, Whitespace-Normalisierung, `\|`-Escaping | ja |
| `date` | `reports.occurred_at` | UTC-Datum `YYYY-MM-DD` | ja |
| `airfield` | `reports.location_text` | trimmen, leer wird `null` | nein |
| `flight_equipment` | `reports.activity_area` | kontrollierte Code-Tabelle | nein |
| `flight_phase` | `reports.flight_phase` | kontrollierte Code-Tabelle | nein |
| `injuries_pilot` | `reports.injury_severity` | kontrollierte Code-Tabelle | nein |
| `description` | `reports.detailed_description` | unverändert | ja |
| `raw_json.id` | `reports.id` | unverändert | ja |
| `raw_json.source` | Konstante | `PAOLO` | ja |
| `first_seen_at` | `reports.created_at` | ISO 8601 UTC | ja |
| `last_seen_at` | `reports.updated_at` | ISO 8601 UTC | ja |

Folgende FIDA-Felder haben derzeit keine strukturierte PAOLO-Quelle und werden
explizit als `null` ausgegeben:

- `age`
- `flies_since`
- `type_of_flight_license`
- `weather_wind`
- `weather_thermic`
- `weather_turbulences`
- `aircraft_manufacturer`
- `aircraft_model`
- `motor_unit_manufacturer`
- `motor_unit_model`
- `pilot_error`
- `incident_cause`

Es findet keine heuristische Extraktion aus Freitext statt. Insbesondere wird
`report_type` nicht als Unfallursache interpretiert.

## Code-Tabellen

### Fluggerät

| PAOLO | FIDA |
|---|---|
| `paragliding` | `Paraglider` |
| `hang_gliding` | `Hang Glider` |
| `powered_paragliding` | `Powered Paraglider` |
| `speed_riding` | `Speedrider` |
| `parakite` | `Parakite` |
| `other` | `Other` |

### Flugphase

| PAOLO | FIDA |
|---|---|
| `pre_flight` | `Pre-flight` |
| `groundhandling` | `Ground handling` |
| `launch` | `Takeoff` |
| `flight` | `Flight` |
| `landing` | `Landing` |
| `post_flight` | `Post-flight` |
| `not_applicable` | `Not applicable` |

### Verletzungsschwere

| PAOLO | FIDA |
|---|---|
| `none` | `None` |
| `minor` | `Minor` |
| `serious` | `Serious` |
| `fatal` | `Fatal` |

## Hashbildung

`report_hash` wird über die fachlichen FIDA-Felder von `date` bis `description`
gebildet. Flüchtige beziehungsweise quellbezogene Felder (`api_uid`,
`exported_at`, `raw_json`, `first_seen_at`, `last_seen_at`) gehören nicht zum
Hash. Damit ist der Hash für unveränderte Fachdaten stabil und ändert sich bei
einer fachlichen Änderung.

## Zugriff und Audit

Der Download unter `/api/export/fida?from=YYYY-MM-DD&to=YYYY-MM-DD` ist nur für
`admin` und `safety_manager` zugänglich. Antworten werden nicht gecacht. Das
Audit-Log enthält Zeitraum, Format, Schema-Version und Anzahl, jedoch keine
exportierten Inhalte.
