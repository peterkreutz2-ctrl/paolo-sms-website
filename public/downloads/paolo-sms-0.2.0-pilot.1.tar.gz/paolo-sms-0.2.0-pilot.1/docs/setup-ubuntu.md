# PAOLO SMS auf Ubuntu 22.04 LTS

Diese Anleitung beschreibt eine native Einzelserver-Installation von PAOLO SMS
auf Ubuntu 22.04 LTS:

- PostgreSQL läuft lokal und ist nicht aus dem Internet erreichbar.
- Die Next.js-Anwendung läuft als eigener, unprivilegierter systemd-Dienst.
- Nginx nimmt HTTP/HTTPS entgegen und leitet intern an Next.js weiter.
- Anhänge werden standardmäßig lokal gespeichert.

Die Beispiele verwenden `paolo.example.org` als Domain. Diese muss überall durch
die eigene Domain ersetzt werden. Für einen produktiven Betrieb werden außerdem
ein Clerk-Mandant **oder** Better Auth, DNS-Zugriff und ein separates
Backup-Ziel benötigt.

## 1. Zielarchitektur

```text
Internet
   |
   | 80/443
   v
Nginx
   |
   | 127.0.0.1:3000
   v
PAOLO SMS (systemd, Benutzer paolo)
   |                         |
   | 127.0.0.1:5432          | /var/lib/paolo-sms/storage
   v                         v
PostgreSQL                 Anhänge
```

Nur SSH, HTTP und HTTPS werden extern freigegeben. Port 3000 und PostgreSQL
bleiben auf Loopback gebunden.

## 2. Voraussetzungen

- Ubuntu Server 22.04 LTS mit sudo-Zugriff
- mindestens 2 GB RAM; für den Build sind 4 GB oder temporärer Swap angenehmer
- DNS-`A`/`AAAA`-Record für die Domain
- ausgehender HTTPS-Zugriff für npm und gegebenenfalls Clerk
- Git-Zugriff auf das Repository

System aktualisieren und Grundpakete installieren:

```bash
sudo apt update
sudo apt full-upgrade -y
sudo apt install -y git curl ca-certificates gnupg nginx postgresql \
  postgresql-contrib postgresql-client age
sudo systemctl enable --now postgresql nginx
```

### Warum Node.js 24 LTS aus dem NodeSource-Repository?

Ubuntu 22.04 liefert im offiziellen `jammy`-Repository nur Node.js 12 aus.
Diese Version ist für den hier verwendeten Stack aus Next.js 16 und React 19 zu
alt. PAOLO SMS wird deshalb mit Node.js 24 LTS betrieben; dieselbe Hauptversion
wird auch im `Dockerfile` verwendet.

Der folgende Installationsweg bindet das externe APT-Repository von NodeSource
für Node.js 24 ein. Danach werden `node` und `npm` weiterhin wie normale
Debian-Pakete mit `apt` installiert und aktualisiert. Das vorbereitende
NodeSource-Skript legt den Repository-Schlüssel und die Paketquelle auf dem
Server an und benötigt deshalb `sudo`.

Wer keine externe APT-Paketquelle zulassen möchte, kann alternativ das signierte
Linux-Binary von nodejs.org unter `/opt` installieren. Dessen Sicherheitsupdates
müssen dann allerdings selbst überwacht und eingespielt werden. `nvm` eignet
sich gut für Benutzer- und Entwicklungsumgebungen, ist für einen systemweiten
systemd-Produktionsdienst aber unnötig aufwendig.

Node.js 24 über NodeSource installieren:

```bash
curl -fsSL https://deb.nodesource.com/setup_24.x | sudo -E bash -
sudo apt install -y nodejs
node --version
npm --version
```

`node --version` muss anschließend `v22.x.x` anzeigen. Das separate Ubuntu-Paket
`npm` nicht zusätzlich installieren: Beim NodeSource-Paket ist eine passende
npm-Version bereits enthalten.

## 3. Dienstbenutzer und Verzeichnisse

```bash
sudo adduser --system --group --home /opt/paolo-sms paolo
sudo install -d -o paolo -g paolo -m 0750 /opt/paolo-sms
sudo install -d -o root -g paolo -m 0750 /etc/paolo-sms
sudo install -d -o paolo -g paolo -m 0750 \
  /var/lib/paolo-sms/storage /var/lib/paolo-sms/backups
```

Repository als Dienstbenutzer auschecken:

```bash
sudo -u paolo git clone <REPOSITORY-URL> /opt/paolo-sms
cd /opt/paolo-sms
sudo -u paolo npm ci
```

Bei einem privaten Repository sollte ein read-only Deploy-Key für den Benutzer
`paolo` verwendet werden. Keine persönlichen Zugangstoken im Repository oder in
Shell-Skripten ablegen.

## 4. Lokales PostgreSQL einrichten

Ein starkes, zufälliges Passwort erzeugen:

```bash
openssl rand -base64 36
```

Anschließend Rolle und Datenbank anlegen. `EIN_STARKES_PASSWORT` ersetzen; bei
einem enthaltenen einfachen Anführungszeichen muss dieses in SQL verdoppelt
werden.

```bash
sudo -u postgres psql
```

```sql
CREATE ROLE paolo LOGIN PASSWORD 'EIN_STARKES_PASSWORT';
CREATE DATABASE paolo_sms OWNER paolo ENCODING 'UTF8';
\q
```

Die Ubuntu-Vorgabe lauscht normalerweise nur lokal. Das ausdrücklich prüfen:

```bash
sudo -u postgres psql -tAc "SHOW listen_addresses;"
sudo ss -ltnp | grep 5432
```

PostgreSQL darf nicht auf einer öffentlichen Adresse lauschen. Es ist weder eine
UFW-Freigabe noch eine Nginx-Konfiguration für Port 5432 erforderlich.

### Datenbank initialisieren oder aktualisieren

PAOLO verwendet bewusst die geprüften SQL-Dateien in `drizzle/` und **nicht**
`drizzle-kit migrate`, `generate` oder `push`. Für frische und bestehende
Datenbanken den vollständigen Satz anwenden:

```bash
cd /opt/paolo-sms
sudo -u postgres psql -X -d paolo_sms -f scripts/migrate.psql || exit 1
```

Die Ausgabe muss ohne Fehler enden. Bei späteren Releases denselben vollständigen
Einstieg mit den Dateien des neuen Releases erneut ausführen.
Vorher immer ein Backup erstellen. Das verbindliche Verfahren steht in
[database-migrations.md](database-migrations.md).

## 5. Anwendung konfigurieren

Die Runtime-Konfiguration liegt außerhalb des Repositorys:

```bash
sudoedit /etc/paolo-sms/paolo.env
sudo chmod 0640 /etc/paolo-sms/paolo.env
sudo chown root:paolo /etc/paolo-sms/paolo.env
```

### Variante A: Better Auth

Diese Variante speichert E-Mail-/Passwort-Konten in der lokalen Datenbank.
`BETTER_AUTH_SECRET` muss mindestens 32 zufällige Zeichen enthalten:

```bash
openssl rand -base64 48
```

```env
NODE_ENV=production
HOSTNAME=127.0.0.1
PORT=3000
NEXT_TELEMETRY_DISABLED=1

APP_BASE_URL=https://paolo.example.org
DATABASE_URL=postgresql://paolo:EIN_URLKODIERTES_PASSWORT@127.0.0.1:5432/paolo_sms

AUTH_MODE=betterauth
BETTER_AUTH_SECRET=EIN_LANGES_ZUFAELLIGES_SECRET
BETTER_AUTH_URL=https://paolo.example.org
BETTER_AUTH_LOGIN_RATE_LIMIT_SALT=EIN_WEITERES_LANGES_ZUFAELLIGES_SECRET
BETTER_AUTH_LOGIN_RATE_LIMIT_TRUSTED_IP_HEADER=X-Forwarded-For
BETTER_AUTH_LOGIN_RATE_LIMIT_MAX_PER_ACCOUNT=5
BETTER_AUTH_LOGIN_RATE_LIMIT_MAX_PER_IP=20
BETTER_AUTH_LOGIN_RATE_LIMIT_RETENTION_DAYS=1

STORAGE_PROVIDER=local
LOCAL_STORAGE_DIR=/var/lib/paolo-sms/storage

BACKUP_ENGINE=pg_dump
BACKUP_DIR=/var/lib/paolo-sms/backups
BACKUP_AGE_RECIPIENTS=age1operator...,age1recovery...
BACKUP_CRON_SECRET=EIN_WEITERES_ZUFAELLIGES_SECRET
BACKUP_CRON_MIN_INTERVAL_MINUTES=1440
BACKUP_CRON_MAX_RUNTIME_MINUTES=120
BACKUP_RETENTION_ENABLED=true
BACKUP_RETENTION_DAILY_DAYS=14
BACKUP_RETENTION_WEEKLY_WEEKS=8
BACKUP_RETENTION_MONTHLY_MONTHS=12
```

Für öffentliche Meldungen sollte zusätzlich ein langer, zufälliger Wert für
`PUBLIC_REPORT_RATE_LIMIT_SALT` gesetzt werden. Der Reverse Proxy muss den
Client-IP-Header korrekt weiterreichen; mit einem üblichen Fronting-Proxy ist die
Standard-Header-Konfiguration `X-Forwarded-For` passend.
`PUBLIC_REPORT_RATE_LIMIT_MAX_ACCEPTED` ist optional und begrenzt die pro
Client-IP und Stunde akzeptierten Meldungen; ohne gueltige positive Ganzzahl
gilt der sichere Standardwert `5`.
`PUBLIC_REPORT_RATE_LIMIT_RETENTION_DAYS` steuert die Aufbewahrung der
pseudonymisierten Rate-Limit-Buckets und ist standardmaessig auf einen Tag
gesetzt. Nach erfolgreicher Meldungserstellung werden abgelaufene Eintraege in
begrenzten Batches entfernt; der zulaessige Bereich ist 1 bis 365 Tage.

Sonderzeichen im Datenbankpasswort müssen im URL-Format percent-encodiert sein.
Alternativ ein nur aus URL-sicheren Zufallszeichen bestehendes Passwort
verwenden.

### Variante B: Clerk

Für Clerk diese Werte anstelle der Better-Auth-Werte verwenden:

```env
AUTH_MODE=clerk
APP_BASE_URL=https://paolo.example.org

NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=...
CLERK_SECRET_KEY=...
NEXT_PUBLIC_CLERK_SIGN_IN_URL=/sign-in
NEXT_PUBLIC_CLERK_SIGN_UP_URL=/sign-up
NEXT_PUBLIC_CLERK_SIGN_IN_FALLBACK_REDIRECT_URL=/dashboard
NEXT_PUBLIC_CLERK_SIGN_UP_FALLBACK_REDIRECT_URL=/dashboard
```

Die öffentliche Domain und erlaubten Redirect-URLs müssen im Clerk-Dashboard
ebenfalls eingetragen sein. Variablen mit Präfix `NEXT_PUBLIC_` werden beim
Build eingebettet. Nach ihrer Änderung muss die Anwendung neu gebaut werden.

### Alternativer Attachment-Speicher

Für Vercel Blob statt lokalem Speicher:

```env
STORAGE_PROVIDER=vercel-blob
BLOB_READ_WRITE_TOKEN=...
```

Ohne `STORAGE_PROVIDER` ist Vercel Blob der Projektstandard. Ein nachträglicher
Providerwechsel migriert bereits vorhandene Dateien nicht automatisch.

## 6. Produktions-Build erstellen

Die Build-Umgebung laden, damit öffentliche Auth-Konfiguration korrekt
eingebettet wird, und als Dienstbenutzer bauen:

```bash
cd /opt/paolo-sms
sudo -u paolo bash -c 'set -a; source /etc/paolo-sms/paolo.env; set +a; npm run build'
```

Der Build erzeugt `.next/standalone/server.js`. Für den nativen Standalone-Start
werden außerdem statische Assets und `public` benötigt:

```bash
sudo -u paolo install -d /opt/paolo-sms/.next/standalone/.next
sudo -u paolo cp -a /opt/paolo-sms/.next/static \
  /opt/paolo-sms/.next/standalone/.next/
sudo -u paolo cp -a /opt/paolo-sms/public \
  /opt/paolo-sms/.next/standalone/
```

## 7. Organisation und ersten Administrator anlegen

Nach den Migrationen den geführten Fresh-Install-Bootstrap mit derselben
produktiven Umgebung ausführen:

```bash
cd /opt/paolo-sms
sudo -u paolo bash -c \
  'set -a; source /etc/paolo-sms/paolo.env; set +a; npm run setup:initialize'
```

Er zeigt das redigierte Datenbankziel und verlangt den Datenbanknamen als
exakte Bestätigung. Bei Better Auth werden E-Mail, Anzeigename und das zweimal
verdeckt eingegebene Passwort abgefragt. Bei Clerk muss das Konto vorher im
richtigen Clerk-Projekt existieren; der Befehl verifiziert E-Mail oder User-ID,
Verifizierungs- und Sperrstatus. Organisation, globaler Admin und Audit-Nachweis
werden atomar gespeichert.

Der Befehl ist nur für vollständig frische Installationen bestimmt. Eine schon
vorhandene Organisation, Rollenzuweisung oder ein Better-Auth-Konto führt ohne
Schreibzugriff zum Abbruch. Optionen für automatisierte Provisionierung stehen
unter `npm run setup:initialize -- --help`; Better-Auth-Passwörter werden dabei
nur über die kurzlebige Laufzeitvariable `BETTER_AUTH_BOOTSTRAP_PASSWORD`
übergeben, niemals als Argument.

## 8. systemd-Dienst

```bash
sudoedit /etc/systemd/system/paolo-sms.service
```

```ini
[Unit]
Description=PAOLO Safety Management System
After=network-online.target postgresql.service
Wants=network-online.target
Requires=postgresql.service

[Service]
Type=simple
User=paolo
Group=paolo
WorkingDirectory=/opt/paolo-sms/.next/standalone
EnvironmentFile=/etc/paolo-sms/paolo.env
ExecStart=/usr/bin/node /opt/paolo-sms/.next/standalone/server.js
Restart=on-failure
RestartSec=5
TimeoutStopSec=30
UMask=0027
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/lib/paolo-sms/storage /var/lib/paolo-sms/backups

[Install]
WantedBy=multi-user.target
```

Dienst aktivieren und zunächst lokal prüfen:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now paolo-sms
sudo systemctl status paolo-sms --no-pager
sudo journalctl -u paolo-sms -n 100 --no-pager
curl --fail http://127.0.0.1:3000/api/health
```

## 9. Nginx als Frontend-Server

Die Anwendung akzeptiert Anhänge bis 4 MiB (`MAX_FILE_SIZE_BYTES` in
`lib/constants/attachment-file-types.ts`). Nginx erhält mit 5 MiB etwas
Multipart-Overhead und stimmt damit zu `bodySizeLimit` und
`proxyClientMaxBodySize` in `next.config.ts` überein. Öffentliche Meldungen
erhalten ein eigenes 256-KiB-Body-Limit. Request-Buffering bleibt eingeschaltet,
damit auch Bodies ohne `Content-Length` vor der Weiterleitung geprüft werden;
Response-Buffering ist für die Anwendung deaktiviert.

Die gemeinsame HTTP-/HTTPS-Policy aus dem Repository installieren (aus dem
Checkout ausführen). Diese beiden Dateien bei späteren Updates ebenfalls
aktualisieren; Zonendefinitionen nicht zusätzlich in die Site kopieren:

```bash
sudo install -d /etc/nginx/conf.d/snippets
sudo install -m 644 deploy/nginx/conf.d/00-rate-limits.conf /etc/nginx/conf.d/00-rate-limits.conf
sudo install -m 644 deploy/nginx/conf.d/snippets/app.conf /etc/nginx/conf.d/snippets/app.conf
```

Nginx muss `/etc/nginx/conf.d/*.conf` im `http`-Kontext laden (Ubuntu-Default).
Das verschachtelte Snippet wird nur von der Site im `server`-Kontext geladen.
Es überschreibt Clientwerte für `X-Forwarded-For` und `X-Real-IP`; hinter
zusätzlichen Proxys ist ein gesondertes Trust-Konzept erforderlich.

```bash
sudoedit /etc/nginx/sites-available/paolo-sms
```

```nginx
upstream paolo_app {
    server 127.0.0.1:3000;
}

server {
    listen 80;
    listen [::]:80;
    server_name paolo.example.org;

    include /etc/nginx/conf.d/snippets/app.conf;
    proxy_read_timeout 120s;
    proxy_send_timeout 120s;
}
```

Site aktivieren:

```bash
sudo ln -s /etc/nginx/sites-available/paolo-sms /etc/nginx/sites-enabled/paolo-sms
sudo rm /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl reload nginx
curl --fail http://paolo.example.org/api/health
```

Falls der Standard-Site-Link bereits entfernt wurde, ist die entsprechende
Meldung von `rm` harmlos.

### TLS mit Let's Encrypt

Erst fortfahren, wenn DNS auf den Server zeigt und Port 80 erreichbar ist:

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d paolo.example.org
sudo certbot renew --dry-run
```

Certbot ergänzt die HTTPS-Konfiguration und HTTP-Weiterleitung. Abschließend:

```bash
curl --fail https://paolo.example.org/api/health
systemctl list-timers | grep certbot
```

## 10. Firewall

Bei Verwendung von UFW zuerst SSH erlauben, damit die Sitzung nicht ausgesperrt
wird:

```bash
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'
sudo ufw enable
sudo ufw status
```

Keine Regeln für 3000 oder 5432 hinzufügen. Bei Cloud-Providern müssen die
externen Firewall-/Security-Group-Regeln dazu passen.

## 11. Updates

Vor jedem Update Release Notes und neue Migrationen prüfen. Für ein
wartungsarmes, nachvollziehbares Update:

```bash
sudo systemctl stop paolo-sms
# Jetzt DB und lokalen Storage konsistent sichern.

cd /opt/paolo-sms
sudo -u paolo git pull --ff-only
sudo -u paolo npm ci

# Vollständigen geprüften Satz atomar und idempotent anwenden:
sudo -u postgres psql -X -d paolo_sms -f scripts/migrate.psql || exit 1

sudo -u paolo bash -c 'set -a; source /etc/paolo-sms/paolo.env; set +a; npm run build'
sudo -u paolo install -d /opt/paolo-sms/.next/standalone/.next
sudo -u paolo cp -a /opt/paolo-sms/.next/static \
  /opt/paolo-sms/.next/standalone/.next/
sudo -u paolo cp -a /opt/paolo-sms/public \
  /opt/paolo-sms/.next/standalone/

sudo systemctl start paolo-sms
sudo systemctl status paolo-sms --no-pager
curl --fail https://paolo.example.org/api/health
```

Der psql-Einstieg enthält alle SQL-Dateien in Reihenfolge und stoppt bei Fehlern.
Ein App-Rollback ersetzt keinen Datenbank-Rollback; deshalb vor Migrationen
immer einen getesteten Sicherungsstand erstellen.

## 12. Backup und Wiederherstellung

Mindestens gemeinsam sichern:

- PostgreSQL-Datenbank `paolo_sms`
- `/var/lib/paolo-sms/storage`
- verschlüsselte Kopie der Konfiguration und der verwendete Git-Commit

DB-Metadaten und Attachment-Dateien müssen aus demselben Stand stammen. Für
einen konsistenten manuellen Sicherungspunkt die Anwendung kurz stoppen:

```bash
sudo systemctl stop paolo-sms
sudo -u postgres pg_dump --format=custom --file=/tmp/paolo_sms.dump paolo_sms
sudo tar -C /var/lib/paolo-sms -czf /tmp/paolo-storage.tar.gz storage
sudo systemctl start paolo-sms
```

Die Dateien unter `/tmp` sind in diesem Beispiel noch **unverschlüsselt**. Sie
müssen unmittelbar verschlüsselt an ein getrenntes, zugriffsgeschütztes
Offsite-Ziel übertragen und anschließend sicher entfernt werden. Private
`age`-Identitäten gehören nicht auf den App-Server. Die integrierte
verschlüsselte Backup-Funktion, Retention und der bewusst CLI-only gehaltene
Restore sind ausführlich in [backup-restore.md](backup-restore.md) dokumentiert.
Restore-Tests immer auf einem separaten Testsystem durchführen.

## 13. Abnahme und Fehlersuche

Nach Installation und Updates mindestens prüfen:

- `/`, `/submit-report` und `/sign-in` laden über HTTPS.
- Anmeldung und `/dashboard` funktionieren.
- Eine Testmeldung kann angelegt und intern geöffnet werden.
- Attachment-Upload und -Download funktionieren.
- `curl https://paolo.example.org/api/health` liefert Status `ok`.
- PostgreSQL und Port 3000 sind extern nicht erreichbar.
- DB- und Storage-Backup sowie ein Restore-Test sind dokumentiert.

Nützliche Diagnosebefehle:

```bash
sudo journalctl -u paolo-sms -f
sudo tail -f /var/log/nginx/error.log
sudo nginx -t
sudo -u postgres psql -d paolo_sms -c '\dt'
sudo ss -ltnp
df -h
```

Typische Fehler:

- **502 Bad Gateway:** `paolo-sms` läuft nicht oder lauscht nicht auf
  `127.0.0.1:3000`.
- **413 Request Entity Too Large:** `client_max_body_size 5m` fehlt in der
  aktiven Nginx-Site.
- **Datenbankfehler beim Start:** `DATABASE_URL`, Passwort, lokaler PostgreSQL-
  Status und angewandte Migrationen prüfen.
- **Fehlende CSS-/JS-Dateien:** `.next/static` oder `public` wurde nicht in den
  Standalone-Ordner kopiert.
- **Upload mit `EACCES`:** Eigentümer und Rechte von
  `/var/lib/paolo-sms/storage` prüfen.
- **Falsche Auth-Redirects:** öffentliche URL in PAOLO und im Auth-Anbieter
  angleichen und nach Änderungen an `NEXT_PUBLIC_*` neu bauen.
