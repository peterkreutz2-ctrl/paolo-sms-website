# Docker-Setup für PAOLO SMS (experimentell)

> **Zielgruppe:** technisch versierte Betreiber, Entwicklerinnen und Entwickler
> oder IT-Dienstleister. **Nicht** für normale Safety Manager im Tagesbetrieb.

Diese Anleitung beschreibt, wie PAOLO SMS lokal als Container (App + PostgreSQL,
optional lokaler Datei-Storage) gestartet wird. Sie ergänzt die strategische
[`containerization-roadmap.md`](containerization-roadmap.md) und das
Migrationsverfahren in [`database-migrations.md`](database-migrations.md).

**Welche Installationsart, Auth-Provider und Datenbank für einen Betreiber
sinnvoll sind**, beschreibt die zentrale Entscheidungshilfe
[`installation-decision-guide.md`](installation-decision-guide.md). Für einen
konkreten Produktionspfad auf einem einzelnen Server/einer VM (Nginx, TLS,
Backups) siehe [`docker-vm-deployment.md`](docker-vm-deployment.md).

Für den empfohlenen Hybrid-Entwicklungsmodus mit Hot Reload auf dem Host und
lokaler PostgreSQL in Docker siehe `docs/setup_vs_windows.md` (Entwicklungsunterlage, nicht im Quellpaket).

---

## 1. Status / Warnhinweis

> ⚠️ **Diese Anleitung selbst bleibt experimentell / lokal orientiert.** Phase A
> der Containerisierung ist technisch verifiziert (Build, Compose-Start,
> Fresh-DB-Apply, lokaler Storage). Für einen konkreten produktionsreifen
> Installationsweg auf einem einzelnen Server/einer VM (Nginx, TLS,
> Backup-Cron) siehe stattdessen
> [`docker-vm-deployment.md`](docker-vm-deployment.md).

- **Keine automatische Migration** beim Containerstart. Die Datenbank muss einmalig
  manuell initialisiert werden (siehe Abschnitt 6).
- **Authentifizierung ist wählbar** (`AUTH_MODE=clerk|betterauth`, siehe
  [`installation-decision-guide.md`](installation-decision-guide.md)). Bei
  `AUTH_MODE=clerk` (Standard) laufen Authentifizierung und Benutzerverwaltung über die
  Clerk-Cloud (eigene Clerk-Keys nötig); bei `AUTH_MODE=betterauth` laufen sie
  selbst betrieben in dieser PostgreSQL (siehe Abschnitt 6.2). Für die
  Umstellung einer bestehenden Docker-Installation siehe
  [`runbooks/switch-clerk-to-better-auth.md`](runbooks/switch-clerk-to-better-auth.md).
- **Der Betreiber ist selbst verantwortlich** für Secrets-Handling, Backups,
  TLS/Reverse Proxy, Updates und die Einhaltung der Datenschutzpflichten. Diese
  Punkte sind bewusst **nicht** Teil dieser Anleitung (vgl.
  [`containerization-roadmap.md`](containerization-roadmap.md) Phase D,
  [`data-protection-concept.md`](data-protection-concept.md)).

---

## 2. Voraussetzungen

- **Docker Desktop** oder **Docker Engine** (getestet mit Docker 29.x).
- **Docker Compose** (getestet mit Compose v5.x; `docker compose …`).
- **Git** (zum Klonen des Repositories). Ohne Git-Zugang: Installation aus dem
  Quellpaket, siehe [`install-from-package.md`](install-from-package.md).
- **Node.js / npm** nur für die lokale Entwicklung (`npm run dev`, Migrations-
  Tooling) — für den **reinen Containerbetrieb nicht zwingend** erforderlich.
- Bei `AUTH_MODE=clerk` (Standard): ein **Clerk-Projekt** mit Publishable- und
  Secret-Key. Bei `AUTH_MODE=betterauth` stattdessen `BETTER_AUTH_SECRET`/
  `BETTER_AUTH_URL`, kein externer Auth-Anbieter nötig (siehe
  [`installation-decision-guide.md`](installation-decision-guide.md)).
- **Optional:** ein **Vercel-Blob-Token**, falls `STORAGE_PROVIDER=vercel-blob`
  genutzt werden soll. Bei `STORAGE_PROVIDER=local` wird kein Token benötigt.

---

## 3. Beteiligte Dateien

| Datei / Objekt | Zweck |
|---|---|
| `Dockerfile` | Multi-Stage-Build des Next.js-Standalone-Images; läuft als non-root Benutzer `nextjs`. Legt `/app/storage` für den lokalen Storage an. Bäckt **keine** Secrets ein. |
| `docker-compose.yml` | Startet zwei Services: `app` (PAOLO) und `db` (`postgres:16`, mit Healthcheck). |
| `docker-compose.prod.yml` | Produktions-Overlay: entfernt öffentliche App-/DB-Ports und veröffentlicht stattdessen Nginx auf `80`/`443`. Siehe [`docker-vm-deployment.md`](docker-vm-deployment.md). |
| `.env.docker.example` | Versionierte Vorlage aller nötigen Umgebungsvariablen (nur Beispielwerte). |
| `.env.docker.local` | **Deine** lokale Env-Datei mit echten Werten. Git- und dockerignoriert — **wird nicht committet und nicht ins Image kopiert**. |
| Volume `paolo-db-data` | Persistente PostgreSQL-Daten (`/var/lib/postgresql/data`). |
| Volume `paolo-storage-data` | Persistente Anhänge bei `STORAGE_PROVIDER=local` (gemountet auf `/app/storage`). |

---

## 4. `.env.docker.local` erstellen

Vorlage kopieren und mit echten Werten füllen:

```bash
cp .env.docker.example .env.docker.local
```

> **Keine echten Secrets committen.** `.env.docker.local` ist bereits git- und
> dockerignoriert; das bitte so belassen.

Wichtige Werte:

```env
# Datenbank: zeigt auf den Compose-Service "db"
DATABASE_URL=postgres://paolo:change-me@db:5432/paolo?sslmode=disable
POSTGRES_DB=paolo
POSTGRES_USER=paolo
POSTGRES_PASSWORD=change-me          # muss zu DATABASE_URL passen

# Storage: lokaler Dateisystem-Storage im Docker-Volume
STORAGE_PROVIDER=local
LOCAL_STORAGE_DIR=/app/storage

# Authentifizierung: clerk (Standard, extern) oder betterauth (selbst betrieben)
AUTH_MODE=clerk

# Nur bei AUTH_MODE=clerk:
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=...
CLERK_SECRET_KEY=...
NEXT_PUBLIC_CLERK_SIGN_IN_URL=/sign-in
NEXT_PUBLIC_CLERK_SIGN_UP_URL=/sign-up
NEXT_PUBLIC_CLERK_SIGN_IN_FALLBACK_REDIRECT_URL=/dashboard
NEXT_PUBLIC_CLERK_SIGN_UP_FALLBACK_REDIRECT_URL=/dashboard

# Nur bei AUTH_MODE=betterauth:
# BETTER_AUTH_SECRET=...
# BETTER_AUTH_URL=http://localhost:3000

# App
APP_BASE_URL=http://localhost:3000   # lokal; im Self-Hosting die öffentliche URL, s. u.
```

- `POSTGRES_*` und `DATABASE_URL` müssen **konsistent** sein (gleicher Benutzer,
  gleiches Passwort, gleiche Datenbank; Host = Service-Name `db`).
- Für **Vercel Blob** stattdessen `STORAGE_PROVIDER=vercel-blob` setzen und
  `BLOB_READ_WRITE_TOKEN` befüllen (dann werden `LOCAL_STORAGE_DIR`/das
  Storage-Volume nicht benötigt).

> **`APP_BASE_URL` im Self-Hosting.** `APP_BASE_URL` ist die **öffentlich
> erreichbare Basis-URL dieser Instanz**. Sie wird serverseitig zum Erzeugen von
> **Auth-, Rücksprung- und Einladungslinks** verwendet (z. B. dem Anmeldelink in
> `lib/actions/user-roles.ts`).
>
> - **Lokaler Test:** `http://localhost:3000`.
> - **Self-Hosting / Echtdatenbetrieb** hinter Domain oder Reverse Proxy: die
>   **öffentliche URL** der Instanz, z. B. `https://paolo.example.org`.
>
> **Nicht auf `localhost` lassen, wenn die Instanz öffentlich genutzt wird** —
> sonst zeigen erzeugte Links ins Leere (z. B. ein Einladungs-/Anmeldelink, der
> auf `http://localhost:3000` verweist). Die **Clerk-Redirect-URLs** (Sign-in/
> Sign-up und Fallback-Redirects) müssen zur **selben öffentlichen URL** passen —
> dies gilt nur bei `AUTH_MODE=clerk`; bei `AUTH_MODE=betterauth` entfällt der
> externe Anbieter, `BETTER_AUTH_URL` muss dann aber ebenfalls die öffentliche
> URL sein.

---

## 5. Build und Start

```bash
# Image bauen
docker compose build

# Zunächst nur PostgreSQL starten
docker compose up -d db

# Status der Container ansehen
docker compose ps
```

Warten, bis der `db`-Service `healthy` ist. Die App erst nach Migration und
Bootstrap (Abschnitt 6) starten:

```bash
docker compose up -d --no-deps --force-recreate app
docker compose logs -f app
```

Die Anwendung ist anschließend unter `http://localhost:3000` erreichbar.

> Die Datenbank ist beim ersten Start **leer** — vor der Nutzung Abschnitt 6
> ausführen.

---

## 6. Datenbank initialisieren und aktualisieren

Neuinstallation und Update verwenden denselben wiederholbaren SQL-Satz.
Es gibt keinen automatischen Migrationslauf beim Containerstart. Das
verbindliche Verfahren steht in [database-migrations.md](database-migrations.md).

Vor dem Lauf Ziel prüfen, bei bestehenden Daten ein vollständiges Backup
anlegen und schreibende App-Prozesse/Jobs während der Migration pausieren.
Das in Abschnitt 5 gebaute App-Image enthält SQL und Einstieg desselben Releases.
`DATABASE_URL` aus der Compose-Konfiguration muss auf die freigegebene, bereits
bereite Datenbank zeigen und eine DB-/Tabelleneigentümerrolle verwenden:

```bash
docker compose stop app || exit 1
docker compose run --rm --no-deps -T app sh /app/scripts/migrate.sh || exit 1
```

Der einmalige Container startet keinen Webserver und keine abhängigen Services.
Das DB-Image und Daten-Volumes bleiben unverändert. Bei Fehlern nicht mit dem
App-Start fortfahren. Nach erfolgreicher Schema-/Datenprüfung und gegebenenfalls
Bootstrap die App wie in Abschnitt 5 starten. `exec app` wäre für Updates falsch:
es verwendet die Dateien des laufenden Containers, nicht des neu gebauten Images.

### 6.1 Migrationsweg

Alle Dateien `0000`–`0031` werden in Reihenfolge in einer Transaktion angewandt.
Bereits vorhandene Effekte werden berücksichtigt; Daten bleiben erhalten.
Bei Fehler oder Lock-Timeout wird zurückgerollt. Nach Behebung den vollständigen
Einstieg erneut ausführen. Nicht mit alten SQL-Dateifassungen mischen.

`psql` ist das einzige benötigte Migrationswerkzeug. `drizzle-kit generate`,
`migrate` und `push` sind nicht Teil dieses Verfahrens; deren historische
Metadaten werden nicht benötigt. Neue Dateien müssen die Replay-Regel erfüllen,
im Einstieg enthalten sein und die vollständige Präfix-Testmatrix bestehen.

Vor einem Betreiber-Rollout auf einer isolierten Testdatenbank prüfen; nach
Migration Schema, Daten und die Kernseiten testen. Ein Produktivzugriff braucht
immer den expliziten Auftrag des jeweiligen Betreibers. Für ausführliche
Updates gilt das [Operator-Runbook](runbooks/production-docker-update.md).

### 6.2 Bootstrap nach Fresh-Init (Organisation + erster Admin)

Nach dem Einspielen der Migrationen ist die Datenbank strukturell bereit, aber
für den internen Betrieb fehlen noch:

- genau eine Organisation
- der erste globale Administrator (`admin`, `organization_id IS NULL`)

Beides legt der geführte Fresh-Install-Bootstrap in einer Transaktion an:

```bash
docker compose run --rm --no-deps app npm run setup:initialize
```

Der Befehl zeigt Host, Port, Datenbank und DB-Benutzer ohne Passwort oder
URL-Parameter an. Vor dem Schreiben muss der Datenbankname exakt wiederholt
werden. Als Organisationstyp stehen `club` (Verein) und `flight_school`
(Flugschule) zur Auswahl.

Der eingegebene Organisationsname wird zugleich als anfänglicher
**Anzeigename** übernommen und erscheint öffentlich im Kopf der Anwendung
(„PAOLO SMS · Name“). Danach sind beide Werte unabhängig; den Anzeigename pflegen
Administratoren und Safety Manager unter `/dashboard/settings`, auch leer.
Der Name aus der Einrichtung selbst lässt sich in der Anwendung nicht ändern.

- **Better Auth:** E-Mail und Anzeigename eingeben; das Passwort wird zweimal
  verdeckt abgefragt und muss mindestens acht Zeichen lang sein.
- **Clerk:** Zuerst im richtigen Clerk-Projekt ein Konto anlegen und dessen
  E-Mail oder User-ID eingeben. Der Bootstrap prüft über Clerk, dass das Konto
  eindeutig, aktiv und nicht gesperrt ist und eine verifizierte passende bzw.
  primäre E-Mail besitzt. Er legt selbst kein Clerk-Konto an.

Der Bootstrap ist **nicht** idempotent, sondern absichtlich Fresh-only. Er
schreibt nur, wenn noch keine Organisation und keine Rollenzuweisung existiert;
bei Better Auth dürfen außerdem keine Benutzer oder Accounts vorhanden sein.
Auch der Zwischenzustand „Organisation vorhanden, aber kein Admin“ wird ohne
Änderung abgelehnt und muss vor einem weiteren Schritt geprüft werden. Fehlende
Tabellen oder Rollen werden nicht repariert: dann zuerst den Migrationslauf
prüfen beziehungsweise wiederholen.

Für automatisierte Provisionierung gibt es einen non-interaktiven Modus. Unter
PowerShell nicht `npm run setup:initialize -- …` verwenden, weil PowerShell `--`
selbst auswertet und der Bootstrap dann stillschweigend interaktiv nachfragt;
stattdessen `node scripts/initialize-installation.mjs …` aufrufen.


```bash
docker compose run --rm --no-deps app npm run setup:initialize -- \
  --non-interactive \
  --organization-name="Beispielverein" \
  --organization-type=club \
  --admin-email=admin@example.org \
  --confirm-database=paolo
  
```

Bei Better Auth muss zusätzlich `BETTER_AUTH_BOOTSTRAP_PASSWORD` ausschließlich für diesen Prozess über die Laufzeitumgebung oder einen geeigneten Secret-Mechanismus gesetzt werden; Passwörter gehören nie in Argumente oder das Repository. Zusätzlich ist bei Better Auth `--admin-name="Admin Name"` verpflichtend. Bei Clerk ist `--admin-email` ausreichend, da der Clerk-User bereits existiert.

`--admin-user-id=<id>` kann bei Clerk anstelle der E-Mail verwendet
werden. `npm run setup:initialize -- --help` zeigt alle Optionen.

---

### 6.3 Optionale Spieldaten (nur docker, VMS Betrieb)

Nach Migration und Bootstrap kann eine fachlich leere Installation mit einem
synthetischen Beispieldatensatz befüllt werden. Derselbe Operator-One-off kann
später alle fachlichen Daten einschließlich Anhängen und lokalen Backups
bestätigungspflichtig entfernen. Vor beiden Ausführungen die Vorschau prüfen;
vor dem Reset ist die App zu stoppen. Das vollständige Verfahren steht in
[`operator-demo-data.md`](operator-demo-data.md).

## 7. Lokaler Storage

- Mit `STORAGE_PROVIDER=local` liegen hochgeladene Anhänge im Docker-Volume
  `paolo-storage-data` (gemountet auf `LOCAL_STORAGE_DIR`, Default `/app/storage`).
  Es gibt **keine öffentlichen Direktlinks**; der Download läuft weiterhin über die
  geschützte Route.
- **DB und Storage gemeinsam sichern und wiederherstellen:** Anhang-Metadaten in der
  Datenbank verweisen per `storageKey` auf Dateien im Volume. Ein Restore muss beide
  aus **demselben Stand** wiederherstellen, sonst entstehen tote Verweise oder
  verwaiste Dateien.
- Ein **Wechsel zwischen Vercel Blob und lokalem Storage bei bereits vorhandenen
  Anhängen ist nicht automatisch möglich** — die Bytes müssten manuell migriert und
  die Metadaten angepasst werden.
- **Vercel Blob bleibt alternativ möglich** (`STORAGE_PROVIDER=vercel-blob` +
  `BLOB_READ_WRITE_TOKEN`) und ist ohne gesetzten `STORAGE_PROVIDER` der Default.

---

## 8. Prüfung nach dem Start

Öffentliche Erreichbarkeit prüfen:

- `http://localhost:3000` — Startseite
- `http://localhost:3000/submit-report` — öffentliche Meldungserfassung
- `http://localhost:3000/sign-in` — Clerk-Anmeldung

Zusätzlich:

```bash
docker compose logs app     # auf Fehler prüfen
docker compose ps           # Container-Status
```

> Diese Anleitung umfasst **keine** E2E-Tests. Authentifizierte Abläufe
> (Login/Dashboard) sind noch nicht Teil der Docker-Verifikation (siehe
> Abschnitt 11).

---

## 9. Stoppen / Aufräumen

```bash
# Container stoppen und entfernen — Volumes (DB + Storage) bleiben erhalten
docker compose down
```

> 🛑 **Achtung — Datenverlust:** `docker compose down -v` entfernt **zusätzlich die
> Volumes** `paolo-db-data` **und** `paolo-storage-data`. Damit werden **alle
> Datenbankinhalte und alle Anhänge unwiderruflich gelöscht.** Nur in Test-/
> Wegwerf-Umgebungen oder nach gesichertem Backup verwenden.

---

## 10. Backups und Restore

> Alle folgenden Kommandos sind **Vorlagen** mit Platzhaltern (`./backup`,
> `YYYY-MM-DD`). Vor Nutzung an die eigene Umgebung anpassen. Echte Ausführung
> nicht Teil dieser Anleitung — hier wird **nichts** ausgeführt.

### 10.1 Was muss gesichert werden?

- **PostgreSQL-Datenbank** (Service `db`, Volume `paolo-db-data`).
- **Lokaler Storage / Datei-Volume** `paolo-storage-data` — **nur** bei
  `STORAGE_PROVIDER=local` (bei `vercel-blob` liegen die Dateien extern bei Vercel).
- **`.env.docker.local`** bzw. eine **sichere, verschlüsselte Kopie** davon
  (enthält Secrets — DB-Passwort, Clerk-Keys, ggf. Blob-Token).
- **Optional:** der verwendete **Git-Commit / Release-Stand** (damit Code und
  Datenstand zusammenpassen).

### 10.2 Warum DB und Storage zusammengehören

- Ein Attachment besteht aus **DB-Metadaten** (u. a. `storageKey`) **und** dem
  **Dateiinhalt** im Storage.
- **DB-Backup ohne Storage** → Metadaten zeigen auf fehlende Dateien (tote Verweise).
- **Storage-Backup ohne DB** → Dateien ohne Metadaten (verwaiste Dateien).
- **Backup-Zeitpunkte konsistent halten:** DB und Storage möglichst aus **demselben
  Stand** sichern. Für einen konsistenten Punkt die App kurz stoppen
  (`docker compose stop app`), dann DB **und** Storage sichern, danach wieder
  starten (`docker compose start app`). Siehe auch Abschnitt 7.

### 10.3 Beispiel-Kommandos (Vorlage)

**PostgreSQL-Dump** (Werte kommen aus der Container-Umgebung, keine Secrets im Befehl):

```bash
mkdir -p ./backup
docker compose exec -T db sh -c 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB"' \
  > ./backup/paolo-db_YYYY-MM-DD.sql
```

**Storage-Volume sichern** (temporärer Hilfscontainer, read-only gemountet):

```bash
docker run --rm \
  -v paolo-storage-data:/data:ro \
  -v "$(pwd)/backup":/backup \
  busybox tar czf /backup/paolo-storage_YYYY-MM-DD.tgz -C /data .
```

> **Hinweis zu Volume-Namen:** Compose kann Volumes mit dem Projektnamen
> **präfixen** (z. B. `<projekt>_paolo-storage-data`). Den tatsächlichen Namen mit
> `docker volume ls` prüfen und im Kommando verwenden.

**Datenbank aus Dump wiederherstellen** (in eine **leere/frische** DB):

```bash
docker compose exec -T db sh -c \
  'psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB"' \
  < ./backup/paolo-db_YYYY-MM-DD.sql
```

**Storage-Volume wiederherstellen:**

```bash
docker run --rm \
  -v paolo-storage-data:/data \
  -v "$(pwd)/backup":/backup:ro \
  busybox sh -c 'rm -rf /data/* && tar xzf /backup/paolo-storage_YYYY-MM-DD.tgz -C /data'
```

### 10.4 Restore-Testablauf

Ein Backup ist erst belastbar, wenn ein Restore **erfolgreich getestet** wurde.
Ablauf in einer **isolierten Test-/Wegwerf-Umgebung** (nicht produktiv):

1. **Frische Docker-Instanz** vorbereiten (leere Volumes, eigenes Projekt-/
   Verzeichnis, separate `.env.docker.local` mit Testwerten).
2. **App stoppen bzw. isoliert starten** (nur `db` hochfahren:
   `docker compose up -d db`), damit während des Restores nichts schreibt.
3. **Datenbank** aus dem Backup wiederherstellen (10.3).
4. **Storage-Backup** wiederherstellen (10.3) — passend zum selben Sicherungsstand.
5. **App starten** (`docker compose up -d app`).
6. **Smoke-Test** (Kernpfade):
   - `/` aufrufen
   - `/submit-report` aufrufen
   - Login prüfen
   - `/dashboard` öffnen
   - eine vorhandene **Meldung** öffnen
   - **Attachment-Download** prüfen, falls vorhanden
   - `/datenschutz` und `/impressum` prüfen
7. **Ergebnis dokumentieren** (Datum, Backup-Stand, Befund).
8. **Restore-Test regelmäßig wiederholen**, besonders **vor größeren Updates**.

### 10.5 Intervall und Warnhinweise

- **Intervall:** mindestens **monatlich**, besser **wöchentlich** (vgl.
  [`containerization-roadmap.md`](containerization-roadmap.md) §2.4 — kann am
  Sicherheitsmeeting-Rhythmus ausgerichtet werden).
- **Restore niemals direkt über eine produktive Instanz testen.**
- **Vor** einem produktiven Restore den **aktuellen Zustand sichern**.
- **Keine produktiven Daten** in unsichere Testumgebungen kopieren.
- Backups **verschlüsselt und zugriffsgeschützt** aufbewahren (enthalten
  personenbezogene Daten und Secrets).
- **Aufbewahrungsfrist** für Backups festlegen (Bezug zu Lösch-/Aufbewahrungs-
  konzept, vgl. [`data-protection-concept.md`](data-protection-concept.md)).
- Eine Backup-Routine ist **erst belastbar, wenn ein Restore erfolgreich getestet
  wurde** (10.4).

---

## 11. Bekannte Grenzen

- **Bei `AUTH_MODE=clerk`** bleiben Auth/Benutzerverwaltung in der Cloud;
  `AUTH_MODE=betterauth` läuft selbst betrieben (siehe Abschnitt 6.2), ob dies
  bereits ein vollwertiger produktiver Clerk-Ersatz ist, ist noch nicht
  abschließend geklärt (siehe
  [`installation-decision-guide.md`](installation-decision-guide.md)).
- **Keine automatische Migration** beim Containerstart; Initialisierung manuell.
- **Kein produktionsreifes Backup-/Update-System** — nur die obigen manuellen
  Hinweise.
- **Produktionsbetrieb nutzt ein separates Compose-Overlay mit Nginx**; siehe
  [`docker-vm-deployment.md`](docker-vm-deployment.md). Die lokale
  Standard-Compose-Datei bleibt bewusst ohne TLS/Reverse Proxy.
- **Keine Mail-/Einladungsalternative ohne Clerk** — Login-/Einladungsflüsse laufen
  über Clerk.
- **MinIO/S3-Storage** ist noch nicht umgesetzt (spätere, optionale Ausbaustufe).
- **Auth-/Dashboard-Smoke-Test** ist noch nicht Teil der Docker-Verifikation; bisher
  wurden nur die öffentlichen Seiten und das Clerk-`/sign-in`-Rendering geprüft.

---

*Experimentelle Anleitung. Für produktiven Betrieb sind die Phase-D-Themen
(Backup/Restore, TLS, Secrets-Management, Monitoring, Updates) zwingend zu
ergänzen — siehe [`containerization-roadmap.md`](containerization-roadmap.md).*
