# Berechtigungsmatrix

Vollständige Aufstellung der Berechtigungen je Rolle, erhoben aus dem Code:
`lib/constants/roles.ts`, die Guards aller Seiten, die Route Handler und die
Server Actions unter `lib/actions/`.

Diese Datei ist eine **Referenz**, keine Spezifikation. Verbindlich ist der
Code; das Modell, die Begründungen und die Sonderregeln stehen in
[`roles-and-permissions.md`](roles-and-permissions.md). Wer eine Berechtigung
ändert, zieht beide Dateien nach.

Die fachliche Gegenprobe — wozu eine Rolle da ist und welche Rechte sie dafür
braucht — steht in [`role-responsibilities.md`](role-responsibilities.md). Eine
Abweichung zwischen dort und hier ist ein Befund, kein Formfehler.

## Lesart

- Zellen sind streng **J** (erlaubt) oder **N** (nicht erlaubt).
- Alles Bedingte — Organisation, Datensatz, Status, Freigabe, geerbte
  Sichtbarkeit — steht in der Spalte „Absicherung und Scope", nie als
  Zwischenwert in der Zelle. Ein eingeklammertes Häkchen gibt es hier nicht.
- Spalten: **A** Administrator, **SM** Safety Manager, **SA** Safety Assistant,
  **BN** Benutzer (`member`).
- Die Spalte **Ebene** nennt, welche Testebene die Zeile trägt (Issue #43):
  **U** die Rollenachse als vollständige Wahrheitstabelle in
  `tests/auth/role-predicates.test.ts`; **S** die Verdrahtung — dass die Stelle
  überhaupt einen Guard aufruft — in `tests/auth/guard-wiring.test.ts`;
  **E** zusätzlich End-to-End, wo der Scope an einem Datenzustand hängt oder die
  Aussage ein Statuscode der laufenden Anwendung ist.
- Ein angemeldetes Konto **ohne** zugewiesene Rolle verhält sich wie ein
  anonymer Besucher, siehe „Konten ohne Rolle" in
  [`roles-and-permissions.md`](roles-and-permissions.md).
- Die Datei hat zwei Blickrichtungen auf denselben Code. Die **fachlichen
  Abschnitte** (Meldungen, Maßnahmen, Dokumente, Anhänge, Administration)
  beantworten „welches Recht, mit welchem Scope, auf welcher Testebene". Der
  Abschnitt **„Seiten und Routen"** am Ende beantwortet „welcher Guard sitzt
  wo" und ist die vollständige Liste jedes Einstiegspunkts. Eine Route kann
  deshalb in beiden auftauchen — mit unterschiedlicher Aussage, nicht als
  Wiederholung.

---

## Öffentlich — ohne Anmeldung

| Technischer Name | Klartext | A | SM | SA | BN | Ebene | Absicherung und Scope |
|---|---|:-:|:-:|:-:|:-:|:-:|---|
| `createReport` | Meldung erfassen | J | J | J | J | U · S · E | Bewusst keine Rollenprüfung (öffentliches Formular), auch anonym. Scope: Rate-Limit je Organisation; bei eingeschalteter Datenschutz-Einwilligung serverseitig nur mit Zustimmung zum aktuellen Stand |
| `getCommunicationsVisibilityDbValues` | Öffentliche Dokumente lesen | J | J | J | J | U · S · E | Scope: ausschließlich `public`; ohne zugewiesene Rolle identisch zur anonymen Sicht |
| `canServePublicly` | Freigegebenen Anhang anmeldefrei laden | J | J | J | J | U · S · E | Scope: `is_public` **und** Elterndokument exakt `public`; zusätzlich Rate-Limit |

## Meldungen

| Technischer Name | Klartext | A | SM | SA | BN | Ebene | Absicherung und Scope |
|---|---|:-:|:-:|:-:|:-:|:-:|---|
| `hasReportReadRole` | Dashboard betreten | J | J | J | N | U · S · E | Ablehnung als 404 mit Erklärseite |
| `hasReportReadRole` | Meldungen ansehen | J | J | J | N | U · S | Sicherheitsfachlicher Inhalt in Liste und Detail; kein Scope auf eigene Meldungen |
| `hasReporterIdentityReadRole` | Melderidentität ansehen (Name, Rolle, Kontakt) | J | J | **N** | N | U · S · E | Ü1 aus #50. Enger als `hasReportReadRole`. Ohne die Fähigkeit wird der Abschnitt nicht gerendert **und** die Spalten werden nicht abgefragt |
| `hasReportNotesReadRole` | Interne Notizen und Nachträge ansehen | J | J | **N** | N | U · S · E | Ü1 aus #50. Die Abfrage entfällt ohne die Fähigkeit |
| `updateReportCore` | Meldungskern bearbeiten | J | J | N | N | U · S | `hasSafetyEditRole` |
| `updateReportWorkflow` | Status und Priorität ändern | J | J | N | N | U · S | `hasSafetyEditRole` |
| `updateReportClassification` | Klassifikation und Risiko bearbeiten | J | J | N | N | U · S | `hasSafetyEditRole` |
| `updateReportReporterInfo` | Melderdaten bearbeiten | J | J | N | N | U · S | `hasSafetyEditRole`; Audit-Werte werden redigiert |
| `createReportNote` | Notiz oder Nachtrag anlegen | J | J | N | N | U · S | `hasSafetyEditRole`; setzt Anonymisierungsstatus auf `needs_review` |
| `softDeleteReport` | Meldung in den Papierkorb | J | J | N | N | U · S | `hasSafetyEditRole` |
| `restoreReport` | Meldung wiederherstellen | J | J | N | N | U · S · E | `hasSafetyEditRole`; Scope: nur Datensätze im Papierkorb |
| `hardDeleteReport` | Meldung endgültig löschen | J | J | N | N | U · S · E | `hasSafetyEditRole`; Scope: nur aus dem Papierkorb heraus |
| `anonymizeReport` | Meldung anonymisieren | J | J | N | N | U · S · E | `hasSafetyEditRole`; Scope: statusabhängig, bestätigte Checkliste |
| `logRetentionReview` | Datenschutzprüfung dokumentieren | J | J | N | N | U · S · E | `hasSafetyEditRole`; auch für Datensätze im Papierkorb |
| `/dashboard/reports/trash` | Papierkorb ansehen | J | J | N | N | U · S · E | `hasSafetyEditRole` — enger als die Meldungsliste |

## Maßnahmen

| Technischer Name | Klartext | A | SM | SA | BN | Ebene | Absicherung und Scope |
|---|---|:-:|:-:|:-:|:-:|:-:|---|
| `/dashboard/measures` | Maßnahmen ansehen | J | J | J | N | U · S · E | `hasMeasureReadRole` — seit #44 die fachlich gemeinte Fähigkeit, vorher `reports.view` |
| `createMeasure` | Maßnahme anlegen | J | J | N | N | U · S · E | `hasSafetyEditRole`; protokolliert als `MEASURE_CREATED` |
| `updateMeasure` | Maßnahme bearbeiten | J | J | N | N | U · S · E | `hasSafetyEditRole`; der Wechsel auf „Verworfen" verlangt eine Begründung und wird als `MEASURE_DISCARDED` protokolliert |
| — | Maßnahme löschen | N | N | N | N | — | Es existiert keine Delete-Action; für niemanden möglich. Der vorgesehene Weg ist der Status „Verworfen" |

## SMS-Dokumente

| Technischer Name | Klartext | A | SM | SA | BN | Ebene | Absicherung und Scope |
|---|---|:-:|:-:|:-:|:-:|:-:|---|
| `hasDocumentReadRole` | Interne Dokumentliste öffnen | J | J | J | N | U · S · E | Sichtbarkeits-Scope je Rolle über `getReadableVisibilityDbValues` |
| `visibility: confidential` | Vertrauliches Dokument lesen | J | J | N | N | U · S | Unbekannte Spaltenwerte gelten ebenfalls als `confidential` |
| `visibility: staff` | Internes Dokument lesen | J | J | J | N | U · S | Altwert `published` zählt hierzu |
| `hasMembersDocumentReadRole` | Mitglieder-Dokument lesen | J | J | J | J | U · S · E | Fähigkeit `documents.read.members`; Scope: `member` nur auf `/communications`, nicht im Dashboard |
| `createSmsDocument` | Dokument anlegen | J | J | N | N | U · S | `hasSafetyEditRole` |
| `updateSmsDocument` | Dokument und Sichtbarkeit ändern | J | J | N | N | U · S · E | Scope: Herabstufung von `public` nimmt alle Anhang-Freigaben in derselben Transaktion zurück |
| `deleteSmsDocument` | Dokument löschen | J | J | N | N | U · S | `hasSafetyEditRole`; löscht Anhänge im Speicher mit |
| `prefillMeetingMinutes` | Protokollvorlage vorbefüllen | J | J | N | N | U · S | `hasSafetyEditRole`; schreibt nichts, liefert nur gerenderten Text |
| `/documents/[documentId]/print` | Druckansicht öffnen | J | J | J | N | U · S · E | `hasDocumentReadRole`; Sichtbarkeits-Scope wie interne Liste |

## Anhänge

| Technischer Name | Klartext | A | SM | SA | BN | Ebene | Absicherung und Scope |
|---|---|:-:|:-:|:-:|:-:|:-:|---|
| `hasAttachmentAccessRole` | Anhang an Meldung hochladen | J | J | J | N | U · S · E | Scope: Typ- und Größengrenzen serverseitig |
| `/dashboard/reports/…/download` | Anhang einer Meldung laden | J | J | J | N | U · S · E | `hasAttachmentAccessRole` — seit #44 dieselbe Quelle wie der Upload |
| `deleteAttachment` | Anhang einer Meldung löschen | J | J | N | N | U · S · E | `hasSafetyEditRole` — enger als der Upload |
| `uploadSmsDocumentAttachment` | Anhang an Dokument hochladen | J | J | N | N | U · S | `hasSafetyEditRole` |
| `canServeToSession` | Anhang eines Dokuments laden | J | J | J | J | U · S · E | Scope: geerbte Dokumentsichtbarkeit; `member` nur bei `members`/`public`, Safety Assistant zusätzlich `staff` |
| `deleteSmsDocumentAttachment` | Anhang eines Dokuments löschen | J | J | N | N | U · S | `hasSafetyEditRole` |
| `publishSmsDocumentAttachment` | Anhang öffentlich freigeben | J | J | N | N | U · S · E | Scope: nur Dokument-Anhänge, vollständige Checkliste, Freigabevermerk, Audit in einer Transaktion |
| `unpublishSmsDocumentAttachment` | Freigabe zurücknehmen | J | J | N | N | U · S · E | `hasSafetyEditRole`; Freigabenachweis bleibt erhalten |

## Administration

| Technischer Name | Klartext | A | SM | SA | BN | Ebene | Absicherung und Scope |
|---|---|:-:|:-:|:-:|:-:|:-:|---|
| `/dashboard/admin` | Administrationsübersicht öffnen | J | J | N | N | U · S · E | `hasSafetyEditRole`; Import- und Export-Karte zusätzlich nur für Admin |
| `canManageRoles` | Zugangs- und Rollenverwaltung öffnen | J | J | J | N | U · S · E | Safety Assistant serverseitig erlaubt, Navigationslink ausgeblendet. Angezeigt werden seit #50/Ü2 nur Konten, die der Handelnde laut `canManageTargetUser` auch verwalten darf |
| `createUserWithRole` | Benutzer anlegen | J | J | J | N | U · S · E | Scope: nur zuweisbare Rollen; Safety Assistant ausschließlich `member` |
| `assignRole` | Rolle zuweisen oder wechseln | J | J | J | N | U · S · E | Scope: `ASSIGNABLE_ROLES` und `canManageTargetUser`; der letzte funktionsfähige Administrator ist nicht herabstufbar, auch nicht bei parallelen Änderungen (Sperre in der Transaktion, `lib/auth/admin-role-lock.ts`) |
| `removeRole` | Rolle entfernen | J | J | J | N | U · S · E | Scope: `REMOVABLE_ROLES`; nicht der letzte funktionsfähige Administrator; nicht die einzige Rolle des Zielbenutzers |
| `issueAccessLink` | Anmeldelink erneuern (Clerk: Sign-in-Link; Better Auth: Link zum Festlegen eines Passworts) | J | J | N | N | U · S · E | Fähigkeit `accounts.access` (`hasAccountAccessRole`) UND Zuständigkeitsbereich der Rollenverwaltung (`canManageAccountAccess` → `canManageTargetUser`); nie am eigenen Konto; nicht für ein Konto, das es nicht mehr gibt. Der Safety Assistant erhält die Aktion nicht. Audit `ACCESS_LINK_ISSUED` mit Handelndem und Ziel-Kennung, nie mit Link oder Token. Link sieben Tage gültig; ältere Links bleiben bis zum Ablauf gültig |
| `updateAccountData` | Kontodaten ändern (Name; E-Mail nur bei Better Auth) | J | J | N | N | U · S · E | Fähigkeit `accounts.access` UND Zuständigkeitsbereich der Rollenverwaltung (`canManageAccountAccess`); nie am eigenen Konto. Bei Clerk lehnt die Aktion eine E-Mail-Änderung ab. Audit `ACCOUNT_DATA_UPDATED` nur mit Feldnamen, nie mit Werten |
| `deleteAccount` | Konto löschen (ohne vorherige Sperrung) | J | J | N | N | U · S · E | `canDeleteAccount` (= `canManageAccountAccess`, zusätzlich nie mit Administratorrolle und nie das eigene Konto); die vollständige E-Mail-Adresse bestätigt serverseitig. Better Auth: eine Transaktion aus Rollen, Konto (Sitzungen per Kaskade) und Audit. Clerk: Administratorrolle unmittelbar vor dem Anbieteraufruf erneut prüfen (bei Unsicherheit Abbruch), dann Anbieter, dann Rollen und Audit. Audit `ACCOUNT_DELETED` mit Kennung und bisheriger Rolle, ohne Name und E-Mail. Der Safety Assistant erhält die Aktion nicht |
| `removeOrphanedRole` | Verwaiste Rolle bereinigen | J | J | J | N | U · S · E | Scope wie `removeRole`, bestimmt von der Rolle des Eintrags (`canManageTargetUser`, `canRemoveRole`); ein unbekannter Rollenwert gilt als Administrator. Nur wenn das Konto beim Anmeldedienst nachweislich fehlt — bei nicht erreichbarem Verzeichnis wird nichts bereinigt. Der Schutz der letzten Rolle greift hier nicht, weil kein Konto zurückbleibt |
| `/dashboard/audit` | Audit-Log ansehen | J | J | N | N | U · S | `hasSafetyEditRole` |
| `updateOrganizationSettings` | Organisationseinstellungen ändern | J | J | N | N | U · S | `hasSafetyEditRole` |
| `updateOrganizationDisplayName` | Anzeigename der Organisation ändern (öffentlich sichtbar im Kopf) | J | J | N | N | U · S · E | `hasSafetyEditRole`; Audit `ORG_DISPLAY_NAME_CHANGED` |
| `updatePublicReportStatusVisibility` | Öffentliche Statusrückmeldungen ein-/ausschalten | J | J | N | N | U · S | `hasSafetyEditRole` |
| `updateSmsGovernanceSettings` | Besprechungsturnus und Governance ändern | J | J | N | N | U · S | `hasSafetyEditRole` |
| `createSafetyMeeting` | Sicherheitsbesprechung eintragen | J | J | N | N | U · S | `hasSafetyEditRole` |
| `updateLegalSettings` | Impressum und Rechtstexte ändern | J | J | N | N | U · S | `hasSafetyEditRole` |
| `/dashboard/privacy` | Datenschutzbereich öffnen | J | J | N | N | U · S | Übersicht, Vorfälle und Anfragen; je eigener Guard, alle `hasSafetyEditRole` |
| `createPrivacyIncident` | Datenschutzvorfall erfassen | J | J | N | N | U · S | `hasSafetyEditRole` |
| `updatePrivacyIncident` | Datenschutzvorfall fortschreiben | J | J | N | N | U · S | `hasSafetyEditRole` |
| `updatePublicReportPrivacyConsentSettings` | Einwilligung im Meldeformular ein-/ausschalten, Text ändern | J | J | N | N | U · S | `hasSafetyEditRole`; auf `/dashboard/privacy`, jede Änderung im Audit-Log |
| `/dashboard/export/fida` | FIDA-Export öffnen und ziehen | J | J | N | N | U · S · E | Seite und `/api/export/fida` beide `hasSafetyEditRole` — anders als der CSV-Export |
| `importReports` | Meldungen als CSV importieren | J | N | N | N | U · S · E | `hasAdminRole` |
| `/api/export/reports` | Meldungen als CSV exportieren | J | N | N | N | U · S · E | `hasAdminRole` |
| `requireGlobalAdmin` | Backup erstellen und herunterladen | J | N | N | N | U · S · E | `isGlobalAdmin` leitet sich seit #44 aus `hasAdminRole` ab; liest über globale Rollen |
| `/api/cron/backup` | Backup per Cron auslösen | N | N | N | N | U · S · E | Keine Rollenprüfung; Bearer-Secret im Authorization-Header, über die Oberfläche für niemanden erreichbar |

---

## Seiten und Routen

Vollständige Liste aller Einstiegspunkte: jede `page.tsx` und jeder
`route.ts` unter `app/`. Diese Tabelle ist die **einzige** Route-zu-Guard-
Übersicht des Projekts; die früheren Tabellen „Seitenzugriff" und „Guards je
Seite / Route" in [`roles-and-permissions.md`](roles-and-permissions.md)
führten dieselbe Aussage doppelt und sind entfallen.

Alle Dashboard-Seiten prüfen zusätzlich die Sitzung und leiten ohne Anmeldung
auf `/sign-in` um. Eine abgelehnte Seite antwortet mit 404 und der Erklärseite
aus `app/dashboard/not-found.tsx`, nicht mit 403 — der Statuscode verrät damit
nicht, ob es die Seite gibt.

### Öffentliche Seiten — ohne Anmeldung

| Route | Guard | A | SM | SA | BN | Absicherung und Scope |
|---|---|:-:|:-:|:-:|:-:|---|
| `/` | keiner | J | J | J | J | Startseite |
| `/submit-report` | keiner | J | J | J | J | Bewusst anmeldefrei; die Abgabe selbst siehe `createReport` |
| `/communications` | keiner | J | J | J | J | Scope über `getCommunicationsVisibilityDbValues`: anonym nur `public`, mit zugewiesener Rolle zusätzlich `members` |
| `/impressum` | keiner | J | J | J | J | Inhalte aus den rechtlichen Angaben |
| `/datenschutz` | keiner | J | J | J | J | Inhalte aus den rechtlichen Angaben |
| `/sign-in`, `/sign-up` | keiner | J | J | J | J | Selbstregistrierung ist providerseitig abgeschaltet |
| `/documents` | keiner | J | J | J | J | Nur `redirect()` auf `/dashboard/documents`; der Guard sitzt am Ziel |

### Interner Bereich

| Route | Guard | A | SM | SA | BN | Absicherung und Scope |
|---|---|:-:|:-:|:-:|:-:|---|
| `/dashboard` | `hasReportReadRole` | J | J | J | N | |
| `/dashboard/reports` | `hasReportReadRole` | J | J | J | N | Kein Scope auf eigene Meldungen |
| `/dashboard/reports/[reportId]` | `hasReportReadRole` | J | J | J | N | Nur Datensätze ohne `deletedAt`. Feldebene: Melderblock und Notizen zusätzlich hinter `hasReporterIdentityReadRole` bzw. `hasReportNotesReadRole` |
| `/dashboard/reports/trash` | `hasSafetyEditRole` | J | J | N | N | Enger als die Meldungsliste |
| `/dashboard/measures` | `hasMeasureReadRole` | J | J | J | N | Seit #44 die fachlich gemeinte Fähigkeit |
| `/dashboard/documents` | `hasDocumentReadRole` | J | J | J | N | Sichtbarkeits-Scope über `getReadableVisibilityDbValues` |
| `/dashboard/hilfe` | `hasReportReadRole` | J | J | J | N | In-App-Hilfe; welche Anleitung erscheint, entscheidet `resolveHelpDocument` — Anzeige, keine Berechtigung |
| `/documents/[documentId]/print` | `hasDocumentReadRole` | J | J | J | N | Gleicher Scope wie die interne Liste |
| `/dashboard/users` | `canManageRoles` | J | J | J | N | Safety Assistant serverseitig erlaubt, Navigationslink ausgeblendet; vergebbare Rollen über `ASSIGNABLE_ROLES`. Die Kontenliste zeigt jedes Verzeichniskonto einmal und nur, was der Handelnde laut `canManageTargetUser` verwalten darf; Status: Aktiv, Ohne Rolle, Konto fehlt, Konto nicht prüfbar |
| `/dashboard/admin` | `hasSafetyEditRole` | J | J | N | N | Einzelne Karten zusätzlich enger, siehe die Zeilen ihrer Ziele |
| `/dashboard/settings` | `hasSafetyEditRole` | J | J | N | N | |
| `/dashboard/admin/legal` | `hasSafetyEditRole` | J | J | N | N | |
| `/dashboard/audit` | `hasSafetyEditRole` | J | J | N | N | Nur lesend, neueste 100 Einträge |
| `/dashboard/privacy` | `hasSafetyEditRole` | J | J | N | N | |
| `/dashboard/privacy/incidents` | `hasSafetyEditRole` | J | J | N | N | |
| `/dashboard/privacy/requests` | `hasSafetyEditRole` | J | J | N | N | Reine Suchhilfe, keine Ausgabe und keine Löschung |
| `/dashboard/export/fida` | `hasSafetyEditRole` | J | J | N | N | Andere Schwelle als der CSV-Export — bewusst |
| `/dashboard/import` | `hasAdminRole` | J | N | N | N | |
| `/dashboard/admin/backup` | `hasAdminRole` über `getCurrentUserGlobalRoles` | J | N | N | N | Liest ausschließlich globale Rollen |

### Route Handler

| Route | Guard | A | SM | SA | BN | Absicherung und Scope |
|---|---|:-:|:-:|:-:|:-:|---|
| `/dashboard/reports/[reportId]/attachments/[attachmentId]/download` | `hasAttachmentAccessRole` | J | J | J | N | Seit #44 dieselbe Quelle wie der Upload; prüft zusätzlich `deletedAt` — Anhänge einer Meldung im Papierkorb sind auch per URL nicht abrufbar |
| `/documents/[documentId]/attachments/[attachmentId]/download` | `canServeToSession` | J | J | J | J | Scope: geerbte Dokumentsichtbarkeit. `member` erreicht `members`/`public`, Safety Assistant zusätzlich `staff`. Bewusst nicht unter `/dashboard`, weil `member` ohne Dashboard-Zugang hier lädt |
| `/communications/attachments/[attachmentId]/[[...filename]]` | `canServePublicly` | J | J | J | J | Anmeldefrei. Nur wenn `is_public` **und** Elterndokument exakt `public`; doppelt geprüft, jede Ablehnung 404 |
| `/api/export/fida` | `hasSafetyEditRole` | J | J | N | N | Gleiche Schwelle wie die Seite |
| `/api/export/reports` | `hasAdminRole` | J | N | N | N | |
| `/dashboard/admin/backup/[backupId]/archive` | `requireGlobalAdmin` | J | N | N | N | 401 ohne Sitzung, 403 ohne Rolle |
| `/dashboard/admin/backup/[backupId]/manifest` | `requireGlobalAdmin` | J | N | N | N | 401 ohne Sitzung, 403 ohne Rolle |
| `/api/cron/backup` | Bearer-Secret | N | N | N | N | Keine Rollenprüfung; über die Oberfläche für niemanden erreichbar |
| `/api/health` | keiner | J | J | J | J | Betriebsendpunkt ohne Daten aus der Anwendung |
| `/api/auth/[...all]` | Better Auth | J | J | J | J | Nur bei `AUTH_MODE=betterauth`; Autorisierung liegt in Better Auth, Selbstregistrierung per `disableSignUp` abgeschaltet. Allowlist (`lib/auth/auth-route-allowlist.ts`): nur `POST /sign-in/email`, `GET /get-session`, `GET /ok` und `POST /sign-out`, alles andere antwortet mit 404 — insbesondere `request-password-reset` und `reset-password*` |
| `/set-password` | keiner (das Token im URL-Fragment ist der Schlüssel) | J | J | J | J | Nur bei `AUTH_MODE=betterauth`, sonst 404. Ruft `auth.api.resetPassword` direkt auf; je Netz ratenbegrenzt, neutrale Fehlermeldung, alle Sitzungen der Person werden danach widerrufen |


---

## Wo die Berechtigungen stehen

Seit #44 gibt es **eine** Quelle: die Tabelle `ROLE_CAPABILITIES` in
`lib/constants/roles.ts`. Die benannten Prädikate der Spalte „Absicherung" sind
dünne Zugriffe darauf — sie tragen die fachliche Absicht an der Aufrufstelle,
die Rollenliste steht aber nur in der Tabelle.

Im gesamten System gibt es genau vier Rollenmengen: Administration
(`admin`), Bearbeitung (`admin`, `safety_manager`), interner Zugang
(`admin`, `safety_manager`, `instructor`) und die gesamte angemeldete
Mitgliedschaft (alle vier Rollen). Die vierte kam mit #50/M1 hinzu — das
Sichtbarkeitsmodell der SMS-Dokumente kennt vier Stufen, und `members`
adressiert mehr als den Bearbeiterkreis. Ein Prädikat, das eine **fünfte**
einführt, fällt in `tests/auth/role-predicates.test.ts` auf.

Die frühere zweite Quelle — die generische Matrix in `lib/auth/permissions.ts`,
von der fünf der sieben Einträge nie aufgerufen wurden — ist entfallen, ebenso
die vier Schreibweisen des Admin-Checks und die Inline-Rollenliste der
Anhang-Download-Route.

## Testabdeckung

Die Zuordnung der Ebenen ist in #43 umgesetzt:

- `tests/auth/role-predicates.test.ts` — Wahrheitstabellen aller
  Rollenprädikate über alle vier Rollen, die leere Rollenmenge, Mehrfachrollen
  und unbekannte Rollen-Strings.
- `tests/auth/guard-wiring.test.ts` — Strukturtest: Jede Server Action, jeder
  Route Handler und jede Dashboard-Seite ruft einen bekannten Guard auf oder
  steht auf einer begründeten Ausnahmeliste.
- `tests/e2e/permission-boundaries.spec.ts` — Wirkung und Scope im laufenden
  System, je Mechanismus an der Rolle geprüft, die seine Grenze markiert.

## Pflegehinweis

Diese Datei wird von Hand geführt und ist nicht generiert. Erstmals erhoben mit
`main` @ `aee7715`, seither fortgeschrieben — zuletzt um den vollständigen
Abschnitt „Seiten und Routen", der die beiden doppelt geführten Routentabellen
aus [`roles-and-permissions.md`](roles-and-permissions.md) abgelöst hat. Bei jeder Änderung an einem Guard, einer
Server Action oder an `ROLE_CAPABILITIES` gehört die betroffene Zeile
mitgezogen — und, wenn sich das Modell ändert, auch
[`roles-and-permissions.md`](roles-and-permissions.md).
