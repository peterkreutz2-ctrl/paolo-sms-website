# Organisations-Scoping-Analyse

Bewertet, wie weit PAOLO SMS auf Mehrorganisationenbetrieb vorbereitet ist und welche Stellen angepasst werden müssen, bevor Admin, Safety Manager, Safety Assistant und Member ausschließlich Daten ihrer eigenen Organisation sehen oder bearbeiten können.

---

## Kurzfazit

Das Datenbankschema trägt das Zielrollenmodell bereits weitgehend. Die zentrale Infrastruktur — `organizationId`-Felder in Kerntabellen, nullbarer `organizationId`-Eintrag in `userRoles` mit separaten Unique-Constraints für globale und org-gebundene Rollen — ist vorhanden.

Die Anwendungslogik ist davon entkoppelt: Queries filtern nicht nach Organisation, Datenzugriff ist nicht org-gesichert, und der Org-Kontext des eingeloggten Nutzers wird nirgends ermittelt. Das Pattern `.from(organizations).limit(1)` ersetzt diesen Kontext aktuell systemweit.

**Für kontrollierten Einzel-/Pilotbetrieb mit einer Organisation: geeignet.**
**Für parallelen Mehrorganisationenbetrieb mit echten Daten: nicht geeignet.**

Clerk bleibt reiner Identity Provider. Organisationen, Rollen und Berechtigungen liegen vollständig in der PAOLO-Datenbank.

---

## Zielmodell

### Globaler `admin`

- `userRoles.organizationId IS NULL`
- Keine Organisationsbindung
- Kann org-übergreifend handeln: alle Reports, alle Audit-Logs, alle Organisationsdaten
- Darf globale Rollen vergeben und entziehen
- Sehr selten vergeben
- Kein separater `org_admin` — der aktuelle `admin` ist der globale Systemadministrator

> **Lesart:** Die folgenden Blöcke beschreiben einen **zurückgestellten
> Zielzustand**, nicht den heutigen. Heute sind alle Rollen global
> (`organizationId IS NULL`). Wozu eine Rolle fachlich da ist, steht in
> [`role-responsibilities.md`](role-responsibilities.md); was sie heute darf, in
> [`permission-matrix.md`](permission-matrix.md). Hier steht ausschließlich, was
> sich am **Organisationsbezug** ändern müsste.

### Organisationsbezogener `safety_manager`

- Künftig `userRoles.organizationId = <org-id>` statt `NULL`
- Sein heutiger Rechteumfang bliebe unverändert, würde aber auf Meldungen,
  Maßnahmen, Besprechungen und Einstellungen der eigenen Organisation begrenzt
- Rollenverwaltung nur noch innerhalb der eigenen Organisation

### Organisationsbezogener `instructor`

- Künftig `userRoles.organizationId = <org-id>` statt `NULL`
- Kein Zugriff auf Daten anderer Organisationen
- Sein heutiger Rechteumfang bliebe unverändert — insbesondere die
  eingeschränkte Rollenvergabe (`member`), die er bereits hat

### Organisationsbezogener `member`

- Künftig `userRoles.organizationId = <org-id>` statt `NULL`
- Der Lesezugriff auf Dokumente der Stufe `members` würde auf die eigene
  Organisation begrenzt
- Gezielte Freigabe einzelner Meldungen an angemeldete Nutzer: mögliche spätere
  Erweiterung, kein MVP-Bestandteil

---

## Vorhandene Schema-Unterstützung

| Schema-Element | Unterstützte Funktion |
|---|---|
| `userRoles.organizationId` nullable | Globale Rollen (NULL) und org-spezifische Rollen (NOT NULL) möglich |
| Unique-Constraint `WHERE organizationId IS NULL` | Verhindert doppelte globale Rollenvergabe |
| Unique-Constraint `WHERE organizationId IS NOT NULL` | Verhindert doppelte org-spezifische Rollenvergabe |
| `reports.organizationId` NOT NULL FK | Datentrennung auf Tabellenebene vorhanden |
| `safetyMeetings.organizationId` NOT NULL FK | Org-Zuordnung für Sicherheitsbesprechungen vorhanden |
| `reportNotes.organizationId` NOT NULL FK | Org-Zuordnung für Notizen vorhanden |
| `auditLogs.organizationId` NOT NULL FK + Index | Org-Trennung im Audit-Log strukturell vorhanden |
| `organizations.safetyMeetingIntervalMonths` | Org-spezifische Konfiguration für `safety_manager` bereit |
| Rollen-Enum `admin, safety_manager, instructor, member` | Entspricht exakt dem Zielmodell |

Tabellen **ohne** direktes `organizationId`:

| Tabelle | Organisationszuordnung |
|---|---|
| `measures` | Nur indirekt über `reportId → reports.organizationId` |
| `attachments` | Nur indirekt über `reportId → reports.organizationId` |

Das Schema muss für das Zielrollenmodell nicht verändert werden. Der strukturelle Boden ist gelegt.

---

## Fehlende Org-Scoping-Mechanismen im Code

### Fundament fehlt vollständig

| Stelle | Befund |
|---|---|
| `getCurrentUserOrganizationId()` | Existiert nicht. Ohne diese Funktion kann kein Query org-korrekt filtern. |
| `getCurrentUserRoles()` | Gibt alle Rollen zurück, ohne Trennung nach globalem Scope (NULL) und org-gebundenem Scope. |
| `.from(organizations).limit(1)` | An mindestens 4 Stellen verwendet. Muss durch nutzerbezogenen Org-Kontext ersetzt werden. |

### Datenzugriff — Queries ohne Org-Filter

| Bereich | Stelle | Befund |
|---|---|---|
| Dashboard-Startseite | `app/dashboard/page.tsx` | Alle Zählabfragen ohne `organizationId`-Filter |
| Reports-Liste | `app/dashboard/reports/page.tsx` | Kein `organizationId`-Filter |
| Report-Detail | `app/dashboard/reports/[reportId]/page.tsx` | Kein Organisations-Check — beliebiger Report abrufbar |
| Maßnahmen-Liste | `app/dashboard/measures/page.tsx` | Kein Org-Filter, kein Join zu `reports.organizationId` |
| Audit-Log | `app/dashboard/audit/page.tsx` | Zeigt alle Einträge aller Organisationen |
| Sicherheitsbesprechungen | `app/dashboard/page.tsx` | Nutzt `.limit(1)`, kein Nutzerbezug |
| Export | `app/api/export/reports/route.ts` | Exportiert alle Reports aller Organisationen |
| Import | `lib/actions/import-reports.ts` | Importiert immer in die erste Organisation |

### Aktionen — fehlende Org-Verifikation

| Aktion | Befund |
|---|---|
| Report erstellen/bearbeiten | `organizationId` aus `.limit(1)`, kein Nutzer-Org-Abgleich |
| Maßnahme erstellen/bearbeiten | Prüft nicht, ob Nutzer zur Organisation des Reports gehört |
| Sicherheitsbesprechung anlegen | `organizationId` aus `.limit(1)` |
| Rollenvergabe `assignRole()` | Setzt nur globale Rollen ohne `organizationId` |
| Nutzer anlegen `createUserWithRole()` | Setzt nur globale Rollen ohne `organizationId` |

### Zugangs- und Rollenverwaltung

| Stelle | Befund |
|---|---|
| `app/dashboard/users/page.tsx` | Zeigt nur globale Rollen (`isNull(userRoles.organizationId)`) |
| Keine UI für org-spezifische Rollenvergabe | `safety_manager` und `instructor` können nicht org-gebunden vergeben werden |
| Schutz `safety_manager` handelt nur in eigener Org | Noch nicht durchgesetzt |

---

## Risiken bei Mehrorganisationenbetrieb

| Risiko | Schwere | Betroffene Stelle |
|---|---|---|
| Report-Liste zeigt alle Orgs | Kritisch | `app/dashboard/reports/page.tsx` |
| Report-Detail ohne Org-Check | Kritisch | `app/dashboard/reports/[reportId]/page.tsx` |
| Maßnahmen-Liste ohne Org-Filter | Kritisch | `app/dashboard/measures/page.tsx` |
| Export gibt alle Orgs aus | Kritisch | `app/api/export/reports/route.ts` |
| Audit-Log zeigt alle Orgs | Hoch | `app/dashboard/audit/page.tsx` |
| Import immer in erste Org | Hoch | `lib/actions/import-reports.ts` |
| Anhang-URLs ohne Org-Schutz | Hoch | Vercel Blob, keine Prüfung |
| Rollenvergabe nur global | Mittel | `lib/actions/user-roles.ts` |
| Kein Org-Kontext für Nutzer | Fundament | Gesamte Anwendung |

Das größte strukturelle Defizit: Es gibt keinen Mechanismus, der bestimmt, welche Organisation ein Nutzer gerade verwendet. Ohne diesen Kontext kann kein einziger Filter org-korrekt arbeiten.

### Attachment-Strategie

Für den Pilotbetrieb mit einer Organisation sind öffentliche Blob-URLs akzeptabel. Vor echtem Mehrorganisationenbetrieb muss geprüft werden:

- ob Blob-URLs öffentlich oder dauerhaft erreichbar sind
- ob Zugriff auf Anhänge wirklich organisationsbezogen geschützt ist
- ob Download nur über geschützte Route mit Rollen- und Organisationsprüfung erfolgen soll
- ob zeitlich begrenzte oder signierte URLs erforderlich sind

Ziel: Download nur nach Rollen- und Org-Prüfung, ggf. über geschützte Route oder signierte URLs.

---

## Empfohlene Umsetzungsphasen

### Phase 0 — Fundament schaffen (Code-only)

Ohne diese Basis ist keine weitere Phase möglich.

1. `getCurrentUserOrganizationId()` implementieren — liest aus `userRoles` die `organizationId` des eingeloggten Nutzers (globaler `admin`: NULL bedeutet org-übergreifend)
2. `getCurrentUserRoles()` erweitern — trennt globale Rollen von org-spezifischen Rollen
3. Hilfsfunktion `getDefaultOrganization()` einführen — alle `.limit(1)`-Stellen zusammenführen, damit spätere Ablösung an einem Ort geschieht

### Phase 1 — Datenzugriffs-Scoping (Code-only)

4. Dashboard-Startseite: Org-Filter in alle Zählabfragen
5. Reports-Liste: `organizationId`-Filter ergänzen
6. Report-Detail: Org-Ownership-Check ergänzen
7. Maßnahmen-Liste: Join zu `reports`, Org-Filter
8. Audit-Log: Org-Filter (admin: alle; übrige: eigene Org)
9. Sicherheitsbesprechungen: Nutzerbezug statt `.limit(1)`

### Phase 2 — Aktionen absichern (Code-only)

10. Report-Aktionen: Org-Verifikation vor Bearbeitung
11. Maßnahmen-Aktionen: Org-Verifikation über `reports.organizationId`
12. Sicherheitsbesprechungs-Aktionen: Org-Verifikation
13. Berechtigungslogik: `safety_manager` darf nur in eigener Org handeln

### Phase 3 — Zugangs- und Rollenverwaltung (Code-only)

14. `assignRole()` und `createUserWithRole()` mit `organizationId`-Parameter
15. Oberfläche der Zugangs- und Rollenverwaltung: org-gebundene Rollen anzeigen und vergeben
16. Safety Manager: Einschränkung auf eigene Org durchsetzen

### Phase 4 — Import/Export (Code-only)

17. Import: Org-Zuweisung aus Nutzerkontext statt `.limit(1)`
18. Export: Org-Filter je nach Rolle (admin: alle oder Auswahl, safety_manager: eigene Org)

### Phase 5 — Schema-Erweiterungen (Migration, Entscheidung vorher treffen)

Abwägen: `measures.organizationId` und `attachments.organizationId` direkt als Spalten hinzufügen oder dauerhaft Join-Strategie. Beide Ansätze sind valide. Die Entscheidung beeinflusst, ob eine Migration notwendig ist. Empfehlung: festlegen vor Beginn von Phase 1, damit Queries von Anfang an konsistent gebaut werden.

### Phase 6 — Attachment-Schutz (vor Mehrorg-Produktivbetrieb)

19. Blob-URL-Erreichbarkeit evaluieren
20. Entscheidung: geschützte Download-Route oder signierte URLs
21. Implementierung mit Rollen- und Org-Prüfung

**Voraussetzung für Mehrorganisationenbetrieb:** Phasen 0–4 müssen abgeschlossen und getestet sein, bevor eine zweite echte Organisation angelegt wird.

---

## Datenbereinigung vor Produktivstart

Testdaten aus der Einführungsphase müssen vor Produktivstart bereinigt werden können. Betrifft:

- Meldungen (Reports)
- Maßnahmen
- Anhänge (inkl. Blob-Dateien)
- Notizen/Nachträge
- Sicherheitsbesprechungen
- Audit-Log
- Testbenutzer und Testrollen

Die Organisationskonfiguration (`organizations`-Tabelle) bleibt erhalten. Die Reihenfolge der Löschung muss FK-Constraints berücksichtigen. Wer die Bereinigung auslösen darf (nur globaler `admin`?) und ob dafür eine Dashboard-UI oder ein einmalig ausgeführtes Admin-Skript benötigt wird, ist noch offen.

---

## Offene Fragen

**a) Admin-Datenzugriff in Listen und Export**
Sieht der globale `admin` in der Reports-Liste und im Audit-Log Daten aller Organisationen gleichzeitig, oder filtert er standardmäßig auf eine Home-Organisation mit optionaler Umschaltung? Die aktuelle Planung geht davon aus: admin sieht alles. Sollte vor Implementierung bestätigt werden.

**b) `measures` und `attachments` — Join-Strategie oder direkte Spalte**
Beide Ansätze sind valide. Die Entscheidung beeinflusst, ob eine Migration notwendig ist. Vor Beginn von Phase 1 festlegen.

**c) Datenbereinigung — Umfang und Auslösung**
Wer darf Testdaten löschen (nur globaler `admin`?)? Wird dafür eine UI im Dashboard benötigt, oder reicht ein einmalig ausgeführtes Admin-Skript? Soll der Audit-Log der Bereinigung selbst erhalten bleiben oder ebenfalls bereinigt werden?

**d) Safety-Meeting-Intervall**
Die UI existiert bereits unter `/dashboard/settings`. Vor Mehrorganisationenbetrieb muss geprüft und umgesetzt werden, dass der Wert ausschließlich für die Organisation des jeweiligen `safety_manager` geändert wird.
