# Installations- und Betreiberentscheidung

Dieses Dokument ist die **zentrale Stelle** für die Frage, wie ein Verein, eine
Flugschule oder ein anderer Betreiber PAOLO SMS installieren und betreiben
sollte (App-Installationsart, Authentifizierung, Datenbank). Andere Dokumente
verweisen hierher, statt dieselbe Abwägung erneut vollständig auszuformulieren.

**Quelle:** Diese Einordnung übernimmt die Empfehlungen aus Rainers
„Entscheidungsleitfaden – Installation von Paolo" (PDF, Stand 2026-07,
außerhalb des Repositories bereitgestellt, nicht Teil dieses Repos). Der
Leitfaden verwendet die Schreibweise „Neo" für den Cloud-Datenbankdienst;
gemeint ist durchgängig **Neon**, wie im übrigen Projekt geschrieben.

---

## 1. Grundabwägung

PAOLO SMS ist keine zentral betriebene SaaS-Plattform. Jeder Verein, jede
Flugschule oder ein beauftragter IT-Dienstleister kann eine eigene,
unabhängige Produktivinstallation betreiben. Damit gibt es potenziell mehrere
„Productions" mit jeweils eigener Betriebs-, Datenschutz-, Backup- und
Updateverantwortung.

Das Projektteam betreibt nur eine produktionsnahe Referenzinstallation
(`Reference Prod`) mit Spiel-/Testdaten. Sie dient der Erprobung von
Installation und Betrieb, ist keine echte Betreiber-Produktivinstanz und
begründet keine Berechtigung, fremde Betreiberinstallationen einzusehen oder
zu verändern.

Die aktuelle Anwendung ist auf eine Organisation pro Installation
ausgerichtet und nicht echt mandantenfähig. Eine spätere zentrale
Mehrorganisationenbereitstellung, beispielsweise durch den DHV, wäre eine
größere eigenständige Produkt-, Sicherheits-, Datenschutz- und
Architekturentscheidung nach der Friends-&-Family-Phase.

Die Installationsentscheidung ist im Kern eine Abwägung zwischen:

- **Datenhoheit und laufenden Kosten** (mehr Selbstbetrieb = mehr Kontrolle,
  aber mehr Eigenaufwand) und
- **Administrationsaufwand** (mehr verwaltete Cloud-Dienste = weniger
  Eigenaufwand, aber laufende Kosten und stärkere Anbieterabhängigkeit).

Es gibt keine pauschal „beste" Variante — die passende Wahl hängt vom
technischen Know-how und den Ressourcen des jeweiligen Betreibers ab. Konkrete
Kostenbeträge werden hier bewusst nicht genannt; sie hängen von Anbieter,
Instanzgröße und Nutzung ab.

## 2. Installationsart: Docker bevorzugt

**Docker ist der bevorzugte Installationsweg** für PAOLO SMS — reproduzierbar,
mit unkomplizierten Updates. Eine native/Bare-Metal-Installation ohne
Container ist nur ein **Sonderfall für technisch versierte Betreiber** mit
bestehenden Vorgaben (z. B. vorhandene Serverlandschaft ohne Docker), nicht der
empfohlene Standard.

Praktische Anleitung: [`docker-setup.md`](docker-setup.md) (App + PostgreSQL +
optionaler lokaler Storage, lokal/experimentell) und
[`docker-vm-deployment.md`](docker-vm-deployment.md) (konkreter
Produktionspfad auf einer Ubuntu-VM mit Nginx, TLS und Backups). Für AWS kommt
zuvor das Infrastruktur-Runbook
[`runbooks/aws-account-and-ec2-provisioning.md`](runbooks/aws-account-and-ec2-provisioning.md)
zum Einsatz.

**AWS EC2 ist dabei keine eigene PAOLO-Betriebsart**, sondern eine mögliche
**Infrastruktur** für den Docker-basierten Betrieb — derselbe Docker-Aufbau
ließe sich ebenso auf einer anderen VM oder einem eigenen Server betreiben.

## 3. Empfohlene Reihenfolge für Betreiber

Bevorzugte Reihenfolge (höchste Präferenz zuerst), abgestimmt zwischen Peter
und Rainer:

Diese fachliche Präferenz ist vom **technischen Installationsdefault** zu
unterscheiden: PAOLO verwendet ohne explizites `AUTH_MODE` weiterhin Clerk.
Clerk ist damit der Standard- und Ausgangspfad der Installationsanleitungen.
Betreiber wählen Better Auth bewusst, wenn die Self-Hosting-Vorteile die
zusätzliche Betriebsverantwortung und den aktuell kleineren
Account-Lifecycle-Funktionsumfang überwiegen. Eine bestehende
Clerk-Docker-Installation kann auch unmittelbar nach der Grundinstallation
gemäß
[`runbooks/switch-clerk-to-better-auth.md`](runbooks/switch-clerk-to-better-auth.md)
umgestellt werden.

| # | Variante | Wann sinnvoll |
|---|---|---|
| 1 | **Docker + Better Auth + PostgreSQL in Docker**, auf eigenem Server oder einer VM/EC2-Instanz | Bevorzugte Self-Hosting-Zielrichtung: hohe Datenhoheit, geringer Cloud-Anteil, dafür eigener Administrationsaufwand (Backups, Updates, Betrieb der DB). |
| 2 | **Docker + Better Auth + Neon** | Wenn die Datenbank nicht selbst betrieben werden soll: weniger eigener Datenbankbetrieb, dafür Cloud-Abhängigkeit und laufende Kosten für Neon. |
| 3 | **Docker + Clerk + Neon** | Wenn möglichst geringer Administrationsaufwand wichtiger ist als Datenhoheit und laufende Kosten: geringerer Administrationsaufwand, dafür stärkere Cloud-Abhängigkeit (Clerk + Neon) und laufende Kosten. |
| 4 | **Native/Bare-Metal-Installation** | Sonderfall für technisch versierte Betreiber mit bestehenden Vorgaben, nicht der empfohlene Standard. |

Die Datenbankwahl (PostgreSQL in Docker vs. Neon) und die Auth-Wahl
(Better Auth vs. Clerk) sind über `DATABASE_URL` bzw. `AUTH_MODE` unabhängig
voneinander konfigurierbar (siehe [`docker-setup.md`](docker-setup.md)
Abschnitt 4 und die Projektregeln in `AGENTS.md` des Repositorys); die Tabelle oben zeigt lediglich
die empfohlenen, sinnvollen Kombinationen.

## 4. Wichtiger Vorbehalt zu Better Auth

**Better Auth ist die bevorzugte Zielrichtung für Self-Hosting**, weil es volle
Datenhoheit ohne Cloud-Abhängigkeit und ohne laufende Lizenzkosten für die
Authentifizierung ermöglicht.

Clerk bietet demgegenüber den umfangreicheren verwalteten Account-Lifecycle
(insbesondere weniger Eigenaufwand für Recovery, Benutzer- und
Sitzungsverwaltung), Support durch einen spezialisierten Auth-Provider und
weniger eigenes Secret-/Credential-Handling. Dafür entstehen
Provider-Abhängigkeit, mögliche laufende Kosten und eine externe Verarbeitung
von Auth-Daten.

Das ist ausdrücklich **keine Aussage darüber, dass die aktuelle
Better-Auth-Implementierung in PAOLO bereits vollständig als produktive
Clerk-Alternative geeignet ist.** Diese Frage ist bewusst noch nicht
entschieden (siehe Offene Punkte unten und
[`containerization-roadmap.md`](containerization-roadmap.md) Phase C). Für
einen produktiven Self-Hosting-Betrieb ohne Clerk ist vor dem Einsatz zu
prüfen, ob der aktuelle Funktionsumfang (Login, Passwort-Reset,
Benutzerverwaltung, Sitzungsverwaltung) ausreicht.

Für Entwicklung/manuelle Tests steht zusätzlich `AUTH_MODE=file` zur
Verfügung (feste Testnutzer aus `config/dev-users.json`); dieser Modus ist
**ausschließlich für die lokale Entwicklung** vorgesehen und in Produktion
deaktiviert.

## 5. Datenbank

- **PostgreSQL in Docker** ist der Standard für Selbstbetrieb (einfache
  Bereitstellung, leicht zu sichern und umzuziehen), siehe
  [`docker-setup.md`](docker-setup.md).
- **Neon (Cloud)** eignet sich für Betreiber ohne eigenen Server oder ohne
  Interesse am eigenen Datenbankbetrieb (kein eigener Betrieb, aber laufende
  Kosten und Internet-/Anbieterabhängigkeit).
- **PostgreSQL nativ** (außerhalb von Docker) ist möglich bei bereits
  vorhandenem Datenbankserver, aber mit höherem Administrationsaufwand
  verbunden und nicht der empfohlene Standard.
- Das Migrationsverfahren ist in allen Fällen identisch und verbindlich in
  [`database-migrations.md`](database-migrations.md) beschrieben — unabhängig
  davon, ob die Ziel-DB lokal in Docker oder auf Neon läuft.

## 6. Ausdrücklich noch nicht entschieden

Die folgenden Punkte sind mit dieser Konsolidierung **bewusst offen
gelassen** und keine Aussage dieses Dokuments:

1. Ein konkreter verbindlicher Pre-Production-Workflow (wo/wie die vollständige
   Container-Konfiguration vor Produktivbetrieb getestet wird).
2. Ob Better Auth bereits technisch vollständig genug ist, um Clerk im
   produktiven Self-Hosting vollständig zu ersetzen (siehe Abschnitt 4).
3. Ein automatisches Release-/Update-Verfahren.
4. Konkrete Supply-Chain-Härtung für Node.js/npm — als offene Anforderung für
   ein künftiges Release-/Update-Konzept festgehalten, ohne bereits eine
   technische Lösung festzulegen.
5. Ein eventuell später vereinfachtes Installationsmodell für nicht technisch
   versierte Vereine/Flugschulen (heute richten sich
   [`docker-setup.md`](docker-setup.md) und
   [`docker-vm-deployment.md`](docker-vm-deployment.md) an technisch
   versierte Betreiber oder IT-Dienstleister).

---

*Konsolidiert 2026-07-28 aus Rainers PDF-Entscheidungsleitfaden und der
abgestimmten Zielrichtung zwischen Peter und Rainer. Ersetzt keine
Rechtsberatung und keine formale Sicherheitsprüfung.*
