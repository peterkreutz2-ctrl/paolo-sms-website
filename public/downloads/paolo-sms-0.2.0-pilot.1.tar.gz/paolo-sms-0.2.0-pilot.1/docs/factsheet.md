# PAOLO SMS – Factsheet

**Pilot Awareness and Occurrence Learning Online** ist ein webbasiertes Safety-Management-System für Gleitschirmflugschulen und Vereine.

## Drei Perspektiven

1. **Betreiber – Verein oder Flugschule:** 

    „Aus Hinweisen wird nachvollziehbare Sicherheitsarbeit: Meldungen erfassen, Risiken bewerten, Maßnahmen festlegen und ihre Umsetzung verfolgen – in einer eigenen Installation unter Ihrer Verantwortung.“

2. **Nutzer – meldende und intern mitarbeitende Personen:** 

    „Sicherheitsrelevante Beobachtungen einfach und auf Wunsch anonym melden. Die zuständigen Personen können den Vorgang strukturiert bearbeiten, damit aus Erfahrungen konkrete Verbesserungen werden.“

3. **DHV – mögliche Perspektive:** 
    
    „Wenn Vereine und Flugschulen Beobachtungen vor Ort systematisch bearbeiten, kann das die Sicherheitskultur im Flugsport stärken und Erkenntnisse für die übergreifende Sicherheitsarbeit liefern.“ Dies beschreibt einen möglichen Nutzen, keine abgestimmte Position des DHV. Eine PAOLO-Meldung ersetzt keine erforderliche Meldung an den DHV über FIDA.


## Betriebskonzepte

Jeder Verein oder jede Flugschule betreibt eine **eigene Installation** – selbst oder über einen beauftragten IT-Dienstleister. 

PAOLO SMS ist derzeit keine zentral betriebene Plattform und für **eine Organisation je Installation** ausgelegt. 

Der Betreiber verantwortet Hosting, Datenschutz, Zugänge, Updates und Backups. Das Projektteam nutzt eine separate Referenzinstallation ausschließlich mit Spiel- und Testdaten.

**Docker ist der bevorzugte Installationsweg.** Die Bausteine lassen sich nach Datenhoheit, Kosten und eigenem Betriebsaufwand wählen:

| Variante | Charakter |
|---|---|
| Docker + Better Auth + PostgreSQL in Docker | Bevorzugte Richtung für Selbstbetrieb und hohe Datenhoheit; eigener Aufwand für Datenbank, Backups und Updates. |
| Docker + Better Auth + Neon | Eigenes Login, verwaltete Cloud-Datenbank; weniger Datenbankbetrieb, dafür Anbieterabhängigkeit. |
| Docker + Clerk + Neon | Verwaltetes Login und verwaltete Datenbank; geringer eigener Aufwand, stärkere Anbieterabhängigkeit. |

Vor einem produktiven Einsatz von Better Auth ist zu prüfen, ob dessen aktueller Funktionsumfang für die eigene Benutzer- und Sitzungsverwaltung genügt.

**Dateien hochladen können nur berechtigte interne Rollen:** Bei Meldungen sind das Administrator, Safety Manager und Safety Assistant, bei SMS-Dokumenten Administrator und Safety Manager. 

Eine native Installation ist ein Sonderfall für technisch versierte Betreiber.

## Lizenz

**GPL-3.0-or-later** gilt für Programmcode, Dokumentation und mitgelieferte Dokumentvorlagen. Kommerzielle Nutzung und Betrieb sind erlaubt. Bei Weitergabe der Software gelten die GPL-Pflichten, insbesondere zu Lizenz und Quellcode. Name und Logo sind gemäß `NOTICE` vom Lizenzrecht ausgenommen und gesondert vorbehalten.

**Weiterführend:** [Betreiberentscheidung](installation-decision-guide.md) · [Produktionsgrenzen](production-readiness.md) · [DHV-Unfallmeldung](https://www.dhv.de/sicherheit/unfaelle/unfallmeldung/) · [Lizenztext](../LICENSE) · [Marken- und Logo-Vorbehalt](../NOTICE)
