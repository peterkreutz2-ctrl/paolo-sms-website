# Update aus dem Quellpaket

Diese Anleitung beschreibt das Update einer Installation im Paket-Layout
([`install-from-package.md`](install-from-package.md)) auf eine neue Paketversion,
ohne Zugang zum Git-Repository. Sie beschreibt auch, wie weit sich ein Update
zurücknehmen lässt und was für bestehende Git-Installationen gilt.

## Grundsätze

- **Konfiguration, Volumes und Anhänge bleiben erhalten.** Das Update ersetzt nur
  das Release-Verzeichnis. Konfiguration (`config/`) und Daten (Docker-Volumes des
  festen Compose-Projekts `paolo-sms`) liegen außerhalb.
- **Die Datenbankmigration läuft vor der Aktivierung des neuen Codes.** Die neue
  Anwendung startet erst, wenn der SQL-Satz des neuen Releases vollständig
  angewendet wurde. Der Satz läuft in einer Transaktion; schlägt er fehl, bleibt
  die Datenbank unverändert.
- **Vor jedem Update steht eine vollständige Sicherung** (Datenbank, Anhänge,
  Konfiguration; [`backup-restore.md`](backup-restore.md)). Ohne sie bricht das
  Skript ab, außer mit `--skip-backup`.
- **Ein Wechsel des Symlinks macht keine Migration rückgängig.** Siehe
  „Rücknahme und ihre Grenzen“.

## Vorbereitung

1. Release-Notes der neuen Version lesen: neue Migrationen, geänderte
   Konfiguration, Hinweis zur Rücknahme („kompatibel zurück bis Version …“).
2. Paket und `SHA256SUMS` aus der vertrauenswürdigen Quelle holen und prüfen:
   `sha256sum -c SHA256SUMS`. Danach entpacken:

   ```bash
   tar -xzf paolo-sms-<neu>.tar.gz -C /opt/paolo-sms/releases
   ```

3. Prüfen, ob in der Konfigurationsvorlage des neuen Releases Variablen
   hinzugekommen sind: `diff /opt/paolo-sms/current/.env.docker.example
   /opt/paolo-sms/releases/paolo-sms-<neu>/.env.docker.example`. Neue Pflichtwerte
   in `/opt/paolo-sms/config/.env.docker.local` ergänzen.
4. Ein Wartungsfenster ankündigen. Die Anwendung ist während der Migration kurz
   nicht erreichbar.

## Ablauf

Das Skript des **neuen** Releases führt das Update aus. Zuerst ein Trockenlauf:

```bash
sh /opt/paolo-sms/releases/paolo-sms-<neu>/scripts/deploy/paolo-update.sh --dry-run
sh /opt/paolo-sms/releases/paolo-sms-<neu>/scripts/deploy/paolo-update.sh
```

Mit Nginx-Overlay `--prod` ergänzen; `--yes` überspringt die Rückfrage. Das Skript:

1. prüft beide Releases gegen `FILES.sha256`, lehnt dieselbe Version und ein Paket
   mit weniger Migrationen als die Installation ab (das wäre ein Downgrade) und
   zeigt, ob das Schema sich ändert;
2. verlangt, dass die laufende Installation gesund ist;
3. erstellt die vollständige Sicherung mit dem **bisherigen** Release;
4. markiert das laufende Image als Rückfall-Image `paolo-sms:rollback-<alt>`;
5. baut das neue Image, während die alte Anwendung weiterläuft;
6. hält die alte Anwendung an und wendet den SQL-Satz mit dem **neuen** Image an;
7. stellt `current` um, startet die neue Anwendung neu (mit `--prod` auch Nginx)
   und wartet auf `/api/health`;
8. schreibt `config/update-history.log`.

Fehlerfälle:

| Fehler | Zustand danach |
|---|---|
| Sicherung oder Image-Build schlägt fehl | nichts verändert, alte Anwendung läuft weiter |
| Migration schlägt fehl | Datenbank unverändert (eine Transaktion); alte Anwendung wird wieder gestartet, `current` unverändert |
| Neue Anwendung wird nicht gesund, **kein** Schemawechsel | automatische Rückstellung auf das alte Release |
| Neue Anwendung wird nicht gesund, **mit** Schemawechsel | keine automatische Rückstellung (Exit-Code 2), siehe unten |

Nach dem Update die Funktionsprüfung aus
[`docker-vm-deployment.md`](docker-vm-deployment.md), Abschnitt 5, durchführen und
die Funktionen der Release-Notes prüfen. Das alte Release-Verzeichnis und das
Rückfall-Image bis zur Abnahme behalten; danach alte Verzeichnisse unter
`releases/` und ungenutzte Images (`docker image prune`) bewusst entfernen.

## Rücknahme und ihre Grenzen

Ein Update besteht aus zwei Teilen mit unterschiedlicher Umkehrbarkeit:

| Teil | Zurücknehmbar? |
|---|---|
| Anwendungscode (Release, Image) | ja: `current` zurückstellen, Image neu starten |
| Datenbankschema (Migrationen) | **nein**: Migrationen sind additiv und bleiben bestehen; es gibt keine Down-Migrationen |

Daraus folgt:

- **Ohne Schemawechsel** (gleiche letzte Migration) ist die Rückstellung des Codes
  unkritisch und geschieht bei einem Startfehler automatisch.
- **Mit Schemawechsel** läuft der alte Code gegen das neuere Schema. Das ist nur
  zulässig, wenn die Kompatibilität nachgewiesen ist, etwa bei rein additiven
  Spalten oder Tabellen, die der alte Code nicht benötigt. Die Release-Notes müssen
  dazu eine ausdrückliche Aussage enthalten. Dann:

  ```bash
  sh /opt/paolo-sms/releases/paolo-sms-<alt>/scripts/deploy/paolo-rollback.sh --schema-compatible
  ```

  Ohne `--schema-compatible` lehnt das Skript die Rückstellung ab.
- **Ist die Kompatibilität nicht nachgewiesen** oder wurden Daten durch die
  Migration verändert, bleibt nur die **Wiederherstellung von Datenbank und
  Anhängen aus der Sicherung vor dem Update**
  ([`backup-restore.md`](backup-restore.md)). Änderungen seit dem Update gehen
  dabei verloren.

Eine Rückstellung erstellt ihrerseits zuerst eine Sicherung und protokolliert sich
in `config/update-history.log`.

## Bestehende Git-Installationen

- **Weiterbetrieb mit Git** ist weiterhin möglich:
  [`runbooks/production-docker-update.md`](runbooks/production-docker-update.md).
  Ein Wechsel der Betriebsart ist nicht erforderlich.
- **Umstieg auf das Paket-Layout** (einmalig, mit Wartungsfenster) setzt voraus,
  dass der **Compose-Projektname erhalten bleibt**; sonst lägen Datenbank und
  Anhänge in Volumes des alten Namens, und die neue Installation fände sie nicht.
  Der Name ist der Verzeichnisname des Git-Checkouts (meist `paolo-sms`) und an den
  Volume-Namen erkennbar (`docker volume ls`: `<name>_paolo-db-data`).

  1. Vollständige Sicherung nach Abschnitt „Sicherung“ in
     [`backup-restore.md`](backup-restore.md) bzw. dem Git-Runbook anlegen.
  2. Neue Betreiberwurzel anlegen, **nicht** im Git-Checkout (dort liegt bereits
     ein `config/`): `mkdir -p /opt/paolo/{config,releases}`, `PAOLO_HOME` entspricht
     dann `/opt/paolo`.
  3. Konfiguration übernehmen: `.env.docker.local` des Checkouts nach
     `/opt/paolo/config/` kopieren; bei aktivem Nginx das Verzeichnis
     `deploy/nginx/conf.d` des Checkouts (mit den umbenannten TLS-Dateien) nach
     `/opt/paolo/config/nginx/conf.d` kopieren.
  4. Den bisherigen Projektnamen festhalten:
     `echo <name> > /opt/paolo/config/compose-project-name`.
  5. Paket nach `/opt/paolo/releases` entpacken, `current` setzen und das neue
     Release **wie ein Update von Hand** aktivieren: Image bauen, Anwendung anhalten,
     `scripts/migrate.sh` ausführen, `paolo-compose.sh up -d --force-recreate app`
     (mit `--prod`: auch Nginx neu starten). Der Datenbankcontainer wird dabei
     möglicherweise neu erstellt; seine Daten liegen im unveränderten Volume.
  6. Prüfen, dass `docker volume ls` keine neuen, leeren Volumes zeigt und die
     Daten vorhanden sind.
  7. Erst danach das alte Git-Verzeichnis stilllegen.

  Das Skript `paolo-update.sh` setzt das Paket-Layout voraus und ersetzt diesen
  einmaligen Umstieg nicht.
- **Dirty-Checkout:** Wer TLS-Dateien im Checkout umbenannt hat, kopiert den
  tatsächlichen Zustand (siehe Schritt 3), nicht die Vorlagen.

## Nachgewiesener Stand

Die Verfahren dieses Dokuments wurden mit den Skripten und Paketen auf einem
Linux-Betreiberhost erprobt (Ubuntu 24.04 mit `dash`, Docker-CLI und Compose-Plugin
gegen einen Docker-Daemon; Better Auth). Die Szenarien liegen im Entwicklungsrepository
unter `tests/release/linux-host/` und gehören nicht zum Paket:

- **Update** von Paket 1 auf ein Paket mit zusätzlicher Migration: Trockenlauf ohne
  Änderung, Sicherung, Migration vor Aktivierung, `current` umgestellt, Anwendung
  gesund; Volumes, Daten, Anhangsdateien (SHA-256), Anmeldung und Downloads unverändert.
- **Defekte Migration:** Update bricht ab, Datenbank unverändert, alte Anwendung läuft
  weiter, `current` unverändert.
- **Rückstellung:** ohne `--schema-compatible` bei Schemaänderung abgelehnt, mit dem
  Nachweis ausgeführt; danach erneutes Update (SQL-Satz wiederholbar).
- **Sicherung, Verlust aller Volumes, Wiederherstellung** mit `paolo-backup.sh` auf einer
  neuen Installation: Datenbestand, Anhänge, Anmeldung und Downloads identisch.
- **Nginx/TLS:** Produktionsoverlay, HTTP-Phase mit ACME-Webroot, HTTPS-Vorlage mit einem
  selbst ausgestellten Zertifikat, Anmeldung über HTTPS, Update mit `--prod`,
  TLS-Konfiguration bleibt erhalten, Certbot-Erneuerung im Paket-Layout (Cron-Zeile).
- **Umstieg einer Git-Installation** auf das Paket-Layout mit erhaltenem Projektnamen:
  dieselben Volumes, Daten unverändert, danach Update mit `paolo-update.sh`.

**Nicht nachgewiesen:**

- Ausstellung und Erneuerung eines Zertifikats bei Let's Encrypt (benötigt eine
  öffentliche Domain).
- Betrieb mit Clerk als Anmeldeverfahren (benötigt ein externes Clerk-Projekt).
- Ein physischer oder virtueller Server mit eigenem Linux-Kernel; getestet wurde die
  Betreiberseite (Skripte, Werkzeuge) gegen einen Docker-Daemon.
- Wechsel zwischen echten, veröffentlichten Paketversionen; erprobt wurden das
  Paket 1 und daraus abgeleitete Testpakete mit additiver und mit defekter Migration.
- Große Datenmengen und Laufzeiten der Migration.
