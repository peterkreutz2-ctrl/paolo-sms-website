# AWS EC2 mit Docker

AWS EC2 ist keine eigene PAOLO-Betriebsart, sondern ein möglicher
Infrastrukturprovider für den generischen Docker-Betrieb auf einer
Ubuntu-VM.

Die Einrichtung besteht aus zwei getrennten Schritten:

1. AWS-Konto, IAM-Operator, EC2-Instanz, EBS, Security Group, Elastic IP, DNS
   und SSH gemäß
   [`runbooks/aws-account-and-ec2-provisioning.md`](runbooks/aws-account-and-ec2-provisioning.md)
   bereitstellen.
2. Nach erfolgreicher SSH-Übergabe PAOLO, PostgreSQL, Storage, Nginx, TLS und
   Backups gemäß
   [`docker-vm-deployment.md`](docker-vm-deployment.md)
   installieren.

Für spätere Updates gilt
[`runbooks/production-docker-update.md`](runbooks/production-docker-update.md).
Eine optionale Umstellung der Standardinstallation von Clerk auf Better Auth
steht in
[`runbooks/switch-clerk-to-better-auth.md`](runbooks/switch-clerk-to-better-auth.md).

AWS-spezifische Unterschiede enden grundsätzlich an der Host-Übergabe. Die
Docker-Images, Compose-Services, Datenbankmigrationen, Auth-Konfiguration,
Nginx-/Certbot-Schritte, Backups und Anwendungstests sind auf EC2 und einer
anderen geeigneten Ubuntu-VM identisch.
