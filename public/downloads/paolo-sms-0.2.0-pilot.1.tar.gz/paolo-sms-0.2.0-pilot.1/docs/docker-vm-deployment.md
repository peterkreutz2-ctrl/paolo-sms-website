# Docker-Deployment auf einer Ubuntu-VM

Diese Anleitung beschreibt einen Ein-Server-Betrieb von PAOLO SMS auf einer
Ubuntu-VM oder einem vergleichbaren eigenen Server mit Docker Compose, lokaler
PostgreSQL-Datenbank, lokalem Attachment-Storage und Nginx als Reverse Proxy.
Der Ablauf ist unabhängig vom Infrastrukturprovider, sobald ein geeigneter
Ubuntu-Host per SSH erreichbar ist.

Für AWS zuerst die Infrastruktur gemäß
[`runbooks/aws-account-and-ec2-provisioning.md`](runbooks/aws-account-and-ec2-provisioning.md)
bereitstellen. Andere Provider müssen dieselben Übergabekriterien erfüllen:
ausreichende Ressourcen, persistenter verschlüsselter Datenträger, stabile
öffentliche Adresse/DNS und ausschließlich die erforderlichen eingehenden
Ports.

Die Authentifizierung ist über `AUTH_MODE` wählbar (`clerk` oder
`betterauth`). **Clerk ist der Standard der Installation** und bietet den
umfangreicheren verwalteten Funktionsumfang. Better Auth ist eine optionale
self-hosted Alternative für Betreiber, die externe Kosten und
Provider-Abhängigkeit gegen mehr eigenen Betriebsaufwand und einen derzeit
kleineren Account-Lifecycle-Funktionsumfang abwägen. Welche Kombination aus
Installationsart, Auth-Provider und Datenbank sinnvoll ist, siehe
[`installation-decision-guide.md`](installation-decision-guide.md).

## Authentifizierung vorab festlegen

- **Clerk (Standard):** verwaltete Authentifizierung und Benutzerverwaltung mit
  geringerem eigenen Betriebsaufwand und umfangreicherem Account-Lifecycle;
  dafür externer Anbieter, mögliche laufende Kosten und geringere lokale
  Datenhoheit.
- **Better Auth (optionaler Self-Hosting-Pfad):** Benutzer, Zugangsdaten und
  Sitzungen liegen in der selbst betriebenen PostgreSQL-Datenbank. Dafür trägt
  der Betreiber Verantwortung für Secrets, Zugangsdaten, Recovery,
  Benutzer-Lifecycle, Sitzungen, Backups und Sicherheitsupdates.

Vor einem produktiven Einsatz von Better Auth muss der Betreiber prüfen, ob der
aktuelle Funktionsumfang für seine Anforderungen ausreicht. Insbesondere
Passwort-Reset sowie Benutzer- und Sitzungsverwaltung sind laut
[`installation-decision-guide.md`, Abschnitt 4](installation-decision-guide.md#4-wichtiger-vorbehalt-zu-better-auth)
noch kein abschließend freigegebener vollständiger Ersatz für Clerk.
Eine bestehende Clerk-Installation kann auch unmittelbar nach der
Grundinstallation kontrolliert umgestellt werden; siehe
[`runbooks/switch-clerk-to-better-auth.md`](runbooks/switch-clerk-to-better-auth.md).
`AUTH_MODE=file` ist keine Produktionsoption und wird bei
`NODE_ENV=production` von der Anwendung abgelehnt.

## Zielarchitektur

- Ubuntu 24.04 LTS, stabile öffentliche IP-Adresse und DNS-`A`-Record für die
  PAOLO-Domain.
- Provider-Firewall/Security Group: `80/tcp` und `443/tcp` aus dem Internet;
  `22/tcp` nur von der Operator-IP.
- Keine öffentliche Datenbankfreigabe. Der `db`-Service ist nur im Docker-Netz
  erreichbar.
- Nginx veröffentlicht `80`/`443`; die Next.js-App ist nur intern unter
  `app:3000` erreichbar.
- Lokale Volumes für PostgreSQL, Attachments, Backups, ACME-Webroot und
  Let's-Encrypt-Zertifikate.

## 1. Ubuntu-Host vorbereiten

Optionales Bootstrap-Skript auf Ubuntu 24.04:

Auf dem lokalen Rechner im ausgecheckten Repository zuerst das Skript auf die
noch leere Instanz kopieren:

```bash
scp scripts/deploy/ubuntu-docker-bootstrap.sh paolo-sms-vm:/tmp/ubuntu-docker-bootstrap.sh
```

`paolo-sms-vm` ist dabei ein Beispiel für einen lokalen SSH-Host-Alias.
Alternativ kann `ubuntu@<server-ip>` verwendet werden. Das Repository erzwingt
für Shell-Skripte LF-Zeilenenden. Bei einer bereits mit Windows-Zeilenenden
übertragenen Datei kann die Instanz sie einmalig normalisieren. Danach auf der
Instanz:

```bash
sed -i 's/\r$//' /tmp/ubuntu-docker-bootstrap.sh
sudo bash /tmp/ubuntu-docker-bootstrap.sh
exit
```

Das Skript installiert Docker Engine aus Dockers offiziellem apt-Repository,
das Compose-Plugin, Git und Cron, aktiviert Docker und Cron und legt
`/opt/paolo-sms` für den aufrufenden sudo-Benutzer an. Nach dem Skript ist eine
neue SSH-Anmeldung erforderlich, damit die Docker-Gruppenzugehörigkeit wirksam
wird.

## 2. Release bereitstellen

Ohne Zugang zum Git-Repository wird stattdessen das versionierte Quellpaket
verwendet; Ablauf, Verzeichnisaufbau und der Compose-Aufruf stehen in
[`install-from-package.md`](install-from-package.md). Die folgenden Befehle
setzen einen Git-Checkout in `/opt/paolo-sms` voraus.

```bash
cd /opt/paolo-sms
git clone <repo-url> .
cp .env.docker.example .env.docker.local
```

Trage in `.env.docker.local` Produktionswerte ein:

```env
APP_BASE_URL=https://paolo.example.org
DATABASE_URL=postgres://paolo:<strong-password>@db:5432/paolo?sslmode=disable
POSTGRES_DB=paolo
POSTGRES_USER=paolo
POSTGRES_PASSWORD=<strong-password>
STORAGE_PROVIDER=local
LOCAL_STORAGE_DIR=/app/storage
AUTH_MODE=clerk
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=...
CLERK_SECRET_KEY=...
NEXT_PUBLIC_CLERK_SIGN_IN_URL=/sign-in
NEXT_PUBLIC_CLERK_SIGN_UP_URL=/sign-up
NEXT_PUBLIC_CLERK_SIGN_IN_FALLBACK_REDIRECT_URL=/dashboard
NEXT_PUBLIC_CLERK_SIGN_UP_FALLBACK_REDIRECT_URL=/dashboard
BACKUP_AGE_RECIPIENTS=age1...,age1...
BACKUP_CRON_SECRET=<mindestens-32-zufällige-zeichen>
BACKUP_CRON_MIN_INTERVAL_MINUTES=1440
BACKUP_CRON_MAX_RUNTIME_MINUTES=120
BACKUP_RETENTION_ENABLED=true
BACKUP_RETENTION_DAILY_DAYS=14
BACKUP_RETENTION_WEEKLY_WEEKS=8
BACKUP_RETENTION_MONTHLY_MONTHS=12
```

### Option: Better Auth

Für Better Auth den Clerk-Block durch folgende Werte ersetzen:

```env
AUTH_MODE=betterauth
BETTER_AUTH_SECRET=<mindestens-32-zufällige-zeichen>
BETTER_AUTH_URL=https://paolo.example.org
```

`BETTER_AUTH_SECRET` kann mit `openssl rand -hex 32` erzeugt werden; eine
Rotation beendet bestehende Sitzungen. `BETTER_AUTH_URL` und `APP_BASE_URL`
müssen exakt dieselbe öffentliche HTTPS-Basis-URL enthalten. Für eine spätere
Umstellung einer bereits eingerichteten Clerk-Installation gilt der
provider-spezifische Runbook-Ablauf.

Im Clerk-Modus müssen Produktionsdomain und Redirects im Clerk-Dashboard zu
`APP_BASE_URL` passen. Nur Production-Keys des vorgesehenen Clerk-Projekts
verwenden.

`BACKUP_CRON_SECRET` kann auf der Instanz mit `openssl rand -hex 32` erzeugt
werden. `BACKUP_AGE_RECIPIENTS` enthält dagegen nur öffentliche age-Empfänger.
Die zugehörigen privaten Identitäten müssen vorher auf vertrauenswürdigen
Administrator-Geräten erzeugt und getrennt vom Server verwahrt werden. Details
und Restore-Ablauf: [`backup-restore.md`](backup-restore.md).

## 3. Start und frische DB initialisieren

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml build app || exit 1
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d db || exit 1
docker compose -f docker-compose.yml -f docker-compose.prod.yml ps
```

Warten, bis `db` als `healthy` angezeigt wird. `DATABASE_URL` muss auf diese
freigegebene DB zeigen und eine DB-/Tabelleneigentümerrolle verwenden. Dann den
SQL-Satz direkt aus dem eben gebauten App-Image anwenden:

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml \
  run --rm --no-deps -T app sh /app/scripts/migrate.sh || exit 1
```

Der einmalige Container startet keinen Webserver; das PostgreSQL-Image bleibt
unverändert. Bei Fehlern nicht mit Bootstrap oder App-Start fortfahren.
Der vollständige SQL-Lauf ist auch auf bestehenden Datenbanken wiederholbar.
Bei Updates vorher ein vollständiges Backup anlegen und Schreibzugriffe für das
Wartungsfenster pausieren; siehe [Operator-Runbook](runbooks/production-docker-update.md).
Kein `drizzle-kit migrate`, `generate` oder `push`.

Danach Organisation und ersten globalen Administrator mit dem Fresh-Install-
Bootstrap aus dem gerade gebauten App-Image anlegen:

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml \
  run --rm --no-deps app npm run setup:initialize
```

Bei Better Auth fragt er E-Mail, Anzeigename und Passwort verdeckt ab. Bei
Clerk muss das Konto vorher im richtigen Clerk-Projekt angelegt sein; E-Mail
oder User-ID und Kontostatus werden über Clerk verifiziert. Der genaue Ablauf,
die Fresh-only-Grenze und der non-interaktive Modus stehen in
[`docker-setup.md`, Abschnitt 6.2](docker-setup.md#62-bootstrap-nach-fresh-init-organisation--erster-admin).

## 4. Nginx und TLS

Initial startet Nginx mit `deploy/nginx/conf.d/paolo-http.conf`.
`00-rate-limits.conf` definiert die gemeinsamen Zonen im HTTP-Kontext;
`snippets/app.conf` enthält die gemeinsame App-Policy für HTTP und HTTPS
(Formular 256 KiB/10 POSTs pro Minute, Downloads 60 Abrufe pro Minute mit
Burst 20). Das gesamte Verzeichnis einschließlich `snippets/` bleibt
gemountet. Beim TLS-Wechsel nur die beiden Serverdateien umbenennen, nicht
die gemeinsame Zonen- oder Snippet-Datei. Details und Stundenkontingente:
[`runbooks/public-report-rate-limit.md`](runbooks/public-report-rate-limit.md).

Damit ist Port 80 für ACME-Challenges und einen ersten HTTP-Smoke-Test nutzbar:

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d app nginx
curl http://paolo.example.org/api/health
```

Zertifikat per Certbot-Container holen:

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml --profile certbot run --rm certbot \
  certonly --webroot --webroot-path /var/www/certbot \
  --email admin@example.org --agree-tos --no-eff-email \
  --cert-name paolo -d paolo.example.org
```

Nach erfolgreicher Ausstellung die HTTPS-Vorlage aktivieren und HTTP-only
deaktivieren:

```bash
mv deploy/nginx/conf.d/paolo-http.conf deploy/nginx/conf.d/paolo-http.conf.disabled
mv deploy/nginx/conf.d/paolo-https.conf.disabled deploy/nginx/conf.d/paolo-https.conf
docker compose -f docker-compose.yml -f docker-compose.prod.yml exec -T nginx nginx -t
docker compose -f docker-compose.yml -f docker-compose.prod.yml restart nginx
```

Renewal:

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml --profile certbot run --rm certbot \
  renew --webroot --webroot-path /var/www/certbot
docker compose -f docker-compose.yml -f docker-compose.prod.yml restart nginx
```

Nach erfolgreicher Erstausstellung installiert ein Hilfsskript eine zweimal
tägliche Renewal-Prüfung mit anschließendem graceful Nginx-Reload:

```bash
sudo bash scripts/deploy/configure-certbot-renewal.sh
docker compose -f docker-compose.yml -f docker-compose.prod.yml --profile certbot run --rm certbot \
  renew --dry-run
```

Das Skript erzeugt idempotent `/etc/cron.d/paolo-certbot`. Eine abweichende
Prüfzeit kann über `PAOLO_CERTBOT_CRON_SCHEDULE` gesetzt werden. Certbot erneuert
Zertifikate nur innerhalb seines Erneuerungsfensters; die häufigere Prüfung
stellt daher nicht bei jedem Lauf ein neues Zertifikat aus.

## 5. Smoke Tests

- `curl http://<domain>` leitet nach aktivem TLS auf HTTPS um.
- `curl https://<domain>/api/health` liefert `{"status":"ok"}`.
- `/`, `/submit-report`, `/sign-in` laden.
- **Better Auth:** Anmeldung mit dem Bootstrap-Admin funktioniert;
  `/sign-up` erlaubt keine öffentliche Selbstregistrierung.
- **Clerk:** Anmeldung mit dem im Clerk-Projekt angelegten und in PAOLO
  zugeordneten Admin funktioniert.
- Nach dem jeweiligen Login laden `/dashboard`, Benutzerverwaltung, eine
  Meldungs-Detailseite und Attachment Upload/Download.
- Abmelden beendet die Sitzung; ein anschließender direkter Aufruf von
  `/dashboard` verlangt erneut eine Anmeldung.
- `docker compose -f docker-compose.yml -f docker-compose.prod.yml ps` zeigt
  gesunde Services.

## 6. Backups

Backups bestehen aus zwei Teilen:

- verschlüsseltes PAOLO-DB-Backup über die bestehende Backup-Funktion
  (`BACKUP_ENGINE=pg_dump`, `BACKUP_AGE_RECIPIENTS` gesetzt); das persistente
  Compose-Volume liegt im App-Container unter `/app/backups`,
- separates Archiv des lokalen Attachment-Volumes.

Beide Sicherungen gehören zeitlich zusammen und müssen verschlüsselt
off-instance abgelegt werden. Restore-Tests erfolgen auf einer separaten
Wegwerf-Instanz oder lokalen VM, nicht auf Production.

### 6.1 Tägliches DB-Backup einrichten

Nachdem HTTPS aktiv und die App gesund ist, installiert das Hilfsskript einen
System-Cron um täglich 03:15 Uhr. Es liest URL und Secret direkt aus
`.env.docker.local`; das Secret erscheint dadurch weder im Befehl noch in der
Crontab:

```bash
sudo bash scripts/deploy/configure-backup-cron.sh
sudo /usr/bin/curl --config /etc/paolo/backup-cron.curl
```

Der erste manuelle Aufruf muss erfolgreich sein. Danach prüfen:

```bash
sudo journalctl -u cron --since today
docker compose -f docker-compose.yml -f docker-compose.prod.yml logs app
```

Eine abweichende Cron-Zeit kann bei der Installation gesetzt werden, zum
Beispiel sonntags um 03:15 Uhr:

```bash
sudo PAOLO_BACKUP_CRON_SCHEDULE='15 3 * * 0' \
  bash scripts/deploy/configure-backup-cron.sh
```

Das Skript erzeugt `/etc/paolo/backup-cron.curl` mit Rechten `0600` und
`/etc/cron.d/paolo-backup`. Ein erneuter Aufruf aktualisiert beide Dateien
idempotent. Bei Rotation von `BACKUP_CRON_SECRET` zuerst
`.env.docker.local` ändern, den App-Container neu erstellen und anschließend
das Skript erneut ausführen:

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d --force-recreate app
docker compose -f docker-compose.yml -f docker-compose.prod.yml restart nginx
sudo bash scripts/deploy/configure-backup-cron.sh
```

Der Nginx-Neustart ist erforderlich, weil ein neu erstellter App-Container eine
andere interne Docker-IP erhalten kann und der bereits laufende Nginx-Prozess
die zuvor aufgelöste `app`-Adresse sonst bis zum Reload weiterverwendet. Ohne
Reload kann vorübergehend `502 Bad Gateway` erscheinen.

Die Standard-Retention behält tägliche, wöchentliche und monatliche Generationen
gemäß den Env-Werten. Sie bereinigt nur das lokale DB-Backup-Volume. Die
regelmäßige verschlüsselte Off-Instance-Kopie von `.age`-Archiv und zugehörigem
Manifest benötigt ein konkretes Ziel (zum Beispiel S3) und ist noch nicht
automatisiert.

### 6.2 Attachments sichern

Der HTTP-Cron sichert ausschließlich PostgreSQL. Datenbank, Anhänge (Volume
`paolo-storage-data`) und Konfiguration gemeinsam sichert und stellt das Verfahren
in [`backup-restore.md`, „Vollständige Sicherung einer Docker-Installation“](backup-restore.md#vollständige-sicherung-einer-docker-installation)
wieder her (`scripts/deploy/paolo-backup.sh` im Paket-Layout; die Volume-Namen
hängen vom Compose-Projektnamen ab). Die manuellen Volume-Backup- und
Restore-Schritte aus
[`docker-setup.md`, Abschnitt 10](docker-setup.md#10-backups-und-restore) bleiben als
Alternative gültig.

Nach der Einrichtung mindestens prüfen:

- Unter `/dashboard/admin/backup` ist das geplante DB-Backup sichtbar.
- Archiv (`.age`) und Manifest sind gemeinsam vorhanden.
- Ein externer Kopierlauf umfasst beide Dateien.
- Ein dokumentierter Restore-Test funktioniert ohne private Identität auf dem
  VM-Host.

## 7. Updates und Rollback

Ohne Git (Paket-Layout): [`update-from-package.md`](update-from-package.md) mit
`paolo-update.sh`, Rücknahmegrenzen und dem Umstieg bestehender Git-Installationen.
Für Git-Installationen gilt:

Der verbindliche, schrittweise Ablauf für Docker-Produktionsupdates,
einschließlich Backup, vollständigem SQL-Replay, TLS-Dateizustand,
Verifikation und Rollback, steht in
[`runbooks/production-docker-update.md`](runbooks/production-docker-update.md).
Die Migrationsregeln bleiben verbindlich in
[`database-migrations.md`](database-migrations.md), Backup und Restore in
[`backup-restore.md`](backup-restore.md).
