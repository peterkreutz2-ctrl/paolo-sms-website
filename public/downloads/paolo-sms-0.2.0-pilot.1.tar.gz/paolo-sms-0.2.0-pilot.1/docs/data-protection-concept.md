# Datenschutzkonzept für PAOLO SMS

> **Wichtiger Hinweis:** Dieses Dokument ist **keine Rechtsberatung** und ersetzt
> keine Prüfung durch den DHV, betriebliche/externe Datenschutzbeauftragte oder
> Juristinnen und Juristen. Es strukturiert technische und organisatorische
> Anforderungen sowie offene rechtliche Klärungspunkte. Alle mit **[offen]**
> markierten Punkte sind vor einem Pilotbetrieb fachlich und rechtlich zu klären.

---

## 1. Zweck des Dokuments

- Das Dokument dient als **technische und organisatorische Leitlinie** für den
  Datenschutz in PAOLO SMS.
- Es dokumentiert, welche personenbezogenen Daten anfallen können, zu welchen
  Zwecken sie verarbeitet werden und welche technischen und organisatorischen
  Maßnahmen (TOM) daraus abzuleiten sind.
- Es ist **keine Rechtsberatung** und trifft keine abschließenden rechtlichen
  Aussagen.
- Es bildet die **Grundlage für eine spätere Prüfung** durch den DHV,
  Datenschutzbeauftragte sowie ggf. juristische Beratung.
- PAOLO SMS ist ein webbasiertes Safety-Management-System für
  Gleitschirmflugschulen, Vereine und perspektivisch den DHV-Kontext. Es erfasst
  sicherheitsrelevante Meldungen (Beobachtungen, Beinahe-Ereignisse, Vorfälle,
  Unfälle), bei denen personenbezogene Daten vorkommen können.

---

## 2. Datenkategorien

In PAOLO SMS können folgende Datenkategorien mit möglichem Personenbezug
verarbeitet werden:

- **Meldedaten:** Kerninhalt einer sicherheitsrelevanten Meldung (Typ,
  Beschreibung, Status, Priorität, Zeitpunkt). Der Freitext kann personenbezogene
  Angaben enthalten.
- **Freiwillige Melderinformationen:** Name, Kontakt (z. B. E-Mail) der meldenden
  Person, sofern freiwillig angegeben. Meldungen können anonym erfolgen.
- **Betroffene/beteiligte Personen in Freitexten:** Namen, Rollen oder sonstige
  identifizierende Angaben zu Dritten, die in Beschreibungen oder Notizen genannt
  werden.
- **Anhänge:** Hochgeladene Dateien (z. B. Fotos, Dokumente), die
  personenbezogene Inhalte enthalten können. Dateibytes werden außerhalb der
  Datenbank gespeichert (Vercel Blob).
- **Bearbeitungsnotizen/Nachträge:** Interne Notizen und Ergänzungen zu einer
  Meldung, die Personenbezug enthalten können.
- **Maßnahmen:** Follow-up-Sicherheitsmaßnahmen inkl. Freitextfeld für
  Verantwortlichkeit (`assignedToText`), das Namen enthalten kann.
- **Sicherheitsbesprechungen:** Vorbereitung/Dokumentation von Besprechungen,
  soweit sie auf konkrete Meldungen und Personen Bezug nehmen. *(Perspektivisch;
  Umfang [offen].)*
- **Benutzerkonten/Rollen:** Interne Nutzerinnen und Nutzer (Authentifizierung
  über Clerk), zugeordnete App-Rollen (`admin`, `safety_manager`, weitere).
- **Audit-Log:** Einträge zu Bearbeitenden und durchgeführten Aktionen
  *(geplant/teilweise; siehe bekannte Lücken)*.
- **Technische Betriebsdaten:** Soweit in der App relevant, z. B. Zeitstempel,
  technische IDs, ggf. serverseitige Protokolldaten des Betreibers/Hosters.
  Der konkrete Umfang der Server-/Zugriffsprotokolle hängt vom jeweiligen
  Anbieter und den eingesetzten Diensten ab. **[offen]**
- **Missbrauchsschutz des öffentlichen Meldeformulars:** PAOLO bildet mit einem
  installationsspezifischen Geheimnis einen pseudonymisierten Identifier aus
  der normalisierten IP-Adresse; die rohe IP-Adresse wird nicht in der
  Rate-Limit-Tabelle gespeichert. Die Datensätze sind standardmäßig nach einem
  Tag zur Löschung vorgesehen und werden beim nächsten erfolgreichen
  Meldevorgang entfernt. Ohne weitere Meldung können sie länger gespeichert
  bleiben; eine garantierte Obergrenze erfordert den im Betreiber-Runbook
  beschriebenen manuellen Cleanup. Als Rechtsgrundlage kommt Art. 6 Abs. 1
  lit. f DSGVO in Betracht; das berechtigte Interesse liegt im Schutz des
  Formulars vor missbräuchlicher Nutzung. Betreiber müssen diese Einordnung
  und die konkrete Aufbewahrung für ihre Installation prüfen.
- **Einwilligungsnachweis:** Ist die Datenschutz-Einwilligung im Meldeformular
  eingeschaltet, speichert PAOLO zu jeder so eingereichten Meldung den
  Serverzeitpunkt, den angezeigten Einwilligungstext und die zu diesem
  Zeitpunkt gültige Datenschutzerklärung (Abschnitt 11b). Der Nachweis enthält
  keine zusätzlichen Angaben zur Person und keine IP-Adresse.

---

## 3. Rollen und Verantwortlichkeiten

- **Verantwortlicher nach DSGVO (Art. 4 Nr. 7):** **[offen]** – zu klären, ob dies
  die einzelne Flugschule/der Verein, der DHV oder der Betreiber von PAOLO ist.
  Ggf. liegt eine gemeinsame Verantwortlichkeit (Art. 26 DSGVO) vor.
- **Betreiber/Hosting:** **[offen]** – wer die Anwendung produktiv betreibt und
  wo (Region, Anbieter). Aktuell technisch beteiligt: Clerk (Auth), Vercel
  (Hosting/Blob), Neon (PostgreSQL).
- **Auftragsverarbeitung (Art. 28 DSGVO):** **Wahrscheinlich erforderlich**,
  sofern externe Hoster/Dienstleister eingesetzt werden. Für jeden Dienstleister
  (Clerk, Vercel, Neon, Blob-Storage) ist ein Auftragsverarbeitungsvertrag (AVV)
  zu prüfen bzw. abzuschließen. **[offen]**
- **Nutzerrollen in PAOLO (organisatorisch/intern):** vier Rollen —
  Administrator, Safety Manager, Safety Assistant und Benutzer. Zweck und Grenzen je
  Rolle stehen in [`role-responsibilities.md`](role-responsibilities.md), der
  durchgesetzte Umfang in [`permission-matrix.md`](permission-matrix.md).
  Der Umfang der Rolle Safety Assistant ist **entschieden** (Ü1 zu Issue #50):
  Sie sieht den sicherheitsfachlichen Inhalt einer Meldung, aber **weder die
  strukturierte Melderidentität noch die internen Notizen** — beide werden für
  diese Rolle serverseitig nicht geladen. Freitexte und Anhänge sind davon
  nicht erfasst. Begründung und Grenzen in
  [`role-responsibilities.md`](role-responsibilities.md) Abschnitt 3. Offen
  bleiben dort Ü3 (Kontoanlage im Verzeichnis) und U1 (eigener Fehl-Upload).
- **Datenschutzbeauftragter/Ansprechpartner:** **[offen]** – zu benennen bzw. zu
  klären, ob eine Benennungspflicht besteht.

---

## 4. Erhebungszeitpunkte

Personenbezogene Daten können zu folgenden Zeitpunkten erhoben werden:

- **Öffentliche Meldung:** Absenden einer Meldung über `/submit-report`
  (anonym oder mit freiwilligen Kontaktangaben).
- **Interne Bearbeitung:** Anlegen von Notizen, Statusänderungen, Zuordnungen
  durch interne Nutzer.
- **Upload von Anhängen:** Hochladen von Dateien zu einer Meldung.
- **Benutzeranlage/Rollenvergabe:** Anlegen interner Konten und Zuweisen von
  Rollen.
- **Sicherheitsbesprechung:** Erfassung/Vorbereitung besprechungsbezogener
  Informationen *(perspektivisch)*.
- **Import/Export:** Datenaustausch (z. B. Export für Auswertung, Import
  bestehender Meldungen) *(perspektivisch; [offen])*.

---

## 5. Zwecke der Verarbeitung

- **Erfassung sicherheitsrelevanter Ereignisse** (Beobachtungen,
  Beinahe-Ereignisse, Vorfälle, Unfälle).
- **Interne Bearbeitung und Nachverfolgung** von Meldungen (Status, Priorität,
  Notizen).
- **Ableitung und Kontrolle von Maßnahmen** zur Verbesserung der Flugsicherheit.
- **Vorbereitung von Sicherheitsbesprechungen**.
- **Nachvollziehbare Administration und Auditierung** (wer hat wann was
  bearbeitet).
- **Statistische/inhaltliche Auswertung** ausschließlich **anonymisiert oder
  aggregiert**, soweit fachlich möglich.

Die Verarbeitung soll dem Prinzip der **Datenminimierung** (Art. 5 Abs. 1 lit. c
DSGVO) folgen: personenbezogene Daten werden nur erhoben und aufbewahrt, soweit
für den jeweiligen Zweck erforderlich.

---

## 6. Datenschutzhinweise im Frontend

Anforderungen an den öffentlichen Bereich:

- **Link zur Datenschutzerklärung** an gut sichtbarer Stelle im öffentlichen
  Bereich (z. B. Footer).
- **Kurzer Datenschutzhinweis auf `/submit-report`** direkt am Meldeformular.
- **Datenschutz-Einwilligung auf `/submit-report`** (umgesetzt, Abschnitt 11b):
  pro Organisation ein- und ausschaltbar, Voreinstellung eingeschaltet; Text
  pro Organisation anpassbar, mit festem Link zur Datenschutzerklärung.
- **Hinweis zur Datenminimierung in Freitexten:** personenbezogene Daten in
  Freitextfeldern **möglichst vermeiden**, sofern sie für die Bearbeitung nicht
  erforderlich sind.
- **Hinweis auf freiwillige Melderinformationen:** Kontaktangaben sind freiwillig;
  eine anonyme Meldung ist möglich.
- **Hinweis auf spätere Anonymisierung/Datenreduktion** personenbezogener Daten
  nach Abschluss der Bearbeitung.
- **Hinweis, dass PAOLO keine gesetzliche oder verbandsrechtliche Unfallmeldung
  ersetzt**, sofern relevant (z. B. gegenüber DHV/Behörden). Konkrete Formulierung
  **[offen]**.

---

## 7. Datenschutzhinweise im Backend

Anforderungen an den internen/Adminbereich:

- **Datenschutz-/Compliance-Hinweise im Adminbereich** (z. B. an zentraler Stelle
  im Dashboard).
- **Hinweise vor Export**, dass exportierte Daten personenbezogen sein können und
  entsprechend geschützt zu behandeln sind.
- **Hinweise vor Import** hinsichtlich Herkunft, Rechtsgrundlage und Qualität
  importierter personenbezogener Daten.
- **Hinweis vor Upload/Download von Anhängen** (mögliche personenbezogene
  Inhalte, sichere Handhabung).
- **Hinweis bei Bearbeitung personenbezogener Daten** (z. B. beim Öffnen von
  Freitexten/Notizen mit möglichem Personenbezug).
- **Klare Trennung zwischen fachlicher Sicherheitsinformation und
  personenbezogenen Zusatzdaten** in Darstellung und Bearbeitung, um
  Datenminimierung und spätere Anonymisierung zu erleichtern.
- **Hinweis beim Erweitern des Empfängerkreises eines Dokuments.** Die
  Sichtbarkeitsstufe `members` macht ein SMS-Dokument für alle angemeldeten
  Mitglieder lesbar und vergrößert den Empfängerkreis damit erheblich —
  besonders bei Protokollen von Sicherheitsbesprechungen, die häufig Namen von
  Beteiligten, Fallbezüge und interne Einschätzungen enthalten. Für die
  Kategorie `safety_meeting_minutes` verlangt das Formular deshalb eine
  ausdrückliche Kenntnisnahme, bevor die Stufe überhaupt in das Feld übernommen
  wird. Die Stufe ist bewusst nicht anmeldefrei: `members` erscheint auf
  `/communications` erst nach der Anmeldung. Siehe
  [`docs/roles-and-permissions.md`](roles-and-permissions.md).

---

## 8. Löschprozess bei Betroffenenanfrage

Prozess bei Anfragen betroffener Personen (z. B. Löschung nach Art. 17 DSGVO):

1. **Anfrage entgegennehmen** über einen definierten Kontaktweg.
2. **Identität/Berechtigung prüfen**, um unberechtigte Löschungen zu vermeiden.
3. **Betroffene Datensätze suchen** über alle relevanten Bereiche (Reports,
   Notes, Measures, Attachments, Users, Audit Logs).
4. **Fachliche/rechtliche Aufbewahrungsgründe prüfen** (z. B. Sicherheitsinteresse,
   gesetzliche Aufbewahrungspflichten, überwiegende schutzwürdige Interessen).
5. **Entscheidung dokumentieren** (Löschung, Anonymisierung oder Ablehnung mit
   Begründung).
6. **Personenbezogene Daten löschen oder anonymisieren**, je nach Entscheidung.
7. **Anhänge prüfen, löschen oder anonymisieren** (inkl. Blob-Speicher).
8. **Audit-Log** nur soweit rechtlich und technisch zulässig behandeln; die
   Nachvollziehbarkeit von Bearbeitungsvorgängen kann eigenen Aufbewahrungs- und
   Integritätsanforderungen unterliegen. **[offen]**
9. **Betroffene Person informieren** über das Ergebnis.
10. **Fristen und Zuständigkeit rechtlich klären** (u. a. Monatsfrist nach
    Art. 12 Abs. 3 DSGVO). **[offen]**

---

## 9. Technische Anforderungen für Löschung

- **Suche nach personenbezogenen Daten** über alle Speicherorte:
  Reports, Notes, Measures (`assignedToText`), Attachments, Users, Audit Logs.
- **Unterscheidung der Löschstrategie:**
  - **Hard Delete:** endgültiges Entfernen des Datensatzes.
  - **Soft Delete:** Markierung als gelöscht bei technischer Erhaltung.
  - **Anonymisierung:** Entfernen/Ersetzen des Personenbezugs unter Erhalt der
    fachlichen Sicherheitsinformation.
- **Löschung von Blob-Dateien** (Anhänge) außerhalb der Datenbank explizit
  berücksichtigen; verwaiste Blobs vermeiden.
- **Auditierbarkeit des Löschvorgangs:** Löschungen/Anonymisierungen sollen
  nachvollziehbar protokolliert werden, ohne dabei erneut sensible
  personenbezogene Daten zu speichern.
- **Schutz vor versehentlicher Löschung** fachlich relevanter Sicherheitsdaten
  (z. B. Bestätigungsschritte, Rollenbeschränkung, ggf. Anonymisierung statt
  vollständiger Löschung).

---

## 10. Anonymisierungsprozess nach Abschluss der Bearbeitung

**Ausgangspunkt:** PAOLO soll sicherheitsrelevante Erkenntnisse dauerhaft
erhalten, personenbezogene Daten nach Abschluss der Bearbeitung jedoch reduzieren
oder entfernen.

- **Trigger (umgesetzt):** Statuswechsel auf `closed` oder `hidden` — dann bietet
  ein Dialog die Anonymisierung an; alternativ nachträglich auf der
  Meldungs-Detailseite (nur bei abgeschlossenen/ausgeblendeten Meldungen).
- **Mögliche Wartefrist nach Abschluss:** **[offen]** – Dauer rechtlich/fachlich
  festzulegen (Balance aus Nachbearbeitbarkeit und Datenminimierung). Aktuell
  erfolgt die Anonymisierung ohne Wartefrist auf ausdrückliche Auslösung hin.
- **Automatisierungsgrad:** **teilautomatisch** (Opt-in), Auslösung/Prüfung durch
  Admin/Safety Manager. Es gibt bewusst **keine** automatische Massen- oder
  Freitext-Anonymisierung.
- **Tatsächlich anonymisiert (umgesetzt):** ausschließlich **strukturierte
  Melderdaten**:
  - `reporterName`
  - `reporterRole`
  - `reporterContact`
  - zusätzlich wird die Meldung auf `isAnonymous = true` und
    `anonymizationStatus = partial` gesetzt; der Vorgang wird im Audit-Log als
    `REPORT_ANONYMIZED` protokolliert (nur Feldnamen, keine Klartext-Melderdaten).
- **Nicht automatisiert – manuell zu prüfen:**
  - personenbezogene Angaben in Freitexten (Beschreibung, Notizen) – **automatisch
    nur schwer sicher erkennbar**
  - `assignedToText` in Maßnahmen
  - Anhänge – **nur manuell prüfbar**, werden nicht gelöscht
- **Grundprinzipien:**
  - **Sicherheitsinformation bleibt erhalten.**
  - **Direkte Identifizierbarkeit wird entfernt/reduziert.**
  - **Automatische Freitext-Anonymisierung nur mit Vorsicht**, da Fehl-Erkennungen
    (falsch-positiv/falsch-negativ) möglich sind; menschliche Prüfung wird
    empfohlen.

---

## 11. VO (EU) 376/2014 / Sicherheitsmeldelogik

*(Vorsichtige Einordnung, keine abschließende rechtliche Bewertung.)*

- PAOLO orientiert sich **fachlich an Prinzipien einer lernorientierten,
  nicht-punitiven Sicherheitsmeldung**.
- **Vertraulichkeit, Schutz der meldenden Person und Reduktion personenbezogener
  Daten** sind zentrale Prinzipien.
- **Ob und wie die VO (EU) 376/2014 unmittelbar anwendbar ist** (Geltungsbereich,
  Luftfahrtsegment, nationale Umsetzung), muss **rechtlich und fachlich geklärt**
  werden. **[offen]**
- Technische Folgerungen für PAOLO – unabhängig von der Frage der unmittelbaren
  Anwendbarkeit:
  - personenbezogene Daten **getrennt und sparsam** behandeln,
  - **fachliche Sicherheitsinformationen erhalten**,
  - personenbezogene Daten **nach Abschluss möglichst entfernen/anonymisieren**,
  - **Zugriff strikt rollenbasiert begrenzen**.

---

## 11a. Öffentliche Statusrückmeldung (Meldungscode und Bearbeitungsstatus)

Meldungen aus dem öffentlichen Formular erhalten beim Speichern einen zufällig
vergebenen, neutralen Meldungscode (`Falke-12`). Auf `/communications` steht
eine Liste, die je Eintrag **ausschließlich** diesen Code und den
Bearbeitungsstatus zeigt.

**Was öffentlich wird:** Code und Status. Sonst nichts.

**Was nicht öffentlich wird:** Meldungsinhalt, Kurzbeschreibung, Kategorie,
Risikobewertung, Melderdaten, interne Notizen, Anhänge, interne IDs und jede
Datums- oder Zeitangabe. Das Eingangsdatum wird nur zur Sortierung verwendet
und nicht ausgeliefert. Der Code eröffnet keinen Zugriff auf irgendetwas davon;
er ist eine Bezeichnung, kein Schlüssel.

**Der Code ist nicht ableitbar** — weder aus einer laufenden Nummer noch aus der
internen ID oder dem Meldungsdatum. Er wird aus einer festen Wortliste und einer
zweistelligen Zahl kryptografisch zufällig gezogen.

**Entfernung aus der öffentlichen Liste:**

- Status `Ausgeblendet` und Verschieben in den Papierkorb wirken **sofort** für
  alle nachfolgenden Abrufe.
- Abgeschlossene Meldungen verschwinden **drei Kalendermonate nach dem
  Abschluss**. Die Frist wird bei jedem Abruf gerechnet, nicht durch eine
  Hintergrundaufgabe — sie hält also auch dann, wenn die Anwendung tagelang
  nicht aufgerufen wurde.
- Die Entfernung betrifft **nur die öffentliche Anzeige**. Meldung, interne
  Daten und Historie bleiben unverändert; es wird nichts gelöscht.

**Bestandsdaten:** Meldungen ohne Meldungscode erscheinen nie. Das betrifft
alle Meldungen von vor der Einführung sowie CSV-Importe. Eine nachträgliche
Codevergabe findet nicht statt. Das ausdrücklich geladene synthetische
Operator-Spieldaten-Fixture enthält dagegen Meldungscodes, damit Betreiber die
öffentliche Statusrückmeldung erproben können.

**Restrisiko — bekannt und bewusst in Kauf genommen.** Die Liste enthält keinen
Inhalt, ist aber eine Veröffentlichung: Sie zeigt, **dass** gemeldet wurde, in
welcher Reihenfolge und wie die Bearbeitung vorankommt. In einer kleinen
Organisation kann das mit anderem Wissen — „am Samstag ist am Startplatz etwas
passiert" — zu einem Rückschluss auf eine einzelne Meldung führen. Diese
Abwägung wurde für diese Funktion ausdrücklich getroffen: Der Nutzen (sichtbare
Bearbeitung, gestärkte Meldebereitschaft) überwiegt.

**Die verhältnismäßige Gegenmaßnahme ist organisatorisch, nicht technisch:**
Jede Organisation kann die Anzeige unter Organisationseinstellungen →
„Statusrückmeldungen öffentlich anzeigen" abschalten. Der Schalter wirkt in der
Datenbereitstellung, nicht nur in der Darstellung; bei abgeschalteter Anzeige
verlassen keine Statusdaten den Server. Jedes Umschalten wird im Audit-Log
festgehalten. Für eine einzelne heikle Meldung ist der Status `Ausgeblendet`
der sofort wirksame Weg.

---

## 11b. Datenschutz-Einwilligung im Meldeformular

Umgesetzt mit Issue
[#101](https://github.com/peterkreutz2-ctrl/paolo-sms/issues/101).

**Konfiguration.** Unter `/dashboard/privacy` → „Einwilligung im
Meldeformular“ (Administrator und Safety Manager) wird die Abfrage ein- oder
ausgeschaltet und ihr Text gepflegt. Voreinstellung: eingeschaltet, auch für
Installationen, die vor dieser Funktion bestanden. Der Standardtext ist ein
abgestimmter Wortlaut; er wird nur nach ausdrücklicher Freigabe geändert. Ein
eigener Text muss die Stelle `[Datenschutzerklärung]` genau einmal enthalten;
sie erscheint im Formular als Link auf `/datenschutz` in einem neuen Tab. Jede
Änderung an Schalter oder Text steht mit vorher/nachher im Audit-Log.

**Im Formular.** Eingeschaltet: ein zunächst leeres Pflicht-Kontrollkästchen;
„Meldung absenden“ bleibt bis zur Zustimmung gesperrt, mit sichtbarem Hinweis.
Der Server weist eine Einreichung ohne Zustimmung unabhängig davon ab.
Ausgeschaltet: kein Kontrollkästchen, keine Sperre.

**Nachweis.** Zu jeder Meldung, die mit Einwilligung eingeht, speichert PAOLO
drei Angaben an der Meldung selbst:

| Angabe | Inhalt |
|---|---|
| Zeitpunkt | Serverzeit der Annahme |
| Einwilligungstext | Wortlaut, wie er angezeigt wurde |
| Datenschutzerklärung | Die zu diesem Zeitpunkt gültige Fassung, wie `/datenschutz` sie zeigt: Betreiberangaben und Betreibertext bzw. PAOLO-Vorschlag |

Die drei Angaben sind nur gemeinsam vorhanden oder gemeinsam leer; die
Datenbank sichert das ab. Gespeichert wird der Wortlaut selbst (Snapshot), kein
Hash und keine Versionsnummer: So bleibt der Nachweis lesbar, auch wenn sich
Texte später ändern oder eine Sicherung zurückgespielt wird. Die Fassungen
stammen aus der Datenbank, nicht aus dem Browser. Eine IP-Adresse wird nicht
gespeichert.

**Geänderter Stand.** Ändern sich Schalter, Einwilligungstext oder
Datenschutzerklärung, während das Formular geöffnet ist, lehnt PAOLO die
Einreichung ab und bittet, die Einwilligung neu zu laden. Die übrigen Eingaben
bleiben erhalten; die Zustimmung muss für die neue Fassung erneut erteilt
werden. Ist die Abfrage ausgeschaltet und bleibt es, führen Änderungen an Text
oder Datenschutzerklärung zu keiner Ablehnung — sie spielen für die
Einreichung dann keine Rolle.

**Ohne Nachweis** bleiben Meldungen, die vor dieser Funktion eingegangen sind
(kein nachträglicher Eintrag), Meldungen bei ausgeschalteter Abfrage, Importe
und Spieldaten.

**Grenzen.** Der Nachweis belegt, dass eine Meldung ohne erteilte Zustimmung
nicht angenommen worden wäre, und welche Fassungen galten. Er kann eine
anonyme Meldung keiner Person zuordnen. Ob eine Einwilligung die zutreffende
Rechtsgrundlage ist und wie ein Widerruf organisatorisch behandelt wird, bleibt
Entscheidung des Betreibers (Abschnitt 14, Issue #16).

---

## 12. Incident-Response bei Datenschutzverletzungen

Prozess bei einer (möglichen) Verletzung des Schutzes personenbezogener Daten
(Art. 33/34 DSGVO):

1. **Vorfall erkennen** (technisch/organisatorisch).
2. **Sofortmaßnahmen** ergreifen (Eindämmung, z. B. Zugänge sperren, betroffene
   Komponenten isolieren).
3. **Intern eskalieren** an Verantwortliche/Ansprechpartner.
4. **Risiko für Betroffene bewerten** (Art, Umfang, Sensibilität der Daten).
5. **Entscheidung über Meldung an die Aufsichtsbehörde** treffen und begründen.
6. **Meldung möglichst binnen 72 Stunden ab Kenntnis**, sofern meldepflichtig
   (Art. 33 DSGVO).
7. **Ggf. Benachrichtigung betroffener Personen** bei hohem Risiko (Art. 34
   DSGVO).
8. **Dokumentation des Vorfalls** (Hergang, Bewertung, Maßnahmen, Entscheidungen).
9. **Technische Nachbereitung** (Ursachenanalyse, Behebung, Prävention).

---

## 13. Technische Anforderungen für Incident-Response

- **Kontaktweg für Datenschutzvorfälle** (definierte Meldeadresse/Zuständigkeit).
- **Internes Incident-Log oder Dokumentationsvorlage** für Vorfälle.
- **Export/Ansicht betroffener Datensätze** zur Bewertung von Umfang und
  Betroffenheit.
- **Audit-Log-Auswertung** zur Rekonstruktion von Zugriffen/Änderungen.
- **Möglichkeit, Benutzerzugänge zu sperren** (Auth/Clerk-seitig).
- **Möglichkeit, kompromittierte Dateien/Anhänge zu entfernen** (inkl.
  Blob-Speicher).
- **Betriebs-/Hostingkontakte dokumentieren** (Clerk, Vercel, Neon, Blob) für
  schnelle Reaktion.

---

## 14. Offene rechtliche Klärungspunkte

> Diese Punkte werden als Checkliste in GitHub-Issue
> [#16](https://github.com/peterkreutz2-ctrl/paolo-sms/issues/16) nachverfolgt.

Folgende Punkte sind **vor Pilotbetrieb rechtlich/fachlich zu klären**:

- **[offen]** Verantwortlicher nach DSGVO (Schule/Verein, DHV, Betreiber, ggf.
  gemeinsame Verantwortlichkeit).
- **[offen]** Auftragsverarbeitung/AVV mit Hoster und Diensten (Clerk, Vercel,
  Blob-Storage, Datenbank-Anbieter/Neon).
- **[offen]** Finaler Text der Datenschutzerklärung.
- **[offen]** Rechtsgrundlage(n) der Verarbeitung (z. B. Art. 6 DSGVO;
  berechtigtes Interesse, Einwilligung, ggf. rechtliche Verpflichtung).
- **[offen]** Speicherdauer der verschiedenen Datenkategorien.
- **[offen]** Löschfristen.
- **[offen]** Anonymisierungszeitpunkt (Wartefrist nach `closed`).
- **[offen]** Zuständige Datenschutzaufsichtsbehörde.
- **[offen]** Umgang mit Unfallmeldungen/Verbandsmeldungen (Verhältnis zu
  gesetzlichen/verbandsrechtlichen Meldepflichten).
- **[offen]** Verhältnis zur VO (EU) 376/2014.
- **[offen]** Datenübermittlung an DHV, Vereine, Flugschulen.
- **[offen]** Hosting-Region und mögliche Drittlandtransfers (Art. 44 ff. DSGVO).

---

## 15. Empfohlene Umsetzungsphasen

**Phase 1 – Grundlagen dokumentieren und sichtbar machen**
- Datenschutzkonzept dokumentieren (dieses Dokument).
- Frontend-Link zur Datenschutzerklärung.
- Kurzer Datenschutzhinweis auf dem Meldeformular.

**Phase 2 – Hinweise und Platzhalter**
- Datenschutzerklärungsseite als Platzhalter mit prüfpflichtigem Text.
- Backend-Hinweise bei Export/Import/Anhängen.

**Phase 3 – Lösch-/Anonymisierungsprozess vorbereiten**
- Lösch- und Anonymisierungsprozess technisch vorbereiten.
- Admin-Werkzeuge oder dokumentierter manueller Prozess.

**Phase 4 – Incident-Response**
- Incident-Response-Dokumentation und Meldeformular/Vorlage.

**Phase 5 – (Halb-)Automatisierung**
- Automatisierte oder halbautomatische Anonymisierung geschlossener Meldungen.

---

## 16. Minimale Anforderungen vor Pilotbetrieb

Vor einem Pilotbetrieb sollten mindestens erfüllt sein:

- **Sichtbare Datenschutzhinweise** (öffentlicher Bereich und Meldeformular).
- **Verantwortlicher/Betreiber geklärt** und benannt.
- **Löschanfragen-Prozess** zumindest organisatorisch beschrieben.
- **Incident-Response-Prozess** beschrieben.
- **Anonymisierungsstrategie** festgelegt.
- **Auftragsverarbeitung/Hosting** geklärt (AVV vorhanden).
- **Keine unkontrollierte öffentliche Registrierung** interner Konten.

### 16.1 Wo die Entscheidungen in PAOLO wirksam werden

Abschnitt 14 nennt, *was* zu klären ist. Die folgende Übersicht nennt, *wo die
Antwort eingetragen wird*. Sie ersetzt keine der dortigen Klärungen und nimmt
keine davon vorweg: PAOLO gibt bewusst keine Fristen, Rechtsgrundlagen oder
Textbausteine vor und leistet keine Rechtsberatung. Die Software hält
ausschließlich die Stellschrauben bereit, an denen die Entscheidung des
Betreibers wirksam wird.

| Zu klärender Punkt (Abschnitt 14) | Entsprechung in PAOLO | Vorbedingung |
|---|---|---|
| Verantwortlicher, Anschrift, Vertretung, Kontakt | `/dashboard/admin/legal` → Rechtliche Angaben; öffentlich unter `/impressum` | — |
| Rechtsgrundlage, Speicherdauer, Empfänger, Betroffenenrechte | `/dashboard/admin/legal` → Rechtliche Angaben; öffentlich unter `/datenschutz` | Verantwortlicher benannt |
| Installationsweg, Hosting und Hosting-Region | Kein Feld in der Anwendung — Auswahl vor der Installation, siehe [`installation-decision-guide.md`](installation-decision-guide.md) | — |
| Speicherdauer je Datenkategorie | Kein Feld. Die Kategorien stehen in Abschnitt 2; die Frist wird organisatorisch geführt | Rechtsgrundlage |
| Turnus der Datenschutzprüfung abgeschlossener Meldungen | Organisationseinstellung `reportRetentionReviewIntervalMonths` unter `/dashboard/settings` | Speicherdauer |
| Turnus der Sicherheitsbesprechungen | Organisationseinstellung unter `/dashboard/settings`, 1–24 Monate | — |
| Aufbewahrung und Verschlüsselung der Backups | `BACKUP_DIR`, `BACKUP_AGE_RECIPIENTS`, `BACKUP_RETENTION_*`; siehe [`backup-restore.md`](backup-restore.md) | Installationsweg |
| Aufbewahrung der Rate-Limit-Datensätze | Standardmäßig ein Tag, Löschung beiläufig beim nächsten Meldevorgang; eine garantierte Obergrenze verlangt den manuellen Cleanup aus dem Betreiber-Runbook (Abschnitt 2) | — |
| Rollenvergabe `admin`, `safety_manager`, `instructor` | `/dashboard/users`. **Wer** Safety Manager ist, legt die Sicherheitsrichtlinie der Organisation fest, nicht dieses Dokument | Verantwortlicher benannt |

Der laufende Betrieb dieser Funktionen — Datenschutzprüfung, Betroffenenanfragen,
Vorfalldokumentation — ist in [`privacy-operations.md`](privacy-operations.md)
beschrieben und nicht Gegenstand dieser Übersicht.

### 16.2 Klärungspunkte, die technische Folgearbeit auslösen können

Zwei Punkte aus Abschnitt 14 haben in PAOLO **keine** Entsprechung. Fällt die
Entscheidung so aus, dass sie eine braucht, ist diese zu entwickeln und steht
nicht ohne Weiteres zum Pilotbetrieb zur Verfügung:

- **Wartefrist zwischen `closed` und Anonymisierung.** Die Anonymisierung
  erfolgt heute ohne Wartefrist auf ausdrückliche Auslösung hin (Abschnitt 10).
  Eine Festlegung wie „automatisch X Monate nach Abschluss" verlangt einen
  zeitgesteuerten Ablauf, den PAOLO nicht besitzt.
- **Aufbewahrung des Audit-Logs bei Löschung.** Das Audit-Log ist praktisch
  fortschreibend; der einzige schreibende Eingriff ist die Redaktion im Zuge
  einer Anonymisierung, die ihrerseits einen Nachweis schreibt (Abschnitt 8).
  Eine Festlegung, die darüber hinaus Einträge entfernt oder verkürzt, verlangt
  einen neuen Löschpfad.

Beide Punkte sollten deshalb **früh** geklärt werden — nicht, weil das
Projektteam sie entscheiden dürfte, sondern weil die Antwort Entwicklungsarbeit
nach sich ziehen kann, die vor dem Pilotbetrieb abgeschlossen sein muss.

---

## 17. Installierbares Betreiber-Modell

PAOLO SMS ist als Software gedacht, die von Vereinen und Gleitschirmschulen
selbst installiert und betrieben werden kann (nicht nur zentral gehostet).

Konsequenzen:

- **Betreiber der konkreten Instanz** ist der jeweilige Verein, die jeweilige
  Flugschule oder ggf. eine zentrale Organisation.
- **Verantwortlicher nach DSGVO** muss **pro Instanz** geklärt und benannt werden
  (voraussichtlich der jeweilige Betreiber, **nicht** automatisch der
  Softwareautor). **[offen]** – siehe Abschnitt 3.
- **Datenschutz- und Impressumsangaben sind installationsspezifisch.**
- PAOLO darf **keine festen rechtlichen Angaben** des Softwareautors oder eines
  bestimmten Verbandes in produktiven Rechtstexten verdrahten.
- PAOLO kann **Standardstruktur, Eingabefelder, Platzhalter und Hinweise**
  bereitstellen.
- Die **rechtliche Verantwortung** für die konkreten Inhalte liegt beim
  **Betreiber** der jeweiligen Instanz.

> Dieses Modell hat Rückwirkungen auf das Organisations-Scoping: Bei
> Mehrorganisationenbetrieb müssen rechtliche Angaben organisationsbezogen
> geführt werden (vgl. `docs/organization-scoping.md`).

---

## 18. Impressum

PAOLO sollte eine **öffentliche Impressumsseite** bereitstellen, z. B.
`/impressum`.

Das Impressum muss durch den **Betreiber der jeweiligen Instanz** gepflegt und
**rechtlich geprüft** werden.

Typische konfigurierbare Angaben:

- Betreibername / Vereinsname / Flugschule
- Rechtsform
- Anschrift
- Kontakt-E-Mail
- Telefon, falls erforderlich oder gewünscht
- vertretungsberechtigte Person(en)
- Registerangaben, falls vorhanden
- Umsatzsteuer-ID, falls relevant
- zuständige Aufsicht / Behörde, falls relevant
- zusätzliche Freitextangaben

**Hinweis:** PAOLO leistet keine Rechtsberatung und garantiert keine
vollständige Rechtssicherheit. Die konkreten Angaben müssen vom Betreiber
geprüft werden. **[offen]**

---

## 19. Datenschutzerklärung

PAOLO sollte eine **öffentliche Datenschutzerklärungsseite** bereitstellen,
z. B. `/datenschutz` oder `/privacy`.

Die Datenschutzerklärung muss **installationsspezifisch anpassbar** sein.

Typische konfigurierbare Angaben:

- Verantwortlicher
- Kontaktdaten des Verantwortlichen
- Datenschutzkontakt
- Datenschutzbeauftragter, falls vorhanden
- zuständige Datenschutzaufsichtsbehörde
- Hostinganbieter / technische Dienstleister
- Auftragsverarbeiter
- Speicherdauer oder Kriterien der Speicherdauer
- Rechtsgrundlagen
- Kontaktweg für Betroffenenrechte
- Kontaktweg für Datenschutzvorfälle
- zusätzliche Freitextangaben

Weiter festzuhalten:

- PAOLO kann einen **prüfpflichtigen Standardtext oder Platzhalter**
  bereitstellen.
- Der Betreiber muss diesen Text **vor Produktivbetrieb prüfen und
  vervollständigen**.
- **Fehlende Angaben sollen im Adminbereich deutlich sichtbar sein.**

---

## 20. Admin-Konfiguration „Rechtliche Angaben"

*(Umgesetzt. Betriebssicht siehe [`docs/privacy-operations.md`](privacy-operations.md);
Migration `0014_add_legal_settings`.)*

Unter `/dashboard/admin/legal` steht der Bereich **„Rechtliche Angaben"** bereit.
Dort werden Betreiberangaben für Impressum und Datenschutzerklärung gepflegt; sie
speisen die öffentlichen Seiten `/impressum` und `/datenschutz`.

Zugriff:

- zunächst nur `admin`
- später ggf. `safety_manager`, wenn dieser Betreiber-/Organisationsverantwortung
  trägt
- bei Mehrorganisationenbetrieb **zwingend organisationsbezogen**
  (vgl. `docs/roles-and-permissions.md`, `docs/organization-scoping.md`)

Struktur:

- Betreiberangaben
- Impressumsangaben
- Datenschutzangaben
- Hosting-/Dienstleisterangaben
- Aufsichtsbehörde
- Freitextergänzungen
- Statushinweis: vollständig / unvollständig / prüfpflichtig

Umgang mit fehlenden Pflichtangaben:

- Fehlende Felder werden öffentlich als „noch nicht hinterlegt" gekennzeichnet;
  öffentliche Seiten geben fehlende Angaben **nicht** als vollständig aus.
- Die **Inhalte** bleiben installationsspezifisch zu pflegen und vor
  Produktivbetrieb rechtlich zu prüfen.

---

## 21. Öffentliche Verlinkung

PAOLO sollte öffentlich sichtbare Links auf Impressum und Datenschutzerklärung
bereitstellen:

- auf der Startseite (`/`)
- auf `/submit-report`
- ggf. im Footer
- ggf. auf Login-/Sign-in-Seiten, soweit technisch möglich und sinnvoll

---

## 22. Auswirkungen auf den Pilotbetrieb (Betreiber-Modell)

Vor einem Pilotbetrieb müssen für die konkrete Instanz **mindestens** geklärt
sein:

- Wer ist **Betreiber** der konkreten Instanz?
- Wer ist **Verantwortlicher nach DSGVO**?
- Welche **Impressumsangaben** werden verwendet?
- Welche **Datenschutzerklärung** gilt?
- Welche **Hostinganbieter und Dienstleister** sind beteiligt?
- Gibt es **Auftragsverarbeitungsverträge**?
- Wer bearbeitet **Betroffenenanfragen**?
- Wer bearbeitet **Datenschutzvorfälle**?
- Wer darf **rechtliche Angaben in PAOLO ändern**?

Diese Punkte ergänzen die minimalen Anforderungen aus Abschnitt 16.

---

## 23. Umsetzungsstand

Dieses Dokument entstand ursprünglich als reiner Dokumentationsschritt (ohne
Code, Tabellen, Routen, UI oder Migrationen). Inzwischen sind wesentliche Teile
umgesetzt:

- Rechtliche Angaben unter `/dashboard/admin/legal`, öffentliche Seiten `/impressum`
  und `/datenschutz` (Migration `0014_add_legal_settings`).
- Anonymisierung strukturierter Melderdaten (Migration
  `0015_add_report_anonymization`).
- Datenschutzvorfälle/Incident-Response unter `/dashboard/privacy/incidents`
  (Migration `0016_add_privacy_incidents`).
- Datenschutzprozesse und Betroffenenanfragen-Suche unter `/dashboard/privacy`.
- Datenschutz-Einwilligung im Meldeformular mit Nachweis an der Meldung
  (Migration `0034_add_public_report_privacy_consent`, Abschnitt 11b).

Betriebssicht: [`docs/privacy-operations.md`](privacy-operations.md).

Weiterhin gilt bewusst:

- **Keine** finalisierten Rechtstexte (bleiben prüfpflichtig durch Betreiber
  bzw. Datenschutzbeauftragte).
- **Keine** hart codierten personenbezogenen Angaben des Softwareautors oder
  eines bestimmten Verbandes.
- **Keine** automatische Löschung und **keine** automatische
  Freitext-Anonymisierung.

---

*Ende des Dokuments. Alle mit **[offen]** markierten Punkte sind vor Produktiv-/
Pilotbetrieb zu klären. Dieses Dokument ersetzt keine rechtliche Prüfung.*
