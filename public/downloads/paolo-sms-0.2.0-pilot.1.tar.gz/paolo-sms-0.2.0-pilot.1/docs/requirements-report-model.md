# Anforderungen an das Report-Datenmodell

Quelle: Auszug und Verdichtung aus `AnforderungSMS-System.docx`, Version 6.5.2026.

Dieses Dokument beschreibt die fachlichen Anforderungen an das Report-Datenmodell von PAOLO SMS. Es dient als Arbeitsgrundlage für die technische Weiterentwicklung des Datenmodells, der Formulare, der Import-/Exportfunktionen und der späteren Filter- und Auswertungsfunktionen.

## Grundsatz

PAOLO SMS dient der organisationsinternen Erfassung und Bearbeitung sicherheitsrelevanter Beobachtungen, Ereignisse, Zwischenfälle, Unfälle und Vorschläge in Gleitschirmflugschulen und Vereinen.

Das System ersetzt keine offizielle Unfallmeldung, keine Versicherungsmeldung und keine sonstige gesetzlich vorgeschriebene Meldung. Es dient dem Lernen aus Ereignissen und der Verbesserung der Sicherheit innerhalb der Organisation.

Der Ansatz ist non-punitive. Ziel ist nicht die Suche nach Schuldigen oder die Bewertung einzelner Personen, sondern das Erkennen von Risiken, beitragenden Faktoren, systemischen Schwächen und geeigneten Maßnahmen.

## Niederschwellige Meldung

Die Erfassung einer Meldung soll möglichst einfach und schnell möglich sein. Das Meldeformular soll für mobile Endgeräte geeignet sein und mit möglichst wenigen Pflichtfeldern auskommen.

Meldungen können anonym erfolgen. Um die Hemmschwelle niedrig zu halten, sollen nur wenige Angaben verpflichtend sein.

Pflichtfelder in der ersten Ausbaustufe:

- Art des Berichts
- Kurzbeschreibung
- detaillierte Beschreibung

Alle weiteren Angaben sollen grundsätzlich optional sein oder später durch den Safety Manager ergänzt werden können.

## Arten von Berichten

Das System soll unterschiedliche Arten sicherheitsrelevanter Meldungen erfassen können.

Fachlich relevante Berichtstypen:

- meldepflichtiger Unfall
- nicht meldepflichtiger Unfall
- schwerer Zwischenfall
- Zwischenfall
- Beinahe-Ereignis / Near Miss
- Beobachtung
- Gefährdung / Hazard
- Vorschlag zu Sicherheitsmaßnahmen
- andere Meldung

Das aktuelle technische Modell kann diese Begriffe zunächst gröber abbilden. Wichtig ist, dass spätere Differenzierungen möglich bleiben.

Aktuelle technische Berichtstypen können sein:

- `accident`
- `near_miss`
- `hazard`
- `observation`
- `suggestion`
- `other`

## Unterschiedliche Datentiefe je Berichtstyp

Nicht jede Meldung benötigt dieselbe Datentiefe.

Für Unfälle, Zwischenfälle und Beinahe-Ereignisse sind mehr optionale Angaben sinnvoll, etwa Ereigniszeitpunkt, Ort, Flugphase, Startart, Ausrüstung, Wetter, Verletzungen, Schäden und beteiligte Personen.

Für Beobachtungen und Vorschläge soll der Umfang reduziert bleiben. Hier reichen zunächst:

- meldende Person, falls nicht anonym
- Bereich der Aktivität
- Dringlichkeit / Priorität
- Kurzbeschreibung
- detaillierte Beschreibung
- vorgeschlagene Maßnahmen
- Anhänge, falls vorhanden

Das öffentliche Formular soll deshalb abhängig vom Berichtstyp unterschiedliche Felder anzeigen können.

## Zentrale Felder der Meldung

Für das Report-Datenmodell sind folgende Felder fachlich wichtig.

### Basisdaten

- Art des Berichts
- Kurzbeschreibung
- detaillierte Beschreibung
- Priorität / Dringlichkeit
- Status
- Erfassungsdatum
- Änderungsdatum
- Erfassungskanal

### Ereigniskontext

- Datum und Uhrzeit des Ereignisses
- Ort des Ereignisses
- Fluggebiet
- Aktivitätsbereich
- Art der Aktivität
- Flugphase
- Startart

### Reflexion durch den Meldenden

Die Meldung soll nicht nur beschreiben, was geschehen ist. Sie soll auch einen Lernprozess anstoßen.

Deshalb soll der Meldende gefragt werden:

- Was wurde aus dem Ereignis gelernt?
- Welche Maßnahme wird vorgeschlagen?

Diese Angaben bilden die Sicht des Meldenden ab. Sie sind von der späteren Bewertung durch den Safety Manager oder das Safety Committee zu unterscheiden.

### Klassifikation

Für spätere Filterung und Auswertung sollen Meldungen grob klassifiziert werden können.

Wichtige Klassifikationsfelder:

- Aktivitätsbereich
- Art der Aktivität
- Flugphase
- Startart
- Schweregrad

Diese Felder sollen zunächst optional sein. Sie können entweder durch den Meldenden angegeben oder später im Backend durch den Safety Manager ergänzt werden.

## Vorschlag für Klassifikationswerte

Die Werte sollen zum Gleitschirmsport und zur Arbeit kleiner Organisationen passen. Sie sollen nicht zu fein sein, damit das System einfach bleibt und auch bei wenigen Meldungen sinnvoll nutzbar ist.

### Aktivitätsbereich

Der Aktivitätsbereich beschreibt den organisatorischen oder betrieblichen Rahmen.

Vorschlag technische Werte:

- `basic_training`
- `high_flight_training`
- `thermal_or_technique_training`
- `b_license_training`
- `safety_training`
- `flight_trip`
- `groundhandling_training`
- `free_flying`
- `tandem_or_passenger`
- `competition`
- `other`
- `unknown`

Deutsche Labels:

- Grundausbildung / Schnupperkurs
- Höhenflugschulung
- Thermik- oder Technikkurs
- B-Schein-Ausbildung
- Sicherheitstraining
- Flugreise
- Groundhandling-Training
- Freies Fliegen
- Passagierflug / Tandem
- Wettbewerb
- Andere
- Unbekannt

Für den MVP genügt Einfachauswahl.

### Art der Aktivität

Die Art der Aktivität beschreibt, was konkret getan wurde.

Vorschlag technische Werte:

- `groundhandling`
- `sled_ride`
- `soaring`
- `thermal_flying`
- `cross_country`
- `technical_flying`
- `acro`
- `spot_landing`
- `competition_task`
- `passenger_flight`
- `simulator_or_training_device`
- `other`
- `unknown`

Deutsche Labels:

- Groundhandling
- Abgleiter
- Soaring
- Thermikflug
- Streckenflug
- technisches Fliegen
- Acro
- Ziellandung
- Wettbewerbsaufgabe
- Passagierflug
- Simulator / Trainingsgerät
- Andere
- Unbekannt

Für den MVP genügt Einfachauswahl. Später kann Mehrfachauswahl sinnvoll sein, weil sich Aktivitäten überschneiden können.

### Flugphase

Die Flugphase beschreibt, in welchem Abschnitt des Ablaufs das Ereignis lag.

Vorschlag technische Werte:

- `preparation`
- `launch_preparation`
- `launch`
- `winch_launch`
- `initial_climb`
- `flight`
- `approach`
- `landing`
- `post_landing`
- `groundhandling`
- `packing`
- `other`
- `unknown`

Deutsche Labels:

- Vorbereitung
- Startvorbereitung
- Start
- Windenstart
- Anfangssteigflug
- Flug
- Landeanflug
- Landung
- Nach der Landung
- Groundhandling
- Packen / Nachbereitung
- Andere
- Unbekannt

Für den MVP genügt Einfachauswahl.

### Startart

Die Startart beschreibt, wie der Flug begonnen wurde.

Vorschlag technische Werte:

- `foot_launch`
- `winch`
- `tow`
- `tandem_launch`
- `motor`
- `other`
- `unknown`

Deutsche Labels:

- Hangstart
- Windenstart
- Schleppstart
- Tandemstart
- Motorschirm / Motorstart
- Andere
- Unbekannt

Für den MVP genügt Einfachauswahl.

### Schweregrad

Der Schweregrad beschreibt die eingetretene oder erkennbare Auswirkung des Ereignisses. Er ist von der Bearbeitungspriorität zu trennen.

Vorschlag technische Werte:

- `none`
- `minor`
- `serious`
- `fatal`
- `material_damage_only`
- `near_miss_high_potential`
- `unknown`

Deutsche Labels:

- Keine Verletzung / kein Schaden
- Leichte Verletzung oder geringer Schaden
- Schwere Verletzung oder erheblicher Schaden
- Tödlicher Unfall
- Nur Sachschaden
- Beinahe-Ereignis mit hohem Potenzial
- Unbekannt

Für den MVP genügt Einfachauswahl.

## Priorität und Schweregrad

Priorität und Schweregrad sind zu unterscheiden.

Der Schweregrad beschreibt die Folgen oder das Schadenspotenzial des Ereignisses.

Die Priorität beschreibt die Dringlichkeit der Bearbeitung.

Beispiele:

- Ein Ereignis ohne Schaden kann hohe Priorität haben, wenn es auf ein erhebliches Risiko hinweist.
- Ein Ereignis mit geringem Schaden kann niedrige Priorität haben, wenn keine Wiederholungsgefahr erkennbar ist.
- Ein schwerer Unfall hat in der Regel hohe oder kritische Priorität, aber die fachlichen Begriffe sollen getrennt bleiben.

## Personenbezogene Daten

Personenbezogene Daten sollen nicht unnötig im Report-Kernmodell vermischt werden.

Fachlich relevante personenbezogene Informationen:

- meldende Person
- Pilot
- Flugschüler
- Fluglehrer
- Zeugen
- Kontaktdaten
- Ausbildungsstand
- Flugerfahrung
- Trainingsstand

Diese Daten sollen langfristig strukturiert und getrennt gespeichert werden, zum Beispiel in einer Tabelle für beteiligte Personen. Sie sollen nicht primär in der allgemeinen Beschreibung versteckt werden.

In der frühen MVP-Phase können personenbezogene Angaben noch in Freitexten vorkommen. Langfristig soll das Datenmodell aber eine sauberere Trennung ermöglichen.

## Ausrüstung

Für viele Ereignisse sind Angaben zur Ausrüstung wichtig.

Relevante Ausrüstung:

- Gleitschirm
- EN-Klasse
- Gurtzeug
- Rettungsgerät
- Motor
- Winde
- weiteres relevantes Material

Diese Angaben sollen langfristig nicht direkt im Report-Kernmodell gespeichert werden, sondern in einer eigenen Struktur für Ausrüstungseinträge.

## Wetter

Wetterangaben können für die Analyse wichtig sein.

Relevante Angaben:

- vorhergesagtes Wetter
- tatsächliches Wetter
- Bodenwind
- Böen
- Thermik
- Bewölkung
- Sicht
- Temperatur

Für den MVP können Wetterinformationen zunächst in der detaillierten Beschreibung oder in späteren Ergänzungen dokumentiert werden. Eine eigene Wetterstruktur kann später ergänzt werden.

## Verletzungen und Schäden

Bei Unfällen und Zwischenfällen können Angaben zu Verletzungen und Schäden relevant sein.

Mögliche Inhalte:

- Art der Verletzung
- leichte oder schwere Verletzung
- Sachschäden
- Fremdschäden
- Verbleib der Ausrüstung
- Sicherstellung von Beweisstücken

Diese Angaben können später in strukturierten Feldern oder eigenen Tabellen ergänzt werden. Für den MVP reicht zunächst Freitext bzw. spätere Ergänzung durch den Safety Manager.

## Anhänge

Anhänge sind fachlich wichtig, aber sicherheits- und datenschutzrelevant.

Mögliche Anhänge:

- Bilder
- Tracklogs
- IGC-Dateien
- GPX-Dateien
- Wetter-Screenshots
- PDF-Dokumente
- Textdateien
- Videos

Das Hochladen durch nicht angemeldete Nutzer sollte begrenzt oder zunächst ausgeschlossen werden. Anhänge sollen als eigene Objekte mit Bezug zum Report gespeichert werden, nicht als Teil des Report-Kernmodells.

## Nachträge und Ergänzungen

Meldungen können später ergänzt werden. Das ist wichtig, weil unmittelbar nach einem Ereignis oft noch nicht alle Informationen vorliegen.

Mögliche Ergänzungen:

- Zeugenaussagen
- nachträgliche Wetterinformationen
- zusätzliche Beschreibung des Ablaufs
- neue Erkenntnisse
- weitere Dokumente
- Ergänzungen durch Safety Manager

Nachträge sollen nachvollziehbar gespeichert werden. Es muss erkennbar sein, wer welche Ergänzung wann vorgenommen hat.

Langfristig sollte es dafür eine eigene Struktur geben. Die ursprüngliche Meldung und spätere Ergänzungen sollen unterscheidbar bleiben.

## Beziehungen zwischen Berichten

Mehrere Berichte können sich auf dasselbe Ereignis beziehen. Außerdem können Berichte über verschiedene Ereignisse hinweg in einem fachlichen Zusammenhang stehen.

Beispiele:

- mehrere Personen melden denselben Unfall
- mehrere Berichte betreffen dasselbe Fluggebiet
- wiederholte Beinahezusammenstöße in einem stark frequentierten Gebiet
- wiederkehrende Probleme bei einer bestimmten Aktivität
- ähnliche Gefährdungen über längere Zeit

Langfristig soll es möglich sein, Berichte miteinander zu verknüpfen und die Art des Zusammenhangs zu beschreiben.

Mögliche Beziehungstypen:

- dasselbe Ereignis
- ähnliches Ereignis
- gemeinsames Gefährdungsmuster
- Duplikat
- Folgeereignis
- andere Beziehung

Diese Beziehungen sollen nicht nur als Freitext gespeichert werden. Sinnvoll ist langfristig eine eigene Verknüpfungsstruktur zwischen Reports.

## Analyse und Maßnahmen

Die Sicht des Meldenden ist von der späteren Bewertung durch Safety Manager oder Safety Committee zu trennen.

Der Report enthält:

- ursprüngliche Beschreibung
- Erkenntnis des Meldenden
- vorgeschlagene Maßnahme des Meldenden

Die spätere Analyse enthält:

- fachliche Bewertung
- Ursachen
- beitragende Faktoren
- erkannte Gefährdungen
- Risikobewertung
- beschlossene Maßnahmen

Maßnahmen sollen eigene Objekte sein. Sie benötigen Verantwortliche, Fälligkeiten, Status und später eine Wirksamkeitskontrolle.

## Safety Committee

In späteren Ausbaustufen soll PAOLO die Arbeit eines Safety Committees unterstützen.

Relevante Funktionen:

- Safety Meetings planen
- fällige oder überfällige Meetings anzeigen
- Reports einem Meeting zuordnen
- Maßnahmen einem Meeting zuordnen
- offene Maßnahmen aus früheren Meetings anzeigen
- Protokollnotizen erfassen
- Meeting-Zusammenfassungen erzeugen

Diese Funktionen gehören nicht in das Report-Kernmodell, müssen aber bei der langfristigen Architektur berücksichtigt werden.

## Import und Export

Report-Import und -Export sollen zunächst nur Reports betreffen.

Nicht Bestandteil des Report-Imports/-Exports:

- Anhänge
- Maßnahmen
- Audit-Log
- vollständiges Backup

Der CSV-Export und CSV-Import sollen die strukturierten Report-Felder enthalten, soweit sie Teil des Report-Kernmodells sind.

Beim Import sollen neue PAOLO-IDs erzeugt werden. Alte IDs aus einer CSV dürfen nicht als interne PAOLO-IDs übernommen werden.

## KI-Unterstützung

KI-Unterstützung ist langfristig denkbar, aber nicht Teil des MVP-Kerns.

Mögliche spätere Funktionen:

- dialogischer Meldeassistent
- Plausibilitätsprüfung
- Spam-/Missbrauchserkennung
- Klassifikationsvorschläge
- Hinweise auf fehlende Angaben
- Maßnahmenvorschläge
- Zusammenfassungen für Safety Meetings

KI-Funktionen müssen assistierend, abschaltbar und datenschutzkonform sein. Personenbezogene oder sensible Daten dürfen nur unter klar definierten Bedingungen verarbeitet werden. Der Kernprozess von PAOLO SMS muss auch ohne KI funktionieren.

## Aktueller nächster Umsetzungsschritt

Als nächster fachlicher Ausbau des Report-Kernmodells sollen strukturierte Klassifikationsfelder eingeführt werden:

- `activityArea`
- `activityType`
- `flightPhase`
- `launchType`
- `severity`

Alle Felder sollen zunächst optional sein.

Für das öffentliche Formular sollen nur wenige zusätzliche Felder angezeigt werden, damit die Meldung niedrigschwellig bleibt. Weitere Klassifikationen können im Backend durch den Safety Manager ergänzt werden.
## Sicherheitsbericht nach Safety-Committee-Sitzung

Nach einem Treffen des Safety Committees soll PAOLO SMS in einer späteren Ausbaustufe die Erstellung eines Sicherheitsberichts unterstützen.

Der Sicherheitsbericht fasst die Ergebnisse eines Berichtszeitraums zusammen und dokumentiert, welche Meldungen behandelt, welche Maßnahmen beschlossen und welche weiteren Aktionspunkte festgelegt wurden.

Der Bericht soll mindestens folgende Bestandteile enthalten.

### 1. Zusammenfassung

Der Safety Manager erfasst eine freie textliche Zusammenfassung des Berichtszeitraums.

Die Zusammenfassung kann enthalten:

- wichtigste Erkenntnisse aus den besprochenen Meldungen
- auffällige Muster oder wiederkehrende Themen
- Bewertung der aktuellen Sicherheitslage
- Hinweise auf beschlossene oder geplante Maßnahmen
- offene Punkte für den nächsten Berichtszeitraum

### 2. Entwicklung über Berichtszeiträume

Der Bericht enthält eine Tabelle über alle vergangenen Berichtszeiträume.

Spalten:

- Berichtszeitraum
- Anzahl der Berichte
- Anzahl der Berichte mit Priorität hoch
- beschlossene Maßnahmen im Berichtszeitraum
- abgeschlossene Maßnahmen insgesamt

Diese Tabelle soll die Entwicklung der Sicherheitsarbeit über mehrere Berichtszeiträume sichtbar machen. Sie dient nicht primär einer statistischen Bewertung einzelner Ereignisse, sondern der Nachvollziehbarkeit des SMS-Prozesses.

### 3. Ereignisse im Berichtszeitraum

Der Bericht enthält eine vom System erzeugte Tabelle mit den Ereignissen, die im Berichtszeitraum gemeldet wurden.

Spalten:

- Kurzbeschreibung
- Art der Meldung
- Schweregrad

### 4. Neu beschlossene Maßnahmen

Der Bericht enthält eine vom System erzeugte Tabelle mit den im Berichtszeitraum neu beschlossenen Maßnahmen.

Spalten:

- Kurztext
- Verantwortlicher
- Fälligkeitsdatum

### 5. Weitere Aktionspunkte

Der Safety Manager kann zusätzlich weitere Aktionspunkte erfassen, die nicht unmittelbar als formale Maßnahme aus einer Meldung abgeleitet wurden.

Spalten:

- Kurztext
- Verantwortlicher
- Fälligkeitsdatum

### 6. Kurzprotokoll

Der Safety Manager erfasst ein freies Kurzprotokoll der Safety-Committee-Sitzung.

Das Kurzprotokoll kann enthalten:

- wesentliche Diskussionspunkte
- getroffene Entscheidungen
- abweichende Einschätzungen
- offene Fragen
- Punkte für die nächste Sitzung

### 7. Fazit und Ausblick

Der Safety Manager erfasst ein freies Fazit mit Ausblick.

Der Abschnitt kann enthalten:

- zusammenfassende Bewertung des Berichtszeitraums
- wichtigste nächste Schritte
- erwartete Schwerpunkte im kommenden Zeitraum
- Hinweise auf geplante Sicherheitshinweise oder Schulungsmaßnahmen

### Umsetzungshinweis

Der Sicherheitsbericht gehört nicht zum Report-Kernmodell. Er setzt spätere Strukturen für Safety Meetings, Maßnahmen, Verantwortliche, Berichtszeiträume und Wirksamkeitskontrollen voraus.

Die Tabellen zu Ereignissen und Maßnahmen sollten möglichst aus den vorhandenen Systemdaten erzeugt werden. Freitextabschnitte wie Zusammenfassung, Kurzprotokoll sowie Fazit und Ausblick werden durch den Safety Manager erfasst.
Für den MVP genügt Einfachauswahl. Mehrfachauswahl kann später ergänzt werden, falls sich das aus der Praxis als erforderlich erweist.
