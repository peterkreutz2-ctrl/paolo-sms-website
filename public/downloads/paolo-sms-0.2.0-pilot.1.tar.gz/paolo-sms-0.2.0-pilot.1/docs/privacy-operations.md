# Datenschutz-Betrieb (Betreiber-/Admin-Leitfaden)

Diese Datei beschreibt die in PAOLO SMS umgesetzten Datenschutzfunktionen aus
**Betriebssicht** — wofür sie gedacht sind, wie sie bedient werden und wo ihre
Grenzen liegen.

> **Keine Rechtsberatung.** Dieses Dokument ersetzt keine juristische Prüfung.
> Fristen, Meldepflichten, Aufbewahrungsgründe und Textinhalte müssen Betreiber
> bzw. Datenschutzbeauftragte **vor dem Produktivbetrieb** eigenständig rechtlich
> prüfen lassen. PAOLO trifft keine rechtlichen Entscheidungen und versendet keine
> automatischen Meldungen.

## Überblick Datenschutzfunktionen

| Funktion | Ort | Zweck |
|---|---|---|
| Rechtliche Angaben | `/dashboard/settings` (Sektion „Rechtliche Angaben") | Betreiberdaten für Impressum/Datenschutz pflegen |
| Impressum | `/impressum` (öffentlich) | Pflichtangaben anzeigen |
| Datenschutzerklärung | `/datenschutz` (öffentlich) | Datenschutzangaben anzeigen |
| Datenschutzprozesse | `/dashboard/privacy` | Checklisten: Betroffenenanfragen, Anonymisierung, Vorfälle |
| Einwilligung im Meldeformular | `/dashboard/privacy` (Abschnitt „Einwilligung im Meldeformular") | Datenschutz-Einwilligung auf `/submit-report` ein-/ausschalten, Text pflegen |
| Anonymisierung | Meldungs-Detailseite + Abschluss-/Ausblenden-Dialog | Strukturierte Melderdaten reduzieren |
| Betroffenenanfragen | `/dashboard/privacy/requests` | Personenbezogene Bezüge suchen |
| Datenschutzvorfälle | `/dashboard/privacy/incidents` | Incident-Response dokumentieren |
| Audit-Log | `/dashboard/audit` | Sicherheitsrelevante Aktionen nachvollziehen |

Zugriff auf die internen Datenschutzfunktionen haben nur **Administratoren** und
**Safety Manager** (`admin` / `safety_manager`). `instructor`/`member` haben
keinen Zugriff.

## Rechtliche Angaben pflegen

- Unter `/dashboard/settings` → „Rechtliche Angaben" die Betreiberdaten pflegen
  (Betreiber, Adresse, Kontakt, Vertretung, Aufsichtsbehörde, Datenschutz-
  Verantwortliche, Hosting-/Aufbewahrungshinweise usw.).
- Diese Angaben speisen `/impressum` und `/datenschutz`.
- Fehlende Felder werden öffentlich als „noch nicht hinterlegt" gekennzeichnet.

## Impressum und Datenschutzerklärung prüfen

- Nach dem Pflegen der rechtlichen Angaben `/impressum` und `/datenschutz`
  öffentlich (ausgeloggt) kontrollieren.
- Die angezeigten Texte sind **prüfpflichtig** — Vollständigkeit und Richtigkeit
  liegen beim Betreiber bzw. der/dem Datenschutzbeauftragten.

## Datenschutzprozesse im Adminbereich

- `/dashboard/privacy` fasst die organisatorischen Abläufe als Checklisten
  zusammen: Betroffenenanfragen, Anonymisierung nach Abschluss, Incident-Response.
- Die Seite verlinkt die Werkzeuge „Betroffenenanfrage vorbereiten" und
  „Datenschutzvorfälle dokumentieren".
- Grundlage: [`docs/data-protection-concept.md`](data-protection-concept.md).

## Datenschutz-Einwilligung im Meldeformular

- Unter `/dashboard/privacy` → „Einwilligung im Meldeformular" wird die
  Abfrage auf „Sicherheitsmeldung einreichen" ein- oder ausgeschaltet.
  **Voreinstellung: eingeschaltet** — auch in Installationen, die vor dieser
  Funktion bestanden. Nach einem Update erscheint das Kontrollkästchen also
  sofort.
- Eingeschaltet: Ein Melder muss das zunächst leere Kontrollkästchen
  ankreuzen, bevor „Meldung absenden" freigegeben wird. Der Server prüft das
  zusätzlich.
- Der Text ist anpassbar. Voreingestellt ist ein abgestimmter Standardtext;
  „Standardtext einsetzen" stellt ihn wieder her. `[Datenschutzerklärung]` muss
  genau einmal enthalten bleiben — an dieser Stelle erscheint der Link auf
  `/datenschutz`. Den Wortlaut vor einer Änderung rechtlich prüfen lassen.
- Zu jeder Meldung mit Einwilligung speichert PAOLO Zeitpunkt,
  Einwilligungstext und die gültige Datenschutzerklärung als Nachweis an der
  Meldung (Datenschutzkonzept, Abschnitt 11b). Ältere Meldungen und Meldungen
  bei ausgeschalteter Abfrage haben keinen Nachweis.
- Ändert sich Schalter, Einwilligungstext oder Datenschutzerklärung, während
  jemand das Formular ausfüllt, wird die Einreichung abgelehnt; der Melder lädt
  die Einwilligung neu und stimmt erneut zu. Seine Eingaben bleiben erhalten.
  Änderungen an `/dashboard/admin/legal` wirken deshalb auch auf gerade offene
  Meldeformulare.
- Jede Änderung an Schalter oder Text steht im Audit-Log, beim Text mit
  Wortlaut vorher und nachher.
- Wie ein Widerruf der Einwilligung behandelt wird, regelt der Betreiber
  organisatorisch; PAOLO bietet dafür keinen eigenen Ablauf.

## Anonymisierung beim Abschluss oder Ausblenden einer Meldung

- Wird eine Meldung von `admin`/`safety_manager` auf **`closed`** oder
  **`hidden`** gesetzt, erscheint ein Hinweisdialog zur Anonymisierungsprüfung mit
  drei Optionen:
  1. Abbrechen
  2. Status speichern, Anonymisierung später manuell prüfen
  3. Status speichern und strukturierte Melderdaten jetzt anonymisieren
- Die Anonymisierung ist auch nachträglich auf der Meldungs-Detailseite im
  Abschnitt „Anonymisierung" verfügbar (nur bei abgeschlossenen/ausgeblendeten
  Meldungen).
- Anonymisiert werden ausschließlich **strukturierte Melderdaten**
  (Name, Rolle, Kontakt). Fachliche Report-Daten bleiben erhalten.
- Jeder Vorgang wird im Audit-Log als `REPORT_ANONYMIZED` protokolliert (nur
  Feldnamen, keine Klartext-Melderdaten).

## Grenzen: Freitexte und Anhänge bleiben manuell zu prüfen

- Die technische Anonymisierung entfernt **keine** Inhalte aus Freitexten
  (z. B. ausführliche Beschreibung, Notizen) und **löscht keine Anhänge**.
- Enthält ein Freitext oder Anhang personenbezogene Daten, sind diese **manuell**
  zu prüfen und ggf. gesondert zu bearbeiten.
- Es gibt bewusst **keine** automatische Freitext- oder Anhangsanonymisierung und
  keine Massenverarbeitung.

## Betroffenenanfragen vorbereiten

- `/dashboard/privacy/requests` ist eine **Such- und Prüfhilfe** für Auskunfts-
  und Löschanfragen nach DSGVO.
- Die Suche startet nur nach expliziter Eingabe und durchsucht strukturierte
  Felder sowie relevante Freitexte in Meldungen, Notizen und Maßnahmen.
- Ergebnisse zeigen Typ, Kurzinfo, Link und die auslösende Datenstelle — ohne
  lange Freitextauszüge.
- Wichtig:
  - Die Seite **löscht keine Daten**.
  - Vor Löschung/Anonymisierung **Aufbewahrungsgründe prüfen**.
  - **Anhänge** werden nicht inhaltlich durchsucht und sind manuell zu prüfen.

## Konten löschen

In der Zugangs- und Rollenverwaltung (`/dashboard/users`) kann ein Administrator oder
Safety Manager ein Konto im eigenen Zuständigkeitsbereich endgültig löschen („Konto löschen“,
Bestätigung mit der vollständigen E-Mail-Adresse).

- **Gelöscht wird:** das Konto beim Anmeldedienst (bei Better Auth die Zeile in der
  lokalen Datenbank mit Passwort und Sitzungen), seine Sitzungen und seine
  Rollenzuweisungen.
- **Unverändert bleibt:** alles, was die Kennung des Kontos trägt — Meldungen, Notizen,
  Besprechungen, SMS-Dokumente und Audit-Einträge. Die Kennung wird nicht ersetzt oder
  anonymisiert; die Anzeige zeigt dafür nur noch eine gekürzte Kennung. Namen in
  Freitexten bleiben ebenfalls (siehe oben).
- **Audit:** „Konto gelöscht“ mit Kennung und bisheriger Rolle, ohne Name und E-Mail.
- **Backups** enthalten das Konto weiter; ein Restore stellt bei Better Auth das Konto
  und seine Rollen wieder her (siehe `backup-restore.md`).
- Eine **Löschanfrage nach DSGVO** wird weiterhin über die Datenschutzprozesse und die
  Betroffenenanfrage-Suche bearbeitet, nicht über diese Funktion; die Kontolöschung
  ist nur ein Baustein davon. Aufbewahrungsgründe sind vorher zu prüfen.

## Datenschutzvorfälle dokumentieren

- `/dashboard/privacy/incidents` dient der Dokumentation und Nachverfolgung von
  Datenschutzvorfällen (Incident-Response).
- Erfasst werden u. a. Titel, Entdeckungszeitpunkt/-quelle, Beschreibung,
  betroffene Datenkategorien, geschätzte Zahl Betroffener, Sofortmaßnahmen sowie
  Status, Risikobewertung, Meldeentscheidung, Begründung und Folgemaßnahmen.
- Status- und Meldeentscheidungsänderungen werden im Audit-Log protokolliert
  (`PRIVACY_INCIDENT_CREATED` / `PRIVACY_INCIDENT_UPDATED`).

### Was ist ein Datenschutzvorfall? (Beispiele aus PAOLO)

- Unberechtigter Zugriff auf eine Meldung
- Anhang versehentlich öffentlich zugänglich
- CSV-Export an eine falsche Person versendet
- Kompromittierter Benutzerzugang
- Falsche Rollen- oder Organisationszuordnung
- Personenbezogene Daten unbeabsichtigt gelöscht oder verändert

### Zuständige Aufsichtsbehörde finden

- Zuständig ist in der Regel die Datenschutzaufsichtsbehörde am Sitz des/der
  Verantwortlichen bzw. Betreibers.
- Für Vereine und private Flugschulen ist dies meist die Landesdatenschutz-
  aufsicht des jeweiligen Bundeslandes.
- Die zuständige Behörde in den Rechtlichen Angaben (`/dashboard/settings#rechtliche-angaben`)
  hinterlegen; sie wird dann auf `/dashboard/privacy` angezeigt. PAOLO codiert
  keine feste Behörde hart.

### Dokumentation auch ohne Meldung

- Auch wenn keine Meldung an die Aufsichtsbehörde erfolgt, sollten Entscheidung
  und Begründung dokumentiert werden (Rechenschaftspflicht) — je Vorfall unter
  `/dashboard/privacy/incidents`.

### 72-Stunden-Hinweis

- Pro Vorfall wird eine grobe Frist `Entdeckt am + 72 Stunden` (Orientierung an
  Art. 33 DSGVO) angezeigt.
- Dies ist **nur eine Orientierung**. PAOLO sendet **keine automatische Meldung**
  an Aufsichtsbehörden und **keine automatische Benachrichtigung** Betroffener.
- Ob eine Meldung erforderlich ist, muss der Betreiber bzw. die/der
  Datenschutzbeauftragte prüfen.

## Audit-Log prüfen

- `/dashboard/audit` protokolliert sicherheits- und datenschutzrelevante
  Aktionen (u. a. Statusänderungen, Anonymisierungen, Rollenvergaben,
  Datenschutzvorfälle) — nur lesend, neueste zuerst.
- Dient der Nachvollziehbarkeit gegenüber Betroffenen und internen Prüfungen.

## Datenschutz-Testlauf vor Pilot-/Produktivbetrieb

Vor dem Pilot- oder Produktivbetrieb empfiehlt sich ein Durchlauf:

1. Rechtliche Angaben vollständig pflegen und `/impressum` + `/datenschutz`
   ausgeloggt prüfen.
2. Rollen prüfen: nur `admin`/`safety_manager` erreichen die internen
   Datenschutzfunktionen.
3. Anonymisierung an einer Testmeldung durchspielen (Abschluss-Dialog +
   nachträgliche Anonymisierung) und Audit-Eintrag kontrollieren.
4. Betroffenenanfrage-Suche mit einem Testbegriff ausführen und Trefferanzeige
   prüfen.
5. Einen Test-Datenschutzvorfall erfassen, Status/Meldeentscheidung ändern und
   Audit-Einträge prüfen.
6. Sicherstellen, dass DB-Änderungen/Migrationen gemäß
   [`docs/database-migrations.md`](database-migrations.md) sicher eingespielt sind.
7. Offene rechtliche Punkte (Fristen, Aufbewahrung, Textinhalte) mit
   Datenschutzbeauftragten klären.

## Weiterführend

- [`docs/data-protection-concept.md`](data-protection-concept.md) — Datenschutzkonzept
- [`docs/database-migrations.md`](database-migrations.md) — sichere DB-Änderungen
- [`docs/roles-and-permissions.md`](roles-and-permissions.md) — Rollen und Rechte
