| Max. Anhanggröße (aktuell) | 4 MiB |# Containerisierungs-Roadmap für PAOLO SMS

> **Strategiedokument, keine Umsetzung.** Dieses Dokument beschreibt einen
> möglichen Weg, PAOLO SMS als selbst betriebene, Docker-basierte Software für
> Vereine und Gleitschirmschulen nutzbar zu machen. Es ändert keinen Code und
> trifft keine endgültigen Architektur- oder Rechtsentscheidungen. **Keine
> Rechtsberatung** — die Compliance-Einordnung ist bewusst vorsichtig formuliert
> und ersetzt keine Prüfung durch Betreiber, Datenschutzbeauftragte oder
> Juristinnen und Juristen.

Verwandte Dokumente: [`data-protection-concept.md`](data-protection-concept.md),
[`production-readiness.md`](production-readiness.md),
[`database-migrations.md`](database-migrations.md),
[`privacy-operations.md`](privacy-operations.md),
[`installation-decision-guide.md`](installation-decision-guide.md),
[`docker-vm-deployment.md`](docker-vm-deployment.md).

> **Migrationsstand 2026-08-27:** Die historischen Aussagen unten zur fehlenden
> Replay-Fähigkeit sind überholt. Der vollständige SQL-Satz ist inzwischen aus
> jedem konsistenten Präfix wiederholbar; `scripts/migrate.psql` führt ihn atomar
> aus. Maßgeblich ist [database-migrations.md](database-migrations.md).

> **Nachtrag (2026-07-28).** Seit den Status-/Phasennotizen unten (Stand
> größtenteils 2026-07-07/08) ist Folgendes hinzugekommen, ohne dass diese
> Roadmap durchgehend aktualisiert wurde:
>
> - **Docker-VM-Produktionspfad existiert bereits:**
>   [`docker-vm-deployment.md`](docker-vm-deployment.md) beschreibt einen
>   konkreten, umgesetzten Ein-Server-Betrieb mit `docker-compose.prod.yml`,
>   Nginx-Reverse-Proxy, Let's-Encrypt-TLS (Certbot) und einem täglichen
>   verschlüsselten DB-Backup-Cron. Ein Teil der unten als offen geführten
>   Phase-D-Themen (Reverse Proxy/TLS, Secrets-Handling, DB-Backup) ist damit
>   umgesetzt und dokumentiert — **nicht** umgesetzt sind weiterhin ein
>   automatischer Migrationsrunner, ein real durchgeführter Restore-Test und ein
>   echter produktiver Self-Hosting-Pilotbetrieb.
>   AWS-spezifische Infrastruktur ist getrennt in
>   [`runbooks/aws-account-and-ec2-provisioning.md`](runbooks/aws-account-and-ec2-provisioning.md)
>   dokumentiert.
> - **Better Auth ist implementiert** (`AUTH_MODE=betterauth`, Migration
>   `0024_add_better_auth.sql`, seit Dev-Log 2026-07-18) — als **zusätzliche**,
>   selbst betriebene Auth-Option neben Clerk. Das ist **keine** abgeschlossene
>   Phase C: Ob Better Auth bereits vollständig als produktive Clerk-Alternative
>   geeignet ist, ist ausdrücklich noch nicht entschieden (siehe
>   [`installation-decision-guide.md`](installation-decision-guide.md)
>   Abschnitt 4). Die ~34 Clerk-Kopplungsstellen und die 4
>   `clerk_user_id`-Spalten aus der Analyse in Abschnitt 3.4 bestehen unverändert
>   fort; Better Auth läuft parallel über denselben `AUTH_MODE`-Schalter.
> - **Betreiber-/Installationsentscheidung konsolidiert:** Die praktische
>   Empfehlung für Vereine/Flugschulen (Installationsart, Auth-Provider,
>   Datenbank) steht jetzt zentral in
>   [`installation-decision-guide.md`](installation-decision-guide.md); dieses
>   Dokument bleibt die strategische Analyse/Historie dahinter.

---

## 1. Zielbild

- **PAOLO als Docker-basierte Installation:** Eine Instanz soll sich mit
  überschaubarem Aufwand per Container (App + PostgreSQL + Objektspeicher) durch
  einen Verein, eine Flugschule oder deren IT-Dienstleister betreiben lassen.
- **Betreiber-Modell:** Verantwortlicher nach DSGVO ist voraussichtlich der
  jeweilige Betreiber der Instanz, nicht der Softwareautor (vgl.
  `data-protection-concept.md` §17–§23). Die Containerisierung ist die technische
  Voraussetzung dafür, dieses Modell überhaupt zu ermöglichen.
- **Unabhängigkeit von verwalteten Diensten:** Ziel ist, PAOLO ohne zwingende
  Bindung an **Vercel** (Hosting), **Neon** (Datenbank) und **Vercel Blob**
  (Dateiablage) betreiben zu können.
- **Clerk (Auth):** Ablösung wird geprüft, aber Aufwand und Risiko realistisch
  bewertet. Clerk ist die am tiefsten verankerte Abhängigkeit (siehe Abschnitt 3
  und Phase C) und bleibt zunächst extern.

**Leitprinzip:** Erst die *Infrastruktur*-Abhängigkeiten (DB, Storage, Hosting)
lösen, die architektonisch bereits gut vorbereitet sind — die *Identitäts*-
Abhängigkeit (Clerk) zuletzt, weil dort der Aufwand und das Risiko am höchsten
sind.

---

## 2. Planungsannahmen für typische Instanzen

Diese Annahmen beschreiben eine **typische** PAOLO-Instanz und dienen als Grundlage
für die technischen Entscheidungen in Phase A (DB-/Storage-Umbau) und Phase D
(Betriebshärtung). Es handelt sich um Planungsgrößen, keine harten Grenzen.

### 2.1 Kennzahlen pro Instanz

| Kennzahl | Annahme |
|---|---|
| Typische Organisation | Verein oder Flugschule |
| Erwartete Benutzer | 1–20 |
| Gleichzeitige Benutzer | 0–5 |
| Meldungen pro Tag | 0–5 |
| Meldungen pro Jahr | 20–250 |
| Anhänge pro Meldung | 0–5 — nur etwa **jede fünfte** Meldung hat überhaupt Anhänge |
| Max. Anhanggröße (aktuell) | 4 MiB |
| Aufbewahrungsdauer | ca. 10 Jahre |
| Tolerierbare Ausfallzeit | bis zu 2 Tage |
| Backup-Intervall | mindestens monatlich, besser wöchentlich |

**Typische Anhänge:** Fotos, IGC-Dateien (200–500 KB), kurze Videos bis 60
Sekunden (MP4, ebenfalls im 4-MiB-Limit), PDF-Dateien bis ca. 5 Seiten.

*Grobe Größenordnung:* Selbst am oberen Rand (≈250 Meldungen/Jahr, davon ~20 % mit
Anhängen, bis 4 MiB) bleibt das jährliche Datenvolumen im Bereich weniger GB — also
klein und unkritisch. PAOLO ist **keine** Massendaten- oder Medienplattform.

### 2.2 Ableitungen für die erste Container-Version

- **Kleine bis mittlere Einzelinstanz** mit **geringer gleichzeitiger Last**.
- **Keine Hochlast- oder Massendatenplattform.**
- **Ein App-Container plus PostgreSQL** reicht zunächst; ein eigener
  Objektspeicher (Volume/MinIO) kommt in Phase A3 hinzu.
- **Kein Kubernetes, kein Load-Balancing, kein Clusterbetrieb** als Ziel der
  ersten Container-Version.
- **Robuste Einfachheit ist wichtiger als maximale Skalierung.**
- **Backup/Restore und Wartbarkeit sind wichtiger als Performanceoptimierung.**
- **Ausfallzeit und Datenverlust getrennt betrachten** (siehe 2.3).

### 2.3 Ausfallzeit und Datenverlust getrennt betrachtet

- **Ausfallzeit:** bis zu **2 Tage** tolerierbar. Daraus folgt: **kein**
  Hochverfügbarkeits-/Cluster-Setup nötig; ein geplanter Neustart oder eine kurze
  Wartung ist unkritisch.
- **Datenverlust:** ärgerlich, aber normalerweise **kein Showstopper**, weil
  regelmäßig **Sicherheitsbesprechungen** stattfinden und Erkenntnisse dort
  gesichert/besprochen werden. **Kritisch** sind vor allem **Meldungen seit dem
  letzten Backup bzw. seit der letzten Sicherheitsbesprechung** — dieser Zeitraum
  bestimmt das reale Verlustrisiko.

### 2.4 Backup-Hinweis

- **Mindestens monatliches** Backup.
- **Besser wöchentliches** Backup.
- **Restore-Test gelegentlich** durchführen, besonders **vor größeren Updates**.
- Das **Backup-Intervall kann am Sicherheitsmeeting-Intervall ausgerichtet**
  werden — so bleibt der maximale Verlust auf „seit der letzten Besprechung"
  begrenzt.

Diese Größen fließen in **Phase D** (Backup/Restore, Speicher-/Löschkonzept) ein.

---

## 3. Aktuelle Kopplungsstellen (Repository-Analyse)

Stand der Analyse auf `main`. Die Einschätzung stützt sich auf die real
vorhandenen Dateien.

### 3.1 Vercel / Next.js Deployment
- **Kein** `Dockerfile`, **kein** `docker-compose`, **keine** `vercel.json`
  vorhanden — Containerisierung ist „grüne Wiese".
- `next.config.ts` ist leer (kein `output: "standalone"`). Für ein schlankes
  Container-Image ist `output: "standalone"` sinnvoll (App-Änderung, hier nicht
  vorgenommen).
- `proxy.ts` im Projektwurzelverzeichnis = Clerk-Middleware
  (`clerkMiddleware()`); in Next.js 16 ist `proxy.ts` die Middleware-Konvention.
- Next.js 16 App Router, React 19, Node-Runtime → grundsätzlich gut über ein
  `node`-Basisimage containerisierbar.
- **Randnotiz:** `app/layout.tsx` lädt die Schrift `Inter` über
  `next/font/google` (Build-Zeit-Bezug). In einer Build-Umgebung ohne
  Internetzugang ggf. Font self-hosten.

### 3.2 Neon / Datenbankzugriff
- **[Phase A2 umgesetzt]** `lib/db/index.ts` nutzt inzwischen `Pool` aus `pg`
  und `drizzle-orm/node-postgres` (Standard-PostgreSQL-Treiber). Zuvor:
  `@neondatabase/serverless` + `drizzle-orm/neon-serverless` (WebSocket-basiert,
  Neon-Proxy-Endpunkt).
- `drizzle.config.ts`: Dialekt `postgresql`, Verbindung aus `DATABASE_URL`
  (unverändert).
- **Ergebnis:** Der Treiberwechsel betraf im Kern **eine Datei**
  (`lib/db/index.ts`) plus die Dependency `pg`/`@types/pg`; Drizzle-Schema und
  Queries blieben unverändert. Die App kann damit gegen eine normale PostgreSQL
  laufen; Neon ist als Datenbankdienst **technisch nicht mehr zwingend** (ein
  Neon-URL funktioniert weiterhin).
- `@neondatabase/serverless` wird **noch nicht entfernt**: das Wartungsskript
  `scripts/cleanup-test-data-before-production.mjs` nutzt es weiterhin direkt, und
  es ist optionaler Peer von `drizzle-orm`.

### 3.3 Vercel Blob / Dateiablage
- **Bereits sauber abstrahiert:** `lib/storage/storage-provider.ts` definiert ein
  `StorageProvider`-Interface; `lib/storage/index.ts` delegiert an einen
  Provider; `lib/storage/vercel-blob-storage.ts` ist die konkrete
  Vercel-Blob-Implementierung (`put`/`get`/`del`, `access: "private"`).
- **Konsequenz:** Ein lokaler oder S3-/MinIO-Provider lässt sich als **neue
  Implementierung des bestehenden Interfaces** ergänzen; nur die
  Provider-Instanziierung in `lib/storage/index.ts` muss (idealerweise
  env-gesteuert) umgestellt werden. **Geringer Aufwand** dank vorhandener
  Abstraktion.
- Offene TODOs im Code: Direkt-Uploads (große Dateien), Multipart, Signed URLs,
  Malware-Scan — heute serverseitig geroutet, 4-MiB-Kappung wegen des
  4,5-MB-Request-Limits von Vercel.

### 3.4 Clerk / Authentifizierung und Benutzerverwaltung
- **Tiefste Kopplung.** Clerk wird in rund **34 Anwendungsdateien** verwendet
  (ohne Lockfiles/Worktree-Kopien).
- Verankerung:
  - `app/layout.tsx`: `ClerkProvider`.
  - `proxy.ts`: `clerkMiddleware()`.
  - `lib/auth/user-roles.ts` und viele Server Actions/Seiten: `auth()` liefert die
    `userId`.
  - `lib/actions/user-roles.ts`: `clerkClient` löst **E-Mail ↔ Benutzer** auf und
    liefert Profildaten — die **Admin-Benutzerverwaltung hängt an Clerks
    User-Directory**.
  - `app/sign-in/...`, `app/sign-up/...`: Clerk-Komponenten.
- **Clerk-User-ID in 4 DB-Spalten** (jeweils Text, referenziert die Clerk-ID):
  - `user_roles.clerk_user_id`
  - `report_notes.author_clerk_user_id`
  - `safety_meetings.created_by_clerk_user_id`
  - `audit_logs.clerk_user_id` (nullable)
- **Rollen/Rechte sind NICHT an Clerk gekoppelt:** Rollen liegen in den Tabellen
  `roles`/`user_roles`, die Rechte-Matrix in `lib/auth/permissions.ts`. Gekoppelt
  ist ausschließlich die **Identität** (die `userId`-Zeichenkette) und die
  **Profilanzeige** (Name/E-Mail aus der Clerk-API).
- **Keine lokale `users`-Tabelle:** Anzeige-Namen und E-Mail-Adressen werden zur
  Laufzeit aus Clerk geholt, nicht lokal persistiert (vgl.
  `production-readiness.md`).

### 3.5 Environment Variables / Secrets
- Aus `.env.example`: `DATABASE_URL`; Clerk (`NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY`,
  `CLERK_SECRET_KEY`, `NEXT_PUBLIC_CLERK_SIGN_IN_URL`,
  `NEXT_PUBLIC_CLERK_SIGN_UP_URL`, zwei Fallback-Redirect-URLs);
  `BLOB_READ_WRITE_TOKEN`.
- Heute lokal in `.env.local` bzw. als Vercel-Umgebungsvariablen. Für Container
  ist ein bewusstes Secrets-Handling nötig (Env-Datei/Secrets-Manager, siehe
  Phase D).

### 3.6 Migrationen / DB-Setup
- SQL-Migrationen unter `drizzle/` (`0000`–`0016`), Schema als Quelle der Wahrheit
  in `lib/db/schema.ts`.
- **Buchhaltung unvollständig** (siehe `database-migrations.md`): `drizzle-kit
  migrate` darf nicht blind laufen; Migrationen werden idempotent/gezielt
  angewandt. Für Container ist ein **kontrollierter Migrationsschritt** beim
  Start/Deploy zu definieren.

### 3.7 Uploads / Anhänge
- 25-MB-Kappung, serverseitig geroutete Uploads, private Ablage; Download über
  `app/dashboard/reports/[reportId]/attachments/[attachmentId]/download/route.ts`.
- Für Self-Hosting: lokales Volume oder S3-/MinIO-Bucket; Zugriffsschutz und
  Löschung von verwaisten Objekten beachten.

### 3.8 E-Mail / externe Dienste
- **Kein eigener Mail-Dienst** im Repo gefunden (kein nodemailer/resend/SMTP
  o. Ä.). Auth-bezogene E-Mails (Sign-in-Links) laufen heute **über Clerk**.
- **Konsequenz:** Eine Clerk-Ablösung erzeugt einen **neuen** Bedarf an einem
  Mail-Versand (SMTP/Transaktionsmail) für Login-/Einladungsflüsse — mit
  entsprechendem neuen Dienstleister-/AVV-Thema (siehe Abschnitt 6).

### Kopplungs-Übersicht

| Bereich | Kopplung | Betroffene Stellen | Ablöse-Aufwand |
|---|---|---|---|
| Storage | **wählbar** (A3: lokaler FS-Provider + Vercel Blob) | `lib/storage/*` | gering |
| Datenbank-Treiber | **abgelöst** (A2: `pg`/node-postgres) | `lib/db/index.ts` | erledigt |
| Hosting/Deployment | **keine** (noch nichts da) | `next.config.ts`, neu: Dockerfile | mittel |
| Migrationen | **mittel** (Buchhaltung unvollständig) | `drizzle/*` | mittel |
| Auth/Identität | **eng** (34 Dateien, 4 Spalten, kein users-Table) | Clerk-weit | hoch |

---

## 4. Phasenplan

### Phase A — App + eigene DB + eigener Storage containerisieren (Clerk bleibt extern)
Ziel: PAOLO läuft als Container gegen eine selbst betriebene PostgreSQL und einen
selbst betriebenen Objektspeicher; Authentifizierung weiter über Clerk (Cloud).

**Status:** **A1 (Docker-Grundlage) erledigt**, **A2 (Standard-PostgreSQL-Treiber
+ lokaler PostgreSQL-Service in Compose) umgesetzt**, **A2.4 (Fresh-DB-Init
dokumentiert)**, **A2.5 (Migrationslücke `safety_meetings` geschlossen)**, **A2.6
(Drift-Abgleich durchgeführt)**, **A2.7 (8 Spalten-Lücken via `0018` geschlossen)**,
**A2.8 (Fresh-DB-Verifikation: real bestätigt am 2026-07-07 — echter Fresh-Apply
0000–0018 gegen temporäre `postgres:16`, voller MATCH gegen `schema.ts` inkl.
Typen/Defaults/NOT NULL/PK/FK/Indizes; siehe §9.3)**. Migrationen decken `schema.ts`
vollständig ab. **A3 (eigener Storage): verifiziert** — lokaler Dateisystem-Storage
per Env wählbar, im Container getestet (put/get/delete PASS nach Volume-Ownership-Fix
im `Dockerfile`); Vercel Blob bleibt Default; MinIO/S3 später optional. Automatischer
Migrationsrunner beim Containerstart bleibt ausgeschlossen. **Docker-Build und
Compose-Start am 2026-07-07 real durchgeführt (PASS, siehe §9.3).**

- **[A1 – erledigt]** `output: "standalone"` in `next.config.ts`, Multi-Stage
  `Dockerfile`, `.dockerignore`, minimaler `docker-compose.yml` (nur App-Service)
  und `.env.docker.example`. **Noch kein** DB-Treiber-/Storage-Wechsel; Neon und
  Vercel Blob werden weiterhin extern genutzt, Clerk bleibt extern.
- **[A2 – umgesetzt]** DB-Treiber von `@neondatabase/serverless` auf `pg`
  + `drizzle-orm/node-postgres` umgestellt (`lib/db/index.ts`, pragmatisches
  Pooling für kleine Instanzen). Zusätzlich ein **lokaler PostgreSQL-Service
  (`postgres:16`) in `docker-compose.yml`** mit eigenem Volume und Healthcheck
  vorbereitet; die App zeigt über `DATABASE_URL` (Host = Service-Name `db`) auf
  diesen Compose-Postgres. **Offen:** kontrolliertes Migrations-/Baselining-
  Vorgehen für eine frische DB — **kein automatischer Migrationsrunner** beim
  Containerstart; Einspielung manuell/idempotent gemäß `database-migrations.md`.
- **[A2.4 – dokumentiert]** Initialisierung frischer Compose-DBs in
  `database-migrations.md` beschrieben (Reihenfolge, `--> statement-breakpoint`,
  Nicht-Idempotenz nur auf leerer DB unkritisch). **Befund:** `safety_meetings`
  ist in `schema.ts` deklariert, hatte aber **keine** Migration → ein reines
  Abspielen von `drizzle/*.sql` hätte ein unvollständiges Schema erzeugt.
- **[A2.5 – umgesetzt]** Migrationslücke geschlossen: `drizzle/0017_add_safety_meetings.sql`
  (idempotent, `CREATE TABLE IF NOT EXISTS` + FK-Guard, Stil wie 0009/0016), read-only
  gegen die bestehende Neon-DB gegengeprüft (Spalten/Typen/FK-Name identisch).
  **Nicht ausgeführt**; `_journal.json` um den 0017-Eintrag ergänzt (kein Snapshot,
  Muster wie 0009–0016).
- **[A2.6 – durchgeführt]** Vollständiger Drift-Abgleich `schema.ts` ↔ DB ↔
  Migrationen (read-only). **DB deckt schema.ts vollständig**; die **Migrationen**
  hatten **8 Spalten-Lücken** (`organizations.safety_meeting_interval_months`,
  `measures.assigned_to_text`, `reports.reporter_name/role/contact`,
  `reports.injury_severity/damage_severity/is_reportable_accident`) — per früherem
  `push` entstanden. Details in `database-migrations.md`.
- **[A2.7 – umgesetzt]** Die 8 Spalten-Lücken mit `drizzle/0018_add_missing_drift_columns.sql`
  geschlossen (idempotent, `ALTER TABLE … ADD COLUMN IF NOT EXISTS …`, Typen exakt
  nach read-only-Introspektion). **Nicht ausgeführt**, No-op auf bestehenden DBs;
  `_journal.json` um den 0018-Eintrag ergänzt (kein Snapshot, Muster wie 0009–0017).
- **[A2.8 – teilweise]** Fresh-DB-Verifikation: **keine** sichere leere Test-DB
  verfügbar (kein Docker/`psql`/lokaler PostgreSQL). Ersatzweise **statische
  Vorwärts-Simulation** von 0000–0018 → **voller MATCH** mit `schema.ts` (11
  Tabellen, alle Spalten; AI-Tabellen erzeugt+gedroppt). Grenzen: Typen/Defaults/
  FK/Index/Ausführbarkeit nicht real geprüft. **Offen (letztes Gate):** echter
  Fresh-Apply auf einer Docker-fähigen Maschine gegen eine temporäre leere
  PostgreSQL, dann read-only gegen `schema.ts`. **Erst danach** ein geführtes
  Init-Script. Details in `database-migrations.md`.
- **[A3 – begonnen]** Lokaler Dateisystem-Storage `lib/storage/local-file-storage.ts`
  hinter dem bestehenden `StorageProvider`-Interface ergänzt; Provider per Env
  wählbar (`STORAGE_PROVIDER=local|vercel-blob`, Default `vercel-blob`),
  `LOCAL_STORAGE_DIR` (Default `/app/storage`). Compose mountet dafür das Volume
  `paolo-storage-data`. **Vercel Blob nicht entfernt**, bleibt Default und
  Alternative. Kein öffentlicher Direktlink — Download weiter über die geschützte
  Route; Pfade gegen Path-Traversal abgesichert. **MinIO/S3** bleibt eine spätere,
  optionale Ausbaustufe. **Backup:** DB **und** Storage-Volume gemeinsam betrachten
  (bei Restore müssen beide zusammenpassen).
- **[A – offen]** Kontrollierten Migrationsschritt für den Container-Start
  definieren (idempotente SQL, siehe `database-migrations.md`).
- Clerk bleibt als externer Dienst konfiguriert (Keys via Env).

> **Hinweis zum Docker-Build:** Der Standalone-Build lädt die Schrift `Inter`
> über `next/font/google` (Build-Zeit) — die Build-Umgebung braucht dafür
> Netzwerkzugang. Zudem können build-zeitige `NEXT_PUBLIC_*`-Variablen (z. B. der
> Clerk-Publishable-Key) für statisch gerenderte Seiten nötig sein; dies wird in
> A2/A3 verfeinert. **Update 2026-07-07:** `docker build` und `docker compose up`
> wurden real ausgeführt (PASS); die öffentlichen Seiten (inkl. Clerk-`/sign-in`)
> rendern ohne Build-Zeit-`NEXT_PUBLIC_*`. Details in §9.3.

### Phase B — Vollständige Ablösung von Vercel, Neon und Vercel Blob
Ziel: Keine funktionale Abhängigkeit mehr von diesen drei Diensten.

- Hosting vollständig im Container/Compose (kein Vercel-spezifisches Verhalten;
  `proxy.ts`/Runtime prüfen).
- PostgreSQL ausschließlich selbst betrieben (Neon entfällt).
- Objektspeicher ausschließlich lokal (Volume) oder S3-kompatibel (MinIO); Vercel
  Blob und `BLOB_READ_WRITE_TOKEN` entfallen.
- Storage-Zugriffe (Download-Route, Löschung) gegen den neuen Provider verifizieren.

#### B.1 Betriebsmodi-Matrix

PAOLO unterstützt in Phase B **zwei gültige Betriebsmodi parallel**. Für die
projektseitige produktionsnahe Referenzinstallation (`Reference Prod`) war
Modus 1 der maßgebliche Referenzbetrieb; Modus 2 ist das Self-Hosting-Ziel für
unabhängige Betreiberinstallationen.

| Aspekt | Modus 1: Vercel-Managed | Modus 2: Self-Hosted Docker |
|---|---|---|
| Hosting | Vercel (Git-Integration) | Docker / Standalone Next.js |
| Datenbank | Neon / PostgreSQL über `DATABASE_URL` | selbst betriebene PostgreSQL |
| Storage | Vercel Blob (`STORAGE_PROVIDER=vercel-blob` oder Default) | lokaler Storage (`STORAGE_PROVIDER=local`, `LOCAL_STORAGE_DIR`) |
| Auth | Clerk | vorerst weiterhin Clerk |

**Modus 1 — Vercel-Managed (damaliger Reference-Prod-Modus):**
- Wichtige Env: `DATABASE_URL`, `BLOB_READ_WRITE_TOKEN`, `APP_BASE_URL`,
  Clerk-Variablen.
- **Hinweis:** historischer Referenzzustand der produktionsnahen
  Testinstallation — nicht mit einer echten Betreiber-Produktivinstanz
  verwechseln.

**Modus 2 — Self-Hosted Docker:**
- Wichtige Env: `DATABASE_URL`, `STORAGE_PROVIDER=local`, `LOCAL_STORAGE_DIR`,
  `APP_BASE_URL` (auf die **öffentliche Instanz-URL** setzen, nicht `localhost`),
  Clerk-Variablen.
- **Hinweis:** DB **und** Storage-Volume müssen **gemeinsam** gesichert werden
  (bei Restore müssen beide zusammenpassen, siehe Abschnitt 2.4 / Phase D).

#### B.2 Entkopplungs-Checkliste (Reihenfolge)

1. **Betriebsmodi dokumentieren** (dieser Abschnitt B.1). — *erledigt.*
2. **Cleanup-Skript isolieren und entschärfen**
   (`scripts/cleanup-test-data-before-production.ts`): — *erledigt (2026-07-08).*
   - **erledigt:** DB-Zugriff von `@neondatabase/serverless` auf **`pg`/`DATABASE_URL`**
     umgestellt (funktioniert damit gegen Neon **und** lokale PostgreSQL);
   - **erledigt:** Dry-Run bleibt Default; Scharfschalten nur noch per Env
     (`CONFIRM_CLEANUP=true` **und** `CONFIRM_TARGET=<host|dbname>`) statt Codekonstante;
   - **erledigt:** Ziel-DB (Host/Port/Name, ohne User/Passwort) und geladene Env-Datei
     werden vor jeder Aktion ausgegeben; Warnung bei nicht-lokalem/Neon-Ziel;
   - **erledigt:** Keep-Liste per `KEEP_CLERK_USER_IDS` konfigurierbar (hartcodierte
     Liste nur noch als deutlich markierter Fallback); Abbruch bei echtem Lauf, wenn
     Keep-Liste leer ist oder keine Keep-ID in `user_roles` existiert;
     `BLOB_READ_WRITE_TOKEN` im Dry-Run nicht mehr zwingend;
   - **erledigt (2026-07-08):** Blob-/Attachment-Löschung ist jetzt
     **provider-neutral** über die Storage-Schicht (`lib/storage`:
     `deleteStoredFile`). Das Skript wurde von `.mjs` auf **`.ts` (Ausführung via
     `npx tsx`)** umgestellt und importiert `deleteStoredFile` **dynamisch nach dem
     dotenv-Load** (damit `STORAGE_PROVIDER` bei der Provider-Initialisierung
     gesetzt ist). Kein direkter `@vercel/blob`-Import mehr im Skript; `del`/
     `BlobNotFoundError` entfernt. `STORAGE_PROVIDER=local` wird beim Cleanup nun
     mitbereinigt (löscht lokale Dateien); `BLOB_READ_WRITE_TOKEN` ist nur noch bei
     `STORAGE_PROVIDER=vercel-blob` erforderlich. Dry-Run bleibt Default; alle
     Sicherheitsguards unverändert. `@vercel/blob` verbleibt ausschließlich im
     Vercel-Blob-Provider.
3. **`BlobNotFoundError`-Leak aus den Actions entfernen**
   (`lib/actions/attachments.ts`, `lib/actions/reports.ts`): — *erledigt (2026-07-08).*
   - provider-neutrale „not found"-Semantik in die Storage-Schicht gezogen:
     jeder Provider behandelt „Datei fehlt beim Löschen" als No-op (lokaler
     Provider bei `ENOENT`, Vercel-Blob-Provider fängt `BlobNotFoundError`),
   - `lib/actions/attachments.ts` und `lib/actions/reports.ts` importieren
     **kein** `@vercel/blob` mehr und kennen keine Blob-spezifischen Fehler; sie
     brechen nur noch bei **echten** Speicherfehlern ab. `BlobNotFoundError`
     verbleibt seit Schritt 2 ausschließlich im Vercel-Blob-Provider. Kein
     `STORAGE_PROVIDER`-Default geändert, keine Migration.
4. **`@neondatabase/serverless` entfernen:** — *erledigt (2026-07-08).*
   Die Neon-spezifische Library ist aus `package.json`/`package-lock.json`
   entfernt (`npm uninstall`), da sie im getrackten Code nicht mehr importiert
   wird (App-Runtime und Cleanup-Skript nutzen `pg`/`DATABASE_URL`). Verbleibende
   Lockfile-Nennungen sind nur **optionale `peerDependencies`** von `drizzle-orm`
   (nicht installiert). **Neon bleibt** als PostgreSQL-Dienst über `DATABASE_URL`
   weiter möglich — nur die Neon-spezifische Library ist nicht mehr erforderlich.
5. **Backup/Restore für Self-Hosted Docker dokumentieren:**
   PostgreSQL-Dump **und** Storage-Volume, plus **gemeinsamer**
   Wiederherstellungstest (Bezug zu Phase D). — *erledigt (2026-07-08):* in
   [`docker-setup.md`](docker-setup.md) Abschnitt 10 konsolidiert — was zu sichern
   ist (DB, lokaler Storage, `.env`/Secrets, Release-Stand), warum DB + Storage
   zusammengehören, Beispiel-Kommandos (Vorlage) für Dump/Storage-Sicherung und
   Restore, ein konkreter **Restore-Testablauf** mit Smoke-Test der Kernseiten und
   Warnhinweise (kein Test über Produktion, verschlüsselte/zugriffsgeschützte
   Aufbewahrung, Aufbewahrungsfrist). **Keine echte Backup-/Restore-Ausführung in
   diesem Schritt.**
6. **Migrationsweg für Self-Hosted klären:**
   **kein** blindes `drizzle-kit migrate`; bestehende manuelle/idempotente
   Migrationen beachten (siehe `database-migrations.md`). — *erledigt (2026-07-08):*
   Self-Hosted-Migrationsweg in [`docker-setup.md`](docker-setup.md) (Abschnitt 6.1)
   dokumentiert: frische DB über geordnete SQL-Migrationen `0000`–`0019`
   initialisieren, **kein** blindes `drizzle-kit migrate`, produktive Migrationen
   nur nach **Backup und Freigabe**, zuerst gegen lokale/Staging-DB testen, danach
   `npm run build` + Smoke-Test der Kernseiten, spätere Migrationen idempotent/
   dokumentiert halten. Kein Init-Runner beim Containerstart.
7. **`APP_BASE_URL` im Self-Hosting hervorheben:** muss auf die öffentliche URL
   zeigen (nicht `localhost`), sonst zeigen Clerk-Anmeldelinks ins Leere
   (`lib/actions/user-roles.ts`). — *erledigt (2026-07-08):* in
   `.env.docker.example`, `docs/docker-setup.md` (Abschnitt 4) und `README.md`
   (Docker-Abschnitt) erklärt — öffentliche Instanz-URL statt `localhost` im
   Echtdatenbetrieb, Zusammenhang mit Auth-/Rücksprung-/Einladungslinks, Clerk-
   Redirect-URLs müssen passen. Keine Runtime-Codeänderung.
8. **Vercel/Neon/Blob als weiterhin unterstützten Betriebsmodus erhalten,**
   solange die Produktion dort läuft (Modus 1 bleibt gültig).

#### B.3 Nicht-Ziele von Phase B

- Phase B **ersetzt nicht Clerk** (das ist Phase C).
- Phase B bedeutet **nicht automatisch Produktionshärtung** (das ist Phase D).
- Phase B bedeutet **nicht das sofortige Abschalten** von Vercel/Neon/Blob.
- **Vercel-Managed bleibt ein gültiger Betriebsmodus**, bis ausdrücklich migriert
  wird.
- **Keine produktiven Datenbank- oder Storage-Änderungen ohne separate Freigabe.**

#### B.4 Abschlussstatus (2026-07-08)

**Phase B ist im vorsichtigen Entkopplungsumfang abgeschlossen.** Erreicht:

- **Vercel-Managed bleibt ein gültiger Betriebsmodus** (Produktionsstandard,
  unverändert lauffähig).
- **Self-Hosted Docker ist dokumentiert und vorbereitet** (Betriebsmodi-Matrix,
  Migrationsweg, `APP_BASE_URL`, Backup/Restore).
- **Storage ist provider-abstrahiert** (`lib/storage`): **Vercel Blob** und
  **lokaler Storage** werden unterstützt; Default bleibt `vercel-blob`.
- **Cleanup-Skript ist provider-neutral** für die Storage-Löschung
  (`deleteStoredFile`); `@vercel/blob` kommt nur noch im Vercel-Blob-Provider vor.
- **Neon-spezifische Runtime-/Skript-Dependency entfernt**
  (`@neondatabase/serverless`); **Neon bleibt** über `DATABASE_URL` (Standard-`pg`)
  weiter möglich.

**Noch nicht Teil dieser Phase (spätere Ausbaustufen):**

- **Clerk-Ablösung** (Phase C).
- **MinIO/S3-Storage-Provider** (optionale spätere Ausbaustufe).
- **Automatische Produktionshärtung** (Phase D — TLS/Reverse Proxy, Monitoring,
  Init-/Migrations-Runner).
- **Produktive Migration** von Vercel/Neon/Blob auf Self-Hosting.
- **Echter Restore-Test** (bisher nur dokumentierter Ablauf).
- **Echter Self-Hosted-Pilotbetrieb.**

### Phase C — Prüfung und ggf. Ablösung von Clerk
Ziel: Identität ohne Clerk betreiben können. **Höchster Aufwand, höchstes Risiko.**

Zu prüfende Optionen (mit grober Einordnung):
- **Auth.js (NextAuth):** Nah am Next.js-Ökosystem, leichtgewichtig; Sessions,
  OAuth/Credentials/Magic-Link. Benutzerverwaltung/Invites müssten selbst gebaut
  werden.
- **Keycloak:** Vollwertiger IdP (Rollen, Admin-UI, OIDC); mächtig, aber eigener
  Betriebsaufwand (weiterer Container) — evtl. „zu groß" für kleine Vereine.
- **Andere** (z. B. Ory, Authentik, Zitadel) als Abwägung je nach Betreiberprofil.

Besonders zu klären (aus der Repository-Analyse abgeleitet):
- **Verankerungstiefe:** ~34 Dateien mit Clerk-Bezug; `ClerkProvider`,
  `clerkMiddleware` (`proxy.ts`), `auth()`, `clerkClient`.
- **`clerk_user_id`-Felder:** 4 Spalten (`user_roles`, `report_notes`,
  `safety_meetings`, `audit_logs`) müssen auf eine neue, stabile interne User-ID
  umgestellt werden.
- **Lokale `users`-Tabelle:** Neu einzuführen (Anzeige-Name, E-Mail, Status),
  weil Profildaten heute aus Clerk kommen. Danach interne ID statt Clerk-ID
  referenzieren.
- **Benutzermigration:** Bestehende Clerk-Benutzer auf lokale Konten abbilden
  (ID-Mapping, E-Mail-Abgleich, Passwort-Setzung/Einladung).
- **Login-, Session- und Rollenmodell:** Session-Mechanik ersetzen; das
  **Rollenmodell selbst kann bleiben** (in DB + `permissions.ts`), da es nicht an
  Clerk hängt — nur die Identitätsauflösung ändert sich.
- **Admin-Benutzerverwaltung:** Heute über `clerkClient` (E-Mail-Lookup, Invite).
  Ersatz nötig: eigene Einladungs-/Anlage-Flows inkl. Mail-Versand (SMTP), da kein
  Mail-Dienst vorhanden ist (Abschnitt 3.8).

### Phase D — Betriebshärtung
Ziel: Produktionsreifer, sicherer Betrieb einer Instanz.

- **Backup/Restore:** Automatisiertes PostgreSQL-Backup (Dump/PITR) und
  Objektspeicher-Backup; Restore geprobt.
- **Reverse Proxy / TLS:** Vorschalten (z. B. Caddy/Traefik/nginx) mit
  automatischen Zertifikaten.
- **Secrets-Management:** Kein Secret im Image/Repo; Env-Datei mit
  Zugriffsschutz oder Secrets-Manager.
- **Updates:** Versionierte Images, definierter Update-/Rollback-Weg,
  Abhängigkeits-Patch-Prozess.
- **Logging/Monitoring:** Zentrales Log, Health-Check-Endpunkt, Fehler-/
  Performance-Monitoring.
- **Migrationsverfahren:** Buchhaltung konsolidieren (siehe
  `database-migrations.md`); kontrollierter, idempotenter Migrations-Runner.
- **Speicher- und Löschkonzept:** Aufbewahrung/Löschung von DB-Daten *und*
  Objektspeicher (inkl. verwaister Anhänge) zusammenführen (Bezug zu
  `data-protection-concept.md` §8–§10).

---

## 5. Bewertung je Phase

| Phase | Techn. Aufwand | Risiko | Kernabhängigkeiten | Vor Pilot nötig? |
|---|---|---|---|---|
| A — Container + eigene DB/Storage | mittel | gering–mittel | DB-Treiberwechsel, Compose | teils (nur wenn Self-Hosting-Pilot) |
| B — Vercel/Neon/Blob ablösen | mittel | mittel | Phase A | nur bei vollem Self-Hosting |
| C — Clerk ablösen | **hoch** | **hoch** | users-Tabelle, Migration, Mail | **nein**, bewusst später |
| D — Betriebshärtung | mittel–hoch | mittel | Phase A/B | ja (Backup/TLS/Secrets) |

**Phase A** — *Aufwand mittel, Risiko gering–mittel.* Storage ist dank Interface
einfach; das Hauptrisiko ist der DB-Treiberwechsel (Verbindungs-/Pooling-
Verhalten testen). Offene Entscheidung: lokales Volume **vs.** MinIO/S3.

**Phase B** — *Aufwand mittel, Risiko mittel.* Baut auf A auf. Offene
Entscheidung: endgültige Storage-Variante; Sicherstellen, dass keine
Vercel-spezifischen Annahmen verbleiben.

**Phase C** — *Aufwand hoch, Risiko hoch.* Abhängig von A/B nicht zwingend, aber
sinnvoll danach. Offene Entscheidungen: Auth-Lösung (Auth.js vs. Keycloak vs.
andere), Session-/Passwort-Strategie, Benutzermigration, **Mail-Versand**. Das
Rollenmodell bleibt erhalten — das senkt das Risiko gegenüber einer
vollständigen Auth-Neuentwicklung.

**Phase D** — *Aufwand mittel–hoch, Risiko mittel.* Teile (Backup/Restore, TLS,
Secrets) sind **vor jedem echten Pilotbetrieb** erforderlich, unabhängig von C.

**Später möglich:** vollständige Clerk-Ablösung (C), MinIO statt Volume,
Multi-Instanz-/Multi-Org-Betrieb, automatisierter Migrations-Runner.

---

## 6. Compliance-Einordnung (vorsichtig)

- **Containerisierung verbessert nicht automatisch die DSGVO-Konformität.** Sie
  ändert primär *wo* und *durch wen* verarbeitet wird, nicht *ob* die
  Anforderungen erfüllt sind.
- Werden **Vercel/Neon/Vercel Blob/Clerk** abgelöst, entfallen lediglich die
  **AVV-Themen mit genau diesen Diensten** — nicht die Datenschutzpflichten an
  sich.
- Bei **anderem Hosting, Backup-Dienst, Mail-Versand, Monitoring** oder einem
  beauftragten **IT-Dienstleister** können **neue AVV** (Art. 28) erforderlich
  werden. Insbesondere entsteht durch eine Clerk-Ablösung ein **neuer
  Mail-Dienstleister-Bedarf** (Abschnitt 3.8).
- **Self-Hosting verlagert Verantwortung** für Betriebssicherheit stärker auf den
  Betreiber (Updates, Backups, Zugriffsschutz, Verschlüsselung).

Weiterhin unabhängig von der Containerisierung zu gewährleisten (vgl.
`data-protection-concept.md`, `privacy-operations.md`):
- **Impressum/Datenschutz:** installationsspezifisch pflegen (`/dashboard/admin/legal`
  → `/impressum`, `/datenschutz`).
- **Betroffenenanfragen:** Such-/Prüfprozess (`/dashboard/privacy/requests`).
- **Löschung/Anonymisierung:** strukturierte Melderdaten anonymisierbar; Freitexte/
  Anhänge manuell; Wartefrist nach `closed` weiterhin `[offen]`.
- **Incident-Response:** Dokumentation (`/dashboard/privacy/incidents`), 72-h-
  Orientierung.
- **Backup-/Löschkonzept:** Backups dürfen Löschpflichten nicht unterlaufen;
  Aufbewahrung und Löschung zusammen denken.
- **TOMs:** TLS/Reverse Proxy, Zugriffsschutz, Secrets-Management, Verschlüsselung
  (at rest/in transit), Patch-/Update-Prozess.

Die offenen rechtlichen Punkte sind in GitHub-Issue **#16** gebündelt.

---

## 7. VO (EU) 376/2014 — nur als fachliches Referenzmodell

*Keine Behauptung unmittelbarer Anwendbarkeit* (Geltungsbereich/Segment/nationale
Umsetzung sind rechtlich zu klären, vgl. `data-protection-concept.md` §11). Als
fachliche Orientierung für ein Self-Hosting-Zielbild relevant:

- **Trennung Personenbezug / Sicherheitssachverhalt:** im Datenmodell und in der
  Anzeige bereits angelegt (strukturierte Melderdaten vs. fachliche Reportdaten).
- **Vollständige Anonymisierung:** heute nur **partiell** (strukturierte
  Melderdaten); Freitexte/Anhänge bleiben manuell — für ein vollständiges Modell
  Lücke bewusst halten.
- **Risikoklassifizierung:** Priorität (`low`/`medium`/`high`/`critical`)
  vorhanden; eine methodischere Klassifizierung wäre ausbaubar.
- **Rückmeldung an Meldende:** derzeit kein Rückkanal an anonyme Melder — offener
  Konzeptpunkt.
- **Periodische Sicherheitsberichte:** aggregierte/periodische Auswertung als
  spätere Ausbaustufe.
- **Just-Culture / Vertraulichkeit:** nicht-punitive Ausrichtung ist Leitprinzip;
  Vertraulichkeit über Rollen/Zugriffsschutz technisch gestützt.

Diese Punkte sind **fachliche Zielbilder**, keine Umsetzungszusagen.

---

## 8. Empfehlung

**Sinnvollste Reihenfolge:** A → D(Teilmenge) → B → C.

- **Kurzfristig beginnen (Phase A):** Dockerfile + Compose, DB-Treiberwechsel,
  zweiter Storage-Provider. Der Aufwand ist überschaubar, weil Storage bereits
  abstrahiert ist und der DB-Wechsel im Kern eine Datei betrifft. Das schafft die
  Grundlage für jedes Self-Hosting.
- **Parallel/zeitnah (Phase-D-Teilmenge):** Backup/Restore, TLS/Reverse Proxy und
  Secrets-Management sind **vor jedem echten Pilotbetrieb** nötig — unabhängig
  davon, ob Clerk schon abgelöst ist.
- **Danach (Phase B):** Vercel/Neon/Blob vollständig entfernen, sobald A stabil
  läuft.
- **Später (Phase C):** **Clerk-Ablösung nicht sofort.** Sie ist die aufwändigste
  und riskanteste Änderung (34 Dateien, 4 `clerk_user_id`-Spalten, fehlende
  lokale `users`-Tabelle, Benutzermigration, neuer Mail-Bedarf). Vorteil: Das
  Rollenmodell bleibt erhalten. Erst angehen, wenn Container-Betrieb (A/B) und
  Härtung (D) stehen — oder wenn ein Betreiber Clerk explizit nicht zulassen darf.
- **Empfehlung zu Clerk:** **später**, bewusst nach A/B/D. Bis dahin Clerk als
  externen Dienst mit AVV betreiben.

**Ist Containerisierung Voraussetzung für den aktuellen DHV-/Pilotpfad?**
- **Nicht zwingend.** Für einen kontrollierten Pilotbetrieb kann PAOLO zunächst
  auf der bestehenden (verwalteten) Infrastruktur laufen; entscheidend sind dann
  die Datenschutz-/Betriebspunkte (Issue #16) und die Phase-D-Grundlagen
  (Backup/TLS/Secrets), **nicht** die Containerisierung selbst.
- Containerisierung ist die Voraussetzung für das **installierbare
  Betreiber-Modell** (mehrere Vereine/Schulen betreiben eigene Instanzen) — also
  ein **mittelfristiges Zielbild**, kein Blocker für einen ersten Pilot.

---

## 9. Status Phase A

Zusammenfassung des Stands von Phase A (Containerisierung: App + eigene DB +
eigener Storage, Clerk bleibt extern). Stand: 2026-07-07.

> **Phase A abgeschlossen (experimentell).** Die Containerisierung ist **technisch
> verifiziert** (Docker-Build, Compose-Start App + PostgreSQL, Fresh-DB-Apply
> 0000–0018 gegen leere PostgreSQL, lokaler Storage im Container — Details in §9.3).
> Eine **experimentelle Docker-Installationsanleitung** liegt nun in
> [`docker-setup.md`](docker-setup.md) vor. Die **produktionsreife Härtung**
> (Backup/Restore, TLS/Reverse Proxy, Secrets-Management, Monitoring, Updates,
> automatischer Migrationsschritt) bleibt bewusst **Phase D**.

### 9.1 Umgesetzt

- **Docker-Grundlage** mit Next.js-Standalone-Build (`next.config.ts`
  `output: "standalone"`, Multi-Stage-`Dockerfile`, `.dockerignore`).
- **`docker-compose.yml`** mit App-Service **und** lokaler PostgreSQL (`db`,
  Healthcheck, Volume `paolo-db-data`, `depends_on: service_healthy`).
- **Standard-PostgreSQL-Treiber** (`pg` + `drizzle-orm/node-postgres`) statt
  Neon-Serverless; pragmatisches Pooling.
- **Lokale PostgreSQL-`DATABASE_URL`** für Compose vorbereitet (`.env.docker.example`).
- **Migrationen `0017`/`0018`** schließen die bekannten Drift-Lücken
  (`safety_meetings` + 8 Spalten); Migrationen decken `schema.ts` statisch auf
  Tabellen- und Spaltenebene ab.
- **Lokaler Dateisystem-Storage** (`lib/storage/local-file-storage.ts`) als
  Alternative zu Vercel Blob, per Env wählbar; Docker-Volume `paolo-storage-data`.

### 9.2 Bewusst noch extern

- **Clerk** (Authentifizierung/Benutzerverwaltung) bleibt extern — Ablösung ist
  Phase C, nicht Teil von Phase A.
- **Vercel Blob** bleibt **optional** und ist weiterhin der **Default**
  (`STORAGE_PROVIDER=vercel-blob`); der lokale Storage ist opt-in.

### 9.3 Verifikation durchgeführt (2026-07-07)

Auf einer erstmals Docker-fähigen Maschine (Docker 29.6.1, Compose v5.2.0) real
ausgeführt. **Keine Produktiv-/Neon-DB berührt, keine Migration gegen Neon, kein
automatischer Migrationsrunner, keine E2E-/Playwright-Läufe.** Ergebnisse:

- **Docker-Build** (`docker build -t paolo-sms:phase-a .`): **PASS**, Image ~295 MB
  (Multi-Stage-Standalone). Realer Buildfehler behoben — `next build` typecheckt
  projektweit und `scripts/e2e/reset-and-seed.ts` importiert aus dem im Image
  ausgeschlossenen `tests/e2e` → In-Image-Typecheck brach ab. **Fix:** `scripts/e2e`
  in `.dockerignore` ausgeschlossen (E2E-Harness gehört nicht ins Produktions-Image;
  konsistent zur bestehenden `tests/e2e`-Ausnahme). Kein App-Code geändert. Die aus
  A1 offenen Build-Zeit-Themen (Font/`NEXT_PUBLIC_*`) blockierten Build und Rendern
  nicht.
- **Fresh-DB-Apply 0000–0018**: **PASS**. Wegwerf-`postgres:16` (temporär, ohne
  Port-Mapping, danach entfernt); alle 19 SQL-Migrationen mit
  `psql -v ON_ERROR_STOP=1` fehlerfrei eingespielt. Read-only-Abgleich
  (`information_schema`/`pg_catalog`) gegen `schema.ts`: **voller MATCH** — 11
  Tabellen, alle Spalten/Typen/`NOT NULL`/Defaults, alle 11 FKs inkl. korrekter
  `ON DELETE`-Regeln (CASCADE vs. NO ACTION), alle Indizes inkl. der beiden
  partiellen Unique-Indizes auf `user_roles` und `roles_key_unique`; AI-Tabellen via
  0013 korrekt entfernt. Damit ist die bisher nur **statische** A2.8-Simulation
  **real bestätigt** — das letzte Gate vor einem geführten Init-Script ist erfüllt.
- **Compose-Start** (`docker compose up --build`): **PASS**. `db` wird healthy, `app`
  startet; öffentliche Routen `/`, `/submit-report`, `/sign-in` liefern **HTTP 200**
  mit echtem Inhalt (keine Error-Boundary, keine Laufzeitfehler). `.env.docker.local`
  aus Clerk-Dev-Keys + Compose-DB + `STORAGE_PROVIDER=local` (git-/dockerignoriert,
  nicht committet).
- **Lokaler Storage im laufenden Container**: **PASS** (nach Fix). put→get→delete als
  non-root `nextjs`-User (uid 1001) gegen das Volume. **Erst FAIL** (`EACCES` beim
  `mkdir /app/storage/…`), weil das Named Volume root gehörte, die App aber als
  `nextjs` läuft. **Infra-Fix im `Dockerfile`** (kein App-Code):
  `RUN mkdir -p /app/storage && chown nextjs:nodejs /app/storage` — ein leeres Named
  Volume erbt diese Eigentümerschaft beim ersten Mount. Nach Rebuild mit frischem
  Volume: Roundtrip + Delete erfolgreich. Testdaten/Volumes danach entfernt.
- **Login/Dashboard** (authentifizierte Flows): **nicht** Teil dieser Verifikation
  (bewusst keine E2E-/Auth-Läufe); öffentliche Erreichbarkeit und Clerk-`/sign-in`-
  Rendering wurden bestätigt.

### 9.4 Nicht mehr Teil von Phase A

- **Clerk-Ablösung** (Phase C).
- **MinIO/S3-Storage** (spätere, optionale Ausbaustufe nach A3).
- **Automatischer Migrationsrunner** beim Containerstart (bewusst ausgeschlossen;
  Migrationen bleiben manuell/idempotent, siehe `database-migrations.md`).
- **Produktionsreife Härtung** (Backup/Restore, Reverse Proxy/TLS,
  Secrets-Management, Monitoring, Updates) — Phase D.

---

## 10. Weiteres Vorgehen nach Phase A

- **Phase A ist abgeschlossen und real verifiziert** (siehe §9); PAOLO ist
  **noch nicht produktiv** im Einsatz.
- Weitere Entwicklung bevorzugt **kleine, testbare, reversible Schritte**.
- **Phase B wird nicht automatisch sofort** umgesetzt.
- **Self-Hosting bleibt mittelfristiges Ziel**, aber kein Sofortzwang.
- **Vercel Blob und Neon werden nicht überstürzt entfernt** — sie bleiben als
  funktionierende Default-/Alternativpfade bestehen.
- **Clerk bleibt vorerst extern**; die Ablösung ist ein späterer eigener
  Meilenstein (Phase C).
- **Produktionshärtung** (Backup, TLS, Reverse Proxy, Update-Prozess) wird
  vorbereitet, aber **nicht vorgezogen**, solange kein produktiver
  Self-Hosting-Pilot ansteht (Phase D).
- **Kurzfristig Vorrang:** Pilotfähigkeit, Datenschutz-/Admin-Prozesse und
  stabile Entwicklung.
- **Keine automatische Migration** gegen bestehende DBs (weiterhin
  manuell/idempotent, siehe `database-migrations.md`).
- Die **E2E-Teststruktur wird nicht angefasst**, solange sie nicht blockiert.

---

## 11. Übergabe-/Pausenvermerk (2026-07-08)

- **Peter pausiert die aktive Entwicklung** und bittet Thomas Behrens um Übernahme.
  `main` ist gepusht und mit `origin/main` synchron.
- **Phase A** abgeschlossen und real verifiziert (§9). **Phase B** im **vorsichtigen
  Entkopplungsumfang** abgeschlossen (§B.4) — das ist **nicht** mit vollständiger
  produktiver Unabhängigkeit zu verwechseln:
  - **Vercel/Neon/Vercel Blob sind nicht produktiv abgelöst**; Vercel-Managed bleibt
    der gültige Produktions-Betriebsmodus.
  - **Self-Hosted Docker ist vorbereitet und dokumentiert**, aber **produktiver
    Betrieb und ein echter Backup-/Restore-Test stehen aus** (kein Pilotbetrieb
    erprobt).
  - **Clerk bleibt externer Dienst** (Ablösung = Phase C).
- **Nächste professionelle Arbeitspakete:**
  - **Block 14 — Testdatenbereinigung** (noch offen; Cleanup-Skript vorbereitet).
  - **Phase C** — Clerk prüfen / ggf. ablösen.
  - **Phase D** — Betriebshärtung, echter Backup-/Restore-Test, Produktions-/
    Pilot-Check.
  - **Entscheidung Vercel-Managed vs. Self-Hosted Docker** (bewusst treffen, bevor
    migriert wird).
- **Hinweis:** `.claude/` ist lokale, untracked Agent-Konfiguration und **nicht Teil
  des Repos**.

---

*Ende des Dokuments. Strategische Planung, keine Umsetzung. Alle rechtlichen
Aussagen sind vorläufig und ersetzen keine fachliche/juristische Prüfung.*
