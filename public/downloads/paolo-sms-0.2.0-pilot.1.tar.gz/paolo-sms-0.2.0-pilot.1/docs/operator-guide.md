# Einführung und Betrieb von PAOLO SMS

Leitfaden für Vereine und Flugschulen.

> **Diese Datei ist die maßgebliche Fassung.** Die als DOCX verteilte Version
> ist eine externe Ausgabe für Betreiber ohne Repository-Zugang; bei
> Abweichungen gilt dieser Text. Änderungen gehören hierher und werden
> anschließend in die DOCX übernommen.
>
> Der Leitfaden bleibt bewusst kompakt. Für jede technische Einzelheit
> verweist er auf das jeweils maßgebliche Fach- oder Runbook-Dokument; er
> wiederholt deren Inhalt nicht und ersetzt sie nicht.

---

## Vorwort

PAOLO SMS (Pilot Awareness and Occurrence Learning Online) ist eine webbasierte
Anwendung, mit der ein Verein oder eine Flugschule ein Safety Management System
(SMS) praktisch betreiben kann. Sie deckt den vollständigen Regelkreis ab:
melden, bewerten, bearbeiten, Maßnahmen verfolgen und an die Melder
zurückmelden.

**Was PAOLO SMS bietet**

- Niederschwelliger Meldeweg – jede Person kann ohne Anmeldung melden, auf
  Wunsch anonym.
- Nachvollziehbare Bearbeitung – Meldungen, Maßnahmen mit Verantwortlichen und
  Fristen sowie Sicherheitsbesprechungen an einer Stelle.
- SMS-Dokumentation im System – Sicherheitsrichtlinie, SMS-Handbuch,
  Notfallpläne, Protokolle, Checklisten und Bedienungsanleitungen, jeweils mit
  fertigen Vorlagen.
- Abgestufte Sichtbarkeit – von vertraulich bis öffentlich, damit
  Sicherheitsinformationen gezielt geteilt werden können.
- Datenschutz eingebaut – Anonymisierung, Löschabläufe, Aufbewahrungsprüfung
  und Audit-Log.
- Eigene Instanz – die Organisation entscheidet, wo die Anwendung und ihre
  Daten betrieben werden.

**Was PAOLO SMS nicht ist**

- Kein Ersatz für die gesetzliche Meldepflicht. Unfälle und schwere Störungen
  werden weiterhin dem DHV bzw. über FIDA gemeldet.
- Impressum und Datenschutz verantwortet der Betreiber.
- Der Betreiber ist für die Einhaltung von Urheber- und
  Persönlichkeitsrechten bei Veröffentlichungen verantwortlich.
- Keine Prüfung auf Schadsoftware. Hochgeladene Dateien werden nicht gescannt;
  hochladen dürfen Administrator, Safety Manager und Safety Assistant. Es gilt
  der Hinweis im Formular: nur Dateien bekannter Herkunft.

Weitere bekannte Grenzen stehen in
[`production-readiness.md`](production-readiness.md).

---

## 1  Entscheidung, ein SMS einzuführen

Die Organisation entscheidet sich dafür, die Sicherheitskultur voranzutreiben
und dies mittels PAOLO SMS zu unterstützen. Der Beschluss wird von der Leitung
getragen – Vorstand im Verein, Schulleitung in der Flugschule.

### 1.1  Rollen benennen

Accountable Executive, Safety Manager und Administrator müssen benannt werden:

| Funktion | Aufgabe | Hinweis |
|---|---|---|
| Accountable Executive (verantwortliche Leitung) | Trägt die übergeordnete Verantwortung für die organisatorischen Voraussetzungen und die Funktionsfähigkeit des SMS und unterzeichnet die Sicherheitsrichtlinie. Nicht gemeint ist die Verantwortung für die Sicherheit jedes einzelnen Fluges. | Führungsverantwortung (Accountability). Im Verein ein entsprechend benanntes Vorstandsmitglied, in der Flugschule etwa Geschäftsführer oder Ausbildungsleiter, jeweils im Rahmen der bestehenden Befugnisse. |
| Safety Manager | Setzt das SMS operativ um: Meldungen bearbeiten, Maßnahmen verfolgen, Sicherheitsbesprechungen vorbereiten, Dokumentation pflegen. | Delegierbar. Braucht Rückendeckung der Leitung und ausreichend Zeit. |
| Administrator | Richtet die Installation ein und betreibt sie: Benutzer, Einstellungen, Updates, Backups. | Kann eine externe IT-Person oder ein Dienstleister sein. |

- In kleinen Organisationen dürfen Funktionen zusammenfallen. Accountable
  Executive und Safety Manager sollten jedoch nicht dieselbe Person sein.
- Die Benennung wird in PAOLO dokumentarisch hinterlegt (Abschnitt 3.3). Sie
  ersetzt keine Bestellung durch die Leitung.

Zweck, Aufgaben und Grenzen jeder Rolle stehen ausführlich in
[`role-responsibilities.md`](role-responsibilities.md).

### 1.2  Was zu Beginn festzulegen ist

- Dass Meldungen nicht für Sanktionen genutzt werden (Redlichkeitskultur) – und
  dass das nach außen gesagt wird.
- Der Turnus der Sicherheitsbesprechung. Empfehlung: nicht mehr als 12 Monate.
- Wer die Installation betreibt: eigene Person oder beauftragter
  IT-Dienstleister.

---

## 2  Technische Einführung

### 2.1  Technische Voraussetzungen schaffen

PAOLO SMS wird als eigene Instanz betrieben. Der empfohlene Weg ist Docker auf
einem eigenen Server oder einer Ubuntu-VM, etwa bei einem Hoster oder auf
AWS EC2.

Mindestvoraussetzungen:

- Server oder VM mit Ubuntu 24.04 LTS, Docker Engine und Docker Compose.
- Eigene Domain mit DNS-A-Record und TLS-Zertifikat (Let's Encrypt über Nginx).
- Firewall: 80/tcp und 443/tcp aus dem Internet, SSH (22/tcp) nur von der
  Administrator-IP. Die Datenbank ist nie öffentlich erreichbar.
- Persistenter, verschlüsselter Datenträger für Datenbank, Anhänge und Backups.
- Eine Person mit Linux- und Docker-Kenntnissen oder ein beauftragter
  IT-Dienstleister.

Vorab sind drei Entscheidungen zu treffen:

| Entscheidung | Optionen | Empfehlung |
|---|---|---|
| Anmeldung | Clerk (verwalteter Dienst) oder Better Auth (selbst betrieben) | Clerk ist der Installationsstandard und funktional vollständiger. Better Auth ist der Self-Hosting-Weg; vor dem produktiven Einsatz Passwort-Reset sowie Benutzer- und Sitzungsverwaltung prüfen. |
| Datenbank | PostgreSQL im eigenen Docker oder Neon (Cloud) | PostgreSQL in Docker für volle Datenhoheit; Neon, wenn kein eigener Datenbankbetrieb gewünscht ist. |
| Dateispeicher | Lokales Verzeichnis oder Vercel Blob | Lokales Verzeichnis beim Docker-Betrieb; Vercel Blob nur beim Hosting auf Vercel. Anhänge sind auf 4 MiB je Datei begrenzt. |

Empfohlene Reihenfolge, wenn volle Datenhoheit das oberste Ziel ist:
(1) Docker + Better Auth + PostgreSQL in Docker, (2) Docker + Better Auth +
Neon, (3) Docker + Clerk + Neon, (4) native Installation ohne Container – nur
als Sonderfall für technisch versierte Betreiber. Steht dagegen der geringste
Betriebsaufwand im Vordergrund, ist Clerk als Installationsstandard die erste
Wahl: Better Auth ist noch nicht als vollwertiger Ersatz freigegeben.

Die Abwägung im Einzelnen und alle noch offenen Punkte stehen in
[`installation-decision-guide.md`](installation-decision-guide.md); dort ist
auch der Vorbehalt zu Better Auth begründet.

### 2.2  PAOLO SMS installieren

Die **verbindliche** Anleitung ist
[`docker-vm-deployment.md`](docker-vm-deployment.md). Der Ablauf in Kürze:

1. **Host vorbereiten** – Docker, Compose, Git und Cron installieren (Skript
   `scripts/deploy/ubuntu-docker-bootstrap.sh`).
2. **Release bereitstellen** – Repository nach `/opt/paolo-sms` klonen,
   `.env.docker.example` nach `.env.docker.local` kopieren und die
   Produktionswerte eintragen: Adresse, Datenbank, Anmeldeverfahren, Speicher,
   Backup-Schlüssel.
3. **Container bauen und starten**, danach die frische Datenbank mit den
   geprüften SQL-Migrationen initialisieren – Verfahren:
   [`database-migrations.md`](database-migrations.md).
4. **Ersten Administrator anlegen** – bei Better Auth über den Bootstrap-Befehl
   (`npm run setup:initialize`), bei Clerk über das Clerk-Projekt mit
   anschließender Zuordnung in PAOLO. Öffentliche Selbstregistrierung ist
   abgeschaltet.
5. **Nginx und TLS einrichten** und das Zertifikat per Certbot beziehen.
6. **Smoke-Test** – `/api/health` antwortet; Startseite, `/submit-report` und
   Anmeldung laden; Dashboard sowie Hoch- und Herunterladen von Anhängen
   funktionieren.
7. **Backups einrichten** – täglicher verschlüsselter Datenbank-Dump per Cron
   und ein separates Archiv der Anhänge, beides außerhalb des Servers abgelegt.
   Verfahren und Grenzen: [`backup-restore.md`](backup-restore.md).

> **Wichtig:** Die Datenbanksicherung enthält die Anhänge **nicht** – diese sind
> separat zu sichern. Eine Wiederherstellung wird auf einer Testinstanz
> geprobt, niemals auf der Produktivinstanz.

Vor dem Produktivstart: Testdaten entfernen – derzeit manuell, ein Seed-/
Reset-Werkzeug ist in Arbeit – und eine Wiederherstellung einmal vollständig
durchspielen.

---

## 3  Einstellungen in PAOLO SMS vornehmen

### 3.1  Benutzer anlegen

Pfad: `/dashboard/users`

- Der bei der Installation angelegte Administrator ist das erste Konto. Der
  letzte verbliebene Administrator kann nicht herabgestuft oder entfernt
  werden. Deshalb früh ein zweites Administratorkonto anlegen – geht das
  einzige verloren, hilft nur ein Eingriff in der Datenbank.
- Mindestens einen Safety Manager anlegen. Safety Assistants und Benutzer nach
  Bedarf.
- Ist ein Anmelde- oder Passwortzugang verloren oder abgelaufen, erzeugt ein
  Administrator oder Safety Manager in der Kontenliste mit „Anmeldelink
  erneuern“ einen neuen Link (sieben Tage gültig). Er erscheint nur einmal auf
  dem Bildschirm und wird nirgends gespeichert; ältere Links bleiben bis zu
  ihrem Ablauf gültig. Bei Better Auth führt der Link zur Seite „Passwort
  festlegen“ und beendet alle bisherigen Sitzungen der Person.
- Namen (und bei Better Auth E-Mail-Adressen) korrigiert ein Administrator oder Safety
  Manager über „Kontodaten ändern“. „Konto löschen“ entfernt ein Konto endgültig, nach
  Eingabe seiner E-Mail-Adresse; das eigene Konto und Konten mit Administratorrolle sind
  ausgenommen (die Rolle vorher ändern). Meldungen, Notizen und Audit-Einträge bleiben
  unverändert. Bei Clerk entscheidet die Instanz über Löschungen: Teilen sich mehrere
  Umgebungen eine Clerk-Instanz, trifft eine Löschung alle.
- **Better Auth, HTTP-Zugang:** Die Route `/api/auth/*` liefert nur noch
  `POST /sign-in/email`, `GET /get-session`, `GET /ok` und `POST /sign-out` aus;
  alles andere antwortet mit 404. Externe Überwachung oder Skripte, die weitere
  Better-Auth-Pfade abfragen, müssen darauf angepasst werden.

| Rolle | Beschreibung | Berechtigung |
|---|---|---|
| Administrator | Verantwortliche Person für den reibungslosen Betrieb, die Konfiguration und die Wartung von PAOLO SMS oder eine Vertretung mit denselben Berechtigungen. | Vollzugriff, zusätzlich CSV-Import/-Export und Datenbank-Backups. |
| Safety Manager | Verantwortliche Person für die operative Umsetzung, Koordination und Aufrechterhaltung des Sicherheitsmanagementsystems innerhalb einer Organisation oder eine Vertretung mit denselben Berechtigungen. | Meldungen, Maßnahmen und Dokumente bearbeiten; Einstellungen und rechtliche Angaben pflegen; Benutzer verwalten. |
| Safety Assistant | Eine vertrauenswürdige und kompetente Ansprechperson innerhalb der Organisation, die mit sensiblen Informationen verantwortungsvoll und vertraulich umgeht. In einer Flugschule kann diese Rolle beispielsweise von einem erfahrenen Fluglehrer, in einem Verein von einem geeigneten Funktionsträger übernommen werden. Die Zahl der Safety Assistants sollte bewusst klein gehalten werden, da eine gute Meldekultur wesentlich davon abhängt, dass Vertraulichkeit gewährleistet bleibt. | Sicherheitsfachliche Inhalte, Maßnahmen, Dokumente und Anhänge lesen; Anhänge hoch- und herunterladen; neuen Mitgliedern die Rolle Benutzer geben. Keine Melderidentität und keine internen Notizen; keine Bearbeitungsrechte. |
| Benutzer | Ein an Sicherheitsthemen interessiertes Mitglied der Organisation. | Kein Dashboard. Sieht nach Anmeldung die für angemeldete Personen freigegebenen Dokumente. |

> Diese Tabelle ist eine Übersicht für die Rollenvergabe. **Verbindlich für den
> tatsächlichen Berechtigungsumfang** ist
> [`permission-matrix.md`](permission-matrix.md), erhoben aus dem Code.

Zum Anlegen E-Mail-Adresse und Rolle eintragen und absenden.

- **Bei Clerk** erzeugt PAOLO einen einmaligen Anmeldelink mit sieben Tagen
  Gültigkeit, der manuell an die Person versendet wird; ist er abgelaufen, wird
  der Vorgang wiederholt – Konto und Rolle bleiben erhalten.
- **Bei Better Auth** verlangt das Formular zusätzlich Name und ein
  Anfangspasswort (mindestens 8 Zeichen); einen Anmeldelink gibt es dort nicht
  – das Passwort wird auf sicherem Weg übermittelt und sollte nach der ersten
  Anmeldung geändert werden.

Hinweis: Zum Melden ist keine Anmeldung nötig. Ein Konto braucht nur, wer im
System arbeiten oder interne Inhalte lesen soll.

### 3.2  Rechtliche Angaben eingeben

Pfad: `/dashboard/admin/legal`

Betreiberangaben für Impressum und Datenschutzerklärung. Diese Angaben
erscheinen auf den öffentlichen Seiten `/impressum` und `/datenschutz` und
müssen vor dem Produktivbetrieb eingegeben werden; fehlende Felder werden dort
als „noch nicht hinterlegt" ausgewiesen.

- Auch die zuständige Aufsichtsbehörde eintragen – sie wird im Modul
  Datenschutzvorfälle angezeigt.
- Die Texte sind prüfpflichtig. PAOLO leistet keine Rechtsberatung.

Welche Entscheidungen der Betreiber vor der Inbetriebnahme zu treffen hat und
wo sie in PAOLO wirksam werden, steht in
[`data-protection-concept.md`](data-protection-concept.md) Abschnitt 16.

### 3.3  Organisationseinstellungen

Pfad: `/dashboard/settings`

- **Turnus Sicherheitsbesprechung** – nach wie vielen Monaten spätestens eine
  Sicherheitsbesprechung stattfinden soll. Sicherheitsbesprechungen sollten
  mindestens einmal jährlich, idealerweise vierteljährlich stattfinden; bei
  akuten Anlässen wie schweren Unfällen sollten zusätzlich außerordentliche
  Sicherheitsbesprechungen einberufen werden. Zulässiger Bereich 1–24 Monate.
  Über einem Wert von 12 Monaten wird eine Warnung ausgegeben.
- **Erinnerung zur Aufbewahrungsprüfung** – nach wie vielen Monaten nach
  Abschluss bzw. Ausblenden einer Meldung an eine datenschutzrechtliche Prüfung
  erinnert werden soll. Optional.
- **Statusrückmeldungen öffentlich anzeigen** – voreingestellt **ein**.
  Eingeschaltet erscheint auf der öffentlichen Seite „Sicherheitsinformationen"
  ganz oben die Box „Status von Sicherheitsmeldungen": je Zeile ein zufälliger
  Meldungscode und der Bearbeitungsstatus, sonst nichts. Sie beantwortet
  Meldern die Frage, ob ihre Meldung ankommt und bearbeitet wird — ohne
  Inhalte preiszugeben und ohne zusätzliche Pflege, denn sie folgt automatisch
  dem Status, den der Safety Manager ohnehin setzt.

  Zu bedenken: Die Liste zeigt keine Inhalte, aber sie zeigt, **dass** gemeldet
  wurde und in welcher Reihenfolge. In einer sehr kleinen Gruppe kann das
  zusammen mit anderem Wissen einen Rückschluss erlauben. Wer das nicht möchte,
  schaltet die Anzeige hier ab; dann werden auch serverseitig keine Statusdaten
  mehr bereitgestellt. Meldungen, Meldungscodes und Bearbeitungsstand bleiben
  in jedem Fall unverändert erhalten, und die Dreimonatsfrist für abgeschlossene
  Meldungen läuft weiter. Jedes Umschalten steht im Audit-Log.
- **SMS-Verantwortung (dokumentarisch)** – hält fest, wer im SMS benannt ist:
  Accountable Executive und Safety Manager mit Funktion, Kontakt und Amtszeit.
  Die Angaben dienen nur der Dokumentation und Erinnerung, erzeugen keine
  Programmberechtigung und ersetzen keine organisatorische Bestellung,
  Unterschrift oder rechtliche Benennung.

### 3.4  Dokumente erstellen

Pfad: `/dashboard/documents`

Für die meisten Dokumente ist eine Vorlage im Programm hinterlegt. Beim Anlegen
eines noch leeren Dokuments lässt sie sich als Startgrundlage übernehmen und
anschließend an die eigene Organisation anpassen.

Mindestumfang zum Start:

- **Sicherheitsrichtlinie** – Vorlagen für Verein und Flugschule, jeweils
  kompakt (eine Seite) oder ausführlich. Vom Accountable Executive
  unterzeichnen.
- **SMS-Handbuch** – Kurzfassung für den Verein: Rollen, Meldeweg, Bewertung,
  Maßnahmen, Besprechung und Notfall.
- **Notfallplan** – für das lokale Fluggelände, bei Bedarf zusätzlich für
  Gleitschirmreisen ins Ausland.
- **Bedienungsanleitungen** – für Meldende, Safety Assistants und Safety
  Manager.
- **Checkliste Änderungsmanagement** – für die Sicherheitsbewertung geplanter
  Änderungen. Eine Vorlage besteht nur für diese Checkliste.
- Später kommen Protokolle der Sicherheitsbesprechungen und
  Sicherheitsinformationen hinzu.

Jedes Dokument erhält eine Sichtbarkeit:

| Stufe | Wer sieht das Dokument |
|---|---|
| Vertraulich | Nur Administrator und Safety Manager. |
| Intern | Zusätzlich Safety Assistants (angemeldet). Nicht öffentlich. |
| Angemeldete Personen | Alle angemeldeten Personen mit zugewiesener Rolle; sichtbar unter `/communications` nach Anmeldung. Nicht öffentlich. |
| Öffentlich | Ohne Anmeldung unter `/communications` sichtbar. |

> **Datenschutz:** Protokolle von Sicherheitsbesprechungen enthalten häufig
> personenbezogene Angaben. Vor einer Freigabe für angemeldete Personen oder die
> Öffentlichkeit prüfen, ob eine gekürzte Fassung angemessen ist.

---

## 4  Betrieb aufnehmen

- Sicherheitsrichtlinie unterzeichnen und auf „Öffentlich" stellen.
- Meldeweg bekannt machen: Link auf `/submit-report` auf der Vereins- bzw.
  Schulseite, am Startplatz und in der Mitgliederinformation. Melden ist ohne
  Anmeldung und auf Wunsch anonym möglich. Das Formular nennt den
  Empfängerkreis: Melderangaben sehen nur Safety Manager und Administrator –
  Freitexte und Anhänge sind davon nicht erfasst.
- Bedienungsanleitung für Melder für angemeldete Personen oder öffentlich freigeben.
- Auf die In-App-Hilfe hinweisen: Angemeldete finden unter `/dashboard/hilfe`
  die Anleitung zu ihrer eigenen Rolle.
- Kurz erklären, was gemeldet werden soll – Unfall, Beinahe-Ereignis,
  Gefahrenquelle, Beobachtung, Verbesserungsidee – und dass Meldungen nicht für
  Sanktionen verwendet werden. Die genaue Auswahl steht im Meldeformular.
- Klarstellen: Die gesetzliche Meldepflicht gegenüber DHV bzw. FIDA bleibt
  bestehen und wird durch eine PAOLO-Meldung nicht erfüllt.
- Zugangslinks an Safety Manager und Safety Assistants versenden und den Termin
  der ersten Sicherheitsbesprechung setzen.

---

## 5  Laufender Betrieb

Meldungen werden zeitnah vervollständigt. Über Maßnahmen wird dagegen in der
Sicherheitsbesprechung entschieden – dort werden sie gemeinsam beschlossen, mit
Verantwortlichem und Frist versehen und beim nächsten Mal auf Wirksamkeit
geprüft. Nur bei besonders hohem Risiko wird eine Maßnahme ausnahmsweise sofort
außerhalb des Turnus beschlossen.

| Wann | Was | Wo | Von wem |
|---|---|---|---|
| Laufend | Meldekultur fördern, sodass sicherheitsrelevante Ereignisse und Beobachtungen gemeldet werden. | `/submit-report` | Alle |
| Laufend | Neue Meldungen sichten und ergänzen. | `/dashboard/reports` | Safety Manager |
| Im Turnus | Sicherheitsbesprechung durchführen: Meldungen gemeinsam bewerten, Maßnahmen mit Verantwortlichem und Frist beschließen, die Wirksamkeit der laufenden Maßnahmen prüfen und das Protokoll als Dokument ablegen. | `/dashboard/measures`, `/dashboard/documents` | Accountable Executive, Safety Manager, Experten |
| Ausnahmsweise | Nur bei besonders hohem Risiko eine Maßnahme sofort außerhalb des Turnus beschließen und umsetzen; in der nächsten Sicherheitsbesprechung nachdokumentieren. | `/dashboard/measures` | Accountable Executive, Safety Manager, Experten |
| Nach Bedarf | Rückmeldung an die Melder und Sicherheitsinformationen veröffentlichen. | `/communications` | Safety Manager |
| Regelmäßig | Aufbewahrungsprüfung, Anonymisierung, Betroffenenanfragen und Datenschutzvorfälle bearbeiten. | `/dashboard/privacy` | Safety Manager, Datenschutzbeauftragter |
| Regelmäßig | Backups prüfen (Datenbank und Anhänge), Updates einspielen, Audit-Log stichprobenartig einsehen. | Server, `/dashboard/admin` | Administrator |

Die Datenschutzarbeit im Einzelnen beschreibt
[`privacy-operations.md`](privacy-operations.md). Ein Update mit
Datenbankmigration folgt dem Runbook
[`runbooks/production-docker-update.md`](runbooks/production-docker-update.md)
— ohne dieses Runbook kein Update.

---

## 6  Checkliste Einführung

- [ ] Leitung hat die Einführung des SMS beschlossen.
- [ ] Accountable Executive, Safety Manager und Administrator sind benannt.
- [ ] Betriebsvariante entschieden: Hosting, Anmeldung, Datenbank,
      Dateispeicher.
- [ ] Instanz installiert, per HTTPS erreichbar, Smoke-Test bestanden.
- [ ] Backups eingerichtet und eine Wiederherstellung getestet – Datenbank und
      Anhänge.
- [ ] Testdaten entfernt (derzeit manuell).
- [ ] Administrator, Safety Manager und weitere Benutzer angelegt.
- [ ] Rechtliche Angaben eingetragen, `/impressum` und `/datenschutz` geprüft.
- [ ] Turnus der Sicherheitsbesprechung und SMS-Verantwortung eingetragen.
- [ ] Sicherheitsrichtlinie unterzeichnet und veröffentlicht.
- [ ] SMS-Handbuch, Notfallplan, Bedienungsanleitungen und Checkliste angelegt.
- [ ] Meldeweg allen Mitgliedern kommuniziert.
- [ ] Termin der ersten Sicherheitsbesprechung steht.

---

## Weiterführende Unterlagen

| Thema | Quelle im Repository |
|---|---|
| Betriebsvariante wählen | [`installation-decision-guide.md`](installation-decision-guide.md) |
| Installation auf einer Ubuntu-VM | [`docker-vm-deployment.md`](docker-vm-deployment.md) |
| Lokale Docker-Installation | [`docker-setup.md`](docker-setup.md) |
| Backup und Wiederherstellung | [`backup-restore.md`](backup-restore.md) |
| Update mit Datenbankmigration | [`runbooks/production-docker-update.md`](runbooks/production-docker-update.md) |
| Migrationsverfahren | [`database-migrations.md`](database-migrations.md) |
| Bedienung je Rolle | [`help/README.md`](help/README.md) |
| Rechte je Rolle | [`permission-matrix.md`](permission-matrix.md) |
| Fachliche Rollenbeschreibung | [`role-responsibilities.md`](role-responsibilities.md) |
| Datenschutzbetrieb | [`privacy-operations.md`](privacy-operations.md) |
| Datenschutzkonzept | [`data-protection-concept.md`](data-protection-concept.md) |
| Bekannte Grenzen | [`production-readiness.md`](production-readiness.md) |

Weitere Runbooks für wiederkehrende Eingriffe:
[`runbooks/README.md`](runbooks/README.md).
