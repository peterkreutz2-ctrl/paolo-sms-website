# Spieldaten laden und Installationsdaten zurücksetzen

> [!IMPORTANT]
> **Unterstützter Umfang: Spieldatenbetrieb (nur docker, VMS Betrieb).**
> Das hier beschriebene Verfahren wird ausschließlich für Docker und die
> dokumentierte native Ubuntu-VM unterstützt. Für Vercel-/Neon-Installationen
> gibt es derzeit keinen unterstützten Seed- oder Reset-Betriebsweg. Dort
> fehlen insbesondere ein sicher festgelegter Wartungsmodus, eine eindeutig
> gebundene direkte Datenbankverbindung und eine vollständige Definition der
> erreichbaren Backup- und Storage-Grenzen. Die folgenden Befehle dürfen daher
> nicht gegen eine Vercel-/Neon-Installation ausgeführt werden.

Dieses Runbook gilt für eine einzelne, vom jeweiligen Betreiber verantwortete
PAOLO-Installation. Unterstützt werden der Docker-Betrieb und die in
[`setup-ubuntu.md`](setup-ubuntu.md) beschriebene native Ubuntu-VM. Beide
Vorgänge sind manuelle Wartungsarbeiten. Die App und alle schreibenden Jobs
müssen vorher gestoppt werden.

## Voraussetzungen

1. Das Schema wurde mit `scripts/migrate.sh` beziehungsweise
   `scripts/migrate.psql` vollständig eingespielt.
2. Organisation und erster globaler Administrator wurden mit
   `npm run setup:initialize` angelegt.
3. Die Installation enthält genau eine Organisation.
4. Für einen Reset ist geklärt, dass **alle** fachlichen Daten, Attachment-
   Dateien und lokalen PAOLO-Backups unwiederbringlich entfernt werden dürfen.

Die benötigte globale Admin-ID steht in `user_roles.clerk_user_id`. Bei Clerk
ist dies die Clerk-User-ID, bei Better Auth die lokale Benutzer-ID. Das Werkzeug
prüft die globale `admin`-Zuweisung serverseitig.

## Vorschau

Die Vorschau verändert nichts und zeigt Datenbankziel, Organisation,
Tabellenzählungen und beim Reset den Datei-Umfang. Dabei nennt sie die
aufgelösten Werte von `LOCAL_STORAGE_DIR` und `BACKUP_DIR` und kennzeichnet
ausdrücklich, welche Verzeichnisse beziehungsweise Blob-Präfixe geleert werden:

### Docker

```bash
docker compose stop app
docker compose run --rm --no-deps -T app npm run operator:data -- seed
docker compose run --rm --no-deps -T app npm run operator:data -- reset
```

### Native Ubuntu-VM

Bei der nativen Installation liegen Repository und Node-Abhängigkeiten unter
`/opt/paolo-sms`. Das Werkzeug muss auf derselben VM als Dienstbenutzer `paolo`
mit der produktiven Umgebung ausgeführt werden. Nur so zeigen
`LOCAL_STORAGE_DIR` und `BACKUP_DIR` auf dieselben Dateien wie der Dienst.

```bash
sudo systemctl stop paolo-sms
cd /opt/paolo-sms
sudo -u paolo bash -c \
  'set -a; source /etc/paolo-sms/paolo.env; set +a; npm run operator:data -- seed'
sudo -u paolo bash -c \
  'set -a; source /etc/paolo-sms/paolo.env; set +a; npm run operator:data -- reset'
```

Passwörter, Tokens und die vollständige `DATABASE_URL` werden nicht ausgegeben.
Weitere DB-Verbindungen müssen vor der Ausführung geschlossen werden. Die
Vorschau und ein entsprechender Abbruch nennen für jede blockierende Verbindung
`pid`, `application_name`, `usename` und `state`. Weitere Verbindungsdetails
werden nicht ausgegeben.

## Spieldaten laden

Der Seed ist nur für einen fachlich leeren Bestand bestimmt. Er erzeugt 20
synthetische, deutlich markierte Meldungen, 10 Maßnahmen, sechs Notizen und zwei
Sicherheitsbesprechungen. Termine werden relativ zum Lauftag berechnet. Die
bereitgestellten Beispiele enthalten keine Anhänge, Rechtstexte, SMS-Dokumente
oder Datenschutzvorfälle.

Alle Spieldaten-Meldungen besitzen feste synthetische Meldungscodes und
demonstrieren damit die öffentliche Statusrückmeldung. Abgeschlossene Beispiele
enthalten unterschiedliche Abschlusszeitpunkte: Einige sind innerhalb der
dreimonatigen Sichtbarkeit, andere bereits abgelaufen. Ausgeblendete oder in den
Papierkorb verschobene Meldungen bleiben trotz vorhandenem Code unsichtbar.

```bash
docker compose run --rm --no-deps -T app npm run operator:data -- seed \
  --execute \
  --confirm-database=paolo \
  --confirm-organization-id=UUID-AUS-DER-VORSCHAU \
  --admin-user-id=GLOBALE-ADMIN-ID
```

Auf einer nativen Ubuntu-VM lautet die entsprechende Ausführung:

```bash
cd /opt/paolo-sms
sudo -u paolo bash -c '
  set -a
  source /etc/paolo-sms/paolo.env
  set +a
  npm run operator:data -- seed \
    --execute \
    --confirm-database=paolo_sms \
    --confirm-organization-id=UUID-AUS-DER-VORSCHAU \
    --admin-user-id=GLOBALE-ADMIN-ID
'
```

Die Werte hinter `--confirm-*` müssen exakt zur Vorschau passen. Ein zweiter
Seed neben fachlichen Daten wird abgelehnt. Nach einem vollständigen Reset kann
der Seed erneut geladen werden.

Die Inhalte sind vollständig synthetisch. Ein lokaler FIDA-Auszug wurde nur zur
Auswahl typischer Themen verwendet; Originaltexte, Orte, Personen, Geräte und
Quelldateien sind nicht Bestandteil des Projekts oder Images.

## Installationsdaten zurücksetzen

Der Reset ist absichtlich destruktiv und nicht rückgängig zu machen. Er erhält:

- Organisations-ID, Name, Typ und ursprünglichen Erstellzeitpunkt;
- statische Rollen und alle Rollenzuweisungen;
- Better-Auth-Benutzer und -Accounts beziehungsweise die externen Clerk-Konten.

Er entfernt alle übrigen aktiven PAOLO-Daten, Sessions, Verifikationen,
Attachment-Dateien und **alle Dateien im konfigurierten `BACKUP_DIR`**. Eine
off-instance gespeicherte Kopie kann das Werkzeug nicht erreichen. Rechtstexte,
SMS-Verantwortliche und individuelle Intervalle werden ebenfalls entfernt
beziehungsweise auf Ausgangswerte gesetzt.

```bash
docker compose run --rm --no-deps -T app npm run operator:data -- reset \
  --execute \
  --confirm-database=paolo \
  --confirm-organization-id=UUID-AUS-DER-VORSCHAU \
  --admin-user-id=GLOBALE-ADMIN-ID
```

Auf einer nativen Ubuntu-VM lautet die entsprechende Ausführung:

```bash
cd /opt/paolo-sms
sudo -u paolo bash -c '
  set -a
  source /etc/paolo-sms/paolo.env
  set +a
  npm run operator:data -- reset \
    --execute \
    --confirm-database=paolo_sms \
    --confirm-organization-id=UUID-AUS-DER-VORSCHAU \
    --admin-user-id=GLOBALE-ADMIN-ID
'
```

Storage- und Backup-Pfade werden vor dem Löschen geprüft. Symlinks, gefährliche
Wurzelpfade, unbekannte oder zur Konfiguration abweichende Storage-Provider und
fehlende Blob-Zugangsdaten führen zum Abbruch. Externe Dateien werden vor dem
DB-Commit entfernt. Schlägt ein Schritt fehl, wird die Datenbanktransaktion
zurückgerollt; bereits entfernte Dateien bleiben entfernt und der Vorgang kann
wiederholt werden.

Nach Erfolg enthält das Audit-Log genau einen Eintrag
`INSTALLATION_DATA_RESET` mit dem ausführenden globalen Administrator und
aggregierten Löschzahlen. Unbekannte experimentelle Legacy-Tabellen werden
nicht verändert.

## Abnahme

Nach Seed beziehungsweise Reset die App neu starten und mindestens Dashboard,
Meldungsliste, Papierkorb, Maßnahmen, Sicherheitsbesprechung und Audit-Log
prüfen:

Docker:

```bash
docker compose up -d --no-deps --force-recreate app
docker compose logs -f app
```

Native Ubuntu-VM:

```bash
sudo systemctl start paolo-sms
sudo systemctl status paolo-sms --no-pager
```
