# Quellpaket

Ein Quellpaket ist ein versioniertes Archiv `paolo-sms-<version>.tar.gz`. Es
enthält den Quellcode und die Dokumentation, die für Installation, Betrieb und
Nutzung nötig sind, und lässt sich ohne Zugang zum Entwicklungsrepository
installieren. Dieses Dokument beschreibt, wie das Paket entsteht und wie sich
ein Paket prüfen lässt. Die Installation aus dem Paket beschreibt
[`install-from-package.md`](install-from-package.md); das Update beschreibt
[`update-from-package.md`](update-from-package.md).

Der Stand ist vorbereitend: Es gibt noch keine Release-Tags, keine
Veröffentlichung und keinen Download. Die erste interne Version ist
`0.2.0-pilot.1`.

## Grundsätze

- **Ein Paket entsteht aus genau einem Commit.** Der Build liest nur Objekte
  dieses Commits aus der Git-Datenbank. Geänderte, vorgemerkte und
  unversionierte Dateien im Arbeitsverzeichnis haben keinen Einfluss.
- **Der Inhalt des Archivs ist reproduzierbar:** sortierte Einträge, feste
  Zeitstempel (Commit-Zeit), feste Eigentümer und Modi, feste gzip-Kopfdaten.
  Auf demselben Werkzeugstand (Node.js und zlib) ergibt derselbe Commit auch
  dasselbe Archiv Byte für Byte. Die komprimierten Bytes können sich zwischen
  zlib-Versionen unterscheiden; **maßgeblich für den Inhalt ist `FILES.sha256`** im
  Paket, die SHA-256 des Archivs gilt für die veröffentlichte Datei.
- **Eine Positivliste entscheidet über den Inhalt.** Sie steht in
  [`scripts/release/package-manifest.json`](../scripts/release/package-manifest.json)
  und wird aus dem Commit gelesen, nicht aus dem Arbeitsverzeichnis.
- **Die Version steht in `package.json`.** Sie muss mit `package-lock.json`
  übereinstimmen und eine gültige SemVer-Version sein.

## Positivliste

Jede versionierte Datei gehört zu genau einem Eintrag im Abschnitt `include`
oder `exclude`; ein Eintrag ist ein Dateipfad oder ein Verzeichnis (endet auf
`/`) mit einer kurzen Begründung. Der Build bricht ab, wenn

- eine Datei in keinem Eintrag vorkommt,
- eine Datei in `include` und `exclude` zugleich vorkommt,
- ein Eintrag keine Datei mehr trifft,
- eine Pflichtdatei fehlt (`package.json`, `package-lock.json`, `LICENSE`,
  `NOTICE`, `THIRD-PARTY-NOTICES.md`, `README.md`),
- ein eingeschlossener Pfad ein Symlink ist, wie `.env`, `*.pem` oder `*.key`
  heißt (Vorlagen `*.example` ausgenommen) oder einen privaten Schlüssel
  enthält.

Eine neue Datei **außerhalb** der freigegebenen Verzeichnisse verlangt damit eine
bewusste Entscheidung, ob sie ins Paket gehört. Unter den freigegebenen
Verzeichnissen (`app/`, `lib/`, `components/`, `docs/help/`, `drizzle/`, `public/`,
`deploy/`, `scripts/release/`) nimmt die Positivliste neue Dateien dagegen
automatisch auf; dort greift die Kontrolle des Paketinhalts. Ausgeschlossen sind insbesondere `security/`, `tests/`, `.github/`,
`.agents/`, `AGENTS.md`, `CLAUDE.md`, das Entwicklungsprotokoll und die
Testunterlagen.

## Kontrolle des Paketinhalts

Die Datei [`scripts/release/package-files.txt`](../scripts/release/package-files.txt)
listet jede Datei, die das Paket enthalten darf. Der Build vergleicht den
tatsächlichen Paketinhalt des Commits mit dieser Liste und bricht ab, sobald eine
Datei neu im Paket ist oder fehlt. Eine neue Datei unter einem freigegebenen
Verzeichnis erscheint damit als Zeile in der Diff dieser Liste und ist im Review
sichtbar, bevor sie ausgeliefert wird.

- Freigeben oder aktualisieren: `node scripts/release/build-source-package.mjs --commit <ref> --update-file-list`
  schreibt die Liste neu; die Änderung prüfen und mit dem Commit versionieren.
- Vor einer Veröffentlichung: `--since <früherer-ref>` zeigt, welche Dateien
  gegenüber dem Paket des früheren Stands neu sind oder fehlen. Diese Diff wird vor
  dem Upload durchgesehen und in der Freigabe vermerkt.
- Zusätzlich lehnt der Build Dateinamen für Zugangsdaten ab (`.env*`, `.npmrc`,
  `.netrc`, `.pgpass`, `.htpasswd`, `credentials.json`, `*.pem`, `*.key`, `*.p12`,
  `*.pfx`, `*.jks`, `*.keystore`, `id_rsa*` und Verwandte) sowie Inhalte mit
  privaten Schlüsseln, age-Identitäten, AWS-Zugangsschlüsseln, GitHub-, Slack- und
  `sk_live_`-Token.

Die Kontrolle ersetzt nicht die inhaltliche Durchsicht der Dateien: Sie stellt sicher,
dass jede ausgelieferte Datei bewusst in der Liste steht.

## Paket bauen

```bash
node scripts/release/build-source-package.mjs --commit <ref> [--out-dir dist/release]
```

Der Commit ist Pflicht. Der Build prüft zuerst, dass die Dateien des Builders
(`scripts/release/*`, `scripts/license-allowlist.mjs`) im Arbeitsverzeichnis
und im Commit identisch sind. Andernfalls hinge das Ergebnis vom lokalen
Skriptstand ab, und der Build bricht ab; er ist dann mit einem Checkout des
Commits auszuführen.

Ein veröffentlichtes Paket entsteht aus dem Merge-Commit auf `main`, nicht aus
einem Branch-Stand: `RELEASE.json` trägt den Commit, und er muss dem geprüften
Stand entsprechen. Das Skript `tests/release/source-package.test.ts` prüft den
Builder gegen `HEAD`; bei ungesicherten Änderungen an `scripts/release/*` zuerst
committen, dann testen oder bauen.

Ausgabe in `dist/release/` (nicht versioniert):

| Datei | Inhalt |
|---|---|
| `paolo-sms-<version>.tar.gz` | das Paket, alle Pfade unter `paolo-sms-<version>/` |
| `SHA256SUMS` | SHA-256 des Archivs im `sha256sum`-Format |

## Zusätzliche Dateien im Paket

Der Build ergänzt drei erzeugte Dateien, die nicht im Repository stehen dürfen:

- `RELEASE.json`: Name, Version, vollständiger Commit, Commit-Datum, Lizenz,
  höchste Migration (`latestMigration`), Anzahl der Migrationen,
  `backupSchemaVersion` aus `lib/backup/constants.ts` und die SHA-256 der
  Positivliste.
- `FILES.sha256`: SHA-256 jeder Datei im Paket außer ihr selbst.
- `THIRD-PARTY-LIST.md`: Pakete mit Lizenz und Verwendung, erzeugt aus dem
  `package-lock.json` des Commits.

## Paket prüfen

```bash
sha256sum -c SHA256SUMS
tar -xzf paolo-sms-<version>.tar.gz
cd paolo-sms-<version> && sha256sum -c FILES.sha256 --quiet
```

`RELEASE.json` nennt den Commit. Mit dem Entwicklungsrepository lässt sich das
Paket aus diesem Commit neu bauen und muss dieselbe SHA-256 ergeben.

## Lizenz und Drittanbieterhinweise

- `LICENSE`, `NOTICE` und `THIRD-PARTY-NOTICES.md` werden unverändert aus dem
  Commit übernommen. Die Logos, die `NOTICE` von der GPL-Gewähr ausnimmt,
  liegen wie im Docker-Image unter `public/`; `docs/logo/` ist nicht im Paket.
- `THIRD-PARTY-LIST.md` gehört zum Lockfile desselben Commits. Der Build
  bricht ab, wenn das Lockfile ein Paket ohne Lizenzangabe oder mit einer
  Lizenz außerhalb von
  [`scripts/license-allowlist.mjs`](../scripts/license-allowlist.mjs) enthält.
  Die Liste gilt für alle Pakete im Lockfile, also auch Entwicklungs- und
  optionale Plattformpakete. Die Allowlist wird auch von
  `npm run licenses:check` verwendet und nur nach Prüfung erweitert.
- Die Lizenztexte der Pakete liegen in den Paketverzeichnissen, die `npm ci`
  installiert; das Paket enthält sie nicht selbst.

## Datenbank und Rücknahme eines Updates

Das Paket enthält den vollständigen, geprüften Migrationssatz
(`drizzle/`, `scripts/migrate.psql`). `RELEASE.json` nennt dessen letzte
Migration. Ein Wechsel auf eine ältere Paketversion macht keine
Datenbankmigration rückgängig: Der Anwendungscode läuft dann gegen ein neueres
Schema. Das ist **nur** zulässig, wenn die Kompatibilität der älteren Version
mit dem migrierten Schema nachgewiesen ist, etwa bei rein additiven
Änderungen, die der ältere Code nicht benötigt. Andernfalls bleibt die
Wiederherstellung von Datenbank und Anhängen aus der Sicherung vor dem Update
(siehe [`backup-restore.md`](backup-restore.md) und
[`runbooks/production-docker-update.md`](runbooks/production-docker-update.md)).
Das Update-Konzept für Pakete muss dies je Release festhalten.

## Bekannte Grenzen

- `package.json` enthält Skripte für Entwicklungswerkzeuge, die im Paket fehlen
  (`e2e:*`, `demo:rebuild`, `help:generate`, `test:*`). Für den Betrieb gelten die
  Befehle der Anleitungen.
- Relative Markdown-Verweise im Paket zeigen nur auf Dateien im Paket; ein Test
  prüft das am echten Repository. Der Build meldet Abweichungen zusätzlich als Hinweis.
- Die Erstinstallation aus dem Paket steht in
  [`install-from-package.md`](install-from-package.md). Das Update aus dem Paket
  beschreibt [`update-from-package.md`](update-from-package.md);
  `runbooks/production-docker-update.md` gilt für Git-Installationen.
- Anhänge sind in der Sicherung nicht enthalten (siehe `backup-restore.md`).
- Das Paket ist nicht signiert; die SHA-256 sichert nur die Unversehrtheit
  gegenüber einem getrennt veröffentlichten Wert.
