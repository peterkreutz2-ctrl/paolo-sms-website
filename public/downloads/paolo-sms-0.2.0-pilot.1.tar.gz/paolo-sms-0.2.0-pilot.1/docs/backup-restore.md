# Datenbank-Backup und Wiederherstellung

PAOLO bietet globalen Administratoren unter `/dashboard/admin/backup` manuelle
PostgreSQL-Backups an. Diese Backups enthalten ausschließlich Datenbankdaten. Bytes aus
Vercel Blob oder lokalem Attachment-Storage sind nicht enthalten; Manifest und
Oberfläche weisen dies mit `attachmentsIncluded: false` aus. Für Docker-Installationen
sichert und stellt der Abschnitt „Vollständige Sicherung einer Docker-Installation“
Datenbank, Anhänge und Konfiguration gemeinsam wieder her.

**Experimentelle AI-Daten:** Falls noch AI-Tabellen vorhanden sind, lässt der
wiederholbare Migrationslauf sie unverändert; er erzeugt kein Archivschema.
Für deren Sicherung und Wiederherstellung einen vollständigen `pg_dump`
verwenden; der begrenzte `paolo_data`-Export enthält sie nicht. Vorhandene
Artefaktdateien separat sichern. Betreiber prüfen diese Altbestände unabhängig
von den aktiven Anwendungsdaten; siehe [Migrationen](database-migrations.md).

Alle Archive werden zwingend mit `age` verschlüsselt. Private Identitäten dürfen
nicht auf dem App-Server liegen. Dateisystemrechte, Datenträgerverschlüsselung,
geschützte Übertragung und externe/off-site Kopien bleiben zusätzlich notwendig.

## Wofür dieses Dokument gilt

Die Anforderungen dieses Dokuments — dauerhaft verschlüsselte Archive, externe
Kopien, Aufbewahrungsregel und erprobter Restore — gelten für **echte
Betreiberdaten**: die Datenbank einer Vereins- oder Flugschulinstallation mit
realen Sicherheitsmeldungen, Personenbezug und Betriebsrelevanz. Dort sind sie
nicht verhandelbar, und ein Verzicht ist auch dann keine Option, wenn der
Datenbestand klein ist.

Sie gelten **nicht** unverändert für Umgebungen, die ausschließlich
unkritische Spiel- und Testdaten enthalten. Für diese ist eine einfache,
unverschlüsselte Sicherung als technische Rückfallmöglichkeit ausreichend — ein
`pg_dump` an einem zugriffsbeschränkten Ort, angelegt vor einem riskanten
Schritt und danach entbehrlich. Maßgeblich ist der Inhalt der Datenbank, nicht
der Name der Umgebung: Entscheidend ist, ob ein Verlust jemandem schadet und ob
die Daten vertraulich sind.

Das betrifft insbesondere `Reference Prod`, die produktionsnahe
Referenzinstallation des Projektteams. Sie ist produktionsförmig aufgebaut,
enthält aber definitionsgemäß keine realen Betreiberdaten (siehe
[`production-readiness.md`](production-readiness.md)). Ihre Daten sind nicht
vertraulich, und ihr Verlust ist hinnehmbar — sie ließe sich neu aufsetzen und
neu befüllen. Für sie ist deshalb **keine dauerhaft verschlüsselte Sicherung
einzurichten**, und es ist dafür auch keine zusätzliche Backup-Infrastruktur
aufzubauen: keine `age`-Schlüsselverwaltung, kein Backup-Cron, kein externer
Ablageort.

Zwei Punkte bleiben davon unberührt:

- Die **Anwendungsfunktion** unter `/dashboard/admin/backup` verschlüsselt
  weiterhin ausnahmslos. Dieser Abschnitt lockert keine Programmvorgabe,
  sondern beschreibt, für welche Umgebungen der **betriebliche** Aufwand
  ringsherum verlangt ist.
- Wird eine bislang unkritische Umgebung jemals mit echten Meldungen befüllt,
  gilt ab diesem Zeitpunkt der strenge Maßstab — rückwirkend für alles, was
  dann in ihr liegt.

Die risikoabgestufte Entscheidung vor einer Migration ist in Abschnitt 2 der
[`release-checklist.md`](release-checklist.md) bereits so vorgesehen: ein
bewusster Verzicht bei geringem Risiko, mit kurzer Begründung und benannter
Freigabe.

## Konfiguration

```env
BACKUP_ENGINE=pg_dump
BACKUP_DIR=
PG_DUMP_PATH=
PG_RESTORE_PATH=
AGE_PATH=age
BACKUP_AGE_RECIPIENTS=age1operator...,age1recovery...
BACKUP_CRON_SECRET=<mindestens-32-zufällige-zeichen>
BACKUP_CRON_MIN_INTERVAL_MINUTES=1440
BACKUP_CRON_MAX_RUNTIME_MINUTES=120
BACKUP_RETENTION_ENABLED=true
BACKUP_RETENTION_DAILY_DAYS=14
BACKUP_RETENTION_WEEKLY_WEEKS=8
BACKUP_RETENTION_MONTHLY_MONTHS=12
```

`BACKUP_DIR` ist standardmäßig `<Projekt>/backups`; auch ein leerer Wert nutzt
diesen Standard. `pg_dump` erzeugt das bevorzugte PostgreSQL-Custom-Format.
`paolo_data` ist der binärfreie, gzip-komprimierte und streamingfähige
Daten-Fallback ohne Schema.

`BACKUP_AGE_RECIPIENTS` enthält mindestens einen öffentlichen age-Empfänger,
mehrere Empfänger werden durch Kommas getrennt. Empfohlen sind ein operativer
und ein getrennt verwahrter Recovery-Schlüssel. Die privaten Identitäten gehören
weder in `.env` noch in Repository, Image, App-Dateisystem oder Backup-Volume.
Gehen alle privaten Identitäten verloren, sind die Backups nicht wiederherstellbar.

Ein Schlüsselpaar wird auf einem vertrauenswürdigen Administrator-Rechner
erzeugt, nicht im App-Container:

```bash
age-keygen -o paolo-backup-identity.txt
age-keygen -y paolo-backup-identity.txt > paolo-backup-recipient.txt
```

Der Inhalt von `paolo-backup-recipient.txt` wird in
`BACKUP_AGE_RECIPIENTS` eingetragen. `paolo-backup-identity.txt` ist der private
Schlüssel, muss besonders geschützt und darf nicht an den App-Server übertragen
werden. Für den empfohlenen Recovery-Empfänger wird dieser Vorgang auf einem
zweiten vertrauenswürdigen Gerät wiederholt.

## Geplante Backups per Cron

Ein externer Scheduler kann ein Backup über einen authentifizierten HTTP-POST
auslösen. Das Secret gehört ausschließlich in den `Authorization`-Header und
niemals in URL, Query-String oder Cron-Logs:

Das Secret kann beispielsweise mit `openssl rand -hex 32` erzeugt werden. Für
System-Cron wird eine nur für `root` lesbare curl-Konfiguration empfohlen, damit
das Secret weder in der Crontab noch in der Prozessliste steht:

```text
# /etc/paolo/backup-cron.curl (Dateirechte 0600)
url = "https://paolo.example.org/api/cron/backup"
request = "POST"
header = "Authorization: Bearer <BACKUP_CRON_SECRET>"
silent
show-error
fail-with-body
```

Beispiel für einen täglichen System-Cron um 03:15 Uhr:

```cron
15 3 * * * /usr/bin/curl --config /etc/paolo/backup-cron.curl
```

`BACKUP_CRON_MIN_INTERVAL_MINUTES` begrenzt Startversuche instanzübergreifend
und persistent (Standard: 24 Stunden). Eine atomare Datenbank-Lease verhindert
parallele Cron-Ausführungen; sie läuft nach `BACKUP_CRON_MAX_RUNTIME_MINUTES`
ab, falls ein Prozess abstürzt. Zusätzlich schützt der vorhandene
Dateisystem-Lock die eigentliche Backup-Erstellung.

Antworten: `201` mit Backup-ID bei Erfolg, `401` ohne gültiges Secret, `409` bei
laufendem Backup, `429` im Mindestintervall und `5xx` bei Betriebsfehlern.
`409`/`429` enthalten `Retry-After`. Fehlgeschlagene Authentifizierungen werden
ohne Header-Inhalt serverseitig protokolliert; fachliche Ablehnungen, Fehler und
Erfolge erscheinen im Audit-Log.

## Automatische Aufbewahrung

Nach jedem erfolgreich erstellten manuellen oder geplanten Backup wird die
Aufbewahrungsregel angewendet. Standardmäßig bleiben erhalten:

- alle gültigen Backups der letzten 14 Tage,
- das jeweils neueste Backup jeder der letzten 8 ISO-Kalenderwochen,
- das jeweils neueste Backup jedes der letzten 12 Kalendermonate.

Die Werte werden mit `BACKUP_RETENTION_DAILY_DAYS`,
`BACKUP_RETENTION_WEEKLY_WEEKS` und `BACKUP_RETENTION_MONTHLY_MONTHS`
konfiguriert. `0` deaktiviert die jeweilige Generation. Unabhängig von der
Konfiguration bleibt immer mindestens das neueste gültige Backup erhalten.
`BACKUP_RETENTION_ENABLED=false` deaktiviert automatische Löschungen vollständig.

Beim Löschen werden das verschlüsselte `.age`-Archiv und sein Manifest entfernt.
Die Bereinigung läuft unter dem Backup-Dateisystem-Lock. Ein Fehler bei der
Bereinigung macht das zuvor erfolgreich erstellte Backup nicht ungültig und wird
separat protokolliert und auditiert. Externe/off-site Kopien benötigen eine
entsprechende eigene Aufbewahrungsregel.

Jedes vollständige Backup besteht aus einem `.age`-Archiv und
`<id>.manifest.json`. Das Manifest enthält Ciphertext- und Klartext-Prüfsummen,
aber keine Schlüssel. Nur vollständige, gültige Paare werden gelistet. Archiv
und Manifest müssen gemeinsam extern kopiert werden. Downloads sind
global-admin-geschützt und auditiert.

## Sicherer Restore-Ablauf

> **Gelöschte Konten:** Ein Backup enthält Konten, die später über „Konto löschen“
> entfernt wurden. Ein Restore stellt bei Better Auth das Konto samt Passwort-Hash und
> Rollen wieder her. Bei Clerk kehren nur die Rollenzeilen zurück; das Konto selbst bleibt
> beim Anmeldedienst gelöscht und erscheint als „Konto fehlt“ (bereinigbar). Nach einem
> Restore sind Löschungen daher erneut durchzuführen, wenn sie fortbestehen sollen.

1. Wartungsfenster herstellen und alle Schreibzugriffe stoppen.
2. Archiv und Manifest in `BACKUP_DIR` legen.
3. `DATABASE_URL` bewusst auf das Ziel setzen und die angezeigten Werte prüfen.
4. Eine passende private age-Identität über `--identity` angeben.
5. Die exakte Bestätigung `RESTORE:<datenbank>` angeben.
6. Nach Abschluss Anmeldung, Rollen, Meldungen, Maßnahmen, Dokumente,
   Audit-Log und Zeilenzahlen prüfen. Anhänge werden von diesem Ablauf nicht
   wiederhergestellt; bei Docker-Installationen den Abschnitt „Vollständige
   Sicherung einer Docker-Installation“ verwenden.

### pg_dump-Custom-Format

```bash
npm run backup:restore -- <backup-id> --identity=<schlüsseldatei> --confirm=RESTORE:<datenbank>
```

Die CLI validiert das verschlüsselte Archiv, entschlüsselt in eine restriktive
temporäre Datei, prüft deren Größe und SHA-256 und startet `pg_restore` ohne
Shell mit `--clean --if-exists --no-owner --no-privileges
--single-transaction --exit-on-error`. Die Klartextdatei wird in `finally`
entfernt.

### PAOLO-Datenarchiv

```bash
npm run backup:restore-data -- <backup-id> --identity=<schlüsseldatei> --confirm=RESTORE:<datenbank>
```

Das Ziel muss leer und mit genau den Migrationen dieser PAOLO-Version erstellt
sein. Die CLI führt keine Migrationen aus. Migrierte Standardrollen sind die
einzige tolerierte Baseline. Tabellen-Allowlist, Reihenfolge, Schema-Version,
Prüfsummen und Zeilenzahlen werden validiert. Der Import läuft in einer
Transaktion und wird bei Fehler vollständig zurückgerollt. Ein Merge in eine
bestehende Datenbank wird nicht unterstützt.

## Vollständige Sicherung einer Docker-Installation

Eine vollständige Sicherung besteht aus drei Teilen, die zusammengehören:

| Teil | Inhalt | Sicherungsdatei im Backup-Volume |
|---|---|---|
| Datenbank | alle PostgreSQL-Daten (`pg_dump`, `age`-verschlüsselt) | `<id>.dump.age` und `<id>.manifest.json` |
| Anhänge | alle Dateien des lokalen Speichers (`STORAGE_PROVIDER=local`) | `attachments/attachments-<zeit>.tar.age` und `.manifest.json` |
| Konfiguration | `config/` des Betreibers (enthält Geheimnisse) | `config-<zeit>.tar.age` |

Nicht gesichert und nicht nötig: das Docker-Image (aus dem Paket neu baubar),
Zertifikate von Let's Encrypt (neu ausstellbar) und die Container. **Aufzubewahren
ist außerdem das Quellpaket der installierten Version**; seine Version steht in
den Anhangsmanifesten (`paoloVersion`, `latestMigration`). Anhänge in Vercel Blob
sichert dieses Verfahren nicht.

### Sicherung erstellen

Im Paket-Layout (Linux-Host):

```bash
PAOLO=/opt/paolo-sms/current/scripts/deploy
sh $PAOLO/paolo-backup.sh create            # mit Nginx-Overlay: paolo-backup.sh --prod create
```

Das Skript erzeugt im laufenden Betrieb zuerst das Datenbank-Backup (wie die
Weboberfläche, mit Audit-Ereignis `BACKUP_CREATED`), danach das Anhangsarchiv und
das Konfigurationsarchiv. Die Konfiguration (Rechte `0600`) liest der Host und
übergibt sie über die Standardeingabe; der Container-Benutzer könnte die Datei nicht
lesen. Kann `tar` eine Datei nicht lesen, bricht die Sicherung ab und hinterlässt
kein unvollständiges Archiv. Die Reihenfolge ist Absicht: Eine Datei, die zwischen
beiden Schritten hochgeladen wird, liegt im Archiv ohne Datenbankzeile (harmlos);
umgekehrt entstünde ein Verweis ohne Datei. Für einen exakt zusammenpassenden
Stand die Anwendung vorher stoppen (`$PAOLO/paolo-compose.sh stop app`). Das
Mindestintervall des HTTP-Crons gilt hier nicht.

Die Ausgabe nennt beide Kennungen (`BACKUP_ID`, `ATTACHMENTS_ID`). Jedes
Anhangsmanifest enthält die zugehörige `dbBackupId`; über diese Kennung findet die
Wiederherstellung das passende Archiv. Anhangsarchive liegen bewusst in einem
Unterverzeichnis und unterliegen **nicht** der automatischen Aufbewahrung der
Datenbank-Backups. Sie wachsen mit dem Anhangsbestand; ältere Archive nach der
externen Kopie manuell entfernen.

Ohne das Skript, zum Beispiel unter Windows:

```bash
docker compose ... run --rm --no-deps -T app sh /app/scripts/backup-installation.sh create
tar -C <pfad>/config -cf - . | docker compose ... run --rm --no-deps -T app sh /app/scripts/backup-installation.sh config-archive
```

### Sicherung aus dem Server herausholen

Eine Sicherung auf demselben Datenträger schützt nicht vor dem Verlust des
Servers. Das gesamte Volume `paolo-sms_paolo-backup-data` verschlüsselt an einen
anderen Ort kopieren (die Dateien sind bereits `age`-verschlüsselt):

```bash
docker run --rm -v paolo-sms_paolo-backup-data:/b:ro -v "$PWD":/out alpine \
  tar -C /b -cf /out/paolo-backup-$(date -u +%Y%m%dT%H%M%SZ).tar .
```

Die private `age`-Identität gehört **nicht** auf den Server und nicht in dieselbe
Ablage wie die Sicherung.

### Vollständige Wiederherstellung auf einer neuen Installation

Voraussetzung: eine Installation derselben Paketversion (oder einer neueren) nach
[`install-from-package.md`](install-from-package.md), **ohne** Bootstrap, mit leerem
Anhangsspeicher. Eine ältere Version als die Sicherung wird nicht unterstützt, weil
der Restore das Schema der Sicherung zurückspielt.

1. Konfiguration wiederherstellen: auf dem Administrator-Rechner
   `age -d -i identity.txt config-<zeit>.tar.age | tar -x -C /opt/paolo-sms/config`.
   Bei einer neuen Domain danach `APP_BASE_URL` und `BETTER_AUTH_URL` anpassen.
2. Die Sicherungsdateien zurück in das Volume `paolo-sms_paolo-backup-data` legen
   (Umkehrung des Kopierbefehls oben) und Datenbank starten:
   `paolo-compose.sh up -d db`, `paolo-compose.sh build app`.
3. Schema der Installation herstellen: `paolo-compose.sh run --rm --no-deps -T app sh /app/scripts/migrate.sh`.
4. Wiederherstellen (die Identität übergibt der Host über die Standardeingabe; sie
   liegt nur für die Dauer des Aufrufs in `/tmp` des Containers):

   ```bash
   sh $PAOLO/paolo-backup.sh restore <backup-id> \
     --identity /sicherer/pfad/identity.txt --confirm RESTORE:paolo
   ```

   Vor jeder Änderung prüft das Skript, dass das Anhangsarchiv vorhanden, unversehrt
   und entschlüsselbar ist und dass der Anhangsspeicher leer ist. Dann ersetzt es die
   Datenbank (`pg_restore --clean`, in einer Transaktion) und entpackt die Anhänge.
   `--replace-attachments` ersetzt einen nicht leeren Speicher, `--without-attachments`
   stellt nur die Datenbank wieder her.
5. Schema auf den Stand der installierten Version bringen (bei einer neueren Version
   als die Sicherung): `paolo-compose.sh run --rm --no-deps -T app sh /app/scripts/migrate.sh`.
6. Anwendung starten und prüfen: Anmeldung (Better Auth: mit dem Passwort der
   Sicherung), Meldungen, Maßnahmen, Anhang herunterladen, Audit-Log.

Nach einem Restore sind später gelöschte Konten wieder vorhanden (siehe Hinweis
oben).

### Nur die Datenbank wiederherstellen

Im Image steht das Werkzeug ohne `npm` bereit:

```bash
paolo-compose.sh run --rm --no-deps -T -v /pfad/identity.txt:/run/id:ro app \
  node scripts/backup-restore.mjs <backup-id> --identity=/run/id --confirm=RESTORE:paolo
```

Anhänge bleiben dabei unverändert. Das Archiv eines `paolo_data`-Backups
stellt `scripts/backup-restore-data.mjs` wieder her.

### Nachgewiesener Stand

Das Verfahren wurde mit einem aus dem Quellpaket gebauten Image und auf einem
Linux-Betreiberhost erprobt: Wegwerf-Installation mit Spieldaten, Konto und Anhängen
(0 Byte bis 5 MiB, Umlaute und Leerzeichen im Namen, auch bei leerem Anhangsspeicher),
Sicherung, Zerstörung aller Volumes, Wiederherstellung auf einer neuen Installation und
Vergleich der Tabellen (Zeilenzahl und Prüfsumme), der Dateien (SHA-256) und der Downloads
über die laufende Anwendung samt Anmeldung mit dem alten Passwort. Dazu Negativproben
(falsche Identität, manipuliertes Archiv, nicht lesbare Anhangsdatei, nicht leeres Ziel,
falsche Bestätigung). Dabei fielen mehrere Fehler auf, die behoben sind: `pg_restore` ohne
`--dbname`, ein PostgreSQL-Client neuer als der Datenbankserver, stille Teilarchive bei
`tar`-Fehlern, ein leerer Anhangsspeicher als Fehlerfall und für den Container nicht lesbare
Konfiguration und Identität. Nicht erprobt: sehr große Datenmengen, Anhänge in Vercel
Blob und der Weg über Clerk. Ein Betreiber sollte vor dem Echtbetrieb dieselbe Probe mit
eigenen Schlüsseln auf einer Wegwerf-Instanz durchführen; Restore-Proben gehören nie auf
die produktive Installation.

## Temporäre Klartextdateien

Bei Erstellung und Restore existiert das Klartextarchiv kurzzeitig als
restriktive temporäre Datei im Backup-Verzeichnis. Es wird unmittelbar nach der
Verschlüsselung und in jedem Fehlerpfad entfernt. Eine spätere direkte
Streaming-Integration kann dieses Klartext-Zeitfenster eliminieren.

## Docker und Betrieb

Das Runtime-Image enthält `age` und den PostgreSQL-Client in der Hauptversion des
mitgelieferten Datenbankservers (`postgres:16`, Build-Argument
`POSTGRES_CLIENT_VERSION`). Die Hauptversionen müssen übereinstimmen: Ein neuerer
`pg_restore` schreibt Anweisungen, die ein älterer Server ablehnt, ein älterer
`pg_dump` bricht gegen einen neueren Server ab. Bei einem Datenbankserver anderer
Hauptversion das Image mit `--build-arg POSTGRES_CLIENT_VERSION=<version>` bauen. Compose bindet das
persistente Volume `paolo-backup-data` unter `/app/backups` ein. Der Container
läuft als nicht-root Benutzer und erhält keinen Docker-Socket. Ein externer
Backup-Job oder Sidecar bleibt eine Alternative.

Managed-Provider-Snapshots bzw. Point-in-Time-Recovery ergänzen die exportierten
Backups. Regelmäßige externe Kopien und dokumentierte Restore-Proben bleiben
notwendig. Ein Web-Restore ist nicht Bestandteil dieses MVP.
