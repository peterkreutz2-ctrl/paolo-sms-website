# Missbrauchsschutz öffentlicher Meldungen und Downloads betreiben

Dieses Runbook beschreibt den laufenden Betrieb des Rate Limits für
`POST /submit-report` und öffentliche Dokumentanhänge unter
`/communications/attachments/`: Schutzschichten, Konfiguration, Aufräumen der
Rate-Limit-Tabelle und die regelmäßigen Prüfungen. Die Ersteinrichtung steht in
[`../setup-ubuntu.md`](../setup-ubuntu.md) und
[`../docker-vm-deployment.md`](../docker-vm-deployment.md); dieses Runbook
ersetzt sie nicht.

Alle Kommandos beziehen sich auf eine Docker-Installation. Für die native
Ubuntu-Installation gilt dasselbe fachlich, nur ohne den
`docker compose exec`-Vorspann.

## Schutzschichten

| Schicht | Wirkung | Ort |
|---|---|---|
| Nginx: Meldung | nur POST auf `/submit-report` und dessen Slash-Variante: `10r/m`, Burst 2, ohne Verzögerung | `deploy/nginx/conf.d/00-rate-limits.conf` und `snippets/app.conf` |
| Nginx: Dokumentanhänge | alle Methoden unter `/communications/attachments/`, einschließlich GET/HEAD: `60r/m`, Burst 20, ohne Verzögerung | eigene Zone in denselben Dateien |
| Nginx-Body-Limit | Formular 256 KiB, übrige Requests 5 MiB für interne Uploads bis 4 MiB | `snippets/app.conf` |
| Anwendungslimit: Meldung | standardmäßig 5 gespeicherte Meldungen je Organisation, Identifier und fester Uhrstunde | Tabelle `public_report_rate_limits`, Scope `public_report_create` |
| Anwendungslimit: Download | standardmäßig 300 Abrufe nach Freigabeprüfung je Organisation, Identifier und fester Uhrstunde | dieselbe Tabelle, Scope `public_attachment_download` |
| Idempotenz | wiederholtes Absenden derselben Einreichung erzeugt genau einen Report | `reports.public_submission_id` |

Für die Beurteilung von Auffälligkeiten wichtig:

- Die Nginx-Zone zählt je Client-IP. Ein Verein, eine Flugschule oder ein
  Veranstaltungs-WLAN hinter einem NAT-Anschluss zählt als **ein** Client.
  Mehrere Personen, die nacheinander vom selben Anschluss melden, teilen sich
  dasselbe Kontingent.
- Das Anwendungslimit für Meldungen zählt nur **erfolgreich gespeicherte** Meldungen.
  Validierungsfehler und fehlgeschlagene Inserts verbrauchen kein Kontingent.
- Die Download-Zone gilt gemeinsam für alle Attachment-IDs und Dateinamen;
  auch ungültige IDs werden am Edge begrenzt. Die Anwendung zählt dagegen
  erst nach der Freigabeprüfung und vor dem Storage-Zugriff. Das begrenzt
  zugelassene Abrufe, nicht erfolgreich vollständig übertragene Dateien.
- Nginx begrenzt Request-Spitzen; die Anwendung die Nutzung über eine feste
  Uhrstunde. Die unterschiedlichen Werte sind Absicht. Beide Scopes sind
  getrennt; viele Downloads verbrauchen kein Meldungskontingent.
- Nur ausdrücklich freigegebene Anhänge öffentlicher SMS-Dokumente sind
  anmeldefrei abrufbar. Meldungsanhänge bleiben intern. Freigaben werden bei
  jedem Abruf geprüft; `no-store` bleibt für sofortigen Widerruf erhalten.

Der Identifier ist ein HMAC über die normalisierte Client-IP; IPv6-Adressen
werden dabei auf das `/64`-Präfix zusammengefasst. Nginx zählt einzelne
IPv6-Adressen. Die Rate-Limit-Tabelle speichert keine rohen IP-Adressen oder
User-Agents; Nginx-Zugriffslogs können diese unabhängig davon enthalten.

## Konfiguration

| Variable | Bedeutung | Standard |
|---|---|---|
| `PUBLIC_REPORT_RATE_LIMIT_SALT` | gemeinsames installationsspezifisches Geheimnis für beide HMAC-Identifier | keiner, **in Produktion setzen** |
| `PUBLIC_REPORT_RATE_LIMIT_MAX_ACCEPTED` | gespeicherte Meldungen je Identifier/Uhrstunde, 1 bis 10.000 | `5` |
| `PUBLIC_ATTACHMENT_RATE_LIMIT_MAX` | zugelassene öffentliche Download-Abrufe je Identifier/Uhrstunde, 1 bis 100.000 | `300` |
| `PUBLIC_REPORT_RATE_LIMIT_RETENTION_DAYS` | Löschschwelle in Tagen für Buckets beider Scopes, zulässig 1 bis 365; keine garantierte Obergrenze | `1` |
| `PUBLIC_REPORT_RATE_LIMIT_TRUSTED_IP_HEADER` | Header, aus dem beide Limiter die Client-IP zuerst lesen | `X-Forwarded-For` |

Fehlt der konfigurierte Header im Request, greift die Anwendung auf bekannte
Alternativen zurück (`X-Forwarded-For`, `X-Real-IP`, `CF-Connecting-IP`). Auf
dem dokumentierten Weg ist das unkritisch, weil Nginx `X-Real-IP` und
`X-Forwarded-For` selbst mit `$remote_addr` überschreibt und Clientwerte damit
verwirft. Ein abweichend konfigurierter Header muss ebenfalls vom Proxy
vertrauenswürdig gesetzt werden. Hinter einem zusätzlichen Load Balancer oder
CDN braucht es eine explizite Vertrauenskette — siehe den letzten Abschnitt.

Ohne gesetztes Salt lehnt die Anwendung in Produktion öffentliche Einreichungen ab
(fail closed). Das ist beabsichtigt: Ohne Salt gäbe es keinen tragfähigen
Identifier und damit keinen Schutz. In der Entwicklung existiert ein
Fallback-Salt für Meldungen. Öffentliche Downloads bleiben dagegen bei
fehlendem Salt/IP oder Zählerfehlern erlaubt (fail open), damit
Sicherheitsinformationen verfügbar bleiben. Das Nginx-Limit wirkt unabhängig
davon weiter; die Freigabeprüfung wird nie übersprungen.

Die Raten stehen in `deploy/nginx/conf.d/00-rate-limits.conf`, Burst- und
Body-Limits im gemeinsamen `deploy/nginx/conf.d/snippets/app.conf`. HTTP und
HTTPS binden dasselbe Snippet ein. Die native Ubuntu-Anleitung installiert
dieselben Dateien. Zonendefinitionen genau einmal im `http`-Kontext laden;
das Snippet gehört in den `server`-Kontext. Nach jeder Änderung `nginx -t`
ausführen und Nginx neu laden. Ein App-Neustart allein aktiviert keine
Nginx-Änderung. Die gemeinsame Datei mit ihrem Unterverzeichnis muss auch bei
bereits umbenannten/angepassten TLS-Konfigurationen vorhanden und eingebunden sein.

Die Downloadrate ist ein Startwert ohne Betriebserfahrung: insbesondere
Vereins-NAT, mehrere Bilder und Videoabrufe beobachten. Sie ist kein
Bandbreitenlimit; 300 vollständige Abrufe à 4 MiB ergeben rund 1,17 GiB je
Identifier/Uhrstunde. Ein Kontingent kann an der Stundengrenze neu beginnen.

### Fehlerantworten unterscheiden

| Quelle | Antwort |
|---|---|
| Nginx-Formularzone | HTTP 429, `Retry-After: 6`, `Cache-Control: no-store` |
| Nginx-Downloadzone | HTTP 429, `Retry-After: 1`, `Cache-Control: no-store` |
| Download-Anwendungslimit | HTTP 429, `Retry-After` mit Restdauer des Stundenfensters, `no-store` |
| Report-Server-Action | `resultCode: rate_limited` und `retryAfterSeconds` im Action-Ergebnis; kein eigener HTTP-429-Status |
| Nginx-Body-Limit | HTTP 413, ohne Weiterleitung an die App |

Die kurzen Nginx-Wartewerte entsprechen dem Abstand bis zum nächsten freien
Platz; weitere gleichzeitige Requests derselben IP können ihn wieder belegen.
Upstream-429 behalten ihre eigenen Header; erfolgreiche Antworten erhalten
keinen zusätzlichen Rate-Limit-`Retry-After`.

## Aufräumen der Rate-Limit-Tabelle

Abgelaufene Buckets werden **beiläufig beim Absenden einer Meldung** entfernt,
in Batches von höchstens 1.000 Zeilen. Ein zusätzlicher täglicher Job ist
bewusst nicht vorgesehen: Der Mechanismus bleibt damit einfach und
wartungsfrei.

Daraus folgt eine Eigenschaft, die man kennen muss: **Auf einer Installation
ohne eingehende Meldungen wird nicht aufgeräumt — auch nicht bei regelmäßigem
Downloadverkehr.** Der Cleanup betrifft beide Scopes, wird aber nicht pro
Download ausgelöst. Bei der erwarteten Nutzung —
wenige Meldungen pro Monat — können pseudonymisierte Identifier deshalb
deutlich länger liegen bleiben, als `PUBLIC_REPORT_RATE_LIMIT_RETENTION_DAYS`
vermuten lässt. Die Aufbewahrungsfrist ist eine Untergrenze für die Löschung,
keine garantierte Obergrenze für die Speicherdauer. Wer eine harte Obergrenze
zusichern will, räumt zusätzlich manuell auf:

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml exec -T db \
  psql -v ON_ERROR_STOP=1 -U paolo -d paolo -c "
DELETE FROM public_report_rate_limits
WHERE window_start < now() - interval '1 day';
"
```

Das Intervall an die eigene Aufbewahrungsfrist anpassen. Das Kommando ist
idempotent und gefahrlos wiederholbar; es löscht ausschließlich abgelaufene
Zählerstände, keine Meldungen.

## Regelmäßige Prüfungen

### Umfang der Tabelle und ältester Eintrag

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml exec -T db \
  psql -U paolo -d paolo -c "
SELECT count(*) AS buckets,
       min(window_start) AS aeltester_bucket,
       max(window_start) AS juengster_bucket
FROM public_report_rate_limits;
"
```

Erwartung bei normalem Betrieb: wenige Zeilen, und `aeltester_bucket` liegt
innerhalb der konfigurierten Aufbewahrungsfrist. Liegt er deutlich darüber, kam
seit der Frist keine Meldung mehr an — siehe den Abschnitt zum Aufräumen.

### Blockierte Fenster

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml exec -T db \
  psql -U paolo -d paolo -c "
SELECT scope, window_start, accepted_count, blocked_count
FROM public_report_rate_limits
WHERE blocked_count > 0
ORDER BY window_start DESC
LIMIT 20;
"
```

`blocked_count` ist die maßgebliche Quelle für Blockierungen am
Anwendungslimit. `accepted_count` bedeutet je nach Scope Unterschiedliches:
bei Meldungen gespeicherte Einreichungen, bei Downloads historisch **alle**
Versuche nach der Freigabeprüfung einschließlich blockierter Versuche.
Nicht ungefiltert über beide Scopes summieren. Der Identifier wird bewusst
nicht mit ausgegeben; für die Betriebsbeurteilung genügen Zeitpunkt und Anzahl.

### 429-Antworten von Nginx

Das offizielle Nginx-Image schreibt Zugriffs- und Fehlerlog nach `stdout` und
`stderr`. `/var/log/nginx/access.log` im Container ist nur ein Symlink dorthin
und enthält keine Historie — die Auswertung läuft deshalb über das Docker-Log:

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml logs nginx \
  | grep 'POST /submit-report' | grep -c ' 429 '
```

Für die zeitliche Verteilung dasselbe Kommando ohne `-c` und mit `tail`.
Zusätzlich vermerkt Nginx jede Begrenzung im Fehlerlog:

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml logs nginx \
  | grep 'limiting requests'
```

Der Eintrag `limiting requests` stammt aus der Nginx-Zone; diese Requests
erreichen die Anwendung nicht und tauchen deshalb nicht in der Datenbank auf.
Das reine Zugriffslog kann bei Downloads zusätzlich 429 der Anwendung enthalten.
Downloadverkehr lässt sich mit `grep '/communications/attachments/'` eingrenzen.
Wie weit das Docker-Log zurückreicht, hängt vom Log-Treiber und dessen Rotation ab.

### Anwendungslog

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml logs app \
  | grep -E 'public-(report|attachment)-rate-limit'
```

Sichtbar sind Aufräumläufe, Cleanup-Fehler, Fehler der Downloadzählung und der
erste am Anwendungslimit blockierte Meldeversuch eines Stundenfensters. Dieser
einmalige `console.info`-Eintrag enthält Organisation, Scope, Grenzwert,
Fensterdauer und Grund. Er enthält weder Client-IP, Identifier-Hash noch
Meldungsinhalt. Spätere Blockierungen desselben Fensters erhöhen nur
`blocked_count`.

Der Console-Eintrag ist ein Betriebssignal im Server-/Containerlog und
ausdrücklich **kein** fachlicher Eintrag in der Applikations-Auditlog-Tabelle
`audit_logs`. DB-Fehlerdetails in anderen Logzeilen trotzdem als interne
Betriebsdaten behandeln.

## Reaktion auf Auffälligkeiten

| Beobachtung | Wahrscheinliche Ursache | Vorgehen |
|---|---|---|
| Viele 429 aus einer einzelnen Quelle, keine neuen Meldungen | automatisierter Versuch | nichts tun, der Schutz wirkt. Bei Dauerlast die Zone enger stellen oder die Quelle auf Netzebene sperren |
| Legitime Meldende werden begrenzt | gemeinsamer NAT-Anschluss, etwa Verein oder Veranstaltung | Nginx-429 und Action-Ergebnis unterscheiden; bei Stundenkontingent `PUBLIC_REPORT_RATE_LIMIT_MAX_ACCEPTED`, bei Spitzen die Nginx-Zone prüfen. Direkten Weg über Sicherheitsverantwortliche anbieten |
| `blocked_count` für Meldungen steigt ohne 429 im Zugriffslog | die Server Action meldet ihr fachliches Limit im Ergebnis | prüfen, ob das Kontingent für die Installation zu klein ist |
| Bilder/Downloads liefern 429 | Nginx-Spitze oder Stundenkontingent, oft gemeinsamer NAT | Quelle anhand Warteheader und Nginx-Fehlerlog unterscheiden; passendes Limit prüfen |
| Ungewöhnlich viele gespeicherte Meldungen ohne Blockierungen | echte Melde-Welle oder Missbrauch unterhalb der Schwellen | Inhalte fachlich sichten, bevor an den Limits gedreht wird |
| Tabelle wächst dauerhaft | kein Aufräumen mangels Meldungen | manuelles Aufräumkommando ausführen |

Beim Anpassen der Limits gilt die Grundhaltung des Systems: Eine abgewiesene
legitime Meldung ist teurer als eine durchgelassene Spam-Meldung. Im Zweifel
lieber annehmen.

## Grenzen dieses Schutzes

- **Kein Audit-Log-Eintrag je Blockversuch.** Das ist bewusst so, um die
  Meldungshistorie nicht mit Betriebsereignissen zu füllen. Nur der erste
  blockierte Meldeversuch eines Fensters erscheint einmalig im Console-/Containerlog;
  App-Blockierungen bleiben zusätzlich über `blocked_count` erkennbar.
- **Meldungen: fail closed.** Fehlt in Produktion das Salt oder ist die Client-IP nicht auswertbar, wird
  die Einreichung abgelehnt. Das ist eine bewusste Entscheidung; die
  Fehlermeldung verweist die meldende Person zusätzlich auf den direkten Weg zu
  den Sicherheitsverantwortlichen. Dieser Weg muss auf der Installation
  tatsächlich erreichbar und benannt sein.
- **Downloads: fail open bei Zählerproblemen.** Freigabeprüfung und
  Nginx-Schutz bleiben bestehen; ohne Nginx fehlt diese zusätzliche Schicht.
- **Hostinggrenze.** Ohne den dokumentierten Nginx-Weg (z. B. Vercel) gelten
  nur die App-Limits und Plattformgrenzen. Die 256-KiB-Grenze gilt für den
  Formular-URL-Pfad am Nginx-Eingang, nicht pauschal für jede mögliche
  Server-Action-Aufrufadresse. Next.js bleibt global bei 5 MiB für Uploads;
  `proxyClientMaxBodySize` ist eine Puffergrenze, kein Ersatz für HTTP 413.
- **HEAD verwendet weiterhin den GET-Handler.** Es gelten dieselbe Freigabe
  und beide Download-Limits; ein reiner Metadatenabruf ohne Storage-Öffnung
  ist hier nicht eingeführt. So bleibt insbesondere 404 bei fehlender Datei
  erhalten, ohne eine zweite Storage-Schnittstelle einzuführen.
- **Kein WAF und keine Bot-Challenge.** Bewusst nicht Teil der Anwendung; ein
  WAF gehört, wenn überhaupt, in das Betriebskonzept des Betreibers.
- **Vorgeschaltete Proxys.** Steht vor Nginx noch ein Load Balancer oder CDN,
  ist die Client-IP nur so vertrauenswürdig wie dessen Header-Behandlung. Diese
  Konstellation braucht ein eigenes Trust-Konzept.
