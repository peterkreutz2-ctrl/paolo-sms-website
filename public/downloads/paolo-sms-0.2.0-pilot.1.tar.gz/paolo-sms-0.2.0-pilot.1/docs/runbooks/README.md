# Operator-Runbooks

Diese Runbooks beschreiben wiederkehrende oder kontrollierte Eingriffe auf
einer bestehenden Docker-Installation. Sie sind keine alternativen Quellen für
Architektur-, Migrations- oder Backup-Regeln.

- [`production-docker-update.md`](production-docker-update.md): schrittweises
  Docker-Produktionsupdate einschließlich vollständigem SQL-Replay,
  Verifikation und Rollback.
- [`../update-from-package.md`](../update-from-package.md): Update einer Installation im
  Paket-Layout ohne Git, mit Rücknahmegrenzen.
- [`switch-clerk-to-better-auth.md`](switch-clerk-to-better-auth.md):
  optionale Umstellung einer bestehenden Standardinstallation von Clerk auf
  Better Auth.
- [`aws-account-and-ec2-provisioning.md`](aws-account-and-ec2-provisioning.md):
  AWS-Konto, IAM-Operator und EC2-Infrastruktur bis zur SSH-fähigen
  Ubuntu-Host-Übergabe.
- [`public-report-rate-limit.md`](public-report-rate-limit.md): laufender
  Betrieb des Missbrauchsschutzes für öffentliche Meldungen und Downloads einschließlich
  Aufräumen der Rate-Limit-Tabelle und 429-Beobachtung.

Maßgebliche Hintergrund- und Policy-Dokumente:

- Einstieg und Gesamtüberblick für Betreiber:
  [`../operator-guide.md`](../operator-guide.md)
- Auth-/Installationsentscheidung:
  [`../installation-decision-guide.md`](../installation-decision-guide.md)
- Datenbankmigrationen:
  [`../database-migrations.md`](../database-migrations.md)
- Release-Vorbereitung:
  [`../release-checklist.md`](../release-checklist.md)
- Backup und Restore:
  [`../backup-restore.md`](../backup-restore.md)
- Generische Docker-Installation auf einer Ubuntu-VM:
  [`../docker-vm-deployment.md`](../docker-vm-deployment.md)
