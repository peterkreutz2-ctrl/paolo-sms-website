# Better-Auth-Anmeldeschutz

Dieser Schutz gilt ausschließlich für `AUTH_MODE=betterauth`. Er begrenzt
erfolgreiche und fehlgeschlagene Anmeldeversuche vor der Passwortprüfung und
gilt gleichermaßen für das PAOLO-Anmeldeformular sowie für
`POST /api/auth/sign-in/email`.

## Konfiguration

| Variable | Bedeutung | Standard |
|---|---|---|
| `BETTER_AUTH_LOGIN_RATE_LIMIT_SALT` | installationsspezifisches Geheimnis für HMAC-Identifier; in Produktion Pflicht | keiner |
| `BETTER_AUTH_LOGIN_RATE_LIMIT_TRUSTED_IP_HEADER` | ausschließlich vom vertrauenswürdigen Proxy gesetzter Client-IP-Header | keiner |
| `BETTER_AUTH_LOGIN_RATE_LIMIT_MAX_PER_ACCOUNT` | Versuche je E-Mail-Identifier und 15 Minuten | `5` |
| `BETTER_AUTH_LOGIN_RATE_LIMIT_MAX_PER_IP` | Versuche je IPv4- bzw. IPv6-/64-Identifier und 15 Minuten | `20` |
| `BETTER_AUTH_LOGIN_RATE_LIMIT_RETENTION_DAYS` | Aufbewahrung abgelaufener Buckets, 1 bis 365 Tage | `1` |

Bei Docker/Nginx ist `X-Forwarded-For` korrekt: das mitgelieferte Nginx-Snippet
überschreibt diesen Header mit `$remote_addr`. Damit verwendet der
Better-Auth-Anmeldeschutz denselben Client-IP-Header wie die öffentlichen
Rate-Limiter. Bei einer zusätzlichen CDN- oder Load-Balancer-Schicht muss der
Betreiber die vollständige Vertrauenskette einrichten; ein vom Internet direkt
erreichbarer App-Port oder ein nicht bereinigter Header macht den IP-Schutz
umgehbar.

Außerhalb von `NODE_ENV=production` nutzt PAOLO nur für Entwicklung und E2E
den Better-Auth-Secretwert sowie `X-Forwarded-For` als Test-Fallback. Dieser
Fallback ist in Produktion nicht aktiv und ersetzt keine Proxy-Konfiguration.

## Verhalten und Betrieb

Die Anwendung speichert nur HMAC-Identifier, Scope, Zeitfenster und Zähler —
nie Passwort, E-Mail-Adresse oder IP-Adresse. Abgelaufene Buckets werden bei
Anmeldeversuchen begrenzt bereinigt. Eine fehlende Konfiguration, fehlende
vertrauenswürdige IP oder ein Datenbankfehler führt absichtlich zu einer
neutralen Ablehnung vor der Passwortprüfung.

Bei einer Blockierung erhalten HTTP-Clients `429`, `Retry-After` und
`Cache-Control: no-store`; das Formular zeigt dieselbe neutrale Warteantwort.
Sie verrät nicht, ob ein Konto existiert. Der Docker-Nginx-Limiter schützt
zusätzlich nur den direkten HTTP-Pfad gegen kurze Spitzen; er ersetzt den
anwendungsweiten PostgreSQL-Zähler nicht.

Serverlogs enthalten nur die Art des Betriebsereignisses. Sie sind kein
fachliches Audit-Log und dürfen nicht mit personenbezogenen Requestdaten
angereichert werden.
