# AWS-Konto und EC2-Host für PAOLO bereitstellen

Dieses Runbook endet mit der Übergabe einer erreichbaren, abgesicherten
Ubuntu-VM. Die Installation von Docker und PAOLO ist bewusst getrennt und
steht in
[`../docker-vm-deployment.md`](../docker-vm-deployment.md).

Die Beispielarchitektur ist für kleine Friends-&-Family-/Vereinsinstallationen
gedacht:

- Region `eu-central-1` (Frankfurt)
- Ubuntu Server 24.04 LTS, x86-64
- `t3.medium` (2 vCPU, 4 GiB RAM)
- verschlüsseltes 30-GiB-gp3-Root-Volume
- Elastic IPv4-Adresse
- extern verwaltetes DNS
- kein öffentlicher PostgreSQL-Port
- zunächst keine EC2-Instance-Role

Jeder Betreiber besitzt und verantwortet sein eigenes AWS-Konto und seine
Installation. Keine Secrets, Account-IDs, Instance-IDs, IP-Adressen,
Hostnamen oder privaten Schlüssel in Repository oder Dokumentation übernehmen.

## Step 1 — Deployment-Operator festlegen

Purpose: AWS-Administration und PAOLO-Deployment mit minimalen, überprüfbaren
Berechtigungen trennen.

Für eine kleine Installation ist folgendes Modell vertretbar:

- ein Console-only-IAM-Benutzer `paolo-deployment-operator`
- Gruppe `PaoloDeploymentOperators`
- Customer-managed Policy `PaoloEc2DeploymentOperator`
- MFA für verändernde EC2-Aktionen
- kein Access Key
- keine AWS-Administratorrechte
- keine Route-53-Rechte, wenn DNS extern verwaltet wird
- kein `iam:PassRole`, solange die Instanz keine Instance-Role erhält

AWS IAM Identity Center und temporäre Credentials sind grundsätzlich
vorzuziehen. Ein MFA-geschützter Console-only-Benutzer bleibt für wenige
unabhängig verantwortete Installationen eine pragmatische Option.

## Step 2 — Begrenzte IAM-Policy anlegen

Purpose: nur die für Bereitstellung und Betrieb benötigten EC2-Aktionen in der
gewählten Region erlauben.

Beispielpolicy:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "ReadEC2Configuration",
      "Effect": "Allow",
      "Action": [
        "ec2:Describe*",
        "ec2:GetConsoleOutput",
        "ec2:GetPasswordData"
      ],
      "Resource": "*"
    },
    {
      "Sid": "CreateAndOperatePaoloEC2Resources",
      "Effect": "Allow",
      "Action": [
        "ec2:RunInstances",
        "ec2:StartInstances",
        "ec2:StopInstances",
        "ec2:RebootInstances",
        "ec2:TerminateInstances",
        "ec2:ModifyInstanceAttribute",
        "ec2:CreateTags",
        "ec2:CreateSecurityGroup",
        "ec2:DeleteSecurityGroup",
        "ec2:AuthorizeSecurityGroupIngress",
        "ec2:AuthorizeSecurityGroupEgress",
        "ec2:RevokeSecurityGroupIngress",
        "ec2:RevokeSecurityGroupEgress",
        "ec2:ModifySecurityGroupRules",
        "ec2:AllocateAddress",
        "ec2:AssociateAddress",
        "ec2:DisassociateAddress",
        "ec2:ReleaseAddress",
        "ec2:CreateKeyPair",
        "ec2:DeleteKeyPair",
        "ec2:AttachVolume",
        "ec2:DetachVolume",
        "ec2:ModifyVolume",
        "ec2:DeleteVolume"
      ],
      "Resource": "*",
      "Condition": {
        "StringEquals": {
          "aws:RequestedRegion": "eu-central-1"
        },
        "Bool": {
          "aws:MultiFactorAuthPresent": "true"
        }
      }
    }
  ]
}
```

Einige EC2-Erstellungsaktionen benötigen `Resource: "*"`, weil Ressourcen
noch nicht existieren oder ein Launch mehrere Ressourcentypen umfasst.
Region- und MFA-Bedingung sind deshalb wichtige Schutzmechanismen. Vorhandene
Permissions Boundaries oder AWS-Organizations-SCPs müssen zusätzlich geprüft
werden.

## Step 3 — Gruppe und Benutzer anlegen

Purpose: die Policy einem eindeutig verantworteten menschlichen Operator
zuweisen.

1. Gruppe `PaoloDeploymentOperators` anlegen.
2. Nur `PaoloEc2DeploymentOperator` anhängen.
3. Benutzer `paolo-deployment-operator` mit Console-Zugriff anlegen.
4. Keinen Access Key erzeugen.
5. Benutzer der Gruppe zuordnen.
6. Passkey, Security Key oder Authenticator-App als MFA einrichten.
7. Sign-in-URL und Initialpasswort im Passwortmanager speichern.
8. Vollständig abmelden und eine neue MFA-authentifizierte Sitzung starten.

Nach stabiler Einrichtung Berechtigungen erneut reduzieren. Insbesondere
Termination, Key-Pair-Erstellung, Security-Group-Änderung und Freigabe einer
Elastic IP nur dauerhaft erlauben, wenn der Operator sie benötigt.

## Step 4 — EC2-Instanz starten

Purpose: einen ausreichend dimensionierten, persistenten und verschlüsselten
Ubuntu-Host erzeugen.

Beispielwerte:

- Name: `paolo-sms-production`
- AMI: Ubuntu Server 24.04 LTS, 64-bit x86
- Instance Type: `t3.medium`
- Key Pair:
  - ED25519
  - PEM-Format
  - privaten Schlüssel einmalig geschützt speichern
- Root Storage:
  - 30 GiB
  - gp3
  - verschlüsselt
  - `Delete on termination` bewusst deaktivieren, wenn das Volume bei
    versehentlicher Terminierung erhalten bleiben soll
- keine zusätzlichen Dateisysteme
- keine Instance-Role, solange sie nicht für einen konkreten Dienst benötigt
  wird
- leere User Data
- Termination Protection aktivieren, sofern verfügbar

Die Größen sind ein bewährter Ausgangspunkt, keine universelle
Kapazitätsgarantie. Nutzung, Attachment-Volumen, Backups, Logs und
Wiederherstellungsziele müssen betreiberspezifisch bewertet werden.

## Step 5 — Security Group konfigurieren

Purpose: nur die benötigten öffentlichen Dienste erreichbar machen.

| Port | Quelle | Zweck |
|---|---|---|
| TCP 22 | aktuelle öffentliche Operator-IP | SSH |
| TCP 80 | `0.0.0.0/0` | ACME und HTTP-Redirect |
| TCP 443 | `0.0.0.0/0` | HTTPS |

Keinen Ingress für TCP 5432 anlegen. Normales Outbound erlauben, damit der
Host Pakete, Container-Images, Repository-Releases, Auth-Dienste und
Zertifikate erreichen kann. IPv6 nur bewusst aktivieren und dann Security
Group, DNS und Host gleichermaßen konfigurieren.

Vor Fortsetzung auf `Running` und `2/2 checks passed` warten.

## Step 6 — Elastic IP zuordnen

Purpose: eine stabile öffentliche Adresse unabhängig von Neustarts der Instanz
bereitstellen.

1. In `eu-central-1` eine Elastic IPv4-Adresse anlegen.
2. Mit `Name=paolo-sms-production` oder einem installationsspezifischen Namen
   taggen.
3. Der Instanz und ihrer privaten IP zuordnen.

Unzugeordnete Elastic IPs und öffentliche IPv4-Nutzung können Kosten
verursachen. Eine Adresse nur freigeben, wenn sie absichtlich nicht mehr
benötigt wird.

## Step 7 — DNS konfigurieren

Purpose: einen stabilen Hostnamen für TLS und die öffentliche Anwendung
bereitstellen.

Beim zuständigen DNS-Anbieter einen `A`-Record auf die Elastic IP setzen:

- genau ein `A`-Record für den Hostnamen
- keinen konkurrierenden CNAME
- keinen `AAAA`-Record, solange IPv6 nicht vollständig konfiguriert ist
- MX, SPF, DKIM und andere Mail-Einträge nicht verändern

DNS muss vor der Zertifikatsausstellung korrekt auflösen.

## Step 8 — SSH-Zugang vom Operatorgerät einrichten

Purpose: den privaten Schlüssel schützen und eine wiederholbare Verbindung
herstellen.

Beispiel für Windows CMD:

```cmd
if not exist "%USERPROFILE%\.ssh" mkdir "%USERPROFILE%\.ssh"
move "%USERPROFILE%\Downloads\paolo-sms-production.pem" "%USERPROFILE%\.ssh\paolo-sms-production.pem"
icacls "%USERPROFILE%\.ssh\paolo-sms-production.pem" /inheritance:r
icacls "%USERPROFILE%\.ssh\paolo-sms-production.pem" /grant:r "%USERNAME%:(R)"
```

Beispiel für `%USERPROFILE%\.ssh\config`:

```sshconfig
Host paolo-sms-production
    HostName <elastic-ip>
    User ubuntu
    IdentityFile ~/.ssh/paolo-sms-production.pem
    IdentitiesOnly yes
```

Verbindung und Host prüfen:

```bash
ssh paolo-sms-production
whoami
cat /etc/os-release
uname -m
df -h /
free -h
```

Erwartet werden `ubuntu`, Ubuntu 24.04, `x86_64`, die geplante
Datenträgergröße und ungefähr die zum Instance Type passende
Arbeitsspeichermenge.

## Step 9 — Host-Übergabe abnehmen

Purpose: die AWS-Verantwortung klar vom generischen VM-/Anwendungsdeployment
trennen.

Vor Übergabe bestätigen:

- [ ] korrektes AWS-Konto und Region
- [ ] IAM-Operator nutzt MFA und keinen Access Key
- [ ] Instanz läuft und besteht beide AWS-Statusprüfungen
- [ ] Root-EBS ist verschlüsselt
- [ ] Entscheidung zu `Delete on termination` ist dokumentiert
- [ ] Termination Protection entspricht der Betreiberentscheidung
- [ ] Security Group erlaubt nur die vorgesehenen Ingress-Regeln
- [ ] SSH ist auf die Operatorquelle beschränkt
- [ ] PostgreSQL-Port 5432 ist nicht öffentlich
- [ ] Elastic IP ist zugeordnet
- [ ] DNS zeigt auf die Elastic IP
- [ ] SSH funktioniert
- [ ] Ubuntu-Version, Architektur, Disk und RAM sind geprüft

Danach mit
[`../docker-vm-deployment.md`](../docker-vm-deployment.md)
fortfahren. Docker-Images, Compose, PAOLO-Konfiguration, PostgreSQL,
Migrationen, Nginx, TLS, Backups und Anwendungstests sind nicht AWS-spezifisch.

