# Docker-Produktionsupdate mit Datenbankmigration

This document describes a controlled in-place update of an existing PAOLO SMS
Docker deployment, including explicit PostgreSQL schema changes. It is generic:
the migration numbers, target branch, target commit, schema checks, and
application smoke tests must be selected for each release. A sanitized example
from the 2026-07-30 production-shaped update rehearsal follows the procedure;
it was not a change to a real production environment.

This runbook is the deployment operator's execution procedure. It does not
replace:

- the authoritative migration policy in
  [`../database-migrations.md`](../database-migrations.md);
- the release owner's preparation checklist in
  [`../release-checklist.md`](../release-checklist.md);
- backup and restore requirements in
  [`../backup-restore.md`](../backup-restore.md).

Authentication-provider cutover is a separate operation; see
[`switch-clerk-to-better-auth.md`](switch-clerk-to-better-auth.md).

In this runbook, a **production installation** means one concrete,
independently operated installation belonging to a club, flight school, or
their service provider. It does not mean a single central PAOLO SaaS
environment. The project team's **Reference Prod** is only a
production-shaped installation with play/test data; executing a rehearsal
there never authorizes changes to an operator's production installation.

Do not record secrets, credentials, tokens, private keys, public IP addresses,
hostnames, account IDs, or personal user data in this document or command
output.

## Safety principles

- Never use `drizzle-kit migrate`, `drizzle-kit push`, or
  `drizzle-kit generate` for a production update.
- Replay the complete reviewed SQL set on both fresh and initialized databases
  using `scripts/migrate.psql` from the same release as `drizzle/`.
- Determine live schema state through read-only PostgreSQL inspection.
- The complete set is idempotent and data-preserving from every consistent
  historical prefix; the psql entry point applies it atomically and stops on errors.
- Back up before schema changes.
- Build the target image while the old healthy container remains in service.
- Stop when an expected precondition or verification fails.
- Prefer additive schema changes and application rollback over destructive
  schema reversal.

## Step 1 — Record the current deployment

Purpose: establish the exact rollback commit, worktree state, service health,
and public availability before changing production.

Example commands:

```bash
cd /opt/paolo-sms

git status --short
git branch --show-current
git log -1 --oneline
git rev-parse HEAD

docker compose -f docker-compose.yml -f docker-compose.prod.yml ps
curl -fsS https://<public-domain>/api/health
```

Record the current commit outside the SSH session. Stop if application,
PostgreSQL, Nginx, or public health is not healthy.

Interpret Git changes before proceeding. A dirty worktree can be deployment
state rather than source modification. In the current Nginx layout, enabling
HTTPS renames two tracked templates:

```text
deploy/nginx/conf.d/paolo-http.conf
    -> deploy/nginx/conf.d/paolo-http.conf.disabled

deploy/nginx/conf.d/paolo-https.conf.disabled
    -> deploy/nginx/conf.d/paolo-https.conf
```

These expected renames must be preserved. Any unrelated change requires
investigation.

## Step 2 — Create and verify a pre-update backup

Purpose: provide a recovery artifact immediately before code and schema
changes.

Example commands:

```bash
sudo /usr/bin/curl --config /etc/paolo/backup-cron.curl
echo "Backup exit: $?"

docker compose -f docker-compose.yml -f docker-compose.prod.yml exec -T app \
  ls -lhtr /app/backups
```

Expected result: exit status `0` and a new `.dump.age` archive with a matching
`.manifest.json`, identifier, and timestamp.

The encrypted archive and manifest must be kept together. A backup on the same
EC2/EBS storage protects this update but not complete instance or volume loss.
Copy it off-instance when practical. Database and attachment backups must be
coordinated for a complete restore.

## Step 3 — Fetch and inspect the target release

Purpose: review the release and migration delta without changing the checked-out
code or running containers.

Example commands:

```bash
git fetch origin

git log --oneline --decorate HEAD..origin/<target-branch>
git diff --stat HEAD..origin/<target-branch>
git diff --name-status HEAD..origin/<target-branch>
git diff --name-status HEAD..origin/<target-branch> -- drizzle
```

Review every new migration:

```bash
git show origin/<target-branch>:drizzle/<migration-file>.sql
```

Confirm:

- the target branch and release are approved;
- the relationship is understood and does not contain unexpected divergence;
- migration numbers were not removed or reused; any replay corrections to
  historical SQL are explicitly reviewed and covered by the prefix matrix;
- every migration is idempotent and non-destructive, including data backfills;
- the migration order and application-specific verification are known.

## Step 4 — Inspect the live pre-migration schema

Purpose: confirm a consistent historical state and detect unexpected drift.
The full replay does not need a list of missing migrations or Drizzle metadata.

Example pattern:

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml exec -T db \
  psql -U paolo -d paolo -c "
SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'public'
  AND table_name IN ('<expected-old-table>', '<new-table>');

SELECT table_name, column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_schema = 'public'
  AND (
    (table_name = '<table-a>' AND column_name = '<new-column-a>')
    OR
    (table_name = '<table-b>' AND column_name = '<new-column-b>')
  );
"
```

Also record representative row counts for tables affected by the migration
when that provides a useful non-destructive integrity check.

Stop when the observed schema contradicts the expected deployment history.
Investigate drift before applying SQL.

## Step 5 — Move the checkout to the target release

Purpose: obtain the approved migration files and application source while
preserving active TLS configuration.

For the current tracked-template Nginx layout, temporarily restore the tracked
names:

```bash
mv deploy/nginx/conf.d/paolo-http.conf.disabled \
   deploy/nginx/conf.d/paolo-http.conf

mv deploy/nginx/conf.d/paolo-https.conf \
   deploy/nginx/conf.d/paolo-https.conf.disabled

git status --short
```

The status must now be clean. Switch or fast-forward to the target branch:

```bash
if git show-ref --verify --quiet refs/heads/<target-branch>; then
  git switch <target-branch>
  git merge --ff-only origin/<target-branch>
else
  git switch --track -c <target-branch> origin/<target-branch>
fi
```

Immediately reactivate HTTPS using the templates from the new checkout:

```bash
mv deploy/nginx/conf.d/paolo-http.conf \
   deploy/nginx/conf.d/paolo-http.conf.disabled

mv deploy/nginx/conf.d/paolo-https.conf.disabled \
   deploy/nginx/conf.d/paolo-https.conf
```

Verify:

```bash
git branch --show-current
git log -1 --oneline
git status --short
curl -fsS https://<public-domain>/api/health
```

The running Nginx process retains its loaded configuration during these file
renames. Do not restart it while the tracked HTTP-only names are temporarily
restored.

## Step 6 — Validate and build before migration

Purpose: prove that the target Compose configuration and application image
build before changing the production schema or running container.

Example commands:

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml \
  config --quiet

echo "Compose validation exit: $?"

docker compose -f docker-compose.yml -f docker-compose.prod.yml \
  build app

echo "Build exit: $?"
```

Both commands must return `0`. The old application container continues serving
traffic during the build.

## Step 7 — Apply the complete reviewed migration set

Pause application writes and background jobs for the maintenance window.
The full transaction can hold table locks until commit; the entry point stops
if a lock cannot be acquired within 10 seconds. Do not restart the old app
against intermediate schema states. Ensure the pre-update full database backup
includes any experimental AI tables (the limited `paolo_data` export does not).

Use the migration bundle in the app image built in Step 6. The PostgreSQL image
and its volumes do not change. Check that the app service's `DATABASE_URL`
identifies the approved target and uses a database/table owner with DDL rights.
If the app normally uses restricted credentials, provide approved migration
credentials for this one-off container without logging them. The target database
must already be running and ready; `--no-deps` deliberately does not start it.

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml stop app || exit 1
docker compose -f docker-compose.yml -f docker-compose.prod.yml \
  run --rm --no-deps -T app sh /app/scripts/migrate.sh || exit 1
```

This starts only the explicit migration command, not the web server, and removes
the one-off container afterwards. Do not substitute `exec app`: a build does not
update the running container, so `exec` would use its previous release's SQL.
Keep the app stopped until verification in Step 8 succeeds; Step 9 activates the
new application. No migration runs automatically at application startup.

The shell entry point suppresses routine psql output; warnings and errors remain
visible on stderr. No psql output is expected on success without warnings.
Exit `0` means the transaction committed. Any SQL/connection failure must stop
the rollout. If commit acknowledgement was lost, the state may already be
committed; after reconnecting, safely replay the complete set. Do not continue
from a guessed statement number. For local or remote psql without Docker see
[database-migrations.md](../database-migrations.md).

The replay correction release leaves unexpected AI tables untouched and creates
no archive schema. Existing public attachments lacking a release record receive
an explicit technical legacy marker. Review these documented effects before rollout.

## Step 8 — Verify the post-migration schema and data

Purpose: confirm that each intended database effect exists exactly as defined
before the new application is started.

Example pattern:

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml exec -T db \
  psql -U paolo -d paolo -c "
SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'public'
  AND table_name = '<new-table>';

SELECT table_name, column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_schema = 'public'
  AND (
    (table_name = '<table-a>' AND column_name = '<new-column-a>')
    OR
    (table_name = '<table-b>' AND column_name = '<new-column-b>')
  )
ORDER BY table_name, column_name;

SELECT indexname
FROM pg_indexes
WHERE schemaname = 'public'
  AND tablename = '<new-table>'
ORDER BY indexname;

SELECT count(*) AS affected_business_row_count
FROM <affected-business-table>;
"
```

Compare tables, columns, types, nullability, defaults, constraints, and indexes
with `lib/db/schema.ts` and the reviewed SQL. Representative row counts should
remain plausible.

## Step 9 — Recreate the application and refresh Nginx

Purpose: switch production to the already built target image after schema
verification.

Example commands:

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml \
  up -d --force-recreate app
```

Wait until the app reports healthy, then restart Nginx so it resolves the new
app container address:

When updating from the older duplicated HTTP/HTTPS configuration, preserve
operator-specific TLS settings but adopt the common policy:
`deploy/nginx/conf.d/00-rate-limits.conf` must be loaded once in the HTTP
context, and the active application server must include
`/etc/nginx/conf.d/snippets/app.conf`. Remove the old inline rate-zone and
application-location blocks when adopting that include; retaining both would
duplicate definitions. Keep the entire `conf.d` directory, including its
`snippets` subdirectory, in the Nginx mount. The current tracked templates
already contain this structure. Test the effective config before restart:

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml ps

docker compose -f docker-compose.yml -f docker-compose.prod.yml \
  exec -T nginx nginx -t

docker compose -f docker-compose.yml -f docker-compose.prod.yml \
  restart nginx

curl -fsS https://<public-domain>/api/health

docker compose -f docker-compose.yml -f docker-compose.prod.yml logs \
  --tail=100 app nginx
```

Stop and use the rollback plan if the app becomes unhealthy or logs show
unresolved schema/runtime errors.

## Step 10 — Perform release-specific smoke tests

Purpose: verify behavior that health checks cannot cover.

Always test:

- public home and reporting routes;
- authentication and logout;
- dashboard and role-protected administration;
- existing report details and measures;
- attachment upload/download where applicable.

Also test every feature introduced by the release. For a schema-backed feature,
confirm both read and write behavior through the UI.

Do not run destructive E2E reset tooling against production.

## Step 11 — Create a post-update backup

Purpose: capture the updated schema and data after acceptance.

Example commands:

```bash
sudo /usr/bin/curl --config /etc/paolo/backup-cron.curl
echo "Backup exit: $?"

docker compose -f docker-compose.yml -f docker-compose.prod.yml exec -T app \
  ls -lhtr /app/backups | tail -4
```

If the endpoint returns HTTP `429`, a prior successful backup is still inside
`BACKUP_CRON_MIN_INTERVAL_MINUTES`. Do not bypass the guard. Verify the
installed schedule and inspect the first naturally eligible backup:

```bash
sudo stat -c '%a %U %G %n' /etc/paolo/backup-cron.curl
sudo cat /etc/cron.d/paolo-backup
systemctl is-active cron
```

## Step 12 — Complete the final audit

Purpose: leave an evidence-backed record of the accepted production state.

Example commands:

```bash
echo "--- release ---"
git branch --show-current
git log -1 --oneline
git status --short

echo "--- services ---"
docker compose -f docker-compose.yml -f docker-compose.prod.yml ps

echo "--- public health ---"
curl -fsS https://<public-domain>/api/health

echo "--- disk ---"
df -h /
docker system df
```

Add release-specific runtime and database checks. Replace placeholders before
running commands: Bash interprets `<public-domain>` as input redirection if
copied literally.

Do not prune Docker images, volumes, or build cache during the migration unless
disk pressure makes cleanup necessary and the exact targets have been reviewed.

## Rollback model

- Retain the pre-update commit and old image until acceptance.
- If no schema reversal is required, switch back to the previous commit/image,
  recreate the app, and restart Nginx.
- Additive migrations can normally remain in place while an earlier compatible
  application version runs.
- Restore PostgreSQL and attachment storage together only when the migration or
  data changes genuinely require data rollback.
- Never improvise destructive down-migrations in production.

## Example: 2026-07-30 production-shaped update rehearsal

### Starting state

- Production used the merged `hardening/docker` feature branch at commit
  `c392555`.
- App, PostgreSQL, and Nginx were healthy; public HTTPS health returned OK.
- Git showed only the expected active-TLS template renames.
- The pre-update backup endpoint returned `0` and created a matching encrypted
  archive/manifest pair with restrictive permissions.
- The backup remained on the same EC2/EBS installation, so off-instance backup
  remained an open resilience gap.

### Release inspection

- `origin/main` targeted commit `8ccf667`.
- The release included retention-review, FIDA, documentation, and E2E work.
- Exactly two migration files were new relative to production:
  `0026_add_retention_review_fields.sql` and
  `0027_add_report_retention_reviews.sql`.
- No historical migration was shown as modified or deleted.

### Pre-migration schema

- All four Better Auth tables from `0024` existed.
- `reports.retention_review_eligible_at` did not exist.
- `organizations.report_retention_review_interval_months` did not exist.
- `report_retention_reviews` did not exist.

### Update and migration

- The TLS template names were temporarily restored, the checkout moved to
  `main` at `8ccf667`, and HTTPS template activation was restored.
- Public health continued to pass.
- Compose validation and application build both returned `0`.
- Migrations `0026` and `0027` were copied individually and applied with
  `ON_ERROR_STOP`; both returned `0`.

### Post-migration verification

- `report_retention_reviews` existed.
- `reports.retention_review_eligible_at` was a nullable timestamp without time
  zone.
- `organizations.report_retention_review_interval_months` was a nullable
  integer.
- The review table had its primary key plus organization and report indexes.
- Existing data remained present: one report and one organization were
  observed.

### Runtime acceptance

- The production app was recreated from the new image and Nginx restarted.
- App, PostgreSQL, and Nginx were healthy.
- Public health returned `{"status":"ok"}`.
- Root storage was about 30% used with roughly 20 GiB available.
- Docker reported about 4.5 GiB of reclaimable build cache; no cleanup was
  needed.

This was a rehearsal on a production-shaped test installation, not a real
production environment. Authentication was changed to Better Auth during the
same maintenance session.
That provider-specific procedure and its acceptance results are documented in
[`switch-clerk-to-better-auth.md`](switch-clerk-to-better-auth.md).

### Follow-up

- Verify the first naturally scheduled backup after the configured
  1,440-minute minimum interval. It will be the first archive containing
  migrations `0026`/`0027` and the Better Auth identity.
- Establish encrypted off-instance copies of database and coordinated
  attachment backups.
- Change the Nginx deployment layout so activating HTTPS no longer leaves a
  permanently dirty Git checkout.
