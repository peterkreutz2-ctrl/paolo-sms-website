# Glossar

Dieses Glossar ist die **einzige verbindliche Quelle** der PAOLO-SMS-Terminologie.
Die Onlinehilfe unter `/dashboard/hilfe/glossar` wird daraus abgeleitet
(`scripts/help/help-manifest.ts`, `npm run help:generate`). Eine zweite Fassung
gibt es nicht.

Die Einträge stehen **alphabetisch nach dem verbindlichen Stichwort**. Damit
zeigt die Onlinehilfe dieselbe Reihenfolge wie die Quelle, ohne dass beim
Erzeugen umsortiert werden müsste.

Verbindlich ist das Glossar für **benutzersichtbaren Text** — Oberfläche,
Meldungen, Dokumentvorlagen, Hilfe und Dokumentation. Technische Bezeichner,
Datenbankschlüssel, Dateinamen und Codewerte sind davon **nicht** betroffen; wo
ein Schlüssel vom Begriff abweicht, ist das beim Eintrag vermerkt.

Wer einen Begriff ändert, ändert ihn hier zuerst.

## Lesart

Jeder Eintrag ist verbindlich. Wo ein Begriff auf eine frühere, datierte
Entscheidung zurückgeht, ist das Datum vermerkt.

„Nicht:" nennt Wörter, die für denselben Sachverhalt nicht mehr verwendet
werden. „Abgrenzung:" nennt einen benachbarten Begriff, mit dem der Eintrag
häufig verwechselt wird. Ein Eintrag ohne eigene Definition verweist mit „→ siehe"
auf das verbindliche Stichwort.

Der Bestand entspricht diesem Glossar noch nicht überall. Die bekannten
Abweichungen sind im Entwicklungsprotokoll festgehalten; eine Abweichung
zwischen Glossar und Oberfläche ist ein Befund, kein Formfehler.

---

## Schreib- und Sprachregeln

Diese Regeln gelten für den gesamten benutzersichtbaren Text und stehen
bewusst vor der Begriffsliste.

1. **Umlaute und ß.** Benutzersichtbarer deutscher Text wird mit Umlauten und ß
   geschrieben: „Maßnahme", „Anhänge", „prüfen", „öffentlich", „löschen".
   Technische Bezeichner, Datenbankschlüssel, Dateinamen, Routen und Codewerte
   dürfen ASCII bleiben. Codekommentare sind kein benutzersichtbarer Text; die
   bestehende Schreibweise dort bleibt unangetastet. 
2. **Ausnahme Meldungscode.** Der Meldungscode enthält bewusst keine Umlaute und
   kein ss/ß, weil er vorgelesen und abgeschrieben wird. 
3. **Deutsch vor Englisch.** Für einen Sachverhalt mit gebräuchlichem deutschem
   Wort wird das deutsche Wort verwendet. Englische Begriffe bleiben nur, wo sie
   der etablierte Fachbegriff sind — Safety Manager, Safety Assistant,
   Accountable Executive, ALARP — oder wo kein deutsches Gegenstück existiert.
   
4. **Rollennamen** werden nicht übersetzt und nicht abgewandelt. 
5. **Ein Begriff, eine Bedeutung.** Wo ein Wort zwei Sachverhalte bezeichnen
   könnte, wird es qualifiziert oder nicht verwendet. 

---

## A

**Abnahmevorlage**
Die redigierte Zusammenstellung der Prüfnachweise für eine menschliche
Releaseentscheidung. Sie ist selbst keine Freigabe.

**Accountable Executive (verantwortliche Leitung)**
Die Person mit der übergeordneten Verantwortung (Accountability,
Führungsverantwortung) für die organisatorischen Voraussetzungen und die
Funktionsfähigkeit des Sicherheitsmanagementsystems. Das ist nicht die
Verantwortung für die Sicherheit jedes einzelnen Fluges. Im Verein kann ein
entsprechend benanntes Vorstandsmitglied die Funktion wahrnehmen, in der
Flugschule etwa der Geschäftsführer oder Ausbildungsleiter, jeweils im Rahmen
der bestehenden Befugnisse.
Abgrenzung: Die operativen Aufgaben (Responsibility) liegen beim Safety
Manager. Keine PAOLO-Rolle: Die Person wird in der Anwendung nur dokumentarisch
benannt; die Benennung erzeugt keine Programmberechtigung und ersetzt keine
organisatorische Bestellung.

**Administrator**
Die PAOLO-Rolle für den technischen Betrieb einer Installation: Konfiguration,
Wartung, Zugänge. Technisch `admin`.
Nicht: Admin, SysAdmin. In Routen und Bezeichnern bleibt `admin`.

**Aktivitätsart**
Der Rahmen, in dem geflogen wurde: Schnupperkurs, Grundausbildung,
Höhenflugausbildung, B-Schein-Ausbildung, Andere Ausbildung, Sicherheitstraining,
Betreutes Fliegen, Eigenflug, Tandemflug, Streckenflug, Wettkampf, Sonstiges.

**Aktivitätsbereich**
Das Fluggerät beziehungsweise die Sportart: Gleitschirm, Hängegleiter,
Motorschirm, Speedriding, Parakite, Sonstiges.

**Akzeptabel**
Stufe der Risikotoleranz (grün). Keine Maßnahme erforderlich.

**ALARP**
*As low as reasonably practicable* — der Grundsatz, ein tolerierbares Risiko so
weit zu senken, wie es mit vertretbarem Aufwand möglich ist. Englische
Abkürzung, weil es keine gebräuchliche deutsche gibt.

**Änderungsmanagement**
Die Bewertung geplanter Änderungen — Gelände, Ausrüstung, Verfahren — auf
Sicherheitsrisiken, bevor sie umgesetzt werden.

**Angemeldete Person**
Ein authentifizierter Nutzer, unabhängig von seiner Rolle.
Der Plural **Angemeldete Personen** bezeichnet dieselbe Gruppe an zwei Stellen:
als Beschriftung der Übersicht aller authentifizierten Nutzer und als
Sichtbarkeitsstufe eines SMS-Dokuments. Das ist derselbe Begriff in zwei
Verwendungen, kein zweiter Begriff.
Nicht: eingeloggter Benutzer, angemeldeter Benutzer.

**Anmeldelink**
Ein Link, den ein Administrator oder Safety Manager für ein Konto erzeugt, damit die
Person (wieder) Zugang bekommt. Bei Clerk meldet er direkt an; bei Better Auth
führt er zur Seite „Passwort festlegen“. Er gilt sieben Tage, wird nur einmal
angezeigt und nirgends gespeichert. Ältere Links desselben Kontos bleiben bis zu
ihrem Ablauf gültig.
Abgrenzung: das vom Administrator beim Anlegen vergebene Anfangspasswort.

**Anmeldeversuch**
Ein Versuch, sich mit E-Mail-Adresse und Passwort anzumelden. Der Begriff
umfasst erfolgreiche und fehlgeschlagene Versuche.

**Anhang**
Eine Datei an einer Meldung oder an einem SMS-Dokument.
Nicht: Dateianhang, Attachment.

**Anzeigename der Organisation**
Der optionale Name, der neben „PAOLO SMS“ im Kopf der Anwendung steht – zum
Beispiel „Flugschule Hot Sport“. Er ist öffentlich sichtbar und kann unter
Organisationseinstellungen gepflegt oder geleert werden; ohne Anzeigename steht
dort nur „PAOLO SMS“. Technisch `organizations.display_name`.
Abgrenzung: der Name der Organisation aus der Einrichtung der Installation
(`organizations.name`), der nirgends angezeigt wird; außerdem der Betreiber in
den Rechtsangaben.

**Anonyme Meldung**
Eine Meldung ohne Melderangaben. Über das öffentliche Meldeformular der
Normalfall, nicht die Ausnahme.
Abgrenzung: Vertraulichkeit.

**Audit-Eintrag**
Eine einzelne Zeile des Audit-Logs.
Nicht: Audit-Ereignis, Audit-Event.

**Audit-Log**
Das Protokoll sicherheitsrelevanter Aktionen im System. Dient der
Nachvollziehbarkeit.

---

## B

**Bedrohung** *(nicht geführt)*
Wird als PAOLO-Begriff nicht verwendet. Der Begriff stammt aus der
Informationssicherheit; ICAO Annex 19 kennt ihn in dieser Bedeutung nicht, und
im Luftsport hat er keine Entsprechung. Wo etwas Schadenspotenzial hat, heißt es
**Gefahr**.

**Beinahe-Ereignis**
Meldetyp, vollständig „Beinahe-Ereignis oder kritische Situation". Bewusst weit
gefasst: jede Situation, die als kritisch erlebt wurde. Technisch `near_miss`.
Abgrenzung: Ein Beinahe-Ereignis in PAOLO ist nicht automatisch ein
meldepflichtiger **Beinahe-Unfall**.

**Beinahe-Unfall**
Die luftrechtliche Meldepflichtschwelle nach DHV: außergewöhnliches
Flugverhalten des Fluggeräts, das zu einem Unfall geführt hat oder hätte führen
können. Meldepflichtig. Kein PAOLO-Meldetyp — der Begriff beschreibt eine
Eigenschaft des Ereignisses gegenüber dem DHV. Schreibweise mit Bindestrich, wie
beim DHV.
Nicht: Beinaheunfall, Near Miss.

**Benutzer**
Die PAOLO-Rolle für ein an Sicherheitsthemen interessiertes Mitglied der
Organisation. Technisch `member`.
Abgrenzung: **Nutzer** ist der Oberbegriff für jede Person, die PAOLO nutzt;
**Benutzer** ist diese eine Rolle.

**Beobachtung oder Hinweis**
Meldetyp für etwas Wahrgenommenes, das für die Sicherheit relevant sein könnte.
Technisch `observation`.

**Beschreibung**
Der ausführliche Text einer Meldung. Pflichtfeld.

**Betreiber**
Wer eine PAOLO-Installation technisch und rechtlich betreibt — die Organisation
selbst oder ein beauftragter Dienstleister.
Abgrenzung: nicht gleichbedeutend mit **Organisation**.

---

## C

**Checkliste**
Dokumentkategorie für Prüflisten, etwa zum Änderungsmanagement.

---

## D

**Demo-Installation**
Öffentlich zugängliche Installation mit ausschließlich erfundenen Spieldaten und
veröffentlichten Zugangsdaten zum Ausprobieren. Sie wird täglich zurückgesetzt;
Eingaben gehen dabei verloren. Veröffentlichen, Dateien hochladen und die
Verwaltung von Konten und Rollen sind in ihr gesperrt.
Abgrenzung: **Spieldaten** sind die erfundenen Inhalte, die **Demo-Installation**
ist die Installation, die sie zeigt.

**DHV**
Deutscher Hängegleiterverband. Vom Bundesverkehrsministerium beauftragte
Unfallmeldestelle für Gleitschirm und Hängegleiter.

**Dokument** → siehe **SMS-Dokument**.

**Dokumentkategorie**
Die Art eines SMS-Dokuments: Sicherheitsrichtlinie, SMS-Handbuch, Notfallplan,
Protokoll der Sicherheitsbesprechung, Sicherheitshinweis, Checkliste,
Bedienungsanleitung.

---

## E

**Eintrittswahrscheinlichkeit**
Wie wahrscheinlich es ist, dass die betrachtete Konsequenz eintritt (Stufen 5
bis 1): Häufig, Gelegentlich, Selten, Unwahrscheinlich, Äußerst unwahrscheinlich.
Nicht: Wahrscheinlichkeit (allein), Häufigkeit.

**Endgültig löschen**
Das unwiderrufliche Entfernen einer Meldung aus dem Papierkorb.
Nicht: Hard Delete.

**Ereignis**
Ein reales sicherheitsrelevantes Geschehen. Eine Meldung kann ein Ereignis
beschreiben, muss es aber nicht — eine Idee oder ein Hinweis beschreibt keines.
Abgrenzung: **Meldung** ist der Datensatz, das Ereignis das Geschehen.

**Ereigniszeitpunkt**
Wann das gemeldete Ereignis stattfand. Freiwillige Angabe. Technisch
`occurredAt`.
Abgrenzung: Der Eingang der Meldung ist etwas anderes und heißt nie so.
Nicht: Vorfallsdatum, Ereignisdatum, Unfalldatum.

**Etwas anderes**
Meldetyp als Auffangkategorie, damit niemand am Formular scheitert. Technisch
`other`.

---

## F

**Fälligkeitsdatum**
Termin, bis zu dem eine Maßnahme erledigt sein soll.

**FIDA**
*Flight Sport Incident Database*, die gemeinsame Meldedatenbank der
Luftsport-Fachverbände. Der gesetzliche Meldeweg für meldepflichtige Ereignisse
im Gleitschirm- und Hängegleiterbereich. Von PAOLO getrennt — eine PAOLO-Meldung
erreicht FIDA nicht automatisch.

**Fluglehrer**
Als Name einer PAOLO-Rolle abgelöst durch **Safety Assistant**. Als
**Melderrolle** im Meldeformular bleibt „Fluglehrer/in" richtig und unverändert.

**Flugphase**
Vorflugcheck, Groundhandling, Start, Flug, Landung, Nachflug, Nicht zutreffend.

**Freigabe**
Die ausdrückliche Entscheidung, einen Anhang öffentlich abrufbar zu machen. Sie
wirkt erst, wenn auch das zugehörige Dokument öffentlich ist.

**Freigabeprüfung**
Die Checkliste, die vor einer Freigabe zu bestätigen ist.

**Freigabevermerk**
Die schriftliche Begründung einer Freigabe. Wird am Anhang gespeichert.

**Funktionsfähiger Administrator**
Ein Administrator, dessen Konto beim Anmeldedienst existiert. Es muss stets
mindestens einer verbleiben: Der letzte funktionsfähige Administrator kann weder
herabgestuft noch seiner Rolle beraubt werden. Ein verwaister Administrator zählt
nicht.
Abgrenzung: **Verwaiste Rolle**.

---

## G

**Gefahr**
Ein Zustand, ein Objekt oder ein Verfahren mit dem Potenzial, zu einem Schaden
beizutragen — ein schlummerndes Schadenspotenzial (ICAO: *hazard*). Die Gefahr
ist noch nicht der Schaden. Beispiele: Rückenwind am Startplatz, enger
Landeplatz, eine bestimmte Gurtzeug-Rettungsgerät-Kombination.
Abgrenzung: In PAOLO gibt es kein eigenständiges Objekt „Gefahr"; sie erscheint
als Meldetyp **Gefahrenquelle oder Mangel**.
Nicht: Gefährdung, Bedrohung.

**Gefahrenquelle oder Mangel**
Meldetyp für einen Zustand, ein Objekt oder ein Verfahren mit
Schadenspotenzial. Technisch `hazard`.

---

## I

**Idee zur Verbesserung der Sicherheit**
Meldetyp für einen Verbesserungsvorschlag. Technisch `suggestion`.

**Inakzeptabel**
Stufe der Risikotoleranz (rot). Sofortige Maßnahme erforderlich.
Nicht: unakzeptabel.

**Installation**
Eine eigenständig betriebene Instanz von PAOLO SMS. PAOLO ist keine zentral
betriebene Plattform; jede Organisation betreibt ihre eigene Installation.

**Intern**
Sichtbarkeitsstufe eines SMS-Dokuments: sichtbar für Administrator, Safety
Manager und Safety Assistant. Der Begriff bezeichnet in PAOLO **ausschließlich**
diese Stufe.
Abgrenzung: Nicht im allgemeinen Sinn von „nicht öffentlich" verwenden — die
Stufen **Vertraulich** und **Angemeldete Personen** sind ebenfalls nicht
öffentlich, aber nicht „intern". Wo „nicht öffentlich" gemeint ist, wird das
ausgeschrieben.

**Interne Notiz**
Notiztyp an einer Meldung, der nur den bearbeitenden Rollen zugänglich ist.

---

## K

**Konsequenz**
Das Ergebnis, das eine Gefahr auslösen kann. Beispiele: Strömungsabriss,
Baumlandung, Fehlauslösung. In der Risikobewertung wird immer die Konsequenz
bewertet, nicht die Gefahr selbst.

**Konto**
Der Eintrag einer angemeldeten Person beim Anmeldedienst (Clerk oder Better
Auth). Ein Konto ist nicht die Rolle: Erst die Rollenzuweisung in PAOLO gibt
Zugang. In der Zugangs- und Rollenverwaltung hat jedes Konto einen Status:
*Aktiv*, *Ohne Rolle*, *Konto fehlt* oder *Konto nicht prüfbar* (Anmeldedienst
nicht erreichbar).
Abgrenzung: **Angemeldete Person** — die Person selbst, unabhängig von Konto
und Rolle.

**Kontodaten**
Name und E-Mail-Adresse eines Kontos. Administrator und Safety Manager ändern den
Namen (Clerk und Better Auth) und bei Better Auth die E-Mail-Adresse; bei Clerk
bleibt die E-Mail-Adresse dem Benutzerprofil der Person beim Anmeldedienst
vorbehalten. Das eigene Konto ist ausgenommen. Rollen und Kennung bleiben dabei
erhalten.

**Kontolöschung**
Das endgültige Entfernen eines Kontos beim Anmeldedienst samt Sitzungen und
Rollenzuweisungen, ohne vorherige Sperrung. Nicht möglich für das eigene Konto und
für Konten mit Administratorrolle; die Rolle wird vorher regulär geändert.
Meldungen, Notizen, Besprechungen, SMS-Dokumente und Audit-Einträge bleiben
unverändert; die Kennung darin wird weder ersetzt noch anonymisiert. Die Bestätigung
verlangt die vollständige E-Mail-Adresse.
Abgrenzung: die Bearbeitung einer Löschanfrage nach DSGVO läuft über die
Datenschutzprozesse, nicht über die Kontolöschung.

**Kurzbeschreibung**
Die einzeilige Zusammenfassung einer Meldung, höchstens 120 Zeichen.
Pflichtfeld.
Nicht: Titel, Betreff.

---

## M

**Maßnahme**
Eine beschlossene Handlung, die aus einer Meldung folgt. Verbindliche
Schreibweise mit ß, auch in Zusammensetzungen: Maßnahmenliste, Maßnahmenstatus,
Maßnahmenvorschlag.
Nicht: Massnahme.

**Maßnahmenstatus**
Offen, In Bearbeitung, Erledigt, Verworfen.

**Meldeformular**
Das öffentliche Formular, über das ohne Anmeldung gemeldet werden kann.

**Meldekultur**
Der Teil der Sicherheitskultur, der das Melden betrifft: wie
selbstverständlich, wie niederschwellig, wie folgenreich gemeldet wird.
Nicht: Fehlerkultur.

**Meldepflichtiger Unfall**
Ein Ereignis, das nach Luftverkehrs-Ordnung gegenüber dem DHV meldepflichtig
ist. Der DHV nennt als Schwellen:

- schwere Verletzung von Pilot und/oder Passagier — stationäre
  Krankenhausbehandlung von mehr als 48 Stunden, Frakturen (außer Finger, Nase,
  Zehen), schwere Blutungen, Nervenverletzungen, Muskel- und Bänderverletzungen,
  innere Verletzungen, Verbrennungen 2. und 3. Grades;
- Tod von Pilot und/oder Passagier;
- schwere Beschädigung oder Zerstörung des Fluggeräts;
- Beinahe-Unfall.

In PAOLO ein Ja/Nein-Feld an der Meldung. **Eine PAOLO-Meldung erfüllt die
Meldepflicht nicht** — die Meldung an DHV/FIDA ist zusätzlich abzugeben.

**Melder**
Die Person, die eine Meldung abgibt. Verbindlicher Fachbegriff, auch als
Bestimmungswort in Zusammensetzungen: Melderangaben, Melderdaten, Melderrolle,
Melderidentität, Melderfelder.
Nicht: Meldender, meldende Person.

**Melderangaben**
Name, Melderrolle und Kontakt einer Meldung. Sämtlich freiwillig.

**Melderrolle**
Die Funktion, in der ein Melder das Ereignis erlebt oder beobachtet hat:
Fluglehrer/in, Startleiter/in, Windenführer/in, Beteiligte/r Pilot/in,
Reiseleiter/in, Helfer/in, Zeuge/Zeugin.
Abgrenzung: Das ist keine PAOLO-Rolle.

**Meldetyp**
Die vom Melder gewählte Art der Meldung, eine von sechs: Unfall,
Beinahe-Ereignis, Gefahrenquelle oder Mangel, Beobachtung oder Hinweis, Idee zur
Verbesserung der Sicherheit, Etwas anderes. Der Meldetyp beschreibt, was
gemeldet wird — nicht, wie es ausging, und nicht, ob eine Meldepflicht besteht.
Nicht: Meldungstyp, Ereignistyp, Kategorie.

**Meldeverfahren**
Die Regelung der Organisation dazu, wer was meldet und wie damit umgegangen
wird. Steht im SMS-Handbuch.
Abgrenzung: **Meldeweg**.

**Meldeweg**
Der konkrete Weg, auf dem eine Meldung eingeht — Meldeformular, Ansprache des
Safety Managers, QR-Code am Startplatz.
Nicht: Meldewesen, Meldesystem.

**Meldung**
Der Datensatz in PAOLO, mit dem ein Ereignis, eine Beobachtung oder eine Idee
erfasst wird.
Nicht: Report, Bericht, Vorfall.

**Meldungscode**
Der neutrale Rückmeldecode einer öffentlich eingereichten Meldung, Form
„Wort-Zahl" (zum Beispiel „Falke-12"). Bewusst inhaltsfrei; lässt keinen
Rückschluss auf Art oder Schwere zu.
Nicht: Meldungsnummer, Vorgangsnummer, Ticketnummer.

**Meldungsstatus**
Neu, In Prüfung, In Bearbeitung, Maßnahmen beschlossen, Abgeschlossen,
Ausgeblendet.

---

## N

**Nachtrag**
Notiztyp für eine spätere Ergänzung zu einer Meldung.

**Notfallplan**
Dokumentkategorie für abgestimmte Abläufe im Ereignisfall — Alarmierung,
Erstversorgung, Zuständige.

**Nutzer**
Jede Person, die PAOLO nutzt — mit oder ohne Anmeldung, einschließlich des
anonymen Melders.
Abgrenzung: **Angemeldete Person**, **Benutzer**.

---

## O

**Öffentliche Statusrückmeldung**
Die Anzeige von Meldungscode und Bearbeitungsstatus auf der öffentlichen Seite
„Sicherheitsinformationen". Zeigt weder Inhalte noch Namen, Kategorien oder
Daten.

**Organisation**
Der Verein oder die Flugschule, für die eine PAOLO-Installation betrieben wird.
Eine Installation führt eine Organisation.

**Ort**
Freitextangabe zum Ort des Ereignisses. Kein Geländekatalog, keine Koordinaten.

---

## P

**Papierkorb**
Der Zustand einer gelöschten, aber wiederherstellbaren Meldung.
Nicht: Soft Delete, Archiv.

**Passwort festlegen**
Der Vorgang und die Seite `/set-password` (nur Better Auth), mit denen eine Person
über einen Anmeldelink ihr Passwort selbst setzt. Der Link ist einmal verwendbar;
nach dem Festlegen sind alle bisherigen Sitzungen der Person beendet.

**Priorität**
Die Dringlichkeit der Bearbeitung einer Meldung: Niedrig, Mittel, Hoch,
Kritisch. Wird unabhängig von der Risikobewertung gesetzt und ist keine Kurzform
davon.
Abgrenzung: **Risiko** beschreibt das Ereignis, **Priorität** die Arbeit daran.

**Protokoll der Sicherheitsbesprechung**
Das Ergebnisdokument einer Sicherheitsbesprechung; zugleich eine
Dokumentkategorie.

---

## R

**Redlichkeitskultur**
Eine Kultur, in der niemand einen Nachteil erleidet, weil er ein Ereignis
gemeldet hat — auch dann nicht, wenn es Folge eines eigenen Fehlers war. Nicht
geschützt sind Vorsatz, grobe Fahrlässigkeit und das bewusste Missachten
offensichtlicher Risiken. Der englische Begriff *Just Culture* darf einmalig
erläuternd in Klammern stehen.

**Report** *(nicht geführt)*
Kein deutsches Wort für „Meldung". Auch nicht in Zusammensetzungen:
Meldungs-Detailseite, nicht Report-Detailseite. Der Datenbankname `reports`
bleibt.

**Restrisiko**
Das nach Umsetzung aller Maßnahmen verbleibende Risiko. In PAOLO derzeit nicht
erfasst; der Begriff steht hier, damit er nicht abweichend eingeführt wird.

**Risiko**
Die Kombination aus der Eintrittswahrscheinlichkeit einer Konsequenz und deren
Schweregrad.

**Risikobewertung**
Die Einschätzung von Eintrittswahrscheinlichkeit und Schweregrad zu einer
Meldung.
Nicht: Risikoeinschätzung, Risikoanalyse.

**Risikocode**
Die Kurzform aus Eintrittswahrscheinlichkeit und Schweregrad, zum Beispiel „3C".

**Risikomatrix**
Die 5×5-Darstellung aus Eintrittswahrscheinlichkeit und Schweregrad.

**Risikotoleranz**
Die Einordnung eines Risikocodes in eine von drei Stufen: **Inakzeptabel**,
**Tolerierbar**, **Akzeptabel**.
Nicht: Risikoakzeptanz, Risiko-Appetit, Tolerierbarkeit von Sicherheitsrisiken.

**Rückmeldung des Melders**
Notiztyp für eine Rückäußerung des Melders zu seiner Meldung.

---

## S

**Sachschadenschwere**
Die Sachschadensdimension des Schadensausmaßes: Kein Sachschaden, Geringer
Sachschaden, Großer Sachschaden, Fluggerät zerstört.

**Safety Assistant** *(entschieden 2026-09-04)*
Die PAOLO-Rolle für eine vertrauenswürdige und kompetente Ansprechperson
innerhalb der Organisation, die mit sensiblen Informationen verantwortungsvoll
umgeht — in einer Flugschule etwa ein erfahrener Fluglehrer, in einem Verein ein
geeigneter Funktionsträger. Ein gemeinsamer Begriff für Verein und Flugschule.
Technisch `instructor`.
Nicht: Fluglehrer (als Rollenname).

**Safety Manager** *(entschieden 2026-07-15)*
Die PAOLO-Rolle für die operative Umsetzung, Koordination und Aufrechterhaltung
des Sicherheitsmanagementsystems innerhalb der Organisation, oder für eine
Vertretung mit denselben Aufgaben. Zugleich der ICAO-Fachbegriff. Technisch
`safety_manager`.
Nicht: Sicherheitsbeauftragter, Sicherheitsmanager, Sicherheitsreferent, Club
Safety Officer.

**Schaden**
Jeder materielle oder immaterielle Nachteil, den eine Person oder Sache
erleidet.

**Schadensausmaß**
Der tatsächlich eingetretene Schaden eines Ereignisses. Oberbegriff über
Verletzungsschwere und Sachschadenschwere. Wird rückblickend festgestellt, nicht
geschätzt.
Abgrenzung: **Schweregrad** ist die potenzielle Schwere in der Risikobewertung.

**Schweregrad**
Wie schwer die betrachtete Konsequenz ausfallen könnte (Stufen A bis E):
Katastrophal, Gefährlich, Wesentlich, Geringfügig, Vernachlässigbar. Der Begriff
wird ausschließlich in der Risikobewertung verwendet.
Abgrenzung: **Schadensausmaß** ist das, was tatsächlich eingetreten ist.

**Sicherheitsausschuss**
Das Gremium, das Meldungen prüft und Maßnahmen beschließt. In kleinen
Organisationen fällt es mit der Sicherheitsbesprechung zusammen.

**Sicherheitsbesprechung**
Die regelmäßige Besprechung, in der Meldungen ausgewertet, Maßnahmen verfolgt
und Sicherheitsziele überprüft werden.
Nicht: Sicherheitssitzung, Safety Meeting, Sitzung.

**Sicherheitshinweis**
Eine vom Safety Manager erstellte, aktuelle sicherheitsrelevante Information,
die für bestimmte Gruppen oder öffentlich freigegeben wird. Dokumentkategorie.
Der Begriff gilt **intern wie öffentlich**; eine abweichende öffentliche
Beschriftung gibt es nicht mehr.
Abgrenzung: **Sicherheitsmitteilung** ist etwas anderes — eine offizielle
Warnung oder Handlungsanweisung zu Ausrüstungsmängeln, die von außen kommt.
Nicht: Sicherheitsinformation (Singular), Informationen vom Safety Manager.

**Sicherheitsindikator**
Eine Messgröße, an der die Erreichung eines Sicherheitsziels beobachtet wird
(ICAO: *safety performance indicator*, SPI).

**Sicherheitsinformation** (Singular) → siehe **Sicherheitshinweis**.

**Sicherheitsinformationen**
Der Name der öffentlichen Seite und zugleich der Sammelbegriff für die dort
veröffentlichten sicherheitsrelevanten Inhalte — Sicherheitshinweise,
freigegebene Dokumente und die öffentliche Statusrückmeldung. Immer im Plural.
Abgrenzung: Ein einzelner Inhalt dieser Seite ist ein **Sicherheitshinweis**
oder ein **SMS-Dokument**, keine „Sicherheitsinformation".

**Sicherheitskultur**
Der übergeordnete Umgang einer Organisation mit Sicherheit. Umfasst die
Redlichkeitskultur, geht aber darüber hinaus.

**Sicherheitsleistung**
Das erreichte Sicherheitsniveau, gemessen an Sicherheitsindikatoren und
Sicherheitszielwerten.

**Sicherheitsmanagementsystem (SMS)**
Der systematische Ansatz einer Organisation zum Umgang mit Sicherheit:
Strukturen, Verantwortlichkeiten, Richtlinien und Verfahren. Die Abkürzung
„SMS" meint in PAOLO immer dies und nie Kurznachrichten.

**Sicherheitsmeldung**
Die ausgeschriebene Form von **Meldung**. Wird an öffentlichen Einstiegspunkten
verwendet, wo der Zusammenhang nicht aus der Umgebung hervorgeht
(„Sicherheitsmeldung einreichen"). Intern und in Listen genügt „Meldung".

**Sicherheitsmitteilung**
Im Luftsport etablierter Begriff für eine offizielle Warnung oder
Handlungsanweisung zu einem sicherheitsrelevanten Ausrüstungsmangel,
herausgegeben von Herstellern, dem DHV oder einer Behörde. Kommt von außen und
richtet sich an alle Betroffenen.
Abgrenzung: **kein** Synonym für **Sicherheitshinweis** und **kein** Synonym
für **SMS-Dokument**. Eine eingehende Sicherheitsmitteilung kann Anlass für
einen Sicherheitshinweis oder eine Maßnahme sein.

**Sicherheitsrichtlinie**
Das vom Accountable Executive unterzeichnete Grundsatzdokument der Organisation
zur Sicherheit (ICAO: *safety policy*). Dokumentkategorie.
Nicht: Sicherheitspolitik.

**Sicherheitsuntersuchung**
Die eigene, vertiefte Untersuchung eines Ereignisses durch die Organisation,
unterhalb der staatlichen Unfalluntersuchung.

**Sicherheitsziel**
Ein von der Organisation gesetztes, überprüfbares Ziel zur Sicherheit.

**Sicherheitszielwert**
Der für einen Sicherheitsindikator angestrebte Wert (ICAO: *safety performance
target*, SPT).

**Sichtbarkeit**
Die Reichweite eines SMS-Dokuments, in vier Stufen von eng nach weit:

| Stufe | Wer sieht das Dokument |
|---|---|
| **Vertraulich** | Administrator und Safety Manager |
| **Intern** | Administrator, Safety Manager und Safety Assistant |
| **Angemeldete Personen** | alle authentifizierten Nutzer mit Rolle |
| **Öffentlich** | ohne Anmeldung abrufbar |

Jede Stufe schließt die engeren mit ein. Drei der vier Stufen sind nicht
öffentlich; „intern" ist deshalb der Name **einer** von ihnen und keine
Sammelbezeichnung — siehe **Intern**.
Nicht: Mitglieder (als Name der dritten Stufe).

**Sitzung**
Bezeichnet in PAOLO die Anmeldesitzung. Nie als Kurzform für
Sicherheitsbesprechung verwenden.

**SMS-Dokument**
Der fachliche Name für ein in PAOLO gepflegtes Dokument des
Sicherheitsmanagementsystems. Trägt eine Dokumentkategorie, eine Sichtbarkeit
und optional Anhänge. Wo der Zusammenhang eindeutig ist, kurz **Dokument**.
Nicht: Sicherheitsmitteilung, Mitteilung.

**SMS-Handbuch**
Dokumentkategorie für das Dokument, das beschreibt, wie die Organisation ihr
Sicherheitsmanagementsystem führt.

**Spieldaten**
Erfundene Beispieldaten zum Ausprobieren einer Installation; zugleich die
Herkunftsangabe einer so erzeugten Meldung.
Abgrenzung: **Testdaten** sind die Daten der automatisierten Tests und kommen in
benutzersichtbarem Text nicht vor.

**Startart**
Hangstart, Windenstart, Andere, Nicht zutreffend.

**Störung** *(nicht geführt)*
Der luftrechtliche Begriff aus Luftverkehrs-Ordnung und DHV-Meldepflicht
(„Unfälle und schwere Störungen"). Wird **nicht** als PAOLO-Meldetyp und nicht
als PAOLO-Kategorie geführt. In Texten, die die gesetzliche Meldepflicht
erläutern, darf er als Zitat der Rechtslage stehen — dann immer mit dem Zusatz,
dass es um die Meldung an DHV/FIDA geht, nicht um PAOLO.

---

## T

**Tolerierbar**
Stufe der Risikotoleranz (gelb). Reguläre Maßnahme erforderlich; das Risiko ist
nach dem ALARP-Grundsatz zu senken und zu beobachten.

**Turnus**
Der Abstand zwischen zwei Sicherheitsbesprechungen in Monaten.
Nicht: Intervall.

---

## U

**Überfällig**
Eine offene Maßnahme, deren Fälligkeitsdatum verstrichen ist.

**Unfall**
Meldetyp für ein Ereignis, bei dem ein Personen- oder Sachschaden tatsächlich
eingetreten ist. Technisch `accident`.
Abgrenzung: Ob die Meldung zugleich der gesetzlichen Meldepflicht unterliegt,
entscheidet der **meldepflichtige Unfall**.

---

## V

**Verantwortlich**
Freitextangabe, wer eine Maßnahme umsetzt. Keine Zuweisung an ein Konto.

**Verein und Flugschule**
Die beiden Organisationstypen. Werden nur dort verwendet, wo die Unterscheidung
inhaltlich trägt — etwa bei Dokumentvorlagen; sonst gilt **Organisation**.

**Verletzungsschwere**
Die Personenschadensdimension des Schadensausmaßes: Keine Verletzung, Leichte
Verletzung, Schwere Verletzung, Tödlich.

**Vertraulichkeit**
Die Zusage, Melderangaben nur zweckgebunden und nur im engen Kreis zu nutzen.
Abgrenzung: nicht dasselbe wie Anonymität — vertraulich heißt, dass jemand den
Melder kennt und Rückfragen möglich bleiben.

**Verwaiste Rolle**
Ein Rolleneintrag, dessen Konto beim Anmeldedienst nicht mehr existiert. Die
Liste zeigt ihn mit dem Status „Konto fehlt“; „Rolle bereinigen“ entfernt ihn.
Bestehende Meldungen, Notizen und Audit-Einträge bleiben unverändert.
Abgrenzung: **Funktionsfähiger Administrator**.

**Verwerfen**
Eine Maßnahme aus der Nachverfolgung nehmen, mit Begründung. Eine verworfene
Maßnahme wird nicht gelöscht.

**Vorfall** *(nicht geführt)*
Wird nicht als PAOLO-Meldekategorie und nicht als SMS-Fachbegriff definiert. Das
Wort ist in PAOLO durch den Datenschutzvorfall belegt. Regel für
benutzersichtbaren Text: nie unqualifiziert — entweder „Datenschutzvorfall" oder
ein Begriff aus diesem Glossar.

---

## Z

**Zeugenaussage**
Notiztyp für die Schilderung einer dritten Person.

**Zugangs- und Rollenverwaltung**
Die Verwaltung von Zugängen und Rollenzuweisungen einer Installation.
Nicht: Benutzerverwaltung — das Wort meint unter der Festlegung zu **Benutzer**
nur noch die Rolle `member` und wäre missverständlich.

---

## Nicht in diesem Glossar

**Datenschutzterminologie.** Datenschutzvorfall, Betroffenenanfrage,
Aufbewahrungsprüfung, Anonymisierung, Pseudonymisierung, Auskunft, Löschung,
Verantwortlicher und die übrige DSGVO-Terminologie gehören in die
Datenschutzdokumentation: [`privacy-operations.md`](privacy-operations.md) und
[`data-protection-concept.md`](data-protection-concept.md). Die dort geltende
Terminologie — insbesondere die Grade der Anonymisierung — bleibt unverändert
und wird von hier nicht berührt.

**Technische Altlasten.** Das Feld `severity` in der Meldungstabelle ist eine
technische Altlast ohne Beschriftung in der Detailansicht. Es bekommt keinen
Glossarbegriff; sein weiteres Schicksal ist eine technische, keine
terminologische Frage.

---

## Pflege

- Dieses Dokument ist die einzige Quelle. Änderungen beginnen hier.
- Die Einträge stehen alphabetisch nach dem verbindlichen Stichwort; neue
  Einträge werden einsortiert, nicht angehängt.
- Nach jeder Änderung `npm run help:generate` ausführen und das Ergebnis
  mitcommitten, sonst schlägt `tests/help/help-content.test.ts` fehl.
- Ein Begriff, der in der Oberfläche eingeführt wird, gehört vorher hierher.
- Eine Abweichung zwischen Glossar und Oberfläche ist ein Befund, kein
  Formfehler.
