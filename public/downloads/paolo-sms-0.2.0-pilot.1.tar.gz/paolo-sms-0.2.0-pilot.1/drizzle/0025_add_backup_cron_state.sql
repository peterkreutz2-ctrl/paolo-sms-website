CREATE TABLE IF NOT EXISTS "backup_cron_state" (
  "key" text PRIMARY KEY NOT NULL,
  "status" text NOT NULL,
  "last_started_at" timestamp with time zone NOT NULL,
  "lease_expires_at" timestamp with time zone NOT NULL,
  "last_completed_at" timestamp with time zone,
  "last_backup_id" uuid,
  "updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
