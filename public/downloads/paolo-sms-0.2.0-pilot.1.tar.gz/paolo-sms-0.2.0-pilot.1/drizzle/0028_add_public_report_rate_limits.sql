CREATE TABLE IF NOT EXISTS public_report_rate_limits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  scope text NOT NULL,
  identifier text NOT NULL,
  window_start timestamptz NOT NULL,
  window_duration_seconds integer NOT NULL,
  accepted_count integer NOT NULL DEFAULT 0,
  blocked_count integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE schemaname = 'public' AND indexname = 'public_report_rate_limits_unique'
  ) THEN
    CREATE UNIQUE INDEX public_report_rate_limits_unique
      ON public_report_rate_limits (organization_id, scope, identifier, window_start);
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE schemaname = 'public' AND indexname = 'public_report_rate_limits_window_start_idx'
  ) THEN
    CREATE INDEX public_report_rate_limits_window_start_idx
      ON public_report_rate_limits (window_start);
  END IF;
END $$;

ALTER TABLE reports ADD COLUMN IF NOT EXISTS public_submission_id uuid;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE schemaname = 'public' AND indexname = 'reports_public_submission_unique'
  ) THEN
    CREATE UNIQUE INDEX reports_public_submission_unique
      ON reports (public_submission_id);
  END IF;
END $$;
