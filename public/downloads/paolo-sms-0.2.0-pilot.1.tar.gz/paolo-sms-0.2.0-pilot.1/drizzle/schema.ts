import { sql } from "drizzle-orm"
import { pgTable, uniqueIndex, uuid, text, timestamp, foreignKey, varchar, integer, boolean } from "drizzle-orm/pg-core"


export const roles = pgTable("roles", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	key: text().notNull(),
	label: text().notNull(),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	uniqueIndex("roles_key_unique").using("btree", table.key.asc().nullsLast().op("text_ops")),
]);

export const organizations = pgTable("organizations", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	name: text().notNull(),
	type: text().default('flight_school').notNull(),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow().notNull(),
});

export const userRoles = pgTable("user_roles", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	clerkUserId: text("clerk_user_id").notNull(),
	roleId: uuid("role_id").notNull(),
	organizationId: uuid("organization_id"),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	uniqueIndex("user_roles_global_unique").using("btree", table.clerkUserId.asc().nullsLast().op("text_ops"), table.roleId.asc().nullsLast().op("text_ops")).where(sql`${table.organizationId} IS NULL`),
	uniqueIndex("user_roles_org_unique").using("btree", table.clerkUserId.asc().nullsLast().op("text_ops"), table.roleId.asc().nullsLast().op("text_ops"), table.organizationId.asc().nullsLast().op("uuid_ops")).where(sql`${table.organizationId} IS NOT NULL`),
	foreignKey({
			columns: [table.roleId],
			foreignColumns: [roles.id],
			name: "user_roles_role_id_roles_id_fk"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.organizationId],
			foreignColumns: [organizations.id],
			name: "user_roles_organization_id_organizations_id_fk"
		}).onDelete("cascade"),
]);

export const measures = pgTable("measures", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	reportId: uuid("report_id").notNull(),
	title: varchar({ length: 200 }).notNull(),
	description: text(),
	status: text().default('open').notNull(),
	dueDate: timestamp("due_date", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.reportId],
			foreignColumns: [reports.id],
			name: "measures_report_id_reports_id_fk"
		}).onDelete("cascade"),
]);

export const attachments = pgTable("attachments", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	reportId: uuid("report_id").notNull(),
	originalFileName: text("original_file_name").notNull(),
	mimeType: text("mime_type").notNull(),
	fileSize: integer("file_size").notNull(),
	storageProvider: text("storage_provider").notNull(),
	storageKey: text("storage_key").notNull(),
	publicUrl: text("public_url").notNull(),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.reportId],
			foreignColumns: [reports.id],
			name: "attachments_report_id_reports_id_fk"
		}).onDelete("cascade"),
]);

export const reports = pgTable("reports", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	organizationId: uuid("organization_id").notNull(),
	reportType: text("report_type").notNull(),
	status: text().default('new').notNull(),
	priority: text().default('medium').notNull(),
	shortDescription: varchar("short_description", { length: 120 }).notNull(),
	detailedDescription: text("detailed_description").notNull(),
	isAnonymous: boolean("is_anonymous").default(true).notNull(),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow().notNull(),
	deletedAt: timestamp("deleted_at", { mode: 'string' }),
	deletedBy: text("deleted_by"),
	deleteReason: text("delete_reason"),
}, (table) => [
	foreignKey({
			columns: [table.organizationId],
			foreignColumns: [organizations.id],
			name: "reports_organization_id_organizations_id_fk"
		}),
]);
