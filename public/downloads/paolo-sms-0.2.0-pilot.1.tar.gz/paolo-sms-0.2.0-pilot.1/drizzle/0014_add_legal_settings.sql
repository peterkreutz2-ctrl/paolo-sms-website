CREATE TABLE IF NOT EXISTS "organization_legal_settings" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"organization_id" uuid NOT NULL,
	"operator_name" text,
	"operator_legal_form" text,
	"operator_address" text,
	"operator_email" text,
	"operator_phone" text,
	"represented_by" text,
	"register_info" text,
	"vat_id" text,
	"supervisory_authority" text,
	"privacy_responsible_name" text,
	"privacy_contact_email" text,
	"data_protection_officer" text,
	"hosting_provider_info" text,
	"data_retention_info" text,
	"legal_extra_text" text,
	"privacy_extra_text" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
DO $$ BEGIN
	ALTER TABLE "organization_legal_settings" ADD CONSTRAINT "organization_legal_settings_org_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;
--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "organization_legal_settings_org_unique" ON "organization_legal_settings" USING btree ("organization_id");
