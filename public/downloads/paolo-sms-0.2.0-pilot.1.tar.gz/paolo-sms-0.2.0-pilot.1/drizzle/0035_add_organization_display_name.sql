-- Anzeigename der Organisation im Kopf der Anwendung (#117).
--
--   display_name   Optionaler, betreiberpflegbarer Name, der neben "PAOLO SMS"
--                  im oeffentlichen Kopf und im Dashboard erscheint. NULL heisst
--                  "kein Name": Es erscheint nur "PAOLO SMS". organizations.name
--                  bleibt unveraendert der Name aus dem Bootstrap und wird von
--                  dieser Spalte weder ersetzt noch nachgefuehrt.
--
-- Einmalige Uebernahme, KEIN dauerhafter Abgleich: Der Migrationssatz wird
-- immer vollstaendig erneut angewandt (docs/database-migrations.md). Ein
-- "UPDATE ... WHERE display_name IS NULL" wuerde dabei einen vom Betreiber
-- bewusst geleerten Namen bei jedem Lauf wieder auffuellen. Deshalb wird nur in
-- dem Lauf kopiert, der die Spalte tatsaechlich anlegt; jeder spaetere Lauf
-- findet die Spalte vor und aendert nichts.
--
-- Folge fuer Bestandsinstallationen: Der bisher nirgends angezeigte
-- Organisationsname wird dadurch erstmals oeffentlich sichtbar. Vor der
-- Anwendung auf einer produktiven Datenbank sind die Namen zu pruefen; ein
-- Betreiber kann den Anzeigenamen danach unter /dashboard/settings leeren.
-- Leere oder nur aus Leerraum bestehende Namen werden zu NULL, damit nie ein
-- unsichtbarer Anzeigename entsteht.
--
-- Additiv und ohne Datenverlust; auf frischen Datenbanken gibt es keine Zeile
-- zu kopieren.

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'organizations'
      AND column_name = 'display_name'
  ) THEN
    ALTER TABLE "organizations" ADD COLUMN "display_name" text;
    UPDATE "organizations" SET "display_name" = NULLIF(btrim("name"), '');
  END IF;
END $$;
