-- Schliesst die 8 Spalten-Drift-Luecken aus dem Abgleich A2.6
-- (siehe docs/database-migrations.md, Abschnitt "Drift-Abgleich schema.ts <-> Migrationen").
-- Diese Spalten sind in lib/db/schema.ts und der bestehenden Neon-DB vorhanden,
-- fehlten aber in drizzle/*.sql (mutmasslich per frueherem drizzle-kit push).
-- Idempotent und additiv (ADD COLUMN IF NOT EXISTS): sicher fuer frische/leere
-- Docker-PostgreSQL und ein No-op auf bestehenden DBs. Keine Daten werden veraendert,
-- keine Spalten geloescht.
ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "safety_meeting_interval_months" integer DEFAULT 12 NOT NULL;--> statement-breakpoint
ALTER TABLE "measures" ADD COLUMN IF NOT EXISTS "assigned_to_text" text;--> statement-breakpoint
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "reporter_name" text;--> statement-breakpoint
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "reporter_role" text;--> statement-breakpoint
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "reporter_contact" text;--> statement-breakpoint
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "injury_severity" text;--> statement-breakpoint
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "damage_severity" text;--> statement-breakpoint
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "is_reportable_accident" boolean;
