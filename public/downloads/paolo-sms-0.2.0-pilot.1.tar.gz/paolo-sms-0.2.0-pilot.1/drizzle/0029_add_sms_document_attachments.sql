-- Anhaenge an SMS-Dokumenten (Sicherheitsmitteilungen), Arbeitspaket AP1.
--
-- Bewusst KEINE zweite Attachment-Tabelle: die bestehende `attachments` wird
-- generalisiert, damit Upload-, Storage-, Validierungs- und Loeschlogik
-- unveraendert weiterverwendet werden koennen. Eine Zeile gehoert entweder zu
-- einer Meldung oder zu einem SMS-Dokument, nie zu beidem und nie zu keinem —
-- das erzwingt die CHECK-Bedingung auf Datenbankebene.
--
-- Additiv und idempotent: bestehende Zeilen behalten ihr `report_id` und
-- erfuellen die CHECK-Bedingung unveraendert, weil `sms_document_id` fuer sie
-- NULL ist. Es werden keine Daten geschrieben oder umgeschrieben.
--
-- Sichtbarkeits-/Freigabefelder gehoeren NICHT hierher: die oeffentliche
-- Freigabe ist Gegenstand spaeterer Arbeitspakete.

ALTER TABLE attachments ADD COLUMN IF NOT EXISTS sms_document_id uuid;

-- Fremdschluessel bewusst OHNE ON DELETE CASCADE. Ein Cascade wuerde beim
-- Loeschen eines Dokuments die Attachment-Zeilen still entfernen und die
-- Dateien im Blob-Speicher verwaisen lassen — genau das, was
-- docs/data-protection-concept.md ausschliesst. Stattdessen loescht
-- deleteSmsDocument() erst die Dateien und dann die Zeilen; ein vergessener
-- Pfad scheitert dadurch laut am Fremdschluessel, statt leise Muell zu
-- hinterlassen.
-- conrelid einschraenken: pg_constraint.conname ist nicht global eindeutig,
-- sondern nur je Tabelle. Ohne diese Bedingung koennte ein gleichnamiges
-- Constraint an einer anderen Tabelle dazu fuehren, dass dieser Schritt
-- faelschlich als "schon vorhanden" uebersprungen wird.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'attachments_sms_document_id_sms_documents_id_fk'
      AND conrelid = 'public.attachments'::regclass
  ) THEN
    ALTER TABLE attachments
      ADD CONSTRAINT attachments_sms_document_id_sms_documents_id_fk
      FOREIGN KEY (sms_document_id) REFERENCES public.sms_documents(id)
      ON DELETE no action ON UPDATE no action;
  END IF;
END $$;

-- Genau eine Zuordnung pro Zeile.
--
-- Bewusst VOR dem Loesen von NOT NULL: so ist report_id zu keinem Zeitpunkt
-- ungeschuetzt — bis hierher greift NOT NULL, danach die CHECK-Bedingung.
-- Beide koennen koexistieren; bestehende Zeilen (report_id gesetzt,
-- sms_document_id NULL) erfuellen die Bedingung auch mit NOT NULL. Bei
-- Ausfuehrung in einer Transaktion aendert die Reihenfolge nichts, sie macht
-- die Datei aber unabhaengig von der Ausfuehrungsweise korrekt.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'attachments_exactly_one_owner'
      AND conrelid = 'public.attachments'::regclass
  ) THEN
    ALTER TABLE attachments
      ADD CONSTRAINT attachments_exactly_one_owner
      CHECK (num_nonnulls(report_id, sms_document_id) = 1);
  END IF;
END $$;

-- report_id ist nur noch fuer Meldungs-Anhaenge gesetzt. Ungeschuetzt, aber von
-- Natur aus idempotent: auf einer bereits nullable Spalte ein folgenloser
-- No-op, kein Fehler.
ALTER TABLE attachments ALTER COLUMN report_id DROP NOT NULL;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes
    WHERE schemaname = 'public' AND indexname = 'attachments_sms_document_idx'
  ) THEN
    CREATE INDEX attachments_sms_document_idx
      ON attachments (sms_document_id, created_at);
  END IF;
END $$;
