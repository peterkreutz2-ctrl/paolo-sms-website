-- Schliesst die Drift-Luecke: "safety_meetings" ist in lib/db/schema.ts definiert
-- und wird von lib/actions/safety-meetings.ts genutzt, hatte aber keine Migration.
-- Idempotent und additiv formuliert; sicher fuer frische/leere Docker-PostgreSQL.
-- Bestehende DBs (z. B. Neon) haben die Tabelle bereits (per frueherem drizzle-kit
-- push) - dank IF NOT EXISTS und duplicate_object-Guard aendert diese Migration
-- dort nichts.
CREATE TABLE IF NOT EXISTS "safety_meetings" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"organization_id" uuid NOT NULL,
	"meeting_date" date NOT NULL,
	"title" varchar(200),
	"notes" text,
	"created_by_clerk_user_id" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
DO $$ BEGIN
	ALTER TABLE "safety_meetings" ADD CONSTRAINT "safety_meetings_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;
