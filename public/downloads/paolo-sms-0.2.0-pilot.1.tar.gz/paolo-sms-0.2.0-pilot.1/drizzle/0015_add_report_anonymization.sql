-- Manuelle Anonymisierung strukturierter Melderdaten (erster kontrollierter Schritt).
-- Nur additive, idempotente Spalten. Keine bestehenden Daten werden veraendert oder geloescht.
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "anonymized_at" timestamp;--> statement-breakpoint
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "anonymized_by" text;--> statement-breakpoint
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "anonymization_note" text;--> statement-breakpoint
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "anonymization_status" text DEFAULT 'none' NOT NULL;
