-- DSGVO-Retention-Review-Pruefprotokoll (Arbeitspaket 4 des Retention-Plans):
-- dokumentiert Entscheidungen ("geprueft/keine Aktion", "zurueckgestellt",
-- "anonymisiert", "geloescht") im Rahmen der periodischen Aufbewahrungs-
-- pruefung. Loescht/aendert keine Reportdaten selbst.
-- report_id bewusst OHNE Fremdschluessel-Constraint (wie audit_logs.resource_id),
-- damit ein Hard Delete des Reports die Pruefhistorie nicht mitreisst.
-- Additiv und idempotent: CREATE TABLE/INDEX IF NOT EXISTS, sicher fuer
-- frische/leere DBs und ein No-op auf bestehenden DBs.
CREATE TABLE IF NOT EXISTS "report_retention_reviews" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"report_id" uuid NOT NULL,
	"organization_id" uuid NOT NULL,
	"report_type" text NOT NULL,
	"decision" text NOT NULL,
	"reason" text,
	"postponed_until" date,
	"computed_due_at" timestamp NOT NULL,
	"reviewed_by_clerk_user_id" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
DO $$ BEGIN
	ALTER TABLE "report_retention_reviews" ADD CONSTRAINT "report_retention_reviews_org_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "report_retention_reviews_report_idx" ON "report_retention_reviews" USING btree ("report_id","created_at");
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "report_retention_reviews_org_idx" ON "report_retention_reviews" USING btree ("organization_id","created_at");
