-- Freigabenachweis fuer oeffentlich gestellte Anhaenge (AP3).
--
-- Ergaenzt das Flag aus 0030 um die drei Angaben, die eine Freigabe dauerhaft
-- nachvollziehbar machen: wann, durch wen, mit welcher Begruendung. Die
-- bestaetigte Checkliste selbst wird bewusst NICHT als Spalten gefuehrt —
-- einzelne Boolean-Spalten koennten in einer gespeicherten Zeile nur `true`
-- enthalten und traegen damit keine Information. Ihr Zustand samt Version
-- landet stattdessen im Audit-Ereignis, wo der Zeitstempel ihm Bedeutung gibt.
--
-- Die drei Felder bleiben beim Widerruf bewusst ERHALTEN: `is_public` faellt
-- auf false, der Nachweis der letzten Freigabe bleibt lesbar. Nachvollziehbar-
-- keit geht vor Ueberschreiben historischer Information. Die Felder bedeuten
-- daher "letzte Freigabe", nicht "aktuell oeffentlich" — dafuer allein steht
-- `is_public`.

ALTER TABLE attachments
  ADD COLUMN IF NOT EXISTS public_released_at timestamp;

ALTER TABLE attachments
  ADD COLUMN IF NOT EXISTS public_released_by_clerk_user_id text;

ALTER TABLE attachments
  ADD COLUMN IF NOT EXISTS public_release_note text;

-- Nichts ist oeffentlich ohne dokumentierte Freigabe. Die Bedingung macht aus
-- der Anforderung "Freigabevermerk ist Pflicht" eine Zusicherung der
-- Datenbank: auch ein kuenftiger Codepfad, der `is_public` direkt setzt, kann
-- den Nachweis nicht ueberspringen.
--
-- 0030 erlaubt bereits oeffentliche Dokument-Anhaenge ohne Freigabenachweis.
-- Deren Sichtbarkeit bleibt erhalten. Fehlende Angaben werden ausdruecklich
-- als TECHNISCHE BESTANDSUEBERNAHME markiert, nicht als menschliche Freigabe:
-- Zeitpunkt = Migration, Akteur = reservierter Migrationsmarker, urspruengliche
-- Freigabe unbekannt. Bestehende Angaben werden nicht ueberschrieben. Die
-- WHERE-Klausel macht den Backfill bei Wiederholung zum No-op. Private oder
-- widerrufene Anhaenge werden nicht veraendert.
UPDATE attachments
SET public_released_at = COALESCE(public_released_at, transaction_timestamp()),
    public_released_by_clerk_user_id = COALESCE(
      public_released_by_clerk_user_id, 'migration:0031:legacy-public'),
    public_release_note = COALESCE(public_release_note,
      'Technische Bestandsuebernahme aus Migration 0030; keine nachtraegliche menschliche Freigabe. Urspruenglicher Freigabezeitpunkt und Akteur unbekannt; Zeitstempel bezeichnet die Migration.')
WHERE is_public AND (
  public_released_at IS NULL
  OR public_released_by_clerk_user_id IS NULL
  OR public_release_note IS NULL
);

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'attachments_public_requires_release_record'
      AND conrelid = 'public.attachments'::regclass
  ) THEN
    ALTER TABLE attachments
      ADD CONSTRAINT attachments_public_requires_release_record
      CHECK (
        NOT is_public
        OR (
          public_released_at IS NOT NULL
          AND public_released_by_clerk_user_id IS NOT NULL
          AND public_release_note IS NOT NULL
        )
      );
  END IF;
END $$;
