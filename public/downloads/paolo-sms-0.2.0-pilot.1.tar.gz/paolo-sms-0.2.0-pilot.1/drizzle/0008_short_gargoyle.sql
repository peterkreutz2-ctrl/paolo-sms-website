ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "activity_area" text;--> statement-breakpoint
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "activity_type" text;--> statement-breakpoint
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "flight_phase" text;--> statement-breakpoint
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "launch_type" text;--> statement-breakpoint
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "severity" text;