DROP INDEX IF EXISTS "user_roles_clerk_user_role_unique";--> statement-breakpoint
ALTER TABLE "user_roles" ADD COLUMN IF NOT EXISTS "organization_id" uuid;--> statement-breakpoint
DO $$ BEGIN
  ALTER TABLE "user_roles" ADD CONSTRAINT "user_roles_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "user_roles_global_unique" ON "user_roles" USING btree ("clerk_user_id","role_id") WHERE "user_roles"."organization_id" IS NULL;--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "user_roles_org_unique" ON "user_roles" USING btree ("clerk_user_id","role_id","organization_id") WHERE "user_roles"."organization_id" IS NOT NULL;