-- Stellt das Sichtbarkeitsmodell der SMS-Dokumente auf drei Stufen um:
--   confidential | staff | public
-- Bisherige Werte werden umbenannt:
--   internal  -> confidential
--   published -> staff
-- 'public' ist kein Bestandswert, sondern ein neuer, in Zod/TypeScript
-- zugelassener Anwendungswert (wird erst durch die App gesetzt).
--
-- visibility ist ein freies Textfeld (kein PG-Enum, kein CHECK-Constraint),
-- daher genuegt ein reines Daten-UPDATE plus die Anpassung des Spalten-Defaults.
-- Additiv und nicht-destruktiv: keine Tabellen/Spalten geaendert oder geloescht,
-- keine Dokumentinhalte veraendert.
--
-- Idempotenz: Die beiden UPDATEs sind ueber ihre WHERE-Klausel wiederholbar.
-- Beim zweiten Lauf existieren die Altwerte nicht mehr -> 0 betroffene Zeilen,
-- No-op. Die WHERE-Klauseln ueberschneiden sich nicht; ALTER ... SET DEFAULT ist
-- ohnehin idempotent.
--
-- Anwendung im vollstaendigen Replay gemaess docs/database-migrations.md;
-- kein drizzle-kit generate/migrate/push und keine Journal-/Snapshot-Pflege.
UPDATE "sms_documents" SET "visibility" = 'confidential' WHERE "visibility" = 'internal';
--> statement-breakpoint
UPDATE "sms_documents" SET "visibility" = 'staff' WHERE "visibility" = 'published';
--> statement-breakpoint
ALTER TABLE "sms_documents" ALTER COLUMN "visibility" SET DEFAULT 'confidential';
