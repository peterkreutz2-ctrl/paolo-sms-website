ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "occurred_at" timestamp;--> statement-breakpoint
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "location_text" text;--> statement-breakpoint
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "reporter_lessons_learned" text;--> statement-breakpoint
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "reporter_suggested_measures" text;--> statement-breakpoint
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "source_channel" text DEFAULT 'public_form' NOT NULL;