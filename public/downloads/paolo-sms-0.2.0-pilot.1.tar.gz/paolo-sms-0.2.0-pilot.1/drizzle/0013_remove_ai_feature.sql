-- Compatibility placeholder for the retired AI experiment.
-- 0010-0012 no longer create AI tables, so there is nothing to remove on
-- supported installations. Do not create an archive schema or delete any
-- unexpected experimental tables here; their inspection/cleanup is separate.
SELECT 1;
