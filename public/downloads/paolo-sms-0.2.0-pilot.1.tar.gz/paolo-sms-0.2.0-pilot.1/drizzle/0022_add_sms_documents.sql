-- Legt die SMS-Dokumentenablage an: Tabelle "sms_documents" fuer die
-- strukturierte SMS-Dokumentation (Sicherheitsrichtlinie / Safety Policy,
-- SMS-Handbuch, Notfallplaene, Protokolle der Sicherheitsbesprechungen) als
-- reiner Text/Markdown.
--
-- category: safety_policy | sms_manual | emergency_plan | safety_meeting_minutes
--   (auf DB-Ebene Freitext, validiert ueber lib/constants/sms-documents.ts + Zod).
-- visibility: internal | published (default internal). Steuert nur die
--   Sichtbarkeit fuer die Rolle instructor; internal = nur admin/safety_manager,
--   published = auch instructor. Erzeugt KEINE neue Rolle/Berechtigungslogik.
--
-- Bewusst NICHT enthalten: Uploads, Versionierung, Review-Felder
-- (reviewDueAt/reviewIntervalMonths), Lesebestaetigung. Spaetere Ausbaustufen.
--
-- Idempotent und additiv (CREATE TABLE/INDEX IF NOT EXISTS): sicher fuer
-- frische/leere PostgreSQL und ein No-op auf bestehenden DBs. Keine Daten werden
-- veraendert, keine Spalten geloescht.
CREATE TABLE IF NOT EXISTS "sms_documents" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
  "organization_id" uuid NOT NULL REFERENCES "organizations"("id") ON DELETE CASCADE,
  "category" text NOT NULL,
  "title" varchar(200) NOT NULL,
  "content" text NOT NULL,
  "visibility" text NOT NULL DEFAULT 'internal',
  "created_by_clerk_user_id" text NOT NULL,
  "updated_by_clerk_user_id" text,
  "created_at" timestamp DEFAULT now() NOT NULL,
  "updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "sms_documents_org_category_created_idx"
  ON "sms_documents" ("organization_id", "category", "created_at");
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "sms_documents_org_visibility_idx"
  ON "sms_documents" ("organization_id", "visibility");
