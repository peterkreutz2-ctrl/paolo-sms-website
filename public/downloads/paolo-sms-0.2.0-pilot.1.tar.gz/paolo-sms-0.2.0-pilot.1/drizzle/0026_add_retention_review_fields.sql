-- Fuegt die Datenmodell-Grundlage fuer das DSGVO-Retention-Review-Feature
-- hinzu (Arbeitspaket 3, Fassung 5 des Retention-Plans):
--   - reports.retention_review_eligible_at: Fristanker, ab wann eine Meldung
--     fuer eine Aufbewahrungs-/Anonymisierungspruefung in Frage kommt (gesetzt
--     beim ersten Wechsel nach "closed"/"hidden", geloescht beim Verlassen
--     dieser Gruppe, unveraendert bei Wechseln innerhalb der Gruppe).
--   - organizations.report_retention_review_interval_months: optionales,
--     organisationsbezogenes Pruefintervall. NULL = Funktion nicht
--     konfiguriert/deaktiviert -- PAOLO gibt keine Frist vor, siehe
--     docs/data-protection-concept.md.
-- Idempotent und additiv (ADD COLUMN IF NOT EXISTS): sicher fuer
-- frische/leere DBs und ein No-op auf bestehenden DBs. Keine Daten werden
-- veraendert, keine Spalten geloescht.
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "retention_review_eligible_at" timestamp;
--> statement-breakpoint
ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "report_retention_review_interval_months" integer;
