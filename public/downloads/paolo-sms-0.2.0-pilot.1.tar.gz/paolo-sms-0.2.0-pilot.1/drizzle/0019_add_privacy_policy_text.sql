-- Fuegt der Datenschutz-Konfiguration ein dediziertes Langtext-Feld hinzu, damit
-- der Betreiber die vollstaendige Datenschutzerklaerung selbst pflegen kann
-- (getrennt von den kurzen strukturierten Feldern wie "Zusaetzliche Angaben").
-- Idempotent und additiv (ADD COLUMN IF NOT EXISTS): sicher fuer frische/leere
-- Docker-PostgreSQL und ein No-op auf bestehenden DBs. Keine Daten werden
-- veraendert, keine Spalten geloescht.
ALTER TABLE "organization_legal_settings" ADD COLUMN IF NOT EXISTS "privacy_policy_text" text;
