import { relations } from "drizzle-orm/relations";
import { roles, userRoles, reports, measures, attachments, organizations } from "./schema";

export const userRolesRelations = relations(userRoles, ({one}) => ({
	role: one(roles, {
		fields: [userRoles.roleId],
		references: [roles.id]
	}),
	organization: one(organizations, {
		fields: [userRoles.organizationId],
		references: [organizations.id]
	}),
}));

export const rolesRelations = relations(roles, ({many}) => ({
	userRoles: many(userRoles),
}));

export const measuresRelations = relations(measures, ({one}) => ({
	report: one(reports, {
		fields: [measures.reportId],
		references: [reports.id]
	}),
}));

export const reportsRelations = relations(reports, ({one, many}) => ({
	measures: many(measures),
	attachments: many(attachments),
	organization: one(organizations, {
		fields: [reports.organizationId],
		references: [organizations.id]
	}),
}));

export const attachmentsRelations = relations(attachments, ({one}) => ({
	report: one(reports, {
		fields: [attachments.reportId],
		references: [reports.id]
	}),
}));

export const organizationsRelations = relations(organizations, ({many}) => ({
	reports: many(reports),
	userRoles: many(userRoles),
}));
