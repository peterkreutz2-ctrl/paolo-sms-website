-- Retired AI experiment: compatibility placeholder, intentionally no DDL.
-- Original SQL is preserved on experimental/ai-dialog (b1ce622) and in
-- tests/migrations/fixtures/original-migrations.json. Do not recreate these
-- tables on main. Unexpected experimental tables are left untouched.
SELECT 1;
