-- Gemeinsamer, datensparsamer Zähler für Better-Auth-Anmeldungen. Die
-- Identifier sind HMAC-Werte aus Anwendungscode, keine Klartext-IP oder E-Mail.
-- Additiv und idempotent: bestehende Better-Auth-Konten und Sitzungen bleiben
-- unverändert; ein vollständiger Migrations-Replay ist sicher.
CREATE TABLE IF NOT EXISTS better_auth_login_rate_limits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  scope text NOT NULL,
  identifier text NOT NULL,
  window_start timestamptz NOT NULL,
  window_duration_seconds integer NOT NULL,
  attempt_count integer NOT NULL DEFAULT 0,
  blocked_count integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS better_auth_login_rate_limits_unique
  ON better_auth_login_rate_limits (scope, identifier, window_start);

CREATE INDEX IF NOT EXISTS better_auth_login_rate_limits_window_start_idx
  ON better_auth_login_rate_limits (window_start);
