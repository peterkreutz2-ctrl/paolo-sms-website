-- Fuegt der Meldung strukturierte ICAO-Risikomatrix-Felder hinzu:
-- risk_probability (Eintrittswahrscheinlichkeit / Safety Risk Probability, "1".."5")
-- und risk_severity (Schweregrad / Safety Risk Severity, "A".."E").
-- Rein dokumentarisch: kein automatischer Workflow, keine Freigabelogik, keine
-- neue Berechtigung. priority/status/reportType bleiben unveraendert. Beide
-- Spalten nullable = "nicht bewertet"; bestehende Reports bleiben gueltig
-- (kein Backfill).
-- Idempotent und additiv (ADD COLUMN IF NOT EXISTS): sicher fuer frische/leere
-- Docker-PostgreSQL und ein No-op auf bestehenden DBs. Keine Daten werden
-- veraendert, keine Spalten geloescht.
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "risk_probability" text;
--> statement-breakpoint
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "risk_severity" text;
