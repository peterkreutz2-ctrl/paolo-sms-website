-- Fuegt der Organisation dokumentarische Felder zur SMS-Verantwortung hinzu
-- (ICAO Annex 19): Accountable Executive (nicht delegierbare Gesamtverantwortung /
-- Accountability) und Safety Manager (delegierbare operative SMS-Aufgaben /
-- Responsibility). Rein dokumentarisch: keine neue Rolle, keine Berechtigungslogik,
-- keine Auswertung oder Fristenpruefung. "term" ist Freitext.
-- Idempotent und additiv (ADD COLUMN IF NOT EXISTS): sicher fuer frische/leere
-- Docker-PostgreSQL und ein No-op auf bestehenden DBs. Keine Daten werden
-- veraendert, keine Spalten geloescht.
ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "accountable_executive_name" text;
--> statement-breakpoint
ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "accountable_executive_function" text;
--> statement-breakpoint
ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "accountable_executive_contact" text;
--> statement-breakpoint
ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "accountable_executive_term" text;
--> statement-breakpoint
ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "safety_manager_name" text;
--> statement-breakpoint
ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "safety_manager_function" text;
--> statement-breakpoint
ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "safety_manager_contact" text;
--> statement-breakpoint
ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "safety_manager_term" text;
