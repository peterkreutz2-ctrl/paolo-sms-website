CREATE TABLE IF NOT EXISTS "roles" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"key" text NOT NULL,
	"label" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "user_roles" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"clerk_user_id" text NOT NULL,
	"role_id" uuid NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
DO $$ BEGIN
  ALTER TABLE "user_roles" ADD CONSTRAINT "user_roles_role_id_roles_id_fk" FOREIGN KEY ("role_id") REFERENCES "public"."roles"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "roles_key_unique" ON "roles" USING btree ("key");--> statement-breakpoint
-- 0005 replaces this with separate global/organization uniqueness. Never
-- recreate the old, stricter index on a later schema: valid scoped assignments
-- can share the same user and role.
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_attribute
    WHERE attrelid = 'public.user_roles'::regclass
      AND attname = 'organization_id' AND NOT attisdropped
  ) THEN
    CREATE UNIQUE INDEX IF NOT EXISTS "user_roles_clerk_user_role_unique"
      ON "user_roles" USING btree ("clerk_user_id","role_id");
  END IF;
END $$;
--> statement-breakpoint
INSERT INTO "roles" ("key", "label")
VALUES
  ('admin', 'Administrator'),
  ('safety_manager', 'Sicherheitsmanager'),
  ('instructor', 'Fluglehrer'),
  ('member', 'Benutzer')
ON CONFLICT ("key") DO NOTHING;
