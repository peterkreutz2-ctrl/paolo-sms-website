-- Konfigurierbare Datenschutz-Einwilligung fuer oeffentliche Meldungen (#101).
--
-- Konfiguration (organizations):
--
--   public_report_privacy_consent_enabled
--                              Organisationsschalter. DEFAULT true erfuellt die
--                              Voreinstellung "Ein" auch fuer bestehende
--                              Installationen, ohne Datenmigration -- dasselbe
--                              Muster wie public_report_status_enabled (0032).
--
--   public_report_privacy_consent_text
--                              Betreiberspezifischer Einwilligungstext. NULL
--                              heisst "Standardtext aus dem Code"
--                              (lib/constants/public-report-privacy-consent.ts).
--                              So steht kein Rechtstext in einer Migration, und
--                              der Standard bleibt im Code nachvollziehbar.
--
-- Nachweis je Meldung (reports), alle drei gemeinsam belegt oder gemeinsam NULL:
--
--   privacy_consent_at         Serverzeitpunkt der angenommenen Einwilligung.
--                              timestamptz, damit der Nachweis nicht von der
--                              Sitzungszeitzone der Installation abhaengt.
--   privacy_consent_text       Wortlaut der Einwilligung, wie er angezeigt wurde.
--   privacy_policy_snapshot    Die zu diesem Zeitpunkt wirksame
--                              Datenschutzerklaerung, wie /datenschutz sie zeigt.
--
-- Snapshots statt Hash oder Versionsnummer: Ein Hash ist nicht umkehrbar und
-- braucht eine dauerhaft gefuehrte Texthistorie; eine Version braucht bei
-- betreiberseitig editierbaren Texten ebenfalls eine Historientabelle. Der
-- Snapshot ist in sich geschlossen und uebersteht Restore und spaetere
-- Textaenderungen.
--
-- KEIN Backfill: Bestehende Meldungen bleiben NULL. Ein nachtraeglicher Eintrag
-- wuerde einen Nachweis erfinden, den es nie gab. Meldungen aus CSV-Import,
-- Spieldaten oder bei ausgeschalteter Funktion bleiben ebenfalls NULL.
--
-- Idempotent und additiv (ADD COLUMN IF NOT EXISTS, CHECK nur wenn fehlend):
-- sicher auf frischen und auf bestehenden Datenbanken, kein Datenverlust.

ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "public_report_privacy_consent_enabled" boolean NOT NULL DEFAULT true;
--> statement-breakpoint
ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "public_report_privacy_consent_text" text;
--> statement-breakpoint
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "privacy_consent_at" timestamp with time zone;
--> statement-breakpoint
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "privacy_consent_text" text;
--> statement-breakpoint
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "privacy_policy_snapshot" text;
--> statement-breakpoint

-- Der Nachweis ist nur vollstaendig etwas wert. Die Bedingung macht daraus eine
-- Zusicherung der Datenbank: Auch ein kuenftiger Codepfad kann keinen halben
-- Nachweis schreiben. Bestandszeilen erfuellen sie, weil alle drei NULL sind.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'reports_privacy_consent_complete'
      AND conrelid = 'public.reports'::regclass
  ) THEN
    ALTER TABLE "reports"
      ADD CONSTRAINT "reports_privacy_consent_complete"
      CHECK (
        (privacy_consent_at IS NULL
          AND privacy_consent_text IS NULL
          AND privacy_policy_snapshot IS NULL)
        OR
        (privacy_consent_at IS NOT NULL
          AND privacy_consent_text IS NOT NULL
          AND privacy_policy_snapshot IS NOT NULL)
      );
  END IF;
END $$;
