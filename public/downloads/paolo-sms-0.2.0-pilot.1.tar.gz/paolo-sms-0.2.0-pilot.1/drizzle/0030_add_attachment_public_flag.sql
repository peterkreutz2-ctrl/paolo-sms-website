-- Freigabe-Flag fuer Anhaenge an SMS-Dokumenten (Sicherheitsmitteilungen),
-- Arbeitspaket AP2.
--
-- Genau ein Feld: is_public. Kein Freigabedatum, kein freigebender Benutzer,
-- keine Begruendung — diese Felder gehoeren zum Freigabe-Workflow und damit in
-- ein spaeteres Arbeitspaket.
--
-- DEFAULT false: bestehende Zeilen und jeder kuenftige Upload sind zunaechst
-- NICHT oeffentlich. Eine Veroeffentlichung muss immer eine bewusste Aenderung
-- sein, nie ein Nebeneffekt.
--
-- NOT NULL mit DEFAULT ist ab PostgreSQL 11 eine reine Katalogoperation: kein
-- Table-Rewrite, keine nennenswerte Sperrzeit.

ALTER TABLE attachments
  ADD COLUMN IF NOT EXISTS is_public boolean NOT NULL DEFAULT false;

-- Nur Anhaenge von SMS-Dokumenten duerfen ueberhaupt oeffentlich sein.
-- Oeffentliche Meldungs-Anhaenge sind ausdruecklich kein Ziel; die Bedingung
-- macht daraus eine Zusicherung der Datenbank statt einer blossen Konvention
-- im Anwendungscode. Bestehende Zeilen erfuellen sie zwangslaeufig, weil
-- is_public fuer alle false ist.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'attachments_public_only_for_sms_documents'
      AND conrelid = 'public.attachments'::regclass
  ) THEN
    ALTER TABLE attachments
      ADD CONSTRAINT attachments_public_only_for_sms_documents
      CHECK (NOT is_public OR sms_document_id IS NOT NULL);
  END IF;
END $$;

-- Traegt die oeffentliche Auslieferungsroute: sie sucht einen Anhang ueber
-- seine ID und filtert zusaetzlich auf is_public.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes
    WHERE schemaname = 'public' AND indexname = 'attachments_public_idx'
  ) THEN
    CREATE INDEX attachments_public_idx
      ON attachments (sms_document_id) WHERE is_public;
  END IF;
END $$;
