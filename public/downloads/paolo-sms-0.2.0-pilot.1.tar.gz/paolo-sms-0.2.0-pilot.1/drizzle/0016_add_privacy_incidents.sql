-- Datenschutzvorfälle (Incident-Response). Additiv, idempotent, nicht destruktiv.
CREATE TABLE IF NOT EXISTS "privacy_incidents" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"organization_id" uuid NOT NULL,
	"title" text NOT NULL,
	"status" text DEFAULT 'new' NOT NULL,
	"discovered_at" timestamp,
	"discovered_by_text" text,
	"description" text NOT NULL,
	"affected_data_categories" text,
	"affected_persons_estimate" text,
	"immediate_actions" text,
	"risk_assessment" text DEFAULT 'unknown' NOT NULL,
	"notification_decision" text DEFAULT 'open' NOT NULL,
	"decision_reason" text,
	"follow_up_actions" text,
	"closed_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
DO $$ BEGIN
	ALTER TABLE "privacy_incidents" ADD CONSTRAINT "privacy_incidents_org_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "privacy_incidents_org_created_idx" ON "privacy_incidents" USING btree ("organization_id","created_at");
