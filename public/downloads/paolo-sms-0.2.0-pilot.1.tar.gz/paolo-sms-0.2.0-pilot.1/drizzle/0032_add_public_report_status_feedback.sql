-- Oeffentliche Statusrueckmeldung fuer Sicherheitsmeldungen.
-- Antrag und Analyse: docs/requirements/2026-09-07-oeffentliche-statusrueckmeldung.md
--
-- Drei Felder, kein neuer Tabellenraum:
--
--   reports.public_code        Neutraler Meldungscode ("Falke-12"), den ein
--                              Meldender nach dem Absenden erhaelt und unter
--                              dem er auf /communications den groben
--                              Bearbeitungsstatus wiederfindet. NULL = kein
--                              oeffentlicher Eintrag. Bewusst nullable:
--                              Bestandsmeldungen, CSV-Importe und Spieldaten
--                              bekommen keinen Code, und "kein Code" ist die
--                              sichere Voreinstellung -- eine Meldung kann
--                              nicht versehentlich oeffentlich werden.
--
--   reports.public_closed_at   Fristanker der Dreimonatsregel: gesetzt, wenn
--                              der Status VON einem anderen Wert NACH "closed"
--                              wechselt. Erneutes Speichern einer bereits
--                              abgeschlossenen Meldung aendert ihn nicht;
--                              Wiedereroeffnung und erneuter Abschluss setzen
--                              ihn neu. Bewusst NICHT
--                              retention_review_eligible_at mitbenutzt: das
--                              Feld gehoert dem DSGVO-Retention-Review, wird
--                              auch von "hidden" gesetzt und fehlt bei
--                              importierten Meldungen.
--
--                              timestamptz statt timestamp -- als einzige
--                              Spalte, aus der eine Frist gegen now()
--                              gerechnet wird, darf sie nicht von der
--                              Sitzungszeitzone der jeweiligen Installation
--                              abhaengen.
--
--   organizations.public_report_status_enabled
--                              Organisationsschalter. DEFAULT true erfuellt
--                              die Voreinstellung "Ein" auch fuer bestehende
--                              Installationen, ohne Datenmigration.
--
-- Idempotent und additiv (ADD COLUMN IF NOT EXISTS): sicher auf frischen und
-- auf bestehenden Datenbanken, kein Datenverlust, keine Spalte wird geloescht.
-- NOT NULL mit DEFAULT ist ab PostgreSQL 11 eine reine Katalogoperation.

ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "public_code" text;
--> statement-breakpoint
ALTER TABLE "reports" ADD COLUMN IF NOT EXISTS "public_closed_at" timestamp with time zone;
--> statement-breakpoint
ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "public_report_status_enabled" boolean NOT NULL DEFAULT true;
--> statement-breakpoint

-- Eindeutigkeit je Organisation, nicht global: Der Code ist die oeffentliche
-- Referenz einer Organisation. Heute betreibt jede Installation genau eine,
-- aber die Zusicherung so zu formulieren kostet nichts und haelt die Funktion
-- aus der Liste der Stellen heraus, die bei einer spaeteren
-- Mehrorganisationsfaehigkeit nachgezogen werden muessten.
--
-- Partiell (WHERE public_code IS NOT NULL): Meldungen ohne Code -- Importe,
-- Spieldaten, Bestand -- sind die Mehrheit und duerfen einander nicht
-- blockieren. In PostgreSQL waeren mehrere NULL zwar auch in einem vollen
-- Unique-Index erlaubt; der partielle Index ist zusaetzlich der kleinere.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes
    WHERE schemaname = 'public' AND indexname = 'reports_public_code_unique'
  ) THEN
    CREATE UNIQUE INDEX reports_public_code_unique
      ON reports (organization_id, public_code)
      WHERE public_code IS NOT NULL;
  END IF;
END $$;
