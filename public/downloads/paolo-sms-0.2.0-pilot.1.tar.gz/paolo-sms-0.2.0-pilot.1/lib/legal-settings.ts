import { eq } from "drizzle-orm"

import { db } from "@/lib/db"
import { organizationLegalSettings, organizations } from "@/lib/db/schema"

export type LegalSettings = typeof organizationLegalSettings.$inferSelect

// Lädt die Rechtsangaben der (aktuell einzigen) Organisation. Gibt null zurück,
// wenn keine Organisation oder noch keine Angaben hinterlegt sind.
export async function getLegalSettings(): Promise<LegalSettings | null> {
  const [organization] = await db.select().from(organizations).limit(1)
  if (!organization) return null

  const [legal] = await db
    .select()
    .from(organizationLegalSettings)
    .where(eq(organizationLegalSettings.organizationId, organization.id))
    .limit(1)

  return legal ?? null
}
