import { randomInt } from "node:crypto"

import {
  createPublicReportCode,
  PUBLIC_REPORT_CODE_MAX_ATTEMPTS,
} from "@/lib/constants/public-report-code"

// ─── Vergabe des Meldungscodes ───────────────────────────────────────────────
//
// Die Zufallsziehung steht in lib/constants/public-report-code.ts (reine
// Daten und Regeln, ohne Node-Import). Hier liegt der Teil, der auf den Server
// gehoert: der kryptografische Generator und die Kollisionsbehandlung.
//
// Die Kollision wird NICHT durch Vorablesen ("ist dieser Code schon
// vergeben?") vermieden, sondern durch den Unique-Index abgefangen. Ein
// Vorablesen waere ein Wettlauf: Zwischen Lesen und Schreiben kann eine
// zweite Einreichung denselben Code belegen. Der Index kann das nicht.

/** Ein Zufallswert 0 <= x < maxExclusive aus dem kryptografischen Generator. */
export const cryptoPick = (maxExclusive: number) => randomInt(maxExclusive)

/**
 * Versucht, eine Meldung mit einem freien Code anzulegen.
 *
 * `insertWithCode` bekommt einen Kandidaten und meldet zurueck, ob das
 * Einfuegen an der Eindeutigkeit gescheitert ist. Alles andere — Transaktion,
 * uebrige Felder, Rueckgabewert — bleibt beim Aufrufer; diese Funktion kennt
 * die Datenbank nicht.
 *
 * Rueckgabe `null` heisst: nach PUBLIC_REPORT_CODE_MAX_ATTEMPTS Versuchen war
 * kein Code frei. Der Aufrufer speichert die Meldung dann **ohne** Code. Das
 * ist der Notfallweg des Antrags: Eine Sicherheitsmeldung darf nicht an ihrer
 * Quittung scheitern.
 */
export async function assignPublicReportCode<T>(
  insertWithCode: (
    code: string
  ) => Promise<{ ok: true; value: T } | { ok: false; collision: true }>,
  pick: (maxExclusive: number) => number = cryptoPick,
  maxAttempts: number = PUBLIC_REPORT_CODE_MAX_ATTEMPTS
): Promise<{ code: string; value: T } | null> {
  for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
    const code = createPublicReportCode(pick)
    const result = await insertWithCode(code)
    if (result.ok) {
      return { code, value: result.value }
    }
  }
  return null
}
