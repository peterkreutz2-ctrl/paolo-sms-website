import {
  ACTIVITY_TYPE_LABELS,
  DAMAGE_SEVERITY_LABELS,
  FLIGHT_PHASE_LABELS,
  INJURY_SEVERITY_LABELS,
  LAUNCH_TYPE_LABELS,
  REPORTER_ROLE_LABELS,
} from "@/lib/constants/report-classification"
import { PUBLIC_REPORT_TYPE_LABELS } from "@/lib/constants/public-report-types"

// ─── Zusammenfassung fuer den Meldenden ──────────────────────────────────────
//
// Reine Funktion ohne Datenbank- und ohne Browserzugriff. Sie baut den Text
// aus einer beim Absenden festgehaltenen Kopie der uebermittelten Angaben.
//
// Zwei Eigenschaften sind hier keine Sorgfalt, sondern Bauart:
//
//   - Es kann nichts Internes hineingeraten. Die Funktion sieht nur, was der
//     Meldende selbst eingegeben hat; Bearbeitungsvermerke, Status oder
//     Kommentare existieren zu diesem Zeitpunkt noch gar nicht.
//   - Es kann keine fremde Zusammenfassung entstehen. Die Datei wird im
//     Browser aus den eigenen Eingaben gebaut, nicht von einer Route
//     abgerufen. Damit gibt es keinen Weg, ueber den Meldungscode an die
//     Zusammenfassung einer anderen Meldung zu kommen — es gibt schlicht
//     nichts abzurufen.

export type PublicReportSummaryInput = {
  reportType: string
  shortDescription: string
  description: string
  occurredAt?: string
  locationText?: string
  reporterLessonsLearned?: string
  reporterSuggestedMeasures?: string
  activityType?: string
  flightPhase?: string
  launchType?: string
  injurySeverity?: string
  damageSeverity?: string
  reporterName?: string
  reporterRole?: string
  reporterContact?: string
}

function labelOf(
  labels: Record<string, string>,
  value: string | undefined
): string | undefined {
  if (!value) return undefined
  return labels[value] ?? value
}

function formatDateTime(value: string | undefined): string | undefined {
  if (!value) return undefined
  const parsed = new Date(value)
  if (Number.isNaN(parsed.getTime())) return value
  return new Intl.DateTimeFormat("de-DE", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(parsed)
}

/**
 * Baut den Text der herunterladbaren Zusammenfassung.
 *
 * `publicCode` ist `null`, wenn ausnahmsweise kein Code vergeben werden konnte
 * (Notfallweg). Die Zusammenfassung sagt das dann offen, statt die Zeile
 * wegzulassen — der Meldende soll wissen, warum er keinen Code hat.
 *
 * `publicStatusEnabled` steuert nur den Hinweis am Ende: Verweist die
 * Organisation gar nicht auf eine oeffentliche Statusanzeige, darf die Datei
 * das auch nicht tun.
 */
export function buildPublicReportSummary({
  data,
  publicCode,
  publicStatusEnabled,
  submittedAt = new Date(),
}: {
  data: PublicReportSummaryInput
  publicCode: string | null
  publicStatusEnabled: boolean
  submittedAt?: Date
}): string {
  const lines: string[] = []

  lines.push("Deine Sicherheitsmeldung an PAOLO SMS")
  lines.push("=====================================")
  lines.push("")

  if (publicCode) {
    lines.push(`Meldungscode: ${publicCode}`)
  } else {
    lines.push(
      "Meldungscode: konnte ausnahmsweise nicht vergeben werden. Deine Meldung ist gespeichert."
    )
  }

  lines.push(
    `Eingereicht am: ${new Intl.DateTimeFormat("de-DE", {
      dateStyle: "medium",
      timeStyle: "short",
    }).format(submittedAt)}`
  )
  lines.push("")
  lines.push("Deine Angaben")
  lines.push("-------------")
  lines.push("")

  const fields: Array<[string, string | undefined]> = [
    ["Art der Meldung", labelOf(PUBLIC_REPORT_TYPE_LABELS, data.reportType)],
    ["Kurzbeschreibung", data.shortDescription],
    ["Beschreibung", data.description],
    ["Zeitpunkt des Ereignisses", formatDateTime(data.occurredAt)],
    ["Ort", data.locationText],
    ["Aktivität", labelOf(ACTIVITY_TYPE_LABELS, data.activityType)],
    ["Flugphase", labelOf(FLIGHT_PHASE_LABELS, data.flightPhase)],
    ["Startart", labelOf(LAUNCH_TYPE_LABELS, data.launchType)],
    [
      "Verletzungsschwere",
      labelOf(INJURY_SEVERITY_LABELS, data.injurySeverity),
    ],
    ["Sachschaden", labelOf(DAMAGE_SEVERITY_LABELS, data.damageSeverity)],
    ["Was hast du daraus gelernt?", data.reporterLessonsLearned],
    ["Vorgeschlagene Maßnahmen", data.reporterSuggestedMeasures],
    ["Name", data.reporterName],
    ["Rolle", labelOf(REPORTER_ROLE_LABELS, data.reporterRole)],
    ["Kontakt", data.reporterContact],
  ]

  for (const [label, value] of fields) {
    const trimmed = value?.trim()
    if (!trimmed) continue
    // Mehrzeilige Freitexte bekommen den Titel auf eine eigene Zeile, damit
    // die Datei auch in einem einfachen Editor lesbar bleibt.
    if (trimmed.includes("\n")) {
      lines.push(`${label}:`)
      lines.push(trimmed)
    } else {
      lines.push(`${label}: ${trimmed}`)
    }
    lines.push("")
  }

  lines.push("Hinweise")
  lines.push("--------")
  lines.push("")

  if (publicCode && publicStatusEnabled) {
    lines.push(
      "Auf der Seite „Sicherheitsinformationen“ findest du unter deinem Meldungscode"
    )
    lines.push(
      "den Bearbeitungsstatus. Öffentlich angezeigt werden ausschließlich der Code"
    )
    lines.push("und der Status – keine Inhalte deiner Meldung.")
  } else if (publicCode) {
    lines.push(
      "Die öffentliche Anzeige des Bearbeitungsstatus ist derzeit deaktiviert."
    )
    lines.push("Deine Meldung wird trotzdem bearbeitet.")
  } else {
    lines.push(
      "Ohne Meldungscode gibt es zu dieser Meldung keinen öffentlichen Eintrag."
    )
    lines.push("Sie liegt dem Safety Manager trotzdem vollständig vor.")
  }

  lines.push("")
  lines.push(
    "Anhänge wie Bilder, Videos oder Tracks lassen sich ohne Anmeldung nicht"
  )
  lines.push(
    "hochladen. Leite sie bei Bedarf an die Sicherheitsverantwortlichen weiter."
  )
  lines.push("")
  lines.push(
    "Diese Datei liegt nur auf deinem Gerät. Sie enthält deine eigenen Angaben –"
  )
  lines.push("bewahre sie so auf, wie du es für richtig hältst.")
  lines.push("")

  return lines.join("\n")
}

/** Dateiname der Zusammenfassung — mit Code, wenn es einen gibt. */
export function publicReportSummaryFileName(publicCode: string | null): string {
  return publicCode
    ? `PAOLO-Meldung-${publicCode}.txt`
    : "PAOLO-Meldung.txt"
}
