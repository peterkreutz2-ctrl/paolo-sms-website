// Internes Hilfsmodul, KEINE Server Action — die Datei traegt bewusst kein
// "use server". Sie lag bis #44 unter lib/actions/ und sah dadurch aus wie
// eine aufrufbare Action ohne Berechtigungspruefung. Der Aufrufer ist immer
// eine Server Action, die ihren eigenen Guard bereits passiert hat und ihre
// Transaktion hereinreicht.

import { and, eq } from "drizzle-orm"

import { db } from "@/lib/db"
import { reports } from "@/lib/db/schema"

// Akzeptiert entweder den globalen db-Client oder den tx-Client, den
// db.transaction(async (tx) => ...) an den Callback uebergibt (gleiches
// Muster wie DbOrTx in lib/audit.ts) — damit Aufrufer die Schreiboperation
// und diesen Reset atomar in derselben Transaktion ausfuehren koennen.
type DbOrTx = typeof db | Parameters<Parameters<typeof db.transaction>[0]>[0]

/**
 * Setzt eine als vollstaendig geprueft bestaetigte Meldung
 * (anonymizationStatus = "completed") zurueck auf "needs_review", sobald
 * Inhalte hinzugefuegt oder geaendert werden, durch die erneut Personenbezug
 * entstehen kann (neue Notizen/Anhaenge/Massnahmen, geaenderte
 * Massnahmen-Freitexte). No-op fuer Reports, die aktuell nicht "completed"
 * sind — kein Schreibzugriff ohne fachlichen Grund.
 */
export async function markAnonymizationNeedsReview(
  reportId: string,
  dbClient: DbOrTx = db
): Promise<void> {
  await dbClient
    .update(reports)
    .set({ anonymizationStatus: "needs_review" })
    .where(
      and(eq(reports.id, reportId), eq(reports.anonymizationStatus, "completed"))
    )
}
