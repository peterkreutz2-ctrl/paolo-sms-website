import { rm } from "node:fs/promises"

import { auditBackupEvent } from "@/lib/backup/audit"
import {
  getBackupRetentionPolicy,
  isBackupRetentionEnabled,
} from "@/lib/backup/config"
import {
  dataPathFromManifest,
  listValidBackups,
  manifestPath,
  withBackupLock,
} from "@/lib/backup/filesystem"
import type { BackupManifest } from "@/lib/backup/manifest"

export type BackupRetentionPolicy = {
  dailyDays: number
  weeklyWeeks: number
  monthlyMonths: number
}

const DAY_MS = 24 * 60 * 60 * 1_000

function isoWeekKey(value: Date): string {
  const date = new Date(Date.UTC(value.getUTCFullYear(), value.getUTCMonth(), value.getUTCDate()))
  const weekday = date.getUTCDay() || 7
  date.setUTCDate(date.getUTCDate() + 4 - weekday)
  const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1))
  const week = Math.ceil(((date.getTime() - yearStart.getTime()) / DAY_MS + 1) / 7)
  return `${date.getUTCFullYear()}-${String(week).padStart(2, "0")}`
}

function monthKey(value: Date): string {
  return `${value.getUTCFullYear()}-${String(value.getUTCMonth() + 1).padStart(2, "0")}`
}

function recentWeekKeys(now: Date, count: number): Set<string> {
  const keys = new Set<string>()
  for (let offset = 0; offset < count; offset += 1) {
    keys.add(isoWeekKey(new Date(now.getTime() - offset * 7 * DAY_MS)))
  }
  return keys
}

function recentMonthKeys(now: Date, count: number): Set<string> {
  const keys = new Set<string>()
  for (let offset = 0; offset < count; offset += 1) {
    keys.add(monthKey(new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - offset, 1))))
  }
  return keys
}

export function selectBackupsForRetentionDeletion(
  backups: readonly BackupManifest[],
  policy: BackupRetentionPolicy,
  now = new Date(),
): BackupManifest[] {
  const sorted = [...backups].sort((a, b) => b.createdAt.localeCompare(a.createdAt))
  if (sorted.length <= 1) return []

  const retained = new Set<string>([sorted[0].backupId])
  const retainedWeeks = new Set<string>()
  const retainedMonths = new Set<string>()
  const eligibleWeeks = recentWeekKeys(now, policy.weeklyWeeks)
  const eligibleMonths = recentMonthKeys(now, policy.monthlyMonths)
  const dailyCutoff = now.getTime() - policy.dailyDays * DAY_MS

  for (const backup of sorted) {
    const createdAt = new Date(backup.createdAt)
    if (policy.dailyDays > 0 && createdAt.getTime() >= dailyCutoff) {
      retained.add(backup.backupId)
    }

    const week = isoWeekKey(createdAt)
    if (eligibleWeeks.has(week) && !retainedWeeks.has(week)) {
      retained.add(backup.backupId)
      retainedWeeks.add(week)
    }

    const month = monthKey(createdAt)
    if (eligibleMonths.has(month) && !retainedMonths.has(month)) {
      retained.add(backup.backupId)
      retainedMonths.add(month)
    }
  }

  return sorted.filter((backup) => !retained.has(backup.backupId))
}

export async function applyBackupRetention(): Promise<BackupManifest[]> {
  if (!isBackupRetentionEnabled()) return []
  return withBackupLock(async () => {
    const backups = await listValidBackups()
    const expired = selectBackupsForRetentionDeletion(
      backups,
      getBackupRetentionPolicy(),
    )
    for (const backup of expired) {
      // Remove ciphertext first. A partially deleted pair is then invalid and
      // hidden rather than exposing a manifest whose archive no longer exists.
      await rm(dataPathFromManifest(backup), { force: true })
      await rm(manifestPath(backup.backupId), { force: true })
    }
    return expired
  })
}

export async function applyBackupRetentionAndAudit(params: {
  backupId: string
  userId: string | null
}): Promise<void> {
  try {
    const deleted = await applyBackupRetention()
    if (deleted.length === 0) return
    await auditBackupEvent({
      userId: params.userId,
      backupId: params.backupId,
      action: "BACKUP_RETENTION_APPLIED",
      changes: {
        deletedCount: deleted.length,
        policy: getBackupRetentionPolicy(),
      },
    })
  } catch (error) {
    console.error("[backup] Retention cleanup failed:", error)
    await auditBackupEvent({
      userId: params.userId,
      backupId: params.backupId,
      action: "BACKUP_RETENTION_FAILED",
      changes: { reason: "cleanup_failed" },
    })
  }
}
