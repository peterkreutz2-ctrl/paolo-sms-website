import { z } from "zod"

import { BACKUP_FORMAT_VERSION, BACKUP_ID_PATTERN } from "./constants"

export const backupManifestSchema = z.object({
  formatVersion: z.literal(BACKUP_FORMAT_VERSION),
  backupId: z.string().regex(BACKUP_ID_PATTERN),
  createdAt: z.iso.datetime(),
  creatorUserId: z.string().min(1),
  engine: z.enum(["pg_dump", "paolo_data"]),
  archiveFormat: z.enum(["postgresql-custom", "paolo-data-ndjson-gzip"]),
  databaseFileName: z.string().regex(/^[0-9a-f-]+\.(dump|paolo\.jsonl\.gz)(\.age)?$/i),
  fileSize: z.number().int().nonnegative(),
  sha256: z.string().regex(/^[0-9a-f]{64}$/),
  schemaVersion: z.string().min(1),
  postgresVersion: z.string().min(1).optional(),
  pgDumpVersion: z.string().min(1).optional(),
  attachmentsIncluded: z.literal(false),
  encryption: z.object({
    scheme: z.literal("age"),
    encrypted: z.literal(true),
    recipientHints: z.array(z.string().regex(/^[0-9a-f]{12}$/)).min(1),
  }),
  plaintextFileSize: z.number().int().nonnegative(),
  plaintextSha256: z.string().regex(/^[0-9a-f]{64}$/),
}).superRefine((manifest, context) => {
  if (!manifest.databaseFileName.endsWith(".age")) context.addIssue({ code: "custom", message: "Backup-Archiv muss mit age verschlüsselt sein." })
})

export type BackupManifest = z.infer<typeof backupManifestSchema>

export function parseBackupManifest(input: unknown): BackupManifest {
  return backupManifestSchema.parse(input)
}
