import { logAuditEvent } from "@/lib/audit"
import { db } from "@/lib/db"
import { organizations } from "@/lib/db/schema"

export async function auditBackupEvent(params: {
  userId: string | null
  backupId: string
  action: "BACKUP_CREATED" | "BACKUP_CRON_REJECTED" | "BACKUP_CRON_FAILED" | "BACKUP_DOWNLOADED" | "BACKUP_MANIFEST_DOWNLOADED" | "BACKUP_RETENTION_APPLIED" | "BACKUP_RETENTION_FAILED"
  changes: Record<string, unknown>
}): Promise<void> {
  const [organization] = await db.select({ id: organizations.id }).from(organizations).limit(1)
  if (!organization) {
    console.error("[backup] Audit event could not be assigned: no organization exists.")
    return
  }
  await logAuditEvent({
    organizationId: organization.id,
    clerkUserId: params.userId,
    action: params.action,
    resourceType: "backup",
    resourceId: params.backupId,
    changes: params.changes,
  })
}

