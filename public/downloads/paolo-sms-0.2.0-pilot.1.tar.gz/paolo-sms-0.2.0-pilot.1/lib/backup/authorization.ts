import { appAuth } from "@/lib/auth"
import { getCurrentUserGlobalRoles } from "@/lib/auth/user-roles"

import { isGlobalAdmin } from "./security"

export async function requireGlobalAdmin(): Promise<string> {
  const { userId } = await appAuth()
  if (!userId) throw new BackupAuthorizationError("unauthenticated")
  if (!isGlobalAdmin(await getCurrentUserGlobalRoles())) throw new BackupAuthorizationError("forbidden")
  return userId
}

export class BackupAuthorizationError extends Error {
  constructor(public readonly reason: "unauthenticated" | "forbidden") {
    super(reason)
  }
}
