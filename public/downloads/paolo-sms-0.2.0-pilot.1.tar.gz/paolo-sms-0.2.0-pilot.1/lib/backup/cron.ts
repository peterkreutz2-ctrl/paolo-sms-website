import { createHash, randomUUID, timingSafeEqual } from "node:crypto"

import { dbPool } from "@/lib/db"
import {
  getBackupCronMaxRuntimeMinutes,
  getBackupCronMinIntervalMinutes,
  getBackupCronSecret,
} from "@/lib/backup/config"

const CRON_STATE_KEY = "scheduled-backup"

export type BackupCronClaim =
  | { acquired: true; attemptId: string }
  | { acquired: false; attemptId: string; reason: "in_progress" | "rate_limited"; retryAfterSeconds: number }

function digest(value: string): Buffer {
  return createHash("sha256").update(value, "utf8").digest()
}

export function isValidBackupCronAuthorization(authorization: string | null): boolean {
  let expected: string
  try {
    expected = `Bearer ${getBackupCronSecret()}`
  } catch {
    return false
  }
  return timingSafeEqual(digest(authorization ?? ""), digest(expected))
}

export async function claimBackupCronRun(now = new Date()): Promise<BackupCronClaim> {
  const attemptId = randomUUID()
  const minIntervalMinutes = getBackupCronMinIntervalMinutes()
  const maxRuntimeMinutes = getBackupCronMaxRuntimeMinutes()
  const result = await dbPool.query<{ acquired: boolean; status: string; retry_after_seconds: number }>(
    `WITH claimed AS (
       INSERT INTO backup_cron_state (
         key, status, last_started_at, lease_expires_at, updated_at
       )
       VALUES (
         $1::text,
         'running',
         $2::timestamptz,
         $2::timestamptz + ($3::integer * interval '1 minute'),
         $2::timestamptz
       )
       ON CONFLICT (key) DO UPDATE SET
         status = 'running',
         last_started_at = $2::timestamptz,
         lease_expires_at = $2::timestamptz + ($3::integer * interval '1 minute'),
         updated_at = $2::timestamptz
       WHERE
         backup_cron_state.lease_expires_at <= $2::timestamptz
         AND backup_cron_state.last_started_at <=
           $2::timestamptz - ($4::integer * interval '1 minute')
       RETURNING true AS acquired, status, 0::integer AS retry_after_seconds
     )
     SELECT * FROM claimed
     UNION ALL
     SELECT
       false AS acquired,
       CASE
         WHEN lease_expires_at > $2::timestamptz THEN 'running'
         ELSE 'rate_limited'
       END AS status,
       GREATEST(
         1,
         CEIL(EXTRACT(EPOCH FROM (
           CASE
             WHEN lease_expires_at > $2::timestamptz THEN lease_expires_at
             ELSE last_started_at + ($4::integer * interval '1 minute')
           END - $2::timestamptz
         )))
       )::integer AS retry_after_seconds
     FROM backup_cron_state
     WHERE key = $1::text AND NOT EXISTS (SELECT 1 FROM claimed)
     LIMIT 1`,
    [CRON_STATE_KEY, now, maxRuntimeMinutes, minIntervalMinutes],
  )
  const row = result.rows[0]
  if (!row) throw new Error("Cron-Backup-Status konnte nicht reserviert werden.")
  if (row.acquired) return { acquired: true, attemptId }
  return {
    acquired: false,
    attemptId,
    reason: row.status === "running" ? "in_progress" : "rate_limited",
    retryAfterSeconds: row.retry_after_seconds,
  }
}

export async function completeBackupCronRun(backupId: string): Promise<void> {
  await dbPool.query(
    `UPDATE backup_cron_state
     SET status = 'completed',
         last_completed_at = now(),
         last_backup_id = $2,
         lease_expires_at = now(),
         updated_at = now()
     WHERE key = $1`,
    [CRON_STATE_KEY, backupId],
  )
}

export async function failBackupCronRun(): Promise<void> {
  await dbPool.query(
    `UPDATE backup_cron_state
     SET status = 'failed', lease_expires_at = now(), updated_at = now()
     WHERE key = $1`,
    [CRON_STATE_KEY],
  )
}
