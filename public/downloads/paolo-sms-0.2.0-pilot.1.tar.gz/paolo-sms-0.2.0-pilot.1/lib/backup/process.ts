import { spawn } from "node:child_process"
import { createWriteStream } from "node:fs"

export async function runCommand(
  executable: string,
  args: readonly string[],
  options: { env?: NodeJS.ProcessEnv; captureStdout?: boolean } = {},
): Promise<string> {
  return new Promise((resolve, reject) => {
    const child = spawn(executable, [...args], {
      env: options.env,
      shell: false,
      windowsHide: true,
      stdio: ["ignore", options.captureStdout ? "pipe" : "ignore", "pipe"],
    })
    let stdout = ""
    let stderr = ""
    child.stdout?.setEncoding("utf8")
    child.stderr?.setEncoding("utf8")
    child.stdout?.on("data", (chunk) => { stdout += chunk })
    child.stderr?.on("data", (chunk) => { stderr += chunk })
    child.once("error", reject)
    child.once("exit", (code) => {
      if (code === 0) return resolve(stdout.trim())
      reject(new Error(`Prozess wurde mit Code ${code ?? "unbekannt"} beendet: ${stderr.trim() || "keine Fehlerausgabe"}`))
    })
  })
}

export async function runCommandToFile(
  executable: string,
  args: readonly string[],
  destination: string,
  options: { env?: NodeJS.ProcessEnv } = {},
): Promise<void> {
  return new Promise((resolve, reject) => {
    const output = createWriteStream(destination, { flags: "wx", mode: 0o600 })
    const child = spawn(executable, [...args], {
      env: options.env,
      shell: false,
      windowsHide: true,
      stdio: ["ignore", "pipe", "pipe"],
    })
    let stderr = ""
    let processFinished = false
    let outputFinished = false
    let settled = false
    const fail = (error: Error) => {
      if (settled) return
      settled = true
      child.kill()
      output.destroy()
      reject(error)
    }
    const finish = () => {
      if (!settled && processFinished && outputFinished) {
        settled = true
        resolve()
      }
    }
    child.stderr.setEncoding("utf8")
    child.stderr.on("data", (chunk) => { stderr += chunk })
    child.once("error", fail)
    output.once("error", fail)
    output.once("finish", () => { outputFinished = true; finish() })
    child.stdout.pipe(output)
    child.once("exit", (code) => {
      if (code !== 0) return fail(new Error(`Prozess wurde mit Code ${code ?? "unbekannt"} beendet: ${stderr.trim() || "keine Fehlerausgabe"}`))
      processFinished = true
      finish()
    })
  })
}
