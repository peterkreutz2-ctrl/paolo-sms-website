import { randomUUID } from "node:crypto"
import { mkdir, rename, rm, stat } from "node:fs/promises"
import path from "node:path"

import { dbPool } from "@/lib/db"
import { BACKUP_FORMAT_VERSION, PAOLO_DATA_FORMAT, PAOLO_SCHEMA_VERSION, PG_DUMP_FORMAT } from "./constants"
import { getAgeRecipients, getBackupDir, getBackupEngine, getPgDumpPath, postgresProcessEnv } from "./config"
import { ageRecipientHint, encryptWithAge } from "./encryption"
import { publishManifest, sha256File, withBackupLock } from "./filesystem"
import type { BackupManifest } from "./manifest"
import { exportPaoloData } from "./paolo-data"
import { runCommand, runCommandToFile } from "./process"

async function postgresVersion(): Promise<string | undefined> {
  try {
    const result = await dbPool.query<{ version: string }>("SHOW server_version")
    return result.rows[0]?.version
  } catch { return undefined }
}

export async function createBackup(creatorUserId: string): Promise<BackupManifest> {
  return withBackupLock(async () => {
    const engine = getBackupEngine()
    const backupId = randomUUID()
    const dir = getBackupDir()
    await mkdir(dir, { recursive: true })
    const extension = engine === "pg_dump" ? ".dump" : ".paolo.jsonl.gz"
    const databaseFileName = `${backupId}${extension}.age`
    const finalDataPath = path.join(dir, databaseFileName)
    const tempPlaintextPath = path.join(dir, `.${backupId}${extension}.${randomUUID()}.plaintext.tmp`)
    const tempDataPath = path.join(dir, `.${databaseFileName}.${randomUUID()}.tmp`)
    const tempManifestPath = path.join(dir, `.${backupId}.${randomUUID()}.manifest.tmp`)
    let pgDumpVersion: string | undefined
    let dataPublished = false

    try {
      if (engine === "pg_dump") {
        const executable = getPgDumpPath()
        pgDumpVersion = await runCommand(executable, ["--version"], { captureStdout: true })
        await runCommandToFile(executable, ["--format=custom", "--no-owner", "--no-privileges"], tempPlaintextPath, {
          env: postgresProcessEnv(),
        })
      } else {
        await exportPaoloData(dbPool, tempPlaintextPath)
      }

      const plaintextInfo = await stat(tempPlaintextPath)
      const plaintextSha256 = await sha256File(tempPlaintextPath)
      const recipients = getAgeRecipients()
      await encryptWithAge({ source: tempPlaintextPath, destination: tempDataPath, recipients })
      await rm(tempPlaintextPath, { force: true })

      const fileInfo = await stat(tempDataPath)
      const manifest: BackupManifest = {
        formatVersion: BACKUP_FORMAT_VERSION,
        backupId,
        createdAt: new Date().toISOString(),
        creatorUserId,
        engine,
        archiveFormat: engine === "pg_dump" ? PG_DUMP_FORMAT : PAOLO_DATA_FORMAT,
        databaseFileName,
        fileSize: fileInfo.size,
        sha256: await sha256File(tempDataPath),
        schemaVersion: PAOLO_SCHEMA_VERSION,
        postgresVersion: await postgresVersion(),
        pgDumpVersion,
        attachmentsIncluded: false,
        encryption: {
          scheme: "age",
          encrypted: true,
          recipientHints: recipients.map(ageRecipientHint),
        },
        plaintextFileSize: plaintextInfo.size,
        plaintextSha256,
      }
      await rename(tempDataPath, finalDataPath)
      dataPublished = true
      await publishManifest(tempManifestPath, manifest)
      return manifest
    } catch (error) {
      await rm(tempPlaintextPath, { force: true }).catch(() => undefined)
      await rm(tempDataPath, { force: true }).catch(() => undefined)
      await rm(tempManifestPath, { force: true }).catch(() => undefined)
      if (dataPublished) await rm(finalDataPath, { force: true }).catch(() => undefined)
      throw error
    }
  })
}
