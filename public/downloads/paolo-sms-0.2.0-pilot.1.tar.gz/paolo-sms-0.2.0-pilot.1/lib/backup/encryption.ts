import { createHash, randomUUID } from "node:crypto"
import { rm, stat } from "node:fs/promises"
import path from "node:path"

import { getAgePath } from "./config"
import { sha256File } from "./filesystem"
import type { BackupManifest } from "./manifest"
import { runCommandToFile } from "./process"

export function ageRecipientHint(recipient: string): string {
  return createHash("sha256").update(recipient).digest("hex").slice(0, 12)
}

export async function encryptWithAge(params: {
  source: string
  destination: string
  recipients: readonly string[]
}): Promise<void> {
  if (params.recipients.length === 0) throw new Error("Keine age-Empfänger konfiguriert.")
  const args = ["--encrypt"]
  for (const recipient of params.recipients) args.push("--recipient", recipient)
  args.push(params.source)
  await runCommandToFile(getAgePath(), args, params.destination)
}

export async function decryptBackupToTemporaryFile(params: {
  manifest: BackupManifest
  encryptedPath: string
  identityPath: string | undefined
}): Promise<{ path: string; cleanup: () => Promise<void> }> {
  if (!params.identityPath?.trim()) throw new Error("Für ein verschlüsseltes Backup ist --identity=<pfad> erforderlich.")

  const temporaryPath = path.join(
    path.dirname(params.encryptedPath),
    `.${params.manifest.backupId}.${randomUUID()}.decrypted.tmp`,
  )
  const cleanup = async () => { await rm(temporaryPath, { force: true }) }
  try {
    await runCommandToFile(getAgePath(), ["--decrypt", "--identity", params.identityPath, params.encryptedPath], temporaryPath)
    const fileInfo = await stat(temporaryPath)
    if (fileInfo.size !== params.manifest.plaintextFileSize) throw new Error("Größe des entschlüsselten Archivs stimmt nicht.")
    if (await sha256File(temporaryPath) !== params.manifest.plaintextSha256) throw new Error("SHA-256 des entschlüsselten Archivs stimmt nicht.")
    return { path: temporaryPath, cleanup }
  } catch (error) {
    await cleanup().catch(() => undefined)
    throw error
  }
}
