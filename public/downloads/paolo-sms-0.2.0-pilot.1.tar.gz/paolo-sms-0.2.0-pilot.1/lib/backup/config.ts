import path from "node:path"

export type BackupEngine = "pg_dump" | "paolo_data"

export function getBackupEngine(): BackupEngine {
  const value = process.env.BACKUP_ENGINE?.trim() || "pg_dump"
  if (value !== "pg_dump" && value !== "paolo_data") {
    throw new Error("BACKUP_ENGINE muss pg_dump oder paolo_data sein.")
  }
  return value
}

export function getBackupDir(): string {
  const configured = process.env.BACKUP_DIR?.trim()
  return configured ? path.resolve(configured) : path.resolve(process.cwd(), "backups")
}

export function getPgDumpPath(): string {
  return process.env.PG_DUMP_PATH?.trim() || "pg_dump"
}

export function getPgRestorePath(): string {
  return process.env.PG_RESTORE_PATH?.trim() || "pg_restore"
}

export function getAgePath(): string {
  return process.env.AGE_PATH?.trim() || "age"
}

function positiveIntegerEnvironment(name: string, fallback: number): number {
  const raw = process.env[name]?.trim()
  if (!raw) return fallback
  if (!/^\d+$/.test(raw)) throw new Error(`${name} muss eine positive ganze Zahl sein.`)
  const value = Number(raw)
  if (!Number.isSafeInteger(value) || value < 1) {
    throw new Error(`${name} muss eine positive ganze Zahl sein.`)
  }
  return value
}

function nonNegativeIntegerEnvironment(name: string, fallback: number): number {
  const raw = process.env[name]?.trim()
  if (!raw) return fallback
  if (!/^\d+$/.test(raw)) throw new Error(`${name} muss eine nichtnegative ganze Zahl sein.`)
  const value = Number(raw)
  if (!Number.isSafeInteger(value)) {
    throw new Error(`${name} muss eine nichtnegative ganze Zahl sein.`)
  }
  return value
}

export function getBackupCronSecret(): string {
  const secret = process.env.BACKUP_CRON_SECRET?.trim() ?? ""
  if (secret.length < 32) {
    throw new Error("BACKUP_CRON_SECRET muss mindestens 32 Zeichen lang sein.")
  }
  return secret
}

export function getBackupCronMinIntervalMinutes(): number {
  return positiveIntegerEnvironment("BACKUP_CRON_MIN_INTERVAL_MINUTES", 1_440)
}

export function getBackupCronMaxRuntimeMinutes(): number {
  return positiveIntegerEnvironment("BACKUP_CRON_MAX_RUNTIME_MINUTES", 120)
}

export function getBackupRetentionPolicy(): {
  dailyDays: number
  weeklyWeeks: number
  monthlyMonths: number
} {
  return {
    dailyDays: nonNegativeIntegerEnvironment("BACKUP_RETENTION_DAILY_DAYS", 14),
    weeklyWeeks: nonNegativeIntegerEnvironment("BACKUP_RETENTION_WEEKLY_WEEKS", 8),
    monthlyMonths: nonNegativeIntegerEnvironment("BACKUP_RETENTION_MONTHLY_MONTHS", 12),
  }
}

export function isBackupRetentionEnabled(): boolean {
  const raw = process.env.BACKUP_RETENTION_ENABLED?.trim().toLowerCase()
  if (!raw) return true
  if (raw === "true") return true
  if (raw === "false") return false
  throw new Error("BACKUP_RETENTION_ENABLED muss true oder false sein.")
}

export function getAgeRecipients(): string[] {
  const recipients = (process.env.BACKUP_AGE_RECIPIENTS ?? "")
    .split(",")
    .map((value) => value.trim())
    .filter(Boolean)
  if (recipients.length === 0) throw new Error("BACKUP_AGE_RECIPIENTS muss mindestens einen öffentlichen Empfänger enthalten.")
  return [...new Set(recipients)]
}

export function getDatabaseUrl(): URL {
  const value = process.env.DATABASE_URL?.trim()
  if (!value) throw new Error("DATABASE_URL ist nicht gesetzt.")
  const url = new URL(value)
  if (url.protocol !== "postgres:" && url.protocol !== "postgresql:") {
    throw new Error("DATABASE_URL ist keine PostgreSQL-URL.")
  }
  return url
}

export function databaseDisplayTarget(url = getDatabaseUrl()): { host: string; database: string } {
  return {
    host: url.port ? `${url.hostname}:${url.port}` : url.hostname,
    database: decodeURIComponent(url.pathname.replace(/^\//, "")),
  }
}

export function postgresProcessEnv(url = getDatabaseUrl()): NodeJS.ProcessEnv {
  const env: NodeJS.ProcessEnv = { ...process.env }
  env.PGHOST = url.hostname
  env.PGPORT = url.port || "5432"
  env.PGDATABASE = decodeURIComponent(url.pathname.replace(/^\//, ""))
  env.PGUSER = decodeURIComponent(url.username)
  env.PGPASSWORD = decodeURIComponent(url.password)
  const sslmode = url.searchParams.get("sslmode")
  if (sslmode) env.PGSSLMODE = sslmode
  delete env.DATABASE_URL
  return env
}
