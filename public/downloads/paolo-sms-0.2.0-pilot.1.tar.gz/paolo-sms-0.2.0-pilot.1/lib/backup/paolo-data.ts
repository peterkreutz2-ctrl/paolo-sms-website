import { createReadStream, createWriteStream } from "node:fs"
import { createGunzip, createGzip } from "node:zlib"
import { once } from "node:events"
import { createInterface } from "node:readline"
import type { Pool, PoolClient } from "pg"

import {
  PAOLO_DATA_FORMAT,
  PAOLO_DATA_TABLES,
  PAOLO_SCHEMA_VERSION,
  isPaoloDataTable,
  type PaoloDataTable,
} from "./constants"

type ArchiveHeader = { type: "header"; format: typeof PAOLO_DATA_FORMAT; schemaVersion: string }
type ArchiveTable = { type: "table"; table: PaoloDataTable }
type ArchiveRow = { type: "row"; table: PaoloDataTable; data: Record<string, unknown> }
type ArchiveTableEnd = { type: "table_end"; table: PaoloDataTable; rowCount: number }
type ArchiveFooter = { type: "footer"; rowCounts: Record<string, number> }

async function writeLine(stream: NodeJS.WritableStream, value: unknown): Promise<void> {
  if (!stream.write(`${JSON.stringify(value)}\n`)) await once(stream, "drain")
}

export async function exportPaoloData(pool: Pool, destination: string): Promise<Record<string, number>> {
  const client = await pool.connect()
  const output = createWriteStream(destination, { flags: "wx", mode: 0o600 })
  const gzip = createGzip({ level: 6 })
  gzip.pipe(output)
  const completion = new Promise<void>((resolve, reject) => {
    output.once("finish", resolve)
    output.once("error", reject)
    gzip.once("error", reject)
  })

  try {
    await client.query("BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
    await writeLine(gzip, { type: "header", format: PAOLO_DATA_FORMAT, schemaVersion: PAOLO_SCHEMA_VERSION } satisfies ArchiveHeader)
    const rowCounts: Record<string, number> = {}

    for (const [index, table] of PAOLO_DATA_TABLES.entries()) {
      await writeLine(gzip, { type: "table", table } satisfies ArchiveTable)
      const cursor = `paolo_backup_${index}`
      await client.query(`DECLARE ${cursor} NO SCROLL CURSOR FOR SELECT row_to_json(t) AS data FROM "${table}" t`)
      let count = 0
      while (true) {
        const result = await client.query<{ data: Record<string, unknown> }>(`FETCH FORWARD 250 FROM ${cursor}`)
        if (result.rows.length === 0) break
        for (const row of result.rows) {
          await writeLine(gzip, { type: "row", table, data: row.data } satisfies ArchiveRow)
          count++
        }
      }
      await client.query(`CLOSE ${cursor}`)
      rowCounts[table] = count
      await writeLine(gzip, { type: "table_end", table, rowCount: count } satisfies ArchiveTableEnd)
    }
    await writeLine(gzip, { type: "footer", rowCounts } satisfies ArchiveFooter)
    await client.query("COMMIT")
    gzip.end()
    await completion
    return rowCounts
  } catch (error) {
    await client.query("ROLLBACK").catch(() => undefined)
    gzip.destroy()
    output.destroy()
    throw error
  } finally {
    client.release()
  }
}

const BASELINE_ROLE_KEYS = new Set(["admin", "safety_manager", "instructor", "member"])

export async function assertEmptyPaoloDatabase(client: PoolClient): Promise<void> {
  for (const table of PAOLO_DATA_TABLES) {
    if (table === "roles") continue
    const result = await client.query<{ count: string }>(`SELECT count(*)::text AS count FROM "${table}"`)
    if (Number(result.rows[0]?.count ?? 0) !== 0) throw new Error(`Zieldatenbank ist nicht leer (Tabelle ${table}).`)
  }
  const roleRows = await client.query<{ key: string }>("SELECT key FROM roles")
  if (roleRows.rows.some((row) => !BASELINE_ROLE_KEYS.has(row.key))) {
    throw new Error("Zieldatenbank enthält nicht erwartete Rollen und gilt nicht als leer.")
  }
}

function parseArchiveLine(line: string): Record<string, unknown> {
  const value: unknown = JSON.parse(line)
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("Ungültiger Archiv-Datensatz.")
  return value as Record<string, unknown>
}

async function insertBatch(client: PoolClient, table: PaoloDataTable, rows: Record<string, unknown>[]): Promise<void> {
  if (rows.length === 0) return
  await client.query(
    `INSERT INTO "${table}" SELECT * FROM json_populate_recordset(NULL::"${table}", $1::json)`,
    [JSON.stringify(rows)],
  )
}

export async function importPaoloData(pool: Pool, source: string, expectedSchemaVersion: string): Promise<Record<string, number>> {
  const client = await pool.connect()
  const lines = createInterface({ input: createReadStream(source).pipe(createGunzip()), crlfDelay: Infinity })
  let headerSeen = false
  let footerSeen = false
  let expectedIndex = 0
  let currentTable: PaoloDataTable | null = null
  let batch: Record<string, unknown>[] = []
  const rowCounts: Record<string, number> = {}

  await client.query("BEGIN")
  try {
    await assertEmptyPaoloDatabase(client)
    for await (const line of lines) {
      if (!line.trim()) continue
      if (footerSeen) throw new Error("Archiv enthält Daten nach dem Footer.")
      const entry = parseArchiveLine(line)
      if (!headerSeen) {
        if (entry.type !== "header" || entry.format !== PAOLO_DATA_FORMAT) throw new Error("Nicht unterstütztes PAOLO-Datenarchiv.")
        if (entry.schemaVersion !== expectedSchemaVersion) throw new Error("Schema-/Migrationsversion des Archivs ist nicht kompatibel.")
        headerSeen = true
        continue
      }
      if (entry.type === "table") {
        if (currentTable || typeof entry.table !== "string" || !isPaoloDataTable(entry.table)) throw new Error("Ungültiger Tabellenabschnitt im Archiv.")
        if (entry.table !== PAOLO_DATA_TABLES[expectedIndex]) throw new Error("Tabellenreihenfolge im Archiv ist ungültig.")
        currentTable = entry.table
        rowCounts[currentTable] = 0
        if (currentTable === "roles") await client.query("DELETE FROM roles")
        continue
      }
      if (entry.type === "row") {
        if (!currentTable || entry.table !== currentTable || !entry.data || typeof entry.data !== "object" || Array.isArray(entry.data)) {
          throw new Error("Ungültiger Zeilendatensatz im Archiv.")
        }
        batch.push(entry.data as Record<string, unknown>)
        rowCounts[currentTable]++
        if (batch.length >= 250) { await insertBatch(client, currentTable, batch); batch = [] }
        continue
      }
      if (entry.type === "table_end") {
        if (!currentTable || entry.table !== currentTable || entry.rowCount !== rowCounts[currentTable]) throw new Error("Zeilenanzahl im Tabellenabschnitt stimmt nicht.")
        await insertBatch(client, currentTable, batch)
        batch = []
        currentTable = null
        expectedIndex++
        continue
      }
      if (entry.type === "footer") {
        if (currentTable || expectedIndex !== PAOLO_DATA_TABLES.length || !entry.rowCounts || typeof entry.rowCounts !== "object") throw new Error("Archiv-Footer ist ungültig.")
        const footerCounts = entry.rowCounts as Record<string, unknown>
        const footerNames = Object.keys(footerCounts)
        if (footerNames.some((name) => !isPaoloDataTable(name)) || footerNames.length !== PAOLO_DATA_TABLES.length) throw new Error("Archiv-Footer enthält ungültige Tabellen.")
        for (const table of PAOLO_DATA_TABLES) if (footerCounts[table] !== rowCounts[table]) throw new Error(`Zeilenanzahl für ${table} stimmt nicht.`)
        footerSeen = true
        continue
      }
      throw new Error("Unbekannter Datensatztyp im Archiv.")
    }
    if (!headerSeen || !footerSeen) throw new Error("Archiv ist unvollständig.")
    await client.query("COMMIT")
    return rowCounts
  } catch (error) {
    await client.query("ROLLBACK").catch(() => undefined)
    throw error
  } finally {
    lines.close()
    client.release()
  }
}
