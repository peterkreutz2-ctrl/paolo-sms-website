import { createHash } from "node:crypto"
import { createReadStream } from "node:fs"
import { mkdir, open, readFile, rename, rm, stat, writeFile } from "node:fs/promises"
import path from "node:path"

import { getBackupDir } from "./config"
import { parseBackupManifest, type BackupManifest } from "./manifest"
import { validateBackupId } from "./security"

export function manifestFileName(id: string): string { return `${validateBackupId(id)}.manifest.json` }
export function manifestPath(id: string): string { return path.join(getBackupDir(), manifestFileName(id)) }

export function dataPathFromManifest(manifest: BackupManifest): string {
  validateBackupId(manifest.backupId)
  const expected = manifest.engine === "pg_dump"
    ? `${manifest.backupId}.dump`
    : `${manifest.backupId}.paolo.jsonl.gz`
  const finalName = `${expected}.age`
  if (manifest.databaseFileName !== finalName) throw new Error("Manifest enthält einen ungültigen Dateinamen.")
  return path.join(getBackupDir(), finalName)
}

export async function sha256File(filePath: string): Promise<string> {
  const hash = createHash("sha256")
  for await (const chunk of createReadStream(filePath)) hash.update(chunk as Buffer)
  return hash.digest("hex")
}

export async function loadValidBackup(id: string, verifyChecksum = false): Promise<{ manifest: BackupManifest; dataPath: string }> {
  const safeId = validateBackupId(id)
  const raw = await readFile(manifestPath(safeId), "utf8")
  const manifest = parseBackupManifest(JSON.parse(raw))
  if (manifest.backupId !== safeId) throw new Error("Backup-ID und Manifest stimmen nicht überein.")
  const dataPath = dataPathFromManifest(manifest)
  const fileStat = await stat(dataPath)
  if (!fileStat.isFile() || fileStat.size !== manifest.fileSize) throw new Error("Backup-Dateigröße stimmt nicht mit dem Manifest überein.")
  if (verifyChecksum && await sha256File(dataPath) !== manifest.sha256) throw new Error("SHA-256-Prüfsumme stimmt nicht überein.")
  return { manifest, dataPath }
}

export async function listValidBackups(): Promise<BackupManifest[]> {
  const dir = getBackupDir()
  await mkdir(dir, { recursive: true })
  const { readdir } = await import("node:fs/promises")
  const names = await readdir(dir)
  const results: BackupManifest[] = []
  for (const name of names) {
    const match = /^([0-9a-f-]{36})\.manifest\.json$/i.exec(name)
    if (!match) continue
    try { results.push((await loadValidBackup(match[1])).manifest) } catch { /* incomplete or invalid backups are intentionally hidden */ }
  }
  return results.sort((a, b) => b.createdAt.localeCompare(a.createdAt))
}

export async function withBackupLock<T>(task: () => Promise<T>): Promise<T> {
  const dir = getBackupDir()
  await mkdir(dir, { recursive: true })
  const lockPath = path.join(dir, ".backup.lock")
  let handle
  try {
    handle = await open(lockPath, "wx", 0o600)
    await handle.writeFile(`${process.pid}\n${new Date().toISOString()}\n`)
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "EEXIST") throw new Error("Es wird bereits ein Backup erstellt.")
    throw error
  }
  try { return await task() } finally { await handle.close(); await rm(lockPath, { force: true }) }
}

export async function publishManifest(tempPath: string, manifest: BackupManifest): Promise<void> {
  await writeFile(tempPath, `${JSON.stringify(manifest, null, 2)}\n`, { encoding: "utf8", mode: 0o600 })
  await rename(tempPath, manifestPath(manifest.backupId))
}
