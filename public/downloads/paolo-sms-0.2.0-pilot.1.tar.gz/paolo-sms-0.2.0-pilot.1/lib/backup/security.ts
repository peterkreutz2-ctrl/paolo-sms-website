import { BACKUP_ID_PATTERN } from "./constants"
import { hasAdminRole, isAppRoleKey } from "../constants/roles"

export function validateBackupId(value: string): string {
  if (!BACKUP_ID_PATTERN.test(value)) throw new Error("Ungültige Backup-ID.")
  return value.toLowerCase()
}

/**
 * Backup-seitiger Zugang. Leitet sich seit #44 aus hasAdminRole ab, statt die
 * Rollenliste ein zweites Mal zu buchstabieren. Die eigene Funktion bleibt,
 * weil sie mit `readonly string[]` arbeitet: Die Backup-Kette liest ueber
 * getCurrentUserGlobalRoles und kennt den engeren AppRoleKey-Typ nicht.
 */
export function isGlobalAdmin(roleKeys: readonly string[]): boolean {
  return hasAdminRole(roleKeys.filter(isAppRoleKey))
}

export function requireRestoreConfirmation(database: string, confirmation: string | undefined): void {
  if (!database || confirmation !== `RESTORE:${database}`) {
    throw new Error(`Bestätigung fehlt oder ist falsch. Erwartet: --confirm=RESTORE:${database}`)
  }
}

