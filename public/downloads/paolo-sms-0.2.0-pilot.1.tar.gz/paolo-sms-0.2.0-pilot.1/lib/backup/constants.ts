export const BACKUP_FORMAT_VERSION = 2 as const
export const PAOLO_DATA_FORMAT = "paolo-data-ndjson-gzip" as const
export const PG_DUMP_FORMAT = "postgresql-custom" as const
export const PAOLO_SCHEMA_VERSION = "0024" as const

export const BACKUP_ID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i

// Explicit dependency order. These names are constants owned by the application;
// archive input is never interpolated into SQL unless it matches this allowlist.
export const PAOLO_DATA_TABLES = [
  "organizations",
  "roles",
  "better_auth_users",
  "reports",
  "organization_legal_settings",
  "safety_meetings",
  "privacy_incidents",
  "sms_documents",
  "user_roles",
  "better_auth_accounts",
  "better_auth_sessions",
  "better_auth_verifications",
  "measures",
  "attachments",
  "report_notes",
  "audit_logs",
] as const

export type PaoloDataTable = (typeof PAOLO_DATA_TABLES)[number]

export function isPaoloDataTable(value: string): value is PaoloDataTable {
  return (PAOLO_DATA_TABLES as readonly string[]).includes(value)
}
