import { createHash } from "node:crypto"

import {
  resolvePrivacyConsentText,
  toDisplayedPrivacyConsentText,
} from "@/lib/constants/public-report-privacy-consent"
import {
  buildEffectivePrivacyPolicy,
  renderPrivacyPolicySnapshot,
} from "@/lib/privacy-policy"

// Einwilligungszustand einer Organisation, wie er im Moment gilt (#101).
//
// Rein und ohne Datenbankzugriff, damit er sich ohne Datenbank pruefen laesst.
// Das Laden uebernimmt lib/queries/public-report-privacy-consent.ts.

export type PublicReportPrivacyConsentState = {
  enabled: boolean
  /** Konfigurierter Text mit Marker — fuer die Darstellung im Formular. */
  consentText: string
  /** Text, wie der Melder ihn liest — fuer den Snapshot an der Meldung. */
  displayedConsentText: string
  /** Wirksame Datenschutzerklaerung, wie /datenschutz sie zeigt. */
  privacyPolicySnapshot: string
  /**
   * Fingerabdruck dessen, was fuer die Einreichung zaehlt. Das Formular
   * bekommt ihn beim Laden und schickt ihn zurueck; weicht er beim Absenden
   * vom neu berechneten ab, hat der Melder einen anderen Stand gesehen.
   */
  fingerprint: string
}

type OrganizationInput = {
  publicReportPrivacyConsentEnabled: boolean
  publicReportPrivacyConsentText: string | null
}

type LegalSettingsInput = Parameters<typeof buildEffectivePrivacyPolicy>[0]

/**
 * Bei ausgeschalteter Funktion zaehlt nur der Schalter selbst: Text und
 * Datenschutzerklaerung spielen fuer die Einreichung dann keine Rolle, und
 * eine Aenderung daran soll keine Meldung ohne Einwilligungsabfrage abweisen.
 * Ein Wechsel des Schalters aendert den Fingerabdruck in jedem Fall.
 */
export function computePrivacyConsentFingerprint(input: {
  enabled: boolean
  consentText: string
  privacyPolicySnapshot: string
}): string {
  const material = input.enabled
    ? ["v1", true, input.consentText, input.privacyPolicySnapshot]
    : ["v1", false]
  return createHash("sha256").update(JSON.stringify(material)).digest("hex")
}

export function buildPublicReportPrivacyConsentState(
  organization: OrganizationInput,
  legal: LegalSettingsInput
): PublicReportPrivacyConsentState {
  const enabled = organization.publicReportPrivacyConsentEnabled
  const consentText = resolvePrivacyConsentText(
    organization.publicReportPrivacyConsentText
  )
  const privacyPolicySnapshot = renderPrivacyPolicySnapshot(
    buildEffectivePrivacyPolicy(legal)
  )

  return {
    enabled,
    consentText,
    displayedConsentText: toDisplayedPrivacyConsentText(consentText),
    privacyPolicySnapshot,
    fingerprint: computePrivacyConsentFingerprint({
      enabled,
      consentText,
      privacyPolicySnapshot,
    }),
  }
}
