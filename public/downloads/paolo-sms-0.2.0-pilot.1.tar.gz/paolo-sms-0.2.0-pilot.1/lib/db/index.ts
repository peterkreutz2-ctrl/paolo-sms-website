import { config } from "dotenv"

config({ path: ".env.local" })

import { Pool } from "pg"
import { drizzle } from "drizzle-orm/node-postgres"

import * as schema from "./schema"

const connectionString = process.env.DATABASE_URL
const allowSelfSignedCertificate =
  process.env.DATABASE_SSL_ALLOW_SELF_SIGNED === "true"

// Verständlicher Fehler bei fehlender Konfiguration. Während des Next.js-
// Production-Builds (der ohne Env laufen kann, z. B. im Docker-Build) wird der
// Import nicht gesprengt; zur Laufzeit fehlt die Verbindung dann hart und klar.
if (!connectionString && process.env.NEXT_PHASE !== "phase-production-build") {
  throw new Error(
    "DATABASE_URL ist nicht gesetzt. Bitte in .env.local bzw. in der Container-Umgebung setzen."
  )
}

// pg parses TLS parameters from connectionString after the other Pool options,
// so an URL-level sslmode would overwrite ssl.rejectUnauthorized below. Use
// pg's explicit no-verify mode only for the development opt-in.
const poolConnectionString = connectionString
  ? (() => {
      if (!allowSelfSignedCertificate) return connectionString

      const url = new URL(connectionString)
      url.searchParams.set("sslmode", "no-verify")
      return url.toString()
    })()
  : connectionString

const globalForPool = globalThis as unknown as {
  smsMvpDbPool?: Pool
}

const pool =
  globalForPool.smsMvpDbPool ??
  new Pool({
    connectionString: poolConnectionString,
    // Pragmatisches Pooling für kleine Instanzen (1-20 Nutzer, 0-5 gleichzeitig).
    max: 10,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 10_000,
  })

if (process.env.NODE_ENV !== "production") {
  globalForPool.smsMvpDbPool = pool
}

export const db = drizzle(pool, { schema })
export const dbPool = pool
