import type { AppRoleKey } from "@/lib/constants/roles"
import { hasAdminRole, hasSafetyEditRole } from "@/lib/constants/roles"

import { GENERATED_HELP_DOCUMENTS } from "./help-content.generated"

export type HelpDocument = {
  key: string
  title: string
  markdown: string
}

export const HELP_DOCUMENTS: readonly HelpDocument[] = GENERATED_HELP_DOCUMENTS

function documentByKey(key: string): HelpDocument {
  const found = HELP_DOCUMENTS.find((doc) => doc.key === key)
  // Der Guard-Test stellt sicher, dass jeder hier verwendete Schlüssel
  // existiert. Bliebe er trotzdem einmal leer, ist eine leere Hilfeseite die
  // harmlosere Antwort als ein Absturz der Seite.
  return found ?? { key, title: "Hilfe", markdown: "" }
}

/**
 * Welche Anleitung eine Rollenmenge sieht.
 *
 * Hier steht bewusst **kein** eigenes Berechtigungsprädikat: Wer die Seite
 * öffnen darf, entscheidet `hasReportReadRole` an der Seite selbst — dieselbe
 * Schwelle wie im übrigen internen Bereich. Ein `canSeeHelp` neben den
 * Prädikaten aus `lib/constants/roles.ts` wäre eine zweite Stelle mit einer
 * Rollenaussage, und genau die hat #44 abgeschafft.
 *
 * Die Reihenfolge ist absteigend nach Umfang: Wer mehrere Rollen trägt — im
 * MVP nicht vorgesehen, aber technisch möglich —, bekommt die weiteste
 * Anleitung. Sie enthält die Aufgaben der engeren mit.
 *
 * Die Zuordnung ist **Anzeige, keine Berechtigung**: Sie entscheidet, welcher
 * Text erscheint, nicht worauf jemand zugreifen darf.
 */
export function resolveHelpDocument(roleKeys: readonly AppRoleKey[]): HelpDocument {
  if (hasAdminRole(roleKeys)) return documentByKey("admin")
  if (hasSafetyEditRole(roleKeys)) return documentByKey("safety-manager")
  return documentByKey("instructor")
}

// ─── Nachschlagedokumente ────────────────────────────────────────────────────
//
// Die Rollenanleitungen verweisen auf die Berechtigungsmatrix und einige
// weitere Unterlagen. Diese liegen als erzeugte Kopie im selben Modul und
// werden unter /dashboard/hilfe/<schluessel> angezeigt.
//
// Hier steht — wie bei resolveHelpDocument — bewusst KEIN eigenes
// Berechtigungspraedikat. Wer die Hilfe oeffnen darf, entscheidet die Seite
// mit `hasReportReadRole`; die Nachschlageseite verwendet dieselbe Schwelle.

/** Schluessel der Dokumente, die als eigene Seite erreichbar sind. */
export const HELP_REFERENCE_KEYS = [
  "glossar",
  "permission-matrix",
  "role-responsibilities",
  "privacy-operations",
  "backup-restore",
] as const

export type HelpReferenceKey = (typeof HELP_REFERENCE_KEYS)[number]

export function isHelpReferenceKey(value: string): value is HelpReferenceKey {
  return (HELP_REFERENCE_KEYS as readonly string[]).includes(value)
}

/**
 * Ein Nachschlagedokument — oder `null`, wenn der Schluessel nicht dazu
 * gehoert. Die Route macht daraus ein 404; ein erfundener Schluessel darf
 * keine leere Seite erzeugen.
 */
export function findHelpReference(key: string): HelpDocument | null {
  if (!isHelpReferenceKey(key)) return null
  return HELP_DOCUMENTS.find((doc) => doc.key === key) ?? null
}

/** Die Nachschlagedokumente in der Reihenfolge der Auslieferung. */
export function listHelpReferences(): HelpDocument[] {
  return HELP_REFERENCE_KEYS.flatMap((key) => {
    const found = HELP_DOCUMENTS.find((doc) => doc.key === key)
    return found ? [found] : []
  })
}
