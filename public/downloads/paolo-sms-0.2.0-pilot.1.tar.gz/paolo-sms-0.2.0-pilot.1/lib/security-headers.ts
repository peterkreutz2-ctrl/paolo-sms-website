// Sicherheitsheader fuer den Vercel-Pfad (#107).
//
// Die Policy steht in der Nginx-Vorlage deploy/nginx/conf.d/paolo-https.conf.disabled
// und gilt dort fuer den Docker-Pfad. Auf Vercel greift die Vorlage nicht;
// next.config.ts liefert deshalb dieselben Werte aus — nur dort, denn hinter
// Nginx kaemen sie sonst doppelt an (add_header haengt an, statt zu ersetzen).
//
// tests/security/security-headers.test.ts vergleicht diese Werte mit der
// Vorlage: Aendert sich dort ein Wert oder kommt ein Header hinzu, schlaegt er
// fehl.

/** Auf Vercel von der Anwendung gesetzt, Werte wortgleich zur Nginx-Vorlage. */
export const SECURITY_HEADERS: ReadonlyArray<{ key: string; value: string }> = [
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
  { key: "X-Frame-Options", value: "SAMEORIGIN" },
]

/**
 * Header der Nginx-Vorlage, die auf Vercel bewusst NICHT von der Anwendung
 * kommen. HSTS setzt die Plattform selbst, und zwar strenger als die Vorlage
 * (max-age=63072000; includeSubDomains; preload statt max-age=31536000;
 * includeSubDomains). Ein zweiter, schwaecherer Header der Anwendung waere
 * bestenfalls wirkungslos — bei mehreren HSTS-Headern wertet der Browser nur
 * den ersten aus.
 */
export const PLATFORM_PROVIDED_HEADERS: Readonly<Record<string, string>> = {
  "Strict-Transport-Security":
    "Setzt Vercel auf jeder HTTPS-Antwort selbst, strenger als die Nginx-Vorlage.",
}

/** Ob die Anwendung die Header selbst ausliefern soll: nur auf Vercel. */
export function servesSecurityHeadersFromApp(env: Record<string, string | undefined> = process.env): boolean {
  return env.VERCEL === "1"
}
