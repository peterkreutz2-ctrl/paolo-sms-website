// Veroeffentlichte Demo-Konten. Einzige Quelle fuer die Anmeldeseite der Demo
// (components/demo-credentials.tsx) und den Neuaufbau (scripts/demo).
//
// Es gibt bewusst kein Administratorkonto: Die Demo hat keine Person, die sie
// verwaltet; der Neuaufbau stellt den Ausgangszustand her. Die Adressen liegen
// unter .example (RFC 2606) und erreichen niemanden — die Anwendung versendet
// ohnehin keine E-Mails.

import type { AppRoleKey } from "@/lib/constants/roles"

export const DEMO_PASSWORD = "PAOLO-Demo-Zugang"

export type DemoAccount = {
  email: string
  name: string
  role: Extract<AppRoleKey, "safety_manager" | "member">
}

export const DEMO_ACCOUNTS: readonly DemoAccount[] = [
  {
    email: "safety-manager@demo.paolo-sms.example",
    name: "Demo Safety Manager",
    role: "safety_manager",
  },
  {
    email: "benutzer@demo.paolo-sms.example",
    name: "Demo Benutzer",
    role: "member",
  },
]
