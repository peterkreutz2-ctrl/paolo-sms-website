// Demo-Betriebsart einer Installation (DEMO_MODE).
//
// Die oeffentliche Demo-Installation ist eine gewoehnliche PAOLO-Installation
// mit eigener Datenbank, bei der DEMO_MODE=true gesetzt ist. Der Schalter hat
// genau drei Wirkungen und sonst keine:
//
//   1. Server Actions, die Inhalte oeffentlich machen, Konten oder Rechte
//      veraendern, Dateien annehmen oder Daten aus der Installation hinaus- bzw.
//      hineinschaffen, antworten mit einer Sperrmeldung (siehe DEMO_BLOCKED_ACTIONS).
//   2. Jede Seite zeigt einen Demo-Hinweis (components/demo-banner.tsx).
//   3. Die Seiten sind fuer Suchmaschinen gesperrt.
//
// Ohne DEMO_MODE aendert sich nichts: isDemoMode() ist false und jeder Aufrufer
// verhaelt sich wie vorher. Die Sperren stehen bewusst in den Actions selbst und
// nicht in Middleware oder Oberflaeche: Eine Server Action ist ein POST gegen
// die Seitenroute und laesst sich ohne Oberflaeche aufrufen.
//
// Diese Datei bleibt frei von Abhaengigkeiten (kein "server-only", kein DB- und
// kein Auth-Import), damit Tests sie ohne Next.js laden koennen.

const TRUTHY = new Set(["1", "true", "yes", "on"])
const FALSY = new Set(["", "0", "false", "no", "off"])

/**
 * Wertet DEMO_MODE aus. Ein unbekannter Wert ist ein Fehler und kein stilles
 * "aus": Eine Demo, deren Sperren wegen eines Tippfehlers fehlen, waere die
 * gefaehrliche Richtung.
 */
export function parseDemoMode(raw: string | undefined): boolean {
  const value = (raw ?? "").trim().toLowerCase()
  if (TRUTHY.has(value)) return true
  if (FALSY.has(value)) return false
  throw new Error(
    `Ungueltiger Wert fuer DEMO_MODE: "${raw}". Erlaubt: true oder false.`
  )
}

/**
 * Ist diese Installation eine Demo?
 *
 * Die Demo laeuft ausschliesslich mit Better Auth: Ihre Konten sind
 * veroeffentlichte Zugangsdaten in der eigenen Datenbank. Bei Clerk oder im
 * Datei-Modus waere DEMO_MODE eine Fehlkonfiguration, und die Anwendung
 * verweigert den Betrieb, statt eine halbe Demo zu zeigen.
 */
export function isDemoMode(): boolean {
  const demo = parseDemoMode(process.env.DEMO_MODE)
  if (demo && (process.env.AUTH_MODE ?? "clerk") !== "betterauth") {
    throw new Error("DEMO_MODE=true setzt AUTH_MODE=betterauth voraus.")
  }
  return demo
}

export type DemoBlockKind = "generic" | "publication" | "accounts" | "uploads"

export const DEMO_BLOCKED_MESSAGES: Record<DemoBlockKind, string> = {
  generic:
    "In der Demo-Installation gesperrt: Diese Funktion steht hier nicht zur Verfügung.",
  publication:
    "In der Demo-Installation gesperrt: Öffentliche Inhalte können hier weder angelegt noch geändert oder gelöscht werden.",
  accounts:
    "In der Demo-Installation gesperrt: Konten und Rollen können hier nicht verwaltet werden.",
  uploads:
    "In der Demo-Installation gesperrt: Dateien können hier nicht hochgeladen werden.",
}

/** Antwort einer gesperrten Server Action; passt zu allen Action-Zustaenden. */
export function demoBlockedResult(
  kind: DemoBlockKind = "generic"
): { success: false; message: string } {
  return { success: false, message: DEMO_BLOCKED_MESSAGES[kind] }
}

/** Zeitpunkt des taeglichen Neuaufbaus, wie ihn der Hinweis nennt. */
export const DEMO_RESET_TIME_LABEL = "03:00 Uhr (Europe/Berlin)"

export const DEMO_BANNER_TEXT =
  `Demo-Installation: Alle Daten sind erfundene Spieldaten. Die Installation wird täglich um ${DEMO_RESET_TIME_LABEL} zurückgesetzt, eingegebene Daten gehen dabei verloren. Bitte keine echten Daten eingeben.`
