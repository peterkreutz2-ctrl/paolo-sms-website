import { createHmac } from "node:crypto"
import { isIP } from "node:net"

export const PUBLIC_REPORT_RATE_LIMIT_SCOPE = "public_report_create"
export const PUBLIC_REPORT_RATE_LIMIT_WINDOW_SECONDS = 3_600
export const PUBLIC_REPORT_RATE_LIMIT_DEFAULT_MAX_ACCEPTED = 5
export const PUBLIC_REPORT_RATE_LIMIT_MAX_CONFIGURED_ACCEPTED = 10_000
export const PUBLIC_REPORT_RATE_LIMIT_DEFAULT_RETENTION_DAYS = 1
export const PUBLIC_REPORT_RATE_LIMIT_MAX_RETENTION_DAYS = 365
export const PUBLIC_REPORT_RATE_LIMIT_CLEANUP_BATCH_SIZE = 1_000

export type PublicReportRateLimitBlockedLog = {
  organizationId: string
  scope: typeof PUBLIC_REPORT_RATE_LIMIT_SCOPE
  maxAccepted: number
  windowDurationSeconds: number
  reason: "accepted_limit_reached"
}

export function createPublicReportRateLimitBlockedLog(
  blockedCount: number,
  organizationId: string,
  maxAccepted: number
): PublicReportRateLimitBlockedLog | null {
  if (blockedCount !== 0) return null

  return {
    organizationId,
    scope: PUBLIC_REPORT_RATE_LIMIT_SCOPE,
    maxAccepted,
    windowDurationSeconds: PUBLIC_REPORT_RATE_LIMIT_WINDOW_SECONDS,
    reason: "accepted_limit_reached",
  }
}

export function getPublicReportRateLimitRetentionDays(
  configuredValue = process.env.PUBLIC_REPORT_RATE_LIMIT_RETENTION_DAYS
): number {
  const normalized = configuredValue?.trim()
  if (!normalized || !/^\d+$/.test(normalized)) {
    return PUBLIC_REPORT_RATE_LIMIT_DEFAULT_RETENTION_DAYS
  }

  const parsed = Number(normalized)
  if (
    !Number.isSafeInteger(parsed) ||
    parsed < 1 ||
    parsed > PUBLIC_REPORT_RATE_LIMIT_MAX_RETENTION_DAYS
  ) {
    return PUBLIC_REPORT_RATE_LIMIT_DEFAULT_RETENTION_DAYS
  }

  return parsed
}

export function getPublicReportRateLimitMaxAccepted(
  configuredValue = process.env.PUBLIC_REPORT_RATE_LIMIT_MAX_ACCEPTED
): number {
  const normalized = configuredValue?.trim()
  if (!normalized || !/^\d+$/.test(normalized)) {
    return PUBLIC_REPORT_RATE_LIMIT_DEFAULT_MAX_ACCEPTED
  }

  const parsed = Number(normalized)
  if (
    !Number.isSafeInteger(parsed) ||
    parsed < 1 ||
    parsed > PUBLIC_REPORT_RATE_LIMIT_MAX_CONFIGURED_ACCEPTED
  ) {
    return PUBLIC_REPORT_RATE_LIMIT_DEFAULT_MAX_ACCEPTED
  }

  return parsed
}

function normalizeIpv6Part(part: string): string {
  const lower = part.toLowerCase()
  const withoutLeadingZeros = lower.replace(/^0+/, "")
  return withoutLeadingZeros || "0"
}

function expandIpv6(address: string): string[] {
  const [left, right] = address.split("::")
  const leftParts = left ? left.split(":") : []
  const rightParts = right ? right.split(":") : []
  const missing = 8 - (leftParts.length + rightParts.length)
  return [...leftParts, ...Array.from({ length: missing }, () => "0"), ...rightParts].map((part) =>
    normalizeIpv6Part(part)
  )
}

function compressIpv6(address: string): string {
  const parts = expandIpv6(address)
  const longestRun = { start: -1, length: 0 }
  let currentStart = -1
  let currentLength = 0

  for (let index = 0; index < parts.length; index += 1) {
    if (parts[index] === "0") {
      if (currentStart === -1) {
        currentStart = index
      }
      currentLength += 1
    } else {
      if (currentLength > longestRun.length) {
        longestRun.start = currentStart
        longestRun.length = currentLength
      }
      currentStart = -1
      currentLength = 0
    }
  }

  if (currentLength > longestRun.length) {
    longestRun.start = currentStart
    longestRun.length = currentLength
  }

  if (longestRun.length < 2) {
    return parts.join(":")
  }

  const prefix = parts.slice(0, longestRun.start).join(":")
  const suffix = parts.slice(longestRun.start + longestRun.length).join(":")

  if (!prefix && !suffix) return "::"
  if (!prefix) return `::${suffix}`
  if (!suffix) return `${prefix}::`
  return `${prefix}::${suffix}`
}

export function normalizeClientIp(value: string | null | undefined): string | null {
  const raw = value?.trim()
  if (!raw) return null

  const candidate = raw.split(",")[0]?.trim()
  if (!candidate) return null

  const ipVersion = isIP(candidate)
  if (ipVersion === 4) return candidate
  if (ipVersion === 6) {
    const parts = expandIpv6(candidate)
    return compressIpv6([...parts.slice(0, 4), "0", "0", "0", "0"].join(":"))
  }

  return null
}

export function resolvePublicReportClientIp(headers: Headers | null | undefined): string | null {
  if (!headers) return null

  const configuredHeader = process.env.PUBLIC_REPORT_RATE_LIMIT_TRUSTED_IP_HEADER?.trim()
  const headerCandidates = [
    configuredHeader,
    "x-forwarded-for",
    "x-real-ip",
    "cf-connecting-ip",
  ].filter((value): value is string => Boolean(value))

  const seenHeaders = new Set<string>()
  for (const headerName of headerCandidates) {
    if (seenHeaders.has(headerName)) continue
    seenHeaders.add(headerName)

    const value = headers.get(headerName)
    if (!value) continue

    const normalized = normalizeClientIp(value)
    if (normalized) return normalized
  }

  return null
}

export function createPublicReportIdentifierHash(
  salt: string,
  clientIp: string
): string | null {
  if (!salt || !clientIp) return null
  return createHmac("sha256", salt).update(clientIp).digest("hex")
}

export function getPublicReportRateLimitWindowStart(
  now = new Date()
): Date {
  const seconds = Math.floor(now.getTime() / 1000 / PUBLIC_REPORT_RATE_LIMIT_WINDOW_SECONDS)
  const windowStartMs = seconds * PUBLIC_REPORT_RATE_LIMIT_WINDOW_SECONDS * 1000
  return new Date(windowStartMs)
}

export function getPublicReportRateLimitRetryAfterSeconds(
  windowStart: Date,
  now = new Date()
): number {
  const windowEndsAt =
    windowStart.getTime() + PUBLIC_REPORT_RATE_LIMIT_WINDOW_SECONDS * 1000
  return Math.max(1, Math.ceil((windowEndsAt - now.getTime()) / 1000))
}
