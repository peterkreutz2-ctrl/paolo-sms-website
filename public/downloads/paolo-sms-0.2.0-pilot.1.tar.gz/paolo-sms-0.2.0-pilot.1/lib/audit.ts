import { and, eq, inArray, isNotNull } from "drizzle-orm"

import { db } from "@/lib/db"
import { auditLogs, reports } from "@/lib/db/schema"

type AuditEventParams = {
  organizationId: string
  clerkUserId: string | null
  action: string
  resourceType: string
  resourceId: string
  changes?: Record<string, unknown> | null
}

// Akzeptiert entweder den globalen db-Client oder den tx-Client, den
// db.transaction(async (tx) => ...) an den Callback uebergibt.
type DbOrTx = typeof db | Parameters<Parameters<typeof db.transaction>[0]>[0]

/**
 * Schreibt ein Audit-Ereignis.
 *
 * Ohne `tx` (bestehende Aufrufstellen, unveraendert): Best-Effort — ein
 * Fehler wird geloggt, aber nicht geworfen, damit ein Logging-Problem nie
 * die eigentliche fachliche Aktion blockiert.
 *
 * Mit `tx`: der Insert laeuft auf demselben Transaktions-Client und ist
 * damit atomar mit den uebrigen Schritten der Transaktion. Ein Fehler wird
 * hier bewusst NICHT verschluckt, sondern weitergeworfen, damit die
 * umgebende db.transaction(...) zurueckrollen kann — ohne das wuerde
 * "REPORT_ANONYMIZED ist Teil derselben Transaktion" keine echte Garantie
 * sein.
 */
export async function logAuditEvent(
  params: AuditEventParams,
  tx?: DbOrTx
): Promise<void> {
  const client = tx ?? db
  const insert = async () => {
    await client.insert(auditLogs).values({
      organizationId: params.organizationId,
      clerkUserId: params.clerkUserId,
      action: params.action,
      resourceType: params.resourceType,
      resourceId: params.resourceId,
      changes: params.changes ?? null,
    })
  }

  if (tx) {
    await insert()
    return
  }

  try {
    await insert()
  } catch (error) {
    console.error("[audit] Failed to log audit event:", error)
  }
}

/**
 * Generische Hilfsfunktion: liefert die Namen der Felder, deren Wert sich
 * zwischen altem und neuem Stand unterscheidet. Reine Funktion, kein
 * DB-Zugriff — Grundlage fuer feldname-only Audit-Payloads statt
 * Klartext-Vorher-/Nachher-Werten.
 */
export function computeChangedFieldNames<T extends Record<string, unknown>>(
  oldValues: T,
  newValues: T
): (keyof T)[] {
  return (Object.keys(oldValues) as (keyof T)[]).filter(
    (key) => (oldValues[key] ?? null) !== (newValues[key] ?? null)
  )
}

const REPORT_REPORTER_INFO_PII_KEYS = [
  "reporterName",
  "reporterRole",
  "reporterContact",
] as const

function asRecord(value: unknown): Record<string, unknown> | undefined {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : undefined
}

/**
 * Reine Funktion (kein DB-Zugriff): redigiert eine bestehende
 * audit_logs.changes-Payload fuer REPORT_CORE_UPDATED/
 * REPORT_REPORTER_INFO_UPDATED, sofern sie noch Klartext-Melderdaten bzw.
 * Klartext-Freitext enthaelt. Gibt `null` zurueck, wenn nichts zu redigieren
 * ist (anderer Action-Typ oder bereits redigiert) — idempotent.
 */
export function redactReportAuditChanges(
  action: string,
  changes: unknown
): { changes: Record<string, unknown>; redacted: boolean } | null {
  const c = asRecord(changes)
  if (!c) return null

  if (action === "REPORT_REPORTER_INFO_UPDATED") {
    const old = asRecord(c.old)
    const next = asRecord(c.new)
    const hasPlaintext = Boolean(
      old && REPORT_REPORTER_INFO_PII_KEYS.some((key) => key in old)
    )
    if (!hasPlaintext) return null

    const changedFields = REPORT_REPORTER_INFO_PII_KEYS.filter(
      (key) => (old?.[key] ?? null) !== (next?.[key] ?? null)
    )
    const rest: Record<string, unknown> = { ...c }
    delete rest.old
    delete rest.new
    return {
      redacted: true,
      changes: {
        ...rest,
        changedFields,
        redactedAt: new Date().toISOString(),
      },
    }
  }

  if (action === "REPORT_CORE_UPDATED") {
    const old = asRecord(c.old)
    const next = asRecord(c.new)
    const hasPlaintext = Boolean(old && "detailedDescription" in old)
    if (!hasPlaintext) return null

    const detailedDescriptionChanged =
      (old?.detailedDescription ?? null) !== (next?.detailedDescription ?? null)

    const cleanOld = old
      ? Object.fromEntries(
          Object.entries(old).filter(([key]) => key !== "detailedDescription")
        )
      : old
    const cleanNew = next
      ? Object.fromEntries(
          Object.entries(next).filter(([key]) => key !== "detailedDescription")
        )
      : next

    const rest: Record<string, unknown> = { ...c }
    delete rest.old
    delete rest.new
    return {
      redacted: true,
      changes: {
        ...rest,
        old: cleanOld,
        new: cleanNew,
        detailedDescriptionChanged,
        redactedAt: new Date().toISOString(),
      },
    }
  }

  return null
}

const REDACTABLE_REPORT_AUDIT_ACTIONS = [
  "REPORT_CORE_UPDATED",
  "REPORT_REPORTER_INFO_UPDATED",
] as const

/**
 * Redigiert alle bestehenden audit_logs-Zeilen eines Reports, die noch
 * Klartext-Melderdaten bzw. Klartext-Freitext enthalten koennten. Muss mit
 * dem tx-Client einer laufenden Transaktion aufgerufen werden, damit die
 * Redaktion atomar mit der eigentlichen Anonymisierung steht. Gibt die
 * Anzahl tatsaechlich redigierter Zeilen zurueck.
 */
export async function redactReportAuditLogEntries(
  tx: Parameters<Parameters<typeof db.transaction>[0]>[0],
  reportId: string
): Promise<number> {
  const rows = await tx
    .select({
      id: auditLogs.id,
      action: auditLogs.action,
      changes: auditLogs.changes,
    })
    .from(auditLogs)
    .where(
      and(
        eq(auditLogs.resourceId, reportId),
        eq(auditLogs.resourceType, "report"),
        inArray(auditLogs.action, REDACTABLE_REPORT_AUDIT_ACTIONS)
      )
    )

  let redactedCount = 0
  for (const row of rows) {
    const result = redactReportAuditChanges(row.action, row.changes)
    if (!result) continue
    await tx
      .update(auditLogs)
      .set({ changes: result.changes })
      .where(eq(auditLogs.id, row.id))
    redactedCount++
  }
  return redactedCount
}

export type RedactAnonymizedReportsSummary = {
  reportsChecked: number
  reportsRedacted: number
  auditLogEntriesRedacted: number
}

/**
 * Einmaliges Wartungswerkzeug (Arbeitspaket 2): redigiert historische
 * Audit-Log-Klartext-Reste fuer Reports, die bereits VOR der
 * Audit-Log-Haertung (Arbeitspaket 1) anonymisiert wurden. Pro Report laeuft
 * Redaktion + Audit-Nachweis atomar in einer eigenen Transaktion (Muster wie
 * bei der laufenden Anonymisierung). Idempotent — ein erneuter Aufruf
 * redigiert nur noch, was tatsaechlich noch Klartext enthaelt, und schreibt
 * dann auch keinen weiteren Nachweis-Eintrag mehr.
 *
 * `dbClient` ist injizierbar fuer Tests (Default: der reale db-Client). Wird
 * ausschliesslich manuell ausgefuehrt — kein automatischer/geplanter Aufruf,
 * konsistent mit der "kein Massenprozess ohne bewusste Ausloesung"-Philosophie
 * dieses Projekts.
 */
export async function redactAnonymizedReportAuditLogs(
  dbClient: typeof db = db
): Promise<RedactAnonymizedReportsSummary> {
  const anonymizedReports = await dbClient
    .select({
      id: reports.id,
      organizationId: reports.organizationId,
      anonymizedBy: reports.anonymizedBy,
    })
    .from(reports)
    .where(isNotNull(reports.anonymizedAt))

  let reportsRedacted = 0
  let auditLogEntriesRedacted = 0

  for (const report of anonymizedReports) {
    const redactedCount = await dbClient.transaction(async (tx) => {
      const count = await redactReportAuditLogEntries(tx, report.id)
      if (count > 0) {
        await logAuditEvent(
          {
            organizationId: report.organizationId,
            clerkUserId: report.anonymizedBy,
            action: "REPORT_ANONYMIZED",
            resourceType: "report",
            resourceId: report.id,
            changes: {
              redactedAuditLogEntries: count,
              source: "backfill_script",
            },
          },
          tx
        )
      }
      return count
    })

    if (redactedCount > 0) {
      reportsRedacted++
      auditLogEntriesRedacted += redactedCount
    }
  }

  return {
    reportsChecked: anonymizedReports.length,
    reportsRedacted,
    auditLogEntriesRedacted,
  }
}
