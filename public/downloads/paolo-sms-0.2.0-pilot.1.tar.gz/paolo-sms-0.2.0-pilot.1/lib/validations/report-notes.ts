import { z } from "zod"

import { NOTE_TYPE_VALUES } from "@/lib/constants/report-notes"

export const createReportNoteSchema = z.object({
  reportId: z.string().uuid("Ungültige Meldungs-ID."),
  noteType: z.enum(NOTE_TYPE_VALUES, { error: "Ungültiger Notiztyp." }),
  content: z.string().trim().min(1, "Der Inhalt darf nicht leer sein."),
})
