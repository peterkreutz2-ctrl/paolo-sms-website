import { z } from "zod"

// Alle Felder sind optional — leere Angaben sind erlaubt. E-Mail-Felder werden
// nur geprüft, wenn sie ausgefüllt sind. Leere Strings werden zu null normiert.
const optionalText = z
  .string()
  .trim()
  .max(2000, "Maximal 2000 Zeichen.")
  .optional()
  .transform((v) => (v && v.length > 0 ? v : null))

const optionalEmail = z
  .string()
  .trim()
  .max(320, "Maximal 320 Zeichen.")
  .optional()
  .transform((v) => (v && v.length > 0 ? v : null))
  .refine(
    (v) => v === null || /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v),
    "Bitte eine gültige E-Mail-Adresse eingeben."
  )

// Freier Langtext (z. B. vollständige Datenschutzerklärung). Höheres Limit als
// die kurzen strukturierten Felder; leerer String wird zu null normiert.
const optionalLongText = z
  .string()
  .trim()
  .max(50000, "Maximal 50000 Zeichen.")
  .optional()
  .transform((v) => (v && v.length > 0 ? v : null))

export const legalSettingsSchema = z.object({
  operatorName: optionalText,
  operatorLegalForm: optionalText,
  operatorAddress: optionalText,
  operatorEmail: optionalEmail,
  operatorPhone: optionalText,
  representedBy: optionalText,
  registerInfo: optionalText,
  vatId: optionalText,
  supervisoryAuthority: optionalText,
  privacyResponsibleName: optionalText,
  privacyContactEmail: optionalEmail,
  dataProtectionOfficer: optionalText,
  hostingProviderInfo: optionalText,
  dataRetentionInfo: optionalText,
  legalExtraText: optionalText,
  privacyExtraText: optionalText,
  privacyPolicyText: optionalLongText,
})

export type LegalSettingsInput = z.infer<typeof legalSettingsSchema>

// Feldschlüssel zentral, damit Action, Formular und öffentliche Seiten
// dieselbe Feldliste nutzen.
export const LEGAL_SETTINGS_FIELDS = [
  "operatorName",
  "operatorLegalForm",
  "operatorAddress",
  "operatorEmail",
  "operatorPhone",
  "representedBy",
  "registerInfo",
  "vatId",
  "supervisoryAuthority",
  "privacyResponsibleName",
  "privacyContactEmail",
  "dataProtectionOfficer",
  "hostingProviderInfo",
  "dataRetentionInfo",
  "legalExtraText",
  "privacyExtraText",
  "privacyPolicyText",
] as const

export type LegalSettingsFieldKey = (typeof LEGAL_SETTINGS_FIELDS)[number]
