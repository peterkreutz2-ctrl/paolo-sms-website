import { z } from "zod"

import {
  INCIDENT_NOTIFICATION_DECISION_VALUES,
  INCIDENT_RISK_VALUES,
  INCIDENT_STATUS_VALUES,
} from "@/lib/constants/privacy-incidents"

const optionalText = z
  .string()
  .trim()
  .max(2000, "Der Text ist zu lang (max. 2000 Zeichen).")
  .optional()

export const createPrivacyIncidentSchema = z.object({
  title: z
    .string()
    .trim()
    .min(1, "Titel fehlt.")
    .max(200, "Der Titel darf höchstens 200 Zeichen enthalten."),
  discoveredAt: z.string().trim().optional(),
  discoveredByText: z
    .string()
    .trim()
    .max(200, "Der Text ist zu lang (max. 200 Zeichen).")
    .optional(),
  description: z.string().trim().min(1, "Beschreibung fehlt."),
  affectedDataCategories: optionalText,
  affectedPersonsEstimate: z
    .string()
    .trim()
    .max(200, "Der Text ist zu lang (max. 200 Zeichen).")
    .optional(),
  immediateActions: optionalText,
  riskAssessment: z.enum(INCIDENT_RISK_VALUES).default("unknown"),
})

export type CreatePrivacyIncidentInput = z.infer<
  typeof createPrivacyIncidentSchema
>

export const updatePrivacyIncidentSchema = z.object({
  incidentId: z.string().uuid("Ungültige Vorfall-ID."),
  status: z.enum(INCIDENT_STATUS_VALUES, { message: "Ungültiger Status." }),
  riskAssessment: z.enum(INCIDENT_RISK_VALUES, {
    message: "Ungültige Risikobewertung.",
  }),
  notificationDecision: z.enum(INCIDENT_NOTIFICATION_DECISION_VALUES, {
    message: "Ungültige Meldeentscheidung.",
  }),
  decisionReason: optionalText,
  followUpActions: optionalText,
})

export type UpdatePrivacyIncidentInput = z.infer<
  typeof updatePrivacyIncidentSchema
>
