import { z } from "zod"
import {
  PUBLIC_REPORT_TYPE_VALUES,
} from "@/lib/constants/public-report-types"
import {
  ACTIVITY_AREA_VALUES,
  ACTIVITY_TYPE_VALUES,
  DAMAGE_SEVERITY_VALUES,
  FLIGHT_PHASE_VALUES,
  INJURY_SEVERITY_VALUES,
  LAUNCH_TYPE_VALUES,
  REPORTER_ROLE_VALUES,
  SEVERITY_VALUES,
} from "@/lib/constants/report-classification"
import {
  REPORT_PRIORITY_VALUES,
  REPORT_STATUS_VALUES,
} from "@/lib/constants/report-workflow"
import {
  RISK_PROBABILITY_VALUES,
  RISK_SEVERITY_VALUES,
} from "@/lib/constants/report-risk"

export const createReportSchema = z.object({
  publicSubmissionId: z.string().uuid("Ungültige Einreichungs-ID."),
  reportType: z.enum(PUBLIC_REPORT_TYPE_VALUES, {
    message: "Bitte wähle, was du melden möchtest.",
  }),
  shortDescription: z
    .string()
    .trim()
    .min(1, "Kurzbeschreibung fehlt.")
    .max(120, "Die Kurzbeschreibung darf höchstens 120 Zeichen enthalten."),

  description: z
    .string()
    .trim()
    .min(1, "Beschreibung fehlt.")
    .max(10000, "Die Beschreibung darf höchstens 10.000 Zeichen enthalten."),

  occurredAt: z.string().optional(),
  locationText: z.string().trim().max(500, "Der Ort darf höchstens 500 Zeichen enthalten.").optional(),
  reporterLessonsLearned: z.string().trim().max(5000, "Die Erkenntnisse dürfen höchstens 5.000 Zeichen enthalten.").optional(),
  reporterSuggestedMeasures: z.string().trim().max(5000, "Der Maßnahmenvorschlag darf höchstens 5.000 Zeichen enthalten.").optional(),

  activityType: z.enum(ACTIVITY_TYPE_VALUES).optional().catch(undefined),
  flightPhase: z.enum(FLIGHT_PHASE_VALUES).optional().catch(undefined),
  launchType: z.enum(LAUNCH_TYPE_VALUES).optional().catch(undefined),
  // severity kept for backward-compat but no longer shown in public form
  severity: z.enum(SEVERITY_VALUES).optional().catch(undefined),

  reporterName: z.string().trim().max(200, "Der Name darf höchstens 200 Zeichen enthalten.").optional(),
  reporterRole: z.enum(REPORTER_ROLE_VALUES).optional().catch(undefined),
  reporterContact: z.string().trim().max(320, "Der Kontakt darf höchstens 320 Zeichen enthalten.").optional(),
  injurySeverity: z.enum(INJURY_SEVERITY_VALUES).optional().catch(undefined),
  damageSeverity: z.enum(DAMAGE_SEVERITY_VALUES).optional().catch(undefined),

  // Datenschutz-Einwilligung (#101). Beide optional: Ob die Zustimmung Pflicht
  // ist, haengt von der Organisationseinstellung ab und wird in createReport
  // gegen den Serverzustand entschieden, nicht im statischen Schema.
  privacyConsentGiven: z.boolean().optional(),
  privacyConsentFingerprint: z.string().max(128).optional(),
})

export type CreateReportInput = z.infer<typeof createReportSchema>

export const updateReportWorkflowSchema = z.object({
  reportId: z.string().uuid("Ungültige Meldungs-ID."),
  status: z.enum(REPORT_STATUS_VALUES, {
    message: "Ungültiger Status.",
  }),
  priority: z.enum(REPORT_PRIORITY_VALUES, {
    message: "Ungültige Priorität.",
  }),
})

export type UpdateReportWorkflowInput = z.infer<
  typeof updateReportWorkflowSchema
>

export const updateReportClassificationSchema = z.object({
  reportId: z.string().uuid("Ungültige Meldungs-ID."),
  activityArea: z.enum(ACTIVITY_AREA_VALUES).optional(),
  isReportableAccident: z.preprocess(
    (v) => {
      if (v === "__none" || v === undefined || v === null || v === "") return undefined
      if (v === "true") return true
      if (v === "false") return false
      return undefined
    },
    z.boolean().optional()
  ),
  // ICAO-Risikomatrix: leer/"nicht bewertet" oder gueltiger Skalenwert.
  riskProbability: z.enum(RISK_PROBABILITY_VALUES).optional(),
  riskSeverity: z.enum(RISK_SEVERITY_VALUES).optional(),
})

export type UpdateReportClassificationInput = z.infer<
  typeof updateReportClassificationSchema
>

export const updateReportReporterInfoSchema = z.object({
  reportId: z.string().uuid("Ungültige Meldungs-ID."),
  reporterName: z.string().trim().optional(),
  reporterRole: z.enum(REPORTER_ROLE_VALUES).optional(),
  reporterContact: z.string().trim().optional(),
})

export type UpdateReportReporterInfoInput = z.infer<
  typeof updateReportReporterInfoSchema
>

export const updateReportCoreSchema = z.object({
  reportId: z.string().uuid("Ungültige Meldungs-ID."),
  reportType: z.enum(PUBLIC_REPORT_TYPE_VALUES, {
    message: "UngÃ¼ltiger Meldungstyp.",
  }),
  shortDescription: z
    .string()
    .trim()
    .min(1, "Kurzbeschreibung fehlt.")
    .max(120, "Die Kurzbeschreibung darf hÃ¶chstens 120 Zeichen enthalten."),
  detailedDescription: z.string().trim().min(1, "Beschreibung fehlt."),
  isAnonymous: z.preprocess(
    (v) => {
      if (v === "true") return true
      if (v === "false") return false
      return undefined
    },
    z.boolean({ message: "UngÃ¼ltiger Wert fÃ¼r AnonymitÃ¤t." })
  ),
  occurredAt: z.string().optional(),
  locationText: z.string().trim().optional(),
  activityType: z.enum(ACTIVITY_TYPE_VALUES).optional(),
  flightPhase: z.enum(FLIGHT_PHASE_VALUES).optional(),
  launchType: z.enum(LAUNCH_TYPE_VALUES).optional(),
  injurySeverity: z.enum(INJURY_SEVERITY_VALUES).optional(),
  damageSeverity: z.enum(DAMAGE_SEVERITY_VALUES).optional(),
})

export type UpdateReportCoreInput = z.infer<typeof updateReportCoreSchema>
