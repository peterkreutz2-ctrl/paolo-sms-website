import { z } from "zod"

import {
  SMS_DOCUMENT_CATEGORY_VALUES,
  SMS_DOCUMENT_VISIBILITY_VALUES,
} from "@/lib/constants/sms-documents"

// Freier Langtext (Text/Markdown). Höheres Limit analog zur
// Datenschutzerklärung; die Ablage speichert reinen Text, kein HTML.
const contentField = z
  .string()
  .trim()
  .min(1, "Inhalt fehlt.")
  .max(50000, "Der Inhalt darf höchstens 50000 Zeichen enthalten.")

const titleField = z
  .string()
  .trim()
  .min(1, "Titel fehlt.")
  .max(200, "Der Titel darf höchstens 200 Zeichen enthalten.")

export const createSmsDocumentSchema = z.object({
  category: z.enum(SMS_DOCUMENT_CATEGORY_VALUES, {
    message: "Ungültige Kategorie.",
  }),
  title: titleField,
  content: contentField,
  visibility: z
    .enum(SMS_DOCUMENT_VISIBILITY_VALUES, { message: "Ungültige Sichtbarkeit." })
    .default("confidential"),
})

export type CreateSmsDocumentInput = z.infer<typeof createSmsDocumentSchema>

export const updateSmsDocumentSchema = z.object({
  documentId: z.string().uuid("Ungültige Dokument-ID."),
  category: z.enum(SMS_DOCUMENT_CATEGORY_VALUES, {
    message: "Ungültige Kategorie.",
  }),
  title: titleField,
  content: contentField,
  visibility: z.enum(SMS_DOCUMENT_VISIBILITY_VALUES, {
    message: "Ungültige Sichtbarkeit.",
  }),
})

export type UpdateSmsDocumentInput = z.infer<typeof updateSmsDocumentSchema>

export const deleteSmsDocumentSchema = z.object({
  documentId: z.string().uuid("Ungültige Dokument-ID."),
})

export type DeleteSmsDocumentInput = z.infer<typeof deleteSmsDocumentSchema>
