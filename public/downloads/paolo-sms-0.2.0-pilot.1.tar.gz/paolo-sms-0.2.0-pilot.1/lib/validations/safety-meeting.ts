import { z } from "zod"

export const createSafetyMeetingSchema = z
  .object({
    meetingDate: z
      .string()
      .trim()
      .min(1, "Datum fehlt.")
      .regex(/^\d{4}-\d{2}-\d{2}$/, "Ungültiges Datum (YYYY-MM-DD)."),
    title: z.string().optional(),
    notes: z.string().optional(),
  })
  .transform((data) => {
    const title = data.title?.trim()
    const notes = data.notes?.trim()

    return {
      meetingDate: data.meetingDate,
      title: title && title.length > 0 ? title : null,
      notes: notes && notes.length > 0 ? notes : null,
    }
  })

export type CreateSafetyMeetingInput = z.infer<typeof createSafetyMeetingSchema>