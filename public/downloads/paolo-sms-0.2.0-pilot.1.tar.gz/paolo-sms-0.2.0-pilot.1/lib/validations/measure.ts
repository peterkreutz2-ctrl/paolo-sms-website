import { z } from "zod"

import { MEASURE_STATUS_VALUES } from "@/lib/constants/measure-workflow"

export const createMeasureSchema = z
  .object({
    reportId: z.string().uuid("Ungültige Meldungs-ID."),
    title: z
      .string()
      .trim()
      .min(1, "Titel fehlt.")
      .max(200, "Der Titel darf hoechstens 200 Zeichen enthalten."),
    description: z.string().optional(),
    assignedToText: z.string().optional(),
    dueDate: z.string().optional(),
  })
  .superRefine((val, ctx) => {
    const raw = val.dueDate?.trim()
    if (!raw) return
    if (!/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
      ctx.addIssue({
        code: "custom",
        path: ["dueDate"],
        message: "Ungültiges Fälligkeitsdatum.",
      })
    }
  })
  .transform((data) => {
    const desc = data.description?.trim()
    const assigned = data.assignedToText?.trim()
    const dueRaw = data.dueDate?.trim()
    let dueDate: Date | null = null
    if (dueRaw && /^\d{4}-\d{2}-\d{2}$/.test(dueRaw)) {
      const d = new Date(`${dueRaw}T12:00:00.000Z`)
      dueDate = Number.isNaN(d.getTime()) ? null : d
    }
    return {
      reportId: data.reportId,
      title: data.title,
      description: desc && desc.length > 0 ? desc : null,
      assignedToText: assigned && assigned.length > 0 ? assigned : null,
      dueDate,
    }
  })

export type CreateMeasureInput = z.infer<typeof createMeasureSchema>

export const updateMeasureSchema = z
  .object({
    measureId: z.string().uuid("Ungültige Maßnahmen-ID."),
    reportId: z.string().uuid("Ungültige Meldungs-ID."),
    title: z
      .string()
      .trim()
      .min(1, "Titel fehlt.")
      .max(200, "Der Titel darf hoechstens 200 Zeichen enthalten."),
    description: z.string().optional(),
    assignedToText: z.string().optional(),
    status: z.enum(MEASURE_STATUS_VALUES, {
      message: "Ungültiger Maßnahmen-Status.",
    }),
    dueDate: z.string().optional(),
    // Begruendung fuer das Verwerfen. Ob sie verlangt wird, haengt am
    // bisherigen Status, den nur der Server kennt — die Regel steht als reine
    // Funktion in lib/constants/measure-workflow.ts und wird in der Action
    // geprueft.
    //
    // `nullish` statt `optional`: Das Eingabefeld wird nur gerendert, wenn
    // „Verworfen" gewaehlt ist. In allen anderen Faellen liefert
    // formData.get() `null` — und `optional()` akzeptiert nur `undefined`.
    // Ohne diese Unterscheidung schlaegt JEDE gewoehnliche Bearbeitung mit
    // „expected string, received null" fehl.
    discardReason: z.string().nullish(),
  })
  .superRefine((val, ctx) => {
    const raw = val.dueDate?.trim()
    if (!raw) return
    if (!/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
      ctx.addIssue({
        code: "custom",
        path: ["dueDate"],
        message: "Ungültiges Fälligkeitsdatum.",
      })
    }
  })
  .transform((data) => {
    const desc = data.description?.trim()
    const assigned = data.assignedToText?.trim()
    const dueRaw = data.dueDate?.trim()
    let dueDate: Date | null = null
    if (dueRaw && /^\d{4}-\d{2}-\d{2}$/.test(dueRaw)) {
      const d = new Date(`${dueRaw}T12:00:00.000Z`)
      dueDate = Number.isNaN(d.getTime()) ? null : d
    }
    const discard = data.discardReason?.trim()
    return {
      measureId: data.measureId,
      reportId: data.reportId,
      title: data.title,
      description: desc && desc.length > 0 ? desc : null,
      assignedToText: assigned && assigned.length > 0 ? assigned : null,
      status: data.status,
      dueDate,
      discardReason: discard && discard.length > 0 ? discard : null,
    }
  })

export type UpdateMeasureInput = z.infer<typeof updateMeasureSchema>
