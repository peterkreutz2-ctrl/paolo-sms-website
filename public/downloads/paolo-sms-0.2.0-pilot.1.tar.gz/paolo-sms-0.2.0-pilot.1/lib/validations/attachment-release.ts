import { z } from "zod"

import {
  RELEASE_NOTE_MAX_LENGTH,
  RELEASE_NOTE_MIN_LENGTH,
} from "@/lib/constants/attachment-release"

// Der Freigabevermerk ist Pflicht. Die Untergrenze verhindert ein
// versehentliches Absenden, erzwingt aber keine Mindestwortzahl — die
// eigentliche Qualitaetssicherung ist der Mensch, nicht das Schema.
const releaseNoteField = z
  .string()
  .trim()
  .min(
    RELEASE_NOTE_MIN_LENGTH,
    `Bitte den Freigabevermerk ausfüllen (mindestens ${RELEASE_NOTE_MIN_LENGTH} Zeichen).`
  )
  .max(
    RELEASE_NOTE_MAX_LENGTH,
    `Der Freigabevermerk darf höchstens ${RELEASE_NOTE_MAX_LENGTH} Zeichen enthalten.`
  )

export const publishAttachmentSchema = z.object({
  attachmentId: z.string().uuid("Ungültige Anhangs-ID."),
  documentId: z.string().uuid("Ungültige Dokument-ID."),
  releaseNote: releaseNoteField,
  // Die Vollstaendigkeit wird nicht hier geprueft, sondern serverseitig gegen
  // die fuer genau diesen Anhang erforderlichen Punkte
  // (areAllChecklistItemsConfirmed) — das Schema kennt den Dateinamen nicht.
  confirmedChecklistKeys: z.array(z.string()),
})

export type PublishAttachmentInput = z.infer<typeof publishAttachmentSchema>

export const unpublishAttachmentSchema = z.object({
  attachmentId: z.string().uuid("Ungültige Anhangs-ID."),
  documentId: z.string().uuid("Ungültige Dokument-ID."),
})

export type UnpublishAttachmentInput = z.infer<typeof unpublishAttachmentSchema>
