import { z } from "zod"

import {
  SAFETY_MEETING_INTERVAL_MAX_MONTHS,
  SAFETY_MEETING_INTERVAL_MIN_MONTHS,
} from "@/lib/constants/safety-meeting-interval"
import { normalizeOrganizationDisplayName } from "@/lib/constants/organization-display-name"
import { validatePrivacyConsentText } from "@/lib/constants/public-report-privacy-consent"

export const updateOrganizationSettingsSchema = z.object({
  // Grenzen aus lib/constants/safety-meeting-interval.ts, damit Formular und
  // Server dieselbe Regel durchsetzen.
  safetyMeetingIntervalMonths: z.coerce
    .number()
    .int("Bitte eine ganze Zahl eingeben.")
    .min(
      SAFETY_MEETING_INTERVAL_MIN_MONTHS,
      `Mindestens ${SAFETY_MEETING_INTERVAL_MIN_MONTHS} Monat.`
    )
    .max(
      SAFETY_MEETING_INTERVAL_MAX_MONTHS,
      `Maximal ${SAFETY_MEETING_INTERVAL_MAX_MONTHS} Monate.`
    ),
  // Leer/nicht gesetzt = Funktion deaktiviert. PAOLO gibt keine Frist vor,
  // siehe docs/data-protection-concept.md.
  reportRetentionReviewIntervalMonths: z
    .preprocess(
      (v) => {
        if (v === null || v === undefined) return undefined
        const s = String(v).trim()
        return s.length === 0 ? undefined : s
      },
      z.coerce
        .number()
        .int("Bitte eine ganze Zahl eingeben.")
        .min(1, "Mindestens 1 Monat.")
        .max(600, "Maximal 600 Monate.")
        .optional()
    )
    .transform((v) => v ?? null),
})

export type UpdateOrganizationSettingsInput = z.infer<
  typeof updateOrganizationSettingsSchema
>

// Organisationsschalter fuer die oeffentliche Statusrueckmeldung. Ein
// Kontrollkaestchen sendet nur dann etwas, wenn es angehakt ist — "nicht
// vorhanden" heisst also "aus". Deshalb wird hier bewusst auf einen genauen
// Wert geprueft statt auf Wahrheitswert-Aehnlichkeit.
export const updatePublicReportStatusVisibilitySchema = z.object({
  publicReportStatusEnabled: z
    .preprocess((v) => v === "on" || v === "true" || v === true, z.boolean()),
})

export type UpdatePublicReportStatusVisibilityInput = z.infer<
  typeof updatePublicReportStatusVisibilitySchema
>

// Datenschutz-Einwilligung auf /submit-report (#101). Kontrollkaestchen wie
// oben; der Text wird nur getrimmt und dann nach den gemeinsamen Regeln aus
// lib/constants/public-report-privacy-consent.ts geprueft.
export const updatePublicReportPrivacyConsentSchema = z.object({
  publicReportPrivacyConsentEnabled: z
    .preprocess((v) => v === "on" || v === "true" || v === true, z.boolean()),
  publicReportPrivacyConsentText: z
    .string({ message: "Der Einwilligungstext fehlt." })
    // Textareas senden Zeilenumbrueche als CRLF; gespeichert wird LF, damit
    // derselbe Text nicht als Aenderung gilt, nur weil er neu gesendet wurde.
    .transform((v) => v.replace(/\r\n?/g, "\n").trim())
    .superRefine((v, ctx) => {
      const error = validatePrivacyConsentText(v)
      if (error) ctx.addIssue({ code: "custom", message: error })
    }),
})

export type UpdatePublicReportPrivacyConsentInput = z.infer<
  typeof updatePublicReportPrivacyConsentSchema
>

// SMS-Verantwortung (rein dokumentarisch). Alle Felder optional; leere Eingaben
// werden zu null normalisiert, damit "geleert" auch tatsaechlich loescht.
const optionalDocText = z
  .string()
  .trim()
  .max(500, "Maximal 500 Zeichen.")
  .transform((v) => (v.length === 0 ? null : v))
  .nullable()

export const updateSmsGovernanceSchema = z.object({
  accountableExecutiveName: optionalDocText,
  accountableExecutiveFunction: optionalDocText,
  accountableExecutiveContact: optionalDocText,
  accountableExecutiveTerm: optionalDocText,
  safetyManagerName: optionalDocText,
  safetyManagerFunction: optionalDocText,
  safetyManagerContact: optionalDocText,
  safetyManagerTerm: optionalDocText,
})

export type UpdateSmsGovernanceInput = z.infer<typeof updateSmsGovernanceSchema>

// Anzeigename der Organisation im Kopf der Anwendung (#117). Die Regeln stehen in
// lib/constants/organization-display-name.ts; leer heisst "kein Name" (null).
export const updateOrganizationDisplayNameSchema = z.object({
  organizationDisplayName: z
    .unknown()
    .transform((value, ctx) => {
      const result = normalizeOrganizationDisplayName(value)
      if (!result.ok) {
        ctx.addIssue({ code: "custom", message: result.message })
        return z.NEVER
      }
      return result.value
    }),
})

export type UpdateOrganizationDisplayNameInput = z.infer<
  typeof updateOrganizationDisplayNameSchema
>
