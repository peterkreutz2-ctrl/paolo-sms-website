import { dbPool } from "@/lib/db"
import {
  getPublicReportRateLimitRetentionDays,
  PUBLIC_REPORT_RATE_LIMIT_CLEANUP_BATCH_SIZE,
} from "@/lib/public-report-rate-limit"

export async function cleanupExpiredPublicReportRateLimits(
  now = new Date()
): Promise<number> {
  const retentionDays = getPublicReportRateLimitRetentionDays()
  const cutoff = new Date(now.getTime() - retentionDays * 24 * 60 * 60 * 1_000)

  const result = await dbPool.query(
    `WITH expired AS (
       SELECT id
       FROM public_report_rate_limits
       WHERE window_start < $1
       ORDER BY window_start ASC
       LIMIT $2
     )
     DELETE FROM public_report_rate_limits AS rate_limit
     USING expired
     WHERE rate_limit.id = expired.id`,
    [cutoff, PUBLIC_REPORT_RATE_LIMIT_CLEANUP_BATCH_SIZE]
  )

  return result.rowCount ?? 0
}
