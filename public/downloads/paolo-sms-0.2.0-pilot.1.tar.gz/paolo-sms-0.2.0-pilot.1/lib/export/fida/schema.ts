import { z } from "zod"

export const FIDA_SCHEMA_VERSION = "1.0" as const

const nullableText = z.string().nullable()

export const fidaReportSchema = z.object({
  api_uid: z.string().min(1),
  report_hash: z.string().regex(/^[0-9a-f]{64}$/),
  heuristic_key: z.string(),
  date: z.iso.date(),
  airfield: nullableText,
  age: nullableText,
  flies_since: nullableText,
  type_of_flight_license: nullableText,
  weather_wind: nullableText,
  weather_thermic: nullableText,
  weather_turbulences: nullableText,
  flight_equipment: nullableText,
  aircraft_manufacturer: nullableText,
  aircraft_model: nullableText,
  motor_unit_manufacturer: nullableText,
  motor_unit_model: nullableText,
  pilot_error: nullableText,
  incident_cause: nullableText,
  flight_phase: nullableText,
  injuries_pilot: nullableText,
  description: z.string(),
  raw_json: z.object({
    id: z.string().min(1),
    source: z.literal("PAOLO"),
  }),
  first_seen_at: z.iso.datetime(),
  last_seen_at: z.iso.datetime(),
})

export const fidaExportSchema = z.object({
  schema_version: z.literal(FIDA_SCHEMA_VERSION),
  exported_at: z.iso.datetime(),
  reports: z.array(fidaReportSchema),
})

export type FidaReport = z.infer<typeof fidaReportSchema>
export type FidaExport = z.infer<typeof fidaExportSchema>
