import { createHash } from "node:crypto"

import {
  fidaExportSchema,
  FIDA_SCHEMA_VERSION,
  type FidaExport,
  type FidaReport,
} from "./schema"

export const FIDA_FLIGHT_EQUIPMENT: Readonly<Record<string, string>> = {
  paragliding: "Paraglider",
  hang_gliding: "Hang Glider",
  powered_paragliding: "Powered Paraglider",
  speed_riding: "Speedrider",
  parakite: "Parakite",
  other: "Other",
}

export const FIDA_FLIGHT_PHASE: Readonly<Record<string, string>> = {
  pre_flight: "Pre-flight",
  groundhandling: "Ground handling",
  launch: "Takeoff",
  flight: "Flight",
  landing: "Landing",
  post_flight: "Post-flight",
  not_applicable: "Not applicable",
}

export const FIDA_INJURY_SEVERITY: Readonly<Record<string, string>> = {
  none: "None",
  minor: "Minor",
  serious: "Serious",
  fatal: "Fatal",
}

export type FidaReportSource = {
  id: string
  occurredAt: Date
  locationText: string | null
  activityArea: string | null
  flightPhase: string | null
  injurySeverity: string | null
  detailedDescription: string
  createdAt: Date
  updatedAt: Date
}

export const FIDA_REPORT_SOURCE_MAPPING = {
  api_uid: { source: "reports.id", required: true },
  date: { source: "reports.occurredAt", transform: "UTC date", required: true },
  airfield: { source: "reports.locationText", required: false },
  flight_equipment: { source: "reports.activityArea", transform: "FIDA_FLIGHT_EQUIPMENT", required: false },
  flight_phase: { source: "reports.flightPhase", transform: "FIDA_FLIGHT_PHASE", required: false },
  injuries_pilot: { source: "reports.injurySeverity", transform: "FIDA_INJURY_SEVERITY", required: false },
  description: { source: "reports.detailedDescription", required: true },
  first_seen_at: { source: "reports.createdAt", transform: "ISO 8601 UTC", required: true },
  last_seen_at: { source: "reports.updatedAt", transform: "ISO 8601 UTC", required: true },
} as const

function mappedValue(mapping: Readonly<Record<string, string>>, value: string | null): string | null {
  return value ? mapping[value] ?? null : null
}

function heuristicPart(value: string | null): string {
  return (value ?? "")
    .normalize("NFKC")
    .trim()
    .replace(/\s+/g, " ")
    .replaceAll("|", "\\|")
}

function canonicalHashInput(report: Omit<FidaReport, "report_hash" | "heuristic_key" | "api_uid" | "raw_json" | "first_seen_at" | "last_seen_at">): string {
  // Property order is intentional and versioned with the FIDA mapping.
  return JSON.stringify(report)
}

export function mapFidaReport(source: FidaReportSource): FidaReport {
  const date = source.occurredAt.toISOString().slice(0, 10)
  const airfield = source.locationText?.trim() || null
  const flightEquipment = mappedValue(FIDA_FLIGHT_EQUIPMENT, source.activityArea)
  const flightPhase = mappedValue(FIDA_FLIGHT_PHASE, source.flightPhase)
  const injuriesPilot = mappedValue(FIDA_INJURY_SEVERITY, source.injurySeverity)
  const hashFields = {
    date,
    airfield,
    age: null,
    flies_since: null,
    type_of_flight_license: null,
    weather_wind: null,
    weather_thermic: null,
    weather_turbulences: null,
    flight_equipment: flightEquipment,
    aircraft_manufacturer: null,
    aircraft_model: null,
    motor_unit_manufacturer: null,
    motor_unit_model: null,
    pilot_error: null,
    incident_cause: null,
    flight_phase: flightPhase,
    injuries_pilot: injuriesPilot,
    description: source.detailedDescription,
  }
  const report: FidaReport = {
    api_uid: source.id,
    report_hash: createHash("sha256").update(canonicalHashInput(hashFields)).digest("hex"),
    heuristic_key: [
      date,
      heuristicPart(airfield),
      heuristicPart(flightEquipment),
      "",
      "",
    ].join("|"),
    ...hashFields,
    raw_json: { id: source.id, source: "PAOLO" },
    first_seen_at: source.createdAt.toISOString(),
    last_seen_at: source.updatedAt.toISOString(),
  }
  return report
}

export function createFidaExport(
  sources: readonly FidaReportSource[],
  exportedAt = new Date(),
): FidaExport {
  return fidaExportSchema.parse({
    schema_version: FIDA_SCHEMA_VERSION,
    exported_at: exportedAt.toISOString(),
    reports: sources.map(mapFidaReport),
  })
}
