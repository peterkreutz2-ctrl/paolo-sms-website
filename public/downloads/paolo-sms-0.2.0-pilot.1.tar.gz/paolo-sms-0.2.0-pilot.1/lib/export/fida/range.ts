const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/

function parseUtcDate(value: string, field: string): Date {
  if (!DATE_PATTERN.test(value)) throw new Error(`${field} muss YYYY-MM-DD entsprechen.`)
  const date = new Date(`${value}T00:00:00.000Z`)
  if (Number.isNaN(date.getTime()) || date.toISOString().slice(0, 10) !== value) {
    throw new Error(`${field} ist kein gültiges Datum.`)
  }
  return date
}

export function parseFidaExportRange(fromValue: string | null, toValue: string | null): {
  from: Date
  to: Date
  fromDate: string
  toDate: string
} {
  if (!fromValue || !toValue) throw new Error("from und to sind erforderlich.")
  const from = parseUtcDate(fromValue, "from")
  const to = parseUtcDate(toValue, "to")
  if (from >= to) throw new Error("to muss nach from liegen.")

  const maximumTo = new Date(from)
  maximumTo.setUTCFullYear(maximumTo.getUTCFullYear() + 1)
  if (to > maximumTo) throw new Error("Der Exportzeitraum darf höchstens ein Jahr umfassen.")

  return { from, to, fromDate: fromValue, toDate: toValue }
}
