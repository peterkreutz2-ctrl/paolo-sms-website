import { cache } from "react"

import { db } from "@/lib/db"
import { organizations } from "@/lib/db/schema"

/**
 * Anzeigename der Organisation dieser Installation (#117) oder `null`.
 *
 * Die einzige Stelle, die der Kopf der Anwendung kennt: Layouts und
 * Komponenten bekommen den Namen als Wert und wissen nichts von Tabelle oder
 * Anzahl der Organisationen. Eine Installation fuehrt genau eine Organisation
 * (AGENTS.md); sollte sich das aendern, wird nur diese Funktion ersetzt.
 *
 * `cache` fasst die Aufrufe eines Requests zusammen: Wurzel- und
 * Dashboard-Layout fragen dieselbe Zeile nur einmal ab.
 *
 * Der Kopf ist Beiwerk und darf keine Seite verhindern. Fehlt die Organisation
 * (frische Datenbank vor dem Bootstrap) oder schlaegt die Abfrage fehl (etwa
 * weil die Migration 0035 noch nicht angewandt ist), liefert die Funktion
 * `null`; der Kopf zeigt dann nur "PAOLO SMS". Ein Fehler wird protokolliert,
 * nicht verschluckt.
 */
export const getOrganizationDisplayName = cache(
  async (): Promise<string | null> => {
    try {
      const [organization] = await db
        .select({ displayName: organizations.displayName })
        .from(organizations)
        .limit(1)

      const name = organization?.displayName?.trim()
      return name ? name : null
    } catch (error) {
      console.error("[header] Anzeigename der Organisation nicht lesbar:", error)
      return null
    }
  }
)
