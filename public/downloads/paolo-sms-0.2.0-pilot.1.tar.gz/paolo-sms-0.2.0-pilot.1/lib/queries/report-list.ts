import { and, count, desc, eq, ilike, inArray, isNull, notInArray } from "drizzle-orm"

import { db } from "@/lib/db"
import { reports } from "@/lib/db/schema"
import {
  CLOSED_OR_HIDDEN_STATUSES,
  type ReportPriority,
  type ReportStatus,
} from "@/lib/constants/report-workflow"

type DbClient = typeof db

/**
 * Seitengröße der Meldungsliste.
 *
 * Bewusst eine Konstante und kein Abfrageparameter: Eine vom Aufrufer frei
 * setzbare Seitengröße wäre ein Weg, die Begrenzung wieder auszuhebeln — und
 * genau davor soll sie schützen. Fünfundzwanzig Zeilen füllen einen Bildschirm
 * ohne Scrollen bis zur Unkenntlichkeit und halten die Antwort klein.
 */
export const REPORT_LIST_PAGE_SIZE = 25

/**
 * Höchstlänge der in der Liste ausgelieferten Beschreibung.
 *
 * Gekürzt wird **serverseitig**, nicht per CSS: `detailedDescription` fasst bis
 * zu 10.000 Zeichen, und die Liste hat sie bisher vollständig an den Browser
 * geschickt — bei fünfundzwanzig Zeilen ein Vielfaches dessen, was sichtbar
 * ist. Die vollständige Beschreibung steht auf der Detailseite.
 */
export const REPORT_LIST_DESCRIPTION_LENGTH = 220

export type ReportListStatusFilter = ReportStatus | "all" | "open_all"
export type ReportListPriorityFilter = ReportPriority | "all"

export type ReportListRow = {
  id: string
  reportType: string
  status: string
  priority: string
  shortDescription: string
  descriptionExcerpt: string
  descriptionTruncated: boolean
  createdAt: Date
}

export type ReportListResult = {
  rows: ReportListRow[]
  total: number
  page: number
  pageCount: number
}

// ─── Reine Hilfsfunktionen ──────────────────────────────────────────────────
// Ohne Datenbankzugriff und deshalb vollständig testbar. Die Normalisierung
// gehört hierher und nicht in die Seite: Ein Seitenparameter aus der URL ist
// Benutzereingabe und kann alles sein.

/** Begrenzt eine Seitenzahl aus der URL auf einen gültigen Bereich. */
export function normalizePageParam(raw: string | undefined, pageCount: number): number {
  const parsed = Number.parseInt(raw ?? "", 10)
  if (!Number.isFinite(parsed) || parsed < 1) return 1
  return Math.min(parsed, Math.max(pageCount, 1))
}

/**
 * Bereinigt den Suchbegriff.
 *
 * Der Rückgabewert wird ausschließlich als **Parameter** an `ilike`
 * weitergereicht, nie in SQL zusammengesetzt. Die Prozentzeichen setzt der
 * Aufrufer; hier werden `%` und `_` maskiert, damit ein Benutzer sie nicht
 * als Platzhalter einschmuggeln kann — sonst fände die Eingabe `%` alles.
 */
export function normalizeSearchTerm(raw: string | undefined): string | null {
  const trimmed = (raw ?? "").trim()
  if (trimmed.length === 0) return null
  return trimmed.slice(0, 120)
}

/** Maskiert die LIKE-Platzhalter eines Suchbegriffs. */
export function escapeLikePattern(term: string): string {
  return term.replace(/[\\%_]/g, (match) => `\\${match}`)
}

/** Anzahl Seiten für eine Treffermenge; mindestens eine, auch bei null Treffern. */
export function computePageCount(total: number, pageSize = REPORT_LIST_PAGE_SIZE): number {
  if (total <= 0) return 1
  return Math.ceil(total / pageSize)
}

/** Kürzt einen Text auf Wortgrenze und meldet, ob gekürzt wurde. */
export function truncateDescription(
  value: string,
  maxLength = REPORT_LIST_DESCRIPTION_LENGTH
): { text: string; truncated: boolean } {
  if (value.length <= maxLength) return { text: value, truncated: false }
  const hardCut = value.slice(0, maxLength)
  const lastSpace = hardCut.lastIndexOf(" ")
  // Nur an der Wortgrenze schneiden, wenn dabei nicht mehr als ein Viertel
  // verlorengeht — sonst steht bei einem sehr langen Wort fast nichts mehr da.
  const text = lastSpace > maxLength * 0.75 ? hardCut.slice(0, lastSpace) : hardCut
  return { text: text.trimEnd(), truncated: true }
}

// ─── Abfrage ────────────────────────────────────────────────────────────────

export type ReportListParams = {
  status: ReportListStatusFilter
  priority: ReportListPriorityFilter
  /** IDs aus der Fälligkeitsprüfung; `null` heißt „kein Retention-Filter". */
  dueReportIds: string[] | null
  search: string | null
  page: number
}

/**
 * Eine Seite der Meldungsliste samt Gesamtzahl.
 *
 * Ausgewählt werden nur die Spalten, die die Liste darstellt. Vorher lud die
 * Seite mit `select()` jede Spalte — einschließlich `reporterName` und
 * `reporterContact`, die in der Liste nirgends erscheinen, aber vollständig
 * im ausgelieferten HTML landeten. Weniger Spalten heißt hier auch weniger
 * personenbezogene Daten im Browser.
 *
 * `dbClient` ist injizierbar für Tests (Default: der reale db-Client).
 */
export async function listReports(
  params: ReportListParams,
  dbClient: DbClient = db
): Promise<ReportListResult> {
  const statusCondition =
    params.status === "all"
      ? undefined
      : params.status === "open_all"
        ? notInArray(reports.status, [...CLOSED_OR_HIDDEN_STATUSES])
        : eq(reports.status, params.status)

  const priorityCondition =
    params.priority === "all" ? undefined : eq(reports.priority, params.priority)

  // „Kritisch" ohne Statusfilter meint die offenen kritischen Meldungen —
  // abgeschlossene sind kein Handlungsbedarf mehr.
  const openCondition =
    params.priority === "critical" && params.status === "all"
      ? notInArray(reports.status, [...CLOSED_OR_HIDDEN_STATUSES])
      : undefined

  const retentionCondition = params.dueReportIds
    ? inArray(reports.id, params.dueReportIds)
    : undefined

  // Der Suchbegriff geht als gebundener Parameter in die Abfrage; Drizzle setzt
  // ihn nicht in den SQL-Text ein. Die Platzhalter der Eingabe sind maskiert.
  const searchCondition = params.search
    ? ilike(reports.shortDescription, `%${escapeLikePattern(params.search)}%`)
    : undefined

  const listFilter = and(
    isNull(reports.deletedAt),
    statusCondition,
    priorityCondition,
    openCondition,
    retentionCondition,
    searchCondition
  )

  const [totalRow] = await dbClient
    .select({ n: count() })
    .from(reports)
    .where(listFilter)

  const total = totalRow?.n ?? 0
  const pageCount = computePageCount(total)
  const page = Math.min(Math.max(params.page, 1), pageCount)

  const rows = await dbClient
    .select({
      id: reports.id,
      reportType: reports.reportType,
      status: reports.status,
      priority: reports.priority,
      shortDescription: reports.shortDescription,
      detailedDescription: reports.detailedDescription,
      createdAt: reports.createdAt,
    })
    .from(reports)
    .where(listFilter)
    // Zweites Sortierkriterium, damit die Seitengrenzen bei gleichem
    // Zeitstempel stabil bleiben — sonst kann eine Meldung zwischen Seite 1
    // und 2 verschwinden oder doppelt erscheinen.
    .orderBy(desc(reports.createdAt), desc(reports.id))
    .limit(REPORT_LIST_PAGE_SIZE)
    .offset((page - 1) * REPORT_LIST_PAGE_SIZE)

  return {
    rows: rows.map((row) => {
      const { text, truncated } = truncateDescription(row.detailedDescription)
      return {
        id: row.id,
        reportType: row.reportType,
        status: row.status,
        priority: row.priority,
        shortDescription: row.shortDescription,
        descriptionExcerpt: text,
        descriptionTruncated: truncated,
        createdAt: row.createdAt,
      }
    }),
    total,
    page,
    pageCount,
  }
}
