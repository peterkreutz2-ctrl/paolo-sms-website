import { getLegalSettings } from "@/lib/legal-settings"
import {
  buildPublicReportPrivacyConsentState,
  type PublicReportPrivacyConsentState,
} from "@/lib/public-report-privacy-consent"

type OrganizationInput = Parameters<typeof buildPublicReportPrivacyConsentState>[0]

/**
 * Laedt die Rechtsangaben und leitet daraus den aktuell geltenden
 * Einwilligungszustand der Organisation ab. Formularseite und Server-Action
 * rufen dieselbe Funktion auf, damit beide denselben Zustand berechnen.
 */
export async function loadPublicReportPrivacyConsentState(
  organization: OrganizationInput
): Promise<PublicReportPrivacyConsentState> {
  const legal = await getLegalSettings()
  return buildPublicReportPrivacyConsentState(organization, legal)
}
