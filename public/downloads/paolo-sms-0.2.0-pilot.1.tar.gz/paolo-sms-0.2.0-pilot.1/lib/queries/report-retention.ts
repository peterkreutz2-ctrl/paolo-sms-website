import { and, desc, eq, inArray, isNotNull, isNull } from "drizzle-orm"

import { db } from "@/lib/db"
import { reportRetentionReviews, reports } from "@/lib/db/schema"
import { computeRetentionReviewStatus } from "@/lib/constants/report-retention"

type DbClient = typeof db

function toYMD(date: Date): string {
  return date.toISOString().slice(0, 10)
}

/**
 * Zentrale Fälligkeitslogik für Dashboard-Kachel und Listenfilter: liefert
 * die IDs aller Reports einer Organisation, die aktuell für eine
 * Aufbewahrungsprüfung überfällig sind — unter Berücksichtigung einer
 * aktiven Verschiebung (`postponed` mit `postponedUntil` in der Zukunft).
 *
 * Die zuletzt protokollierte Entscheidung je Report wird deterministisch
 * nach `createdAt`, bei Gleichstand nach `id` bestimmt (absteigend), damit
 * das Ergebnis bei mehreren Einträgen mit identischem Zeitstempel stabil
 * bleibt.
 *
 * `NULL`-Intervall (Funktion deaktiviert) liefert immer eine leere Liste.
 * `dbClient` ist injizierbar für Tests (Default: der reale db-Client).
 */
export async function getDueReportIds(
  organizationId: string,
  intervalMonths: number | null,
  now: Date = new Date(),
  dbClient: DbClient = db
): Promise<string[]> {
  if (!intervalMonths) return []

  const eligibleReports = await dbClient
    .select({
      id: reports.id,
      retentionReviewEligibleAt: reports.retentionReviewEligibleAt,
      anonymizationStatus: reports.anonymizationStatus,
    })
    .from(reports)
    .where(
      and(
        eq(reports.organizationId, organizationId),
        isNull(reports.deletedAt),
        isNotNull(reports.retentionReviewEligibleAt)
      )
    )

  // "completed" (vollstaendig geprueft, kein Personenbezug mehr erkennbar)
  // erscheint nicht mehr als faellig — "needs_review" (durch neue/geaenderte
  // Inhalte nach der Bestaetigung entstanden) hingegen schon.
  const overdueReportIds = eligibleReports
    .filter(
      (r) =>
        r.anonymizationStatus !== "completed" &&
        computeRetentionReviewStatus(r.retentionReviewEligibleAt, intervalMonths, now) ===
          "overdue"
    )
    .map((r) => r.id)

  if (overdueReportIds.length === 0) return []

  const reviewRows = await dbClient
    .select({
      id: reportRetentionReviews.id,
      reportId: reportRetentionReviews.reportId,
      decision: reportRetentionReviews.decision,
      postponedUntil: reportRetentionReviews.postponedUntil,
      createdAt: reportRetentionReviews.createdAt,
    })
    .from(reportRetentionReviews)
    .where(inArray(reportRetentionReviews.reportId, overdueReportIds))
    .orderBy(desc(reportRetentionReviews.createdAt), desc(reportRetentionReviews.id))

  const latestDecisionByReport = new Map<string, (typeof reviewRows)[number]>()
  for (const row of reviewRows) {
    if (!latestDecisionByReport.has(row.reportId)) {
      latestDecisionByReport.set(row.reportId, row)
    }
  }

  const todayYMD = toYMD(now)

  return overdueReportIds.filter((reportId) => {
    const latest = latestDecisionByReport.get(reportId)
    if (!latest) return true
    if (latest.decision === "postponed" && latest.postponedUntil) {
      const isActivePostponement = latest.postponedUntil >= todayYMD
      if (isActivePostponement) return false
    }
    return true
  })
}
