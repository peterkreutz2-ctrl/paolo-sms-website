import { and, desc, eq, inArray, isNotNull, isNull, or, sql } from "drizzle-orm"

import { db } from "@/lib/db"
import { organizations, reports } from "@/lib/db/schema"
import {
  PUBLIC_REPORT_CLOSED_VISIBILITY_MONTHS,
  PUBLIC_REPORT_STATUS_MAX_ENTRIES,
  PUBLIC_REPORT_STATUS_PAGE_SIZE,
  PUBLIC_REPORT_VISIBILITY_TIME_ZONE,
  PUBLICLY_VISIBLE_REPORT_STATUSES,
  publicReportStatusLabel,
} from "@/lib/constants/public-report-status"

// ─── Die oeffentliche Statusliste ────────────────────────────────────────────
//
// Diese Abfrage ist die einzige Stelle, an der Meldungsdaten den anonymen
// Bereich erreichen. Sie ist deshalb absichtlich schmal gehalten: Sie
// selektiert **zwei Spalten** und liefert eine Zeile aus Code und
// uebersetztem Status. Kein Titel, keine Kategorie, keine interne ID, kein
// Datum — auch nicht "unsichtbar mitgeliefert".
//
// Der Organisationsschalter wird HIER ausgewertet, nicht in der Darstellung.
// Ist er aus, gibt es nichts zurueckzuhalten: Die Oberflaeche kann dann gar
// nicht mehr anzeigen, was die Datenschicht nie geliefert hat.

export type PublicReportStatusEntry = {
  code: string
  statusLabel: string
}

export type PublicReportStatusList =
  | { enabled: false }
  | {
      enabled: true
      entries: PublicReportStatusEntry[]
      /** Gibt es hinter dem gezeigten Ausschnitt noch weitere Eintraege? */
      hasMore: boolean
      /** Wie viele Eintraege ein "Weitere anzeigen" als naechstes zeigen wuerde. */
      nextLimit: number
    }

/**
 * Liest die oeffentliche Statusliste einer Organisation.
 *
 * Sichtbar ist eine Meldung, wenn sie **alle** Bedingungen erfuellt:
 *
 *   1. Die Organisation hat die Anzeige eingeschaltet.
 *   2. Sie hat einen Meldungscode — den bekommen Meldungen aus dem
 *      oeffentlichen Formular und das ausdrueckliche Operator-Spieldaten-
 *      Fixture; Importe und Bestand haben keinen.
 *   3. Sie liegt nicht im Papierkorb (`deleted_at IS NULL`). Das ist der
 *      zweite, vom Antrag nicht genannte "Ausblenden"-Mechanismus neben dem
 *      Status "hidden".
 *   4. Ihr Status steht auf der Positivliste — "hidden" steht nicht darauf.
 *   5. Ist sie abgeschlossen, liegt der Abschluss weniger als drei
 *      Kalendermonate zurueck.
 *
 * Zur Fristbedingung: Gerechnet wird **vorwaerts vom Abschluss**, nicht
 * rueckwaerts von heute. Das ist nicht dasselbe: PostgreSQL kappt bei der
 * Monatsarithmetik auf den letzten gueltigen Tag des Zielmonats, und diese
 * Kappung ist nicht umkehrbar. Ein Abschluss am 30.11. ergibt vorwaerts den
 * 28.02.; rueckwaerts ergaebe der 28.02. den 28.11., und die Meldung stuende
 * einen Tag zu lang. `AT TIME ZONE` macht daraus Wanduhr-Arithmetik in einer
 * festen Zone, damit zwei Installationen mit verschiedener Sitzungszeitzone
 * dasselbe tun. Dieselbe Regel steht als pruefbare reine Funktion in
 * lib/constants/public-report-status.ts (`publicVisibilityEndsAt`).
 */
export async function getPublicReportStatusList(
  limit: number = PUBLIC_REPORT_STATUS_PAGE_SIZE
): Promise<PublicReportStatusList> {
  const [organization] = await db
    .select({
      id: organizations.id,
      publicReportStatusEnabled: organizations.publicReportStatusEnabled,
    })
    .from(organizations)
    .limit(1)

  if (!organization || !organization.publicReportStatusEnabled) {
    return { enabled: false }
  }

  const effectiveLimit = Math.min(limit, PUBLIC_REPORT_STATUS_MAX_ENTRIES)

  // Eine Zeile mehr holen, als gezeigt wird: So ist "gibt es noch mehr?"
  // beantwortet, ohne eine zweite Zaehlabfrage zu stellen.
  const rows = await db
    .select({
      code: reports.publicCode,
      status: reports.status,
    })
    .from(reports)
    .where(
      and(
        eq(reports.organizationId, organization.id),
        isNotNull(reports.publicCode),
        isNull(reports.deletedAt),
        inArray(reports.status, [...PUBLICLY_VISIBLE_REPORT_STATUSES]),
        or(
          sql`${reports.status} <> 'closed'`,
          and(
            isNotNull(reports.publicClosedAt),
            sql`(${reports.publicClosedAt} AT TIME ZONE ${PUBLIC_REPORT_VISIBILITY_TIME_ZONE})
                  + make_interval(months => ${PUBLIC_REPORT_CLOSED_VISIBILITY_MONTHS})
                > (now() AT TIME ZONE ${PUBLIC_REPORT_VISIBILITY_TIME_ZONE})`
          )
        )
      )
    )
    // createdAt sortiert nur; es wird nicht ausgewaehlt und nie ausgeliefert.
    // id als Stichentscheid, damit das Blaettern bei gleicher Sekunde keine
    // Zeile ueberspringt oder doppelt zeigt.
    .orderBy(desc(reports.createdAt), desc(reports.id))
    .limit(effectiveLimit + 1)

  const hasMore = rows.length > effectiveLimit

  const entries = rows.slice(0, effectiveLimit).flatMap((row) => {
    const statusLabel = publicReportStatusLabel(row.status)
    // Doppelter Boden: Die Abfrage filtert bereits auf die Positivliste. Faende
    // sich hier dennoch ein unbekannter oder nicht oeffentlicher Status, faellt
    // die Zeile weg, statt mit dem Rohwert angezeigt zu werden.
    if (!statusLabel || !row.code) return []
    return [{ code: row.code, statusLabel }]
  })

  return {
    enabled: true,
    entries,
    hasMore,
    nextLimit: Math.min(
      effectiveLimit + PUBLIC_REPORT_STATUS_PAGE_SIZE,
      PUBLIC_REPORT_STATUS_MAX_ENTRIES
    ),
  }
}
