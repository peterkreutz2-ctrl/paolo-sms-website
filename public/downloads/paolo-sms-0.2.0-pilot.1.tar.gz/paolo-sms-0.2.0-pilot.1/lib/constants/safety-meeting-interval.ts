// Turnus der Sicherheitsbesprechung: zulaessiger Bereich und die Schwelle, ab
// der die Einstellungsseite einen fachlichen Warnhinweis zeigt.
//
// Warum hier und nicht je einmal im Zod-Schema und im Formular: Die Obergrenze
// stand vorher doppelt da (max=120 im <input>, .max(120) im Schema). Beide
// Stellen muessen zusammenpassen, sonst laesst das Formular etwas zu, das der
// Server ablehnt — oder umgekehrt.
//
// Der Bereich ist eine fachliche Vorgabe, keine technische: 24 Monate sind das
// Aeusserste, was als Turnus noch vertretbar ist. Die Schwelle liegt tiefer als
// die Obergrenze, weil schon der Jahresturnus das Minimum und nicht das Ziel
// ist. Der Hinweis ist deshalb ausdruecklich KEINE Validierungsregel: Ein
// zulaessiger Wert bleibt zulaessig, die Entscheidung liegt beim Betreiber.

export const SAFETY_MEETING_INTERVAL_MIN_MONTHS = 1
export const SAFETY_MEETING_INTERVAL_MAX_MONTHS = 24

// OBERHALB dieses Werts wird gewarnt, nicht ab ihm. Der Jahresturnus (12) ist
// die fachliche Mindestanforderung und gilt selbst nicht als warnwuerdig; der
// Standardwert der Organisation ist 12 und traegt deshalb keinen Hinweis.
export const SAFETY_MEETING_INTERVAL_WARN_ABOVE_MONTHS = 12

export const SAFETY_MEETING_INTERVAL_WARNING =
  "Sicherheitsbesprechungen sollten mindestens einmal jährlich, idealerweise " +
  "vierteljährlich stattfinden. Bei akuten Anlässen wie schweren Unfällen " +
  "sollten zusätzlich außerordentliche Sicherheitsbesprechungen einberufen " +
  "werden."

// Reine Funktion, damit Formular und Tests dieselbe Regel benutzen. Nicht
// eingegebene oder unlesbare Werte warnen nicht — dafuer ist die Validierung
// zustaendig, und eine Warnung neben einer Fehlermeldung waere Laerm.
export function shouldWarnAboutSafetyMeetingInterval(
  months: number | null | undefined
): boolean {
  if (months === null || months === undefined) return false
  if (!Number.isFinite(months)) return false
  return months > SAFETY_MEETING_INTERVAL_WARN_ABOVE_MONTHS
}
