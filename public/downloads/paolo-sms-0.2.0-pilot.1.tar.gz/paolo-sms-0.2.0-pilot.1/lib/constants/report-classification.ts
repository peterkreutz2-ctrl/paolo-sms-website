export const ACTIVITY_AREA_VALUES = [
  "paragliding",
  "hang_gliding",
  "powered_paragliding",
  "speed_riding",
  "parakite",
  "other",
] as const

export type ActivityArea = (typeof ACTIVITY_AREA_VALUES)[number]

export const ACTIVITY_AREA_LABELS: Record<ActivityArea, string> = {
  paragliding: "Gleitschirm",
  hang_gliding: "Hängegleiter",
  powered_paragliding: "Motorschirm",
  speed_riding: "Speedriding",
  parakite: "Parakite",
  other: "Sonstiges",
}

export const ACTIVITY_TYPE_VALUES = [
  "trial_course",
  "basic_training",
  "high_flight_training",
  "b_license_training",
  "other_training",
  "safety_training",
  "supervised_flying",
  "solo_flight",
  "tandem",
  "cross_country",
  "competition",
  "other",
] as const

export type ActivityType = (typeof ACTIVITY_TYPE_VALUES)[number]

export const ACTIVITY_TYPE_LABELS: Record<ActivityType, string> = {
  trial_course: "Schnupperkurs",
  basic_training: "Grundausbildung",
  high_flight_training: "Höhenflugausbildung",
  b_license_training: "B-Schein-Ausbildung",
  other_training: "Andere Ausbildung",
  safety_training: "Sicherheitstraining",
  supervised_flying: "Betreutes Fliegen",
  solo_flight: "Eigenflug",
  tandem: "Tandemflug",
  cross_country: "Streckenflug",
  competition: "Wettkampf",
  other: "Sonstiges",
}

export const FLIGHT_PHASE_VALUES = [
  "pre_flight",
  "groundhandling",
  "launch",
  "flight",
  "landing",
  "post_flight",
  "not_applicable",
] as const

export type FlightPhase = (typeof FLIGHT_PHASE_VALUES)[number]

export const FLIGHT_PHASE_LABELS: Record<FlightPhase, string> = {
  pre_flight: "Vorflugcheck",
  groundhandling: "Groundhandling",
  launch: "Start",
  flight: "Flug",
  landing: "Landung",
  post_flight: "Nachflug",
  not_applicable: "Nicht zutreffend",
}

export const LAUNCH_TYPE_VALUES = [
  "hill_launch",
  "winch_launch",
  "other",
  "not_applicable",
] as const

export type LaunchType = (typeof LAUNCH_TYPE_VALUES)[number]

export const LAUNCH_TYPE_LABELS: Record<LaunchType, string> = {
  hill_launch: "Hangstart",
  winch_launch: "Windenstart",
  other: "Andere",
  not_applicable: "Nicht zutreffend",
}

export const SEVERITY_VALUES = [
  "no_damage",
  "material_damage_only",
  "minor_injury",
  "serious_injury",
  "fatal",
] as const

export type Severity = (typeof SEVERITY_VALUES)[number]

export const SEVERITY_LABELS: Record<Severity, string> = {
  no_damage: "Kein Schaden",
  material_damage_only: "Nur Sachschaden",
  minor_injury: "Leichte Verletzung",
  serious_injury: "Schwere Verletzung",
  fatal: "Tödlich",
}

export const REPORTER_ROLE_VALUES = [
  "flight_instructor",
  "launch_director",
  "winch_operator",
  "involved_pilot",
  "trip_leader",
  "helper",
  "witness",
] as const

export type ReporterRole = (typeof REPORTER_ROLE_VALUES)[number]

export const REPORTER_ROLE_LABELS: Record<ReporterRole, string> = {
  flight_instructor: "Fluglehrer/in",
  launch_director: "Startleiter/in",
  winch_operator: "Windenführer/in",
  involved_pilot: "Beteiligter Pilot / Beteiligte Pilotin",
  trip_leader: "Reiseleiter/in",
  helper: "Helfer/in",
  witness: "Zeuge / Zeugin",
}

export const INJURY_SEVERITY_VALUES = [
  "none",
  "minor",
  "serious",
  "fatal",
] as const

export type InjurySeverity = (typeof INJURY_SEVERITY_VALUES)[number]

export const INJURY_SEVERITY_LABELS: Record<InjurySeverity, string> = {
  none: "Keine Verletzung",
  minor: "Leichte Verletzung",
  serious: "Schwere Verletzung",
  fatal: "Tödlich",
}

export const DAMAGE_SEVERITY_VALUES = [
  "none",
  "minor",
  "major",
  "aircraft_destroyed",
] as const

export type DamageSeverity = (typeof DAMAGE_SEVERITY_VALUES)[number]

export const DAMAGE_SEVERITY_LABELS: Record<DamageSeverity, string> = {
  none: "Kein Sachschaden",
  minor: "Geringer Sachschaden",
  major: "Großer Sachschaden",
  aircraft_destroyed: "Fluggerät zerstört",
}
