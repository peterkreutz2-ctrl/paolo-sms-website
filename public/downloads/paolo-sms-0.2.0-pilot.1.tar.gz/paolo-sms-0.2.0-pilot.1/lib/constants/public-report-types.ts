/** Display order: severity / urgency (highest first). Same values as before. */
export const PUBLIC_REPORT_TYPE_VALUES = [
  "accident",
  "near_miss",
  "hazard",
  "observation",
  "suggestion",
  "other",
] as const

export type PublicReportType = (typeof PUBLIC_REPORT_TYPE_VALUES)[number]

export const PUBLIC_REPORT_TYPE_LABELS: Record<PublicReportType, string> = {
  accident: "Unfall",
  observation: "Beobachtung oder Hinweis",
  near_miss: "Beinahe-Ereignis oder kritische Situation",
  hazard: "Gefahrenquelle oder Mangel",
  suggestion: "Idee zur Verbesserung der Sicherheit",
  other: "Etwas anderes",
}

export const PUBLIC_REPORT_SHORT_DESCRIPTION_PLACEHOLDERS: Record<
  PublicReportType,
  string
> = {
  accident: "z. B. misslungene Toplandung mit schwerer Verletzung",
  near_miss: "z. B. seitlicher Einklapper mit Verhänger",
  hazard:
    "z. B. Inkompatibilität des Rettungsgerätes X mit dem Gurtzeug Y",
  observation:
    "z. B. Brummellocks sind besonders hilfreich beim Windenschlepp",
  other: "z. B. eine Nachricht an den Safety Manager",
  suggestion:
    "z. B. im Landebereich sollten keine Autos geparkt werden",
}

/** UI guidance groups — DB values stay on `PublicReportType`. */
export type PublicReportGuidanceGroup = "accident" | "observation" | "suggestion"

export function getPublicReportGuidanceGroup(
  reportType: PublicReportType
): PublicReportGuidanceGroup {
  if (reportType === "accident" || reportType === "near_miss") {
    return "accident"
  }
  if (reportType === "suggestion") {
    return "suggestion"
  }
  return "observation"
}

type GuidanceCopy = {
  infoBoxTitle: string
  infoBoxBody: string
  detailsSectionTitle: string
  detailsSectionLead: string
  shortHelper: string
  detailPlaceholder: string
  detailHelper: string
}

export const PUBLIC_REPORT_GUIDANCE: Record<
  PublicReportGuidanceGroup,
  GuidanceCopy
> = {
  accident: {
    infoBoxTitle: "Worauf es bei Unfällen und Beinahe-Ereignissen ankommt",
    infoBoxBody:
      "Beschreibe möglichst detailliert, was passiert ist, wo und wann es geschah, ob es Verletzungen oder Sachschäden gab, welche Geräte betroffen waren und wie die Witterung war.",
    detailsSectionTitle: "Was ist passiert?",
    detailsSectionLead:
      "Schildere den Ablauf sachlich. Ort, Zeit und beteiligte Mittel helfen uns, das Geschehen zu verstehen — ohne Schuldfrage.",
    shortHelper: "Eine Zeile, die den Kern des Vorfalls zusammenfasst.",
    detailPlaceholder:
      "Was genau ist passiert? Wo und ungefähr wann? Gab es Verletzungen oder Schäden? Welche Geräte oder Mittel spielten eine Rolle? Wie war die Witterung, falls relevant?",
    detailHelper:
      "Folgende Angaben können hilfreich sein:\n- Beteiligte Piloten: Name, Alter, Ausbildungsstand, Übungsstand.\n- Verwendete Ausrüstung (Gleitschirm, Gurtzeug, Rettung, Motor ...)\n- Tatsächliches und vorhergesagtes Wetter sowie Quellen der Wetterinformationen.\n- Was ist vorgefallen oder beobachtet worden?\n- Kontaktdaten von Zeugen\n- Ggf. Verbleib der Ausrüstung und sichergestellte Beweisstücke.",
  },
  observation: {
    infoBoxTitle: "Worauf es bei Beobachtungen und Hinweisen ankommt",
    infoBoxBody:
      "Beschreibe, was du wahrgenommen hast und unter welchen Umständen (Ort, Tätigkeit, Bedingungen). Überlege, ob es auf ein wiederkehrendes Risiko oder eine systematische Schwachstelle hindeuten könnte — wenn dir das auffällt.",
    detailsSectionTitle: "Was hast du beobachtet?",
    detailsSectionLead:
      "Sachliche Schilderung reicht. Ort, Zeit und Rahmen helfen — Namen nur, wenn sie für das Verständnis nötig sind.",
    shortHelper: "Eine Zeile, die den Kern deiner Beobachtung zusammenfasst.",
    detailPlaceholder:
      "Was genau ist dir aufgefallen? In welcher Situation? Könnte es ein wiederkehrendes Risiko oder ein Muster sein?",
    detailHelper:
      "Konkrete Beobachtungen helfen uns, Muster zu erkennen. Es reicht, was du sicher weißt — nichts erfinden.",
  },
  suggestion: {
    infoBoxTitle: "Worauf es bei Verbesserungsideen ankommt",
    infoBoxBody:
      "Beschreibe, welche Verbesserung du vorschlägst und welches Sicherheitsproblem oder welche Gefahr sie adressieren soll. Wenn du einen konkreten Ort oder Ablauf im Kopf hast, nenne ihn.",
    detailsSectionTitle: "Dein Vorschlag",
    detailsSectionLead:
      "Formuliere die Idee und den Bezug zur Sicherheit so klar du kannst — auch ohne technische Lösung im Detail.",
    shortHelper: "Eine Zeile, die deine Idee und den Nutzen kurz fasst.",
    detailPlaceholder:
      "Welche Verbesserung schlägst du vor? Welches Sicherheitsproblem oder welche Gefahr soll damit behoben oder verringert werden?",
    detailHelper:
      "Je klarer Problem und Idee, desto besser können wir deinen Vorschlag einordnen. Es reicht, was du sicher weißt — nichts erfinden.",
  },
}
