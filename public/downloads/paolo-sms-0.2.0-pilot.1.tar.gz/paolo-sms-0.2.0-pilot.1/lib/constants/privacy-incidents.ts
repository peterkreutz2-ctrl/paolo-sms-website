// Konstanten für Datenschutzvorfälle (Incident-Response).
//
// PAOLO dokumentiert Vorfälle nur — es trifft keine rechtliche Entscheidung und
// versendet keine automatische Meldung. Die Bewertung obliegt Betreiber bzw.
// Datenschutzbeauftragten.

export const INCIDENT_STATUS_VALUES = [
  "new",
  "investigating",
  "notification_check",
  "notified",
  "closed",
] as const

export type IncidentStatus = (typeof INCIDENT_STATUS_VALUES)[number]

export const INCIDENT_STATUS_LABELS: Record<IncidentStatus, string> = {
  new: "Neu",
  investigating: "In Untersuchung",
  notification_check: "Meldeprüfung",
  notified: "Gemeldet",
  closed: "Abgeschlossen",
}

export const INCIDENT_RISK_VALUES = [
  "unknown",
  "low",
  "medium",
  "high",
] as const

export type IncidentRisk = (typeof INCIDENT_RISK_VALUES)[number]

export const INCIDENT_RISK_LABELS: Record<IncidentRisk, string> = {
  unknown: "Unbekannt",
  low: "Niedrig",
  medium: "Mittel",
  high: "Hoch",
}

export const INCIDENT_NOTIFICATION_DECISION_VALUES = [
  "open",
  "not_required",
  "authority_required",
  "affected_persons_required",
  "completed",
] as const

export type IncidentNotificationDecision =
  (typeof INCIDENT_NOTIFICATION_DECISION_VALUES)[number]

export const INCIDENT_NOTIFICATION_DECISION_LABELS: Record<
  IncidentNotificationDecision,
  string
> = {
  open: "Offen / noch zu prüfen",
  not_required: "Keine Meldung erforderlich",
  authority_required: "Meldung an Aufsichtsbehörde erforderlich",
  affected_persons_required: "Benachrichtigung Betroffener erforderlich",
  completed: "Meldung/Benachrichtigung erfolgt",
}

// Gesetzliche Orientierungsfrist (Art. 33 DSGVO): 72 Stunden ab Kenntnisnahme.
// Reiner Hinweis — keine automatische Meldung.
export const INCIDENT_NOTIFICATION_DEADLINE_HOURS = 72
