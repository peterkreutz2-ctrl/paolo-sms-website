// Freigabepruefung fuer die Veroeffentlichung eines Anhangs (AP3).
//
// Diese Datei ist die einzige Quelle fuer Hinweistext, Checkliste und deren
// Version. Formular, Zod-Schema und Audit-Payload leiten sich daraus ab und
// definieren nichts eigenes.
//
// Warum eine Version: Die Checkliste wird sich fachlich weiterentwickeln. Ein
// Audit-Eintrag "alle Punkte bestaetigt" ist nur dann etwas wert, wenn
// nachvollziehbar bleibt, WELCHE Punkte das waren. Bei jeder inhaltlichen
// Aenderung an CHECKLIST_ITEMS muss deshalb die Version erhoeht werden.
//
// Warum keine Boolean-Spalten pro Punkt: In einer gespeicherten Zeile koennten
// sie nur `true` enthalten, weil ohne vollstaendige Bestaetigung nicht
// gespeichert wird. Eine Spalte, die nur einen Wert annehmen kann, traegt null
// Information und suggeriert trotzdem Pruefungstiefe. Der bestaetigte Zustand
// gehoert in das Audit-Ereignis, wo der Zeitstempel ihm Bedeutung gibt.

export const ATTACHMENT_RELEASE_CHECKLIST_VERSION = 1

export type AttachmentReleaseChecklistItem = {
  key: string
  label: string
  /** Nur fuer Tracklogs (IGC/GPX/KML) einzublenden und zu verlangen. */
  tracklogOnly?: true
}

// Reihenfolge ist bewusst gewaehlt: erst was auf dem Material zu sehen ist,
// dann die Rechtelage, zuletzt die fachliche Rechtfertigung.
export const ATTACHMENT_RELEASE_CHECKLIST: readonly AttachmentReleaseChecklistItem[] =
  [
    {
      key: "no_personal_data",
      label:
        "Es sind keine personenbezogenen Daten erkennbar – keine Namen, Kennzeichen, Kontaktdaten oder identifizierenden Falldetails.",
    },
    {
      key: "no_identifiable_persons",
      label:
        "Es sind keine unbeteiligten Personen erkennbar, oder die abgebildeten Personen haben der Veröffentlichung zugestimmt (Recht am eigenen Bild).",
    },
    {
      key: "no_audio_recordings",
      label:
        "Es sind keine Ton- oder Stimmaufnahmen Dritter enthalten, oder deren Einwilligung liegt vor.",
    },
    {
      key: "usage_rights_cleared",
      label:
        "Die Urheber- und Nutzungsrechte am Material sind geklärt; eine Veröffentlichung ist zulässig.",
    },
    {
      key: "consents_available",
      label:
        "Alle darüber hinaus erforderlichen Einwilligungen oder Genehmigungen liegen vor.",
    },
    {
      key: "tracklog_positions_checked",
      tracklogOnly: true,
      label:
        "Tracklog geprüft: Der Header enthält keinen Pilotennamen, und die Veröffentlichung von Startplatz, Zeitstempeln und der genauen Flugspur ist bewusst gewollt.",
    },
    {
      key: "publication_justified",
      label:
        "Die Veröffentlichung dient erkennbar dem Sicherheitszweck des Dokuments.",
    },
  ]

/**
 * Hinweistext unmittelbar an der Freigabe. Bewusst kurz und konkret — er steht
 * im Dialog direkt neben der Vorschau des betroffenen Anhangs, nicht
 * irgendwo in der Dokumentation.
 */
export const ATTACHMENT_RELEASE_WARNING =
  "Diese Datei wird nach der Freigabe ohne Anmeldung im Internet abrufbar. Prüfen Sie sie vorher vollständig – eine Veröffentlichung lässt sich zwar zurücknehmen, aber nicht ungeschehen machen: Kopien können bereits verbreitet sein."

const TRACKLOG_EXTENSIONS = new Set(["igc", "gpx", "kml"])

/**
 * Ist dieser Anhang ein Tracklog? Entscheidet, ob der zusaetzliche
 * Checklistenpunkt zu Positionsdaten verlangt wird. Der MIME-Typ taugt dafuer
 * nicht: fuer .igc liefern Browser haeufig gar keinen (siehe
 * lib/constants/attachment-file-types.ts).
 */
export function isTracklogFileName(fileName: string): boolean {
  const lastDot = fileName.lastIndexOf(".")
  if (lastDot <= 0 || lastDot === fileName.length - 1) return false
  return TRACKLOG_EXTENSIONS.has(fileName.slice(lastDot + 1).toLowerCase())
}

/** Die fuer diesen Anhang tatsaechlich zu bestaetigenden Punkte. */
export function getRequiredChecklistItems(
  fileName: string
): readonly AttachmentReleaseChecklistItem[] {
  const isTracklog = isTracklogFileName(fileName)
  return ATTACHMENT_RELEASE_CHECKLIST.filter(
    (item) => !item.tracklogOnly || isTracklog
  )
}

export function getRequiredChecklistKeys(fileName: string): string[] {
  return getRequiredChecklistItems(fileName).map((item) => item.key)
}

/**
 * Sind alle fuer diesen Anhang noetigen Punkte bestaetigt? Reine Funktion,
 * damit die Regel unabhaengig von Formular und Server pruefbar bleibt.
 * Unbekannte Schluessel werden ignoriert, fehlende fuehren zu `false`.
 */
export function areAllChecklistItemsConfirmed(
  fileName: string,
  confirmedKeys: readonly string[]
): boolean {
  const confirmed = new Set(confirmedKeys)
  return getRequiredChecklistKeys(fileName).every((key) => confirmed.has(key))
}

// Freigabevermerk: kurzer Pflicht-Freitext. Die Untergrenze ist bewusst
// niedrig, aber nicht null — sie soll ein versehentliches Absenden verhindern,
// nicht eine Mindestwortzahl erzwingen.
export const RELEASE_NOTE_MIN_LENGTH = 10
export const RELEASE_NOTE_MAX_LENGTH = 1000
