// ─── Oeffentliche Statusrueckmeldung: Abbildung und Frist ────────────────────
//
// Der oeffentliche Status wird aus dem internen Workflow-Status abgeleitet.
// Es gibt keine zweite, manuell gepflegte Statusverwaltung und keinen
// Freigabeschritt — genau das war die Bedingung des Antrags: keine zusaetzliche
// laufende Pflege fuer Vereine und Flugschulen.

import {
  REPORT_STATUS_VALUES,
  type ReportStatus,
} from "./report-workflow"

/**
 * Was die Oeffentlichkeit zu einem Status zu sehen bekommt.
 *
 * `null` heisst: **kein oeffentlicher Eintrag**. Heute betrifft das nur
 * "hidden"; die Meldung verschwindet dann sofort aus der Liste, und der Status
 * selbst wird nie angezeigt.
 *
 * Warum `Record<ReportStatus, …>` und nicht `Partial<…>`:
 *
 * Ein neuer Wert in REPORT_STATUS_VALUES bricht diese Tabelle, bis jemand ihn
 * hier ausdruecklich einordnet. Damit kann ein spaeter ergaenzter Status nicht
 * versehentlich oeffentlich werden — und ebenso wenig versehentlich fehlen.
 * Die Alternative (eine Ausschlussliste "alles ausser hidden") haette den
 * umgekehrten, gefaehrlicheren Fehlerfall: unbekannt = sichtbar.
 * tests/report-workflow/public-report-status.test.ts sichert das zusaetzlich
 * zur Laufzeit ab.
 *
 * Die Beschriftungen weichen bewusst von REPORT_STATUS_LABELS ab, wo die
 * interne Bezeichnung technisch gewachsen ist: oeffentlich steht die
 * gebraeuchliche deutsche Schreibweise.
 */
export const PUBLIC_REPORT_STATUS_LABELS: Record<ReportStatus, string | null> = {
  new: "Neu",
  in_review: "In Prüfung",
  in_progress: "In Bearbeitung",
  measures_defined: "Maßnahmen beschlossen",
  closed: "Abgeschlossen",
  hidden: null,
}

/**
 * Die Positivliste fuer die Datenbankabfrage — abgeleitet, nicht abgeschrieben.
 *
 * Eine zweite, von Hand gepflegte Statusliste im SQL waere genau das Muster,
 * das report-workflow.ts im Kommentar zur closed/hidden-Gruppe als bereits
 * einmal begangenen Fehler beschreibt: Zwei Stellen, die dasselbe wissen
 * muessen, und eine davon wird beim naechsten Mal vergessen.
 */
export const PUBLICLY_VISIBLE_REPORT_STATUSES: readonly ReportStatus[] =
  REPORT_STATUS_VALUES.filter(
    (status) => PUBLIC_REPORT_STATUS_LABELS[status] !== null
  )

/** Darf dieser Status ueberhaupt oeffentlich erscheinen? */
export function isPubliclyVisibleStatus(status: string): boolean {
  return (PUBLICLY_VISIBLE_REPORT_STATUSES as readonly string[]).includes(
    status
  )
}

/**
 * Oeffentliche Beschriftung zu einem gespeicherten Statuswert — oder `null`,
 * wenn er nicht oeffentlich gehoert. Unbekannte Werte (etwa aus einem
 * Datenbestand, der einer aelteren Fassung entstammt) gelten als nicht
 * oeffentlich; im Zweifel wird nichts angezeigt.
 */
export function publicReportStatusLabel(status: string): string | null {
  return PUBLIC_REPORT_STATUS_LABELS[status as ReportStatus] ?? null
}

// ─── Die Dreimonatsfrist ─────────────────────────────────────────────────────

/** Wie lange eine abgeschlossene Meldung oeffentlich sichtbar bleibt. */
export const PUBLIC_REPORT_CLOSED_VISIBILITY_MONTHS = 3

/**
 * Zeitzone, in der die Monatsarithmetik der Frist gerechnet wird.
 *
 * Ohne ausdrueckliche Zone rechnete PostgreSQL in der Sitzungszeitzone — und
 * die ist je nach Installation verschieden (Container und Vercel laufen
 * ueblicherweise auf UTC, eine lokale Entwicklungsdatenbank nicht). Zwei
 * Installationen verhielten sich dann an der Monatsgrenze unterschiedlich.
 * Es geht hier nicht um die paar Stunden, sondern um Reproduzierbarkeit.
 */
export const PUBLIC_REPORT_VISIBILITY_TIME_ZONE = "Europe/Berlin"

/**
 * Reine Funktion (kein DB-Zugriff): entscheidet, ob/wie
 * reports.publicClosedAt bei einem Statuswechsel zu setzen ist.
 *
 * Die Regel ist bewusst schmal: **nur der Wechsel NACH "closed"** setzt den
 * Anker. Daraus folgt alles, was der Antrag verlangt:
 *
 *   - Das erneute Speichern einer bereits abgeschlossenen Meldung — etwa nur
 *     zur Aenderung der Prioritaet — startet die Frist NICHT neu, weil dabei
 *     kein Wechsel stattfindet.
 *   - Wiedereroeffnung laesst den Anker stehen; er ist dann bedeutungslos,
 *     weil die Frist nur fuer "closed" gilt, und die Meldung erscheint wieder
 *     mit ihrem neuen Status.
 *   - Ein erneuter Abschluss danach ist wieder ein Wechsel und startet die
 *     Frist neu.
 *
 * Ein fehlendes Feld im Ergebnis heisst "unveraendert lassen" und darf nicht
 * in ein DB-Update uebernommen werden — dasselbe Muster wie bei
 * computeRetentionReviewEligibleAtUpdate.
 */
export function computePublicClosedAtUpdate(
  previousStatus: string,
  nextStatus: string,
  now: Date = new Date()
): { publicClosedAt?: Date } {
  if (nextStatus === "closed" && previousStatus !== "closed") {
    return { publicClosedAt: now }
  }
  return {}
}

/**
 * Ortszeit-Bestandteile eines Zeitpunkts in
 * PUBLIC_REPORT_VISIBILITY_TIME_ZONE.
 *
 * Der Umweg ueber Intl ist noetig, weil `Date` nur UTC und die Zeitzone des
 * laufenden Prozesses kennt — und die ist auf einem Server eine andere als in
 * der Datenbank.
 */
function zonedParts(instant: Date): {
  year: number
  month: number
  day: number
  hour: number
  minute: number
  second: number
} {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: PUBLIC_REPORT_VISIBILITY_TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).formatToParts(instant)

  const get = (type: string) => {
    const raw = parts.find((part) => part.type === type)?.value ?? "0"
    // Intl liefert Mitternacht je nach Umgebung als "24"; beides meint
    // denselben Moment am Tagesbeginn.
    return raw === "24" ? 0 : Number(raw)
  }

  return {
    year: get("year"),
    month: get("month"),
    day: get("day"),
    hour: get("hour"),
    minute: get("minute"),
    second: get("second"),
  }
}

/** Wie viele Tage der angegebene Monat hat (month ist 1-basiert). */
function daysInMonth(year: number, month: number): number {
  return new Date(Date.UTC(year, month, 0)).getUTCDate()
}

/**
 * Vergleichsschluessel einer Ortszeit: JJJJMMTTHHMMSS als Zahl. Zwei
 * Ortszeiten derselben Zone lassen sich damit vergleichen, ohne sie in
 * Zeitpunkte zurueckzuverwandeln.
 */
function wallClockKey(p: {
  year: number
  month: number
  day: number
  hour: number
  minute: number
  second: number
}): number {
  return (
    p.year * 1e10 +
    p.month * 1e8 +
    p.day * 1e6 +
    p.hour * 1e4 +
    p.minute * 1e2 +
    p.second
  )
}

/**
 * Ortszeit, zu der eine zu `closedAt` abgeschlossene Meldung aus der
 * oeffentlichen Liste verschwindet: **Abschlusszeitpunkt plus drei
 * Kalendermonate**, mit Kappung auf den letzten gueltigen Tag des Zielmonats
 * (30.11. + 3 Monate = 28.02., im Schaltjahr 29.02.; 31.08. + 3 Monate =
 * 30.11.).
 *
 * Warum Ortszeit und nicht ein Zeitpunkt: Die SQL-Bedingung in
 * lib/queries/public-report-status.ts rechnet mit
 * `(public_closed_at AT TIME ZONE '…') + interval '3 months'` — also
 * Wanduhr-Arithmetik ohne Sommerzeitsprung. Diese Funktion bildet genau das
 * ab. Wuerde sie stattdessen einen UTC-Zeitpunkt bilden, laege sie ueber einer
 * Zeitumstellung hinweg um eine Stunde daneben, und die pruefbare Regel waere
 * nicht mehr dieselbe wie die laufende.
 */
export function publicVisibilityEndsAt(closedAt: Date): {
  year: number
  month: number
  day: number
  hour: number
  minute: number
  second: number
} {
  const start = zonedParts(closedAt)

  const monthIndex =
    start.month - 1 + PUBLIC_REPORT_CLOSED_VISIBILITY_MONTHS
  const year = start.year + Math.floor(monthIndex / 12)
  const month = (monthIndex % 12) + 1

  return {
    year,
    month,
    day: Math.min(start.day, daysInMonth(year, month)),
    hour: start.hour,
    minute: start.minute,
    second: start.second,
  }
}

/**
 * Ist eine abgeschlossene Meldung zum Zeitpunkt `now` noch oeffentlich
 * sichtbar?
 *
 * Ohne Abschlusszeitpunkt lautet die Antwort **nein**: Ohne Anker gibt es
 * keine Frist, die laufen koennte. Das trifft Meldungen, die vor Einfuehrung
 * des Feldes geschlossen wurden — die haben aber ohnehin keinen Meldungscode
 * und erscheinen deshalb gar nicht erst.
 */
export function isClosedReportStillPublic(
  closedAt: Date | null,
  now: Date = new Date()
): boolean {
  if (!closedAt) return false
  return wallClockKey(publicVisibilityEndsAt(closedAt)) > wallClockKey(zonedParts(now))
}

// ─── Umfang eines Abrufs ─────────────────────────────────────────────────────
//
// Die Liste ist vollstaendig erreichbar: Kein gueltiger Eintrag verschwindet
// allein wegen seines Alters oder weil neuere hinzugekommen sind. Begrenzt
// wird nur, wie viel ein einzelner Abruf zeigt; "Weitere anzeigen" erhoeht die
// Zahl ueber die Adresszeile.

/** Wie viele Eintraege ein Abruf hoechstens zeigt. */
export const PUBLIC_REPORT_STATUS_PAGE_SIZE = 100

/**
 * Obergrenze fuer den Seitenparameter. Ohne sie waere
 * `?rueckmeldungen=99999999` ein billiger Weg, die Datenbank zu beschaeftigen
 * — auf einer Seite, die ohne Anmeldung erreichbar ist.
 */
export const PUBLIC_REPORT_STATUS_MAX_ENTRIES = 2000

/**
 * Wandelt den Seitenparameter aus der Adresszeile in eine gueltige Zeilenzahl.
 * Alles Unbrauchbare — fehlend, keine Zahl, negativ, absurd gross — faellt auf
 * die erste Seitengroesse zurueck beziehungsweise auf die Obergrenze.
 */
export function normalizePublicReportStatusLimit(raw: unknown): number {
  const parsed =
    typeof raw === "string" || typeof raw === "number" ? Number(raw) : NaN

  if (!Number.isFinite(parsed) || parsed < PUBLIC_REPORT_STATUS_PAGE_SIZE) {
    return PUBLIC_REPORT_STATUS_PAGE_SIZE
  }

  const rounded =
    Math.ceil(parsed / PUBLIC_REPORT_STATUS_PAGE_SIZE) *
    PUBLIC_REPORT_STATUS_PAGE_SIZE

  return Math.min(rounded, PUBLIC_REPORT_STATUS_MAX_ENTRIES)
}
