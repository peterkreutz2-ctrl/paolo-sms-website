// ─── Neutraler Meldungscode ──────────────────────────────────────────────────
//
// Ein Meldender bekommt nach dem Absenden einen Code wie "Falke-12" und findet
// darunter auf /communications den groben Bearbeitungsstatus wieder. Der Code
// ist eine oeffentliche Referenz, KEIN Zugangsschluessel: Er oeffnet nichts,
// er benennt nur eine Zeile in einer Liste, die ohnehin oeffentlich ist.
//
// Was der Code nicht sein darf (Antrag, Abschnitt 4):
//   - nicht aus einer laufenden Nummer, der internen ID oder dem Datum
//     abgeleitet — sonst verriete er Reihenfolge oder Zeitpunkt,
//   - nicht personenbezogen oder inhaltlich,
//   - nicht erratbar im Sinne von "der naechste ist Falke-13".
//
// Deshalb: zufaellige Wortwahl aus einer festen Liste, zufaellige zweistellige
// Zahl, beides aus dem kryptografischen Zufallsgenerator. Math.random waere
// hier zwar wahrscheinlich unauffaellig, aber es gibt keinen Grund, an einer
// oeffentlich sichtbaren Kennung mit vorhersagbaren Zahlen zu arbeiten.

// ─── Die Wortliste ───────────────────────────────────────────────────────────
//
// Auswahlkriterien, bewusst eng:
//
//   - Naturbegriffe: Voegel, Wetter, Landschaft, Baeume, Gestein. Sie sind
//     neutral, im Flugsport vertraut und tragen keine Wertung.
//   - Keine Begriffe mit Bezug zu Unfall, Gefahr, Schuld oder Koerper — ein
//     Code wie "Absturz-12" waere in einer non-punitiven Meldekultur ein
//     Missgriff.
//   - Keine Personen-, Orts- oder Vereinsnamen, keine Geraetehersteller.
//   - Keine Umlaute und kein ss/ß: Der Code wird abgeschrieben, vorgelesen und
//     in Suchfelder getippt. "Baer-12" waere je nach Tastatur drei
//     Schreibweisen.
//   - Vier bis zwanzig Buchstaben. Kuerzere Woerter ("Uhu", "See") sind beim
//     Vorlesen zu leicht zu verwechseln; PUBLIC_REPORT_CODE_PATTERN haelt die
//     Grenze fest, und ein Test prueft die ganze Liste dagegen.
//
// Rund 270 Woerter x 90 Zahlen = ueber 24.000 Kombinationen je Organisation.
// Fuer einen Verein oder eine Flugschule ist das um Groessenordnungen mehr,
// als je gebraucht wird; die Kollisionsbehandlung in assignPublicReportCode
// traegt den Rest. Die genaue Zahl steht bewusst nicht hier, sondern wird in
// PUBLIC_REPORT_CODE_SPACE gerechnet und im Test geprueft.
export const PUBLIC_REPORT_CODE_WORDS: readonly string[] = [
  // Voegel
  "Falke", "Adler", "Bussard", "Milan", "Weihe", "Turmfalke", "Habicht",
  "Sperber", "Kranich", "Reiher", "Storch", "Schwalbe", "Mauersegler",
  "Lerche", "Amsel", "Drossel", "Fink", "Meise", "Specht", "Kleiber",
  "Zaunkoenig", "Rotkehlchen", "Star", "Dohle", "Elster", "Eichelhaeher",
  "Kolkrabe", "Steinkauz", "Waldkauz", "Schleiereule", "Wiedehopf", "Eisvogel",
  "Kiebitz", "Regenpfeifer", "Austernfischer", "Seeschwalbe", "Moewe",
  "Kormoran", "Haubentaucher", "Blaessralle", "Stockente", "Graugans",
  "Wildgans", "Schwan", "Fasan", "Rebhuhn", "Wachtel", "Birkhuhn",
  "Auerhuhn", "Alpendohle",
  // Wetter und Luft
  "Thermik", "Aufwind", "Bise", "Foehn", "Passat", "Monsun", "Brise",
  "Windstoss", "Windsack", "Wolke", "Kumulus", "Zirrus", "Stratus", "Nebel",
  "Dunst", "Nordwand", "Reif", "Raureif", "Schnee", "Firn", "Graupel",
  "Regen", "Schauer", "Niesel", "Blitz", "Donner", "Regenbogen",
  "Halo", "Morgenrot", "Abendrot", "Daemmerung", "Sonne", "Mond",
  "Stern", "Polarstern", "Komet", "Nordlicht", "Zenit", "Horizont",
  "Wetterfahne",
  // Landschaft
  "Gipfel", "Grat", "Kamm", "Sattel", "Joch", "Scharte", "Karboden", "Hang",
  "Wiese", "Almwiese", "Matte", "Heide", "Moor", "Auwald", "Delta", "Bucht",
  "Kliff", "Duene", "Strand", "Insel", "Halbinsel", "Landzunge",
  "Riff", "Lagune", "Fjord", "Schlucht", "Klamm", "Canyon", "Talkessel",
  "Hochtal", "Plateau", "Terrasse", "Senke", "Mulde", "Ebene",
  "Steppe", "Savanne", "Tundra", "Oase", "Wueste",
  // Gewaesser
  "Quelle", "Bach", "Fluss", "Strom", "Bergsee", "Weiher", "Teich",
  "Tuempel", "Wasserfall", "Stromschnelle", "Maeander", "Altarm",
  "Gletscher", "Eisfeld", "Firnfeld", "Brandung", "Duenung", "Ebbe",
  "Flut", "Gezeiten",
  // Baeume und Pflanzen
  "Ahorn", "Buche", "Birke", "Eiche", "Erle", "Esche", "Fichte",
  "Foehre", "Kiefer", "Laerche", "Linde", "Pappel", "Platane",
  "Tanne", "Ulme", "Weide", "Zeder", "Zypresse", "Holunder",
  "Hasel", "Weissdorn", "Schlehe", "Wacholder", "Ginster", "Heidekraut",
  "Farn", "Moos", "Flechte", "Binse", "Schilf", "Rohrkolben",
  "Klee", "Distel", "Enzian", "Edelweiss", "Arnika", "Primel",
  "Anemone", "Krokus", "Narzisse",
  // Gestein und Boden
  "Granit", "Basalt", "Gneis", "Schiefer", "Quarzit", "Marmor",
  "Kalkstein", "Sandstein", "Dolomit", "Tuff", "Kiesel", "Geroell",
  "Moraene", "Findling", "Felsband", "Platte", "Blockfeld", "Lehm",
  "Loess", "Torf",
  // Jahreszeit, Zeit, Himmelsrichtung
  "Fruehling", "Sommer", "Herbst", "Winter", "Vollmond", "Neumond",
  "Sonnwende", "Zeitenwende", "Norden", "Sueden", "Osten",
  "Westen", "Nordwind", "Suedwind", "Ostwind", "Westwind", "Kompass",
  "Meridian", "Breitengrad", "Laengengrad",
  // Weitere neutrale Naturbegriffe
  "Bernstein", "Kristall", "Achat", "Opal", "Jade", "Onyx", "Koralle",
  "Perle", "Muschel", "Seestern", "Libelle", "Schmetterling",
  "Zitronenfalter", "Admiral", "Schwalbenschwanz", "Hummel", "Biene",
  "Grille", "Zikade", "Glueckskaefer", "Marienkaefer", "Ameise",
  "Eichhorn", "Murmeltier", "Gaemse", "Steinbock", "Rothirsch",
  "Rehkitz", "Dachs", "Fischotter", "Biber", "Luchs", "Wildkatze",
  "Fuchs", "Marder", "Iltis", "Hermelin", "Igel", "Fledermaus",
  "Siebenschlaefer", "Haselmaus", "Feldhase",
]

/** Kleinste und groesste Zahl im Code — bewusst zweistellig (Antrag). */
export const PUBLIC_REPORT_CODE_MIN_NUMBER = 10
export const PUBLIC_REPORT_CODE_MAX_NUMBER = 99

/**
 * Wie viele Kombinationen es theoretisch gibt. Nur fuer Tests und
 * Dokumentation — die Anwendung rechnet nicht damit.
 */
export const PUBLIC_REPORT_CODE_SPACE =
  PUBLIC_REPORT_CODE_WORDS.length *
  (PUBLIC_REPORT_CODE_MAX_NUMBER - PUBLIC_REPORT_CODE_MIN_NUMBER + 1)

/**
 * Wie oft bei einer Kollision ein neuer Code gezogen wird, bevor die Meldung
 * ausnahmsweise ohne Code gespeichert wird.
 *
 * Zehn Versuche sind selbst bei einer zu 90 % gefuellten Liste noch
 * praktisch sicher. Die Zahl ist eine Obergrenze gegen eine Endlosschleife,
 * kein erwarteter Betriebsfall.
 */
export const PUBLIC_REPORT_CODE_MAX_ATTEMPTS = 10

/** Form, die ein gueltiger Code hat: Wort, Bindestrich, zwei Ziffern. */
export const PUBLIC_REPORT_CODE_PATTERN = /^[A-Za-z]{4,20}-\d{2}$/

/**
 * Erzeugt einen einzelnen Code. Reine Zufallsziehung ohne Kenntnis der
 * Datenbank — ob der Code frei ist, entscheidet der Unique-Index; siehe
 * assignPublicReportCode in lib/reports/public-code.ts.
 *
 * `pick` wird bewusst hereingereicht statt hier `node:crypto` zu importieren:
 * Diese Datei enthaelt sonst nur Daten und Regeln und soll auch dann
 * unbedenklich sein, wenn sie ueber eine Client-Komponente ins Browser-Bundle
 * geraet. Den kryptografischen Generator liefert der Aufrufer auf dem Server
 * (lib/reports/public-code.ts); Tests liefern eine deterministische Ziehung.
 */
export function createPublicReportCode(
  pick: (maxExclusive: number) => number
): string {
  const word = PUBLIC_REPORT_CODE_WORDS[pick(PUBLIC_REPORT_CODE_WORDS.length)]
  const span =
    PUBLIC_REPORT_CODE_MAX_NUMBER - PUBLIC_REPORT_CODE_MIN_NUMBER + 1
  const number = PUBLIC_REPORT_CODE_MIN_NUMBER + pick(span)
  return `${word}-${number}`
}
