// Anzeigename der Organisation im Kopf der Anwendung (#117).
//
// Eine Regel fuer Formular, Server und Tests. Der Name steht fuer jeden
// Besucher einzeilig im Kopf; die Obergrenze verhindert, dass ein versehentlich
// eingefuegter Absatz dort landet. Gekuerzt wird zusaetzlich per CSS — die
// Grenze ersetzt das nicht, sie begrenzt nur, was gespeichert wird.

export const ORGANIZATION_DISPLAY_NAME_MAX_LENGTH = 100

// Steuerzeichen (auch Zeilenumbruch und Tabulator) sowie unsichtbare
// Formatierzeichen (Nullbreiten-Zeichen, Schreibrichtungs-Steuerung, BOM) haben
// in einem Namen nichts verloren: Sie liessen sich nicht sehen und koennten die
// Darstellung im Kopf verfaelschen.
const FORBIDDEN_CHARACTERS = /[\u0000-\u001F\u007F-\u009F​-‏‪-‮⁠-⁤﻿]/

export type OrganizationDisplayNameResult =
  | { ok: true; value: string | null }
  | { ok: false; message: string }

/**
 * Normalisiert und prueft die Eingabe des Anzeigenamens.
 *
 * Leerraum am Rand wird entfernt und im Inneren auf ein Leerzeichen
 * zusammengefasst. Ein leerer Wert ist gueltig und bedeutet "kein Name"
 * (`null`) — der Kopf zeigt dann nur "PAOLO SMS".
 */
export function normalizeOrganizationDisplayName(
  input: unknown
): OrganizationDisplayNameResult {
  if (input === null || input === undefined) return { ok: true, value: null }
  if (typeof input !== "string") {
    return { ok: false, message: "Der Anzeigename muss ein Text sein." }
  }

  // Nur echte Steuerzeichen vorab ablehnen; gewoehnlicher Leerraum (auch
  // Zeilenumbrueche eines eingefuegten Textes) wird danach zusammengefasst.
  const withoutWhitespace = input.replace(/\s+/g, " ").trim()
  if (FORBIDDEN_CHARACTERS.test(withoutWhitespace)) {
    return {
      ok: false,
      message: "Der Anzeigename enthält unzulässige Zeichen.",
    }
  }
  if (withoutWhitespace.length === 0) return { ok: true, value: null }
  if (withoutWhitespace.length > ORGANIZATION_DISPLAY_NAME_MAX_LENGTH) {
    return {
      ok: false,
      message: `Der Anzeigename darf höchstens ${ORGANIZATION_DISPLAY_NAME_MAX_LENGTH} Zeichen lang sein.`,
    }
  }
  return { ok: true, value: withoutWhitespace }
}
