// Datenschutz-Einwilligung auf /submit-report (#101).
//
// Diese Datei ist die einzige Quelle fuer den Standardtext, den Linkmarker und
// die Regeln, nach denen ein Einwilligungstext gueltig ist und eine Einreichung
// angenommen wird. Meldeformular, Einstellungsformular, Zod-Schema und Server
// leiten sich daraus ab. Sie ist bewusst frei von Server-Abhaengigkeiten, weil
// das Meldeformular sie im Browser fuer die Darstellung braucht.

/**
 * Platzhalter im Einwilligungstext. Er bleibt im gespeicherten Text stehen und
 * wird auf /submit-report als Link auf /datenschutz in neuem Tab dargestellt.
 */
export const PRIVACY_CONSENT_LINK_MARKER = "[Datenschutzerklärung]"

/** Sichtbare Linkbeschriftung — fester Bestandteil, nicht konfigurierbar. */
export const PRIVACY_CONSENT_LINK_LABEL = "Datenschutzerklärung"

export const PRIVACY_CONSENT_LINK_HREF = "/datenschutz"

/**
 * Abgestimmter Standardtext. Wortlaut NICHT aendern: Aenderungen erfolgen nur
 * nach ausdruecklicher Freigabe (Issue #101). Organisationen, die keinen
 * eigenen Text hinterlegt haben (Spalte NULL), verwenden diesen.
 */
export const DEFAULT_PUBLIC_REPORT_PRIVACY_CONSENT_TEXT =
  "Ich willige ein, dass die von mir eingegebenen Daten (inkl. Kontaktdaten und Angaben zum Ereignis) zum Zweck des Sicherheitsmanagements verarbeitet werden. Mir ist bewusst, dass die Meldung sensible Daten enthalten kann. Die Hinweise zum Datenschutz in der [Datenschutzerklärung] habe ich zur Kenntnis genommen und bestätige, keine unbefugten personenbezogenen Daten Dritter ohne deren Zustimmung in der Meldung zu teilen. Ich kann diese Einwilligung gegenüber dem Betreiber jederzeit für die Zukunft widerrufen."

export const PRIVACY_CONSENT_TEXT_MAX_LENGTH = 2000

/** Der gespeicherte Wert, oder der Standardtext, wenn keiner hinterlegt ist. */
export function resolvePrivacyConsentText(stored: string | null | undefined): string {
  return stored && stored.trim().length > 0
    ? stored
    : DEFAULT_PUBLIC_REPORT_PRIVACY_CONSENT_TEXT
}

/**
 * Was gespeichert wird: NULL, solange der Text dem Standardtext entspricht.
 * So folgt eine Organisation ohne eigenen Text einer spaeter freigegebenen
 * Aenderung des Standards, und "eigener Text" heisst wirklich "abweichend".
 */
export function toStoredPrivacyConsentText(text: string): string | null {
  return text === DEFAULT_PUBLIC_REPORT_PRIVACY_CONSENT_TEXT ? null : text
}

function countMarker(text: string): number {
  return text.split(PRIVACY_CONSENT_LINK_MARKER).length - 1
}

/**
 * Prueft einen Einwilligungstext. Gibt eine Fehlermeldung zurueck oder null.
 * Der Marker muss genau einmal vorkommen: Ohne ihn fehlte der Link auf die
 * Datenschutzerklaerung, mehrfach waere unklar, welche Stelle verlinkt ist.
 */
export function validatePrivacyConsentText(text: string): string | null {
  if (text.trim().length === 0) {
    return "Der Einwilligungstext darf nicht leer sein."
  }
  if (text.length > PRIVACY_CONSENT_TEXT_MAX_LENGTH) {
    return `Der Einwilligungstext darf höchstens ${PRIVACY_CONSENT_TEXT_MAX_LENGTH.toLocaleString("de-DE")} Zeichen enthalten.`
  }
  const markers = countMarker(text)
  if (markers === 0) {
    return `Der Einwilligungstext muss ${PRIVACY_CONSENT_LINK_MARKER} enthalten – dort steht der Link zur Datenschutzerklärung.`
  }
  if (markers > 1) {
    return `${PRIVACY_CONSENT_LINK_MARKER} darf nur einmal im Einwilligungstext vorkommen.`
  }
  return null
}

/** Teilt den Text am Marker, damit die Oberflaeche dort den Link einsetzt. */
export function splitPrivacyConsentText(text: string): {
  before: string
  after: string
} {
  const index = text.indexOf(PRIVACY_CONSENT_LINK_MARKER)
  if (index < 0) return { before: text, after: "" }
  return {
    before: text.slice(0, index),
    after: text.slice(index + PRIVACY_CONSENT_LINK_MARKER.length),
  }
}

/**
 * Der Text, wie der Melder ihn liest: der Marker als sichtbares Linkwort.
 * Genau das landet als Snapshot an der Meldung.
 */
export function toDisplayedPrivacyConsentText(text: string): string {
  return text.replace(PRIVACY_CONSENT_LINK_MARKER, PRIVACY_CONSENT_LINK_LABEL)
}

export type PrivacyConsentDecision =
  /** Funktion aus, Zustand unveraendert: annehmen, nichts speichern. */
  | "not_required"
  /** Funktion an, Zustimmung erteilt, Zustand unveraendert: annehmen, Nachweis speichern. */
  | "given"
  /** Funktion an, Zustimmung fehlt: ablehnen. */
  | "missing"
  /** Schalter, Text oder Datenschutzerklaerung haben sich geaendert: ablehnen, neu laden. */
  | "stale"

/**
 * Entscheidet ueber eine Einreichung. Massgeblich ist der Serverzustand im
 * Moment der Einreichung; der Fingerabdruck aus dem Formular dient nur dem
 * Abgleich, ob der Melder genau diesen Zustand gesehen hat.
 *
 * "stale" geht vor "missing": Hat sich der Zustand geaendert, muss der Melder
 * die neue Fassung erst sehen, bevor eine Zustimmung etwas bedeutet.
 */
export function decidePrivacyConsent(input: {
  enabled: boolean
  currentFingerprint: string
  submittedFingerprint: string | null | undefined
  consentGiven: boolean
}): PrivacyConsentDecision {
  if (input.submittedFingerprint !== input.currentFingerprint) return "stale"
  if (!input.enabled) return "not_required"
  return input.consentGiven ? "given" : "missing"
}
