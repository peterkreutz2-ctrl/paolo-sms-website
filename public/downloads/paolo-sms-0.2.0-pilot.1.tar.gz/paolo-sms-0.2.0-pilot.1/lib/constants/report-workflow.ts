export const SOURCE_CHANNEL_VALUES = [
  "public_form",
  "import",
  "manual",
  "demo",
  "ai_text_dialog",
  "ai_voice_dialog",
] as const

export type SourceChannel = (typeof SOURCE_CHANNEL_VALUES)[number]

export const SOURCE_CHANNEL_LABELS: Record<SourceChannel, string> = {
  public_form: "Öffentliches Formular",
  import: "CSV-Import",
  manual: "Manuell",
  demo: "Spieldaten",
  ai_text_dialog: "KI-Textdialog",
  ai_voice_dialog: "KI-Sprachdialog",
}

export const REPORT_STATUS_VALUES = [
  "new",
  "in_review",
  "in_progress",
  "measures_defined",
  "closed",
  "hidden",
] as const

export const REPORT_PRIORITY_VALUES = [
  "low",
  "medium",
  "high",
  "critical",
] as const

export type ReportStatus = (typeof REPORT_STATUS_VALUES)[number]
export type ReportPriority = (typeof REPORT_PRIORITY_VALUES)[number]

// Beschriftungen der Oberflaeche. Sie stimmen heute mit den oeffentlichen
// Bezeichnungen in lib/constants/public-report-status.ts ueberein — bis auf
// "hidden", das oeffentlich gar nicht erscheint. Die beiden Tabellen bleiben
// trotzdem getrennt: Die interne darf sich aendern, ohne dass sich damit
// stillschweigend aendert, was eine oeffentliche Seite anzeigt.
export const REPORT_STATUS_LABELS: Record<ReportStatus, string> = {
  new: "Neu",
  in_review: "In Prüfung",
  in_progress: "In Bearbeitung",
  measures_defined: "Maßnahmen beschlossen",
  closed: "Abgeschlossen",
  hidden: "Ausgeblendet",
}

export const REPORT_PRIORITY_LABELS: Record<ReportPriority, string> = {
  low: "Niedrig",
  medium: "Mittel",
  high: "Hoch",
  critical: "Kritisch",
}

// ─── Die Gruppe "nicht mehr aktiv bearbeitet" ───────────────────────────────
//
// "closed" und "hidden" bilden fachlich eine Gruppe. Sie entscheidet an drei
// Stellen: wann anonymisiert werden darf, wann der Aufbewahrungsanker gesetzt
// wird, und — als Verneinung — was als offene Meldung zaehlt.
//
// Vorher stand diese Regel an SIEBEN Stellen: hier, zweimal inline in
// lib/actions/reports.ts, als zwei voneinander unabhaengige
// CLOSED_OR_HIDDEN-Konstanten in der Listenabfrage und im Dashboard, und
// zweimal inline in der Oberflaeche. Alle sieben stimmten ueberein — aber ein
// Status, der spaeter zur Gruppe gehoert, haette den Aufbewahrungsanker
// gesetzt bekommen, waehrend die Oberflaeche die Anonymisierung nicht anbietet
// und das Dashboard die Meldung weiter als offen zaehlt (Regelaudit F1).
//
// Jetzt steht sie einmal. Die Liste ist fuer SQL (notInArray) da, das Praedikat
// fuer alles andere.

/**
 * Status, die als "nicht mehr aktiv bearbeitet" gelten.
 *
 * Bewusst `readonly`: Die Liste ist eine Regel, kein Arbeitsspeicher. Fuer
 * Drizzles `notInArray`, das eine veraenderbare Liste erwartet, wird an der
 * Aufrufstelle gespreizt — das kostet eine Kopie und verhindert, dass eine
 * Stelle die Regel fuer alle anderen veraendert.
 */
export const CLOSED_OR_HIDDEN_STATUSES: readonly ReportStatus[] = [
  "closed",
  "hidden",
]

/** Gehoert dieser Status zur Gruppe "nicht mehr aktiv bearbeitet"? */
export function isClosedOrHidden(status: string): boolean {
  return (CLOSED_OR_HIDDEN_STATUSES as readonly string[]).includes(status)
}

/**
 * DSGVO-Retention-Review (Arbeitspaket 3): Ein duenner benannter Zugriff auf
 * dieselbe Gruppe — er traegt an der Aufrufstelle die fachliche Absicht, die
 * `isClosedOrHidden` dort nicht transportieren wuerde. Dasselbe Muster wie bei
 * den Rollenpraedikaten ueber ROLE_CAPABILITIES.
 */
export function isRetentionReviewEligibleStatus(status: string): boolean {
  return isClosedOrHidden(status)
}

/**
 * Reine Funktion (kein DB-Zugriff): entscheidet, ob/wie
 * reports.retentionReviewEligibleAt bei einem Statuswechsel zu setzen ist.
 * - Erster Eintritt in die Gruppe (closed/hidden): Anker setzen (now).
 * - Austritt aus der Gruppe: Anker loeschen (null).
 * - Wechsel innerhalb der Gruppe oder außerhalb: unveraendert — das Feld
 *   fehlt dann im Ergebnis und darf nicht in ein DB-Update uebernommen
 *   werden, damit der bestehende Wert erhalten bleibt.
 */
export function computeRetentionReviewEligibleAtUpdate(
  previousStatus: string,
  nextStatus: string,
  now: Date = new Date()
): { retentionReviewEligibleAt?: Date | null } {
  const wasEligible = isRetentionReviewEligibleStatus(previousStatus)
  const willBeEligible = isRetentionReviewEligibleStatus(nextStatus)

  if (willBeEligible && !wasEligible) {
    return { retentionReviewEligibleAt: now }
  }
  if (!willBeEligible && wasEligible) {
    return { retentionReviewEligibleAt: null }
  }
  return {}
}
