export const MEASURE_STATUS_VALUES = [
  "open",
  "in_progress",
  "completed",
  "discarded",
] as const

export type MeasureStatus = (typeof MEASURE_STATUS_VALUES)[number]

export const MEASURE_STATUS_LABELS: Record<MeasureStatus, string> = {
  open: "Offen",
  in_progress: "In Bearbeitung",
  completed: "Erledigt",
  discarded: "Verworfen",
}

// ─── Verwerfen ──────────────────────────────────────────────────────────────
//
// „Verworfen" ist der vorgesehene Weg, eine Massnahme aus der Nachverfolgung
// zu nehmen: Sie faellt aus „Offene" und „Ueberfaellige" und aus der
// Arbeitsliste der Besprechungsprotokolle, bleibt aber in der Historie. Bis
// hierher war der Wechsel ein Auswahlfeld wie jedes andere — „hat sich anders
// erledigt", „war doppelt" und „war ein Irrtum" sahen hinterher gleich aus.
//
// Jetzt verlangt der Wechsel eine Begruendung, nach demselben Muster wie der
// Freigabevermerk bei Anhaengen.

/** Mindestlaenge der Begruendung beim Verwerfen. */
export const MEASURE_DISCARD_REASON_MIN_LENGTH = 10

export const DISCARDED_STATUS: MeasureStatus = "discarded"

/**
 * Verlangt dieser Statuswechsel eine Begruendung?
 *
 * Nur der EINTRITT in „Verworfen" zaehlt. Eine bereits verworfene Massnahme
 * erneut zu speichern — etwa um einen Tippfehler im Titel zu beheben — soll
 * nicht jedes Mal eine neue Begruendung verlangen.
 */
export function requiresDiscardReason(
  previousStatus: string,
  nextStatus: string
): boolean {
  return nextStatus === DISCARDED_STATUS && previousStatus !== DISCARDED_STATUS
}

/**
 * Prueft die Begruendung fuer einen Statuswechsel und liefert die
 * Fehlermeldung — oder `null`, wenn alles stimmt.
 *
 * Reine Funktion ohne Datenbankzugriff: Die Regel haengt am vorherigen Status,
 * den nur der Server kennt, und ist deshalb nicht im Zod-Schema abbildbar. Als
 * eigene Funktion bleibt sie trotzdem vollstaendig testbar.
 */
export function validateDiscardReason(
  previousStatus: string,
  nextStatus: string,
  reason: string | null
): string | null {
  if (!requiresDiscardReason(previousStatus, nextStatus)) return null

  const trimmed = (reason ?? "").trim()
  if (trimmed.length === 0) {
    return "Zum Verwerfen ist eine kurze Begruendung noetig."
  }
  if (trimmed.length < MEASURE_DISCARD_REASON_MIN_LENGTH) {
    return `Die Begruendung muss mindestens ${MEASURE_DISCARD_REASON_MIN_LENGTH} Zeichen enthalten.`
  }
  return null
}
