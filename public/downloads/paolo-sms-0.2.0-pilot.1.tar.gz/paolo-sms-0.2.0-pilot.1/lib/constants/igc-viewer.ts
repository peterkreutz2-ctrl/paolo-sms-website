// Hinweis auf einen externen IGC-Viewer fuer oeffentlich freigegebene
// Tracklogs (AP4).
//
// PAOLO baut bewusst KEINE eigene Flugdarstellung und uebergibt die Datei auch
// NICHT automatisch an einen externen Dienst. Angeboten wird ausschliesslich
// der Download plus ein Hinweis, womit sich eine IGC-Datei ansehen laesst.
//
// Warum keine Uebergabe per URL — das ist die eigentliche Entscheidung:
//
// Dienste, die eine IGC-URL per Parameter uebernehmen (etwa
// `seeyou.cloud/api/open?igc=…`), rufen die Datei SERVERSEITIG ab und legen
// daraus einen Flug in ihrer eigenen Cloud an. Nachgemessen: die Antwort ist
// eine Weiterleitung auf eine dort dauerhaft und ohne Anmeldung erreichbare
// Flugansicht, und wiederholte Aufrufe liefern dieselbe ID — die Ablage ist
// inhaltsadressiert und bleibt bestehen.
//
// Damit waere ein Widerruf in PAOLO wirkungslos: unsere Route antwortet danach
// mit 404, die Kopie beim Drittanbieter bleibt. Fuer eine IGC-Datei wiegt das
// besonders schwer — sie enthaelt Pilotennamen im Header und eine
// sekundengenaue Bewegungsspur. Der gesamte Freigabeprozess aus AP3 mit
// Checkliste, Freigabevermerk und Widerruf haette dort ein Loch, das sich
// nachtraeglich nicht mehr schliessen laesst.
//
// Der hier verlinkte Viewer verarbeitet die Datei ausschliesslich im Browser
// ("All processing takes place in client-side script, so there is no need to
// upload the IGC file (or anything else) to the server", MIT-Lizenz). Der Link
// uebergibt bewusst KEINE PAOLO-URL: der Nutzer laedt die Datei herunter und
// oeffnet sie dort selbst. Zwei Schritte statt einem — dafuer verlaesst nichts
// den Rechner des Betrachters.

import { getExtension } from "./attachment-file-types"

export const IGC_VIEWER_HINT_NAME = "jsigc"

export const IGC_VIEWER_HINT_URL = "https://alistairmgreen.github.io/jsigc/"

/**
 * Ist das eine IGC-Datei? Entscheidet allein darueber, ob der Hinweis
 * eingeblendet wird. Die Endung kommt aus getExtension() in
 * attachment-file-types.ts — die Zerlegung des Dateinamens gibt es damit
 * weiterhin nur an einer Stelle. Der MIME-Typ taugt hier nicht: fuer .igc
 * liefern Browser haeufig gar keinen.
 */
export function isIgcFileName(fileName: string): boolean {
  return getExtension(fileName) === "igc"
}
