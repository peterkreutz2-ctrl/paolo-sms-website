export const NOTE_TYPE_VALUES = [
  "supplement",
  "witness_statement",
  "internal_note",
  "reporter_followup",
  "other",
] as const

export type NoteType = (typeof NOTE_TYPE_VALUES)[number]

export const NOTE_TYPE_LABELS: Record<NoteType, string> = {
  supplement: "Nachtrag",
  witness_statement: "Zeugenaussage",
  internal_note: "Interne Notiz",
  reporter_followup: "Rückmeldung des Melders",
  other: "Sonstiges",
}
