// Regeln fuer Anhang-Uploads: erlaubte Dateitypen, Groessenlimit und Aufbau
// des Storage-Keys. Gelten unveraendert fuer Anhaenge an Meldungen UND an
// SMS-Dokumenten — es gibt bewusst nur einen
// Regelsatz.
//
// Bewusst hier und nicht in lib/actions/attachments.ts: eine "use server"-Datei
// darf ausschliesslich async Funktionen exportieren, die Pruefungen waeren dort
// also nicht direkt testbar. Zudem zieht lib/actions/attachments.ts ueber
// lib/auth das Paket `server-only` und laesst sich ausserhalb von Next gar
// nicht laden. Die Server Actions bleiben die einzige Stelle, die diese Regeln
// durchsetzt — sie importieren nur die Funktionen hier.

const BASIC_ALLOWED_MIME_TYPES = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
  "application/pdf",
  "text/plain",
])

const TRACKLOG_EXTENSIONS = new Set(["igc", "gpx", "kml"])

// ─── Video ──────────────────────────────────────────────────────────────────
//
// Nur MP4, und bewusst strenger geprueft als die uebrigen Typen: Endung UND
// MIME-Typ UND Dateisignatur muessen stimmen. Ein Video ist die einzige
// Anhangsart, die im Browser abgespielt wird — bei den anderen entscheidet
// allein der Download.
//
// Die maximale Laufzeit von 60 Sekunden wird NICHT hier geprueft: dafuer
// muesste der MP4-Container geparst werden (der moov-Block liegt bei
// Kamera-Aufnahmen meist am Dateiende). Die Dauer prueft das Formular vor dem
// Absenden ueber <video>.duration. Das ist umgehbar — aber nur von den
// internen Rollen, die ohnehin hochladen duerfen, und die Groesse als
// eigentliche Schutzgrenze bleibt serverseitig erzwungen.

export const VIDEO_MIME_TYPE = "video/mp4"

export const VIDEO_EXTENSION = "mp4"

/** Maximale Laufzeit in Sekunden. Wird clientseitig geprueft. */
export const MAX_VIDEO_DURATION_SECONDS = 60

/**
 * Traegt die Datei die MP4-Signatur? Ein MP4 beginnt mit einem Box-Header,
 * dessen Typ ab Byte 4 "ftyp" lautet; die ersten vier Bytes sind die
 * Boxlaenge. Geprueft werden nur die ersten 12 Bytes — das genuegt, um eine
 * umbenannte Datei zu erkennen, und kostet nichts.
 */
export async function hasMp4Signature(file: File): Promise<boolean> {
  if (file.size < 12) return false
  const header = new Uint8Array(await file.slice(0, 12).arrayBuffer())
  return (
    header[4] === 0x66 && // f
    header[5] === 0x74 && // t
    header[6] === 0x79 && // y
    header[7] === 0x70 // p
  )
}

export function isVideoFileName(fileName: string): boolean {
  return getExtension(fileName) === VIDEO_EXTENSION
}

/**
 * Entscheidet ueber die gemessene Laufzeit. Reine Funktion, damit die Regel
 * unabhaengig vom Browser pruefbar bleibt — das Auslesen selbst geht nur ueber
 * ein <video>-Element.
 *
 * Eine NICHT bestimmbare Dauer fuehrt bewusst NICHT zur Ablehnung: sie
 * bedeutet nur, dass der Browser des Hochladenden die Datei nicht dekodieren
 * kann — etwa bei einem Codec, den er nicht kennt. Das zum Ausschlussgrund zu
 * machen, wuerde gueltige Dateien blockieren und eine Genauigkeit vortaeuschen,
 * die diese Pruefung ohnehin nicht hat: sie laeuft im Client und ist umgehbar.
 * Die verbindliche Schranke bleibt die Dateigroesse, und die wird
 * serverseitig erzwungen.
 */
export function videoDurationError(
  durationSeconds: number | null
): string | null {
  if (durationSeconds === null) return null
  if (durationSeconds <= MAX_VIDEO_DURATION_SECONDS) return null
  return `Video zu lang (${Math.round(durationSeconds)} Sekunden). Maximal ${MAX_VIDEO_DURATION_SECONDS} Sekunden sind erlaubt – bitte vorher kürzen.`
}

// Anzeige- und Formularwerte, damit die Upload-Formulare fuer Meldungen und
// SMS-Dokumenten nicht auseinanderlaufen. Beide leiten Hinweistext,
// accept-Attribut und Groessenangabe aus dieser Datei ab.
export const ATTACHMENT_ACCEPT_ATTRIBUTE =
  ".jpg,.jpeg,.png,.webp,.pdf,.txt,.igc,.gpx,.kml,.mp4"

export const ATTACHMENT_TYPES_LABEL =
  "JPG, PNG, WEBP, PDF, TXT, IGC, GPX, KML, MP4"

const TRACKLOG_MIME_TYPES = new Set([
  "application/octet-stream",
  "application/gpx+xml",
  "application/vnd.google-earth.kml+xml",
  "application/xml",
  "text/xml",
  "text/plain",
])

/**
 * Endung in Kleinschreibung, ohne Punkt. Leerstring, wenn der Dateiname keine
 * echte Endung hat — ein Name ganz ohne Punkt ("igc"), ein Dotfile (".igc")
 * und ein Name mit Punkt am Ende ("track.") liefern daher bewusst "" und
 * nicht den Namen selbst.
 */
export function getExtension(fileName: string): string {
  const lastDot = fileName.lastIndexOf(".")
  if (lastDot <= 0 || lastDot === fileName.length - 1) {
    return ""
  }
  return fileName.slice(lastDot + 1).toLowerCase()
}

export function isAllowedFileType(file: File): boolean {
  // Video zuerst und mit eigener Regel: Endung UND MIME muessen stimmen.
  // Bewusst nicht ueber die Basisliste, damit eine .txt mit dem MIME-Typ
  // video/mp4 nicht durchrutscht — und umgekehrt.
  if (isVideoFileName(file.name) || file.type === VIDEO_MIME_TYPE) {
    return isVideoFileName(file.name) && file.type === VIDEO_MIME_TYPE
  }

  if (BASIC_ALLOWED_MIME_TYPES.has(file.type)) {
    return true
  }

  const extension = getExtension(file.name)
  if (!TRACKLOG_EXTENSIONS.has(extension)) {
    return false
  }

  // Browser leiten den MIME-Typ aus der Endung ab. Fuer .igc ist system-
  // seitig keine Zuordnung registriert (und je nach System auch fuer .gpx/
  // .kml nicht), sodass file.type leer bleibt. Ein leerer Typ ist hier also
  // der Normalfall und kein Hinweis auf eine unerlaubte Datei — massgeblich
  // ist die oben bereits gepruefte Tracklog-Endung. Fuer alle anderen
  // Endungen aendert das nichts: die sind an dieser Stelle schon abgelehnt.
  return file.type === "" || TRACKLOG_MIME_TYPES.has(file.type)
}

// ─── Groesse und Storage-Key ────────────────────────────────────────────────

// 4 MiB. Der Wert ergibt sich aus der Plattform, nicht aus einer fachlichen
// Ueberlegung: Reference Prod laeuft auf Vercel, und dort ist der Request-Body
// einer Funktion auf 4,5 MB begrenzt — infrastrukturseitig, nicht ueber
// vercel.json oder Anwendungscode aenderbar. Groessere Server-Action-Uploads
// erreichen die Anwendung gar nicht erst, sondern werden mit einem rohen
// 413 abgewiesen, bevor unser Code laeuft.
//
// 4 MiB laesst gegen die pessimistische Lesart (4.500.000 Bytes) rund 300 KB
// Reserve; der Multipart-Overhead eines Uploads liegt bei unter 2 KB. Bewusst
// EIN Wert fuer alle Provider: ein hoeheres Limit fuer Docker-Installationen
// waere zwar technisch moeglich, wuerde aber bedeuten, dass dieselbe Datei je
// nach Installation angenommen oder abgelehnt wird.
//
// Vorher standen hier 25 MB — ein Versprechen, das auf Vercel nie einloesbar
// war. Aufgefallen ist es nicht, weil die groesste hochgeladene Datei 86 KB
// hatte.
export const MAX_FILE_SIZE_BYTES = 4 * 1024 * 1024

/** Fuer Anzeigetexte. Leitet sich aus dem Limit ab, damit die Zahl nur an
 * einer Stelle steht. */
export const MAX_FILE_SIZE_MB = MAX_FILE_SIZE_BYTES / (1024 * 1024)

const SAFE_FILENAME_CHARS = /[^a-zA-Z0-9._-]/g

/**
 * Ersetzt alles ausserhalb von [A-Za-z0-9._-]. Wird sowohl fuer den
 * Speicher-Schluessel als auch fuer den Dateinamen in oeffentlichen URLs
 * verwendet — die Regel steht dadurch nur an dieser einen Stelle.
 */
export function sanitizeFileName(fileName: string): string {
  return fileName.replace(SAFE_FILENAME_CHARS, "_")
}

/**
 * Ablageordner im Speicher. Der Praefix trennt die beiden Eigentuemer-Arten,
 * damit ein storageKey auch ohne Datenbank zuordenbar bleibt und Schluessel
 * der beiden Bereiche nie kollidieren koennen.
 */
export type StorageFolder = "reports" | "sms-documents"

/**
 * Baut den Speicher-Schluessel: Ordner, Eigentuemer-ID, Zeitstempel,
 * Zufallsanteil und bereinigter Originalname. Der Originalname dient nur noch
 * der Lesbarkeit — alle Zeichen ausserhalb von [A-Za-z0-9._-] werden ersetzt,
 * sodass weder Pfadtrenner noch ".." in den Schluessel gelangen koennen.
 */
export function buildStorageKey(
  folder: StorageFolder,
  ownerId: string,
  fileName: string
): string {
  const cleanedName = sanitizeFileName(fileName)
  const timestamp = Date.now()
  const randomPart = crypto.randomUUID().slice(0, 8)
  return `${folder}/${ownerId}/${timestamp}-${randomPart}-${cleanedName}`
}

// ─── Gemeinsame Dateipruefung ───────────────────────────────────────────────

export type FileCheckResult =
  | { ok: true; file: File }
  | { ok: false; message: string }

/**
 * Prueft einen Wert aus FormData als hochladbare Datei: vorhanden, nicht leer,
 * innerhalb des Groessenlimits, erlaubter Typ — und bei MP4 zusaetzlich die
 * Dateisignatur. Identisch fuer beide Upload-Pfade und fuer die
 * clientseitige Vorpruefung, damit Meldungen, SMS-Dokumente und Formular nie
 * auseinanderlaufen.
 *
 * Asynchron wegen der Signaturpruefung; fuer alle anderen Typen wird kein
 * Byte gelesen.
 */
export async function checkUploadedFile(
  value: FormDataEntryValue | null
): Promise<FileCheckResult> {
  if (!(value instanceof File)) {
    return { ok: false, message: "Bitte waehle eine Datei aus." }
  }

  if (value.size <= 0) {
    return { ok: false, message: "Die Datei ist leer." }
  }

  if (value.size > MAX_FILE_SIZE_BYTES) {
    return {
      ok: false,
      message: `Datei zu gross. Maximal ${MAX_FILE_SIZE_MB} MB sind erlaubt.`,
    }
  }

  if (!isAllowedFileType(value)) {
    return { ok: false, message: "Dateityp nicht erlaubt." }
  }

  // Nur bei Video: Endung und MIME-Typ stammen beide vom Client und sind
  // beliebig setzbar. Die Signatur ist der einzige Beleg, dass es sich
  // tatsaechlich um ein MP4 handelt.
  if (value.type === VIDEO_MIME_TYPE && !(await hasMp4Signature(value))) {
    return {
      ok: false,
      message: "Die Datei ist kein gueltiges MP4-Video.",
    }
  }

  return { ok: true, file: value }
}
