// Konstanten für die SMS-Dokumentenablage (strukturierte SMS-Dokumentation).
//
// Es handelt sich NICHT um ein allgemeines Dokumentenmanagement: Die Ablage
// führt reine Text-/Markdown-Dokumente — keine Uploads, keine Versionierung,
// keine Review-Felder. Spätere Ausbaustufen sind in docs/development-log.md
// vorgemerkt.
//
// Diese Datei ist die zentrale Quelle für drei Achsen; Formulare, interne
// Übersicht und öffentliche Seite leiten sich daraus ab und definieren nichts
// eigenes:
//
//   Kategorie     fachliche Einordnung eines Dokuments
//                 (SMS_DOCUMENT_CATEGORY_VALUES / _LABELS).
//   Section       Bereich der internen Übersicht; jede Kategorie gehört zu
//                 genau einer Section (SMS_DOCUMENT_SECTIONS).
//   Sichtbarkeit  wer ein Dokument sehen darf — von vertraulich bis
//                 öffentlich (SMS_DOCUMENT_VISIBILITY_VALUES / _LABELS).
//
// Kategorie und Sichtbarkeit sind auf DB-Ebene freier Text; gültig sind
// ausschließlich die hier definierten Werte, erzwungen über die TS-Unions und
// die Zod-Schemas in lib/validations/sms-document.ts. Neue Werte werden daher
// hier ergänzt und brauchen keine Migration.

import {
  hasDocumentReadRole,
  hasMembersDocumentReadRole,
  hasSafetyEditRole,
  type AppRoleKey,
} from "./roles"

export const SMS_DOCUMENT_CATEGORY_VALUES = [
  "safety_policy",
  "sms_manual",
  "emergency_plan",
  "safety_meeting_minutes",
  "safety_information",
  "checklist",
  "operating_manual",
] as const

export type SmsDocumentCategory = (typeof SMS_DOCUMENT_CATEGORY_VALUES)[number]

// Kategorie-Titel für ein EINZELNES Dokument (Singular): Kategorie-Badge und
// Auswahl in /dashboard/documents, Druckansicht, Audit-Log. Für Gruppentitel
// über mehrere Dokumente siehe SMS_DOCUMENT_CATEGORY_GROUP_LABELS.
export const SMS_DOCUMENT_CATEGORY_LABELS: Record<SmsDocumentCategory, string> = {
  safety_policy: "Sicherheitsrichtlinie",
  sms_manual: "SMS-Handbuch",
  emergency_plan: "Notfallplan",
  safety_meeting_minutes: "Protokoll Sicherheitsbesprechung",
  safety_information: "Sicherheitshinweis",
  checklist: "Checkliste",
  operating_manual: "Bedienungsanleitung",
}

// Kategorie-Titel für eine GRUPPE von Dokumenten (Plural): die aufklappbaren
// Kategorieboxen auf /communications inkl. ihrer aria-labels. Bewusst getrennt
// von SMS_DOCUMENT_CATEGORY_LABELS, weil ein Gruppentitel („Notfallpläne") und
// die Bezeichnung eines einzelnen Dokuments („Notfallplan") auseinanderfallen.
export const SMS_DOCUMENT_CATEGORY_GROUP_LABELS: Record<
  SmsDocumentCategory,
  string
> = {
  safety_policy: "Sicherheitsrichtlinie",
  sms_manual: "SMS-Handbuch",
  emergency_plan: "Notfallpläne",
  safety_meeting_minutes: "Protokolle der Sicherheitsbesprechungen",
  // Gruppentitel der Kategoriebox — auf /communications und im internen
  // Dokumentbereich. Seit dem Glossar traegt die Kategorie intern wie
  // oeffentlich denselben Namen; nur die Zahl unterscheidet Einzeldokument
  // ("Sicherheitshinweis") und Gruppe. Die Seite /communications heisst
  // unveraendert "Sicherheitsinformationen" — sie fasst alle dort
  // veroeffentlichten Inhalte zusammen, nicht nur diese Kategorie.
  safety_information: "Sicherheitshinweise",
  checklist: "Checklisten",
  operating_manual: "PAOLO Bedienungsanleitungen",
}

// Vierstufiges Sichtbarkeitsmodell (löst das frühere internal/published ab).
// Aufsteigend nach Offenheit — die Reihenfolge bestimmt zugleich die Reihung
// im Auswahlfeld des Formulars:
//   confidential – nur admin/safety_manager
//   staff        – zusätzlich instructor (angemeldet)
//   members      – alle angemeldeten Benutzer MIT zugewiesener PAOLO-Rolle,
//                  also zusätzlich member; sichtbar unter /communications erst
//                  nach Anmeldung. Nicht öffentlich.
//   public       – öffentlich ohne Anmeldung unter /communications sichtbar
//
// `members` ist bewusst offener als `staff`: Die Stufe adressiert die gesamte
// angemeldete Mitgliedschaft, `staff` nur den internen Bearbeiterkreis. Wer
// `staff` lesen darf, darf deshalb auch `members` lesen — nicht umgekehrt.
//
// Auf DB-Ebene weiterhin freies Textfeld; Gültigkeit erzwingen Zod + TS-Union.
// Eine neue Stufe braucht daher keine Migration.
export const SMS_DOCUMENT_VISIBILITY_VALUES = [
  "confidential",
  "staff",
  "members",
  "public",
] as const

export type SmsDocumentVisibility =
  (typeof SMS_DOCUMENT_VISIBILITY_VALUES)[number]

export const SMS_DOCUMENT_VISIBILITY_LABELS: Record<
  SmsDocumentVisibility,
  string
> = {
  confidential: "Vertraulich",
  staff: "Intern",
  members: "Angemeldete Personen",
  public: "Öffentlich",
}

// Kurze Zielgruppen-Hinweise für die Sichtbarkeitsauswahl im Formular.
export const SMS_DOCUMENT_VISIBILITY_HINTS: Record<
  SmsDocumentVisibility,
  string
> = {
  confidential: "Nur Administrator und Safety Manager.",
  staff: "Zusätzlich Safety Assistants (angemeldet). Nicht öffentlich.",
  members:
    "Alle angemeldeten Personen mit zugewiesener Rolle – sichtbar unter /communications erst nach Anmeldung. Nicht öffentlich.",
  public:
    "Öffentlich ohne Anmeldung unter /communications sichtbar – auch für Administrator, Safety Manager und Safety Assistant.",
}

export function isSmsDocumentVisibility(
  value: string
): value is SmsDocumentVisibility {
  return (SMS_DOCUMENT_VISIBILITY_VALUES as readonly string[]).includes(value)
}

// ─── Übergangs-Kompatibilität zu den Altwerten internal/published ────────────
// Bis Migration 0023 (Umbenennung internal→confidential, published→staff) gegen
// Docker UND Neon angewandt ist, können in der DB noch Altwerte stehen. Die
// folgenden zwei Helfer bilden diese Altwerte auf das neue Modell ab, damit die
// Lesepfade während des Übergangs kompatibel bleiben.
//
// WICHTIG: Diese Kompatibilität gilt NICHT für die öffentliche Query — die
// filtert ausschließlich exakt auf visibility = 'public'.
//
// TODO (Cleanup nach 0023 auf Docker + Neon): Altwert-Zweige ('internal',
// 'published') hier und die Nutzung von SMS_DOCUMENT_STAFF_VISIBLE_DB_VALUES
// zurückbauen; unbekannte Werte danach nicht mehr erwarten.
export function normalizeVisibility(value: string): SmsDocumentVisibility {
  if (value === "internal") return "confidential"
  if (value === "published") return "staff"
  if (isSmsDocumentVisibility(value)) return value
  // Unbekannt → restriktivste Stufe, damit nie versehentlich öffentlich.
  return "confidential"
}

// DB-Werte, die ein Nicht-Editor (instructor) intern sehen darf: staff,
// members und public sowie der Altwert 'published' (= staff), solange 0023
// nicht angewandt ist. Bewusst OHNE 'confidential'/'internal' — instructor
// sieht Vertrauliches nie.
//
// `members` steht hier, weil ein Safety Assistant mindestens alles sehen muss, was
// ein einfaches Mitglied auf /communications sieht.
export const SMS_DOCUMENT_STAFF_VISIBLE_DB_VALUES = [
  "staff",
  "members",
  "public",
  "published",
] as const

// DB-Werte für ein angemeldetes Mitglied ohne internen Lesezugriff.
export const SMS_DOCUMENT_MEMBERS_VISIBLE_DB_VALUES = [
  "members",
  "public",
] as const

// DB-Werte ohne Anmeldung: exakt 'public'. Bewusst KEINE Normalisierung von
// Altwerten — nichts anderes wird je anmeldefrei ausgeliefert.
export const SMS_DOCUMENT_PUBLIC_VISIBLE_DB_VALUES = ["public"] as const

// ─── Leseregel: die eine Stelle ─────────────────────────────────────────────
//
// Welche Sichtbarkeitsstufen darf eine Rollenmenge lesen? Diese Funktion ist
// die einzige Antwort darauf. Öffentliche Liste (/communications), interne
// Liste (/dashboard/documents) und die Auslieferung von Anhängen leiten sich
// daraus ab und definieren nichts Eigenes.
//
// Rückgabe `null` heißt „keine Einschränkung“ und ist bewusst kein leeres
// Array und keine Aufzählung aller bekannten Werte: Ein unbekannter Wert in
// der Spalte gilt laut normalizeVisibility als 'confidential' und muss dem
// Bearbeiterkreis deshalb sichtbar bleiben. Eine Aufzählung würde ihn
// stillschweigend verschlucken — genau die Richtung, in die ein Fehler hier
// nicht laufen darf.
export function getReadableVisibilityDbValues(
  roleKeys: readonly AppRoleKey[]
): readonly string[] | null {
  if (hasSafetyEditRole(roleKeys)) return null
  if (hasDocumentReadRole(roleKeys)) return SMS_DOCUMENT_STAFF_VISIBLE_DB_VALUES
  // Vorher stand hier `roleKeys.length > 0` — die einzige Berechtigung im
  // System, die nicht über die Fähigkeitentabelle lief. Für die heutigen vier
  // Rollen ist das Ergebnis dasselbe; der Unterschied liegt in der Zukunft:
  // Eine fünfte Rolle erbt diesen Lesezugriff jetzt nicht mehr stillschweigend,
  // sondern muss in ROLE_CAPABILITIES eingetragen werden.
  if (hasMembersDocumentReadRole(roleKeys)) {
    return SMS_DOCUMENT_MEMBERS_VISIBLE_DB_VALUES
  }
  // Keine zugewiesene Rolle — ob angemeldet oder nicht — bedeutet die anonyme
  // Sicht. Ein Konto ohne Rolle sieht damit genau das, was ein anonymer
  // Besucher sieht.
  return SMS_DOCUMENT_PUBLIC_VISIBLE_DB_VALUES
}

/**
 * Dieselbe Regel, angewandt auf eine bereits geladene Zeile.
 *
 * Zweites Tor neben der WHERE-Bedingung: Fällt die SQL-Einschränkung durch
 * eine spätere Änderung weg, greift diese Prüfung weiterhin. Sie ist eine
 * reine Funktion ohne Datenbankzugriff und damit vollständig testbar.
 */
export function canReadDocumentVisibility(
  roleKeys: readonly AppRoleKey[],
  visibility: string
): boolean {
  const allowed = getReadableVisibilityDbValues(roleKeys)
  if (allowed === null) return true
  // Rohwert UND normalisierten Wert prüfen: die Listen führen die Altwerte
  // ausdrücklich mit, und ein unbekannter Wert normalisiert auf
  // 'confidential' — also auf die restriktivste Stufe, nie auf eine offenere.
  return (
    allowed.includes(visibility) ||
    allowed.includes(normalizeVisibility(visibility))
  )
}

// Auf /communications erscheinen ausschließlich diese beiden Stufen — 'staff'
// und 'confidential' unter keinen Umständen, auch nicht für Administrator oder
// Safety Manager. Die Seite ist eine Darstellungsfläche, keine zweite
// Berechtigungsregel.
const COMMUNICATIONS_SURFACE_DB_VALUES = ["public", "members"] as const

/**
 * Sichtbarkeits-DB-Werte für /communications: die Schnittmenge aus der
 * Darstellungsfläche der Seite und dem, was die Rollenmenge ohnehin lesen
 * darf. Ohne Rolle ergibt das exakt ['public'] — das bisherige Verhalten.
 */
export function getCommunicationsVisibilityDbValues(
  roleKeys: readonly AppRoleKey[]
): readonly string[] {
  const readable = getReadableVisibilityDbValues(roleKeys)
  if (readable === null) return [...COMMUNICATIONS_SURFACE_DB_VALUES]
  return COMMUNICATIONS_SURFACE_DB_VALUES.filter((value) =>
    readable.includes(value)
  )
}

// Die drei klar getrennten UI-Bereiche. Jede Kategorie gehört zu genau einem
// Bereich; die zulässigen Kategorien werden pro Bereich an die Formulare
// weitergereicht, damit die Struktur beim Anlegen/Bearbeiten erhalten bleibt.
export type SmsDocumentSection = {
  key: string
  title: string
  description: string
  categories: readonly SmsDocumentCategory[]
}

export const SMS_DOCUMENT_SECTIONS: readonly SmsDocumentSection[] = [
  {
    key: "policy_manual",
    title:
      "Sicherheitsrichtlinie, SMS-Handbuch, Checklisten und Bedienungsanleitungen",
    description:
      "Sicherheitsrichtlinie, SMS-Handbuch, Checklisten (z. B. Änderungsmanagement) und Bedienungsanleitungen für die Nutzung von PAOLO SMS als Text bzw. Markdown.",
    categories: ["safety_policy", "sms_manual", "checklist", "operating_manual"],
  },
  {
    key: "emergency_plans",
    title: "Notfallpläne",
    description:
      "Ein oder mehrere Notfallpläne. Schnittstellen- und Kontaktlisten werden im Inhalt eines Notfallplans geführt.",
    categories: ["emergency_plan"],
  },
  {
    key: "meeting_minutes",
    title: "Protokolle der Sicherheitsbesprechungen",
    description:
      "Protokolle der Sicherheitsbesprechungen als Text bzw. Markdown.",
    categories: ["safety_meeting_minutes"],
  },
  {
    key: "safety_information",
    title: "Sicherheitshinweise",
    description:
      "Frei formulierte Sicherheitshinweise (Warnungen, saisonale Hinweise, Lessons Learned, Verfahrensänderungen, organisatorische Hinweise). Können über die Sichtbarkeit „Öffentlich\" unter /communications freigegeben werden.",
    categories: ["safety_information"],
  },
]

export function isSmsDocumentCategory(
  value: string
): value is SmsDocumentCategory {
  return (SMS_DOCUMENT_CATEGORY_VALUES as readonly string[]).includes(value)
}

// ─── Hinweistexte des Sichtbarkeitsfeldes ───────────────────────────────────
// Bewusst Konstanten statt im Formular eingebetteter Literale: Der Wortlaut
// ist datenschutzrelevant und soll an einer Stelle stehen, an der er zusammen
// mit dem Sichtbarkeitsmodell gepflegt wird.

/**
 * Protokolle der Sicherheitsbesprechungen auf `members` zu stellen ist
 * ausdrücklich erlaubt, vergrößert den Empfängerkreis aber erheblich. Der
 * Hinweis ist die Mindestmaßnahme aus dem Datenschutzabschnitt von Issue #36.
 */
export const SMS_DOCUMENT_MEETING_MINUTES_MEMBERS_HINT =
  "Protokolle von Sicherheitsbesprechungen enthalten häufig personenbezogene oder vertrauliche Angaben — Namen von Beteiligten, Fallbezüge, interne Einschätzungen. Mit „Angemeldete Personen“ wird das Protokoll für alle angemeldeten Personen lesbar. Bitte vor dem Speichern prüfen, ob der Inhalt dafür geeignet ist, und gegebenenfalls eine gekürzte Fassung veröffentlichen."

/**
 * Hinweis auf die Nebenwirkung einer Herabstufung von `public`: Die öffentliche
 * Freigabe einzelner Anhänge wird dabei zurückgenommen (siehe
 * `lib/actions/sms-documents.ts`).
 */
export const SMS_DOCUMENT_PUBLIC_DOWNGRADE_HINT =
  "Mit dem Speichern wird die öffentliche Freigabe aller Anhänge dieses Dokuments zurückgenommen. Die Dateien sind dann ohne Anmeldung nicht mehr abrufbar. Eine spätere erneute Veröffentlichung des Dokuments gibt die Anhänge nicht automatisch wieder frei — jeder Anhang braucht dann eine neue Einzelfreigabe."
