// Anonymisierungsstatus einer Meldung.
//
// Dieser erste kontrollierte Schritt entfernt nur strukturierte Melderdaten
// (Name, Rolle, Kontakt). Freitexte und Anhaenge bleiben bewusst manuell zu
// pruefen — deshalb ist das Ergebnis "partial" und nicht "completed".
// Die weiteren Werte sind fuer spaetere Ausbaustufen vorgesehen (halbautomatische
// Anonymisierung, Freitext-/Anhangpruefung) und werden aktuell noch nicht gesetzt.
export const REPORT_ANONYMIZATION_STATUS_VALUES = [
  "none",
  "partial",
  "completed",
  "needs_review",
] as const

export type ReportAnonymizationStatus =
  (typeof REPORT_ANONYMIZATION_STATUS_VALUES)[number]

export const REPORT_ANONYMIZATION_STATUS_LABELS: Record<
  ReportAnonymizationStatus,
  string
> = {
  none: "Nicht anonymisiert",
  partial: "Teilweise anonymisiert",
  completed: "Anonymisiert",
  needs_review: "Manuell zu prüfen",
}
