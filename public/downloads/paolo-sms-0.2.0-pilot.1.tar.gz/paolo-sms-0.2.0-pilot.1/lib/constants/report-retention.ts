// DSGVO-Retention-Review (Arbeitspaket 4): Entscheidungswerte für das
// Prüfprotokoll (reportRetentionReviews) sowie eine reine Fälligkeits-
// Berechnungsfunktion. Bewusst getrennt von
// lib/constants/report-anonymization.ts — anonymizationStatus beschreibt den
// Grad der strukturierten Anonymisierung, dieses Modul beschreibt, ob/wann
// eine periodische Aufbewahrungsprüfung fällig ist und was zuletzt
// entschieden wurde. Beides sind unabhängige Achsen, siehe
// docs/data-protection-concept.md.

export const REPORT_RETENTION_REVIEW_DECISION_VALUES = [
  "reviewed_no_action",
  "postponed",
  "anonymized",
  "deleted",
] as const

export type ReportRetentionReviewDecision =
  (typeof REPORT_RETENTION_REVIEW_DECISION_VALUES)[number]

export const REPORT_RETENTION_REVIEW_DECISION_LABELS: Record<
  ReportRetentionReviewDecision,
  string
> = {
  reviewed_no_action: "Keine personenbezogenen Daten vorhanden",
  postponed: "Prüfung zurückstellen",
  anonymized: "Vollständig anonymisiert",
  deleted: "Meldung gelöscht",
}

export const RETENTION_REVIEW_STATUS_VALUES = [
  "not_configured",
  "not_eligible",
  "current",
  "soon",
  "overdue",
] as const

export type RetentionReviewStatus = (typeof RETENTION_REVIEW_STATUS_VALUES)[number]

export const RETENTION_REVIEW_STATUS_LABELS: Record<RetentionReviewStatus, string> = {
  not_configured: "Nicht konfiguriert",
  not_eligible: "Nicht fällig",
  current: "Aktuell",
  soon: "Bald fällig",
  overdue: "Überfällig",
}

// Ab wie vielen Tagen vor dem berechneten Fälligkeitsdatum als "bald fällig"
// gilt — analog zur bestehenden Sicherheitsbesprechungs-Statuslogik im
// Dashboard (app/dashboard/page.tsx).
const SOON_THRESHOLD_DAYS = 30

/**
 * Reine Funktion (kein DB-Zugriff): berechnet das Fälligkeitsdatum einer
 * Aufbewahrungsprüfung aus Anker + Intervall. Liefert `null`, wenn kein
 * Anker gesetzt ist (Report noch nicht geschlossen/ausgeblendet) oder kein
 * Intervall konfiguriert ist (Funktion deaktiviert). Wird dynamisch zur
 * Anzeigezeit berechnet, nicht materialisiert — Intervalländerungen wirken
 * dadurch sofort auf alle Reports, kein Backfill nötig.
 */
export function computeRetentionReviewDueAt(
  retentionReviewEligibleAt: Date | null,
  intervalMonths: number | null
): Date | null {
  if (!retentionReviewEligibleAt || !intervalMonths) return null
  const dueAt = new Date(retentionReviewEligibleAt)
  dueAt.setMonth(dueAt.getMonth() + intervalMonths)
  return dueAt
}

/**
 * Reine Funktion (kein DB-Zugriff): leitet aus Anker + Intervall den
 * Anzeigestatus ab (analog zur Sicherheitsbesprechungs-Kachel im
 * Dashboard: überfällig/bald/aktuell), zusätzlich die beiden Zustände
 * "nicht konfiguriert" (kein Intervall) und "nicht fällig" (kein Anker).
 */
export function computeRetentionReviewStatus(
  retentionReviewEligibleAt: Date | null,
  intervalMonths: number | null,
  now: Date = new Date()
): RetentionReviewStatus {
  if (!intervalMonths) return "not_configured"
  const dueAt = computeRetentionReviewDueAt(retentionReviewEligibleAt, intervalMonths)
  if (!dueAt) return "not_eligible"

  if (now.getTime() >= dueAt.getTime()) return "overdue"

  const soonThreshold = new Date(dueAt)
  soonThreshold.setDate(soonThreshold.getDate() - SOON_THRESHOLD_DAYS)
  if (now.getTime() >= soonThreshold.getTime()) return "soon"

  return "current"
}

/**
 * Reine Funktion (kein DB-Zugriff): naechstzulaessiges Datum (YYYY-MM-DD)
 * fuer "Zurückstellen bis" — muss in der Zukunft liegen, siehe
 * logRetentionReviewSchema (lib/actions/reports.ts). Dient als serverseitig
 * berechneter Wert fuer das <input type="date" min> der UI (reine
 * Client-Hilfe; massgeblich bleibt die serverseitige Pruefung). `now`
 * injizierbar fuer Tests.
 */
export function computeMinPostponedUntil(now: Date = new Date()): string {
  const min = new Date(now.getTime() + 24 * 60 * 60 * 1000)
  return min.toISOString().slice(0, 10)
}
