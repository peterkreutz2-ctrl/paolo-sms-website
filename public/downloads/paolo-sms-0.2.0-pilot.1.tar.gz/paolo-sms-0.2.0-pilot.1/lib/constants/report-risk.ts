// ICAO-orientierte Risikomatrix je Meldung: Eintrittswahrscheinlichkeit
// (Safety Risk Probability, 5..1) und Schweregrad (Safety Risk Severity, A..E).
// Reine strukturierte Erfassung — kein automatischer Workflow, keine Freigabe
// von Restrisiken. Werte werden als text gespeichert; "nicht bewertet" = null.

export const RISK_PROBABILITY_VALUES = ["5", "4", "3", "2", "1"] as const

export type RiskProbability = (typeof RISK_PROBABILITY_VALUES)[number]

export const RISK_PROBABILITY_LABELS: Record<RiskProbability, string> = {
  "5": "Häufig",
  "4": "Gelegentlich",
  "3": "Selten",
  "2": "Unwahrscheinlich",
  "1": "Äußerst unwahrscheinlich",
}

// Englische ICAO-Begriffe zur Referenz.
export const RISK_PROBABILITY_ICAO: Record<RiskProbability, string> = {
  "5": "Frequent",
  "4": "Occasional",
  "3": "Remote",
  "2": "Improbable",
  "1": "Extremely Improbable",
}

export const RISK_PROBABILITY_DESCRIPTIONS: Record<RiskProbability, string> = {
  "5": "Tritt sehr oft auf; ist in der Vergangenheit bereits mehrfach im eigenen Betrieb vorgekommen.",
  "4": "Tritt ab und zu auf; ist dem Unternehmen oder in der Branche bekannt.",
  "3": "Unwahrscheinlich, aber möglich; kommt in der Luftfahrt insgesamt nur selten vor.",
  "2": "Sehr unwahrscheinlich; es gibt kaum bekannte Fälle.",
  "1": "Fast undenkbar; ein Auftreten gilt als nahezu ausgeschlossen.",
}

export const RISK_SEVERITY_VALUES = ["A", "B", "C", "D", "E"] as const

export type RiskSeverity = (typeof RISK_SEVERITY_VALUES)[number]

export const RISK_SEVERITY_LABELS: Record<RiskSeverity, string> = {
  A: "Katastrophal",
  B: "Gefährlich",
  C: "Wesentlich",
  D: "Geringfügig",
  E: "Vernachlässigbar",
}

// Englische ICAO-Begriffe zur Referenz.
export const RISK_SEVERITY_ICAO: Record<RiskSeverity, string> = {
  A: "Catastrophic",
  B: "Hazardous",
  C: "Major",
  D: "Minor",
  E: "Negligible",
}

export const RISK_SEVERITY_DESCRIPTIONS: Record<RiskSeverity, string> = {
  A: "Zerstörung des Fluggeräts, Totalverlust von Ausrüstung oder mehrere Todesopfer.",
  B: "Große Reduzierung der Sicherheitsmarge; extreme Arbeitsbelastung; schwere Verletzungen von Personen oder erhebliche Sachschäden.",
  C: "Deutliche Verringerung der Sicherheitsmarge; spürbar erhöhte Arbeitsbelastung; erhebliche sicherheitsrelevante Auswirkungen oder Verletzungen von Personen.",
  D: "Betriebliche Einschränkungen; Nutzung von Notfallverfahren; geringe sicherheitsrelevante Auswirkungen oder Unannehmlichkeiten.",
  E: "Kaum nennenswerte Auswirkungen oder Konsequenzen für die Sicherheit.",
}

export function isRiskProbability(v: string | null | undefined): v is RiskProbability {
  return v != null && (RISK_PROBABILITY_VALUES as readonly string[]).includes(v)
}

export function isRiskSeverity(v: string | null | undefined): v is RiskSeverity {
  return v != null && (RISK_SEVERITY_VALUES as readonly string[]).includes(v)
}

/**
 * Kombinierter ICAO-Risikocode, z. B. "5A", "3C". Nur wenn beide Teile
 * bewertet sind; sonst null.
 */
export function formatRiskCode(
  probability: string | null | undefined,
  severity: string | null | undefined
): string | null {
  if (!isRiskProbability(probability) || !isRiskSeverity(severity)) return null
  return `${probability}${severity}`
}

// ─── Risikotoleranz (ICAO 5×5, rot/gelb/grün) ────────────────────────────────
// Zellzuordnung fachlich von Peter freigegeben. Rein dokumentarisch/darstellend:
// erzeugt KEINEN automatischen Workflow und KEINE Freigabe von Restrisiken.

export const RISK_TOLERANCE_VALUES = [
  "intolerable",
  "tolerable",
  "acceptable",
] as const

export type RiskTolerance = (typeof RISK_TOLERANCE_VALUES)[number]

// Explizite Codelisten je Bereich (keine abgeleitete Logik, um genau die
// freigegebene Zuordnung abzubilden).
const INTOLERABLE_CODES = ["5A", "5B", "5C", "4A", "4B", "3A"] as const
const TOLERABLE_CODES = [
  "5D", "5E", "4C", "4D", "4E", "3B", "3C", "3D", "2A", "2B", "2C",
] as const
const ACCEPTABLE_CODES = ["3E", "2D", "2E", "1A", "1B", "1C", "1D", "1E"] as const

const RISK_TOLERANCE_BY_CODE: Record<string, RiskTolerance> = {
  ...Object.fromEntries(INTOLERABLE_CODES.map((c) => [c, "intolerable"])),
  ...Object.fromEntries(TOLERABLE_CODES.map((c) => [c, "tolerable"])),
  ...Object.fromEntries(ACCEPTABLE_CODES.map((c) => [c, "acceptable"])),
}

export const RISK_TOLERANCE_LABELS: Record<RiskTolerance, string> = {
  intolerable: "Inakzeptabel",
  tolerable: "Tolerierbar",
  acceptable: "Akzeptabel",
}

export const RISK_TOLERANCE_DESCRIPTIONS: Record<RiskTolerance, string> = {
  intolerable:
    "Das Risiko ist zu hoch. Der Betrieb muss in diesem Bereich gestoppt werden; Maßnahmen zur Risikominderung sind zwingend erforderlich.",
  tolerable:
    "Das Risiko ist nur akzeptabel, wenn es nach dem ALARP-Prinzip so weit wie vernünftigerweise möglich gesenkt und aktiv überwacht wird.",
  acceptable:
    "Keine unmittelbaren Maßnahmen nötig; Beobachtung im normalen SMS-Monitoring.",
}

/**
 * Risikobereich (rot/gelb/grün) für eine Kombination. Gibt null zurück, wenn
 * Wahrscheinlichkeit oder Schweregrad fehlt („nicht bewertet").
 */
export function getRiskTolerance(
  probability: string | null | undefined,
  severity: string | null | undefined
): RiskTolerance | null {
  const code = formatRiskCode(probability, severity)
  if (!code) return null
  return RISK_TOLERANCE_BY_CODE[code] ?? null
}

export function getRiskToleranceLabel(
  probability: string | null | undefined,
  severity: string | null | undefined
): string | null {
  const tolerance = getRiskTolerance(probability, severity)
  return tolerance ? RISK_TOLERANCE_LABELS[tolerance] : null
}

export function getRiskToleranceDescription(
  probability: string | null | undefined,
  severity: string | null | undefined
): string | null {
  const tolerance = getRiskTolerance(probability, severity)
  return tolerance ? RISK_TOLERANCE_DESCRIPTIONS[tolerance] : null
}
