// Zugriffsregel fuer die oeffentliche Auslieferung von Anhaengen an
// SMS-Dokumenten.
//
// Bewusst eine reine Funktion ohne DB-Zugriff: die oeffentliche Route ist der
// einzige anmeldefreie Pfad zu Dateiinhalten, ihre Bedingung muss deshalb
// vollstaendig und ohne Datenbank pruefbar sein.
//
// Die Route filtert dieselben Bedingungen zusaetzlich bereits in SQL. Diese
// Funktion ist keine zweite Spezifikation, sondern ein zweites Tor auf der
// tatsaechlich geladenen Zeile: faellt die WHERE-Bedingung durch eine spaetere
// Aenderung weg, greift sie weiterhin.

import { sanitizeFileName } from "./attachment-file-types"
import type { AppRoleKey } from "./roles"
import {
  canReadDocumentVisibility,
  normalizeVisibility,
  SMS_DOCUMENT_VISIBILITY_LABELS,
  type SmsDocumentVisibility,
} from "./sms-documents"

export type PublicAttachmentAccessInput = {
  /** attachments.is_public */
  isPublic: boolean
  /** attachments.sms_document_id — NULL bei Anhaengen von Meldungen. */
  smsDocumentId: string | null
  /**
   * sms_documents.visibility des Elterndokuments, oder null, wenn es keines
   * gibt bzw. keines geladen werden konnte.
   */
  documentVisibility: string | null
}

/**
 * Darf dieser Anhang ohne Anmeldung ausgeliefert werden?
 *
 * Drei Bedingungen, alle notwendig:
 *   1. Der Anhang gehoert zu einem SMS-Dokument. Anhaenge von Meldungen sind
 *      niemals oeffentlich — auch nicht versehentlich.
 *   2. Der Anhang ist ausdruecklich freigegeben.
 *   3. Das Elterndokument ist selbst oeffentlich.
 *
 * Die Sichtbarkeit wird hart auf exakt "public" geprueft, ohne Normalisierung
 * von Altwerten — dasselbe bewusst restriktive Vorgehen wie in der
 * oeffentlichen Dokumentenliste (app/communications/page.tsx). Ein unbekannter
 * oder alter Wert fuehrt damit zu "nicht oeffentlich", nie umgekehrt.
 */
export function canServePublicly(input: PublicAttachmentAccessInput): boolean {
  if (input.smsDocumentId === null) return false
  if (input.isPublic !== true) return false
  return input.documentVisibility === "public"
}

// ─── Zweites Tor: Zugriff MIT Sitzung ───────────────────────────────────────
//
// Bewusst getrennt von canServePublicly und bewusst daneben, damit beide Tore
// in einer Datei nebeneinander pruefbar sind:
//
//   canServePublicly    entscheidet ueber den anmeldefreien Pfad und haengt
//                       ausschliesslich an attachments.is_public plus exakt
//                       visibility = 'public'.
//   canServeToSession   entscheidet ueber den Pfad mit Sitzung und haengt
//                       ausschliesslich an den Rollen und der Sichtbarkeit des
//                       Elterndokuments.
//
// Die beiden Richtungen werden nie vermischt:
//   - is_public wird NIE aus der Dokumentsichtbarkeit abgeleitet. Ein Dokument
//     auf 'public' zu heben gibt keinen einzigen Anhang frei; dafuer gibt es
//     ausschliesslich publishSmsDocumentAttachment mit Checkliste und Audit.
//   - Der Sitzungszugriff wird NIE aus is_public abgeleitet. Ein nicht
//     freigegebener Anhang eines 'members'-Dokuments ist fuer Mitglieder
//     abrufbar, ein freigegebener Anhang eines herabgestuften Dokuments fuer
//     Anonyme dagegen nicht.

export type SessionAttachmentAccessInput = {
  /** Rollen des angemeldeten Benutzers; leer = keine zugewiesene PAOLO-Rolle. */
  roleKeys: readonly AppRoleKey[]
  /** attachments.sms_document_id — NULL bei Anhaengen von Meldungen. */
  smsDocumentId: string | null
  /** sms_documents.visibility des Elterndokuments. */
  documentVisibility: string | null
}

/**
 * Darf dieser Anhang an eine bestehende Sitzung ausgeliefert werden?
 *
 * Die Sichtbarkeit wird vom Elterndokument geerbt: Wer das Dokument lesen
 * darf, darf seine Anhaenge herunterladen. Anhaenge haben bewusst KEINE eigene
 * Sichtbarkeitsspalte — eine zweite Quelle waere eine zweite Wahrheit.
 *
 * Anhaenge von Meldungen (smsDocumentId === null) sind ausgeschlossen; fuer sie
 * gilt die eigene Route unter /dashboard/reports.
 */
export function canServeToSession(
  input: SessionAttachmentAccessInput
): boolean {
  if (input.smsDocumentId === null) return false
  if (input.documentVisibility === null) return false
  return canReadDocumentVisibility(input.roleKeys, input.documentVisibility)
}

// ─── Beschriftung des Anhang-Status ─────────────────────────────────────────

/**
 * Wie weit reicht dieser Anhang gerade? Drei Zustaende:
 *
 *   "public"     freigegeben UND Elterndokument oeffentlich — ohne Anmeldung
 *                abrufbar.
 *   "released"   freigegeben, Elterndokument aber nicht oeffentlich. Die
 *                Freigabe steht, wirkt aber nicht; "Öffentlich freigegeben"
 *                waere hier irrefuehrend.
 *   "inherited"  nicht freigegeben. Die Reichweite ist die des
 *                Elterndokuments — bei 'members' also jedes angemeldete
 *                Mitglied, nicht nur der Bearbeiterkreis.
 *
 * Der vierte Fall braucht eine eigene Beschriftung: Ein nicht freigegebener
 * Anhang an einem OEFFENTLICHEN Dokument ist anmeldefrei gerade NICHT
 * abrufbar — "Sichtbar: Öffentlich" waere hier genauso falsch wie vorher
 * "Nur intern" bei 'members', nur in die andere Richtung. Erreichbar ist er
 * fuer jede Sitzung, weil jede Rollenmenge ein oeffentliches Dokument lesen
 * darf.
 *
 * Bewusst eine reine Funktion neben den beiden Toren: Die Beschriftung
 * behauptet gegenueber dem Bearbeiter eine Reichweite, und diese Behauptung
 * muss dieselbe Quelle haben wie die Auslieferung selbst. Vorher stand an
 * dieser Stelle pauschal "Nur intern" — das untertreibt bei einem
 * 'members'-Dokument und verschweigt den Unterschied zu 'confidential'.
 */
export type AttachmentReach =
  | { kind: "public" }
  | { kind: "released" }
  | { kind: "inherited"; visibility: SmsDocumentVisibility }

export function describeAttachmentReach(input: {
  isPublic: boolean
  documentVisibility: string
}): AttachmentReach {
  if (input.isPublic) {
    return input.documentVisibility === "public"
      ? { kind: "public" }
      : { kind: "released" }
  }
  return {
    kind: "inherited",
    visibility: normalizeVisibility(input.documentVisibility),
  }
}

/** Badge-Text zu einer Reichweite. */
export function attachmentReachLabel(reach: AttachmentReach): string {
  if (reach.kind === "public") return "Öffentlich abrufbar"
  if (reach.kind === "released") return "Freigegeben – noch nicht öffentlich"
  if (reach.visibility === "public") return "Nicht freigegeben – nur angemeldet"
  return `Sichtbar: ${SMS_DOCUMENT_VISIBILITY_LABELS[reach.visibility]}`
}

/** Pfad der Auslieferung mit Sitzung. Neutral, nicht unter /dashboard: die
 *  Route bedient auch Mitglieder ohne internen Dashboard-Zugang. */
export function buildSessionAttachmentPath(
  documentId: string,
  attachmentId: string
): string {
  return `/documents/${documentId}/attachments/${attachmentId}/download`
}

// ─── Oeffentliche URL ───────────────────────────────────────────────────────

/**
 * Pfad der kontrollierten oeffentlichen Auslieferung. Der Dateiname bildet den
 * letzten Abschnitt, damit die URL auf die Originalendung endet — externe
 * Werkzeuge erkennen das Format teilweise daran. Fuer die Berechtigung ist
 * ausschliesslich die Attachment-ID massgeblich; der Abschnitt wird von der
 * Route nicht ausgewertet.
 */
export function buildPublicAttachmentPath(
  attachmentId: string,
  fileName: string
): string {
  return `/communications/attachments/${attachmentId}/${sanitizeFileName(fileName)}`
}

// ─── Auslieferungsart ───────────────────────────────────────────────────────

// Nur diese drei Typen werden inline ausgeliefert, damit ein <img> sie
// darstellen kann. Bewusst eine enge Positivliste statt "image/*": SVG ist
// kein Bild im harmlosen Sinn, sondern ein Dokument, das Skript enthalten
// kann. Es steht ohnehin nicht auf der Upload-Allowlist — diese Liste haelt
// den Schutz auch dann aufrecht, wenn sich das einmal aendert.
const INLINE_IMAGE_MIME_TYPES = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
])

/**
 * Wird dieser Typ im Browser abgespielt? Nur MP4 — die Auslieferung erfolgt
 * inline, damit ein <video>-Element die Datei laden kann.
 */
export function isPlayableVideo(mimeType: string): boolean {
  return mimeType === "video/mp4"
}

/**
 * Antwortheader fuer die Auslieferung eines Anhangs.
 *
 * `Content-Length` wird bewusst nur fuer Video gesetzt, aus dem beim Upload
 * gespeicherten `fileSize`. Ohne Laengenangabe uebertraegt die Route chunked,
 * und der Browser kennt die Dateigroesse nicht vorab — bei Video fuehrt das
 * dazu, dass die Zeitleiste zunaechst keine Dauer zeigt. Fuer die uebrigen
 * Typen bringt die Angabe nichts und wuerde nur die Angriffsflaeche fuer eine
 * Abweichung zwischen gespeicherter und tatsaechlicher Groesse vergroessern.
 *
 * Bewusst KEIN Range-Handling: bei maximal 4 MiB ist der Puffer sofort voll,
 * und Chrome, Edge und Firefox spielen eine 200-Antwort ohne Range-
 * Unterstuetzung ab. Safari verlangt 206 und ist damit ausgenommen — deshalb
 * bleibt neben dem Player immer der Download-Link stehen.
 */
export function buildAttachmentDeliveryHeaders(input: {
  mimeType: string
  fileName: string
  fileSize: number
  fallbackContentType: string
  cacheControl: string
}): Record<string, string> {
  const headers: Record<string, string> = {
    "Content-Type": input.mimeType || input.fallbackContentType,
    "Content-Disposition": buildContentDisposition(
      input.mimeType,
      input.fileName
    ),
    "X-Content-Type-Options": "nosniff",
    "Cache-Control": input.cacheControl,
  }

  if (isPlayableVideo(input.mimeType) && input.fileSize > 0) {
    headers["Content-Length"] = String(input.fileSize)
  }

  return headers
}

/**
 * Darf dieser MIME-Typ inline ausgeliefert werden (Content-Disposition:
 * inline)? Alles andere — insbesondere PDF und Tracklogs — wird als Download
 * ausgeliefert. PDF bewusst nicht inline: ein PDF laeuft im Browser-Viewer
 * unter der eigenen Herkunft, das ist eine eigene Sicherheitsentscheidung.
 */
export function isInlineDisplayableImage(mimeType: string): boolean {
  return INLINE_IMAGE_MIME_TYPES.has(mimeType)
}

/** Wird der Typ inline ausgeliefert — Bild oder Video? */
function isInlineDeliverable(mimeType: string): boolean {
  return INLINE_IMAGE_MIME_TYPES.has(mimeType) || mimeType === "video/mp4"
}

/**
 * Baut den Content-Disposition-Header. `inline` nur fuer Bilder aus der engen
 * Positivliste, sonst `attachment`.
 */
export function buildContentDisposition(
  mimeType: string,
  fileName: string
): string {
  const mode = isInlineDeliverable(mimeType) ? "inline" : "attachment"
  const safeFileName = fileName.replace(/["\\]/g, "_")
  const encoded = encodeURIComponent(fileName)
  return `${mode}; filename="${safeFileName}"; filename*=UTF-8''${encoded}`
}
