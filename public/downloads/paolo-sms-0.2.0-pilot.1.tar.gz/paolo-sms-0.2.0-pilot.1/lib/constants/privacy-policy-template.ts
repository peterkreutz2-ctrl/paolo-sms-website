// Unverbindlicher PAOLO-Vorschlag für eine Datenschutzerklärung.
//
// WICHTIG: Dies ist KEIN geprüfter Rechtstext. Der Betreiber übernimmt den Text
// in den Einstellungen, passt ihn an seine Konstellation (Verein, Flugschule,
// Verband) an und lässt ihn vor Echtdatenbetrieb rechtlich prüfen. PAOLO leistet
// keine Rechtsberatung.
//
// Bewusst Plain Text mit Absätzen (keine HTML-/Markdown-Auszeichnung), damit der
// gespeicherte Betreibertext auf /datenschutz sicher als reiner Text gerendert
// werden kann (kein HTML-Injection-Risiko). Betreiberspezifische Angaben
// (Verantwortlicher, Kontakt, Aufsichtsbehörde, Hosting, Speicherdauer) werden
// separat über die strukturierten Felder gepflegt und getrennt angezeigt.
export const PRIVACY_POLICY_TEMPLATE = `Datenschutzerklärung (Vorschlag)

Dieser Text ist ein unverbindlicher Vorschlag und muss vom Betreiber vor Echtdatenbetrieb geprüft und angepasst werden. Die betreiberspezifischen Angaben (Verantwortlicher, Datenschutzkontakt, Aufsichtsbehörde, Empfänger/Hosting, Speicherdauer) werden gesondert oben angezeigt.

Zweck dieser PAOLO-Instanz
PAOLO SMS ist ein Safety-Management-System für Gleitschirmschulen und Vereine. Diese Instanz dient dazu, sicherheitsrelevante Ereignisse, Beobachtungen und Risiken im Sinne einer nicht-punitiven Meldekultur zu erfassen, zu bearbeiten und nachzuverfolgen.

Zwecke der Verarbeitung
- Erfassung und Bearbeitung von Sicherheitsmeldungen
- Ableitung und Nachverfolgung von Maßnahmen
- Durchführung und Dokumentation von Sicherheitsbesprechungen
- Verwaltung interner Benutzerkonten und Rollen
- Nachvollziehbarkeit relevanter Aktionen über ein Audit-Log

Datenkategorien
- Meldungsdaten (Art, Zeitpunkt, Ort, Beschreibung, Klassifikation)
- freiwillige Melderangaben (Name, Rolle, Kontakt) bei namentlichen Meldungen
- Inhalte von Freitexten und Anhängen
- interne Benutzerdaten (Anmeldung, Rolle, zugeordnete Aktionen)
- technische Betriebsdaten (siehe unten)

Anonyme und namentliche Meldungen
Meldungen können anonym oder mit Melderangaben abgegeben werden. Bei anonymen Meldungen werden keine strukturierten Melderdaten (Name, Rolle, Kontakt) erhoben. Freitexte und Anhänge können jedoch – unabhängig von der Anonymität – personenbezogene Daten enthalten, wenn Meldende solche Angaben machen.

Anonymisierung
Strukturierte Melderdaten (Name, Rolle, Kontakt) können nach Abschluss oder Ausblenden einer Meldung anonymisiert werden. Freitexte und Anhänge werden dabei nicht automatisch anonymisiert und sind bei Bedarf manuell zu prüfen.

Benutzerkonten und Rollen
Angemeldete Personen erhalten Rollen (z. B. Administrator, Safety Manager, Safety Assistant). Aktionen werden rollenbasiert geprüft und zur Nachvollziehbarkeit in einem Audit-Log protokolliert.

Wer die Melderangaben sieht
Strukturierte Melderangaben (Name, Rolle, Kontakt) und interne Bearbeitungsnotizen sind ausschließlich für die Rollen Safety Manager und Administrator zugänglich. Die Rolle Safety Assistant sieht den sicherheitsfachlichen Inhalt einer Meldung, aber weder die Melderangaben noch die internen Notizen; die Daten werden für diese Rolle serverseitig nicht bereitgestellt. Freitexte und Anhänge sind davon nicht erfasst – dort genannte Namen sind für alle internen Rollen lesbar.

Technische Betriebsdaten und Server-Logs
Beim Betrieb können technisch notwendige Daten anfallen (z. B. Server-Logs, IP-Adressen, Zeitpunkt und Art des Zugriffs). Umfang und Aufbewahrung hängen vom Hosting des Betreibers ab; Näheres ergibt sich aus den Angaben unter „Empfänger / Dienstleister / Hosting".

Schutz des öffentlichen Meldeformulars vor Spam und Missbrauch
Zum Schutz vor Spam und Missbrauch verarbeitet PAOLO für die Begrenzung mehrfacher Formularsendungen einen pseudonymisierten Identifier. Er wird mit einem installationsspezifischen Geheimnis aus der normalisierten IP-Adresse gebildet; die rohe IP-Adresse wird nicht in der Rate-Limit-Tabelle gespeichert. Die Datensätze sind standardmäßig nach einem Tag zur Löschung vorgesehen und werden beim nächsten erfolgreichen Meldevorgang automatisch entfernt. Geht keine weitere Meldung ein, können sie länger gespeichert bleiben; eine garantierte Obergrenze setzt den im Betreiber-Runbook beschriebenen manuellen Cleanup voraus. Als Rechtsgrundlage kommt Art. 6 Abs. 1 lit. f DSGVO in Betracht; das berechtigte Interesse liegt im Schutz des Formulars vor missbräuchlicher Nutzung. Diese Einordnung und die konkrete Aufbewahrung muss der Betreiber für seine Installation prüfen und anpassen.

Cookies, Session und Authentifizierung
PAOLO verwendet technisch notwendige Cookies bzw. vergleichbare Mechanismen für Anmeldung und Sitzungsverwaltung. Für die öffentliche Abgabe einer Meldung ist keine Anmeldung erforderlich.

Empfänger und Dienstleister
Zur Bereitstellung können Auftragsverarbeiter eingesetzt werden (z. B. Hosting, Datenbank, Authentifizierung, Dateiablage). Die konkreten Dienstleister ergeben sich aus den Betreiberangaben („Empfänger / Dienstleister / Hosting"). Der Betreiber verantwortet die erforderlichen Vereinbarungen, etwa zur Auftragsverarbeitung.

Speicherdauer
Personenbezogene Daten werden gespeichert, solange dies für die genannten Zwecke oder aufgrund gesetzlicher Pflichten erforderlich ist. Die konkrete Speicherdauer legt der Betreiber fest (siehe Angabe „Speicherdauer").

Rechtsgrundlagen
Die zutreffenden Rechtsgrundlagen hängen vom jeweiligen Betreiber und Einsatzzweck ab. In Betracht kommen je nach Fall insbesondere Art. 6 Abs. 1 lit. f (berechtigtes Interesse), lit. b (Vertrag/Mitgliedschaft), lit. c (rechtliche Verpflichtung) oder lit. a (Einwilligung) DSGVO. Welche Grundlage konkret gilt, muss der Betreiber prüfen; PAOLO trifft hierzu keine verbindliche Festlegung.

Rechte der betroffenen Personen
Betroffene haben nach Maßgabe der DSGVO insbesondere Rechte auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung, Datenübertragbarkeit sowie Widerspruch. Anfragen richten sich an den oben genannten Datenschutzkontakt.

Beschwerderecht bei einer Aufsichtsbehörde
Betroffene haben das Recht, sich bei einer Datenschutzaufsichtsbehörde zu beschweren. Die zuständige Behörde ist – soweit hinterlegt – oben unter „Zuständige Aufsichtsbehörde" angegeben.

Sichere Übertragung (SSL/TLS)
Die Übertragung erfolgt üblicherweise verschlüsselt über SSL/TLS. Die konkrete Bereitstellung (z. B. Reverse Proxy, Zertifikate) verantwortet der Betreiber.

Kein Tracking, keine Werbung
Solange PAOLO unverändert betrieben wird, finden keine Werbung, kein Tracking, kein E-Commerce und keine Zahlungsabwicklung statt.

Datenschutzvorfälle
PAOLO unterstützt die interne Dokumentation und Nachverfolgung von Datenschutzvorfällen. Eine Meldung an Aufsichtsbehörden oder eine Benachrichtigung Betroffener erfolgt nicht automatisch; deren Prüfung und Durchführung obliegt dem Betreiber.`
