// Sicherheitshinweis an jeder Stelle, an der eine Datei hochgeladen werden
// kann.
//
// Warum ueberhaupt ein Hinweis: PAOLO prueft hochgeladene Dateien NICHT auf
// Schadcode. Erlaubte Dateitypen, Groessenlimit und ein Loeschkonzept sind
// umgesetzt, die Malware-/Virenpruefung fehlt (siehe
// docs/production-readiness.md). Solange das so ist, ist die Sorgfalt der
// hochladenden Person die einzige Massnahme an dieser Stelle — und sie muss
// dort stehen, wo hochgeladen wird, nicht in einer Betriebsdokumentation.
//
// Bewusst eine Konstante und nicht drei Literale in den Formularen: Der
// Wortlaut ist eine Sicherheitsaussage. Er soll an einer Stelle gepflegt
// werden und an allen Upload-Stellen identisch erscheinen.
export const UPLOAD_MALWARE_NOTICE =
  "Sicherheitshinweis: Anhänge können Schadsoftware enthalten. Lade nur Dateien hoch, deren Herkunft du kennst und denen du vertraust. Dateien aus externen oder unsicheren Quellen müssen vor dem Hochladen auf Schadsoftware geprüft werden."
