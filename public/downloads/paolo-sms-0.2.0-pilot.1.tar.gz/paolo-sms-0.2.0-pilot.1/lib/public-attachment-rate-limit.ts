// Rate-Begrenzung fuer die oeffentliche Attachment-Route (AP3).
//
// Bewusst KEINE zweite Infrastruktur: dieselbe Tabelle
// `public_report_rate_limits`, dieselben Primitive (IP-Normalisierung inkl.
// IPv6-/64-Aggregation, HMAC-Identifier, feste Zeitfenster) aus
// lib/public-report-rate-limit.ts. Unterschiedlich sind nur zwei Dinge: der
// `scope` — die Spalte existiert genau dafuer — und die Obergrenze.
//
// Warum die Obergrenze deutlich hoeher liegt als beim Meldeformular: eine
// oeffentliches SMS-Dokument kann mehrere Bilder enthalten, und jedes
// Bild ist ein eigener Abruf dieser Route. Ein Seitenaufruf kostet damit
// leicht ein halbes Dutzend Anfragen, ein Reload dasselbe noch einmal. Die
// Grenze soll massenhaftes Absaugen begrenzen, nicht normales Lesen.

import { and, eq, sql } from "drizzle-orm"

import { db } from "@/lib/db"
import { publicReportRateLimits } from "@/lib/db/schema"
import {
  createPublicReportIdentifierHash,
  getPublicReportRateLimitRetryAfterSeconds,
  getPublicReportRateLimitWindowStart,
  PUBLIC_REPORT_RATE_LIMIT_WINDOW_SECONDS,
  resolvePublicReportClientIp,
} from "@/lib/public-report-rate-limit"

export const PUBLIC_ATTACHMENT_RATE_LIMIT_SCOPE = "public_attachment_download"

/** Abrufe je Client und Stunde. Grosszuegig; siehe Begruendung oben. */
export const PUBLIC_ATTACHMENT_RATE_LIMIT_DEFAULT_MAX = 300

const MAX_CONFIGURED = 100_000

export function getPublicAttachmentRateLimitMax(
  configuredValue = process.env.PUBLIC_ATTACHMENT_RATE_LIMIT_MAX
): number {
  const normalized = configuredValue?.trim()
  if (!normalized || !/^\d+$/.test(normalized)) {
    return PUBLIC_ATTACHMENT_RATE_LIMIT_DEFAULT_MAX
  }
  const parsed = Number(normalized)
  if (!Number.isSafeInteger(parsed) || parsed < 1 || parsed > MAX_CONFIGURED) {
    return PUBLIC_ATTACHMENT_RATE_LIMIT_DEFAULT_MAX
  }
  return parsed
}

export type RateLimitDecision =
  | { allowed: true }
  | { allowed: false; retryAfterSeconds: number }

/**
 * Zaehlt einen Abruf und entscheidet, ob er bedient werden darf.
 *
 * Bewusst "fail open": ist kein Salt konfiguriert, keine Client-IP ermittelbar
 * oder die Zaehlung schlaegt fehl, wird der Abruf erlaubt. Eine oeffentliche
 * SMS-Dokument soll nicht wegen eines Buchhaltungsproblems
 * unlesbar werden — die eigentliche Zugriffskontrolle leistet ohnehin die
 * Freigabepruefung der Route, nicht dieses Limit.
 */
export async function consumePublicAttachmentRateLimit(
  organizationId: string,
  headers: Headers
): Promise<RateLimitDecision> {
  const salt = process.env.PUBLIC_REPORT_RATE_LIMIT_SALT?.trim()
  if (!salt) return { allowed: true }

  const clientIp = resolvePublicReportClientIp(headers)
  if (!clientIp) return { allowed: true }

  const identifier = createPublicReportIdentifierHash(salt, clientIp)
  if (!identifier) return { allowed: true }

  const windowStart = getPublicReportRateLimitWindowStart()
  const max = getPublicAttachmentRateLimitMax()

  try {
    // Ein einziges UPSERT je Abruf: legt den Zaehler an oder erhoeht ihn und
    // liefert den neuen Stand zurueck. Kein Vorab-SELECT, damit parallele
    // Abrufe derselben Seite nicht aneinander vorbeizaehlen.
    const [bucket] = await db
      .insert(publicReportRateLimits)
      .values({
        organizationId,
        scope: PUBLIC_ATTACHMENT_RATE_LIMIT_SCOPE,
        identifier,
        windowStart,
        windowDurationSeconds: PUBLIC_REPORT_RATE_LIMIT_WINDOW_SECONDS,
        acceptedCount: 1,
      })
      .onConflictDoUpdate({
        target: [
          publicReportRateLimits.organizationId,
          publicReportRateLimits.scope,
          publicReportRateLimits.identifier,
          publicReportRateLimits.windowStart,
        ],
        set: {
          acceptedCount: sql`${publicReportRateLimits.acceptedCount} + 1`,
          updatedAt: new Date(),
        },
      })
      .returning({ acceptedCount: publicReportRateLimits.acceptedCount })

    if (!bucket || bucket.acceptedCount <= max) {
      return { allowed: true }
    }

    // Ueberschreitung getrennt mitzaehlen, damit im Betrieb erkennbar bleibt,
    // ob das Limit greift. Historisch zaehlt acceptedCount hier ALLE Versuche
    // nach der Freigabepruefung, auch die blockierten; beim Meldeformular
    // dagegen nur gespeicherte Meldungen. Monitoring muss nach Scope trennen.
    await db
      .update(publicReportRateLimits)
      .set({ blockedCount: sql`${publicReportRateLimits.blockedCount} + 1` })
      .where(
        and(
          eq(publicReportRateLimits.organizationId, organizationId),
          eq(
            publicReportRateLimits.scope,
            PUBLIC_ATTACHMENT_RATE_LIMIT_SCOPE
          ),
          eq(publicReportRateLimits.identifier, identifier),
          eq(publicReportRateLimits.windowStart, windowStart)
        )
      )

    return {
      allowed: false,
      retryAfterSeconds: getPublicReportRateLimitRetryAfterSeconds(windowStart),
    }
  } catch (error) {
    console.error("[public-attachment-rate-limit] Zaehlung fehlgeschlagen:", error)
    return { allowed: true }
  }
}
