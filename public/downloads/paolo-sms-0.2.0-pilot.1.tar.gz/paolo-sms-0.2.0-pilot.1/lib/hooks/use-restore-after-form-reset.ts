"use client"

import { useEffect, useRef, type RefObject } from "react"

/**
 * Stellt den sichtbaren Zustand kontrollierter NATIVER Formularfelder nach dem
 * automatischen Formular-Reset wieder her.
 *
 * Hintergrund: React 19 fuehrt nach JEDER abgeschlossenen Form-Action (Erfolg
 * wie Validierungsfehler) ein natives form.reset() aus. Kontrollierte native
 * Felder verlieren dabei ihre Anzeige:
 * - <select> springt auf die erste Option, weil React fuer kontrollierte Felder
 *   kein "selected"-Attribut setzt,
 * - Checkboxen fallen auf "nicht angehakt" zurueck.
 * Der React-State bleibt dabei unveraendert — und weil React den DOM bei
 * unveraendertem State nicht neu schreibt (Diffing-Bail-out), laufen Anzeige und
 * State dauerhaft auseinander.
 *
 * Die Wiederherstellung laeuft bewusst in einem Microtask: Der reset-Listener
 * feuert VOR der eigentlichen Reset-Aktion des Browsers, der Microtask danach.
 *
 * Nicht geeignet fuer Radix-Selects: die halten ihren Wert in eigenem
 * React-State und stellen ihn beim Reset selbst auf den Mount-Wert zurueck. Dort
 * hilft nur ein Remount ueber einen aus dem Serverwert abgeleiteten `key`.
 *
 * @param ref     Beliebiges Element innerhalb des betroffenen Formulars.
 * @param restore Schreibt den React-State zurueck in den DOM.
 */
export function useRestoreAfterFormReset(
  ref: RefObject<HTMLElement | null>,
  restore: () => void
): void {
  const latest = useRef(restore)

  useEffect(() => {
    latest.current = restore
  })

  useEffect(() => {
    const form = ref.current?.closest("form")
    if (!form) return
    const onReset = () => queueMicrotask(() => latest.current())
    form.addEventListener("reset", onReset)
    return () => form.removeEventListener("reset", onReset)
  }, [ref])
}
