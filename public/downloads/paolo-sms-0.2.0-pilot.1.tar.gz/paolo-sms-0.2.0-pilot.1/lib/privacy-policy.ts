import { PRIVACY_POLICY_TEMPLATE } from "@/lib/constants/privacy-policy-template"

// Die wirksame Datenschutzerklaerung — genau das, was /datenschutz anzeigt.
//
// Eine Ableitung fuer zwei Verwender: die oeffentliche Seite und den Snapshot,
// der mit jeder Einwilligung an der Meldung gespeichert wird (#101). Laege die
// Ableitung zweimal vor, koennte der Snapshot still von der Seite abweichen und
// belegte dann eine Fassung, die nie angezeigt wurde.

type LegalSettingsInput = {
  operatorName?: string | null
  operatorEmail?: string | null
  privacyResponsibleName?: string | null
  privacyContactEmail?: string | null
  dataProtectionOfficer?: string | null
  hostingProviderInfo?: string | null
  dataRetentionInfo?: string | null
  supervisoryAuthority?: string | null
  privacyExtraText?: string | null
  privacyPolicyText?: string | null
} | null

export type EffectivePrivacyPolicyField = {
  label: string
  value: string | null
  required: boolean
}

export type EffectivePrivacyPolicy = {
  fields: EffectivePrivacyPolicyField[]
  missingRequired: string[]
  /** Vom Betreiber hinterlegter Text, getrimmt; null, wenn keiner vorliegt. */
  policyText: string | null
  isIncomplete: boolean
}

export const PRIVACY_POLICY_MISSING_REQUIRED_TEXT =
  "Diese Angabe muss vor Echtdatenbetrieb vom Betreiber ergänzt und geprüft werden."
export const PRIVACY_POLICY_MISSING_OPTIONAL_TEXT = "noch nicht hinterlegt"
export const PRIVACY_POLICY_TEMPLATE_HEADING =
  "Unverbindlicher PAOLO-Vorschlag (noch nicht übernommen)"

function present(value: string | null | undefined): string | null {
  return value && value.length > 0 ? value : null
}

export function buildEffectivePrivacyPolicy(
  legal: LegalSettingsInput
): EffectivePrivacyPolicy {
  const privacyContact = present(legal?.privacyContactEmail) ?? present(legal?.operatorEmail)
  const policyText = legal?.privacyPolicyText?.trim() || null

  // `required` markiert die fuer einen Echtdatenbetrieb wichtigen Angaben;
  // fehlen sie, wird die Seite oben als pruefpflichtig gekennzeichnet und das
  // Feld deutlich markiert.
  const fields: EffectivePrivacyPolicyField[] = [
    {
      label: "Verantwortlicher",
      value: present(legal?.privacyResponsibleName) ?? present(legal?.operatorName),
      required: true,
    },
    { label: "Datenschutzkontakt", value: privacyContact, required: true },
    {
      label: "Datenschutzbeauftragter",
      value: present(legal?.dataProtectionOfficer),
      required: false,
    },
    {
      label: "Empfänger / Dienstleister / Hosting",
      value: present(legal?.hostingProviderInfo),
      required: true,
    },
    { label: "Speicherdauer", value: present(legal?.dataRetentionInfo), required: true },
    {
      label: "Zuständige Aufsichtsbehörde",
      value: present(legal?.supervisoryAuthority),
      required: true,
    },
    {
      label: "Kontakt für Auskunfts- und Löschanfragen",
      value: privacyContact,
      required: false,
    },
    { label: "Kontakt für Datenschutzvorfälle", value: privacyContact, required: false },
    { label: "Zusätzliche Angaben", value: present(legal?.privacyExtraText), required: false },
  ]

  const missingRequired = fields
    .filter((field) => field.required && !field.value)
    .map((field) => field.label)

  return {
    fields,
    missingRequired,
    policyText,
    isIncomplete: missingRequired.length > 0 || !policyText,
  }
}

/**
 * Textfassung der wirksamen Datenschutzerklaerung fuer den Snapshot an der
 * Meldung. Enthaelt dieselben Angaben und denselben Haupttext wie die Seite,
 * in fester Reihenfolge. Seitenrahmen wie Navigation bleiben draussen.
 */
export function renderPrivacyPolicySnapshot(policy: EffectivePrivacyPolicy): string {
  const fieldLines = policy.fields.map(({ label, value, required }) => {
    const shown =
      value ??
      (required ? PRIVACY_POLICY_MISSING_REQUIRED_TEXT : PRIVACY_POLICY_MISSING_OPTIONAL_TEXT)
    return `${label}: ${shown}`
  })

  const body = policy.policyText
    ? ["Datenschutzerklärung", policy.policyText]
    : [PRIVACY_POLICY_TEMPLATE_HEADING, PRIVACY_POLICY_TEMPLATE]

  return [
    "Verantwortlicher und Kontakt (Betreiberangaben)",
    ...fieldLines,
    "",
    ...body,
  ].join("\n")
}
