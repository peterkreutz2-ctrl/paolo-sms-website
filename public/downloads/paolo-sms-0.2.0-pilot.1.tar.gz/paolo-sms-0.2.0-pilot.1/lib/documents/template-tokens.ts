// Reiner, deterministischer Token-Renderer für SMS-Dokumentvorlagen.
//
// Vorlagen können Platzhalter im Format {{key|Fallback}} enthalten (der
// Fallback-Teil ist optional). renderTemplate ersetzt jeden Token durch den
// passenden Wert aus `data`, sofern dieser vorhanden und nicht leer ist —
// andernfalls durch den Fallback-Text. So bleibt bei fehlenden Daten der
// ursprüngliche Platzhalter (z. B. "[Datum]") stehen und es sind NIE rohe
// {{…}}-Tokens im Ergebnis sichtbar.
//
// Keine KI, keine Interpretation — nur String-Ersetzung. Bewusst client-sicher
// (keine DB-/Server-Importe), damit sowohl die normale Vorlagenübernahme (ohne
// Daten → Fallbacks) als auch die serverseitige Vorbefüllung dieselbe Funktion
// nutzen können.

const TOKEN_RE = /\{\{\s*([^}|]+?)\s*(?:\|([^}]*))?\}\}/g

export function renderTemplate(
  content: string,
  data: Record<string, string | null | undefined> = {}
): string {
  return content.replace(TOKEN_RE, (_match, rawKey: string, fallback?: string) => {
    const key = rawKey.trim()
    const value = data[key]
    if (typeof value === "string" && value.trim() !== "") return value
    return fallback ?? ""
  })
}
