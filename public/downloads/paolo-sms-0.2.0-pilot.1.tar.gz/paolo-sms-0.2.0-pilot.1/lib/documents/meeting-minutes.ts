// Serverseitige Datenermittlung für die Vorbefüllung der Protokollvorlage.
//
// Variante A: deterministische Kopf-/Stammdaten.
// Variante B: deterministisches Befüllen der BESTEHENDEN Zähltabellen in
// Abschnitt 1 sowie der bestehenden Listen in Abschnitt 2.1/2.2 der Vorlage.
//
// Ausschließlich deterministische Werte (Zählwerte, Datumswerte, Listen aus
// Kurzbeschreibung/Status/Priorität bzw. Titel/Status/Fälligkeit). KEINE KI,
// keine Interpretation, keine Zusammenfassung, keine neuen Abschnitte. Liefert
// eine Token→Wert-Zuordnung für lib/documents/template-tokens.ts.

import { desc, eq, isNull } from "drizzle-orm"

import { db } from "@/lib/db"
import { measures, organizations, reports, safetyMeetings } from "@/lib/db/schema"
import {
  MEASURE_STATUS_LABELS,
  MEASURE_STATUS_VALUES,
  type MeasureStatus,
} from "@/lib/constants/measure-workflow"
import {
  REPORT_PRIORITY_LABELS,
  REPORT_STATUS_LABELS,
  type ReportPriority,
  type ReportStatus,
} from "@/lib/constants/report-workflow"

// Obergrenze der Listen in 2.1/2.2, damit das Protokoll nicht zu lang wird.
const LIST_LIMIT = 15
const MORE_NOTE =
  "*Weitere Einträge vorhanden; bitte bei Bedarf in PAOLO prüfen.*"

// Meldungs-Status, die in 2.1 „zu bearbeiten" sind.
const REPORT_WORKLIST_STATUS: ReportStatus[] = [
  "new",
  "in_review",
  "in_progress",
  "measures_defined",
]
// Maßnahmen-Status, die in 2.2 „zu bearbeiten" sind.
const MEASURE_WORKLIST_STATUS: MeasureStatus[] = ["open", "in_progress"]
const MEASURE_DONE: MeasureStatus[] = ["completed", "discarded"]

function todayYMD(): string {
  return new Date().toISOString().slice(0, 10)
}
function fmtDEfromYMD(ymd: string): string {
  const [y, m, d] = ymd.split("-")
  return `${d}.${m}.${y}`
}
function fmtDEfromDate(d: Date): string {
  const y = d.getUTCFullYear()
  const m = String(d.getUTCMonth() + 1).padStart(2, "0")
  const day = String(d.getUTCDate()).padStart(2, "0")
  return `${day}.${m}.${y}`
}
function addMonthsYMD(ymd: string, months: number): string {
  const [y, m, d] = ymd.split("-").map(Number)
  return new Date(Date.UTC(y, m - 1 + months, d)).toISOString().slice(0, 10)
}
function startOfUtcToday(): Date {
  const now = new Date()
  return new Date(
    Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate())
  )
}
function intervalLabel(months: number): string {
  switch (months) {
    case 1:
      return "monatlich"
    case 3:
      return "vierteljährlich"
    case 6:
      return "halbjährlich"
    case 12:
      return "jährlich"
    case 24:
      return "alle zwei Jahre"
    default:
      return `alle ${months} Monate`
  }
}

// Zelleninhalt für Markdown-Tabellen absichern (Pipes/Zeilenumbrüche).
function sanitizeCell(text: string): string {
  return text.replace(/\r?\n+/g, " ").replace(/\|/g, "\\|").trim()
}

function measureStatusLabel(v: string): string {
  return MEASURE_STATUS_VALUES.includes(v as MeasureStatus)
    ? MEASURE_STATUS_LABELS[v as MeasureStatus]
    : v
}

export type MeetingMinutesData = Record<string, string>

// Baut alle Token-Werte (Variante A + B). Gibt null zurück, wenn keine
// Organisation existiert. Fehlende Einzelwerte werden als "" geliefert, damit
// der Renderer den jeweiligen Fallback-Platzhalter stehen lässt.
export async function buildMeetingMinutesData(): Promise<MeetingMinutesData | null> {
  const [org] = await db
    .select({
      id: organizations.id,
      name: organizations.name,
      interval: organizations.safetyMeetingIntervalMonths,
      accountableExecutiveName: organizations.accountableExecutiveName,
      safetyManagerName: organizations.safetyManagerName,
    })
    .from(organizations)
    .limit(1)

  if (!org) return null

  const [lastMeeting] = await db
    .select({ meetingDate: safetyMeetings.meetingDate })
    .from(safetyMeetings)
    .where(eq(safetyMeetings.organizationId, org.id))
    .orderBy(desc(safetyMeetings.meetingDate))
    .limit(1)

  // Nicht gelöschte Meldungen und die zugehörigen Maßnahmen laden.
  const reportRows = await db
    .select({
      id: reports.id,
      reportType: reports.reportType,
      activityArea: reports.activityArea,
      severity: reports.severity,
      riskProbability: reports.riskProbability,
      isReportableAccident: reports.isReportableAccident,
      status: reports.status,
      priority: reports.priority,
      shortDescription: reports.shortDescription,
      createdAt: reports.createdAt,
    })
    .from(reports)
    .where(isNull(reports.deletedAt))
    .orderBy(desc(reports.createdAt))

  const measureRows = await db
    .select({
      id: measures.id,
      title: measures.title,
      status: measures.status,
      dueDate: measures.dueDate,
      createdAt: measures.createdAt,
    })
    .from(measures)
    .innerJoin(reports, eq(measures.reportId, reports.id))
    .where(isNull(reports.deletedAt))

  const today = todayYMD()
  const lastYmd = lastMeeting?.meetingDate ?? null
  const nextDue = addMonthsYMD(lastYmd ?? today, org.interval)
  const startToday = startOfUtcToday()

  const countBy = (pred: (r: (typeof reportRows)[number]) => boolean) =>
    String(reportRows.filter(pred).length)
  const mCountBy = (pred: (m: (typeof measureRows)[number]) => boolean) =>
    String(measureRows.filter(pred).length)

  const isOverdue = (m: (typeof measureRows)[number]) =>
    m.dueDate != null &&
    m.dueDate < startToday &&
    !MEASURE_DONE.includes(m.status as MeasureStatus)

  // Meldungen im Berichtszeitraum (ab letztem Meeting; sonst alle).
  const periodStart = lastYmd ? new Date(`${lastYmd}T00:00:00.000Z`) : null
  const reportsInPeriod = periodStart
    ? reportRows.filter((r) => r.createdAt >= periodStart)
    : reportRows

  // ── Listen 2.1 / 2.2 ────────────────────────────────────────────────────────
  const worklistReports = reportRows.filter((r) =>
    REPORT_WORKLIST_STATUS.includes(r.status as ReportStatus)
  )
  const worklistMeasures = measureRows
    .filter((m) => MEASURE_WORKLIST_STATUS.includes(m.status as MeasureStatus))
    .sort((a, b) => {
      const av = a.dueDate ? a.dueDate.getTime() : Number.POSITIVE_INFINITY
      const bv = b.dueDate ? b.dueDate.getTime() : Number.POSITIVE_INFINITY
      return av - bv
    })

  function buildRows<T>(
    items: T[],
    render: (item: T) => string,
    emptyNote: string
  ): string {
    if (items.length === 0) return `| ${emptyNote} | | | |`
    const shown = items.slice(0, LIST_LIMIT).map(render)
    if (items.length > LIST_LIMIT) shown.push(`| ${MORE_NOTE} | | | |`)
    return shown.join("\n")
  }

  const reportRowsMd = buildRows(
    worklistReports,
    (r) =>
      `| ${sanitizeCell(r.shortDescription)} | ${
        REPORT_STATUS_LABELS[r.status as ReportStatus] ?? r.status
      } | ${REPORT_PRIORITY_LABELS[r.priority as ReportPriority] ?? r.priority} | […] |`,
    "*Keine offenen Meldungen zur Bearbeitung.*"
  )

  const measureRowsMd = buildRows(
    worklistMeasures,
    (m) =>
      `| ${sanitizeCell(m.title)} | ${measureStatusLabel(m.status)} | ${
        m.dueDate ? fmtDEfromDate(m.dueDate) : "Kein Fälligkeitsdatum"
      } | […] |`,
    "*Keine offenen Maßnahmen zur Bearbeitung.*"
  )

  return {
    // ── Variante A: Kopf-/Stammdaten ──────────────────────────────────────────
    "organization.name": org.name ?? "",
    "meeting.date": fmtDEfromYMD(today),
    "period.start": lastYmd ? fmtDEfromYMD(lastYmd) : "",
    "period.end": fmtDEfromYMD(today),
    "meeting.interval": intervalLabel(org.interval),
    "meeting.previous": lastYmd ? fmtDEfromYMD(lastYmd) : "",
    "meeting.next": fmtDEfromYMD(nextDue),
    "accountableExecutive.name": org.accountableExecutiveName ?? "",
    "safetyManager.name": org.safetyManagerName ?? "",
    stichtag: fmtDEfromYMD(today),

    // ── Variante B, §1.1: Meldungen kumuliert ─────────────────────────────────
    "r.type.accident": countBy((r) => r.reportType === "accident"),
    "r.type.near_miss": countBy((r) => r.reportType === "near_miss"),
    "r.type.hazard": countBy((r) => r.reportType === "hazard"),
    "r.type.observation": countBy((r) => r.reportType === "observation"),
    "r.type.suggestion": countBy((r) => r.reportType === "suggestion"),
    "r.type.other": countBy((r) => r.reportType === "other"),
    "r.type.sum": String(reportRows.length),

    "r.area.paragliding": countBy((r) => r.activityArea === "paragliding"),
    "r.area.hang_gliding": countBy((r) => r.activityArea === "hang_gliding"),
    "r.area.powered_paragliding": countBy(
      (r) => r.activityArea === "powered_paragliding"
    ),
    "r.area.speed_riding": countBy((r) => r.activityArea === "speed_riding"),
    "r.area.parakite": countBy((r) => r.activityArea === "parakite"),
    "r.area.other": countBy((r) => r.activityArea === "other"),

    "r.rep.yes": countBy((r) => r.isReportableAccident === true),
    "r.rep.no": countBy((r) => r.isReportableAccident === false),

    "r.prob.5": countBy((r) => r.riskProbability === "5"),
    "r.prob.4": countBy((r) => r.riskProbability === "4"),
    "r.prob.3": countBy((r) => r.riskProbability === "3"),
    "r.prob.2": countBy((r) => r.riskProbability === "2"),
    "r.prob.1": countBy((r) => r.riskProbability === "1"),

    "r.sev.no_damage": countBy((r) => r.severity === "no_damage"),
    "r.sev.material_damage_only": countBy(
      (r) => r.severity === "material_damage_only"
    ),
    "r.sev.minor_injury": countBy((r) => r.severity === "minor_injury"),
    "r.sev.serious_injury": countBy((r) => r.severity === "serious_injury"),
    "r.sev.fatal": countBy((r) => r.severity === "fatal"),

    // ── §1.2 Maßnahmen kumuliert ──────────────────────────────────────────────
    "m.tot.open": mCountBy((m) => m.status === "open"),
    "m.tot.overdue": mCountBy(isOverdue),
    "m.tot.in_progress": mCountBy((m) => m.status === "in_progress"),
    "m.tot.completed": mCountBy((m) => m.status === "completed"),
    "m.tot.discarded": mCountBy((m) => m.status === "discarded"),
    "m.tot.sum": String(measureRows.length),

    // ── §1.3 Neu im Berichtszeitraum (Gesamtzahl) ─────────────────────────────
    "r.period.total": String(reportsInPeriod.length),

    // ── §1.4 Maßnahmen-Status vor dem Meeting (= aktueller Stand) ──────────────
    "m.now.open": mCountBy((m) => m.status === "open"),
    "m.now.overdue": mCountBy(isOverdue),
    "m.now.in_progress": mCountBy((m) => m.status === "in_progress"),
    "m.now.completed": mCountBy((m) => m.status === "completed"),
    "m.now.discarded": mCountBy((m) => m.status === "discarded"),

    // ── §2.1 / §2.2 Listen ────────────────────────────────────────────────────
    "r.workRows": reportRowsMd,
    "m.workRows": measureRowsMd,
  }
}
