import { createHmac } from "node:crypto"
import { isIP } from "node:net"

import { and, eq, sql } from "drizzle-orm"

import { db, dbPool } from "@/lib/db"
import { betterAuthLoginRateLimits } from "@/lib/db/schema"

export const BETTER_AUTH_LOGIN_RATE_LIMIT_WINDOW_SECONDS = 15 * 60
export const BETTER_AUTH_LOGIN_RATE_LIMIT_DEFAULT_MAX_PER_ACCOUNT = 5
export const BETTER_AUTH_LOGIN_RATE_LIMIT_DEFAULT_MAX_PER_IP = 20
export const BETTER_AUTH_LOGIN_RATE_LIMIT_DEFAULT_RETENTION_DAYS = 1
const MAX_CONFIGURED_LIMIT = 10_000
const MAX_RETENTION_DAYS = 365
const CLEANUP_BATCH_SIZE = 1_000

const ACCOUNT_SCOPE = "better_auth_login_account"
const NETWORK_SCOPE = "better_auth_login_network"

export type BetterAuthLoginRateLimitDecision =
  | { allowed: true }
  | { allowed: false; retryAfterSeconds: number }

function getBoundedPositiveInteger(
  value: string | undefined,
  fallback: number,
  max: number
): number {
  const normalized = value?.trim()
  if (!normalized || !/^\d+$/.test(normalized)) return fallback
  const parsed = Number(normalized)
  return Number.isSafeInteger(parsed) && parsed >= 1 && parsed <= max
    ? parsed
    : fallback
}

export function getBetterAuthLoginRateLimitMaxPerAccount(
  value = process.env.BETTER_AUTH_LOGIN_RATE_LIMIT_MAX_PER_ACCOUNT
): number {
  return getBoundedPositiveInteger(
    value,
    BETTER_AUTH_LOGIN_RATE_LIMIT_DEFAULT_MAX_PER_ACCOUNT,
    MAX_CONFIGURED_LIMIT
  )
}

export function getBetterAuthLoginRateLimitMaxPerIp(
  value = process.env.BETTER_AUTH_LOGIN_RATE_LIMIT_MAX_PER_IP
): number {
  return getBoundedPositiveInteger(
    value,
    BETTER_AUTH_LOGIN_RATE_LIMIT_DEFAULT_MAX_PER_IP,
    MAX_CONFIGURED_LIMIT
  )
}

export function getBetterAuthLoginRateLimitRetentionDays(
  value = process.env.BETTER_AUTH_LOGIN_RATE_LIMIT_RETENTION_DAYS
): number {
  return getBoundedPositiveInteger(
    value,
    BETTER_AUTH_LOGIN_RATE_LIMIT_DEFAULT_RETENTION_DAYS,
    MAX_RETENTION_DAYS
  )
}

export function normalizeBetterAuthLoginEmail(value: string): string {
  return value.trim().toLowerCase()
}

function normalizeIpv6Part(part: string): string {
  const normalized = part.toLowerCase().replace(/^0+/, "")
  return normalized || "0"
}

function normalizeIpv6To64(address: string): string {
  const [left, right] = address.split("::")
  const leftParts = left ? left.split(":") : []
  const rightParts = right ? right.split(":") : []
  const missing = 8 - leftParts.length - rightParts.length
  const parts = [
    ...leftParts,
    ...Array.from({ length: missing }, () => "0"),
    ...rightParts,
  ].map(normalizeIpv6Part)
  return `${parts.slice(0, 4).join(":")}::`
}

export function normalizeBetterAuthLoginClientIp(value: string | null): string | null {
  const candidate = value?.trim()
  if (!candidate) return null
  const ipVersion = isIP(candidate)
  if (ipVersion === 4) return candidate
  if (ipVersion === 6) return normalizeIpv6To64(candidate)
  return null
}

export function resolveBetterAuthLoginClientIp(headers: Headers): string | null {
  // Kein Fallback auf beliebige Forwarded-Header: nur der explizit vom
  // Betreiber als vertrauenswürdig konfigurierte und vom Proxy bereinigte
  // Header darf die Begrenzung beeinflussen.
  const headerName =
    process.env.BETTER_AUTH_LOGIN_RATE_LIMIT_TRUSTED_IP_HEADER?.trim() ||
    (process.env.NODE_ENV === "production" ? "" : "x-forwarded-for")
  if (!headerName) return null
  return normalizeBetterAuthLoginClientIp(headers.get(headerName))
}

export function createBetterAuthLoginIdentifier(
  salt: string,
  scope: string,
  value: string
): string | null {
  if (!salt || !value) return null
  return createHmac("sha256", salt).update(`${scope}:${value}`).digest("hex")
}

export function getBetterAuthLoginRateLimitWindowStart(now = new Date()): Date {
  const seconds = Math.floor(now.getTime() / 1_000 / BETTER_AUTH_LOGIN_RATE_LIMIT_WINDOW_SECONDS)
  return new Date(seconds * BETTER_AUTH_LOGIN_RATE_LIMIT_WINDOW_SECONDS * 1_000)
}

function retryAfterSeconds(windowStart: Date, now = new Date()): number {
  const endsAt = windowStart.getTime() + BETTER_AUTH_LOGIN_RATE_LIMIT_WINDOW_SECONDS * 1_000
  return Math.max(1, Math.ceil((endsAt - now.getTime()) / 1_000))
}

async function increment(scope: string, identifier: string, windowStart: Date): Promise<number> {
  const [bucket] = await db
    .insert(betterAuthLoginRateLimits)
    .values({
      scope,
      identifier,
      windowStart,
      windowDurationSeconds: BETTER_AUTH_LOGIN_RATE_LIMIT_WINDOW_SECONDS,
      attemptCount: 1,
    })
    .onConflictDoUpdate({
      target: [
        betterAuthLoginRateLimits.scope,
        betterAuthLoginRateLimits.identifier,
        betterAuthLoginRateLimits.windowStart,
      ],
      set: {
        attemptCount: sql`${betterAuthLoginRateLimits.attemptCount} + 1`,
        updatedAt: new Date(),
      },
    })
    .returning({ attemptCount: betterAuthLoginRateLimits.attemptCount })

  if (!bucket) throw new Error("Login-Rate-Limit-Zähler lieferte kein Ergebnis.")
  return bucket.attemptCount
}

async function recordBlocked(scope: string, identifier: string, windowStart: Date): Promise<void> {
  await db
    .update(betterAuthLoginRateLimits)
    .set({ blockedCount: sql`${betterAuthLoginRateLimits.blockedCount} + 1` })
    .where(
      and(
        eq(betterAuthLoginRateLimits.scope, scope),
        eq(betterAuthLoginRateLimits.identifier, identifier),
        eq(betterAuthLoginRateLimits.windowStart, windowStart)
      )
    )
}

async function cleanupExpiredBuckets(): Promise<void> {
  const cutoff = new Date(
    Date.now() - getBetterAuthLoginRateLimitRetentionDays() * 24 * 60 * 60 * 1_000
  )
  await dbPool.query(
    `WITH expired AS (
       SELECT id FROM better_auth_login_rate_limits
       WHERE window_start < $1 ORDER BY window_start ASC LIMIT $2
     )
     DELETE FROM better_auth_login_rate_limits AS bucket
     USING expired WHERE bucket.id = expired.id`,
    [cutoff, CLEANUP_BATCH_SIZE]
  )
}

export async function consumeBetterAuthLoginRateLimit(
  email: string,
  headers: Headers
): Promise<BetterAuthLoginRateLimitDecision> {
  const salt =
    process.env.BETTER_AUTH_LOGIN_RATE_LIMIT_SALT?.trim() ||
    (process.env.NODE_ENV === "production"
      ? ""
      : process.env.BETTER_AUTH_SECRET?.trim())
  const normalizedEmail = normalizeBetterAuthLoginEmail(email)
  const clientIp = resolveBetterAuthLoginClientIp(headers)
  const accountIdentifier = salt
    ? createBetterAuthLoginIdentifier(salt, ACCOUNT_SCOPE, normalizedEmail || "invalid")
    : null
  const networkIdentifier = salt && clientIp
    ? createBetterAuthLoginIdentifier(salt, NETWORK_SCOPE, clientIp)
    : null

  if (!accountIdentifier || !networkIdentifier) {
    console.error("[better-auth-login-rate-limit] Trusted client IP or salt is unavailable.")
    return { allowed: false, retryAfterSeconds: BETTER_AUTH_LOGIN_RATE_LIMIT_WINDOW_SECONDS }
  }

  const windowStart = getBetterAuthLoginRateLimitWindowStart()
  try {
    const [accountAttempts, networkAttempts] = await Promise.all([
      increment(ACCOUNT_SCOPE, accountIdentifier, windowStart),
      increment(NETWORK_SCOPE, networkIdentifier, windowStart),
    ])
    const blocked =
      accountAttempts > getBetterAuthLoginRateLimitMaxPerAccount() ||
      networkAttempts > getBetterAuthLoginRateLimitMaxPerIp()

    if (!blocked) {
      void cleanupExpiredBuckets().catch(() => {
        console.error("[better-auth-login-rate-limit] Cleanup failed.")
      })
      return { allowed: true }
    }

    await Promise.all([
      recordBlocked(ACCOUNT_SCOPE, accountIdentifier, windowStart),
      recordBlocked(NETWORK_SCOPE, networkIdentifier, windowStart),
    ])
    // Ein Signal pro überschrittener Schwelle genügt; jeder weitere Versuch
    // bleibt im Zähler sichtbar, würde das Betriebslog aber nur fluten.
    if (
      accountAttempts === getBetterAuthLoginRateLimitMaxPerAccount() + 1 ||
      networkAttempts === getBetterAuthLoginRateLimitMaxPerIp() + 1
    ) {
      console.info("[better-auth-login-rate-limit] Login attempt blocked.")
    }
    return { allowed: false, retryAfterSeconds: retryAfterSeconds(windowStart) }
  } catch {
    console.error("[better-auth-login-rate-limit] Counter unavailable.")
    return { allowed: false, retryAfterSeconds: BETTER_AUTH_LOGIN_RATE_LIMIT_WINDOW_SECONDS }
  }
}
