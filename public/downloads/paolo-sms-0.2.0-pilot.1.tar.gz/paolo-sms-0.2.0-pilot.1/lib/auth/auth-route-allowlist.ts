// Welche Better-Auth-Pfade die oeffentliche HTTP-Route ausliefert (#111).
//
// Better Auth bringt viele Endpunkte mit (Passwort-Reset, Sitzungsliste,
// Kontoaenderung …). PAOLO braucht ueber HTTP nur vier; alles andere ist
// verwehrt, damit ein kuenftiges Update oder eine neue Option keinen Endpunkt
// stillschweigend oeffentlich macht. Der Passwort-Reset laeuft ausschliesslich
// ueber Server Actions, die `auth.api` direkt aufrufen — nicht ueber diese Route.
//
// Die vier Pfade sind die tatsaechlich benoetigten (Stand der Repositorypruefung):
//   POST /sign-in/email  Anmeldung ueber HTTP: Rate-Limit-E2E, Sicherheitsprofil-
//                        Spec, Nginx-Regeln in deploy/nginx
//   GET  /get-session    Sicherheitsprofil-Spec (Sitzung nach Abmeldung ungueltig)
//   GET  /ok             Gesundheitsendpunkt; Sonde in tests/auth/fixtures
//   POST /sign-out       Sonde in tests/auth/fixtures
// Im Anwendungscode ruft nichts im Browser /api/auth/* auf.

export const AUTH_BASE_PATH = "/api/auth"

const ALLOWED: ReadonlyArray<readonly [method: string, path: string]> = [
  ["GET", "/ok"],
  ["GET", "/get-session"],
  ["POST", "/sign-in/email"],
  ["POST", "/sign-out"],
]

/**
 * Exakter Vergleich, keine Muster: Abweichende Schreibweisen, ein
 * abschliessender oder doppelter Schraegstrich und kodierte Trenner gehoeren
 * nicht zur Liste und werden verwehrt. Das schliesst auch aus, dass die
 * Anmeldebegrenzung in route.ts, die den Pfad exakt vergleicht, ueber eine
 * Schreibvariante umgangen wird.
 */
export function isAllowedAuthRoute(method: string, pathname: string): boolean {
  if (!pathname.startsWith(`${AUTH_BASE_PATH}/`)) return false
  const rest = pathname.slice(AUTH_BASE_PATH.length)
  return ALLOWED.some(([allowedMethod, path]) => allowedMethod === method.toUpperCase() && path === rest)
}
