import "server-only"
import { cookies } from "next/headers"
import { z } from "zod"
import devUsersJson from "@/config/dev-users.json"
import { ROLE_KEYS, type AppRoleKey } from "@/lib/constants/roles"

const schema = z.object({
  users: z.array(z.object({ id: z.string().trim().min(1), email: z.email(), displayName: z.string().trim().min(1), roles: z.array(z.enum(ROLE_KEYS)).min(1) })).min(1),
}).superRefine((value, context) => {
  const ids = value.users.map((user) => user.id)
  if (new Set(ids).size !== ids.length) context.addIssue({ code: "custom", message: "User IDs must be unique." })
})

export type FileAuthUser = { id: string; email: string; displayName: string; roles: AppRoleKey[] }
export const FILE_AUTH_COOKIE_NAME = "paolo_file_auth_user"
let cached: { users: FileAuthUser[] } | undefined

export function loadFileAuthConfig() {
  if (process.env.NODE_ENV === "production") throw new Error("AUTH_MODE=file is development-only and cannot run in production.")
  return cached ??= schema.parse(devUsersJson)
}
export function getFileUsers() { return loadFileAuthConfig().users }
export async function getActiveFileUser() {
  const userId = (await cookies()).get(FILE_AUTH_COOKIE_NAME)?.value
  return getFileUsers().find((user) => user.id === userId) ?? null
}
