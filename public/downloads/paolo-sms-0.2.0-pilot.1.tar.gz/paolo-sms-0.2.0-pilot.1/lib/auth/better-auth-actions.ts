"use server"

import { APIError } from "better-auth/api"
import { headers } from "next/headers"
import { redirect } from "next/navigation"

import { getBetterAuth } from "@/auth"
import {
  consumeBetterAuthLoginRateLimit,
  resolveBetterAuthLoginClientIp,
} from "@/lib/auth/better-auth-login-rate-limit"
import { usesBetterAuth } from "@/lib/auth/mode"
import {
  POST_SIGN_IN_PARAM,
  resolvePostSignInPath,
} from "@/lib/auth/redirect-targets"

function assertBetterAuth() {
  if (!usesBetterAuth()) throw new Error("Better Auth ist nicht aktiviert.")
}

export async function betterAuthSignIn(formData: FormData) {
  assertBetterAuth()
  const email = String(formData.get("email") ?? "").trim().toLowerCase()
  const password = String(formData.get("password") ?? "")

  const decision = await consumeBetterAuthLoginRateLimit(email, await headers())
  if (!decision.allowed) {
    redirect("/sign-in?error=rate-limited")
  }

  try {
    await getBetterAuth().api.signInEmail({ body: { email, password } })
  } catch (error) {
    if (error instanceof APIError) redirect("/sign-in?error=invalid-credentials")
    throw error
  }
  // Rueckweg nur aus der Positivliste; jeder andere Wert faellt auf das
  // bisherige Ziel /dashboard zurueck (siehe lib/auth/redirect-targets.ts).
  redirect(resolvePostSignInPath(formData.get(POST_SIGN_IN_PARAM)))
}

export async function betterAuthSignOut() {
  assertBetterAuth()
  await getBetterAuth().api.signOut({ headers: await headers() })
  redirect("/sign-in")
}

export type SetPasswordState = { success: boolean; message: string }

const INVALID_LINK_MESSAGE =
  "Der Link ist ungültig oder abgelaufen. Bitte bei der Administration einen neuen Link anfordern."
const MIN_PASSWORD_LENGTH = 8
const MAX_PASSWORD_LENGTH = 128

// Passwort festlegen ueber einen Link, den ein Administrator oder Safety Manager
// erzeugt hat (#111). Ruft die dokumentierte Reset-Schnittstelle von Better Auth
// DIREKT auf — nicht ueber die HTTP-Route, die fuer diesen Ablauf gesperrt ist
// (lib/auth/auth-route-allowlist.ts).
//
// Das Token ist ein Zugangsschluessel: Es wird weder geloggt noch in eine
// Fehlermeldung aufgenommen. Jeder Fehlschlag der Schnittstelle (unbekannt,
// abgelaufen, bereits verwendet) erhaelt dieselbe neutrale Antwort. Nach
// Erfolg sind alle Sitzungen der Person widerrufen (revokeSessionsOnPasswordReset
// in auth.ts), und das alte Passwort ist ungueltig.
//
// Eingabefehler (zu kurz, ungleich) verbrauchen weder das Token noch einen
// Versuch der Ratenbegrenzung.
export async function setPasswordWithToken(
  _: SetPasswordState,
  formData: FormData
): Promise<SetPasswordState> {
  assertBetterAuth()
  const token = String(formData.get("token") ?? "").trim()
  const password = String(formData.get("password") ?? "")
  const confirmation = String(formData.get("passwordConfirm") ?? "")

  if (!token) return { success: false, message: INVALID_LINK_MESSAGE }
  if (password.length < MIN_PASSWORD_LENGTH) {
    return { success: false, message: `Das Passwort muss mindestens ${MIN_PASSWORD_LENGTH} Zeichen lang sein.` }
  }
  if (password.length > MAX_PASSWORD_LENGTH) {
    return { success: false, message: `Das Passwort darf höchstens ${MAX_PASSWORD_LENGTH} Zeichen lang sein.` }
  }
  if (password !== confirmation) {
    return { success: false, message: "Die beiden Passwörter stimmen nicht überein." }
  }

  // Je Netz begrenzt (gleiche Zaehler wie die Anmeldung, eigener Bezeichner):
  // Der Bezeichner traegt die Adresse, damit ein Angreifer nicht den Zaehler
  // aller Personen verbrauchen kann.
  const requestHeaders = await headers()
  const clientIp = resolveBetterAuthLoginClientIp(requestHeaders)
  const decision = await consumeBetterAuthLoginRateLimit(
    `password-reset:${clientIp ?? ""}`,
    requestHeaders
  )
  if (!decision.allowed) {
    return {
      success: false,
      message: "Zu viele Versuche. Bitte warten Sie einige Minuten und versuchen Sie es dann erneut.",
    }
  }

  try {
    await getBetterAuth().api.resetPassword({ body: { newPassword: password, token } })
  } catch (error) {
    if (error instanceof APIError) return { success: false, message: INVALID_LINK_MESSAGE }
    throw error
  }
  return {
    success: true,
    message: "Das Passwort wurde festgelegt. Sie können sich jetzt anmelden.",
  }
}
