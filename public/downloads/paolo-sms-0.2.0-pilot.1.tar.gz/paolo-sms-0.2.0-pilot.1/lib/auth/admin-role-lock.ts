import { and, eq, isNull, sql } from "drizzle-orm"

import type { db } from "@/lib/db"
import { roles, userRoles } from "@/lib/db/schema"

import {
  decideAdminRoleChange,
  type AdminChangeRefusal,
} from "@/lib/auth/admin-invariant"

// Bewusst `import type`: Dieses Modul darf lib/db nicht zur Laufzeit laden.
// Der Integrationstest (tests/auth/admin-invariant.integration.mts) uebergibt
// eine eigene Transaktion gegen eine Wegwerf-Datenbank; ein Laufzeit-Import
// von lib/db wuerde stattdessen .env.local lesen.
type Database = typeof db
export type AdminLockTransaction = Parameters<Parameters<Database["transaction"]>[0]>[0]

// Fester Schluessel des Advisory Locks. Er gilt nur innerhalb von PAOLO und
// serialisiert alle Aenderungen an Administratorrollen.
const ADMIN_INVARIANT_LOCK_KEY = 735_001_109

export class AdminChangeRefused extends Error {
  constructor(readonly reason: AdminChangeRefusal) {
    super(`Administratoraenderung abgelehnt: ${reason}`)
    this.name = "AdminChangeRefused"
  }
}

/** Kennungen aller globalen Administratorrollen (Lesen ausserhalb einer Sperre). */
export async function readGlobalAdminIds(
  executor: Pick<AdminLockTransaction, "select">
): Promise<string[]> {
  const rows = await executor
    .select({ clerkUserId: userRoles.clerkUserId })
    .from(userRoles)
    .innerJoin(roles, eq(userRoles.roleId, roles.id))
    .where(and(eq(roles.key, "admin"), isNull(userRoles.organizationId)))
  return [...new Set(rows.map((row) => row.clerkUserId))]
}

/**
 * Nimmt in der laufenden Transaktion die Administrator-Sperre und prueft dann
 * auf FRISCH gelesenem Stand, ob die Aenderung zulaessig ist. Wirft
 * `AdminChangeRefused`; der Aufrufer laesst die Transaktion dadurch
 * zurueckrollen.
 *
 * Die Reihenfolge ist der Kern: Erst sperren, dann lesen, dann schreiben.
 * Ohne Sperre sehen zwei gleichzeitige Herabstufungen beide „zwei
 * Administratoren“ und gehen beide durch. Die Sperre ist transaktionsgebunden
 * (`pg_advisory_xact_lock`) und endet mit Commit oder Rollback.
 *
 * `liveAccountIds` stammt aus einem Verzeichnisabruf VOR der Transaktion
 * (Netzwerkaufruf, nicht unter der Sperre). Das ist ein Schnappschuss: Wird ein
 * Administratorkonto genau dazwischen extern gesperrt oder geloescht, laesst
 * sich das nicht ausschliessen.
 */
export async function guardAdminRoleChange(
  tx: AdminLockTransaction,
  input: {
    targetId: string
    targetStaysAdmin: boolean
    liveAccountIds: ReadonlySet<string> | null
  }
): Promise<void> {
  await tx.execute(sql`select pg_advisory_xact_lock(${sql.raw(String(ADMIN_INVARIANT_LOCK_KEY))})`)
  const adminIds = await readGlobalAdminIds(tx)
  const decision = decideAdminRoleChange({ ...input, adminIds })
  if (!decision.allowed) throw new AdminChangeRefused(decision.reason)
}
