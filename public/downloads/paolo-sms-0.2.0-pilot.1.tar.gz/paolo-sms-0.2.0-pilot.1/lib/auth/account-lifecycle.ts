// Kontodaten aendern und Konto loeschen (#114) — reine Logik ohne Datenbank- und
// Providerzugriff, damit sie mit Fake-Abhaengigkeiten testbar bleibt
// (tests/auth/account-lifecycle.test.ts). Der datenbankseitige Teil fuer Better
// Auth steht in lib/auth/account-lifecycle-db.ts.
import { canDeleteAccount, isAppRoleKey, type AppRoleKey } from "@/lib/constants/roles"

export const NAME_MAX_LENGTH = 120
export const EMAIL_MAX_LENGTH = 254
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const CONTROL_CHARACTERS = /[\u0000-\u001f\u007f]/

/**
 * Rollenwerte aus der Datenbank fuer Berechtigungspruefungen. Ein Wert, der keine
 * bekannte Rolle ist, gilt als die am staerksten geschuetzte (Administrator) —
 * wie in app/dashboard/users/page.tsx. „Keine Rolle“ waere die falsche Richtung.
 */
export function normalizeTargetRoles(roleKeys: readonly string[]): AppRoleKey[] {
  return roleKeys.map((key) => (isAppRoleKey(key) ? key : ("admin" as const)))
}

// ─── Kontodaten ─────────────────────────────────────────────────────────────

export type AccountDataValidation =
  | { ok: true; name: string; email: string | null }
  | { ok: false; message: string }

/**
 * Prueft und normalisiert die Eingabe. Die E-Mail-Adresse wird nur beruecksichtigt,
 * wenn sie aenderbar ist (Better Auth); bei Clerk bleibt sie dem Benutzerprofil des
 * Anbieters vorbehalten und `email` ist dann immer null.
 */
export function validateAccountData(
  input: { name: unknown; email: unknown },
  options: { emailEditable: boolean }
): AccountDataValidation {
  const name = typeof input.name === "string" ? input.name.trim().replace(/\s+/g, " ") : ""
  if (!name) return { ok: false, message: "Bitte einen Namen eingeben." }
  if (name.length > NAME_MAX_LENGTH) {
    return { ok: false, message: `Der Name darf höchstens ${NAME_MAX_LENGTH} Zeichen lang sein.` }
  }
  if (CONTROL_CHARACTERS.test(name)) {
    return { ok: false, message: "Der Name enthält unzulässige Zeichen." }
  }
  if (!options.emailEditable) return { ok: true, name, email: null }

  const email = typeof input.email === "string" ? input.email.trim().toLowerCase() : ""
  if (!email || email.length > EMAIL_MAX_LENGTH || !EMAIL_RE.test(email)) {
    return { ok: false, message: "Ungültige E-Mail-Adresse." }
  }
  return { ok: true, name, email }
}

/** Clerk fuehrt Vor- und Nachnamen getrennt; PAOLO zeigt ein Feld „Name“. */
export function splitName(name: string): { firstName: string; lastName: string } {
  const [firstName = "", ...rest] = name.trim().split(/\s+/)
  return { firstName, lastName: rest.join(" ") }
}

export function changedAccountFields(input: {
  currentName: string
  currentEmail: string
  name: string
  email: string | null
}): Array<"name" | "email"> {
  const fields: Array<"name" | "email"> = []
  if (input.name !== input.currentName) fields.push("name")
  if (input.email !== null && input.email !== input.currentEmail.trim().toLowerCase()) fields.push("email")
  return fields
}

// ─── Loeschen ───────────────────────────────────────────────────────────────

export type DeletionRefusal = "self" | "not-permitted" | "admin-role" | "email-mismatch"

export const DELETION_REFUSAL_MESSAGES: Readonly<Record<DeletionRefusal, string>> = {
  self: "Das eigene Konto lässt sich hier nicht löschen.",
  "not-permitted": "Keine Berechtigung, dieses Konto zu löschen.",
  "admin-role":
    "Ein Konto mit Administratorrolle lässt sich nicht löschen. Bitte zuerst die Rolle ändern.",
  "email-mismatch": "Die eingegebene E-Mail-Adresse stimmt nicht mit dem Konto überein.",
}

export function emailsMatch(typed: string, accountEmail: string): boolean {
  const expected = accountEmail.trim().toLowerCase()
  return expected.length > 0 && typed.trim().toLowerCase() === expected
}

export function decideAccountDeletion(input: {
  actorRoles: readonly AppRoleKey[]
  actorId: string
  targetId: string
  targetRoles: readonly AppRoleKey[]
  accountEmail: string
  typedEmail: string
}): { ok: true } | { ok: false; reason: DeletionRefusal } {
  if (input.actorId === input.targetId) return { ok: false, reason: "self" }
  if (input.targetRoles.includes("admin")) return { ok: false, reason: "admin-role" }
  if (!canDeleteAccount(input.actorRoles, input.targetRoles, false)) {
    return { ok: false, reason: "not-permitted" }
  }
  if (!emailsMatch(input.typedEmail, input.accountEmail)) return { ok: false, reason: "email-mismatch" }
  return { ok: true }
}

export type DeletionOutcome = {
  success: boolean
  message: string
  stage: "refused" | "provider-failed" | "database-failed" | "done"
}

export type ProviderFirstDeletionDeps = {
  /** Liest die Rollen des Ziels FRISCH. Wirft bei jeder Unsicherheit. */
  recheckNotAdmin: () => Promise<"not-admin" | "admin">
  deleteAtProvider: () => Promise<"deleted" | "not-found">
  cleanupInDatabase: () => Promise<void>
}

/**
 * Clerk-Loeschung: Der Anbieter ist nicht Teil der Datenbanktransaktion und nicht
 * rueckrollbar. Deshalb steht die Pruefung unmittelbar VOR dem Anbieteraufruf,
 * und die Reihenfolge ist:
 *   1. Rolle erneut pruefen — bei Administrator oder Unsicherheit abbrechen,
 *   2. Konto beim Anbieter loeschen („nicht gefunden“ gilt als bereits geloescht),
 *   3. Rollen und Audit-Eintrag in PAOLO in einer Transaktion bereinigen.
 * Scheitert Schritt 3, ist das Konto weg, die Rolle bleibt als „Konto fehlt“ stehen
 * und laesst sich mit „Rolle bereinigen“ entfernen — kein Kompensationsschritt.
 */
export async function runProviderFirstDeletion(
  deps: ProviderFirstDeletionDeps
): Promise<DeletionOutcome> {
  let check: "not-admin" | "admin"
  try {
    check = await deps.recheckNotAdmin()
  } catch {
    return {
      success: false,
      stage: "refused",
      message: "Die Rolle des Kontos konnte nicht sicher geprüft werden. Es wurde nichts gelöscht — bitte erneut versuchen.",
    }
  }
  if (check === "admin") {
    return { success: false, stage: "refused", message: DELETION_REFUSAL_MESSAGES["admin-role"] }
  }

  let provider: "deleted" | "not-found"
  try {
    provider = await deps.deleteAtProvider()
  } catch {
    return {
      success: false,
      stage: "provider-failed",
      message: "Das Konto konnte beim Anmeldedienst nicht gelöscht werden. In PAOLO wurde nichts geändert — bitte erneut versuchen.",
    }
  }

  try {
    await deps.cleanupInDatabase()
  } catch {
    return {
      success: false,
      stage: "database-failed",
      message:
        "Das Konto wurde beim Anmeldedienst gelöscht, die Bereinigung in PAOLO ist aber fehlgeschlagen. Die Rolle erscheint jetzt als „Konto fehlt“ und lässt sich mit „Rolle bereinigen“ entfernen.",
    }
  }

  return {
    success: true,
    stage: "done",
    message:
      provider === "not-found"
        ? "Das Konto war beim Anmeldedienst bereits gelöscht; die Rollen wurden bereinigt."
        : "Konto gelöscht.",
  }
}
