"use server"

import { z } from "zod"
import { redirect } from "next/navigation"
import { cookies } from "next/headers"

import { FILE_AUTH_COOKIE_NAME, getFileUsers } from "@/lib/auth/file-auth"
import { usesFileAuth } from "@/lib/auth/mode"
import {
  POST_SIGN_IN_PARAM,
  resolvePostSignInPath,
} from "@/lib/auth/redirect-targets"

const userIdSchema = z.string().trim().min(1)

function assertFileAuth() {
  if (!usesFileAuth() || process.env.NODE_ENV === "production") {
    throw new Error("Die Entwicklungsanmeldung ist nicht verfügbar.")
  }
}

export async function fileAuthSignIn(formData: FormData) {
  assertFileAuth()
  const parsedUserId = userIdSchema.safeParse(formData.get("userId"))
  const user = parsedUserId.success
    ? getFileUsers().find((candidate) => candidate.id === parsedUserId.data)
    : undefined

  if (!user) redirect("/sign-in?error=invalid-user")

  ;(await cookies()).set(FILE_AUTH_COOKIE_NAME, user.id, {
    httpOnly: true,
    sameSite: "lax",
    secure: false,
    path: "/",
    maxAge: 60 * 60 * 12,
  })
  // Rueckweg nur aus der Positivliste; jeder andere Wert faellt auf das
  // bisherige Ziel /dashboard zurueck (siehe lib/auth/redirect-targets.ts).
  redirect(resolvePostSignInPath(formData.get(POST_SIGN_IN_PARAM)))
}

export async function fileAuthSignOut() {
  assertFileAuth()
  ;(await cookies()).delete(FILE_AUTH_COOKIE_NAME)
  redirect("/sign-in")
}
