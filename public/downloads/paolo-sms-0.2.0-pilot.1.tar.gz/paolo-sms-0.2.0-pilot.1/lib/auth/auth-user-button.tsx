"use client"
import { UserButton } from "@clerk/nextjs"
import { fileAuthSignOut } from "@/lib/auth/file-auth-actions"
import { betterAuthSignOut } from "@/lib/auth/better-auth-actions"
export function AuthUserButton({ fileAuth, betterAuth }: { fileAuth: boolean; betterAuth: boolean }) {
  return fileAuth || betterAuth ? (
    <form action={betterAuth ? betterAuthSignOut : fileAuthSignOut}>
      <button type="submit" className="rounded-full bg-amber-100 px-2 py-1 text-xs font-medium text-amber-900 hover:bg-amber-200">
        Abmelden
      </button>
    </form>
  ) : <UserButton />
}
