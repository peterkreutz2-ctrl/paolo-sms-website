// Reine Logik fuer die Kontenliste auf /dashboard/users. Bewusst ohne Datenbank-
// und Provider-Import, damit sie ohne Umgebung testbar bleibt (tests/auth/
// user-overview.test.ts).

export type DirectoryAccount = { id: string; email: string; displayName: string }

export type GlobalRoleRow = {
  id: string
  clerkUserId: string
  roleKey: string
  createdAt: Date
}

// active      Konto existiert und hat eine Rolle
// no-role     Konto existiert, aber keine globale Rolle
// missing     Rolleneintrag ohne Konto im Verzeichnis (verwaist)
// unverified  Verzeichnis nicht erreichbar: Ob das Konto existiert, ist offen
export type AccountStatus = "active" | "no-role" | "missing" | "unverified"

export type OverviewRow = {
  id: string
  displayName: string
  email: string | null
  roleKey: string | null
  userRoleId: string | null
  status: AccountStatus
}

export class IncompleteDirectoryError extends Error {
  constructor(expected: number, received: number) {
    super(`Verzeichnis unvollstaendig: ${received} von ${expected} Konten geladen.`)
    this.name = "IncompleteDirectoryError"
  }
}

type Page<T> = { data: T[]; totalCount: number }

// Ein Anbieter, der nur seitenweise liefert (Clerk: hoechstens 500 je Abruf),
// darf die Liste nicht still abschneiden. Diese Funktion liest weiter, bis
// `totalCount` erreicht ist, und wirft, wenn am Ende Konten fehlen — dann zeigt
// die Seite „unvollstaendig“ statt einer falschen Vollstaendigkeitsaussage.
//
// Doppelte Eintraege entstehen, wenn waehrend des Blaetterns ein Konto
// angelegt wird und alle Offsets verrutschen; sie werden ueber die Kennung
// zusammengefuehrt.
export async function fetchAllPages<T extends { id: string }>(
  fetchPage: (offset: number, limit: number) => Promise<Page<T>>,
  pageSize = 100,
  maxPages = 100
): Promise<T[]> {
  const seen = new Map<string, T>()
  let offset = 0
  let totalCount = 0

  for (let page = 0; page < maxPages; page++) {
    const result = await fetchPage(offset, pageSize)
    totalCount = result.totalCount
    for (const item of result.data) seen.set(item.id, item)
    offset += result.data.length
    if (result.data.length === 0 || offset >= totalCount) break
  }

  if (seen.size < totalCount) throw new IncompleteDirectoryError(totalCount, seen.size)
  return [...seen.values()]
}

// Fuehrt Verzeichnis und globale Rolleneintraege zu einer Liste zusammen.
// `accounts === null` heisst: Verzeichnis nicht erreichbar.
//
// Je Konto zaehlt die zuletzt vergebene Rolle (`roleRows` aufsteigend nach
// createdAt) — wie bisher. Es gibt hoechstens eine globale Rolle je Konto.
export function buildUserOverview(input: {
  accounts: readonly DirectoryAccount[] | null
  roleRows: readonly GlobalRoleRow[]
}): OverviewRow[] {
  const roleByUser = new Map<string, GlobalRoleRow>()
  for (const row of input.roleRows) roleByUser.set(row.clerkUserId, row)

  const rows: OverviewRow[] = []

  if (input.accounts === null) {
    for (const [userId, role] of roleByUser) {
      rows.push({
        id: userId,
        displayName: userId,
        email: null,
        roleKey: role.roleKey,
        userRoleId: role.id,
        status: "unverified",
      })
    }
  } else {
    const known = new Set<string>()
    for (const account of input.accounts) {
      known.add(account.id)
      const role = roleByUser.get(account.id)
      rows.push({
        id: account.id,
        displayName: account.displayName,
        email: account.email || null,
        roleKey: role?.roleKey ?? null,
        userRoleId: role?.id ?? null,
        status: role ? "active" : "no-role",
      })
    }
    for (const [userId, role] of roleByUser) {
      if (known.has(userId)) continue
      rows.push({
        id: userId,
        displayName: userId,
        email: null,
        roleKey: role.roleKey,
        userRoleId: role.id,
        status: "missing",
      })
    }
  }

  return rows.sort(
    (a, b) => a.displayName.localeCompare(b.displayName, "de") || a.id.localeCompare(b.id)
  )
}
