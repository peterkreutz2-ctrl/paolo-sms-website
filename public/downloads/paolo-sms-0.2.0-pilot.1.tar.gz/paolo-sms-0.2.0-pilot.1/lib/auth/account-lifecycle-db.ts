import { eq } from "drizzle-orm"

import type { db } from "@/lib/db"
import { betterAuthUsers, roles, userRoles } from "@/lib/db/schema"

import { normalizeTargetRoles } from "@/lib/auth/account-lifecycle"

// Datenbankteil fuer Better Auth (#114). Bewusst `import type` auf lib/db: Der
// Integrationstest uebergibt eine Transaktion gegen eine Wegwerf-Datenbank
// (tests/auth/account-lifecycle.integration.mts); ein Laufzeit-Import wuerde
// stattdessen .env.local lesen.
type Database = typeof db
export type AccountTransaction = Parameters<Parameters<Database["transaction"]>[0]>[0]
type Executor = Pick<AccountTransaction, "select">

export class AccountChangeRefused extends Error {
  constructor(readonly reason: "admin-role" | "not-found") {
    super(`Kontoaenderung abgelehnt: ${reason}`)
    this.name = "AccountChangeRefused"
  }
}

/** Alle Rollenwerte des Kontos (global und je Organisation). */
export async function readAccountRoleKeys(executor: Executor, userId: string): Promise<string[]> {
  const rows = await executor
    .select({ key: roles.key })
    .from(userRoles)
    .innerJoin(roles, eq(userRoles.roleId, roles.id))
    .where(eq(userRoles.clerkUserId, userId))
  return rows.map((row) => row.key)
}

/** Entfernt alle Rollenzuweisungen des Kontos; liefert die entfernten Rollenwerte. */
export async function deleteRoleAssignments(tx: AccountTransaction, userId: string): Promise<string[]> {
  const keys = await readAccountRoleKeys(tx, userId)
  await tx.delete(userRoles).where(eq(userRoles.clerkUserId, userId))
  return keys
}

/**
 * Loescht ein Better-Auth-Konto samt Rollen. Sitzungen und Passwort-Zeile fallen
 * ueber `ON DELETE CASCADE` mit. Eine Administratorrolle — oder ein Rollenwert, der
 * keine bekannte Rolle ist — bricht ab; die Transaktion rollt dann zurueck.
 * Historische Datensaetze, die die Kennung tragen, bleiben unveraendert.
 */
export async function deleteBetterAuthAccount(
  tx: AccountTransaction,
  userId: string
): Promise<{ previousRoleKeys: string[] }> {
  const keys = await readAccountRoleKeys(tx, userId)
  if (normalizeTargetRoles(keys).includes("admin")) throw new AccountChangeRefused("admin-role")

  await tx.delete(userRoles).where(eq(userRoles.clerkUserId, userId))
  const removed = await tx
    .delete(betterAuthUsers)
    .where(eq(betterAuthUsers.id, userId))
    .returning({ id: betterAuthUsers.id })
  if (removed.length === 0) throw new AccountChangeRefused("not-found")
  return { previousRoleKeys: keys }
}

/** Name und/oder E-Mail eines Better-Auth-Kontos. Kennung, Rollen und Passwort bleiben. */
export async function updateBetterAuthAccount(
  tx: AccountTransaction,
  userId: string,
  changes: { name?: string; email?: string }
): Promise<void> {
  const updated = await tx
    .update(betterAuthUsers)
    .set({ ...changes, updatedAt: new Date() })
    .where(eq(betterAuthUsers.id, userId))
    .returning({ id: betterAuthUsers.id })
  if (updated.length === 0) throw new AccountChangeRefused("not-found")
}

/** Verletzung des eindeutigen Index (doppelte E-Mail-Adresse), auch wenn Drizzle den Fehler verpackt. */
export function isUniqueViolation(error: unknown): boolean {
  const candidate = (error as { code?: string; cause?: { code?: string } } | null) ?? {}
  return candidate.code === "23505" || candidate.cause?.code === "23505"
}
