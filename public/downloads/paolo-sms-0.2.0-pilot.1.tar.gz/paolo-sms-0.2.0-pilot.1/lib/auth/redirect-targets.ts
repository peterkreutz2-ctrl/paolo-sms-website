// Wohin darf eine Anmeldung zurueckspringen?
//
// Ohne Angabe landet jede Anmeldung wie bisher auf /dashboard. Ein Mitglied
// ohne internen Zugang wuerde dort aber auf der Seite „Kein Zugriff auf das
// interne Dashboard" stranden — deshalb kann /communications den Rueckweg zu
// sich selbst anfordern.
//
// Bewusst eine Positivliste mit EXAKTEM Vergleich, kein Praefix-Test und keine
// URL-Analyse: Damit ist ein Open Redirect strukturell ausgeschlossen. Weder
// "//example.org" noch "/dashboard/../../evil" noch ein absoluter Link kommen
// durch, weil sie schlicht nicht in der Liste stehen. Query und Fragment sind
// ebenfalls nicht erlaubt — ein Rueckweg braucht sie nicht.
//
// Der Wert stammt immer aus einem Query-Parameter oder einem Formularfeld,
// also aus Benutzerhand. Er darf deshalb nie ungeprueft in ein redirect().

export const DEFAULT_POST_SIGN_IN_PATH = "/dashboard"

/** Interne Ziele, die eine Anmeldung anfordern darf. */
const ALLOWED_POST_SIGN_IN_PATHS: readonly string[] = [
  "/dashboard",
  "/communications",
]

/** Name des Query-Parameters bzw. Formularfeldes fuer den Rueckweg. */
export const POST_SIGN_IN_PARAM = "redirect"

/**
 * Liefert ein sicheres Ziel fuer den Rueckweg nach der Anmeldung: den
 * angeforderten Pfad, wenn er auf der Positivliste steht, sonst das bisherige
 * Standardziel. Fuer jeden ungueltigen Wert gibt es bewusst keine Fehlermeldung
 * — der Rueckweg ist Komfort, kein Vertrag.
 */
export function resolvePostSignInPath(value: unknown): string {
  if (typeof value !== "string") return DEFAULT_POST_SIGN_IN_PATH
  const candidate = value.trim()
  return ALLOWED_POST_SIGN_IN_PATHS.includes(candidate)
    ? candidate
    : DEFAULT_POST_SIGN_IN_PATH
}

/** Pfad der Anmeldeseite inklusive Rueckweg-Parameter. */
export function buildSignInPath(target: string): string {
  const safe = resolvePostSignInPath(target)
  if (safe === DEFAULT_POST_SIGN_IN_PATH) return "/sign-in"
  return `/sign-in?${POST_SIGN_IN_PARAM}=${encodeURIComponent(safe)}`
}
