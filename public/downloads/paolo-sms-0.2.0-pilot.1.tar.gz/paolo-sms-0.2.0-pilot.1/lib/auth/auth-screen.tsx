import { SignIn, SignUp } from "@clerk/nextjs"

import { Button } from "@/components/ui/button"
import { DemoCredentials } from "@/components/demo-credentials"
import { usesBetterAuth, usesFileAuth } from "@/lib/auth"
import { betterAuthSignIn } from "@/lib/auth/better-auth-actions"
import { fileAuthSignIn } from "@/lib/auth/file-auth-actions"
import { getFileUsers } from "@/lib/auth/file-auth"
import { ROLE_LABELS } from "@/lib/constants/roles"
import {
  DEFAULT_POST_SIGN_IN_PATH,
  POST_SIGN_IN_PARAM,
  resolvePostSignInPath,
} from "@/lib/auth/redirect-targets"

// `redirectTo` ist der gewuenschte Rueckweg nach der Anmeldung. Er kommt aus
// einem Query-Parameter und wird deshalb hier noch einmal gegen die
// Positivliste geprueft — die Komponente verlaesst sich nicht darauf, dass der
// Aufrufer das bereits getan hat.
export function AuthScreen({
  kind,
  redirectTo,
  error,
}: {
  kind: "sign-in" | "sign-up"
  redirectTo?: string
  error?: string
}) {
  const postSignInPath = resolvePostSignInPath(redirectTo)

  if (usesFileAuth()) {
    const users = getFileUsers()

    return (
      <div className="w-full max-w-md rounded-lg border bg-card p-6 shadow-sm">
        <h1 className="text-xl font-semibold">Entwicklungsanmeldung</h1>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
          Wählen Sie einen Testbenutzer aus. Diese Anmeldung ist ausschließlich
          im lokalen Entwicklungsmodus verfügbar.
        </p>

        <form action={fileAuthSignIn} className="mt-6 space-y-4">
          <input
            type="hidden"
            name={POST_SIGN_IN_PARAM}
            value={postSignInPath}
          />
          <div className="space-y-2">
            <label htmlFor="file-auth-user" className="text-sm font-medium">
              Benutzer und Rolle
            </label>
            <select
              id="file-auth-user"
              name="userId"
              required
              defaultValue=""
              className="flex h-9 w-full rounded-lg border border-input bg-background px-3 py-1 text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50"
            >
              <option value="" disabled>Rolle auswählen</option>
              {users.map((user) => (
                <option key={user.id} value={user.id}>
                  {user.displayName} — {user.roles.map((role) => ROLE_LABELS[role]).join(", ")}
                </option>
              ))}
            </select>
          </div>

          <Button type="submit" className="w-full">Anmelden</Button>
        </form>
      </div>
    )
  }
  if (usesBetterAuth()) {
    if (kind === "sign-up") {
      return <div className="w-full max-w-md rounded-lg border bg-card p-6 shadow-sm"><h1 className="text-xl font-semibold">Benutzerkonto anlegen</h1><p className="mt-2 text-sm text-muted-foreground">Neue Konten werden von einem Administrator in der Zugangs- und Rollenverwaltung angelegt.</p></div>
    }
    return (
      <div className="w-full max-w-md rounded-lg border bg-card p-6 shadow-sm">
        <h1 className="text-xl font-semibold">Anmelden</h1>
        <p className="mt-2 text-sm text-muted-foreground">Mit E-Mail-Adresse und Passwort anmelden.</p>
        {error === "rate-limited" ? (
          <p role="alert" className="mt-3 rounded-md border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive">
            Zu viele Anmeldeversuche. Bitte warten Sie einige Minuten und versuchen Sie es dann erneut.
          </p>
        ) : error === "invalid-credentials" ? (
          <p role="alert" className="mt-3 rounded-md border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive">
            E-Mail-Adresse oder Passwort ist nicht korrekt.
          </p>
        ) : null}
        <form action={betterAuthSignIn} className="mt-6 space-y-4">
          <input
            type="hidden"
            name={POST_SIGN_IN_PARAM}
            value={postSignInPath}
          />
          <div className="space-y-2"><label htmlFor="email" className="text-sm font-medium">E-Mail-Adresse</label><input id="email" name="email" type="email" autoComplete="email" aria-label="Email" required className="w-full rounded-md border bg-background px-3 py-2 text-sm" /></div>
          <div className="space-y-2"><label htmlFor="password" className="text-sm font-medium">Passwort</label><input id="password" name="password" type="password" autoComplete="current-password" aria-label="Password" required className="w-full rounded-md border bg-background px-3 py-2 text-sm" /></div>
          <Button type="submit" className="w-full">Anmelden</Button>
        </form>
        <DemoCredentials />
      </div>
    )
  }
  // Clerk kennt den Rueckweg ueber forceRedirectUrl. Beim Standardziel bleibt
  // das Attribut weg, damit sich das bisherige Verhalten nicht aendert.
  if (kind === "sign-up") return <SignUp />
  return postSignInPath === DEFAULT_POST_SIGN_IN_PATH ? (
    <SignIn />
  ) : (
    <SignIn forceRedirectUrl={postSignInPath} />
  )
}
