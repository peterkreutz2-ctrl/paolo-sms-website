// Entscheidung des Letzter-Administrator-Schutzes — reine Funktion, damit sie
// ohne Datenbank und Anmeldedienst testbar bleibt (tests/auth/admin-invariant.
// test.ts). Der datenbankseitige Teil (Sperre, frisches Lesen) steht in
// lib/auth/admin-role-lock.ts.

export type AdminChangeRefusal = "last-admin" | "directory-unavailable"

export type AdminChangeDecision =
  | { allowed: true }
  | { allowed: false; reason: AdminChangeRefusal }

/**
 * Darf die Administratorrolle von `targetId` wegfallen?
 *
 * Erlaubt ist die Aenderung, wenn der Betroffene keine Administratorrolle hat
 * oder sie behaelt. Faellt sie weg, muss mindestens ein ANDERER Administrator
 * uebrig bleiben, dessen Konto im Verzeichnis existiert. Ein verwaister
 * Rolleneintrag zaehlt deshalb nicht — er koennte sich nie anmelden.
 *
 * `liveAccountIds === null` heisst: Das Verzeichnis war nicht erreichbar. Dann
 * wird abgelehnt, statt zu raten (fail closed).
 */
export function decideAdminRoleChange(input: {
  targetId: string
  targetStaysAdmin: boolean
  adminIds: readonly string[]
  liveAccountIds: ReadonlySet<string> | null
}): AdminChangeDecision {
  if (!input.adminIds.includes(input.targetId) || input.targetStaysAdmin) {
    return { allowed: true }
  }
  if (input.liveAccountIds === null) {
    return { allowed: false, reason: "directory-unavailable" }
  }
  const survivors = input.adminIds.filter(
    (id) => id !== input.targetId && input.liveAccountIds!.has(id)
  )
  return survivors.length > 0
    ? { allowed: true }
    : { allowed: false, reason: "last-admin" }
}

export const ADMIN_CHANGE_REFUSAL_MESSAGES: Readonly<Record<AdminChangeRefusal, string>> = {
  "last-admin":
    "Der letzte funktionsfähige Administrator kann nicht herabgestuft oder entfernt werden.",
  "directory-unavailable":
    "Die Kontenliste des Anmeldedienstes ist gerade nicht erreichbar. Eine Administratorrolle kann deshalb jetzt nicht geändert werden — bitte später erneut versuchen.",
}
