import { appAuth, usesFileAuth } from "@/lib/auth"
import { getActiveFileUser } from "@/lib/auth/file-auth"
import { and, eq, isNull } from "drizzle-orm"

import { type AppRoleKey, isAppRoleKey } from "@/lib/constants/roles"
import { db } from "@/lib/db"
import { roles, userRoles } from "@/lib/db/schema"

export async function getCurrentUserRoles(): Promise<AppRoleKey[]> {
  if (usesFileAuth()) return (await getActiveFileUser())?.roles ?? []
  const { userId } = await appAuth()
  if (!userId) {
    return []
  }

  const rows = await db
    .select({ key: roles.key })
    .from(userRoles)
    .innerJoin(roles, eq(userRoles.roleId, roles.id))
    .where(eq(userRoles.clerkUserId, userId))

  const keys: AppRoleKey[] = []
  for (const row of rows) {
    if (isAppRoleKey(row.key)) {
      keys.push(row.key)
    }
  }
  return keys
}

export async function hasRole(roleKey: AppRoleKey): Promise<boolean> {
  const keys = await getCurrentUserRoles()
  return keys.includes(roleKey)
}

/** Roles that are not scoped to an organization. File-auth roles are global. */
export async function getCurrentUserGlobalRoles(): Promise<AppRoleKey[]> {
  if (usesFileAuth()) return (await getActiveFileUser())?.roles ?? []
  const { userId } = await appAuth()
  if (!userId) return []

  const rows = await db
    .select({ key: roles.key })
    .from(userRoles)
    .innerJoin(roles, eq(userRoles.roleId, roles.id))
    .where(and(eq(userRoles.clerkUserId, userId), isNull(userRoles.organizationId)))

  return rows.flatMap((row) => isAppRoleKey(row.key) ? [row.key] : [])
}
