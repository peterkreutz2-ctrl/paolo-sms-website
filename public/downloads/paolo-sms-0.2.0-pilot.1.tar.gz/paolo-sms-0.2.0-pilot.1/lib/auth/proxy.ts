import type { NextFetchEvent, NextRequest } from "next/server"

import { usesBetterAuth, usesFileAuth } from "@/lib/auth/mode"

export async function authProxy(request: NextRequest, event: NextFetchEvent) {
  if (usesBetterAuth() || usesFileAuth()) return
  const { clerkMiddleware } = await import("@clerk/nextjs/server")
  return clerkMiddleware()(request, event)
}
