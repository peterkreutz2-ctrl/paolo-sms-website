import "server-only"
import { auth, currentUser } from "@clerk/nextjs/server"
import { headers } from "next/headers"
import { getBetterAuth } from "@/auth"
import { getActiveFileUser } from "@/lib/auth/file-auth"
export { usesBetterAuth, usesFileAuth } from "@/lib/auth/mode"
import { usesBetterAuth, usesFileAuth } from "@/lib/auth/mode"
export async function appAuth(): Promise<{ userId: string | null }> {
  if (usesFileAuth()) return { userId: (await getActiveFileUser())?.id ?? null }
  if (!usesBetterAuth()) return auth()
  const session = await getBetterAuth().api.getSession({ headers: await headers() })
  return { userId: session?.user.id ?? null }
}
export async function appCurrentUser() {
  if (usesFileAuth()) {
    const user = await getActiveFileUser()
    if (!user) return null
    const [firstName, ...rest] = user.displayName.split(/\s+/)
    const emailId = `email-${user.id}`
    return { id: user.id, firstName: firstName || null, lastName: rest.join(" ") || null, emailAddresses: [{ id: emailId, emailAddress: user.email }], primaryEmailAddressId: emailId }
  }
  if (!usesBetterAuth()) return currentUser()
  const session = await getBetterAuth().api.getSession({ headers: await headers() })
  if (!session?.user) return null
  const [firstName, ...rest] = (session.user.name ?? "").split(/\s+/)
  const emailId = `email-${session.user.id}`
  return { id: session.user.id, firstName: firstName || null, lastName: rest.join(" ") || null, emailAddresses: [{ id: emailId, emailAddress: session.user.email ?? "" }], primaryEmailAddressId: emailId }
}
