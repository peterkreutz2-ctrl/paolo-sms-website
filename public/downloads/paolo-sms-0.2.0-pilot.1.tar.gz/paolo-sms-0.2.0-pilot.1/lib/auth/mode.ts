const authMode = process.env.AUTH_MODE ?? "clerk"

if (authMode !== "clerk" && authMode !== "betterauth" && authMode !== "file") {
  throw new Error(`Unsupported AUTH_MODE: ${authMode}`)
}

if (authMode === "file" && process.env.NODE_ENV === "production") {
  throw new Error("AUTH_MODE=file is development-only and cannot run in production.")
}

export function usesBetterAuth(): boolean {
  return authMode === "betterauth"
}

export function usesFileAuth(): boolean {
  return authMode === "file"
}

// Clerk-Modus: Better Auth wird weder initialisiert noch ist /api/auth/*
// erreichbar (#105). Siehe getBetterAuth in auth.ts.
export function usesClerkAuth(): boolean {
  return authMode === "clerk"
}
