import { ClerkProvider } from "@clerk/nextjs"
import { usesBetterAuth, usesFileAuth } from "@/lib/auth"
export function AuthProvider({ children }: { children: React.ReactNode }) {
  return usesBetterAuth() || usesFileAuth() ? children : <ClerkProvider afterSignOutUrl="/">{children}</ClerkProvider>
}
