"use server"

import { appAuth } from "@/lib/auth"
import { and, count, eq, isNotNull, isNull } from "drizzle-orm"
import { headers } from "next/headers"
import { revalidatePath } from "next/cache"
import { redirect } from "next/navigation"
import { z } from "zod"

import {
  computeChangedFieldNames,
  logAuditEvent,
  redactReportAuditLogEntries,
} from "@/lib/audit"
import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { hasSafetyEditRole } from "@/lib/constants/roles"
import { db } from "@/lib/db"
import {
  attachments,
  measures,
  organizations,
  publicReportRateLimits,
  reportNotes,
  reportRetentionReviews,
  reports,
} from "@/lib/db/schema"
import { deleteStoredFile } from "@/lib/storage"
import {
  createPublicReportRateLimitBlockedLog,
  createPublicReportIdentifierHash,
  getPublicReportRateLimitMaxAccepted,
  getPublicReportRateLimitRetryAfterSeconds,
  getPublicReportRateLimitWindowStart,
  PUBLIC_REPORT_RATE_LIMIT_SCOPE,
  PUBLIC_REPORT_RATE_LIMIT_WINDOW_SECONDS,
  type PublicReportRateLimitBlockedLog,
  resolvePublicReportClientIp,
} from "@/lib/public-report-rate-limit"
import { cleanupExpiredPublicReportRateLimits } from "@/lib/public-report-rate-limit-cleanup"
import {
  PUBLIC_REPORT_TYPE_LABELS,
  type PublicReportType,
} from "@/lib/constants/public-report-types"
import {
  REPORT_STATUS_LABELS,
  computeRetentionReviewEligibleAtUpdate,
  isClosedOrHidden,
} from "@/lib/constants/report-workflow"
import { computePublicClosedAtUpdate } from "@/lib/constants/public-report-status"
import { assignPublicReportCode } from "@/lib/reports/public-code"
import { decidePrivacyConsent } from "@/lib/constants/public-report-privacy-consent"
import { loadPublicReportPrivacyConsentState } from "@/lib/queries/public-report-privacy-consent"
import {
  computeRetentionReviewDueAt,
  REPORT_RETENTION_REVIEW_DECISION_VALUES,
} from "@/lib/constants/report-retention"
import {
  createReportSchema,
  updateReportClassificationSchema,
  updateReportCoreSchema,
  updateReportReporterInfoSchema,
  updateReportWorkflowSchema,
} from "@/lib/validations/report"

const softDeleteReportSchema = z.object({
  reportId: z.string().uuid("Ungültige Meldungs-ID."),
})

const restoreReportSchema = softDeleteReportSchema

const anonymizeReportSchema = z.object({
  reportId: z.string().uuid("Ungültige Meldungs-ID."),
  note: z
    .string()
    .trim()
    .max(500, "Der Hinweis darf hoechstens 500 Zeichen lang sein.")
    .optional(),
})

const logRetentionReviewSchema = z
  .object({
    reportId: z.string().uuid("Ungültige Meldungs-ID."),
    decision: z.enum(REPORT_RETENTION_REVIEW_DECISION_VALUES, {
      message: "Ungültige Entscheidung.",
    }),
    reason: z
      .string()
      .trim()
      .max(500, "Die Begruendung darf hoechstens 500 Zeichen lang sein.")
      .optional(),
    postponedUntil: z.preprocess(
      (v) => {
        const s = typeof v === "string" ? v.trim() : ""
        return s.length === 0 ? undefined : s
      },
      z
        .string()
        .regex(/^\d{4}-\d{2}-\d{2}$/, "Ungültiges Datum (YYYY-MM-DD).")
        .optional()
    ),
    // Explizite menschliche Bestaetigung, dass strukturierte Melderdaten,
    // Freitexte, Notizen und Anhaenge auf Personenbezug geprueft wurden.
    // Setzt anonymizationStatus nur bei "anonymized" wirklich auf
    // "completed" — die Auswahl der Entscheidung allein reicht nicht.
    confirmNoPersonalData: z.preprocess(
      (v) => v === "1" || v === "true" || v === "on",
      z.boolean()
    ),
  })
  .refine(
    (data) => data.decision !== "postponed" || Boolean(data.postponedUntil),
    {
      message: "Bitte ein Zurueckstellungsdatum angeben.",
      path: ["postponedUntil"],
    }
  )
  .refine(
    (data) => {
      if (data.decision !== "postponed" || !data.postponedUntil) return true
      const todayYMD = new Date().toISOString().slice(0, 10)
      return data.postponedUntil > todayYMD
    },
    {
      message: "Das Zurueckstellungsdatum muss in der Zukunft liegen.",
      path: ["postponedUntil"],
    }
  )
  .refine(
    (data) => data.decision !== "anonymized" || !data.confirmNoPersonalData || Boolean(data.reason),
    {
      message:
        "Bitte einen Pruefvermerk angeben, wenn der vollständige Personenbezugs-Check bestaetigt wird.",
      path: ["reason"],
    }
  )

const HARD_DELETE_CONFIRM_TEXT = "ENDGÜLTIG LÖSCHEN"

const hardDeleteReportSchema = z.object({
  reportId: z.string().uuid("Ungültige Meldungs-ID."),
  confirmText: z
    .string()
    .refine((val) => val === HARD_DELETE_CONFIRM_TEXT, {
      message: "Die Bestätigung ist ungültig.",
    }),
})

function isUniqueConstraintError(error: unknown): boolean {
  return error instanceof Error && /duplicate key|unique constraint|violates unique/i.test(error.message)
}

export async function createReport(data: unknown) {
  const parsed = createReportSchema.safeParse(data)

  if (!parsed.success) {
    return {
      success: false,
      resultCode: "validation_error",
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const [organization] = await db
    .select()
    .from(organizations)
    .limit(1)

  if (!organization) {
    return {
      success: false,
      resultCode: "infrastructure_error",
      message: "Keine Organisation gefunden.",
    }
  }

  // ─── Datenschutz-Einwilligung (#101) ──────────────────────────────────────
  //
  // Vor Ratenbegrenzung und Transaktion: Eine abgewiesene Einreichung
  // verbraucht kein Kontingent und legt nichts an. Massgeblich ist der
  // Serverzustand jetzt — nicht das, was das Formular beim Laden kannte. Die
  // Snapshots kommen deshalb aus der Datenbank, nie aus dem Browser.
  const privacyConsentState = await loadPublicReportPrivacyConsentState(organization)
  const privacyConsentDecision = decidePrivacyConsent({
    enabled: privacyConsentState.enabled,
    currentFingerprint: privacyConsentState.fingerprint,
    submittedFingerprint: parsed.data.privacyConsentFingerprint,
    consentGiven: parsed.data.privacyConsentGiven === true,
  })

  if (privacyConsentDecision === "stale") {
    return {
      success: false,
      resultCode: "privacy_consent_stale",
      message: "Die Hinweise zum Datenschutz wurden in der Zwischenzeit geändert. Bitte lade die Einwilligung neu und lies sie erneut. Deine Meldung wurde noch nicht gespeichert.",
    }
  }

  if (privacyConsentDecision === "missing") {
    return {
      success: false,
      resultCode: "privacy_consent_required",
      message: "Bitte bestätige die Einwilligung zum Datenschutz, bevor du die Meldung absendest.",
    }
  }

  const privacyConsentRecord =
    privacyConsentDecision === "given"
      ? {
          privacyConsentAt: new Date(),
          privacyConsentText: privacyConsentState.displayedConsentText,
          privacyPolicySnapshot: privacyConsentState.privacyPolicySnapshot,
        }
      : {
          privacyConsentAt: null,
          privacyConsentText: null,
          privacyPolicySnapshot: null,
        }

  const requestHeaders = await headers()
  const clientIp = resolvePublicReportClientIp(requestHeaders)
  const rateLimitSalt = process.env.PUBLIC_REPORT_RATE_LIMIT_SALT?.trim()
  const effectiveRateLimitSalt =
    rateLimitSalt || (process.env.NODE_ENV === "production" ? null : "dev-public-report-rate-limit-salt")

  if (!effectiveRateLimitSalt || !clientIp) {
    return {
      success: false,
      resultCode: "rate_limit_unavailable",
      message: "Die Schutzmechanismen für öffentliche Meldungen sind gerade nicht verfügbar. Bitte versuche es später erneut oder wende dich direkt an die Sicherheitsverantwortlichen.",
    }
  }

  const identifierHash = createPublicReportIdentifierHash(effectiveRateLimitSalt, clientIp)
  if (!identifierHash) {
    return {
      success: false,
      resultCode: "rate_limit_unavailable",
      message: "Die Schutzmechanismen für öffentliche Meldungen sind gerade nicht verfügbar. Bitte versuche es später erneut oder wende dich direkt an die Sicherheitsverantwortlichen.",
    }
  }

  const rateLimitMaxAccepted = getPublicReportRateLimitMaxAccepted()

  const hasReporterName = Boolean(parsed.data.reporterName?.trim())
  const isAnonymous = !hasReporterName

  const showReportabilityHint =
    parsed.data.reportType === "accident" && (
      parsed.data.injurySeverity === "serious" ||
      parsed.data.injurySeverity === "fatal" ||
      parsed.data.damageSeverity === "aircraft_destroyed"
    )

  let submissionOutcome = "accepted"
  let rateLimitRetryAfterSeconds: number | undefined
  let blockedLog: PublicReportRateLimitBlockedLog | null = null
  let duplicatePublicCode: string | null = null
  let assignedPublicCode: string | null = null
  let insertedReport: {
    id: string
    shortDescription: string | null
    reportType: string
    isAnonymous: boolean
  } | null = null

  await db.transaction(async (tx) => {
    // Wiederholte Einreichung: Der Code der bereits gespeicherten Meldung
    // wird mitgelesen und zurueckgegeben. Kam die erste Antwort beim
    // Meldenden nicht an, bekommt er beim zweiten Versuch dieselbe Quittung
    // statt einer zweiten Meldung.
    //
    // Ausgelesen wird ausschliesslich der Code — kein Titel, kein Status,
    // keine ID. Die Einreichungskennung ist damit ein Weg zur eigenen
    // Quittung, aber kein Weg zu Inhalten.
    const [existingReport] = await tx
      .select({ id: reports.id, publicCode: reports.publicCode })
      .from(reports)
      .where(eq(reports.publicSubmissionId, parsed.data.publicSubmissionId))
      .limit(1)

    if (existingReport) {
      // Auch die Wiederholung unterliegt der Ratenbegrenzung. Bis hierher kehrte
      // dieser Zweig zurueck, bevor die Begrenzung ueberhaupt betrachtet wurde
      // — solange er nichts zurueckgab, war das folgenlos. Seit er einen Code
      // liefert, waere er sonst der einzige anonyme Pfad ohne Schranke.
      //
      // Gezaehlt wird dabei nichts: Eine Wiederholung ist keine neue Meldung
      // und darf das Kontingent des Meldenden nicht aufbrauchen. Ist das
      // Kontingent des Zeitfensters aber bereits erschoepft, gibt es auch
      // keine Auskunft mehr.
      const [bucket] = await tx
        .select({ acceptedCount: publicReportRateLimits.acceptedCount })
        .from(publicReportRateLimits)
        .where(
          and(
            eq(publicReportRateLimits.organizationId, organization.id),
            eq(publicReportRateLimits.scope, PUBLIC_REPORT_RATE_LIMIT_SCOPE),
            eq(publicReportRateLimits.identifier, identifierHash),
            eq(
              publicReportRateLimits.windowStart,
              getPublicReportRateLimitWindowStart(new Date())
            )
          )
        )
        .limit(1)

      if (bucket && bucket.acceptedCount >= rateLimitMaxAccepted) {
        submissionOutcome = "blocked"
        rateLimitRetryAfterSeconds = getPublicReportRateLimitRetryAfterSeconds(
          getPublicReportRateLimitWindowStart(new Date())
        )
        return
      }

      submissionOutcome = "duplicate"
      duplicatePublicCode = existingReport.publicCode
      return
    }

    const windowStart = getPublicReportRateLimitWindowStart(new Date())
    const bucketMatch = and(
      eq(publicReportRateLimits.organizationId, organization.id),
      eq(publicReportRateLimits.scope, PUBLIC_REPORT_RATE_LIMIT_SCOPE),
      eq(publicReportRateLimits.identifier, identifierHash),
      eq(publicReportRateLimits.windowStart, windowStart)
    )

    const [existingBucket] = await tx
      .select({
        id: publicReportRateLimits.id,
        acceptedCount: publicReportRateLimits.acceptedCount,
        blockedCount: publicReportRateLimits.blockedCount,
      })
      .from(publicReportRateLimits)
      .where(bucketMatch)
      .limit(1)
      .for("update")

    if (existingBucket) {
      if (existingBucket.acceptedCount >= rateLimitMaxAccepted) {
        blockedLog = createPublicReportRateLimitBlockedLog(
          existingBucket.blockedCount,
          organization.id,
          rateLimitMaxAccepted
        )
        await tx
          .update(publicReportRateLimits)
          .set({
            blockedCount: existingBucket.blockedCount + 1,
            updatedAt: new Date(),
          })
          .where(eq(publicReportRateLimits.id, existingBucket.id))
        submissionOutcome = "blocked"
        rateLimitRetryAfterSeconds = getPublicReportRateLimitRetryAfterSeconds(windowStart)
        return
      }

      await tx
        .update(publicReportRateLimits)
        .set({
          acceptedCount: existingBucket.acceptedCount + 1,
          updatedAt: new Date(),
        })
        .where(eq(publicReportRateLimits.id, existingBucket.id))
    } else {
      try {
        await tx.insert(publicReportRateLimits).values({
          organizationId: organization.id,
          scope: PUBLIC_REPORT_RATE_LIMIT_SCOPE,
          identifier: identifierHash,
          windowStart,
          windowDurationSeconds: PUBLIC_REPORT_RATE_LIMIT_WINDOW_SECONDS,
          acceptedCount: 1,
          blockedCount: 0,
        })
      } catch (error) {
        if (!isUniqueConstraintError(error)) throw error

        const [conflictingBucket] = await tx
          .select({
            id: publicReportRateLimits.id,
            acceptedCount: publicReportRateLimits.acceptedCount,
            blockedCount: publicReportRateLimits.blockedCount,
          })
          .from(publicReportRateLimits)
          .where(bucketMatch)
          .limit(1)
          .for("update")

        if (!conflictingBucket) throw error

        if (conflictingBucket.acceptedCount >= rateLimitMaxAccepted) {
          blockedLog = createPublicReportRateLimitBlockedLog(
            conflictingBucket.blockedCount,
            organization.id,
            rateLimitMaxAccepted
          )
          await tx
            .update(publicReportRateLimits)
            .set({
              blockedCount: conflictingBucket.blockedCount + 1,
              updatedAt: new Date(),
            })
            .where(eq(publicReportRateLimits.id, conflictingBucket.id))
          submissionOutcome = "blocked"
          rateLimitRetryAfterSeconds = getPublicReportRateLimitRetryAfterSeconds(windowStart)
          return
        }

        await tx
          .update(publicReportRateLimits)
          .set({
            acceptedCount: conflictingBucket.acceptedCount + 1,
            updatedAt: new Date(),
          })
          .where(eq(publicReportRateLimits.id, conflictingBucket.id))
      }
    }

    const reportValues = {
      organizationId: organization.id,
      reportType: parsed.data.reportType,
      status: "new",
      priority: "medium",
      shortDescription: parsed.data.shortDescription,
      detailedDescription: parsed.data.description,
      isAnonymous,
      occurredAt: parsed.data.occurredAt ? new Date(parsed.data.occurredAt) : null,
      locationText: parsed.data.locationText || null,
      reporterLessonsLearned: parsed.data.reporterLessonsLearned || null,
      reporterSuggestedMeasures: parsed.data.reporterSuggestedMeasures || null,
      sourceChannel: "public_form",
      publicSubmissionId: parsed.data.publicSubmissionId,
      activityType: parsed.data.activityType ?? null,
      flightPhase: parsed.data.flightPhase ?? null,
      launchType: parsed.data.launchType ?? null,
      severity: parsed.data.severity ?? null,
      injurySeverity: parsed.data.injurySeverity ?? null,
      damageSeverity: parsed.data.damageSeverity ?? null,
      reporterName: parsed.data.reporterName || null,
      reporterRole: parsed.data.reporterRole ?? null,
      reporterContact: parsed.data.reporterContact || null,
      ...privacyConsentRecord,
    }

    // Codevergabe: Kandidat ziehen, einfuegen, bei Kollision neu ziehen. Der
    // Unique-Index entscheidet, ob ein Code frei ist — ein vorheriges
    // Nachsehen waere ein Wettlauf, weil zwischen Lesen und Schreiben eine
    // zweite Einreichung denselben Code belegen kann.
    //
    // Jeder Versuch laeuft in einem eigenen Sicherungspunkt (verschachtelte
    // Transaktion). Ohne ihn wuerde die erste Eindeutigkeitsverletzung die
    // gesamte umgebende Transaktion abbrechen — samt der bereits gebuchten
    // Ratenbegrenzung.
    const assignment = await assignPublicReportCode(async (code) => {
      try {
        const rows = await tx.transaction(async (savepoint) =>
          savepoint
            .insert(reports)
            .values({ ...reportValues, publicCode: code })
            .returning()
        )
        return { ok: true as const, value: rows[0] ?? null }
      } catch (error) {
        if (isUniqueConstraintError(error)) {
          return { ok: false as const, collision: true as const }
        }
        throw error
      }
    })

    if (assignment) {
      assignedPublicCode = assignment.code
      insertedReport = assignment.value as typeof insertedReport
    } else {
      // Notfallweg: Nach allen Versuchen war kein Code frei. Die Meldung wird
      // trotzdem gespeichert — eine Sicherheitsmeldung darf nicht an ihrer
      // Quittung scheitern. Sie erhaelt dann keinen oeffentlichen Eintrag.
      console.error(
        "[public-report-code] Kein freier Meldungscode gefunden; Meldung wird ohne Code gespeichert.",
        { organizationId: organization.id }
      )
      const rows = await tx.insert(reports).values(reportValues).returning()
      insertedReport = (rows[0] ?? null) as typeof insertedReport
    }
  })

  if (submissionOutcome === "duplicate") {
    return {
      success: true,
      resultCode: "duplicate_submission",
      message: "Diese Einreichung wurde bereits verarbeitet. Keine neue Meldung wurde erstellt.",
      publicCode: duplicatePublicCode,
      publicStatusEnabled: organization.publicReportStatusEnabled,
    }
  }

  if (submissionOutcome === "blocked") {
    if (blockedLog) {
      console.info("[public-report-rate-limit] Public report blocked.", blockedLog)
    }
    return {
      success: false,
      resultCode: "rate_limited",
      message: "Zu viele Meldungen von dieser Verbindung. Bitte versuche es später erneut oder wende dich direkt an die Sicherheitsverantwortlichen.",
      retryAfterSeconds: rateLimitRetryAfterSeconds ?? PUBLIC_REPORT_RATE_LIMIT_WINDOW_SECONDS,
    }
  }

  if (!insertedReport) {
    return {
      success: false,
      resultCode: "infrastructure_error",
      message: "Die Meldung konnte nicht gespeichert werden. Bitte versuche es später erneut.",
    }
  }

  const reportForAudit = insertedReport as {
    id: string
    shortDescription: string | null
    reportType: string
    isAnonymous: boolean
  }

  try {
    const deletedRateLimitBuckets = await cleanupExpiredPublicReportRateLimits()
    if (deletedRateLimitBuckets > 0) {
      console.info(
        `[public-report-rate-limit] Deleted ${deletedRateLimitBuckets} expired bucket(s).`
      )
    }
  } catch (error) {
    console.error(
      "[public-report-rate-limit] Cleanup of expired buckets failed:",
      error
    )
  }

  await logAuditEvent({
    organizationId: organization.id,
    clerkUserId: null,
    action: "REPORT_CREATED",
    resourceType: "report",
    resourceId: reportForAudit.id,
    changes: {
      shortDescription: reportForAudit.shortDescription,
      reportType: reportForAudit.reportType,
      isAnonymous: reportForAudit.isAnonymous,
      // Nur das Ja/Nein, nie der Code selbst: Der Audit-Eintrag macht den
      // Notfallweg im Nachhinein auffindbar, ohne die oeffentliche Kennung
      // ins interne Protokoll zu ziehen.
      publicCodeAssigned: Boolean(assignedPublicCode),
      // Nur das Ja/Nein; Zeitpunkt und Snapshots stehen an der Meldung selbst.
      privacyConsentRecorded: privacyConsentDecision === "given",
    },
  })

  return {
    success: true,
    resultCode: "created",
    message: "Die Meldung wurde gespeichert.",
    showReportabilityHint,
    // Bewusst nur der Meldungscode statt des gesamten Datensatzes: Die interne
    // Report-UUID hat im Browser nichts verloren. `null` heisst, dass
    // ausnahmsweise kein Code vergeben werden konnte (Notfallweg).
    publicCode: assignedPublicCode,
    // Damit der Bestaetigungsdialog nicht auf eine Statusabfrage verweist, die
    // die Organisation abgeschaltet hat. Der Server hat die Organisation
    // ohnehin schon geladen; ein zweiter Weg waere eine zweite Wahrheitsquelle
    // fuer dieselbe Einstellung.
    publicStatusEnabled: organization.publicReportStatusEnabled,
  }
}

export type UpdateReportWorkflowState = {
  success: boolean
  message: string
}

export async function updateReportWorkflow(
  _: UpdateReportWorkflowState,
  formData: FormData
): Promise<UpdateReportWorkflowState> {
  const parsed = updateReportWorkflowSchema.safeParse({
    reportId: formData.get("reportId"),
    status: formData.get("status"),
    priority: formData.get("priority"),
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zur Bearbeitung des Meldungs-Workflows.",
    }
  }

  // Opt-in Flag aus dem Abschluss-/Ausblenden-Dialog: strukturierte Melderdaten
  // im selben Schritt teilautomatisch anonymisieren.
  const wantsAnonymize = formData.get("anonymizeReporter") === "1"

  // Fetch current values for audit trail before updating
  const [currentReport] = await db
    .select({
      status: reports.status,
      priority: reports.priority,
      organizationId: reports.organizationId,
      shortDescription: reports.shortDescription,
      anonymizedAt: reports.anonymizedAt,
      reporterName: reports.reporterName,
      reporterRole: reports.reporterRole,
      reporterContact: reports.reporterContact,
    })
    .from(reports)
    .where(and(eq(reports.id, parsed.data.reportId), isNull(reports.deletedAt)))
    .limit(1)

  if (!currentReport) {
    return {
      success: false,
      message: "Meldung wurde nicht gefunden.",
    }
  }

  // Anonymisierung nur bei Abschluss/Ausblenden, nur strukturierte Melderdaten,
  // und nur, wenn noch nicht anonymisiert.
  const isClosingOrHiding = isClosedOrHidden(parsed.data.status)
  const willAnonymize =
    wantsAnonymize && isClosingOrHiding && !currentReport.anonymizedAt

  // Nur die betroffenen Feldnamen protokollieren — niemals Klartext-Melderdaten.
  const clearedFields = willAnonymize
    ? (
        [
          ["reporterName", currentReport.reporterName],
          ["reporterRole", currentReport.reporterRole],
          ["reporterContact", currentReport.reporterContact],
        ] as const
      )
        .filter(([, value]) => Boolean(value))
        .map(([key]) => key)
    : []

  const anonymizedAt = willAnonymize ? new Date() : undefined
  const anonymizationNote = willAnonymize
    ? `Strukturierte Melderdaten beim Statuswechsel auf „${REPORT_STATUS_LABELS[parsed.data.status]}" anonymisiert.`
    : null

  // DSGVO-Retention-Review-Anker: nur bei Eintritt/Austritt aus der
  // closed/hidden-Gruppe gesetzt/geloescht, sonst unveraendert (leeres
  // Objekt, Feld wird nicht ins Update uebernommen).
  const retentionReviewEligibleAtUpdate = computeRetentionReviewEligibleAtUpdate(
    currentReport.status,
    parsed.data.status
  )

  // Fristanker der oeffentlichen Statusrueckmeldung: nur beim WECHSEL nach
  // "closed" gesetzt, sonst leeres Objekt — das Feld faellt dann aus dem
  // Update heraus und behaelt seinen Wert. Deshalb startet das erneute
  // Speichern einer bereits abgeschlossenen Meldung die Drei-Monats-Frist
  // nicht neu, ein erneuter Abschluss nach Wiedereroeffnung aber schon.
  //
  // Rein serverseitig: Die Bedienoberflaeche von /dashboard/reports/[id]
  // aendert sich dadurch nicht.
  const publicClosedAtUpdate = computePublicClosedAtUpdate(
    currentReport.status,
    parsed.data.status
  )

  // Die Anonymisierung (Reporterfelder nullen + Audit-Log-Redaktion +
  // REPORT_ANONYMIZED-Nachweis) laeuft atomar in einer Transaktion — analog
  // zu anonymizeReport. Der reine Status-/Prioritaets-Wechsel ohne
  // Anonymisierung bleibt unveraendert (keine Transaktion noetig).
  let redactedAuditLogEntries = 0

  if (willAnonymize) {
    try {
      await db.transaction(async (tx) => {
        const [updatedReport] = await tx
          .update(reports)
          .set({
            status: parsed.data.status,
            priority: parsed.data.priority,
            updatedAt: new Date(),
            reporterName: null,
            reporterRole: null,
            reporterContact: null,
            isAnonymous: true,
            anonymizedAt,
            anonymizedBy: userId ?? null,
            anonymizationNote,
            // "partial": nur strukturierte Melderdaten, Freitexte/Anhaenge offen.
            anonymizationStatus: "partial" as const,
            ...retentionReviewEligibleAtUpdate,
            ...publicClosedAtUpdate,
          })
          .where(
            and(eq(reports.id, parsed.data.reportId), isNull(reports.deletedAt))
          )
          .returning({ id: reports.id })

        if (!updatedReport) {
          throw new Error("UPDATE_REPORT_WORKFLOW_NOT_FOUND")
        }

        redactedAuditLogEntries = await redactReportAuditLogEntries(
          tx,
          parsed.data.reportId
        )

        await logAuditEvent(
          {
            organizationId: currentReport.organizationId,
            clerkUserId: userId ?? null,
            action: "REPORT_ANONYMIZED",
            resourceType: "report",
            resourceId: parsed.data.reportId,
            changes: {
              shortDescription: currentReport.shortDescription,
              anonymizationStatus: "partial",
              clearedFields,
              note: anonymizationNote,
              trigger: "workflow_status_change",
              redactedAuditLogEntries,
            },
          },
          tx
        )
      })
    } catch (error) {
      if (
        error instanceof Error &&
        error.message === "UPDATE_REPORT_WORKFLOW_NOT_FOUND"
      ) {
        return {
          success: false,
          message: "Meldung wurde nicht gefunden.",
        }
      }
      return {
        success: false,
        message: "Die Datenbankaktion ist fehlgeschlagen. Bitte erneut versuchen.",
      }
    }
  } else {
    const [updatedReport] = await db
      .update(reports)
      .set({
        status: parsed.data.status,
        priority: parsed.data.priority,
        updatedAt: new Date(),
        ...retentionReviewEligibleAtUpdate,
        ...publicClosedAtUpdate,
      })
      .where(
        and(eq(reports.id, parsed.data.reportId), isNull(reports.deletedAt))
      )
      .returning({ id: reports.id })

    if (!updatedReport) {
      return {
        success: false,
        message: "Meldung wurde nicht gefunden.",
      }
    }
  }

  await logAuditEvent({
    organizationId: currentReport.organizationId,
    clerkUserId: userId ?? null,
    action: "REPORT_WORKFLOW_UPDATED",
    resourceType: "report",
    resourceId: parsed.data.reportId,
    changes: {
      shortDescription: currentReport.shortDescription,
      old: { status: currentReport.status, priority: currentReport.priority },
      new: { status: parsed.data.status, priority: parsed.data.priority },
    },
  })

  revalidatePath(`/dashboard/reports/${parsed.data.reportId}`)
  revalidatePath("/dashboard/reports")
  revalidatePath("/dashboard")

  return {
    success: true,
    message: willAnonymize
      ? "Workflow-Felder gespeichert. Strukturierte Melderdaten wurden anonymisiert; Freitexte und Anhänge bleiben manuell zu prüfen."
      : "Workflow-Felder wurden gespeichert.",
  }
}

export type UpdateReportCoreState = {
  success: boolean
  message: string
}

export async function updateReportCore(
  _: UpdateReportCoreState,
  formData: FormData
): Promise<UpdateReportCoreState> {
  const toOpt = (v: FormDataEntryValue | null): string | undefined => {
    if (!v || v === "__none") return undefined
    return String(v)
  }

  const rawOccurredAt = formData.get("occurredAt")
  const occurredAtStr = rawOccurredAt ? String(rawOccurredAt).trim() : ""

  const parsed = updateReportCoreSchema.safeParse({
    reportId: formData.get("reportId"),
    reportType: formData.get("reportType"),
    shortDescription: formData.get("shortDescription"),
    detailedDescription: formData.get("detailedDescription"),
    isAnonymous: formData.get("isAnonymous"),
    occurredAt: occurredAtStr || undefined,
    locationText: formData.get("locationText") || undefined,
    activityType: toOpt(formData.get("activityType")),
    flightPhase: toOpt(formData.get("flightPhase")),
    launchType: toOpt(formData.get("launchType")),
    injurySeverity: toOpt(formData.get("injurySeverity")),
    damageSeverity: toOpt(formData.get("damageSeverity")),
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zur Bearbeitung der Meldungsdaten.",
    }
  }

  const [currentReport] = await db
    .select({
      organizationId: reports.organizationId,
      shortDescription: reports.shortDescription,
      reportType: reports.reportType,
      detailedDescription: reports.detailedDescription,
      isAnonymous: reports.isAnonymous,
      occurredAt: reports.occurredAt,
      locationText: reports.locationText,
      activityType: reports.activityType,
      flightPhase: reports.flightPhase,
      launchType: reports.launchType,
      injurySeverity: reports.injurySeverity,
      damageSeverity: reports.damageSeverity,
      anonymizationStatus: reports.anonymizationStatus,
    })
    .from(reports)
    .where(and(eq(reports.id, parsed.data.reportId), isNull(reports.deletedAt)))
    .limit(1)

  if (!currentReport) {
    return {
      success: false,
      message: "Meldung wurde nicht gefunden.",
    }
  }

  const occurredAtDate = parsed.data.occurredAt
    ? new Date(parsed.data.occurredAt)
    : null

  // Relevante Freitext-/Ortsangaben-Aenderung setzt eine bereits als
  // vollstaendig geprueft bestaetigte Meldung zurueck auf "needs_review"
  // (siehe lib/actions/report-anonymization-status.ts). Rein strukturierte
  // Felder (Typ, anonym-Flag, Vorfallsdatum, Aktivitaet, Schweregrade)
  // loesen bewusst KEINEN Reset aus.
  const freeTextChanged =
    currentReport.shortDescription !== parsed.data.shortDescription ||
    currentReport.detailedDescription !== parsed.data.detailedDescription ||
    (currentReport.locationText ?? null) !== (parsed.data.locationText ?? null)
  const nextAnonymizationStatus =
    freeTextChanged && currentReport.anonymizationStatus === "completed"
      ? "needs_review"
      : currentReport.anonymizationStatus

  const [updatedReport] = await db
    .update(reports)
    .set({
      reportType: parsed.data.reportType,
      shortDescription: parsed.data.shortDescription,
      detailedDescription: parsed.data.detailedDescription,
      isAnonymous: parsed.data.isAnonymous,
      occurredAt: occurredAtDate,
      locationText: parsed.data.locationText ?? null,
      activityType: parsed.data.activityType ?? null,
      flightPhase: parsed.data.flightPhase ?? null,
      launchType: parsed.data.launchType ?? null,
      injurySeverity: parsed.data.injurySeverity ?? null,
      damageSeverity: parsed.data.damageSeverity ?? null,
      anonymizationStatus: nextAnonymizationStatus,
      updatedAt: new Date(),
    })
    .where(
      and(eq(reports.id, parsed.data.reportId), isNull(reports.deletedAt))
    )
    .returning({ id: reports.id })

  if (!updatedReport) {
    return {
      success: false,
      message: "Meldung wurde nicht gefunden.",
    }
  }

  const typeLabel = (t: string) =>
    PUBLIC_REPORT_TYPE_LABELS[t as PublicReportType] ?? t

  await logAuditEvent({
    organizationId: currentReport.organizationId,
    clerkUserId: userId ?? null,
    action: "REPORT_CORE_UPDATED",
    resourceType: "report",
    resourceId: parsed.data.reportId,
    changes: {
      shortDescription: parsed.data.shortDescription,
      // Freitext nie im Klartext protokollieren — nur, ob er sich geaendert hat.
      detailedDescriptionChanged:
        currentReport.detailedDescription !== parsed.data.detailedDescription,
      anonymizationStatusReset: nextAnonymizationStatus !== currentReport.anonymizationStatus,
      old: {
        reportType: typeLabel(currentReport.reportType),
        isAnonymous: currentReport.isAnonymous,
        occurredAt: currentReport.occurredAt?.toISOString() ?? null,
        locationText: currentReport.locationText,
        activityType: currentReport.activityType,
        flightPhase: currentReport.flightPhase,
        launchType: currentReport.launchType,
        injurySeverity: currentReport.injurySeverity,
        damageSeverity: currentReport.damageSeverity,
      },
      new: {
        reportType: typeLabel(parsed.data.reportType),
        isAnonymous: parsed.data.isAnonymous,
        occurredAt: occurredAtDate?.toISOString() ?? null,
        locationText: parsed.data.locationText ?? null,
        activityType: parsed.data.activityType ?? null,
        flightPhase: parsed.data.flightPhase ?? null,
        launchType: parsed.data.launchType ?? null,
        injurySeverity: parsed.data.injurySeverity ?? null,
        damageSeverity: parsed.data.damageSeverity ?? null,
      },
    },
  })

  revalidatePath(`/dashboard/reports/${parsed.data.reportId}`)
  revalidatePath("/dashboard/reports")
  revalidatePath("/dashboard")

  return {
    success: true,
    message: "Meldungsdaten wurden gespeichert.",
  }
}

export type UpdateReportClassificationState = {
  success: boolean
  message: string
}

export async function updateReportClassification(
  _: UpdateReportClassificationState,
  formData: FormData
): Promise<UpdateReportClassificationState> {
  const toOpt = (v: FormDataEntryValue | null): string | undefined => {
    if (!v || v === "__none") return undefined
    return String(v)
  }

  const parsed = updateReportClassificationSchema.safeParse({
    reportId: formData.get("reportId"),
    activityArea: toOpt(formData.get("activityArea")),
    isReportableAccident: formData.get("isReportableAccident"),
    riskProbability: toOpt(formData.get("riskProbability")),
    riskSeverity: toOpt(formData.get("riskSeverity")),
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zur Klassifikation von Meldungen.",
    }
  }

  const [currentReport] = await db
    .select({
      organizationId: reports.organizationId,
      shortDescription: reports.shortDescription,
      activityArea: reports.activityArea,
      isReportableAccident: reports.isReportableAccident,
      riskProbability: reports.riskProbability,
      riskSeverity: reports.riskSeverity,
    })
    .from(reports)
    .where(and(eq(reports.id, parsed.data.reportId), isNull(reports.deletedAt)))
    .limit(1)

  if (!currentReport) {
    return {
      success: false,
      message: "Meldung wurde nicht gefunden.",
    }
  }

  const [updatedReport] = await db
    .update(reports)
    .set({
      activityArea: parsed.data.activityArea ?? null,
      isReportableAccident: parsed.data.isReportableAccident ?? null,
      riskProbability: parsed.data.riskProbability ?? null,
      riskSeverity: parsed.data.riskSeverity ?? null,
      updatedAt: new Date(),
    })
    .where(
      and(eq(reports.id, parsed.data.reportId), isNull(reports.deletedAt))
    )
    .returning({ id: reports.id })

  if (!updatedReport) {
    return {
      success: false,
      message: "Meldung wurde nicht gefunden.",
    }
  }

  await logAuditEvent({
    organizationId: currentReport.organizationId,
    clerkUserId: userId ?? null,
    action: "REPORT_CLASSIFICATION_UPDATED",
    resourceType: "report",
    resourceId: parsed.data.reportId,
    changes: {
      shortDescription: currentReport.shortDescription,
      old: {
        activityArea: currentReport.activityArea,
        isReportableAccident: currentReport.isReportableAccident,
        riskProbability: currentReport.riskProbability,
        riskSeverity: currentReport.riskSeverity,
      },
      new: {
        activityArea: parsed.data.activityArea ?? null,
        isReportableAccident: parsed.data.isReportableAccident ?? null,
        riskProbability: parsed.data.riskProbability ?? null,
        riskSeverity: parsed.data.riskSeverity ?? null,
      },
    },
  })

  revalidatePath(`/dashboard/reports/${parsed.data.reportId}`)

  return {
    success: true,
    message: "Klassifikation wurde gespeichert.",
  }
}

export type UpdateReportReporterInfoState = {
  success: boolean
  message: string
}

export async function updateReportReporterInfo(
  _: UpdateReportReporterInfoState,
  formData: FormData
): Promise<UpdateReportReporterInfoState> {
  const toOpt = (v: FormDataEntryValue | null): string | undefined => {
    const s = v ? String(v).trim() : ""
    if (!s || s === "__none") return undefined
    return s
  }

  const parsed = updateReportReporterInfoSchema.safeParse({
    reportId: formData.get("reportId"),
    reporterName: toOpt(formData.get("reporterName")),
    reporterRole: toOpt(formData.get("reporterRole")),
    reporterContact: toOpt(formData.get("reporterContact")),
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zur Bearbeitung der Melderinfos.",
    }
  }

  const [currentReport] = await db
    .select({
      organizationId: reports.organizationId,
      shortDescription: reports.shortDescription,
      reporterName: reports.reporterName,
      reporterRole: reports.reporterRole,
      reporterContact: reports.reporterContact,
      anonymizedAt: reports.anonymizedAt,
    })
    .from(reports)
    .where(and(eq(reports.id, parsed.data.reportId), isNull(reports.deletedAt)))
    .limit(1)

  if (!currentReport) {
    return {
      success: false,
      message: "Meldung wurde nicht gefunden.",
    }
  }

  // Nach Anonymisierung duerfen Melderdaten nicht erneut gesetzt werden —
  // das waere faktisch eine Re-Identifizierung. Kein Ausnahmefall im MVP.
  if (currentReport.anonymizedAt) {
    return {
      success: false,
      message:
        "Melderdaten wurden bereits anonymisiert und können nicht erneut gesetzt werden.",
    }
  }

  const newReporterName = parsed.data.reporterName ?? null
  const isAnonymous = !Boolean(newReporterName?.trim())

  const [updatedReport] = await db
    .update(reports)
    .set({
      reporterName: newReporterName,
      reporterRole: parsed.data.reporterRole ?? null,
      reporterContact: parsed.data.reporterContact ?? null,
      isAnonymous,
      updatedAt: new Date(),
    })
    .where(
      and(eq(reports.id, parsed.data.reportId), isNull(reports.deletedAt))
    )
    .returning({ id: reports.id })

  if (!updatedReport) {
    return {
      success: false,
      message: "Meldung wurde nicht gefunden.",
    }
  }

  // Nur die geaenderten Feldnamen protokollieren — niemals Klartext-Melderdaten.
  const changedFields = computeChangedFieldNames(
    {
      reporterName: currentReport.reporterName,
      reporterRole: currentReport.reporterRole,
      reporterContact: currentReport.reporterContact,
    },
    {
      reporterName: newReporterName,
      reporterRole: parsed.data.reporterRole ?? null,
      reporterContact: parsed.data.reporterContact ?? null,
    }
  )

  await logAuditEvent({
    organizationId: currentReport.organizationId,
    clerkUserId: userId ?? null,
    action: "REPORT_REPORTER_INFO_UPDATED",
    resourceType: "report",
    resourceId: parsed.data.reportId,
    changes: {
      shortDescription: currentReport.shortDescription,
      changedFields,
    },
  })

  revalidatePath(`/dashboard/reports/${parsed.data.reportId}`)

  return {
    success: true,
    message: "Melder-Informationen wurden gespeichert.",
  }
}

export type SoftDeleteReportState = {
  success: boolean
  message: string
}

export async function softDeleteReport(
  _: SoftDeleteReportState,
  formData: FormData
): Promise<SoftDeleteReportState> {
  const parsed = softDeleteReportSchema.safeParse({
    reportId: formData.get("reportId"),
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()
  if (!userId) {
    return {
      success: false,
      message: "Nicht angemeldet.",
    }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zum Ausblenden von Meldungen.",
    }
  }

  const [updated] = await db
    .update(reports)
    .set({
      deletedAt: new Date(),
      deletedBy: userId,
      deleteReason: "Manuell ausgeblendet",
      updatedAt: new Date(),
    })
    .where(
      and(eq(reports.id, parsed.data.reportId), isNull(reports.deletedAt))
    )
    .returning({ id: reports.id, organizationId: reports.organizationId, shortDescription: reports.shortDescription })

  if (!updated) {
    return {
      success: false,
      message: "Meldung wurde nicht gefunden oder ist bereits ausgeblendet.",
    }
  }

  revalidatePath(`/dashboard/reports/${parsed.data.reportId}`)
  revalidatePath("/dashboard/reports")
  revalidatePath("/dashboard/reports/trash")
  revalidatePath("/dashboard")

  await logAuditEvent({
    organizationId: updated.organizationId,
    clerkUserId: userId,
    action: "REPORT_SOFT_DELETED",
    resourceType: "report",
    resourceId: updated.id,
    changes: {
      shortDescription: updated.shortDescription,
      deletedAt: new Date().toISOString(),
      deletedBy: userId,
      deleteReason: "Manuell ausgeblendet",
    },
  })

  redirect("/dashboard/reports")
}

export type RestoreReportState = {
  success: boolean
  message: string
}

export async function restoreReport(
  _: RestoreReportState,
  formData: FormData
): Promise<RestoreReportState> {
  const parsed = restoreReportSchema.safeParse({
    reportId: formData.get("reportId"),
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()
  if (!userId) {
    return {
      success: false,
      message: "Nicht angemeldet.",
    }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zum Wiederherstellen von Meldungen.",
    }
  }

  const [beforeRestore] = await db
    .select({
      organizationId: reports.organizationId,
      shortDescription: reports.shortDescription,
      deletedAt: reports.deletedAt,
      deletedBy: reports.deletedBy,
      deleteReason: reports.deleteReason,
    })
    .from(reports)
    .where(and(eq(reports.id, parsed.data.reportId), isNotNull(reports.deletedAt)))
    .limit(1)

  const [updated] = await db
    .update(reports)
    .set({
      deletedAt: null,
      deletedBy: null,
      deleteReason: null,
      updatedAt: new Date(),
    })
    .where(
      and(eq(reports.id, parsed.data.reportId), isNotNull(reports.deletedAt))
    )
    .returning({ id: reports.id })

  if (!updated) {
    return {
      success: false,
      message: "Meldung wurde nicht gefunden oder ist nicht ausgeblendet.",
    }
  }

  if (beforeRestore) {
    await logAuditEvent({
      organizationId: beforeRestore.organizationId,
      clerkUserId: userId,
      action: "REPORT_RESTORED",
      resourceType: "report",
      resourceId: parsed.data.reportId,
      changes: {
        shortDescription: beforeRestore.shortDescription,
        before: {
          deletedAt: beforeRestore.deletedAt?.toISOString() ?? null,
          deletedBy: beforeRestore.deletedBy,
          deleteReason: beforeRestore.deleteReason,
        },
        after: { deletedAt: null, deletedBy: null, deleteReason: null },
      },
    })
  }

  revalidatePath("/dashboard")
  revalidatePath("/dashboard/reports")
  revalidatePath("/dashboard/reports/trash")
  revalidatePath(`/dashboard/reports/${parsed.data.reportId}`)

  return {
    success: true,
    message: "Meldung wurde wiederhergestellt.",
  }
}

export type HardDeleteReportState = {
  success: boolean
  message: string
}

export async function hardDeleteReport(
  _: HardDeleteReportState,
  formData: FormData
): Promise<HardDeleteReportState> {
  const parsed = hardDeleteReportSchema.safeParse({
    reportId: formData.get("reportId"),
    confirmText: formData.get("confirmText"),
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()
  if (!userId) {
    return {
      success: false,
      message: "Nicht angemeldet.",
    }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zum endgültigen Löschen von Meldungen.",
    }
  }

  const reportId = parsed.data.reportId

  const [report] = await db
    .select({
      id: reports.id,
      organizationId: reports.organizationId,
      shortDescription: reports.shortDescription,
      status: reports.status,
      priority: reports.priority,
      deletedAt: reports.deletedAt,
    })
    .from(reports)
    .where(eq(reports.id, reportId))
    .limit(1)

  if (!report) {
    return {
      success: false,
      message: "Meldung wurde nicht gefunden.",
    }
  }

  if (report.deletedAt == null) {
    return {
      success: false,
      message:
        "Nur ausgeblendete Meldungen können aus dem Papierkorb endgültig gelöscht werden.",
    }
  }

  const attachmentRows = await db
    .select({ storageKey: attachments.storageKey })
    .from(attachments)
    .where(eq(attachments.reportId, reportId))

  // Vor dem Loeschen zaehlen, damit der Audit-Eintrag den Umfang traegt.
  // Bisher stand dort nur die Zahl der Anhaenge — nach dem Loeschen war nicht
  // mehr erkennbar, ob an der Meldung ueberhaupt gearbeitet worden war.
  // Bewusst nur Zahlen, keine Titel: Massnahmen- und Notiztexte sind Freitext
  // und koennen Personenbezug tragen.
  const [measureCountRow] = await db
    .select({ n: count() })
    .from(measures)
    .where(eq(measures.reportId, reportId))
  const [noteCountRow] = await db
    .select({ n: count() })
    .from(reportNotes)
    .where(eq(reportNotes.reportId, reportId))

  for (const row of attachmentRows) {
    try {
      // Fehlende Dateien behandelt die Storage-Schicht als No-op
      // (provider-neutral); nur echte Speicherfehler brechen hier ab.
      await deleteStoredFile(row.storageKey)
    } catch {
      return {
        success: false,
        message:
          "Die Datei im Speicher konnte nicht gelöscht werden. Bitte später erneut versuchen.",
      }
    }
  }

  try {
    await db.transaction(async (tx) => {
      await tx.delete(attachments).where(eq(attachments.reportId, reportId))
      await tx.delete(measures).where(eq(measures.reportId, reportId))
      await tx.delete(reportNotes).where(eq(reportNotes.reportId, reportId))
      // reportRetentionReviews bewusst NICHT geloescht: reportId hat dort
      // keinen Fremdschluessel/Cascade (siehe schema.ts), damit das
      // Pruefprotokoll auch nach einem Hard Delete erhalten bleibt.
      const removed = await tx
        .delete(reports)
        .where(and(eq(reports.id, reportId), isNotNull(reports.deletedAt)))
        .returning({ id: reports.id })

      if (removed.length === 0) {
        throw new Error("HARD_DELETE_REPORT_NOT_REMOVED")
      }
    })
  } catch {
    return {
      success: false,
      message:
        "Die Datenbankaktion ist fehlgeschlagen. Bitte erneut versuchen.",
    }
  }

  await logAuditEvent({
    organizationId: report.organizationId,
    clerkUserId: userId,
    action: "REPORT_HARD_DELETED",
    resourceType: "report",
    resourceId: reportId,
    changes: {
      shortDescription: report.shortDescription,
      status: report.status,
      priority: report.priority,
      deletedAt: report.deletedAt?.toISOString() ?? null,
      attachmentCount: attachmentRows.length,
      measureCount: measureCountRow?.n ?? 0,
      noteCount: noteCountRow?.n ?? 0,
    },
  })

  revalidatePath("/dashboard")
  revalidatePath("/dashboard/reports")
  revalidatePath("/dashboard/reports/trash")
  revalidatePath(`/dashboard/reports/${reportId}`)

  return {
    success: true,
    message: "Meldung wurde endgültig gelöscht.",
  }
}

export type AnonymizeReportState = {
  success: boolean
  message: string
}

/**
 * Manuelle, gepruefte Anonymisierung strukturierter Melderdaten.
 *
 * Erster kontrollierter Schritt Richtung spaeterer Anonymisierungsprozess:
 * - Es werden ausschliesslich die strukturierten Melderfelder
 *   (Name, Rolle, Kontakt) entfernt.
 * - Fachliche Report-Daten, Freitexte (z. B. detailedDescription) und Anhaenge
 *   bleiben unveraendert und muessen weiterhin manuell geprueft werden.
 * - Nur zulaessig fuer abgeschlossene Meldungen (Status "closed").
 * - Nur admin und safety_manager.
 * - Der Vorgang wird im Audit-Log dokumentiert (REPORT_ANONYMIZED). Es werden
 *   dabei keine Klartext-Melderdaten protokolliert.
 */
export async function anonymizeReport(
  _: AnonymizeReportState,
  formData: FormData
): Promise<AnonymizeReportState> {
  const rawNote = formData.get("note")
  const parsed = anonymizeReportSchema.safeParse({
    reportId: formData.get("reportId"),
    note: rawNote ? String(rawNote).trim() || undefined : undefined,
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()
  if (!userId) {
    return {
      success: false,
      message: "Nicht angemeldet.",
    }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zur Anonymisierung von Meldungen.",
    }
  }

  const [currentReport] = await db
    .select({
      organizationId: reports.organizationId,
      shortDescription: reports.shortDescription,
      status: reports.status,
      anonymizedAt: reports.anonymizedAt,
      reporterName: reports.reporterName,
      reporterRole: reports.reporterRole,
      reporterContact: reports.reporterContact,
    })
    .from(reports)
    .where(and(eq(reports.id, parsed.data.reportId), isNull(reports.deletedAt)))
    .limit(1)

  if (!currentReport) {
    return {
      success: false,
      message: "Meldung wurde nicht gefunden.",
    }
  }

  if (!isClosedOrHidden(currentReport.status)) {
    return {
      success: false,
      message:
        "Nur abgeschlossene oder ausgeblendete Meldungen können anonymisiert werden. Bitte die Meldung zuerst abschließen oder ausblenden.",
    }
  }

  if (currentReport.anonymizedAt) {
    return {
      success: false,
      message: "Die strukturierten Melderdaten wurden bereits anonymisiert.",
    }
  }

  // Nur protokollieren, WELCHE Felder Daten enthielten — niemals die Klartextwerte.
  const clearedFields = (
    [
      ["reporterName", currentReport.reporterName],
      ["reporterRole", currentReport.reporterRole],
      ["reporterContact", currentReport.reporterContact],
    ] as const
  )
    .filter(([, value]) => Boolean(value))
    .map(([key]) => key)

  // Reporterfelder nullen, bestehende Audit-Log-Klartext-Reste dieses
  // Reports redigieren und den REPORT_ANONYMIZED-Nachweis schreiben laufen
  // atomar in einer Transaktion: entweder gelingt alles zusammen, oder
  // nichts davon — kein Zwischenzustand "anonymisiert, aber Audit-Log noch
  // im Klartext".
  let redactedAuditLogEntries = 0
  try {
    await db.transaction(async (tx) => {
      const [updated] = await tx
        .update(reports)
        .set({
          reporterName: null,
          reporterRole: null,
          reporterContact: null,
          isAnonymous: true,
          anonymizedAt: new Date(),
          anonymizedBy: userId,
          anonymizationNote: parsed.data.note ?? null,
          // "partial": strukturierte Melderdaten entfernt, Freitexte/Anhaenge offen.
          anonymizationStatus: "partial",
          updatedAt: new Date(),
        })
        .where(
          and(eq(reports.id, parsed.data.reportId), isNull(reports.deletedAt))
        )
        .returning({ id: reports.id })

      if (!updated) {
        throw new Error("ANONYMIZE_REPORT_NOT_FOUND")
      }

      redactedAuditLogEntries = await redactReportAuditLogEntries(
        tx,
        parsed.data.reportId
      )

      await logAuditEvent(
        {
          organizationId: currentReport.organizationId,
          clerkUserId: userId,
          action: "REPORT_ANONYMIZED",
          resourceType: "report",
          resourceId: parsed.data.reportId,
          changes: {
            shortDescription: currentReport.shortDescription,
            anonymizationStatus: "partial",
            clearedFields,
            note: parsed.data.note ?? null,
            redactedAuditLogEntries,
          },
        },
        tx
      )
    })
  } catch (error) {
    if (error instanceof Error && error.message === "ANONYMIZE_REPORT_NOT_FOUND") {
      return {
        success: false,
        message: "Meldung wurde nicht gefunden.",
      }
    }
    return {
      success: false,
      message: "Die Datenbankaktion ist fehlgeschlagen. Bitte erneut versuchen.",
    }
  }

  revalidatePath(`/dashboard/reports/${parsed.data.reportId}`)
  revalidatePath("/dashboard/reports")
  revalidatePath("/dashboard")

  return {
    success: true,
    message:
      "Strukturierte Melderdaten wurden anonymisiert. Freitexte und Anhänge bleiben manuell zu prüfen.",
  }
}

export type LogRetentionReviewState = {
  success: boolean
  message: string
}

/**
 * Dokumentiert eine bewusste Entscheidung im Rahmen der periodischen
 * Aufbewahrungspruefung ("geprueft/keine Aktion", "zurueckgestellt",
 * "anonymisiert", "geloescht"). Reine Dokumentation — loescht/anonymisiert
 * selbst nichts; die eigentlichen Aktionen laufen weiterhin ueber
 * anonymizeReport/softDeleteReport/hardDeleteReport (kein neuer Lösch-/
 * Anonymisierungspfad). Nur für Reports mit gesetztem Retention-Review-Anker
 * (geschlossen/ausgeblendet) und nur, wenn die Organisation ein
 * Prüfintervall konfiguriert hat — sonst gäbe es kein sinnvoll berechenbares
 * Fälligkeitsdatum zu protokollieren.
 */
export async function logRetentionReview(
  _: LogRetentionReviewState,
  formData: FormData
): Promise<LogRetentionReviewState> {
  const rawReason = formData.get("reason")
  const parsed = logRetentionReviewSchema.safeParse({
    reportId: formData.get("reportId"),
    decision: formData.get("decision"),
    reason: rawReason ? String(rawReason).trim() || undefined : undefined,
    postponedUntil: formData.get("postponedUntil"),
    confirmNoPersonalData: formData.get("confirmNoPersonalData"),
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()
  if (!userId) {
    return { success: false, message: "Nicht angemeldet." }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zur Dokumentation von Datenschutzpruefungen.",
    }
  }

  const [currentReport] = await db
    .select({
      organizationId: reports.organizationId,
      reportType: reports.reportType,
      retentionReviewEligibleAt: reports.retentionReviewEligibleAt,
      anonymizedAt: reports.anonymizedAt,
      deletedAt: reports.deletedAt,
    })
    .from(reports)
    .where(eq(reports.id, parsed.data.reportId))
    .limit(1)

  if (!currentReport) {
    return {
      success: false,
      message: "Meldung wurde nicht gefunden.",
    }
  }

  if (!currentReport.retentionReviewEligibleAt) {
    return {
      success: false,
      message:
        "Meldung ist nicht für eine Datenschutzprüfung fällig (noch nicht abgeschlossen oder ausgeblendet).",
    }
  }

  const [organization] = await db
    .select({
      reportRetentionReviewIntervalMonths:
        organizations.reportRetentionReviewIntervalMonths,
    })
    .from(organizations)
    .where(eq(organizations.id, currentReport.organizationId))
    .limit(1)

  const intervalMonths = organization?.reportRetentionReviewIntervalMonths ?? null
  if (!intervalMonths) {
    return {
      success: false,
      message:
        "Pruefintervall ist nicht konfiguriert. Bitte zuerst unter Einstellungen festlegen.",
    }
  }

  if (parsed.data.decision === "anonymized" && !currentReport.anonymizedAt) {
    return {
      success: false,
      message:
        "Melderdaten wurden noch nicht anonymisiert. Bitte zuerst über die Anonymisierungsfunktion anonymisieren.",
    }
  }

  if (parsed.data.decision === "deleted" && !currentReport.deletedAt) {
    return {
      success: false,
      message: "Meldung wurde noch nicht gelöscht. Bitte zuerst über den Papierkorb löschen.",
    }
  }

  const computedDueAt = computeRetentionReviewDueAt(
    currentReport.retentionReviewEligibleAt,
    intervalMonths
  )
  if (!computedDueAt) {
    // Kann bei obigen Guards (Anker + Intervall bereits geprueft) nicht
    // eintreten — defensiver Schutz gegen die NOT-NULL-Spalte.
    return {
      success: false,
      message: "Fälligkeitsdatum konnte nicht berechnet werden.",
    }
  }

  const postponedUntilDate =
    parsed.data.decision === "postponed" ? parsed.data.postponedUntil ?? null : null

  // Nur bei "anonymisiert" + explizit bestaetigtem Personenbezugs-Check wird
  // anonymizationStatus wirklich auf "completed" gesetzt — die Auswahl der
  // Entscheidung allein reicht nicht (siehe Schema-Refine oben, das in
  // diesem Fall bereits `reason` als Pruefvermerk verpflichtend macht).
  const marksFullyAnonymized =
    parsed.data.decision === "anonymized" && parsed.data.confirmNoPersonalData

  try {
    await db.transaction(async (tx) => {
      const [inserted] = await tx
        .insert(reportRetentionReviews)
        .values({
          reportId: parsed.data.reportId,
          organizationId: currentReport.organizationId,
          reportType: currentReport.reportType,
          decision: parsed.data.decision,
          reason: parsed.data.reason ?? null,
          postponedUntil: postponedUntilDate,
          computedDueAt,
          reviewedByClerkUserId: userId,
        })
        .returning({ id: reportRetentionReviews.id })

      if (!inserted) {
        throw new Error("LOG_RETENTION_REVIEW_INSERT_FAILED")
      }

      if (marksFullyAnonymized) {
        await tx
          .update(reports)
          .set({ anonymizationStatus: "completed" })
          .where(eq(reports.id, parsed.data.reportId))
      }

      await logAuditEvent(
        {
          organizationId: currentReport.organizationId,
          clerkUserId: userId,
          action: "REPORT_RETENTION_REVIEWED",
          resourceType: "report",
          resourceId: parsed.data.reportId,
          changes: {
            decision: parsed.data.decision,
            hasReason: Boolean(parsed.data.reason),
            postponedUntil: postponedUntilDate,
            confirmedFullyAnonymized: marksFullyAnonymized,
          },
        },
        tx
      )
    })
  } catch {
    return {
      success: false,
      message: "Die Datenbankaktion ist fehlgeschlagen. Bitte erneut versuchen.",
    }
  }

  revalidatePath(`/dashboard/reports/${parsed.data.reportId}`)

  return {
    success: true,
    message: marksFullyAnonymized
      ? "Datenschutzprüfung wurde dokumentiert. Die Meldung gilt als vollständig geprueft."
      : "Datenschutzprüfung wurde dokumentiert.",
  }
}
