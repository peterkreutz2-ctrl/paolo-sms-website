"use server"

import { appAuth } from "@/lib/auth"
import { eq } from "drizzle-orm"
import { revalidatePath } from "next/cache"

import { logAuditEvent } from "@/lib/audit"
import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { hasSafetyEditRole } from "@/lib/constants/roles"
import { db } from "@/lib/db"
import { organizations, privacyIncidents } from "@/lib/db/schema"
import {
  createPrivacyIncidentSchema,
  updatePrivacyIncidentSchema,
} from "@/lib/validations/privacy-incident"

export type PrivacyIncidentActionState = {
  success: boolean
  message: string
}

const INCIDENTS_PATH = "/dashboard/privacy/incidents"

export async function createPrivacyIncident(
  _: PrivacyIncidentActionState,
  formData: FormData
): Promise<PrivacyIncidentActionState> {
  const toOpt = (v: FormDataEntryValue | null): string | undefined => {
    const s = v ? String(v).trim() : ""
    return s.length > 0 ? s : undefined
  }

  const parsed = createPrivacyIncidentSchema.safeParse({
    title: formData.get("title"),
    discoveredAt: toOpt(formData.get("discoveredAt")),
    discoveredByText: toOpt(formData.get("discoveredByText")),
    description: formData.get("description"),
    affectedDataCategories: toOpt(formData.get("affectedDataCategories")),
    affectedPersonsEstimate: toOpt(formData.get("affectedPersonsEstimate")),
    immediateActions: toOpt(formData.get("immediateActions")),
    riskAssessment: formData.get("riskAssessment") ?? undefined,
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()
  if (!userId) {
    return { success: false, message: "Nicht angemeldet." }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zum Erfassen von Datenschutzvorfällen.",
    }
  }

  const [organization] = await db.select().from(organizations).limit(1)
  if (!organization) {
    return { success: false, message: "Organisation nicht gefunden." }
  }

  const discoveredAt = parsed.data.discoveredAt
    ? new Date(parsed.data.discoveredAt)
    : null

  const [incident] = await db
    .insert(privacyIncidents)
    .values({
      organizationId: organization.id,
      title: parsed.data.title,
      status: "new",
      discoveredAt,
      discoveredByText: parsed.data.discoveredByText ?? null,
      description: parsed.data.description,
      affectedDataCategories: parsed.data.affectedDataCategories ?? null,
      affectedPersonsEstimate: parsed.data.affectedPersonsEstimate ?? null,
      immediateActions: parsed.data.immediateActions ?? null,
      riskAssessment: parsed.data.riskAssessment,
      notificationDecision: "open",
    })
    .returning({ id: privacyIncidents.id })

  if (!incident) {
    return { success: false, message: "Vorfall konnte nicht gespeichert werden." }
  }

  await logAuditEvent({
    organizationId: organization.id,
    clerkUserId: userId,
    action: "PRIVACY_INCIDENT_CREATED",
    resourceType: "privacy_incident",
    resourceId: incident.id,
    changes: {
      title: parsed.data.title,
      status: "new",
      riskAssessment: parsed.data.riskAssessment,
    },
  })

  revalidatePath(INCIDENTS_PATH)

  return { success: true, message: "Datenschutzvorfall wurde erfasst." }
}

export async function updatePrivacyIncident(
  _: PrivacyIncidentActionState,
  formData: FormData
): Promise<PrivacyIncidentActionState> {
  const toOpt = (v: FormDataEntryValue | null): string | undefined => {
    const s = v ? String(v).trim() : ""
    return s.length > 0 ? s : undefined
  }

  const parsed = updatePrivacyIncidentSchema.safeParse({
    incidentId: formData.get("incidentId"),
    status: formData.get("status"),
    riskAssessment: formData.get("riskAssessment"),
    notificationDecision: formData.get("notificationDecision"),
    decisionReason: toOpt(formData.get("decisionReason")),
    followUpActions: toOpt(formData.get("followUpActions")),
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()
  if (!userId) {
    return { success: false, message: "Nicht angemeldet." }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zum Bearbeiten von Datenschutzvorfällen.",
    }
  }

  const [current] = await db
    .select({
      organizationId: privacyIncidents.organizationId,
      title: privacyIncidents.title,
      status: privacyIncidents.status,
      closedAt: privacyIncidents.closedAt,
    })
    .from(privacyIncidents)
    .where(eq(privacyIncidents.id, parsed.data.incidentId))
    .limit(1)

  if (!current) {
    return { success: false, message: "Vorfall wurde nicht gefunden." }
  }

  // closedAt setzen, wenn abgeschlossen; bei Wiederöffnung zurücksetzen.
  const closedAt =
    parsed.data.status === "closed" ? current.closedAt ?? new Date() : null

  const [updated] = await db
    .update(privacyIncidents)
    .set({
      status: parsed.data.status,
      riskAssessment: parsed.data.riskAssessment,
      notificationDecision: parsed.data.notificationDecision,
      decisionReason: parsed.data.decisionReason ?? null,
      followUpActions: parsed.data.followUpActions ?? null,
      closedAt,
      updatedAt: new Date(),
    })
    .where(eq(privacyIncidents.id, parsed.data.incidentId))
    .returning({ id: privacyIncidents.id })

  if (!updated) {
    return { success: false, message: "Vorfall wurde nicht gefunden." }
  }

  await logAuditEvent({
    organizationId: current.organizationId,
    clerkUserId: userId,
    action: "PRIVACY_INCIDENT_UPDATED",
    resourceType: "privacy_incident",
    resourceId: parsed.data.incidentId,
    changes: {
      title: current.title,
      old: { status: current.status },
      new: {
        status: parsed.data.status,
        riskAssessment: parsed.data.riskAssessment,
        notificationDecision: parsed.data.notificationDecision,
      },
    },
  })

  revalidatePath(INCIDENTS_PATH)

  return { success: true, message: "Datenschutzvorfall wurde aktualisiert." }
}
