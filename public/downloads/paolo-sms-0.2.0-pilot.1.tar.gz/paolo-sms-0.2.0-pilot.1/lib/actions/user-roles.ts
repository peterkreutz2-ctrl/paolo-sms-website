"use server"

import { appAuth, usesBetterAuth, usesFileAuth } from "@/lib/auth"
import { createDirectoryAccessLink, createDirectorySignInUrl, createDirectoryUser, FILE_USER_MANAGEMENT_MESSAGE, deleteClerkAccount, findLiveAccountIds, getDirectoryUser, listDirectoryUsers, updateClerkAccountName } from "@/lib/auth/user-directory"
import { and, eq, isNull } from "drizzle-orm"
import { revalidatePath } from "next/cache"

import { accountAuditResourceId } from "@/lib/auth/access-link"
import {
  changedAccountFields,
  decideAccountDeletion,
  DELETION_REFUSAL_MESSAGES,
  normalizeTargetRoles,
  runProviderFirstDeletion,
  validateAccountData,
} from "@/lib/auth/account-lifecycle"
import {
  AccountChangeRefused,
  deleteBetterAuthAccount,
  deleteRoleAssignments,
  isUniqueViolation,
  readAccountRoleKeys,
  updateBetterAuthAccount,
} from "@/lib/auth/account-lifecycle-db"
import { ADMIN_CHANGE_REFUSAL_MESSAGES } from "@/lib/auth/admin-invariant"
import {
  AdminChangeRefused,
  guardAdminRoleChange,
  readGlobalAdminIds,
} from "@/lib/auth/admin-role-lock"
import { logAuditEvent } from "@/lib/audit"
import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import {
  canAssignRole,
  canManageAccountAccess,
  canManageRoles,
  canManageTargetUser,
  canRemoveRole,
  isAppRoleKey,
  wouldLeaveUserWithoutRole,
} from "@/lib/constants/roles"
import { db } from "@/lib/db"
import { organizations, roles, userRoles } from "@/lib/db/schema"
import { demoBlockedResult, isDemoMode } from "@/lib/demo/mode"

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

async function loadTargetCurrentRoles(clerkUserId: string) {
  const rows = await db
    .select({ roleKey: roles.key })
    .from(userRoles)
    .innerJoin(roles, eq(userRoles.roleId, roles.id))
    .where(and(eq(userRoles.clerkUserId, clerkUserId), isNull(userRoles.organizationId)))
  return rows.map((r) => r.roleKey).filter(isAppRoleKey)
}

// Schnappschuss der Administratorkonten, die im Verzeichnis existieren — VOR
// der Transaktion, weil es ein Netzwerkaufruf ist. `null`: Verzeichnis nicht
// erreichbar. Die eigentliche Pruefung (Sperre, frisches Lesen) macht
// guardAdminRoleChange in der Transaktion; siehe lib/auth/admin-role-lock.ts.
async function snapshotLiveAdminIds(): Promise<Set<string> | null> {
  return findLiveAccountIds(await readGlobalAdminIds(db))
}

function adminRefusalResult(error: unknown): UserRoleActionState | null {
  if (!(error instanceof AdminChangeRefused)) return null
  return { success: false, message: ADMIN_CHANGE_REFUSAL_MESSAGES[error.reason] }
}

export type UserRoleActionState = {
  success: boolean
  message: string
  // Zugangsschluessel — nur in der Antwort, nie gespeichert, geloggt oder auditiert.
  signInUrl?: string
  // „sign-in“: Clerk-Anmeldelink. „password“: Better-Auth-Link zum Festlegen eines Passworts.
  linkKind?: "sign-in" | "password"
}

export async function assignRole(
  _: UserRoleActionState,
  formData: FormData
): Promise<UserRoleActionState> {
  if (isDemoMode()) return demoBlockedResult("accounts")
  if (usesFileAuth()) return { success: false, message: FILE_USER_MANAGEMENT_MESSAGE }
  const { userId } = await appAuth()
  if (!userId) {
    return { success: false, message: "Nicht angemeldet." }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!canManageRoles(roleKeys)) {
    return { success: false, message: "Keine Berechtigung." }
  }

  const clerkUserId = formData.get("clerkUserId")
  const roleKey = formData.get("roleKey")

  if (typeof clerkUserId !== "string" || !clerkUserId.trim()) {
    return { success: false, message: "Ungültige Konto-Kennung." }
  }

  if (typeof roleKey !== "string" || !isAppRoleKey(roleKey)) {
    return { success: false, message: "Ungültige Rolle." }
  }

  const targetId = clerkUserId.trim()

  // Load target's current roles — needed for permission checks and audit trail
  const targetRoleKeys = await loadTargetCurrentRoles(targetId)

  // Check: can actor manage this target user?
  if (!canManageTargetUser(roleKeys, targetRoleKeys)) {
    return { success: false, message: "Keine Berechtigung, diesen Benutzer zu verwalten." }
  }

  // Check: can actor remove the target's current role(s)?
  for (const currentRole of targetRoleKeys) {
    if (!canRemoveRole(roleKeys, currentRole)) {
      return { success: false, message: "Keine Berechtigung, die aktuelle Rolle dieses Benutzers zu entfernen." }
    }
  }

  // Check: can actor assign the new role?
  if (!canAssignRole(roleKeys, roleKey)) {
    return { success: false, message: "Keine Berechtigung, diese Rolle zu vergeben." }
  }

  const [role] = await db
    .select({ id: roles.id })
    .from(roles)
    .where(eq(roles.key, roleKey))
    .limit(1)

  if (!role) {
    return { success: false, message: "Rolle nicht in der Datenbank gefunden." }
  }

  const [organization] = await db
    .select({ id: organizations.id })
    .from(organizations)
    .limit(1)

  const previousRoleKey = targetRoleKeys[0] ?? null

  // Letzter-Administrator-Schutz: Der Schnappschuss der lebenden Konten wird
  // nur gebraucht, wenn die Administratorrolle wegfaellt. Die Pruefung selbst
  // laeuft in der Transaktion unter Sperre, auf frisch gelesenem Stand — und
  // zwar immer, damit auch eine zwischenzeitlich erteilte Administratorrolle
  // nicht an der Pruefung vorbei entzogen werden kann.
  const liveAdminIds =
    targetRoleKeys.includes("admin") && roleKey !== "admin"
      ? await snapshotLiveAdminIds()
      : new Set<string>()

  // Ein Rollenwechsel ist Loeschen PLUS Einfuegen (genau eine globale Rolle je
  // Benutzer). Beides zusammen mit dem Audit-Eintrag in EINER Transaktion:
  // Ohne die Klammer machte ein fehlgeschlagenes Insert aus dem Wechsel einen
  // ersatzlosen Entzug — der Benutzer stand danach ohne Rolle da, waehrend die
  // Meldung nur von einem Fehler sprach.
  try {
    await db.transaction(async (tx) => {
      await guardAdminRoleChange(tx, {
        targetId,
        targetStaysAdmin: roleKey === "admin",
        liveAccountIds: liveAdminIds,
      })

      await tx
        .delete(userRoles)
        .where(
          and(
            eq(userRoles.clerkUserId, targetId),
            isNull(userRoles.organizationId)
          )
        )

      const [newRow] = await tx
        .insert(userRoles)
        .values({ clerkUserId: targetId, roleId: role.id })
        .returning({ id: userRoles.id })

      if (!newRow) throw new Error("role-insert-failed")

      if (organization) {
        await logAuditEvent(
          {
            organizationId: organization.id,
            clerkUserId: userId,
            action: "ROLE_ASSIGNED",
            resourceType: "user_role",
            resourceId: newRow.id,
            changes: {
              targetClerkUserId: targetId,
              previousRoleKey,
              newRoleKey: roleKey,
            },
          },
          tx
        )
      }
    })
  } catch (error) {
    const refusal = adminRefusalResult(error)
    if (refusal) return refusal
    console.error("[user-roles] Rollenzuweisung fehlgeschlagen:", error)
    return {
      success: false,
      message:
        "Fehler beim Zuweisen der Rolle. Die bisherige Rolle bleibt unverändert bestehen.",
    }
  }

  revalidatePath("/dashboard/users")
  return { success: true, message: "Rolle erfolgreich zugewiesen." }
}

export async function removeRole(
  _: UserRoleActionState,
  formData: FormData
): Promise<UserRoleActionState> {
  if (isDemoMode()) return demoBlockedResult("accounts")
  if (usesFileAuth()) return { success: false, message: FILE_USER_MANAGEMENT_MESSAGE }
  const { userId } = await appAuth()
  if (!userId) {
    return { success: false, message: "Nicht angemeldet." }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!canManageRoles(roleKeys)) {
    return { success: false, message: "Keine Berechtigung." }
  }

  const userRoleId = formData.get("userRoleId")
  if (typeof userRoleId !== "string" || !userRoleId.trim()) {
    return { success: false, message: "Ungültige Rollen-ID." }
  }

  const [row] = await db
    .select({
      id: userRoles.id,
      clerkUserId: userRoles.clerkUserId,
      roleKey: roles.key,
    })
    .from(userRoles)
    .innerJoin(roles, eq(userRoles.roleId, roles.id))
    .where(eq(userRoles.id, userRoleId.trim()))
    .limit(1)

  if (!row) {
    return { success: false, message: "Zuweisung nicht gefunden." }
  }

  if (!isAppRoleKey(row.roleKey)) {
    return { success: false, message: "Ungültige Rolle in der Datenbank." }
  }

  // Check: can actor manage this target user?
  if (!canManageTargetUser(roleKeys, [row.roleKey])) {
    return { success: false, message: "Keine Berechtigung, diesen Benutzer zu verwalten." }
  }

  // Check: can actor remove this specific role?
  if (!canRemoveRole(roleKeys, row.roleKey)) {
    return { success: false, message: "Keine Berechtigung, diese Rolle zu entfernen." }
  }

  // Schutz der letzten Rolle — unabhaengig vom Last-Admin-Schutz oben. Der
  // ersatzlose Entzug waere eine Deaktivierung durch die Hintertuer, fuer die
  // es in PAOLO kein Konzept gibt (Konten sperrt der Auth-Provider), und er
  // entzoege seit der Stufe `members` still Leserechte auf /communications.
  // Ein Rollenwechsel bleibt moeglich; der laeuft ueber assignRole.
  const targetCurrentRoles = await loadTargetCurrentRoles(row.clerkUserId)
  if (wouldLeaveUserWithoutRole(targetCurrentRoles, row.roleKey)) {
    return {
      success: false,
      message:
        "Das ist die einzige Rolle dieses Benutzers und kann nicht ersatzlos entfernt werden — das Konto bliebe angemeldet, aber ohne jeden Zugang. Stattdessen eine andere Rolle zuweisen, oder das Konto beim Anmeldedienst deaktivieren.",
    }
  }

  // Fetch org for audit trail
  const [organization] = await db
    .select({ id: organizations.id })
    .from(organizations)
    .limit(1)

  // Letzter-Administrator-Schutz, siehe assignRole: Schnappschuss vor der
  // Transaktion, Pruefung darin unter Sperre.
  const liveAdminIds =
    row.roleKey === "admin" ? await snapshotLiveAdminIds() : new Set<string>()

  // Loeschung und Audit atomar: keine Rollenaenderung ohne Audit-Eintrag.
  try {
    await db.transaction(async (tx) => {
      await guardAdminRoleChange(tx, {
        targetId: row.clerkUserId,
        targetStaysAdmin: false,
        liveAccountIds: liveAdminIds,
      })

      await tx.delete(userRoles).where(eq(userRoles.id, userRoleId.trim()))

      if (organization) {
        await logAuditEvent(
          {
            organizationId: organization.id,
            clerkUserId: userId,
            action: "ROLE_REMOVED",
            resourceType: "user_role",
            resourceId: userRoleId.trim(),
            changes: {
              targetClerkUserId: row.clerkUserId,
              removedRoleKey: row.roleKey,
            },
          },
          tx
        )
      }
    })
  } catch (error) {
    const refusal = adminRefusalResult(error)
    if (refusal) return refusal
    console.error("[user-roles] Rollenentzug fehlgeschlagen:", error)
    return {
      success: false,
      message:
        "Die Rolle konnte nicht entfernt werden. Es wurde nichts geändert — bitte erneut versuchen.",
    }
  }

  revalidatePath("/dashboard/users")
  return { success: true, message: "Rolle wurde entfernt." }
}

// Entfernt eine Rolle, deren Konto beim Anmeldedienst nicht mehr existiert.
//
// Das ist KEIN Weg an removeRole vorbei: Dort ist der Entzug der letzten Rolle
// gesperrt, weil das Konto sonst angemeldet, aber ohne Zugang bliebe. Bei einem
// nicht mehr vorhandenen Konto gibt es nichts, das angemeldet bliebe — der
// Eintrag ist nur noch Rest. Deshalb gilt hier statt des Letzte-Rolle-Schutzes
// der Nachweis, dass das Konto wirklich fehlt; ist das Verzeichnis nicht
// erreichbar, wird nichts bereinigt.
//
// Der Letzter-Administrator-Schutz ist hier nicht noetig: Ein verwaister
// Administrator zaehlt ohnehin nicht als funktionsfaehig, und wer diese Aktion
// ausfuehrt, ist selbst ein existierendes Konto. Die Rechte folgen der Rolle
// des Eintrags wie bei removeRole.
export async function removeOrphanedRole(
  _: UserRoleActionState,
  formData: FormData
): Promise<UserRoleActionState> {
  if (isDemoMode()) return demoBlockedResult("accounts")
  if (usesFileAuth()) return { success: false, message: FILE_USER_MANAGEMENT_MESSAGE }
  const { userId } = await appAuth()
  if (!userId) return { success: false, message: "Nicht angemeldet." }

  const roleKeys = await getCurrentUserRoles()
  if (!canManageRoles(roleKeys)) return { success: false, message: "Keine Berechtigung." }

  const userRoleId = formData.get("userRoleId")
  if (typeof userRoleId !== "string" || !userRoleId.trim()) {
    return { success: false, message: "Ungültige Rollen-ID." }
  }

  const [row] = await db
    .select({
      id: userRoles.id,
      clerkUserId: userRoles.clerkUserId,
      roleKey: roles.key,
    })
    .from(userRoles)
    .innerJoin(roles, eq(userRoles.roleId, roles.id))
    .where(and(eq(userRoles.id, userRoleId.trim()), isNull(userRoles.organizationId)))
    .limit(1)

  if (!row) return { success: false, message: "Zuweisung nicht gefunden." }

  // Ein unbekannter Rollenwert wird wie die am staerksten geschuetzte Rolle
  // behandelt (siehe app/dashboard/users/page.tsx).
  if (isAppRoleKey(row.roleKey)) {
    if (!canManageTargetUser(roleKeys, [row.roleKey])) {
      return { success: false, message: "Keine Berechtigung, diesen Eintrag zu verwalten." }
    }
    if (!canRemoveRole(roleKeys, row.roleKey)) {
      return { success: false, message: "Keine Berechtigung, diese Rolle zu entfernen." }
    }
  } else if (!canManageTargetUser(roleKeys, ["admin"])) {
    return { success: false, message: "Keine Berechtigung, diesen Eintrag zu verwalten." }
  }

  const live = await findLiveAccountIds([row.clerkUserId])
  if (live === null) {
    return {
      success: false,
      message:
        "Die Kontenliste des Anmeldedienstes ist gerade nicht erreichbar. Ob das Konto noch existiert, lässt sich deshalb nicht prüfen — bitte später erneut versuchen.",
    }
  }
  if (live.has(row.clerkUserId)) {
    return {
      success: false,
      message:
        "Das Konto existiert noch. Eine Rolle lässt sich nur bereinigen, wenn das Konto fehlt — bitte die Rolle stattdessen ändern.",
    }
  }

  const [organization] = await db
    .select({ id: organizations.id })
    .from(organizations)
    .limit(1)

  try {
    await db.transaction(async (tx) => {
      await tx.delete(userRoles).where(eq(userRoles.id, row.id))

      if (organization) {
        await logAuditEvent(
          {
            organizationId: organization.id,
            clerkUserId: userId,
            action: "ROLE_REMOVED",
            resourceType: "user_role",
            resourceId: row.id,
            changes: {
              targetClerkUserId: row.clerkUserId,
              removedRoleKey: row.roleKey,
              orphaned: true,
            },
          },
          tx
        )
      }
    })
  } catch (error) {
    console.error("[user-roles] Bereinigung einer verwaisten Rolle fehlgeschlagen:", error)
    return {
      success: false,
      message:
        "Die verwaiste Rolle konnte nicht bereinigt werden. Es wurde nichts geändert — bitte erneut versuchen.",
    }
  }

  revalidatePath("/dashboard/users")
  return { success: true, message: "Verwaiste Rolle wurde bereinigt." }
}

export async function createUserWithRole(
  _: UserRoleActionState,
  formData: FormData
): Promise<UserRoleActionState> {
  if (isDemoMode()) return demoBlockedResult("accounts")
  if (usesFileAuth()) return { success: false, message: FILE_USER_MANAGEMENT_MESSAGE }
  const { userId } = await appAuth()
  if (!userId) return { success: false, message: "Nicht angemeldet." }

  const roleKeys = await getCurrentUserRoles()
  if (!canManageRoles(roleKeys)) return { success: false, message: "Keine Berechtigung." }

  const email = (formData.get("email") as string | null)?.trim().toLowerCase() ?? ""
  const name = (formData.get("name") as string | null)?.trim() ?? ""
  const password = (formData.get("password") as string | null) ?? ""
  const roleKey = formData.get("roleKey")

  if (!email || !EMAIL_RE.test(email)) {
    return { success: false, message: "Ungültige E-Mail-Adresse." }
  }

  if (usesBetterAuth() && (!name || password.length < 8)) {
    return { success: false, message: "Name und Passwort mit mindestens 8 Zeichen sind erforderlich." }
  }

  if (typeof roleKey !== "string" || !isAppRoleKey(roleKey)) {
    return { success: false, message: "Ungültige Rolle." }
  }

  if (!canAssignRole(roleKeys, roleKey)) {
    return { success: false, message: "Keine Berechtigung, diese Rolle zu vergeben." }
  }

  const [role] = await db
    .select({ id: roles.id })
    .from(roles)
    .where(eq(roles.key, roleKey))
    .limit(1)

  if (!role) return { success: false, message: "Rolle nicht in der Datenbank gefunden." }

  let clerkUserId: string
  let wasCreated = false
  let liveAdminIds: Set<string> | null = new Set<string>()

  try {
    const existing = await listDirectoryUsers({ email, limit: 1 })

    if (existing.length > 0) {
      clerkUserId = existing[0].id
    } else {
      const created = await createDirectoryUser({ email, name, password })
      clerkUserId = created.id
      wasCreated = true
    }
  } catch (error) {
    console.error("[user-roles] Anlegen im Verzeichnis fehlgeschlagen:", error)
    return { success: false, message: "Fehler beim Anlegen des Benutzers." }
  }

  // For existing users: check current roles before replacing them
  if (!wasCreated) {
    const targetRoleKeys = await loadTargetCurrentRoles(clerkUserId)

    if (!canManageTargetUser(roleKeys, targetRoleKeys)) {
      return { success: false, message: "Keine Berechtigung, diesen Benutzer zu verwalten." }
    }

    for (const currentRole of targetRoleKeys) {
      if (!canRemoveRole(roleKeys, currentRole)) {
        return { success: false, message: "Keine Berechtigung, die aktuelle Rolle dieses Benutzers zu entfernen." }
      }
    }

    // Letzter-Administrator-Schutz: siehe assignRole.
    if (targetRoleKeys.includes("admin") && roleKey !== "admin") {
      liveAdminIds = await snapshotLiveAdminIds()
    }
  }

  const [organization] = await db
    .select({ id: organizations.id })
    .from(organizations)
    .limit(1)

  // Rollenwechsel und Audit-Eintrag atomar — dieselbe Klammer wie in
  // assignRole. Der Audit-Eintrag fehlte hier bisher ganz: Ein ueber dieses
  // Formular angelegter Benutzer bekam seine Rolle ohne jede Spur im Log.
  //
  // NICHT in der Transaktion enthalten ist die Anlage im Directory
  // (Clerk bzw. Better Auth) weiter oben — die liegt ausserhalb der Datenbank
  // und laesst sich nicht zurueckrollen. Scheitert die Rollenzuweisung danach,
  // bleibt das Konto deshalb bestehen und ist rollenlos. Genau dafuer weist
  // /dashboard/users die Konten ohne Rolle gesondert aus; der Administrator
  // ist also nicht auf sein Gedaechtnis angewiesen.
  try {
    await db.transaction(async (tx) => {
      // Ein neu angelegtes Konto hat noch keine Rolle; die Pruefung betrifft
      // nur das Ersetzen der Rolle eines vorhandenen Kontos.
      if (!wasCreated) {
        await guardAdminRoleChange(tx, {
          targetId: clerkUserId,
          targetStaysAdmin: roleKey === "admin",
          liveAccountIds: liveAdminIds,
        })
      }

      await tx
        .delete(userRoles)
        .where(
          and(
            eq(userRoles.clerkUserId, clerkUserId),
            isNull(userRoles.organizationId)
          )
        )

      const [newRow] = await tx
        .insert(userRoles)
        .values({ clerkUserId, roleId: role.id })
        .returning({ id: userRoles.id })

      if (!newRow) throw new Error("role-insert-failed")

      if (organization) {
        await logAuditEvent(
          {
            organizationId: organization.id,
            clerkUserId: userId,
            action: "ROLE_ASSIGNED",
            resourceType: "user_role",
            resourceId: newRow.id,
            changes: {
              targetClerkUserId: clerkUserId,
              previousRoleKey: null,
              newRoleKey: roleKey,
              createdUser: wasCreated,
            },
          },
          tx
        )
      }
    })
  } catch (error) {
    const refusal = adminRefusalResult(error)
    if (refusal) return refusal
    console.error("[user-roles] Rollenzuweisung fehlgeschlagen:", error)
    return {
      success: false,
      message: wasCreated
        ? "Benutzer angelegt, Rollenzuweisung fehlgeschlagen — das Konto steht in der Liste mit dem Status „Ohne Rolle“ und braucht dort eine Zuweisung."
        : "Fehler beim Zuweisen der Rolle. Die bisherige Rolle bleibt unverändert bestehen.",
    }
  }

  if (!wasCreated) {
    revalidatePath("/dashboard/users")
    return {
      success: true,
      message: `Rolle zugewiesen. Benutzer war bereits vorhanden. (${email})`,
    }
  }

  if (usesBetterAuth()) {
    revalidatePath("/dashboard/users")
    return { success: true, message: `Neuer Benutzer angelegt und Rolle zugewiesen. (${email})` }
  }

  let signInUrl: string | undefined
  try {
    signInUrl = await createDirectorySignInUrl(clerkUserId)
  } catch {
    revalidatePath("/dashboard/users")
    return {
      success: false,
      message: `Benutzer und Rolle wurden angelegt, aber der Anmeldelink konnte nicht erzeugt werden. Bitte prüfen, ob Sign-in Tokens im Clerk Dashboard aktiviert sind.`,
    }
  }

  revalidatePath("/dashboard/users")
  return {
    success: true,
    message: `Neuer Benutzer angelegt und Rolle zugewiesen. (${email})`,
    signInUrl,
  }
}

// Anmeldelink erneuern (#111): Clerk ein neuer Sign-in-Link, Better Auth ein
// Link zum Festlegen eines neuen Passworts. Beide sieben Tage gueltig.
//
// Berechtigung: Faehigkeit `accounts.access` (Administrator, Safety Manager) UND
// Zustaendigkeitsbereich der Rollenverwaltung (`canManageTargetUser`), nie am
// eigenen Konto. Der Safety Assistant hat diese Aktion nicht.
//
// Der Link ist ein Zugangsschluessel. Er steht ausschliesslich in der Antwort
// dieser Aktion. Weder er noch das darin enthaltene Token werden geloggt oder in
// den Audit-Eintrag geschrieben; auditiert wird nur DASS und FUER WEN ein Link
// ausgestellt wurde. Scheitert der Audit-Eintrag, wird der Link nicht
// ausgeliefert — ein Link ohne Spur gibt es nicht.
export async function issueAccessLink(
  _: UserRoleActionState,
  formData: FormData
): Promise<UserRoleActionState> {
  if (isDemoMode()) return demoBlockedResult("accounts")
  if (usesFileAuth()) return { success: false, message: FILE_USER_MANAGEMENT_MESSAGE }
  const { userId } = await appAuth()
  if (!userId) return { success: false, message: "Nicht angemeldet." }

  const roleKeys = await getCurrentUserRoles()
  if (!canManageRoles(roleKeys)) return { success: false, message: "Keine Berechtigung." }

  const clerkUserId = formData.get("clerkUserId")
  if (typeof clerkUserId !== "string" || !clerkUserId.trim()) {
    return { success: false, message: "Ungültige Konto-Kennung." }
  }
  const targetId = clerkUserId.trim()

  // Ein unbekannter Rollenwert in der Datenbank gilt als die am staerksten
  // geschuetzte Rolle (siehe app/dashboard/users/page.tsx).
  const targetRows = await db
    .select({ roleKey: roles.key })
    .from(userRoles)
    .innerJoin(roles, eq(userRoles.roleId, roles.id))
    .where(and(eq(userRoles.clerkUserId, targetId), isNull(userRoles.organizationId)))
  const targetRoleKeys = targetRows.map((row) =>
    isAppRoleKey(row.roleKey) ? row.roleKey : ("admin" as const)
  )

  if (!canManageAccountAccess(roleKeys, targetRoleKeys, targetId === userId)) {
    return { success: false, message: "Keine Berechtigung, für dieses Konto einen Link zu erstellen." }
  }

  const live = await findLiveAccountIds([targetId])
  if (live === null) {
    return {
      success: false,
      message:
        "Die Kontenliste des Anmeldedienstes ist gerade nicht erreichbar. Der Link kann deshalb jetzt nicht erstellt werden — bitte später erneut versuchen.",
    }
  }
  if (!live.has(targetId)) {
    return { success: false, message: "Für diese Rolle gibt es kein Konto mehr. Bitte die Rolle bereinigen." }
  }

  let link: Awaited<ReturnType<typeof createDirectoryAccessLink>>
  try {
    link = await createDirectoryAccessLink(targetId)
  } catch (error) {
    // Nur der Fehlertyp und die Meldung, nie der Link.
    console.error("[user-roles] Link konnte nicht erstellt werden:", error instanceof Error ? error.message : "unbekannter Fehler")
    return {
      success: false,
      message:
        "Der Link konnte nicht erstellt werden. Bitte prüfen, ob der Anmeldedienst erreichbar ist und – bei Clerk – Sign-in-Tokens im Clerk Dashboard aktiviert sind.",
    }
  }

  const [organization] = await db
    .select({ id: organizations.id })
    .from(organizations)
    .limit(1)

  if (organization) {
    try {
      // Mit tx: Ein Fehler wird geworfen statt verschluckt (siehe logAuditEvent).
      await db.transaction(async (tx) => {
        await logAuditEvent(
          {
            organizationId: organization.id,
            clerkUserId: userId,
            action: "ACCESS_LINK_ISSUED",
            resourceType: "user_account",
            // audit_logs.resource_id ist eine UUID; Clerk-Kennungen sind keine.
            resourceId: accountAuditResourceId(targetId),
            changes: { targetClerkUserId: targetId, linkKind: link.kind },
          },
          tx
        )
      })
    } catch (error) {
      // Mit Ursache (Drizzle verpackt den Postgres-Fehler in `cause`), nie mit dem Link.
      console.error(
        "[user-roles] Audit-Eintrag zur Linkausstellung fehlgeschlagen:",
        error instanceof Error ? `${error.message} | Ursache: ${error.cause instanceof Error ? error.cause.message : "unbekannt"}` : "unbekannter Fehler"
      )
      return {
        success: false,
        message: "Der Audit-Eintrag konnte nicht geschrieben werden, deshalb wird der Link nicht angezeigt. Bitte erneut versuchen.",
      }
    }
  }

  return {
    success: true,
    message: link.kind === "password" ? "Link zum Festlegen eines Passworts erstellt." : "Anmeldelink erstellt.",
    signInUrl: link.url,
    linkKind: link.kind,
  }
}

// ─── Kontodaten ändern und Konto löschen (#114) ─────────────────────────────
//
// Gemeinsame Vorarbeit beider Aktionen: Ziel lesen, Zuständigkeit prüfen, das
// Konto im Verzeichnis finden. Die Rechte sind die der Zugangsaktionen
// (`accounts.access` UND Zuständigkeitsbereich der Rollenverwaltung, nie das
// eigene Konto). Der Safety Assistant erhält die Aktionen nicht.
type ManagedAccount = {
  targetId: string
  targetRoleKeys: ReturnType<typeof normalizeTargetRoles>
  account: NonNullable<Awaited<ReturnType<typeof getDirectoryUser>>>
}

async function resolveManagedAccount(
  formData: FormData,
  actorRoles: Parameters<typeof canManageAccountAccess>[0],
  actorId: string
): Promise<ManagedAccount | { error: UserRoleActionState }> {
  const raw = formData.get("clerkUserId")
  if (typeof raw !== "string" || !raw.trim()) {
    return { error: { success: false, message: "Ungültige Konto-Kennung." } }
  }
  const targetId = raw.trim()
  if (targetId === actorId) {
    return { error: { success: false, message: DELETION_REFUSAL_MESSAGES.self } }
  }

  const targetRoleKeys = normalizeTargetRoles(await readAccountRoleKeys(db, targetId))
  if (!canManageAccountAccess(actorRoles, targetRoleKeys, false)) {
    return { error: { success: false, message: "Keine Berechtigung, dieses Konto zu verwalten." } }
  }

  let account: ManagedAccount["account"] | null
  try {
    account = await getDirectoryUser(targetId)
  } catch {
    return {
      error: {
        success: false,
        message:
          "Die Kontenliste des Anmeldedienstes ist gerade nicht erreichbar. Bitte später erneut versuchen.",
      },
    }
  }
  if (!account) {
    return {
      error: {
        success: false,
        message: "Für diese Rolle gibt es kein Konto mehr. Bitte die Rolle bereinigen.",
      },
    }
  }
  return { targetId, targetRoleKeys, account }
}

// Name (Clerk und Better Auth) und E-Mail-Adresse (nur Better Auth) ändern. Bei
// Clerk bleibt die E-Mail-Änderung dem Benutzerprofil des Anbieters vorbehalten;
// die Aktion lehnt sie ab. Das eigene Konto ist ausgenommen (ein Tippfehler in der
// eigenen E-Mail-Adresse würde bei Better Auth die Anmeldung kosten).
//
// Audit: nur welche Felder sich geändert haben, nie Namen oder Adressen.
export async function updateAccountData(
  _: UserRoleActionState,
  formData: FormData
): Promise<UserRoleActionState> {
  if (isDemoMode()) return demoBlockedResult("accounts")
  if (usesFileAuth()) return { success: false, message: FILE_USER_MANAGEMENT_MESSAGE }
  const { userId } = await appAuth()
  if (!userId) return { success: false, message: "Nicht angemeldet." }

  const roleKeys = await getCurrentUserRoles()
  if (!canManageRoles(roleKeys)) return { success: false, message: "Keine Berechtigung." }

  const target = await resolveManagedAccount(formData, roleKeys, userId)
  if ("error" in target) return target.error
  const { targetId, account } = target

  const emailEditable = usesBetterAuth()
  const input = validateAccountData(
    { name: formData.get("name"), email: formData.get("email") },
    { emailEditable }
  )
  if (!input.ok) return { success: false, message: input.message }

  if (!emailEditable) {
    const submitted = String(formData.get("email") ?? "").trim().toLowerCase()
    if (submitted && submitted !== account.email.trim().toLowerCase()) {
      return {
        success: false,
        message: "E-Mail-Adressen werden bei Clerk im Benutzerprofil der Person geändert.",
      }
    }
  }

  const changedFields = changedAccountFields({
    currentName: account.displayName,
    currentEmail: account.email,
    name: input.name,
    email: input.email,
  })
  if (changedFields.length === 0) return { success: false, message: "Es gibt keine Änderung." }

  const [organization] = await db
    .select({ id: organizations.id })
    .from(organizations)
    .limit(1)

  const writeAudit = (tx: Parameters<typeof logAuditEvent>[1]) =>
    organization
      ? logAuditEvent(
          {
            organizationId: organization.id,
            clerkUserId: userId,
            action: "ACCOUNT_DATA_UPDATED",
            resourceType: "user_account",
            resourceId: accountAuditResourceId(targetId),
            changes: { targetClerkUserId: targetId, changedFields },
          },
          tx
        )
      : Promise.resolve()

  if (usesBetterAuth()) {
    try {
      await db.transaction(async (tx) => {
        await updateBetterAuthAccount(tx, targetId, {
          ...(changedFields.includes("name") ? { name: input.name } : {}),
          ...(changedFields.includes("email") && input.email ? { email: input.email } : {}),
        })
        await writeAudit(tx)
      })
    } catch (error) {
      if (isUniqueViolation(error)) {
        return { success: false, message: "Diese E-Mail-Adresse wird bereits verwendet." }
      }
      console.error("[user-roles] Kontodaten ändern fehlgeschlagen:", error instanceof Error ? error.message : "unbekannter Fehler")
      return { success: false, message: "Die Kontodaten konnten nicht geändert werden. Es wurde nichts geändert — bitte erneut versuchen." }
    }
  } else {
    try {
      await updateClerkAccountName(targetId, input.name)
    } catch (error) {
      console.error("[user-roles] Name bei Clerk ändern fehlgeschlagen:", error instanceof Error ? error.message : "unbekannter Fehler")
      return { success: false, message: "Der Name konnte beim Anmeldedienst nicht geändert werden. Es wurde nichts geändert — bitte erneut versuchen." }
    }
    try {
      await db.transaction(async (tx) => {
        await writeAudit(tx)
      })
    } catch (error) {
      console.error("[user-roles] Audit-Eintrag zur Namensänderung fehlgeschlagen:", error instanceof Error ? error.message : "unbekannter Fehler")
      return { success: false, message: "Der Name wurde geändert, der Audit-Eintrag konnte aber nicht geschrieben werden." }
    }
  }

  revalidatePath("/dashboard/users")
  return { success: true, message: "Kontodaten geändert." }
}

// Konto endgültig löschen — ohne vorherige Sperrung. Entfernt das Konto beim
// Anmeldedienst, seine Sitzungen und seine Rollenzuweisungen. Meldungen, Notizen,
// Besprechungen, SMS-Dokumente und Audit-Einträge bleiben unverändert; die Kennung
// darin wird weder ersetzt noch anonymisiert. DSGVO-Löschanträge laufen weiter über
// die bestehenden Datenschutzprozesse.
//
// Nie das eigene Konto, nie ein Konto mit Administratorrolle (die Rolle wird vorher
// regulär geändert, mit dem Letzter-Administrator-Schutz aus #109). Bestätigung:
// die vollständige E-Mail-Adresse des Kontos, serverseitig geprüft.
//
// Better Auth: Rollen, Konto (Sitzungen und Passwort per Kaskade) und Audit in einer
// Transaktion. Clerk: Rolle unmittelbar vor dem Anbieteraufruf erneut prüfen, dann
// Anbieter, dann Rollen und Audit (siehe runProviderFirstDeletion).
export async function deleteAccount(
  _: UserRoleActionState,
  formData: FormData
): Promise<UserRoleActionState> {
  if (isDemoMode()) return demoBlockedResult("accounts")
  if (usesFileAuth()) return { success: false, message: FILE_USER_MANAGEMENT_MESSAGE }
  const { userId } = await appAuth()
  if (!userId) return { success: false, message: "Nicht angemeldet." }

  const roleKeys = await getCurrentUserRoles()
  if (!canManageRoles(roleKeys)) return { success: false, message: "Keine Berechtigung." }

  const target = await resolveManagedAccount(formData, roleKeys, userId)
  if ("error" in target) return target.error
  const { targetId, targetRoleKeys, account } = target

  const decision = decideAccountDeletion({
    actorRoles: roleKeys,
    actorId: userId,
    targetId,
    targetRoles: targetRoleKeys,
    accountEmail: account.email,
    typedEmail: String(formData.get("confirmEmail") ?? ""),
  })
  if (!decision.ok) {
    return { success: false, message: DELETION_REFUSAL_MESSAGES[decision.reason] }
  }

  const [organization] = await db
    .select({ id: organizations.id })
    .from(organizations)
    .limit(1)

  const writeAudit = (tx: Parameters<typeof logAuditEvent>[1], previousRoleKey: string | null) =>
    organization
      ? logAuditEvent(
          {
            organizationId: organization.id,
            clerkUserId: userId,
            action: "ACCOUNT_DELETED",
            resourceType: "user_account",
            resourceId: accountAuditResourceId(targetId),
            // Weder Name noch E-Mail-Adresse: Die Kennung bleibt als Pseudonym.
            changes: { targetClerkUserId: targetId, previousRoleKey },
          },
          tx
        )
      : Promise.resolve()

  if (usesBetterAuth()) {
    try {
      await db.transaction(async (tx) => {
        const { previousRoleKeys } = await deleteBetterAuthAccount(tx, targetId)
        await writeAudit(tx, previousRoleKeys[0] ?? null)
      })
    } catch (error) {
      if (error instanceof AccountChangeRefused) {
        return {
          success: false,
          message:
            error.reason === "admin-role"
              ? DELETION_REFUSAL_MESSAGES["admin-role"]
              : "Für diese Rolle gibt es kein Konto mehr. Bitte die Rolle bereinigen.",
        }
      }
      console.error("[user-roles] Konto löschen fehlgeschlagen:", error instanceof Error ? error.message : "unbekannter Fehler")
      return { success: false, message: "Das Konto konnte nicht gelöscht werden. Es wurde nichts geändert — bitte erneut versuchen." }
    }
    revalidatePath("/dashboard/users")
    return { success: true, message: "Konto gelöscht." }
  }

  const outcome = await runProviderFirstDeletion({
    recheckNotAdmin: async () =>
      normalizeTargetRoles(await readAccountRoleKeys(db, targetId)).includes("admin")
        ? "admin"
        : "not-admin",
    deleteAtProvider: () => deleteClerkAccount(targetId),
    cleanupInDatabase: async () => {
      try {
        await db.transaction(async (tx) => {
          const previousRoleKeys = await deleteRoleAssignments(tx, targetId)
          await writeAudit(tx, previousRoleKeys[0] ?? null)
        })
      } catch (error) {
        console.error(
          "[user-roles] Konto beim Anmeldedienst gelöscht, Bereinigung in PAOLO fehlgeschlagen:",
          error instanceof Error ? error.message : "unbekannter Fehler"
        )
        throw error
      }
    },
  })
  revalidatePath("/dashboard/users")
  return { success: outcome.success, message: outcome.message }
}
