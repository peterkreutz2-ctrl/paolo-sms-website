"use server"

import { appAuth } from "@/lib/auth"
import { eq } from "drizzle-orm"
import { revalidatePath } from "next/cache"

import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { hasSafetyEditRole } from "@/lib/constants/roles"
import { db } from "@/lib/db"
import { organizationLegalSettings, organizations } from "@/lib/db/schema"
import {
  LEGAL_SETTINGS_FIELDS,
  legalSettingsSchema,
} from "@/lib/validations/legal-settings"
import { demoBlockedResult, isDemoMode } from "@/lib/demo/mode"

export type LegalSettingsActionState = {
  success: boolean
  message: string
}

export async function updateLegalSettings(
  _: LegalSettingsActionState,
  formData: FormData
): Promise<LegalSettingsActionState> {
  if (isDemoMode()) return demoBlockedResult("publication")
  const parsed = legalSettingsSchema.safeParse(
    Object.fromEntries(
      LEGAL_SETTINGS_FIELDS.map((key) => [key, formData.get(key) ?? ""])
    )
  )

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()
  if (!userId) {
    return { success: false, message: "Nicht angemeldet." }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return { success: false, message: "Keine Berechtigung." }
  }

  const [organization] = await db.select().from(organizations).limit(1)
  if (!organization) {
    return { success: false, message: "Organisation nicht gefunden." }
  }

  const [existing] = await db
    .select({ id: organizationLegalSettings.id })
    .from(organizationLegalSettings)
    .where(eq(organizationLegalSettings.organizationId, organization.id))
    .limit(1)

  if (existing) {
    await db
      .update(organizationLegalSettings)
      .set({ ...parsed.data, updatedAt: new Date() })
      .where(eq(organizationLegalSettings.id, existing.id))
  } else {
    await db.insert(organizationLegalSettings).values({
      organizationId: organization.id,
      ...parsed.data,
    })
  }

  revalidatePath("/dashboard/settings")
  revalidatePath("/impressum")
  revalidatePath("/datenschutz")

  return { success: true, message: "Rechtliche Angaben gespeichert." }
}
