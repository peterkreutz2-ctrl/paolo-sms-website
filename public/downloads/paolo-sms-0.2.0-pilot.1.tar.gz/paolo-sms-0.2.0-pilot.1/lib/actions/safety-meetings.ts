"use server"

import { appAuth } from "@/lib/auth"
import { revalidatePath } from "next/cache"

import { logAuditEvent } from "@/lib/audit"
import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { hasSafetyEditRole } from "@/lib/constants/roles"
import { db } from "@/lib/db"
import { organizations, safetyMeetings } from "@/lib/db/schema"
import { createSafetyMeetingSchema } from "@/lib/validations/safety-meeting"

export type SafetyMeetingActionState = {
  success: boolean
  message: string
}

export async function createSafetyMeeting(
  _: SafetyMeetingActionState,
  formData: FormData
): Promise<SafetyMeetingActionState> {
  const parsed = createSafetyMeetingSchema.safeParse({
    meetingDate: formData.get("meetingDate"),
    title: formData.get("title"),
    notes: formData.get("notes"),
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()
  if (!userId) {
    return { success: false, message: "Nicht angemeldet." }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zum Eintragen einer Sicherheitsbesprechung.",
    }
  }

  const [organization] = await db.select().from(organizations).limit(1)
  if (!organization) {
    return { success: false, message: "Organisation nicht gefunden." }
  }

  const insertResult = await db
    .insert(safetyMeetings)
    .values({
      organizationId: organization.id,
      meetingDate: parsed.data.meetingDate,
      title: parsed.data.title,
      notes: parsed.data.notes,
      createdByClerkUserId: userId,
    })
    .returning({ id: safetyMeetings.id })

  const meeting = insertResult[0]

  if (meeting) {
    await logAuditEvent({
      organizationId: organization.id,
      clerkUserId: userId,
      action: "SAFETY_MEETING_CREATED",
      resourceType: "safety_meeting",
      resourceId: meeting.id,
      changes: {
        meetingDate: parsed.data.meetingDate,
        title: parsed.data.title ?? null,
      },
    })
  }

  revalidatePath("/dashboard")

  return { success: true, message: "Sicherheitsbesprechung wurde eingetragen." }
}
