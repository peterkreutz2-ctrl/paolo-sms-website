"use server"

import { appAuth } from "@/lib/auth"
import { z } from "zod"

import { logAuditEvent } from "@/lib/audit"
import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import {
  ACTIVITY_AREA_VALUES,
  ACTIVITY_TYPE_VALUES,
  DAMAGE_SEVERITY_VALUES,
  FLIGHT_PHASE_VALUES,
  INJURY_SEVERITY_VALUES,
  LAUNCH_TYPE_VALUES,
  REPORTER_ROLE_VALUES,
  SEVERITY_VALUES,
} from "@/lib/constants/report-classification"
import { PUBLIC_REPORT_TYPE_VALUES } from "@/lib/constants/public-report-types"
import { REPORT_PRIORITY_VALUES } from "@/lib/constants/report-workflow"
import { db } from "@/lib/db"
import { organizations, reports } from "@/lib/db/schema"
import { hasAdminRole } from "@/lib/constants/roles"
import { demoBlockedResult, isDemoMode } from "@/lib/demo/mode"

export type ImportReportsState = {
  success: boolean
  message: string
  total?: number
  inserted?: number
  skipped?: number
  errors?: Array<{ line: number; message: string }>
}

// "hidden" is explicitly excluded: imported reports must not arrive pre-hidden
const IMPORT_STATUS_VALUES = [
  "new",
  "in_review",
  "in_progress",
  "measures_defined",
  "closed",
] as const

const importRowSchema = z.object({
  reportType: z.enum(PUBLIC_REPORT_TYPE_VALUES, {
    message: "Ungültiger Meldetyp.",
  }),
  status: z.enum(IMPORT_STATUS_VALUES, {
    message: "Ungültiger Status. Erlaubt: new, in_review, in_progress, measures_defined, closed.",
  }),
  priority: z.enum(REPORT_PRIORITY_VALUES, {
    message: "Ungültige Priorität.",
  }),
  shortDescription: z
    .string()
    .trim()
    .min(1, "Kurzbeschreibung fehlt.")
    .max(120, "Kurzbeschreibung zu lang (max. 120 Zeichen)."),
  detailedDescription: z.string().trim().min(1, "Detailbeschreibung fehlt."),
  isAnonymous: z
    .enum(["true", "false"], {
      message: "isAnonymous muss 'true' oder 'false' sein.",
    })
    .transform((v) => v === "true"),
  occurredAt: z.string().optional(),
  locationText: z.string().optional(),
  reporterLessonsLearned: z.string().optional(),
  reporterSuggestedMeasures: z.string().optional(),
  activityArea: z.preprocess((v) => v === "" ? undefined : v, z.enum(ACTIVITY_AREA_VALUES).optional().catch(undefined)),
  activityType: z.preprocess((v) => v === "" ? undefined : v, z.enum(ACTIVITY_TYPE_VALUES).optional().catch(undefined)),
  flightPhase: z.preprocess((v) => v === "" ? undefined : v, z.enum(FLIGHT_PHASE_VALUES).optional().catch(undefined)),
  launchType: z.preprocess((v) => v === "" ? undefined : v, z.enum(LAUNCH_TYPE_VALUES).optional().catch(undefined)),
  severity: z.preprocess((v) => v === "" ? undefined : v, z.enum(SEVERITY_VALUES).optional().catch(undefined)),
  reporterName: z.string().optional(),
  reporterRole: z.preprocess((v) => v === "" ? undefined : v, z.enum(REPORTER_ROLE_VALUES).optional().catch(undefined)),
  reporterContact: z.string().optional(),
  injurySeverity: z.preprocess((v) => v === "" ? undefined : v, z.enum(INJURY_SEVERITY_VALUES).optional().catch(undefined)),
  damageSeverity: z.preprocess((v) => v === "" ? undefined : v, z.enum(DAMAGE_SEVERITY_VALUES).optional().catch(undefined)),
  isReportableAccident: z.preprocess(
    (v) => {
      if (!v || v === "") return undefined
      if (v === "true") return true
      if (v === "false") return false
      return undefined
    },
    z.boolean().optional()
  ),
})

// RFC 4180-compatible CSV parser for our own export format:
// - strips UTF-8 BOM
// - semicolon separator
// - always-quoted cells
// - double-quote escaping ("")
// - embedded newlines inside quoted fields
function parseCsv(text: string, sep = ";"): string[][] {
  const rows: string[][] = []
  let row: string[] = []
  let field = ""
  let inQuote = false
  let i = text.charCodeAt(0) === 0xfeff ? 1 : 0

  while (i < text.length) {
    const ch = text[i]
    if (inQuote) {
      if (ch === '"') {
        if (text[i + 1] === '"') {
          field += '"'
          i += 2
          continue
        }
        inQuote = false
        i++
        continue
      }
      field += ch
      i++
    } else {
      if (ch === '"') {
        inQuote = true
        i++
        continue
      }
      if (ch === sep) {
        row.push(field)
        field = ""
        i++
        continue
      }
      if (ch === '\r' && text[i + 1] === '\n') {
        row.push(field)
        rows.push(row)
        row = []
        field = ""
        i += 2
        continue
      }
      if (ch === '\n') {
        row.push(field)
        rows.push(row)
        row = []
        field = ""
        i++
        continue
      }
      field += ch
      i++
    }
  }
  if (field !== "" || row.length > 0) {
    row.push(field)
    rows.push(row)
  }
  return rows
}

export async function importReports(
  _: ImportReportsState,
  formData: FormData
): Promise<ImportReportsState> {
  if (isDemoMode()) return demoBlockedResult("generic")
  const { userId } = await appAuth()
  if (!userId) {
    return { success: false, message: "Nicht angemeldet." }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasAdminRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung. Import ist nur für Administratoren verfügbar.",
    }
  }

  const fileEntry = formData.get("file")
  if (!(fileEntry instanceof File)) {
    return { success: false, message: "Keine Datei ausgewählt." }
  }
  if (fileEntry.size === 0) {
    return { success: false, message: "Die ausgewählte Datei ist leer." }
  }

  const text = await fileEntry.text()
  const allRows = parseCsv(text)
  const nonEmptyRows = allRows.filter((r) => r.some((cell) => cell !== ""))

  if (nonEmptyRows.length === 0) {
    return { success: false, message: "Die Datei enthält keine verwertbaren Zeilen." }
  }

  const [headerRow, ...dataRows] = nonEmptyRows
  const headers = headerRow.map((h) => h.trim())

  const idx = (col: string): number => headers.indexOf(col)

  const requiredColumns = [
    "reportType",
    "status",
    "priority",
    "shortDescription",
    "detailedDescription",
    "isAnonymous",
  ]
  const missingColumns = requiredColumns.filter((col) => idx(col) === -1)
  if (missingColumns.length > 0) {
    return {
      success: false,
      message: `Pflichtfelder fehlen in der Kopfzeile: ${missingColumns.join(", ")}`,
    }
  }

  if (dataRows.length === 0) {
    return {
      success: false,
      message: "Die Datei enthält nur eine Kopfzeile, aber keine Datenzeilen.",
    }
  }

  const [organization] = await db
    .select({ id: organizations.id })
    .from(organizations)
    .limit(1)

  if (!organization) {
    return { success: false, message: "Keine Organisation gefunden." }
  }

  const errors: Array<{ line: number; message: string }> = []
  const validRows: Array<{
    organizationId: string
    reportType: string
    status: string
    priority: string
    shortDescription: string
    detailedDescription: string
    isAnonymous: boolean
    occurredAt: Date | null
    locationText: string | null
    reporterLessonsLearned: string | null
    reporterSuggestedMeasures: string | null
    sourceChannel: string
    activityArea: string | null
    activityType: string | null
    flightPhase: string | null
    launchType: string | null
    severity: string | null
    reporterName: string | null
    reporterRole: string | null
    reporterContact: string | null
    injurySeverity: string | null
    damageSeverity: string | null
    isReportableAccident: boolean | null
    retentionReviewEligibleAt: Date | null
  }> = []

  const optionalCol = (col: string, row: string[]): string | undefined =>
    idx(col) !== -1 ? (row[idx(col)] ?? undefined) : undefined

  for (let i = 0; i < dataRows.length; i++) {
    const row = dataRows[i]
    const lineNumber = i + 2 // header is line 1, first data row is line 2

    const raw = {
      reportType: row[idx("reportType")] ?? "",
      status: row[idx("status")] ?? "",
      priority: row[idx("priority")] ?? "",
      shortDescription: row[idx("shortDescription")] ?? "",
      detailedDescription: row[idx("detailedDescription")] ?? "",
      isAnonymous: row[idx("isAnonymous")] ?? "",
      occurredAt: optionalCol("occurredAt", row),
      locationText: optionalCol("locationText", row),
      reporterLessonsLearned: optionalCol("reporterLessonsLearned", row),
      reporterSuggestedMeasures: optionalCol("reporterSuggestedMeasures", row),
      activityArea: optionalCol("activityArea", row),
      activityType: optionalCol("activityType", row),
      flightPhase: optionalCol("flightPhase", row),
      launchType: optionalCol("launchType", row),
      severity: optionalCol("severity", row),
      reporterName: optionalCol("reporterName", row),
      reporterRole: optionalCol("reporterRole", row),
      reporterContact: optionalCol("reporterContact", row),
      injurySeverity: optionalCol("injurySeverity", row),
      damageSeverity: optionalCol("damageSeverity", row),
      isReportableAccident: optionalCol("isReportableAccident", row),
    }

    const parsed = importRowSchema.safeParse(raw)
    if (!parsed.success) {
      errors.push({
        line: lineNumber,
        message: parsed.error.issues[0]?.message ?? "Ungültige Zeile.",
      })
      continue
    }

    validRows.push({
      organizationId: organization.id,
      reportType: parsed.data.reportType,
      status: parsed.data.status,
      priority: parsed.data.priority,
      shortDescription: parsed.data.shortDescription,
      detailedDescription: parsed.data.detailedDescription,
      isAnonymous: parsed.data.isAnonymous,
      occurredAt: parsed.data.occurredAt ? new Date(parsed.data.occurredAt) : null,
      locationText: parsed.data.locationText?.trim() || null,
      reporterLessonsLearned: parsed.data.reporterLessonsLearned?.trim() || null,
      reporterSuggestedMeasures: parsed.data.reporterSuggestedMeasures?.trim() || null,
      sourceChannel: "import",
      activityArea: parsed.data.activityArea ?? null,
      activityType: parsed.data.activityType ?? null,
      flightPhase: parsed.data.flightPhase ?? null,
      launchType: parsed.data.launchType ?? null,
      severity: parsed.data.severity ?? null,
      reporterName: parsed.data.reporterName?.trim() || null,
      reporterRole: parsed.data.reporterRole ?? null,
      reporterContact: parsed.data.reporterContact?.trim() || null,
      injurySeverity: parsed.data.injurySeverity ?? null,
      damageSeverity: parsed.data.damageSeverity ?? null,
      isReportableAccident: parsed.data.isReportableAccident ?? null,
      // Import umgeht updateReportWorkflow, die einzige sonstige Stelle, die
      // den Retention-Review-Anker setzt. Ohne diese Ergaenzung wuerden
      // direkt als "closed" importierte Reports nie in der Faelligkeits-
      // uebersicht erscheinen ("hidden" ist beim Import ausgeschlossen).
      retentionReviewEligibleAt: parsed.data.status === "closed" ? new Date() : null,
    })
  }

  if (validRows.length > 0) {
    await db.insert(reports).values(validRows)
  }

  const total = dataRows.length
  const inserted = validRows.length
  const skipped = total - inserted

  await logAuditEvent({
    organizationId: organization.id,
    clerkUserId: userId,
    action: "REPORTS_IMPORTED",
    resourceType: "organization",
    resourceId: organization.id,
    changes: { total, inserted, skipped, format: "csv" },
  })

  const success = inserted > 0
  const message =
    inserted > 0
      ? `Import abgeschlossen: ${inserted} von ${total} Reports importiert.`
      : "Import fehlgeschlagen: Keine gültigen Zeilen gefunden."

  return { success, message, total, inserted, skipped, errors }
}
