"use server"

import { appAuth } from "@/lib/auth"
import { eq } from "drizzle-orm"
import { revalidatePath } from "next/cache"

import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { hasSafetyEditRole } from "@/lib/constants/roles"
import { db } from "@/lib/db"
import { organizations } from "@/lib/db/schema"
import { logAuditEvent } from "@/lib/audit"
import {
  updateOrganizationDisplayNameSchema,
  updateOrganizationSettingsSchema,
  updatePublicReportStatusVisibilitySchema,
  updateSmsGovernanceSchema,
} from "@/lib/validations/organization-settings"
import { demoBlockedResult, isDemoMode } from "@/lib/demo/mode"

export type OrganizationSettingsActionState = {
  success: boolean
  message: string
}

/**
 * Ergebnis des Schalters fuer die oeffentliche Statusrueckmeldung.
 *
 * Anders als die uebrigen Einstellungen gibt dieser Vorgang den **gespeicherten
 * Wert** zurueck. Grund ist die Darstellung: Nach einer Form-Action setzt React
 * das Formular zurueck, und das Kontrollkaestchen fiel dabei auf den Wert des
 * urspruenglichen Server-Renderings zurueck — es zeigte also das Gegenteil der
 * gerade gespeicherten Einstellung, bis die Seite neu geladen wurde. Damit die
 * Oberflaeche sich nicht auf ihren eigenen, veralteten Zustand verlassen muss,
 * sagt der Server hier ausdruecklich, was jetzt gilt.
 *
 * `resultId` ist ein blosser Zaehlwert, der sich bei jedem Durchlauf aendert.
 * Er erlaubt der Oberflaeche, die Anzeige nach JEDEM abgeschlossenen Vorgang
 * neu aufzubauen — auch dann, wenn sich der gespeicherte Wert gar nicht
 * geaendert hat und ein Vergleich allein nichts bemerken wuerde.
 */
export type PublicReportStatusVisibilityState =
  OrganizationSettingsActionState & {
    enabled?: boolean
    resultId?: number
  }

export async function updateOrganizationSettings(
  _: OrganizationSettingsActionState,
  formData: FormData
): Promise<OrganizationSettingsActionState> {
  const parsed = updateOrganizationSettingsSchema.safeParse({
    safetyMeetingIntervalMonths: formData.get("safetyMeetingIntervalMonths"),
    reportRetentionReviewIntervalMonths: formData.get(
      "reportRetentionReviewIntervalMonths"
    ),
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()
  if (!userId) {
    return { success: false, message: "Nicht angemeldet." }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return { success: false, message: "Keine Berechtigung." }
  }

  const [organization] = await db.select().from(organizations).limit(1)
  if (!organization) {
    return { success: false, message: "Organisation nicht gefunden." }
  }

  await db
    .update(organizations)
    .set({
      safetyMeetingIntervalMonths: parsed.data.safetyMeetingIntervalMonths,
      reportRetentionReviewIntervalMonths:
        parsed.data.reportRetentionReviewIntervalMonths,
    })
    .where(eq(organizations.id, organization.id))

  revalidatePath("/dashboard")
  revalidatePath("/dashboard/settings")

  return { success: true, message: "Einstellungen gespeichert." }
}

// Dokumentarische SMS-Verantwortung (Accountable Executive / Safety Manager).
// Rein dokumentarisch: gleiche Berechtigung wie sonstige Organisationseinstellungen
// (hasSafetyEditRole), aber keine neue Rolle und keine zusaetzliche
// Programmberechtigung. Speichert nur Text.
export async function updateSmsGovernanceSettings(
  _: OrganizationSettingsActionState,
  formData: FormData
): Promise<OrganizationSettingsActionState> {
  const parsed = updateSmsGovernanceSchema.safeParse({
    accountableExecutiveName: formData.get("accountableExecutiveName") ?? "",
    accountableExecutiveFunction:
      formData.get("accountableExecutiveFunction") ?? "",
    accountableExecutiveContact:
      formData.get("accountableExecutiveContact") ?? "",
    accountableExecutiveTerm: formData.get("accountableExecutiveTerm") ?? "",
    safetyManagerName: formData.get("safetyManagerName") ?? "",
    safetyManagerFunction: formData.get("safetyManagerFunction") ?? "",
    safetyManagerContact: formData.get("safetyManagerContact") ?? "",
    safetyManagerTerm: formData.get("safetyManagerTerm") ?? "",
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()
  if (!userId) {
    return { success: false, message: "Nicht angemeldet." }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return { success: false, message: "Keine Berechtigung." }
  }

  const [organization] = await db.select().from(organizations).limit(1)
  if (!organization) {
    return { success: false, message: "Organisation nicht gefunden." }
  }

  await db
    .update(organizations)
    .set({
      accountableExecutiveName: parsed.data.accountableExecutiveName,
      accountableExecutiveFunction: parsed.data.accountableExecutiveFunction,
      accountableExecutiveContact: parsed.data.accountableExecutiveContact,
      accountableExecutiveTerm: parsed.data.accountableExecutiveTerm,
      safetyManagerName: parsed.data.safetyManagerName,
      safetyManagerFunction: parsed.data.safetyManagerFunction,
      safetyManagerContact: parsed.data.safetyManagerContact,
      safetyManagerTerm: parsed.data.safetyManagerTerm,
      updatedAt: new Date(),
    })
    .where(eq(organizations.id, organization.id))

  revalidatePath("/dashboard/settings")

  return { success: true, message: "SMS-Verantwortung gespeichert." }
}

// ─── Oeffentliche Statusrueckmeldung ein-/ausschalten ────────────────────────
//
// Berechtigung wie bei allen Organisationseinstellungen: hasSafetyEditRole.
// Der Schalter braucht bewusst keine eigene Regel — er ist eine Einstellung
// der Organisation wie der Besprechungsturnus.
//
// Anders als die uebrigen Einstellungen wird dieser Wechsel ins Audit-Log
// geschrieben: Er schaltet eine oeffentliche Ausgabe fuer die gesamte
// Organisation um. Dass jede andere Veroeffentlichung (Freigabe eines
// SMS-Dokuments auf "oeffentlich") einen Nachweis hinterlaesst und
// ausgerechnet diese nicht, waere eine Luecke im vorhandenen Muster.
//
// Ein Bestaetigungsdialog wie bei Dokumenten ist bewusst NICHT vorgesehen:
// Der Schalter ist mit einem Klick umkehrbar und veroeffentlicht keinen
// Inhalt.
export async function updatePublicReportStatusVisibility(
  _: PublicReportStatusVisibilityState,
  formData: FormData
): Promise<PublicReportStatusVisibilityState> {
  if (isDemoMode()) return demoBlockedResult("publication")
  // Aendert sich bei jedem Durchlauf; siehe PublicReportStatusVisibilityState.
  const resultId = Date.now()

  const parsed = updatePublicReportStatusVisibilitySchema.safeParse({
    publicReportStatusEnabled: formData.get("publicReportStatusEnabled"),
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
      resultId,
    }
  }

  const { userId } = await appAuth()
  if (!userId) {
    return { success: false, message: "Nicht angemeldet.", resultId }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return { success: false, message: "Keine Berechtigung.", resultId }
  }

  const [organization] = await db
    .select({
      id: organizations.id,
      publicReportStatusEnabled: organizations.publicReportStatusEnabled,
    })
    .from(organizations)
    .limit(1)

  if (!organization) {
    return { success: false, message: "Organisation nicht gefunden.", resultId }
  }

  const nextValue = parsed.data.publicReportStatusEnabled

  if (nextValue !== organization.publicReportStatusEnabled) {
    await db
      .update(organizations)
      .set({ publicReportStatusEnabled: nextValue, updatedAt: new Date() })
      .where(eq(organizations.id, organization.id))

    await logAuditEvent({
      organizationId: organization.id,
      clerkUserId: userId,
      action: "ORG_PUBLIC_REPORT_STATUS_VISIBILITY_CHANGED",
      resourceType: "organization",
      resourceId: organization.id,
      changes: {
        from: organization.publicReportStatusEnabled,
        to: nextValue,
      },
    })
  }

  revalidatePath("/dashboard/settings")
  // /communications rendert pro Aufruf frisch (force-dynamic); der Aufruf ist
  // deshalb keine Voraussetzung, sondern nur Sorgfalt fuer den Fall, dass die
  // Seite spaeter einmal zwischengespeichert wird.
  revalidatePath("/communications")

  return {
    success: true,
    message: nextValue
      ? "Statusrückmeldungen werden öffentlich angezeigt."
      : "Öffentliche Statusrückmeldungen sind abgeschaltet.",
    // Der jetzt gespeicherte Wert — die Oberflaeche richtet sich danach und
    // nicht nach ihrem eigenen Zustand.
    enabled: nextValue,
    resultId,
  }
}

// ─── Anzeigename der Organisation (#117) ─────────────────────────────────────
//
// Berechtigung wie bei allen Organisationseinstellungen: hasSafetyEditRole,
// serverseitig. Der Name steht fuer jeden Besucher im Kopf der Anwendung — wie
// beim Schalter fuer die oeffentliche Statusrueckmeldung schreibt deshalb jede
// tatsaechliche Aenderung einen Audit-Eintrag. Anders als dort enthaelt er den
// alten und den neuen Wert im Klartext: Der Name ist ohnehin oeffentlich, und
// ohne ihn waere nicht nachvollziehbar, was zu welchem Zeitpunkt zu sehen war.
//
// Leer = NULL = kein Name. Gleiche Werte (auch zweimal "leer") schreiben weder
// eine Zeile noch einen Audit-Eintrag.
export async function updateOrganizationDisplayName(
  _: OrganizationSettingsActionState,
  formData: FormData
): Promise<OrganizationSettingsActionState> {
  if (isDemoMode()) return demoBlockedResult("publication")
  const parsed = updateOrganizationDisplayNameSchema.safeParse({
    organizationDisplayName: formData.get("organizationDisplayName") ?? "",
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()
  if (!userId) {
    return { success: false, message: "Nicht angemeldet." }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return { success: false, message: "Keine Berechtigung." }
  }

  const [organization] = await db
    .select({
      id: organizations.id,
      displayName: organizations.displayName,
    })
    .from(organizations)
    .limit(1)

  if (!organization) {
    return { success: false, message: "Organisation nicht gefunden." }
  }

  const nextValue = parsed.data.organizationDisplayName

  if (nextValue !== organization.displayName) {
    await db
      .update(organizations)
      .set({ displayName: nextValue, updatedAt: new Date() })
      .where(eq(organizations.id, organization.id))

    await logAuditEvent({
      organizationId: organization.id,
      clerkUserId: userId,
      action: "ORG_DISPLAY_NAME_CHANGED",
      resourceType: "organization",
      resourceId: organization.id,
      changes: {
        from: organization.displayName,
        to: nextValue,
      },
    })
  }

  // Der Name steht im Kopf jeder Seite.
  revalidatePath("/", "layout")

  return {
    success: true,
    message: nextValue
      ? "Anzeigename gespeichert."
      : "Anzeigename entfernt. Der Kopf zeigt nur noch „PAOLO SMS“.",
  }
}
