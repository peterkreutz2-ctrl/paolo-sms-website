"use server"

import { appAuth } from "@/lib/auth"
import { and, eq, isNull } from "drizzle-orm"
import { revalidatePath } from "next/cache"

import { logAuditEvent } from "@/lib/audit"
import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import {
  requiresDiscardReason,
  validateDiscardReason,
} from "@/lib/constants/measure-workflow"
import { hasSafetyEditRole } from "@/lib/constants/roles"
import { markAnonymizationNeedsReview } from "@/lib/reports/anonymization-status"
import { db } from "@/lib/db"
import { measures, reports } from "@/lib/db/schema"
import {
  createMeasureSchema,
  updateMeasureSchema,
} from "@/lib/validations/measure"

export type MeasureActionState = {
  success: boolean
  message: string
}

export async function createMeasure(
  _: MeasureActionState,
  formData: FormData
): Promise<MeasureActionState> {
  const parsed = createMeasureSchema.safeParse({
    reportId: formData.get("reportId"),
    title: formData.get("title"),
    description: formData.get("description"),
    assignedToText: formData.get("assignedToText"),
    dueDate: formData.get("dueDate"),
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()
  if (!userId) {
    return {
      success: false,
      message: "Nicht angemeldet.",
    }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zum Bearbeiten von Maßnahmen.",
    }
  }

  // Organisation und Kurzbeschreibung werden fuer das Audit-Ereignis
  // mitgelesen — dieselbe Quelle wie bei updateMeasure. Die Tabelle `measures`
  // fuehrt keine Organisation; sie haengt an der Meldung.
  const [report] = await db
    .select({
      id: reports.id,
      organizationId: reports.organizationId,
      shortDescription: reports.shortDescription,
    })
    .from(reports)
    .where(
      and(eq(reports.id, parsed.data.reportId), isNull(reports.deletedAt))
    )
    .limit(1)

  if (!report) {
    return {
      success: false,
      message: "Meldung wurde nicht gefunden.",
    }
  }

  // Insert und Reset ("completed" -> "needs_review") laufen atomar in
  // derselben Transaktion: schlaegt der Reset isoliert fehl, darf die neue
  // Massnahme nicht ohne diesen Reset bestehen bleiben.
  const [created] = await db.transaction(async (tx) => {
    const inserted = await tx
      .insert(measures)
      .values({
        reportId: parsed.data.reportId,
        title: parsed.data.title,
        description: parsed.data.description,
        assignedToText: parsed.data.assignedToText,
        dueDate: parsed.data.dueDate,
        status: "open",
      })
      .returning({ id: measures.id })

    // Eine neue Massnahme kann erneut Personenbezug einbringen (Titel,
    // Beschreibung, Zustaendigkeit) — bereits als vollstaendig geprueft
    // bestaetigte Meldungen muessen dann erneut geprueft werden.
    await markAnonymizationNeedsReview(parsed.data.reportId, tx)

    return inserted
  })

  // Bis hierher war das Anlegen einer Massnahme die einzige Aktion, die einen
  // fachlichen Datensatz erzeugt und dabei NICHTS protokolliert — Notiz,
  // Besprechung, SMS-Dokument, Datenschutzvorfall und Anhaenge tun es alle.
  // Damit war fuer eine irrtuemlich angelegte Massnahme nicht belegbar, wer sie
  // wann angelegt hat.
  //
  // Der Beschreibungstext wird bewusst NICHT mitgeschrieben, nur ob einer
  // gesetzt ist — dieselbe Zurueckhaltung wie bei MEASURE_UPDATED.
  if (created) {
    await logAuditEvent({
      organizationId: report.organizationId,
      clerkUserId: userId,
      action: "MEASURE_CREATED",
      resourceType: "measure",
      resourceId: created.id,
      changes: {
        reportId: parsed.data.reportId,
        reportShortDescription: report.shortDescription,
        title: parsed.data.title,
        status: "open",
        dueDate: parsed.data.dueDate
          ? parsed.data.dueDate.toISOString().slice(0, 10)
          : null,
        descriptionChanged: parsed.data.description !== null,
        assignedToText: parsed.data.assignedToText ?? null,
      },
    })
  }

  revalidatePath(`/dashboard/reports/${parsed.data.reportId}`)
  revalidatePath("/dashboard/reports")
  revalidatePath("/dashboard")
  revalidatePath("/dashboard/measures")

  return {
    success: true,
    message: "Maßnahme wurde angelegt.",
  }
}

export async function updateMeasure(
  _: MeasureActionState,
  formData: FormData
): Promise<MeasureActionState> {
  const parsed = updateMeasureSchema.safeParse({
    measureId: formData.get("measureId"),
    reportId: formData.get("reportId"),
    title: formData.get("title"),
    description: formData.get("description"),
    assignedToText: formData.get("assignedToText"),
    status: formData.get("status"),
    dueDate: formData.get("dueDate"),
    discardReason: formData.get("discardReason"),
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()
  if (!userId) {
    return { success: false, message: "Nicht angemeldet." }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zum Bearbeiten von Maßnahmen.",
    }
  }

  const [existing] = await db
    .select({
      organizationId: reports.organizationId,
      reportShortDescription: reports.shortDescription,
      title: measures.title,
      description: measures.description,
      assignedToText: measures.assignedToText,
      status: measures.status,
    })
    .from(measures)
    .innerJoin(reports, eq(measures.reportId, reports.id))
    .where(
      and(
        eq(measures.id, parsed.data.measureId),
        eq(measures.reportId, parsed.data.reportId),
        isNull(reports.deletedAt)
      )
    )
    .limit(1)

  if (!existing) {
    return { success: false, message: "Maßnahme wurde nicht gefunden." }
  }

  // Das Verwerfen ist die einzige Statusaenderung, die eine Massnahme aus der
  // Nachverfolgung nimmt. Sie verlangt deshalb eine Begruendung — geprueft
  // gegen den BISHERIGEN Status, damit eine bereits verworfene Massnahme
  // weiterhin ohne neue Begruendung bearbeitet werden kann.
  const isDiscarding = requiresDiscardReason(existing.status, parsed.data.status)
  const discardError = validateDiscardReason(
    existing.status,
    parsed.data.status,
    parsed.data.discardReason
  )
  if (discardError) {
    return { success: false, message: discardError }
  }

  // Nur inhaltliche Aenderungen (Titel/Beschreibung/Zustaendigkeit) koennen
  // erneut Personenbezug einbringen — rein workflowbezogene Aenderungen
  // (Status, Faelligkeitsdatum) loesen bewusst KEINEN Reset aus.
  const contentChanged =
    existing.title !== parsed.data.title ||
    existing.description !== parsed.data.description ||
    (existing.assignedToText ?? null) !== (parsed.data.assignedToText ?? null)

  // Update und (bedingter) Reset laufen atomar in derselben Transaktion:
  // schlaegt der Reset isoliert fehl, darf die Aenderung nicht ohne diesen
  // Reset bestehen bleiben.
  await db.transaction(async (tx) => {
    await tx
      .update(measures)
      .set({
        title: parsed.data.title,
        description: parsed.data.description,
        assignedToText: parsed.data.assignedToText,
        status: parsed.data.status,
        dueDate: parsed.data.dueDate,
        updatedAt: new Date(),
      })
      .where(eq(measures.id, parsed.data.measureId))

    if (contentChanged) {
      await markAnonymizationNeedsReview(parsed.data.reportId, tx)
    }
  })

  // Das Verwerfen bekommt ein eigenes Ereignis statt eines generischen
  // Updates: Im Audit-Log war bisher nicht zu erkennen, ob eine Massnahme
  // inhaltlich bearbeitet oder aus der Nachverfolgung genommen wurde.
  //
  // Die Begruendung steht als Klartext im Ereignis. Das ist bewusst anders als
  // beim Freigabevermerk fuer Anhaenge, der aus Datenschutzgruenden NICHT im
  // Audit-Log landet — dort gibt es dafuer eine eigene Spalte. Hier gibt es
  // keine, und eine Begruendung, die nirgends steht, waere keine. Das
  // Eingabefeld weist deshalb ausdruecklich darauf hin, keine
  // personenbezogenen Angaben einzutragen. Eine eigene Spalte bleibt der
  // bessere Weg und ist als Schemaschritt zurueckgestellt.
  await logAuditEvent({
    organizationId: existing.organizationId,
    clerkUserId: userId,
    action: isDiscarding ? "MEASURE_DISCARDED" : "MEASURE_UPDATED",
    resourceType: "measure",
    resourceId: parsed.data.measureId,
    changes: {
      reportId: parsed.data.reportId,
      reportShortDescription: existing.reportShortDescription,
      title: parsed.data.title,
      status: parsed.data.status,
      previousStatus: existing.status,
      dueDate: parsed.data.dueDate
        ? parsed.data.dueDate.toISOString().slice(0, 10)
        : null,
      descriptionChanged: parsed.data.description !== null,
      assignedToText: parsed.data.assignedToText ?? null,
      ...(isDiscarding ? { discardReason: parsed.data.discardReason } : {}),
    },
  })

  revalidatePath(`/dashboard/reports/${parsed.data.reportId}`)
  revalidatePath("/dashboard/reports")
  revalidatePath("/dashboard")
  revalidatePath("/dashboard/measures")

  return {
    success: true,
    message: isDiscarding
      ? "Maßnahme wurde verworfen."
      : "Maßnahme wurde gespeichert.",
  }
}
