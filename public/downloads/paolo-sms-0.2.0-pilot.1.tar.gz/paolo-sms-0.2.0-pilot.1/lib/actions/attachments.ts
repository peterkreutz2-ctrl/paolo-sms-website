"use server"

import { appAuth } from "@/lib/auth"
import { and, eq, isNull } from "drizzle-orm"
import { revalidatePath } from "next/cache"
import { z } from "zod"

import { logAuditEvent } from "@/lib/audit"
import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import {
  buildStorageKey,
  checkUploadedFile,
} from "@/lib/constants/attachment-file-types"
import {
  areAllChecklistItemsConfirmed,
  ATTACHMENT_RELEASE_CHECKLIST_VERSION,
  getRequiredChecklistKeys,
} from "@/lib/constants/attachment-release"
import { hasAttachmentAccessRole, hasSafetyEditRole } from "@/lib/constants/roles"
import {
  publishAttachmentSchema,
  unpublishAttachmentSchema,
} from "@/lib/validations/attachment-release"
import { markAnonymizationNeedsReview } from "@/lib/reports/anonymization-status"
import { db } from "@/lib/db"
import { attachments, reports, smsDocuments } from "@/lib/db/schema"
import { deleteStoredFile, uploadFile } from "@/lib/storage"
import { demoBlockedResult, isDemoMode } from "@/lib/demo/mode"

const uploadAttachmentSchema = z.object({
  reportId: z.string().uuid("Ungültige Meldungs-ID."),
})

const deleteAttachmentSchema = z.object({
  attachmentId: z.string().uuid("Ungültige Anhangs-ID."),
  reportId: z.string().uuid("Ungültige Meldungs-ID."),
})

const uploadSmsDocumentAttachmentSchema = z.object({
  documentId: z.string().uuid("Ungültige Dokument-ID."),
})

const deleteSmsDocumentAttachmentSchema = z.object({
  attachmentId: z.string().uuid("Ungültige Anhangs-ID."),
  documentId: z.string().uuid("Ungültige Dokument-ID."),
})

export type UploadAttachmentState = {
  success: boolean
  message: string
}

export async function uploadReportAttachment(
  _: UploadAttachmentState,
  formData: FormData
): Promise<UploadAttachmentState> {
  if (isDemoMode()) return demoBlockedResult("uploads")
  const parsed = uploadAttachmentSchema.safeParse({
    reportId: formData.get("reportId"),
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasAttachmentAccessRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zum Hochladen von Anhängen.",
    }
  }

  const fileCheck = await checkUploadedFile(formData.get("file"))
  if (!fileCheck.ok) {
    return { success: false, message: fileCheck.message }
  }
  const fileValue = fileCheck.file

  const [report] = await db
    .select({ id: reports.id })
    .from(reports)
    .where(
      and(eq(reports.id, parsed.data.reportId), isNull(reports.deletedAt))
    )
    .limit(1)

  if (!report) {
    return {
      success: false,
      message: "Meldung nicht gefunden.",
    }
  }

  const storageKey = buildStorageKey(
    "reports",
    parsed.data.reportId,
    fileValue.name
  )

  const uploadedFile = await uploadFile(fileValue, {
    storagePath: storageKey,
    contentType: fileValue.type || "application/octet-stream",
  })

  // Blob-Upload ist bereits abgeschlossen (siehe oben) und bewusst NICHT
  // Teil dieser Transaktion (keine riskante neue Transaktionskonstruktion um
  // Blob + DB). Der DB-Insert und der Reset ("completed" -> "needs_review")
  // sind aber reine DB-Operationen und laufen atomar zusammen: schlaegt der
  // Reset isoliert fehl, darf der neue Anhang nicht ohne diesen Reset
  // bestehen bleiben.
  await db.transaction(async (tx) => {
    await tx.insert(attachments).values({
      reportId: parsed.data.reportId,
      originalFileName: fileValue.name,
      mimeType: fileValue.type || "application/octet-stream",
      fileSize: fileValue.size,
      storageProvider: uploadedFile.storageProvider,
      storageKey: uploadedFile.storageKey,
      publicUrl: uploadedFile.publicUrl,
    })

    await markAnonymizationNeedsReview(parsed.data.reportId, tx)
  })

  revalidatePath(`/dashboard/reports/${parsed.data.reportId}`)
  revalidatePath("/dashboard")

  return {
    success: true,
    message: "Anhang wurde hochgeladen.",
  }
}

export type DeleteAttachmentState = {
  success: boolean
  message: string
}

export async function deleteAttachment(
  _: DeleteAttachmentState,
  formData: FormData
): Promise<DeleteAttachmentState> {
  const parsed = deleteAttachmentSchema.safeParse({
    attachmentId: formData.get("attachmentId"),
    reportId: formData.get("reportId"),
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  if (!(await appAuth()).userId) {
    return {
      success: false,
      message: "Nicht angemeldet.",
    }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zum Löschen von Anhängen.",
    }
  }

  const [attachment] = await db
    .select()
    .from(attachments)
    .where(eq(attachments.id, parsed.data.attachmentId))
    .limit(1)

  if (!attachment) {
    return {
      success: false,
      message: "Anhang wurde nicht gefunden.",
    }
  }

  if (attachment.reportId !== parsed.data.reportId) {
    return {
      success: false,
      message: "Anhang gehoert nicht zu dieser Meldung.",
    }
  }

  const [report] = await db
    .select({ id: reports.id, deletedAt: reports.deletedAt })
    .from(reports)
    .where(eq(reports.id, attachment.reportId))
    .limit(1)

  if (!report || report.deletedAt != null) {
    return {
      success: false,
      message: "Meldung nicht gefunden oder ausgeblendet.",
    }
  }

  try {
    // Fehlt die Datei im Speicher bereits, behandelt die Storage-Schicht das als
    // No-op (provider-neutral); nur echte Speicherfehler landen hier.
    await deleteStoredFile(attachment.storageKey)
  } catch {
    return {
      success: false,
      message:
        "Die Datei im Speicher konnte nicht gelöscht werden. Bitte später erneut versuchen.",
    }
  }

  const [removed] = await db
    .delete(attachments)
    .where(eq(attachments.id, parsed.data.attachmentId))
    .returning({ id: attachments.id })

  if (!removed) {
    return {
      success: false,
      message:
        "Der Anhang konnte in der Datenbank nicht entfernt werden. Bitte erneut versuchen.",
    }
  }

  revalidatePath("/dashboard")
  revalidatePath("/dashboard/reports")
  revalidatePath(`/dashboard/reports/${parsed.data.reportId}`)

  return {
    success: true,
    message: "Anhang wurde gelöscht.",
  }
}

// ─── Anhaenge an SMS-Dokumenten ───────────────────
//
// Gleiche Infrastruktur wie oben: dieselbe Tabelle, dieselbe Storage-Schicht,
// dieselbe Datei- und Groessenpruefung. Unterschiede sind bewusst nur zwei:
//
//   Berechtigung  hasSafetyEditRole (safety_manager fachlich zustaendig,
//                 admin als technische Administrations-/Notfallrolle).
//                 Insbesondere NICHT instructor — anders als bei Meldungen.
//   Anonymisierung Kein Reset des Anonymisierungsstatus: der haengt an einer
//                 Meldung und hat bei einem SMS-Dokument keine Entsprechung.
//
// Eine oeffentliche Freigabe gibt es hier nicht; Anhaenge von
// SMS-Dokumente sind in diesem Arbeitspaket ausschliesslich intern.

const DOCUMENTS_PATH = "/dashboard/documents"
// Oeffentliche Seite mit revalidieren: eine Freigabe oder ihr Widerruf muss
// dort sofort greifen.
const COMMUNICATIONS_PATH = "/communications"

export async function uploadSmsDocumentAttachment(
  _: UploadAttachmentState,
  formData: FormData
): Promise<UploadAttachmentState> {
  if (isDemoMode()) return demoBlockedResult("uploads")
  const parsed = uploadSmsDocumentAttachmentSchema.safeParse({
    documentId: formData.get("documentId"),
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()
  if (!userId) {
    return { success: false, message: "Nicht angemeldet." }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zum Hochladen von Anhängen.",
    }
  }

  const fileCheck = await checkUploadedFile(formData.get("file"))
  if (!fileCheck.ok) {
    return { success: false, message: fileCheck.message }
  }
  const fileValue = fileCheck.file

  const [document] = await db
    .select({
      id: smsDocuments.id,
      organizationId: smsDocuments.organizationId,
    })
    .from(smsDocuments)
    .where(eq(smsDocuments.id, parsed.data.documentId))
    .limit(1)

  if (!document) {
    return { success: false, message: "Dokument wurde nicht gefunden." }
  }

  const storageKey = buildStorageKey(
    "sms-documents",
    parsed.data.documentId,
    fileValue.name
  )

  const uploadedFile = await uploadFile(fileValue, {
    storagePath: storageKey,
    contentType: fileValue.type || "application/octet-stream",
  })

  const [created] = await db
    .insert(attachments)
    .values({
      smsDocumentId: parsed.data.documentId,
      originalFileName: fileValue.name,
      mimeType: fileValue.type || "application/octet-stream",
      fileSize: fileValue.size,
      storageProvider: uploadedFile.storageProvider,
      storageKey: uploadedFile.storageKey,
      publicUrl: uploadedFile.publicUrl,
    })
    .returning({ id: attachments.id })

  if (!created) {
    return {
      success: false,
      message: "Der Anhang konnte nicht gespeichert werden.",
    }
  }

  // Muster wie in lib/actions/sms-documents.ts: Best-Effort nach der
  // fachlichen Aenderung. isPublic wird bewusst mitprotokolliert, damit im
  // Audit erkennbar bleibt, dass ein Anhang nicht oeffentlich angelegt wird.
  //
  // Der Dateiname steht bewusst NICHT in der Payload: er kann personenbezogen
  // sein ("Unfall_Nachname.jpg") und wuerde dauerhaft im Audit-Log liegen,
  // waehrend die Datei selbst loeschbar ist. Identifiziert wird der Anhang
  // ueber resourceId; solange er existiert, ist der Name darueber auffindbar.
  await logAuditEvent({
    organizationId: document.organizationId,
    clerkUserId: userId,
    action: "SMS_DOCUMENT_ATTACHMENT_UPLOADED",
    resourceType: "sms_document_attachment",
    resourceId: created.id,
    changes: {
      smsDocumentId: parsed.data.documentId,
      mimeType: fileValue.type || "application/octet-stream",
      fileSize: fileValue.size,
      isPublic: false,
    },
  })

  revalidatePath(DOCUMENTS_PATH)

  return { success: true, message: "Anhang wurde hochgeladen." }
}

export async function deleteSmsDocumentAttachment(
  _: DeleteAttachmentState,
  formData: FormData
): Promise<DeleteAttachmentState> {
  if (isDemoMode()) return demoBlockedResult("publication")
  const parsed = deleteSmsDocumentAttachmentSchema.safeParse({
    attachmentId: formData.get("attachmentId"),
    documentId: formData.get("documentId"),
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()
  if (!userId) {
    return { success: false, message: "Nicht angemeldet." }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zum Löschen von Anhängen.",
    }
  }

  const [attachment] = await db
    .select()
    .from(attachments)
    .where(eq(attachments.id, parsed.data.attachmentId))
    .limit(1)

  if (!attachment) {
    return { success: false, message: "Anhang wurde nicht gefunden." }
  }

  if (attachment.smsDocumentId !== parsed.data.documentId) {
    return {
      success: false,
      message: "Anhang gehoert nicht zu diesem Dokument.",
    }
  }

  const [document] = await db
    .select({ organizationId: smsDocuments.organizationId })
    .from(smsDocuments)
    .where(eq(smsDocuments.id, parsed.data.documentId))
    .limit(1)

  if (!document) {
    return { success: false, message: "Dokument wurde nicht gefunden." }
  }

  try {
    // Fehlt die Datei im Speicher bereits, behandelt die Storage-Schicht das
    // als No-op (provider-neutral); nur echte Speicherfehler landen hier.
    await deleteStoredFile(attachment.storageKey)
  } catch {
    return {
      success: false,
      message:
        "Die Datei im Speicher konnte nicht gelöscht werden. Bitte später erneut versuchen.",
    }
  }

  const [removed] = await db
    .delete(attachments)
    .where(eq(attachments.id, parsed.data.attachmentId))
    .returning({ id: attachments.id })

  if (!removed) {
    return {
      success: false,
      message:
        "Der Anhang konnte in der Datenbank nicht entfernt werden. Bitte erneut versuchen.",
    }
  }

  // isPublic wird mitprotokolliert: ob ein oeffentlich freigegebener Anhang
  // entfernt wurde, ist die fuer eine spaetere Nachvollziehbarkeit
  // entscheidende Angabe.
  //
  // Der Dateiname fehlt bewusst — gleiche Begruendung wie beim Upload. Beim
  // Loeschen wiegt sie schwerer: der Eintrag ueberlebt die Datei, ein
  // personenbezogener Name bliebe also gerade dann stehen, wenn der Inhalt
  // absichtlich entfernt wurde.
  await logAuditEvent({
    organizationId: document.organizationId,
    clerkUserId: userId,
    action: "SMS_DOCUMENT_ATTACHMENT_DELETED",
    resourceType: "sms_document_attachment",
    resourceId: parsed.data.attachmentId,
    changes: {
      smsDocumentId: parsed.data.documentId,
      mimeType: attachment.mimeType,
      fileSize: attachment.fileSize,
      isPublic: attachment.isPublic,
    },
  })

  // Kein COMMUNICATIONS_PATH — anders als bei Freigabe und Widerruf weiter
  // oben, und das ist Absicht: /communications traegt `force-dynamic` und
  // rendert bei jedem Aufruf frisch aus der Datenbank, ein geloeschter Anhang
  // kann dort also nicht stehenbleiben. Faellt dieses `force-dynamic`
  // irgendwann weg, muss hier revalidiert werden.
  revalidatePath(DOCUMENTS_PATH)

  return { success: true, message: "Anhang wurde gelöscht." }
}

// ─── Oeffentliche Freigabe und Widerruf ─────────────────────────────────────
//
// Die Freigabe ist die einzige Stelle, an der Inhalte PAOLO ohne Anmeldung
// verlassen koennen. Sie verlangt daher dreierlei zusammen: die vollstaendig
// bestaetigte Checkliste, einen Freigabevermerk im Klartext und dieselbe
// Rolle wie die uebrige Bearbeitung von SMS-Dokumenten.
//
// Zwei Tore bleiben davon unberuehrt: die oeffentliche Route verlangt
// zusaetzlich, dass das Elterndokument selbst oeffentlich ist. Ein
// freigegebener Anhang an einem vertraulichen Dokument ist damit nicht
// abrufbar.

export type AttachmentReleaseState = {
  success: boolean
  message: string
}

export async function publishSmsDocumentAttachment(
  _: AttachmentReleaseState,
  formData: FormData
): Promise<AttachmentReleaseState> {
  if (isDemoMode()) return demoBlockedResult("publication")
  const parsed = publishAttachmentSchema.safeParse({
    attachmentId: formData.get("attachmentId"),
    documentId: formData.get("documentId"),
    releaseNote: formData.get("releaseNote"),
    confirmedChecklistKeys: formData.getAll("checklist").map(String),
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()
  if (!userId) {
    return { success: false, message: "Nicht angemeldet." }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zum Freigeben von Anhängen.",
    }
  }

  const [attachment] = await db
    .select({
      id: attachments.id,
      smsDocumentId: attachments.smsDocumentId,
      originalFileName: attachments.originalFileName,
      mimeType: attachments.mimeType,
      isPublic: attachments.isPublic,
    })
    .from(attachments)
    .where(eq(attachments.id, parsed.data.attachmentId))
    .limit(1)

  if (!attachment || attachment.smsDocumentId !== parsed.data.documentId) {
    return { success: false, message: "Anhang wurde nicht gefunden." }
  }

  const [document] = await db
    .select({
      organizationId: smsDocuments.organizationId,
      visibility: smsDocuments.visibility,
    })
    .from(smsDocuments)
    .where(eq(smsDocuments.id, parsed.data.documentId))
    .limit(1)

  if (!document) {
    return { success: false, message: "Dokument wurde nicht gefunden." }
  }

  // Welche Punkte noetig sind, haengt am Dateinamen (Tracklogs brauchen einen
  // zusaetzlichen). Serverseitig gegen die tatsaechliche Datei geprueft, nicht
  // gegen das, was das Formular geschickt hat.
  if (
    !areAllChecklistItemsConfirmed(
      attachment.originalFileName,
      parsed.data.confirmedChecklistKeys
    )
  ) {
    return {
      success: false,
      message:
        "Bitte alle Punkte der Freigabeprüfung bestätigen. Ohne vollständige Prüfung ist keine Veröffentlichung möglich.",
    }
  }

  const releasedAt = new Date()

  // Zustandsaenderung und Audit-Eintrag laufen atomar: logAuditEvent mit `tx`
  // schreibt auf demselben Transaktions-Client und verschluckt Fehler bewusst
  // NICHT, sondern wirft weiter — dadurch rollt die Transaktion zurueck.
  // Es kann also keine oeffentliche Freigabe ohne zugehoerigen Audit-Eintrag
  // geben. Fuer ein Ereignis, das Inhalte anmeldefrei erreichbar macht, ist
  // das die richtige Abwaegung; die uebrigen Aktionen dieses Moduls bleiben
  // beim Best-Effort-Muster.
  //
  // Der Freigabevermerk selbst steht bewusst NICHT in der Audit-Payload: er
  // ist Freitext und kann personenbezogene Angaben enthalten ("Einwilligung
  // von Frau X liegt vor"). Er lebt am Anhang und ist mit ihm loeschbar; das
  // Audit haelt nur fest, DASS einer vorlag. Der bestaetigte Checklisten-
  // Zustand samt Version gehoert dagegen hierher — nur hier gibt der
  // Zeitstempel ihm Bedeutung.
  try {
    await db.transaction(async (tx) => {
      await tx
        .update(attachments)
        .set({
          isPublic: true,
          publicReleasedAt: releasedAt,
          publicReleasedByClerkUserId: userId,
          publicReleaseNote: parsed.data.releaseNote,
          updatedAt: releasedAt,
        })
        .where(eq(attachments.id, parsed.data.attachmentId))

      await logAuditEvent(
        {
          organizationId: document.organizationId,
          clerkUserId: userId,
          action: "SMS_DOCUMENT_ATTACHMENT_PUBLISHED",
          resourceType: "sms_document_attachment",
          resourceId: parsed.data.attachmentId,
          changes: {
            smsDocumentId: parsed.data.documentId,
            isPublic: true,
            mimeType: attachment.mimeType,
            documentVisibility: document.visibility,
            checklistVersion: ATTACHMENT_RELEASE_CHECKLIST_VERSION,
            confirmedChecklistKeys: getRequiredChecklistKeys(
              attachment.originalFileName
            ),
            releaseNoteProvided: true,
            releaseNoteLength: parsed.data.releaseNote.length,
          },
        },
        tx
      )
    })
  } catch (error) {
    console.error("[attachments] Freigabe fehlgeschlagen:", error)
    return {
      success: false,
      message:
        "Die Freigabe konnte nicht vollständig gespeichert werden und wurde zurückgenommen. Der Anhang bleibt intern. Bitte erneut versuchen.",
    }
  }

  revalidatePath(DOCUMENTS_PATH)
  revalidatePath(COMMUNICATIONS_PATH)

  return {
    success: true,
    message:
      document.visibility === "public"
        ? "Anhang wurde öffentlich freigegeben."
        : "Anhang wurde freigegeben. Er wird öffentlich sichtbar, sobald das Dokument selbst öffentlich ist.",
  }
}

export async function unpublishSmsDocumentAttachment(
  _: AttachmentReleaseState,
  formData: FormData
): Promise<AttachmentReleaseState> {
  if (isDemoMode()) return demoBlockedResult("publication")
  const parsed = unpublishAttachmentSchema.safeParse({
    attachmentId: formData.get("attachmentId"),
    documentId: formData.get("documentId"),
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()
  if (!userId) {
    return { success: false, message: "Nicht angemeldet." }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zum Zuruecknehmen von Freigaben.",
    }
  }

  const [attachment] = await db
    .select({
      smsDocumentId: attachments.smsDocumentId,
      mimeType: attachments.mimeType,
      publicReleasedAt: attachments.publicReleasedAt,
    })
    .from(attachments)
    .where(eq(attachments.id, parsed.data.attachmentId))
    .limit(1)

  if (!attachment || attachment.smsDocumentId !== parsed.data.documentId) {
    return { success: false, message: "Anhang wurde nicht gefunden." }
  }

  const [document] = await db
    .select({ organizationId: smsDocuments.organizationId })
    .from(smsDocuments)
    .where(eq(smsDocuments.id, parsed.data.documentId))
    .limit(1)

  if (!document) {
    return { success: false, message: "Dokument wurde nicht gefunden." }
  }

  // Nur das Flag faellt. Freigabedatum, freigebender Benutzer und
  // Freigabevermerk bleiben bewusst stehen: sie dokumentieren, dass und warum
  // veroeffentlicht wurde. Nachvollziehbarkeit geht vor dem Ueberschreiben
  // historischer Information; die Felder bedeuten "letzte Freigabe", nicht
  // "aktuell oeffentlich".
  //
  // Atomar wie beim Freigeben: auch der Widerruf darf nicht ohne Audit-Eintrag
  // bestehen bleiben, sonst waere im Nachhinein nicht erkennbar, wer eine
  // Veroeffentlichung beendet hat.
  try {
    await db.transaction(async (tx) => {
      await tx
        .update(attachments)
        .set({ isPublic: false, updatedAt: new Date() })
        .where(eq(attachments.id, parsed.data.attachmentId))

      await logAuditEvent(
        {
          organizationId: document.organizationId,
          clerkUserId: userId,
          action: "SMS_DOCUMENT_ATTACHMENT_UNPUBLISHED",
          resourceType: "sms_document_attachment",
          resourceId: parsed.data.attachmentId,
          changes: {
            smsDocumentId: parsed.data.documentId,
            isPublic: false,
            mimeType: attachment.mimeType,
            // Korrelation zur zurueckgenommenen Freigabe, ohne deren Inhalt.
            previousReleasedAt:
              attachment.publicReleasedAt?.toISOString() ?? null,
          },
        },
        tx
      )
    })
  } catch (error) {
    console.error("[attachments] Widerruf fehlgeschlagen:", error)
    return {
      success: false,
      message:
        "Die Freigabe konnte nicht zurückgenommen werden. Der Anhang bleibt öffentlich — bitte erneut versuchen.",
    }
  }

  revalidatePath(DOCUMENTS_PATH)
  revalidatePath(COMMUNICATIONS_PATH)

  return { success: true, message: "Freigabe wurde zurückgenommen." }
}
