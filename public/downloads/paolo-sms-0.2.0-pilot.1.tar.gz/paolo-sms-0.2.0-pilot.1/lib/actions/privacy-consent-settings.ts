"use server"

import { appAuth } from "@/lib/auth"
import { eq } from "drizzle-orm"
import { revalidatePath } from "next/cache"

import { logAuditEvent } from "@/lib/audit"
import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import {
  resolvePrivacyConsentText,
  toStoredPrivacyConsentText,
} from "@/lib/constants/public-report-privacy-consent"
import { hasSafetyEditRole } from "@/lib/constants/roles"
import { db } from "@/lib/db"
import { organizations } from "@/lib/db/schema"
import { updatePublicReportPrivacyConsentSchema } from "@/lib/validations/organization-settings"
import { demoBlockedResult, isDemoMode } from "@/lib/demo/mode"

/**
 * Ergebnis der Einwilligungseinstellungen (#101).
 *
 * Wie beim Schalter fuer die Statusrueckmeldung gibt der Server die jetzt
 * geltenden Werte zurueck, und `resultId` aendert sich bei jedem Durchlauf:
 * Nach einer Form-Action setzt React das Formular zurueck, und die Oberflaeche
 * soll sich nach dem Gespeicherten richten, nicht nach ihrem eigenen Zustand.
 */
export type PrivacyConsentSettingsState = {
  success: boolean
  message: string
  /** Nach Erfolg der gespeicherte Wert, nach Ablehnung der abgeschickte. */
  enabled?: boolean
  /** Nach Erfolg der wirksame Text, nach Ablehnung der abgeschickte. */
  text?: string
  resultId?: number
}

// Berechtigung wie bei allen Organisationseinstellungen: hasSafetyEditRole.
// Jede Aenderung an Schalter oder Text wird als eigener Audit-Eintrag mit
// vorher/nachher festgehalten — der Wortlaut einer Einwilligung ist genau die
// Art Information, deren Entstehung spaeter nachvollziehbar sein muss.
export async function updatePublicReportPrivacyConsentSettings(
  _: PrivacyConsentSettingsState,
  formData: FormData
): Promise<PrivacyConsentSettingsState> {
  if (isDemoMode()) return demoBlockedResult("publication")
  const resultId = Date.now()
  const rawEnabled = formData.get("publicReportPrivacyConsentEnabled")
  const rawText = formData.get("publicReportPrivacyConsentText")

  // Bei einer Ablehnung bekommt das Formular die abgeschickten Werte zurueck.
  // React setzt es nach der Action zurueck; ohne diese Werte waere ein gerade
  // bearbeiteter Text verloren, nur weil zum Beispiel der Marker fehlte.
  const rejected = (message: string): PrivacyConsentSettingsState => ({
    success: false,
    message,
    enabled: rawEnabled === "on" || rawEnabled === "true",
    text: typeof rawText === "string" ? rawText : undefined,
    resultId,
  })

  const parsed = updatePublicReportPrivacyConsentSchema.safeParse({
    publicReportPrivacyConsentEnabled: rawEnabled,
    publicReportPrivacyConsentText: rawText,
  })

  if (!parsed.success) {
    return rejected(parsed.error.issues[0]?.message ?? "Ungültige Eingabe.")
  }

  const { userId } = await appAuth()
  if (!userId) {
    return rejected("Nicht angemeldet.")
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return rejected("Keine Berechtigung.")
  }

  const [organization] = await db
    .select({
      id: organizations.id,
      enabled: organizations.publicReportPrivacyConsentEnabled,
      storedText: organizations.publicReportPrivacyConsentText,
    })
    .from(organizations)
    .limit(1)

  if (!organization) {
    return rejected("Organisation nicht gefunden.")
  }

  const nextEnabled = parsed.data.publicReportPrivacyConsentEnabled
  const nextStoredText = toStoredPrivacyConsentText(
    parsed.data.publicReportPrivacyConsentText
  )
  const previousText = resolvePrivacyConsentText(organization.storedText)
  const nextText = resolvePrivacyConsentText(nextStoredText)

  const enabledChanged = nextEnabled !== organization.enabled
  // Verglichen wird der gespeicherte Wert: Auch der Wechsel von einem eigenen
  // Text zurueck auf den Standardtext ist eine Aenderung.
  const textChanged = nextStoredText !== organization.storedText

  if (enabledChanged || textChanged) {
    await db
      .update(organizations)
      .set({
        publicReportPrivacyConsentEnabled: nextEnabled,
        publicReportPrivacyConsentText: nextStoredText,
        updatedAt: new Date(),
      })
      .where(eq(organizations.id, organization.id))
  }

  if (enabledChanged) {
    await logAuditEvent({
      organizationId: organization.id,
      clerkUserId: userId,
      action: "ORG_PUBLIC_REPORT_PRIVACY_CONSENT_ENABLED_CHANGED",
      resourceType: "organization",
      resourceId: organization.id,
      changes: { from: organization.enabled, to: nextEnabled },
    })
  }

  if (textChanged) {
    await logAuditEvent({
      organizationId: organization.id,
      clerkUserId: userId,
      action: "ORG_PUBLIC_REPORT_PRIVACY_CONSENT_TEXT_CHANGED",
      resourceType: "organization",
      resourceId: organization.id,
      // Der volle Wortlaut vorher und nachher, jeweils der wirksame Text.
      // `...IsDefault` haelt fest, ob es der Standardtext aus dem Code war.
      changes: {
        from: previousText,
        to: nextText,
        fromIsDefault: organization.storedText === null,
        toIsDefault: nextStoredText === null,
      },
    })
  }

  revalidatePath("/dashboard/privacy")
  revalidatePath("/submit-report")

  return {
    success: true,
    message:
      enabledChanged || textChanged
        ? "Einwilligungseinstellungen gespeichert."
        : "Keine Änderungen.",
    enabled: nextEnabled,
    text: nextText,
    resultId,
  }
}
