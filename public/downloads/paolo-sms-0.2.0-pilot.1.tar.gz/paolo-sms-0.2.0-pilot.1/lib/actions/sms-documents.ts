"use server"

import { appAuth } from "@/lib/auth"
import { and, eq } from "drizzle-orm"
import { revalidatePath } from "next/cache"

import { logAuditEvent } from "@/lib/audit"
import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { hasSafetyEditRole } from "@/lib/constants/roles"
import { normalizeVisibility } from "@/lib/constants/sms-documents"
import { SMS_DOCUMENT_TEMPLATES } from "@/lib/constants/sms-document-templates"
import { db } from "@/lib/db"
import { attachments, organizations, smsDocuments } from "@/lib/db/schema"
import { deleteStoredFile } from "@/lib/storage"
import { buildMeetingMinutesData } from "@/lib/documents/meeting-minutes"
import { renderTemplate } from "@/lib/documents/template-tokens"
import { demoBlockedResult, isDemoMode } from "@/lib/demo/mode"
import {
  createSmsDocumentSchema,
  deleteSmsDocumentSchema,
  updateSmsDocumentSchema,
} from "@/lib/validations/sms-document"

export type SmsDocumentActionState = {
  success: boolean
  message: string
}

export type PrefillMeetingMinutesResult =
  | { success: true; content: string }
  | { success: false; message: string }

const DOCUMENTS_PATH = "/dashboard/documents"
// Öffentliche Sicherheitsinformationen: bei jeder Änderung an einem Dokument
// mit revalidieren, damit ein Freigeben/Zurückziehen sofort öffentlich greift.
const COMMUNICATIONS_PATH = "/communications"

export async function createSmsDocument(
  _: SmsDocumentActionState,
  formData: FormData
): Promise<SmsDocumentActionState> {
  const parsed = createSmsDocumentSchema.safeParse({
    category: formData.get("category"),
    title: formData.get("title"),
    content: formData.get("content"),
    visibility: formData.get("visibility") ?? undefined,
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  // Demo: Ein Dokument darf nicht oeffentlich werden (/communications ist ohne
  // Anmeldung lesbar).
  if (isDemoMode() && parsed.data.visibility === "public") {
    return demoBlockedResult("publication")
  }

  const { userId } = await appAuth()
  if (!userId) {
    return { success: false, message: "Nicht angemeldet." }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zum Anlegen von SMS-Dokumenten.",
    }
  }

  const [organization] = await db.select().from(organizations).limit(1)
  if (!organization) {
    return { success: false, message: "Organisation nicht gefunden." }
  }

  const [document] = await db
    .insert(smsDocuments)
    .values({
      organizationId: organization.id,
      category: parsed.data.category,
      title: parsed.data.title,
      content: parsed.data.content,
      visibility: parsed.data.visibility,
      createdByClerkUserId: userId,
    })
    .returning({ id: smsDocuments.id })

  if (!document) {
    return { success: false, message: "Dokument konnte nicht gespeichert werden." }
  }

  await logAuditEvent({
    organizationId: organization.id,
    clerkUserId: userId,
    action: "SMS_DOCUMENT_CREATED",
    resourceType: "sms_document",
    resourceId: document.id,
    changes: {
      category: parsed.data.category,
      title: parsed.data.title,
      visibility: parsed.data.visibility,
    },
  })

  revalidatePath(DOCUMENTS_PATH)
  revalidatePath(COMMUNICATIONS_PATH)

  return { success: true, message: "Dokument wurde angelegt." }
}

export async function updateSmsDocument(
  _: SmsDocumentActionState,
  formData: FormData
): Promise<SmsDocumentActionState> {
  const parsed = updateSmsDocumentSchema.safeParse({
    documentId: formData.get("documentId"),
    category: formData.get("category"),
    title: formData.get("title"),
    content: formData.get("content"),
    visibility: formData.get("visibility"),
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  // Demo: Ein Dokument darf nicht oeffentlich werden; ein bereits oeffentliches
  // wird unten ebenfalls nicht angefasst (Pruefung nach dem Laden).
  if (isDemoMode() && parsed.data.visibility === "public") {
    return demoBlockedResult("publication")
  }

  const { userId } = await appAuth()
  if (!userId) {
    return { success: false, message: "Nicht angemeldet." }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zum Bearbeiten von SMS-Dokumenten.",
    }
  }

  const [current] = await db
    .select({
      organizationId: smsDocuments.organizationId,
      category: smsDocuments.category,
      visibility: smsDocuments.visibility,
    })
    .from(smsDocuments)
    .where(eq(smsDocuments.id, parsed.data.documentId))
    .limit(1)

  if (!current) {
    return { success: false, message: "Dokument wurde nicht gefunden." }
  }

  // Demo: Jede Aenderung an einem oeffentlichen Dokument ist eine Aenderung
  // der Veroeffentlichung — Inhalt, Titel und auch die Herabstufung.
  if (isDemoMode() && current.visibility === "public") {
    return demoBlockedResult("publication")
  }

  // Herabstufung von 'public' auf eine restriktivere Stufe: Die oeffentliche
  // Freigabe der Anhaenge faellt mit. Ohne diesen Schritt bliebe ein Anhang mit
  // is_public = true an einem nicht mehr oeffentlichen Dokument zurueck; die
  // Auslieferungsroute liefert ihn dann zwar nicht mehr aus (sie prueft die
  // Dokumentsichtbarkeit mit), aber der Datenbankstand widerspraeche sich.
  //
  // Bewusst NICHT die Gegenrichtung: Ein Dokument auf 'public' zu heben gibt
  // keinen einzigen Anhang frei. Freigabe bleibt ausschliesslich
  // publishSmsDocumentAttachment mit Checkliste, Freigabevermerk und Audit.
  const isDowngradeFromPublic =
    normalizeVisibility(current.visibility) === "public" &&
    parsed.data.visibility !== "public"

  const revokedAttachments = isDowngradeFromPublic
    ? await db
        .select({
          id: attachments.id,
          mimeType: attachments.mimeType,
          publicReleasedAt: attachments.publicReleasedAt,
        })
        .from(attachments)
        .where(
          and(
            eq(attachments.smsDocumentId, parsed.data.documentId),
            eq(attachments.isPublic, true)
          )
        )
    : []

  // Alles in EINER Transaktion: Es darf keine Herabstufung ohne zugehoerige
  // Ruecknahme geben und keine Ruecknahme ohne Audit-Eintrag. Schlaegt ein
  // Teilschritt fehl, bleibt das Dokument oeffentlich — der sichtbare,
  // korrigierbare Zustand ist besser als ein halb vollzogener.
  try {
    await db.transaction(async (tx) => {
      const [updated] = await tx
        .update(smsDocuments)
        .set({
          category: parsed.data.category,
          title: parsed.data.title,
          content: parsed.data.content,
          visibility: parsed.data.visibility,
          updatedByClerkUserId: userId,
          updatedAt: new Date(),
        })
        .where(eq(smsDocuments.id, parsed.data.documentId))
        .returning({ id: smsDocuments.id })

      if (!updated) {
        throw new Error("document-not-found")
      }

      if (revokedAttachments.length > 0) {
        await tx
          .update(attachments)
          .set({ isPublic: false, updatedAt: new Date() })
          .where(
            and(
              eq(attachments.smsDocumentId, parsed.data.documentId),
              eq(attachments.isPublic, true)
            )
          )

        // Eigene Aktion statt des manuellen Widerrufs
        // (SMS_DOCUMENT_ATTACHMENT_UNPUBLISHED): Im Audit-Log muss erkennbar
        // bleiben, dass hier niemand einen einzelnen Anhang zurueckgezogen
        // hat, sondern die Herabstufung des Dokuments die Freigabe beendet
        // hat. Der Freigabenachweis (publicReleasedAt, ...ByClerkUserId,
        // ...Note) bleibt stehen — er bedeutet "letzte Freigabe", nicht
        // "aktuell oeffentlich".
        for (const attachment of revokedAttachments) {
          await logAuditEvent(
            {
              organizationId: current.organizationId,
              clerkUserId: userId,
              action: "SMS_DOCUMENT_ATTACHMENT_UNPUBLISHED_BY_DOWNGRADE",
              resourceType: "sms_document_attachment",
              resourceId: attachment.id,
              changes: {
                smsDocumentId: parsed.data.documentId,
                isPublic: false,
                mimeType: attachment.mimeType,
                trigger: "Herabstufung des Dokuments",
                documentVisibility: {
                  old: current.visibility,
                  new: parsed.data.visibility,
                },
                previousReleasedAt:
                  attachment.publicReleasedAt?.toISOString() ?? null,
              },
            },
            tx
          )
        }
      }

      await logAuditEvent(
        {
          organizationId: current.organizationId,
          clerkUserId: userId,
          action: "SMS_DOCUMENT_UPDATED",
          resourceType: "sms_document",
          resourceId: parsed.data.documentId,
          changes: {
            title: parsed.data.title,
            old: { category: current.category, visibility: current.visibility },
            new: {
              category: parsed.data.category,
              visibility: parsed.data.visibility,
            },
            revokedPublicAttachments: revokedAttachments.length,
          },
        },
        tx
      )
    })
  } catch (error) {
    if (error instanceof Error && error.message === "document-not-found") {
      return { success: false, message: "Dokument wurde nicht gefunden." }
    }
    console.error("[sms-documents] Aktualisierung fehlgeschlagen:", error)
    return {
      success: false,
      message:
        "Das Dokument konnte nicht aktualisiert werden. Es wurde nichts geändert — bitte erneut versuchen.",
    }
  }

  revalidatePath(DOCUMENTS_PATH)
  revalidatePath(COMMUNICATIONS_PATH)

  return {
    success: true,
    message:
      revokedAttachments.length > 0
        ? "Dokument wurde aktualisiert. Die öffentliche Freigabe der Anhänge wurde zurückgenommen."
        : "Dokument wurde aktualisiert.",
  }
}

export async function deleteSmsDocument(
  _: SmsDocumentActionState,
  formData: FormData
): Promise<SmsDocumentActionState> {
  const parsed = deleteSmsDocumentSchema.safeParse({
    documentId: formData.get("documentId"),
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()
  if (!userId) {
    return { success: false, message: "Nicht angemeldet." }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zum Löschen von SMS-Dokumenten.",
    }
  }

  const [current] = await db
    .select({
      organizationId: smsDocuments.organizationId,
      category: smsDocuments.category,
      title: smsDocuments.title,
      visibility: smsDocuments.visibility,
    })
    .from(smsDocuments)
    .where(eq(smsDocuments.id, parsed.data.documentId))
    .limit(1)

  if (!current) {
    return { success: false, message: "Dokument wurde nicht gefunden." }
  }

  // Demo: Ein oeffentliches Dokument bleibt, wie es ist.
  if (isDemoMode() && current.visibility === "public") {
    return demoBlockedResult("publication")
  }

  // Anhaenge zuerst aus dem Speicher entfernen, dann Zeilen und Dokument in
  // einer Transaktion — dasselbe Muster wie beim Hard Delete einer Meldung
  // (lib/actions/reports.ts). Der Fremdschluessel auf sms_document_id hat
  // bewusst kein Cascade, damit ein vergessener Pfad hier laut scheitert,
  // statt Dateien im Blob-Speicher verwaisen zu lassen.
  const attachmentRows = await db
    .select({ storageKey: attachments.storageKey })
    .from(attachments)
    .where(eq(attachments.smsDocumentId, parsed.data.documentId))

  for (const row of attachmentRows) {
    try {
      // Fehlende Dateien behandelt die Storage-Schicht als No-op
      // (provider-neutral); nur echte Speicherfehler brechen hier ab.
      await deleteStoredFile(row.storageKey)
    } catch {
      return {
        success: false,
        message:
          "Ein Anhang konnte im Speicher nicht gelöscht werden. Das Dokument wurde nicht gelöscht. Bitte später erneut versuchen.",
      }
    }
  }

  await db.transaction(async (tx) => {
    await tx
      .delete(attachments)
      .where(eq(attachments.smsDocumentId, parsed.data.documentId))
    await tx.delete(smsDocuments).where(eq(smsDocuments.id, parsed.data.documentId))
  })

  await logAuditEvent({
    organizationId: current.organizationId,
    clerkUserId: userId,
    action: "SMS_DOCUMENT_DELETED",
    resourceType: "sms_document",
    resourceId: parsed.data.documentId,
    changes: {
      title: current.title,
      category: current.category,
      visibility: current.visibility,
      attachmentCount: attachmentRows.length,
    },
  })

  revalidatePath(DOCUMENTS_PATH)
  revalidatePath(COMMUNICATIONS_PATH)

  return { success: true, message: "Dokument wurde gelöscht." }
}

// Vorbefüllung der Protokollvorlage mit deterministischen PAOLO-Stammdaten
// (Variante A). Schreibt NICHTS in die Datenbank — liefert nur den gerenderten
// Markdown-Text zurück; die Übernahme ins Inhaltsfeld (nur bei leerem Feld)
// entscheidet der Client. Kein KI-Schritt, keine Aggregation.
export async function prefillMeetingMinutes(): Promise<PrefillMeetingMinutesResult> {
  const { userId } = await appAuth()
  if (!userId) {
    return { success: false, message: "Nicht angemeldet." }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return {
      success: false,
      message: "Keine Berechtigung zum Vorbefüllen.",
    }
  }

  const template = SMS_DOCUMENT_TEMPLATES.find(
    (t) => t.category === "safety_meeting_minutes"
  )
  if (!template) {
    return {
      success: false,
      message: "Keine Protokollvorlage vorhanden.",
    }
  }

  const data = await buildMeetingMinutesData()
  if (!data) {
    return { success: false, message: "Organisation nicht gefunden." }
  }

  return { success: true, content: renderTemplate(template.content, data) }
}
