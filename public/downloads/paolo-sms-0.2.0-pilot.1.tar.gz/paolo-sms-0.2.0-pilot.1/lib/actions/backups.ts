"use server"

import { revalidatePath } from "next/cache"

import { auditBackupEvent } from "@/lib/backup/audit"
import { BackupAuthorizationError, requireGlobalAdmin } from "@/lib/backup/authorization"
import { createBackup } from "@/lib/backup/service"
import { applyBackupRetentionAndAudit } from "@/lib/backup/retention"
import { demoBlockedResult, isDemoMode } from "@/lib/demo/mode"

export type CreateBackupState = { success: boolean; message: string }

export async function createBackupAction(previousState: CreateBackupState): Promise<CreateBackupState> {
  if (isDemoMode()) return demoBlockedResult("generic")
  void previousState
  let userId: string
  try {
    userId = await requireGlobalAdmin()
  } catch (error) {
    if (error instanceof BackupAuthorizationError) {
      return { success: false, message: error.reason === "unauthenticated" ? "Nicht angemeldet." : "Keine Berechtigung." }
    }
    throw error
  }

  try {
    const manifest = await createBackup(userId)
    await auditBackupEvent({
      userId,
      backupId: manifest.backupId,
      action: "BACKUP_CREATED",
      changes: { engine: manifest.engine, fileSize: manifest.fileSize, sha256: manifest.sha256, encryption: "age", attachmentsIncluded: false },
    })
    await applyBackupRetentionAndAudit({ backupId: manifest.backupId, userId })
    revalidatePath("/dashboard/admin/backup")
    return { success: true, message: "Backup wurde erfolgreich erstellt." }
  } catch (error) {
    console.error("[backup] Backup creation failed:", error)
    return { success: false, message: "Backup konnte nicht erstellt werden. Details wurden serverseitig protokolliert." }
  }
}
