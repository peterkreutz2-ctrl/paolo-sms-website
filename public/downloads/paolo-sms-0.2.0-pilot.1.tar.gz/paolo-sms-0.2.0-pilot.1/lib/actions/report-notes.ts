"use server"

import { appAuth } from "@/lib/auth"
import { and, eq, isNull } from "drizzle-orm"
import { revalidatePath } from "next/cache"

import { logAuditEvent } from "@/lib/audit"
import { getCurrentUserRoles } from "@/lib/auth/user-roles"
import { hasSafetyEditRole } from "@/lib/constants/roles"
import { markAnonymizationNeedsReview } from "@/lib/reports/anonymization-status"
import { db } from "@/lib/db"
import { reportNotes, reports } from "@/lib/db/schema"
import { createReportNoteSchema } from "@/lib/validations/report-notes"

export type CreateReportNoteState = {
  success: boolean
  message: string
}

export async function createReportNote(
  _: CreateReportNoteState,
  formData: FormData
): Promise<CreateReportNoteState> {
  const parsed = createReportNoteSchema.safeParse({
    reportId: formData.get("reportId"),
    noteType: formData.get("noteType"),
    content: formData.get("content"),
  })

  if (!parsed.success) {
    return {
      success: false,
      message: parsed.error.issues[0]?.message ?? "Ungültige Eingabe.",
    }
  }

  const { userId } = await appAuth()
  if (!userId) {
    return { success: false, message: "Nicht angemeldet." }
  }

  const roleKeys = await getCurrentUserRoles()
  if (!hasSafetyEditRole(roleKeys)) {
    return { success: false, message: "Keine Berechtigung zum Erstellen von Notizen." }
  }

  const [report] = await db
    .select({
      organizationId: reports.organizationId,
      shortDescription: reports.shortDescription,
    })
    .from(reports)
    .where(and(eq(reports.id, parsed.data.reportId), isNull(reports.deletedAt)))
    .limit(1)

  if (!report) {
    return { success: false, message: "Meldung wurde nicht gefunden." }
  }

  // Insert und Reset ("completed" -> "needs_review") laufen atomar in
  // derselben Transaktion: schlaegt der Reset isoliert fehl, darf die neue
  // Notiz nicht ohne diesen Reset bestehen bleiben.
  const [note] = await db.transaction(async (tx) => {
    const [inserted] = await tx
      .insert(reportNotes)
      .values({
        organizationId: report.organizationId,
        reportId: parsed.data.reportId,
        authorClerkUserId: userId,
        noteType: parsed.data.noteType,
        content: parsed.data.content,
      })
      .returning()

    // Eine neue Notiz kann erneut Personenbezug einbringen — bereits als
    // vollstaendig geprueft bestaetigte Meldungen muessen dann erneut
    // geprueft werden.
    await markAnonymizationNeedsReview(parsed.data.reportId, tx)

    return [inserted]
  })

  await logAuditEvent({
    organizationId: report.organizationId,
    clerkUserId: userId,
    action: "REPORT_NOTE_CREATED",
    resourceType: "report_note",
    resourceId: note.id,
    changes: {
      reportId: parsed.data.reportId,
      noteType: parsed.data.noteType,
      shortDescription: report.shortDescription,
    },
  })

  revalidatePath(`/dashboard/reports/${parsed.data.reportId}`)

  return { success: true, message: "Notiz wurde gespeichert." }
}
