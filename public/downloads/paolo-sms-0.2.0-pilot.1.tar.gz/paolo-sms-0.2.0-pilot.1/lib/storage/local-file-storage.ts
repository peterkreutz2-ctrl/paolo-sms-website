import { createReadStream } from "node:fs"
import { mkdir, stat, unlink, writeFile } from "node:fs/promises"
import path from "node:path"
import { Readable } from "node:stream"

import type {
  DownloadFileResult,
  StorageProvider,
  UploadFileOptions,
  UploadFileResult,
} from "./storage-provider"

const LOCAL_FILE_PROVIDER = "local_file"

/**
 * Speichert Anhaenge serverseitig im Dateisystem (z. B. auf einem Docker-Volume).
 * Es gibt bewusst KEINE oeffentlichen Direktlinks — der Download laeuft weiterhin
 * ueber die geschuetzte Download-Route, die downloadFile(storageKey) nutzt.
 */
export class LocalFileStorageProvider implements StorageProvider {
  private readonly baseDir: string

  constructor(baseDir: string) {
    if (!baseDir || !baseDir.trim()) {
      throw new Error(
        "LOCAL_STORAGE_DIR ist nicht gesetzt. Bitte ein Speicherverzeichnis konfigurieren."
      )
    }
    this.baseDir = path.resolve(baseDir)
  }

  /**
   * Loest einen storageKey sicher innerhalb von baseDir auf und verhindert
   * Path-Traversal (z. B. "../"), absolute Pfade und Null-Bytes.
   */
  private resolveSafePath(storageKey: string): string {
    if (!storageKey || storageKey.includes("\0")) {
      throw new Error("Ungueltiger Speicher-Schluessel.")
    }
    const target = path.resolve(this.baseDir, storageKey)
    const relative = path.relative(this.baseDir, target)
    if (
      relative === "" ||
      relative.startsWith("..") ||
      path.isAbsolute(relative)
    ) {
      throw new Error("Ungueltiger Speicher-Schluessel (Pfad ausserhalb des Speichers).")
    }
    return target
  }

  async uploadFile(
    file: File,
    options: UploadFileOptions
  ): Promise<UploadFileResult> {
    const absolutePath = this.resolveSafePath(options.storagePath)
    await mkdir(path.dirname(absolutePath), { recursive: true })

    const bytes = Buffer.from(await file.arrayBuffer())
    await writeFile(absolutePath, bytes)

    return {
      storageProvider: LOCAL_FILE_PROVIDER,
      storageKey: options.storagePath,
      // Kein oeffentlicher Direktlink: nur ein Marker. Der Zugriff erfolgt
      // ausschliesslich ueber die geschuetzte Download-Route.
      publicUrl: `local://${options.storagePath}`,
    }
  }

  async downloadFile(storageKey: string): Promise<DownloadFileResult | null> {
    let absolutePath: string
    try {
      absolutePath = this.resolveSafePath(storageKey)
    } catch {
      return null
    }

    try {
      const stats = await stat(absolutePath)
      if (!stats.isFile()) {
        return null
      }
    } catch {
      // Datei nicht vorhanden -> wie beim Blob-Provider: null
      return null
    }

    const nodeStream = createReadStream(absolutePath)
    const webStream = Readable.toWeb(
      nodeStream
    ) as unknown as ReadableStream<Uint8Array>

    return {
      stream: webStream,
      // Der MIME-Typ wird in der Download-Route aus der DB (attachment.mimeType)
      // bevorzugt; hier nur ein neutraler Fallback.
      contentType: "application/octet-stream",
    }
  }

  async deleteFile(storageKey: string): Promise<void> {
    const absolutePath = this.resolveSafePath(storageKey)
    try {
      await unlink(absolutePath)
    } catch (error: unknown) {
      // Fehlt die Datei bereits, ist das Loeschen ein No-op.
      if (
        error instanceof Error &&
        (error as NodeJS.ErrnoException).code === "ENOENT"
      ) {
        return
      }
      throw error
    }
  }
}
