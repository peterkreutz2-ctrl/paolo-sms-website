import { LocalFileStorageProvider } from "./local-file-storage"
import { VercelBlobStorageProvider } from "./vercel-blob-storage"
import type {
  DownloadFileResult,
  StorageProvider,
  UploadFileOptions,
} from "./storage-provider"

const DEFAULT_LOCAL_STORAGE_DIR = "/app/storage"

// Provider per Env auswaehlbar; Default bleibt Vercel Blob, damit bestehende
// Installationen unveraendert funktionieren.
function createStorageProvider(): StorageProvider {
  const provider = process.env.STORAGE_PROVIDER ?? "vercel-blob"
  switch (provider) {
    case "vercel-blob":
      return new VercelBlobStorageProvider()
    case "local":
      return new LocalFileStorageProvider(
        process.env.LOCAL_STORAGE_DIR ?? DEFAULT_LOCAL_STORAGE_DIR
      )
    default:
      throw new Error(
        `Unbekannter STORAGE_PROVIDER: "${provider}". Erlaubt: "vercel-blob" oder "local".`
      )
  }
}

const storageProvider = createStorageProvider()

export async function uploadFile(file: File, options: UploadFileOptions) {
  // TODO(attachments): Add client-side direct uploads to avoid routing large files through the server.
  // TODO(attachments): Add multipart uploads for large files (especially future video support).
  // TODO(attachments): Add upload progress reporting in the dashboard UI.
  // TODO(attachments): Integrate malware scanning before finalizing attachment records.
  // TODO(attachments): Enforce stricter per-file access controls with signed URLs.
  return storageProvider.uploadFile(file, options)
}

export async function downloadFile(
  storageKey: string
): Promise<DownloadFileResult | null> {
  return storageProvider.downloadFile(storageKey)
}

export async function deleteStoredFile(storageKey: string): Promise<void> {
  return storageProvider.deleteFile(storageKey)
}
