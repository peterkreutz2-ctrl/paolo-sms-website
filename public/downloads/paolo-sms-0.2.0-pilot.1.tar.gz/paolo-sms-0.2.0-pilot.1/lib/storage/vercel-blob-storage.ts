import { BlobNotFoundError, del, get, put } from "@vercel/blob"

import type {
  DownloadFileResult,
  StorageProvider,
  UploadFileOptions,
  UploadFileResult,
} from "./storage-provider"

const VERCEL_BLOB_PROVIDER = "vercel_blob"

// Kapselt die Vercel-Blob-spezifische "not found"-Erkennung in der Storage-Schicht,
// damit die Action-Schicht @vercel/blob nicht kennen muss.
function isBlobNotFoundError(error: unknown): boolean {
  return (
    error instanceof BlobNotFoundError ||
    (error instanceof Error && error.name === "BlobNotFoundError")
  )
}

export class VercelBlobStorageProvider implements StorageProvider {
  async uploadFile(
    file: File,
    options: UploadFileOptions
  ): Promise<UploadFileResult> {
    if (!process.env.BLOB_READ_WRITE_TOKEN) {
      throw new Error("BLOB_READ_WRITE_TOKEN ist nicht gesetzt.")
    }

    const blob = await put(options.storagePath, file, {
      access: "private",
      addRandomSuffix: false,
      contentType: options.contentType,
    })

    return {
      storageProvider: VERCEL_BLOB_PROVIDER,
      storageKey: options.storagePath,
      // TODO(attachments): Private blobs should later be served through an authenticated download route or signed URL.
      publicUrl: blob.url,
    }
  }

  async getFileUrl(storageKey: string): Promise<string> {
    // TODO(attachments): Replace with provider-specific signed URLs if access control becomes stricter.
    return `https://blob.vercel-storage.com/${storageKey}`
  }

  async downloadFile(storageKey: string): Promise<DownloadFileResult | null> {
    const blob = await get(storageKey, {
      access: "private",
    })

    if (!blob || blob.statusCode !== 200 || !blob.stream) {
      return null
    }

    return {
      stream: blob.stream,
      contentType: blob.blob.contentType || "application/octet-stream",
    }
  }

  async deleteFile(storageKey: string): Promise<void> {
    if (!process.env.BLOB_READ_WRITE_TOKEN) {
      throw new Error("BLOB_READ_WRITE_TOKEN ist nicht gesetzt.")
    }
    try {
      await del(storageKey)
    } catch (error: unknown) {
      // Fehlt das Blob bereits, ist das Loeschen ein No-op — provider-neutral,
      // analog zum lokalen Provider bei ENOENT. So muss die Action-Schicht keine
      // Blob-spezifischen Fehler mehr behandeln.
      if (isBlobNotFoundError(error)) {
        return
      }
      throw error
    }
  }
}
