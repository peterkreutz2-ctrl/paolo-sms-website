export type UploadFileOptions = {
  storagePath: string
  contentType: string
}

export type UploadFileResult = {
  storageProvider: string
  storageKey: string
  publicUrl: string
}

export type DownloadFileResult = {
  stream: ReadableStream<Uint8Array>
  contentType: string
}

export interface StorageProvider {
  uploadFile(file: File, options: UploadFileOptions): Promise<UploadFileResult>
  getFileUrl?(storageKey: string): Promise<string> | string
  downloadFile(storageKey: string): Promise<DownloadFileResult | null>
  deleteFile(storageKey: string): Promise<void>
}
