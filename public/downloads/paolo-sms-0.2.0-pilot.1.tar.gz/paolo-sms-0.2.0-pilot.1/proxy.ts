export { authProxy as proxy } from "@/lib/auth/proxy"

export const config = {
  matcher: [
    "/((?!_next|.*\\..*).*)",
    "/",
    "/(api|trpc)(.*)",
  ],
}
