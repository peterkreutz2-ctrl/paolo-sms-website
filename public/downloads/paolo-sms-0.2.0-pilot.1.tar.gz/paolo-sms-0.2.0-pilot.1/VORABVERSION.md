# Vorabversion – nicht für den Produktivbetrieb freigegeben

Diese Version von PAOLO SMS ist eine **Vorabversion**. Sie ist **nicht für den
Produktivbetrieb freigegeben**.

## Was das bedeutet

- **Nur Testdaten.** Verwenden Sie ausschließlich Test- und Beispieldaten. Erfassen
  Sie keine echten Sicherheitsmeldungen und keine personenbezogenen Daten realer
  Personen. Für echte Betreiberdaten gelten die Voraussetzungen aus
  [`docs/production-readiness.md`](docs/production-readiness.md); sie sind für diese
  Version nicht erfüllt.
- **Noch nicht alle Sicherheits- und Betriebsprüfungen abgeschlossen.** Siehe
  [`docs/release-notes/0.2.0-pilot.1.md`](docs/release-notes/0.2.0-pilot.1.md),
  Abschnitt „Bekannte Grenzen“.
- **Keine Gewähr.** PAOLO SMS steht unter GPL-3.0-or-later (siehe `LICENSE`,
  `NOTICE`). Name und Logos sind von der Lizenzgewähr ausgenommen (`NOTICE`).

## Wie Sie die Version prüfen

- Die SHA-256 des Archivs steht in `SHA256SUMS` und auf der Download-Seite.
  `sha256sum -c SHA256SUMS` prüft das Archiv, `sha256sum -c FILES.sha256` im
  entpackten Verzeichnis jede einzelne Datei. `RELEASE.json` nennt Version und
  Quellcommit. Die Prüfsumme belegt die Unversehrtheit gegenüber dem auf
  paolo-sms.de veröffentlichten Wert; das Paket ist nicht signiert.
- Installation: [`docs/install-from-package.md`](docs/install-from-package.md).
  Update: [`docs/update-from-package.md`](docs/update-from-package.md).
  Sicherung und Wiederherstellung: [`docs/backup-restore.md`](docs/backup-restore.md).
