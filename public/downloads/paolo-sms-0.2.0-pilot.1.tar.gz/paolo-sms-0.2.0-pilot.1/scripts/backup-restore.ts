import { databaseDisplayTarget, getPgRestorePath, postgresProcessEnv } from "../lib/backup/config"
import { PG_DUMP_FORMAT } from "../lib/backup/constants"
import { loadValidBackup } from "../lib/backup/filesystem"
import { decryptBackupToTemporaryFile } from "../lib/backup/encryption"
import { runCommand } from "../lib/backup/process"
import { requireRestoreConfirmation, validateBackupId } from "../lib/backup/security"

function argument(name: string): string | undefined {
  return process.argv.slice(2).find((value) => value.startsWith(`${name}=`))?.slice(name.length + 1)
}

async function main() {
  const backupId = validateBackupId(process.argv[2] ?? "")
  const target = databaseDisplayTarget()
  console.log(`Ziel: ${target.host}/${target.database}`)
  console.warn("WARNUNG: Die Zieldatenbank wird bereinigt. Dateianhänge werden nicht wiederhergestellt.")
  requireRestoreConfirmation(target.database, argument("--confirm"))

  const { manifest, dataPath } = await loadValidBackup(backupId, true)
  if (manifest.engine !== "pg_dump" || manifest.archiveFormat !== PG_DUMP_FORMAT) {
    throw new Error("Backup ist kein unterstütztes pg_dump-Custom-Format.")
  }

  const decrypted = await decryptBackupToTemporaryFile({ manifest, encryptedPath: dataPath, identityPath: argument("--identity") })
  try {
    await runCommand(getPgRestorePath(), [
      "--clean",
      "--if-exists",
      "--no-owner",
      "--no-privileges",
      "--single-transaction",
      "--exit-on-error",
      // pg_restore verlangt -d oder -f ausdruecklich; Host, Port und Zugangsdaten
      // kommen aus postgresProcessEnv(). Ohne --dbname bricht es sofort ab.
      `--dbname=${target.database}`,
      decrypted.path,
    ], { env: postgresProcessEnv() })
  } finally {
    await decrypted.cleanup()
  }
  console.log(`Restore ${backupId} abgeschlossen. Anwendung und Datenbank jetzt fachlich prüfen.`)
}

main().catch((error) => {
  console.error(`[backup:restore] ${error instanceof Error ? error.message : "Unbekannter Fehler."}`)
  process.exitCode = 1
})
