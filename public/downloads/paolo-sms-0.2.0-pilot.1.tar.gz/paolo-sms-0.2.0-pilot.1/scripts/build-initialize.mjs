import { mkdir, readFile } from "node:fs/promises"
import { dirname } from "node:path"
import { fileURLToPath } from "node:url"

import { build } from "esbuild"

const root = new URL("../", import.meta.url)
const outputDirectory = new URL("build/", root)
await mkdir(outputDirectory, { recursive: true })
// Betreiberwerkzeuge als eigenstaendige Einzeldateien. TypeScript-Quellen
// (Sicherung und Wiederherstellung) werden zu .mjs gebuendelt; das Image enthaelt
// weder tsx noch den Quellbaum.
for (const sourceName of [
  "initialize-installation.mjs",
  "operator-data.mjs",
  "backup-create.ts",
  "backup-restore.ts",
  "backup-restore-data.ts",
]) {
  const entryPoint = fileURLToPath(new URL(`scripts/${sourceName}`, root))
  await build({
    stdin: {
      contents: await readFile(entryPoint, "utf8"),
      resolveDir: dirname(entryPoint),
      sourcefile: sourceName,
      loader: sourceName.endsWith(".ts") ? "ts" : "js",
    },
    outfile: fileURLToPath(new URL(sourceName.replace(/\.ts$/, ".mjs"), outputDirectory)),
    bundle: true,
    platform: "node",
    format: "esm",
    target: "node22",
    // Einige gebündelte CommonJS-Abhängigkeiten (insbesondere dotenv) rufen
    // require("fs") dynamisch auf. Im ESM-Artefakt stellt createRequire dafür
    // die Node-kompatible Brücke bereit.
    banner: {
      js: "import { createRequire as __paoloCreateRequire } from 'node:module'; const require = __paoloCreateRequire(import.meta.url);",
    },
    // pg is already a complete dependency of Next's standalone runtime.
    external: ["pg"],
    logLevel: "info",
  })
}
