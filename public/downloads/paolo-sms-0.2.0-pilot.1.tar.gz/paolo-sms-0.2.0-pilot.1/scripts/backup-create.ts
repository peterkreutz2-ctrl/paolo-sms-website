// Erstellt ein verschluesseltes Datenbank-Backup ohne Weboberflaeche und ohne
// HTTP-Cron (kein Mindestintervall). Gleicher Weg wie die Weboberflaeche und der
// Cron-Endpunkt: createBackup(), Audit-Ereignis BACKUP_CREATED, Aufbewahrungsregel.
// Gedacht fuer Sicherungen vor einem Update und fuer backup-installation.sh.
// Die Ausgabe der letzten Zeile ist `BACKUP_ID=<uuid>`.
import { auditBackupEvent } from "../lib/backup/audit"
import { createBackup } from "../lib/backup/service"
import { applyBackupRetentionAndAudit } from "../lib/backup/retention"
import { dbPool } from "../lib/db"

async function main() {
  const manifest = await createBackup("system:backup-cli")
  await auditBackupEvent({
    userId: null,
    backupId: manifest.backupId,
    action: "BACKUP_CREATED",
    changes: {
      trigger: "cli",
      engine: manifest.engine,
      fileSize: manifest.fileSize,
      sha256: manifest.sha256,
      encryption: "age",
      attachmentsIncluded: false,
    },
  })
  await applyBackupRetentionAndAudit({ backupId: manifest.backupId, userId: null })
  console.log(`Backup erstellt: ${manifest.databaseFileName} (${manifest.fileSize} Bytes, ${manifest.engine})`)
  console.log(`BACKUP_ID=${manifest.backupId}`)
}

main()
  .catch((error) => {
    console.error(`[backup:create] ${error instanceof Error ? error.message : "Unbekannter Fehler."}`)
    process.exitCode = 1
  })
  .finally(() => dbPool.end().catch(() => undefined))
