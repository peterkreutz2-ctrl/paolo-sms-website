#!/bin/sh
# Explicit operator entry point; never invoked by application startup.
set -eu

if [ -z "${DATABASE_URL:-}" ]; then
  printf '%s\n' 'DATABASE_URL must identify the database approved for migration.' >&2
  exit 1
fi

# Resolve relative includes independently of the caller's working directory.
script_dir=$(CDPATH= cd "$(dirname "$0")" && pwd)
# Hide command tags and query results, but leave warnings/errors on stderr.
exec psql -X -q -o /dev/null -d "$DATABASE_URL" -f "$script_dir/migrate.psql"
