import { config } from "dotenv"

config({ path: ".env.local" })

import { inArray } from "drizzle-orm"

import { db } from "../lib/db"
import {
  betterAuthUsers,
  betterAuthVerifications,
  userRoles,
} from "../lib/db/schema"

const CONFIRMATION = "--confirm-reset-better-auth"

async function main() {
  if (process.env.AUTH_MODE !== "betterauth") {
    throw new Error("AUTH_MODE muss auf betterauth gesetzt sein.")
  }
  if (!process.argv.includes(CONFIRMATION)) {
    throw new Error(`Bestätigung fehlt: npm run auth:reset -- ${CONFIRMATION}`)
  }

  const result = await db.transaction(async (tx) => {
    const users = await tx.select({ id: betterAuthUsers.id }).from(betterAuthUsers)
    const userIds = users.map((user) => user.id)

    let removedRoleAssignments = 0
    if (userIds.length > 0) {
      const removedRoles = await tx
        .delete(userRoles)
        .where(inArray(userRoles.clerkUserId, userIds))
        .returning({ id: userRoles.id })
      removedRoleAssignments = removedRoles.length
    }

    // Accounts and sessions reference users with ON DELETE CASCADE.
    const removedUsers = await tx
      .delete(betterAuthUsers)
      .returning({ id: betterAuthUsers.id })
    const removedVerifications = await tx
      .delete(betterAuthVerifications)
      .returning({ id: betterAuthVerifications.id })

    return {
      users: removedUsers.length,
      roleAssignments: removedRoleAssignments,
      verifications: removedVerifications.length,
    }
  })

  console.log(
    `Better Auth zurückgesetzt: ${result.users} Benutzer, ${result.roleAssignments} Rollenzuweisungen, ${result.verifications} Verifizierungen entfernt.`
  )
}

main()
  .then(() => process.exit(0))
  .catch((error: unknown) => {
    console.error(error instanceof Error ? error.message : "Reset fehlgeschlagen.")
    process.exit(1)
  })
