import { config as loadEnv } from "dotenv"
import path from "node:path"
import pg from "pg"

import {
  databaseDisplayTarget,
  formatConnectionDetails,
  formatExternalPreview,
  inspectExternalData,
  inspectOperatorDatabase,
  OperatorDataError,
  parseOperatorArguments,
  purgeExternalData,
  requireExecutionConfirmation,
  requireNoOtherConnections,
  resetInstallationData,
  seedDemoData,
} from "./operator-data-core.mjs"

loadEnv({ path: ".env.local" })

function poolOptions(connectionString) {
  const allowSelfSigned = process.env.DATABASE_SSL_ALLOW_SELF_SIGNED === "true"
  if (!allowSelfSigned) return { connectionString, application_name: "paolo-operator-data" }
  const url = new URL(connectionString)
  url.searchParams.set("sslmode", "no-verify")
  return {
    connectionString: url.toString(),
    application_name: "paolo-operator-data",
    ssl: { rejectUnauthorized: false },
  }
}

function externalOptions() {
  return {
    storageProvider: process.env.STORAGE_PROVIDER ?? "vercel-blob",
    localStorageDir: process.env.LOCAL_STORAGE_DIR ?? "/app/storage",
    backupDir: process.env.BACKUP_DIR ?? path.resolve(process.cwd(), "backups"),
  }
}

function requireConfiguredAttachmentProvider(state, storageProvider) {
  const expected = storageProvider === "local"
    ? "local_file"
    : storageProvider === "vercel-blob"
      ? "vercel_blob"
      : null
  if (!expected) throw new OperatorDataError(`Unbekannter STORAGE_PROVIDER: ${storageProvider}`, "storage_provider")
  const mismatches = state.attachmentProviders.filter((entry) => entry.storage_provider !== expected)
  if (mismatches.length > 0) {
    throw new OperatorDataError(
      `Attachment-Datensätze verwenden einen anderen oder unbekannten Provider: ${mismatches.map((entry) => entry.storage_provider).join(", ")}.`,
      "storage_provider_mismatch",
    )
  }
}

function printDatabasePreview(target, state) {
  console.log("PAOLO Operator-Datenwerkzeug — Vorschau")
  console.log(`  Host: ${target.host}`)
  console.log(`  Datenbank: ${target.database}`)
  console.log(`  Organisation: ${state.organization.name} (${state.organization.id})`)
  console.log(`  Validierte globale Administratoren: ${state.globalAdminIds.join(", ") || "keine"}`)
  console.log(`  Weitere DB-Verbindungen: ${state.otherConnections}`)
  for (const line of formatConnectionDetails(state.otherConnectionDetails)) {
    console.log(`    ${line}`)
  }
  console.log("  Tabellen:")
  for (const [name, count] of Object.entries(state.counts)) console.log(`    ${name}: ${count}`)
}

function printExecutionHint(command, target, organizationId) {
  console.log("\nKeine Daten verändert. Ausführung nur mit:")
  console.log(
    `  --execute --confirm-database=${target.database} ` +
    `--confirm-organization-id=${organizationId} --admin-user-id=<globale-admin-id>`,
  )
  console.log(`  Unterbefehl: ${command}`)
}

function safeMessage(error, secrets) {
  let message = error instanceof Error ? error.message : "Operator-Datenwerkzeug fehlgeschlagen."
  for (const secret of secrets.filter(Boolean)) message = message.split(secret).join("[REDACTED]")
  return message
}

async function main() {
  const parsed = parseOperatorArguments(process.argv.slice(2))
  const connectionString = process.env.DATABASE_URL?.trim()
  const target = databaseDisplayTarget(connectionString)
  const pool = new pg.Pool(poolOptions(connectionString))
  const client = await pool.connect()
  try {
    const state = await inspectOperatorDatabase(client)
    printDatabasePreview(target, state)

    let external
    if (parsed.command === "reset") {
      const options = externalOptions()
      requireConfiguredAttachmentProvider(state, options.storageProvider)
      external = await inspectExternalData(options)
      for (const line of formatExternalPreview(external, options.storageProvider)) {
        console.log(`  ${line}`)
      }
    }

    if (!parsed.execute) {
      printExecutionHint(parsed.command, target, state.organization.id)
      return
    }

    const adminUserId = requireExecutionConfirmation({
      values: parsed.values,
      database: target.database,
      organizationId: state.organization.id,
    })
    requireNoOtherConnections(state.otherConnectionDetails)

    if (parsed.command === "seed") {
      const result = await seedDemoData(client, { adminUserId })
      console.log(`Spieldaten Version ${result.fixtureVersion} erfolgreich geladen.`)
      console.log(`  Meldungen: ${result.inserted.reports}`)
      console.log(`  Maßnahmen: ${result.inserted.measures}`)
      console.log(`  Notizen: ${result.inserted.reportNotes}`)
      console.log(`  Sicherheitsbesprechungen: ${result.inserted.safetyMeetings}`)
      return
    }

    const result = await resetInstallationData(client, {
      adminUserId,
      storageProvider: externalOptions().storageProvider,
      deleteExternal: () => purgeExternalData(externalOptions()),
    })
    console.log(`Installationsdaten erfolgreich zurückgesetzt (Version ${result.resetVersion}).`)
    console.log(`  Attachment-Dateien gelöscht: ${result.external.attachmentFiles}`)
    console.log(`  Backup-Dateien gelöscht: ${result.external.backupFiles}`)
  } finally {
    client.release()
    await pool.end()
  }
}

main().catch((error) => {
  const secrets = [process.env.DATABASE_URL, process.env.BLOB_READ_WRITE_TOKEN]
  console.error(safeMessage(error, secrets))
  process.exitCode = 1
})
