export const DEMO_FIXTURE_VERSION = 2

const REPORT_ID_PREFIX = "72000000-0000-4000-8000-"
const MEASURE_ID_PREFIX = "72000000-0000-4000-9000-"
const PUBLIC_CODES = [
  "Falke-12", "Adler-47", "Bussard-83", "Milan-29", "Weihe-64",
  "Turmfalke-91", "Habicht-35", "Sperber-76", "Kranich-18", "Reiher-52",
  "Storch-87", "Schwalbe-24", "Mauersegler-69", "Lerche-43", "Amsel-95",
  "Drossel-31", "Fink-74", "Meise-16", "Specht-58", "Kleiber-82",
]

function daysFrom(now, offset) {
  return new Date(now.getTime() + offset * 24 * 60 * 60 * 1000)
}

function reportId(index) {
  return `${REPORT_ID_PREFIX}${String(index).padStart(12, "0")}`
}

function measureId(index) {
  return `${MEASURE_ID_PREFIX}${String(index).padStart(12, "0")}`
}

const REPORTS = [
  {
    type: "accident", status: "in_review", priority: "critical", days: -18,
    title: "Start mit nicht vollständig eingehängtem Gurtzeug",
    detail: "Beim Vorbereiten eines Hangstarts wurde ein Verbindungspunkt am Gurtzeug übersehen. Die startende Person bemerkte die Fehlkonfiguration erst beim Lastaufbau und brach den Start mit einer Verletzung ab. Der Fall zeigt, warum ein ruhiger Partnercheck auch bei Zeitdruck nötig ist.",
    area: "hang_gliding", activity: "solo_flight", phase: "launch", launch: "hill_launch",
    injury: "serious", damage: "minor", reportable: true, probability: "2", risk: "A",
    anonymous: false, reporterRole: "witness",
    learned: "Der letzte Sicht- und Zugcheck darf nicht durch Startbereitschaft ersetzt werden.",
    suggested: "Verbindlichen Vier-Augen-Check für alle Gurtzeugverbindungen einführen.",
  },
  {
    type: "near_miss", status: "in_progress", priority: "high", days: -12,
    title: "Böe hebt Groundhandling-Schirm unerwartet an",
    detail: "Während einer Bodenübung nahm der Wind innerhalb weniger Sekunden deutlich zu. Der Schirm hob die übende Person kurz an; sie konnte kontrolliert ausleiten. Die Böigkeit war am Übungsplatz zuvor nicht gemeinsam bewertet worden.",
    area: "paragliding", activity: "basic_training", phase: "groundhandling", launch: "not_applicable",
    injury: "none", damage: "none", reportable: false, probability: "4", risk: "C",
    learned: "Beim Groundhandling zählt die Böenspitze und nicht nur der Mittelwind.",
    suggested: "Abbruchkriterien vor jeder Übungseinheit gemeinsam festlegen.",
  },
  {
    type: "accident", status: "measures_defined", priority: "high", days: -35,
    title: "Strömungsabriss in enger Landekurve",
    detail: "Im Queranflug wurde eine Kurve bei geringer Höhe stark angebremst. Der Schirm verlor einseitig Auftrieb und die Person setzte hart auf. Die Landeeinteilung war wegen mehrerer anderer Fluggeräte kurzfristig geändert worden.",
    area: "paragliding", activity: "supervised_flying", phase: "landing", launch: "hill_launch",
    injury: "minor", damage: "minor", reportable: false, probability: "3", risk: "B",
    learned: "Eine stabile Anfluggeschwindigkeit ist wichtiger als ein punktgenaues Aufsetzen.",
    suggested: "Ausweichoptionen und Abbruchpunkte im Landebriefing deutlicher behandeln.",
  },
  {
    type: "near_miss", status: "new", priority: "high", days: -4,
    title: "Seitlicher Klapper im Lee eines Geländerückens",
    detail: "Nach dem Verlassen eines Aufwindbereichs führte die Route dicht hinter einen Geländerücken. Dort klappte der Schirm großflächig ein und öffnete nach deutlichem Höhenverlust wieder. Eine sichere Ausweichhöhe war noch vorhanden.",
    area: "paragliding", activity: "cross_country", phase: "flight", launch: "hill_launch",
    injury: "none", damage: "none", reportable: false, probability: "3", risk: "B",
    learned: "Geländeabschattung muss auch bei scheinbar ruhiger Luft großzügig umflogen werden.",
    suggested: "Lokale Leebereiche in der Streckenflugvorbereitung markieren.",
  },
  {
    type: "accident", status: "closed", priority: "high", days: -210,
    publicClosedDays: -30,
    title: "Außenlandung endet in niedrigem Baum",
    detail: "Nach anhaltendem Sinken wurde spät ein kleiner Außenlandeplatz gewählt. Im Endanflug reichte der Raum für eine Korrektur nicht mehr aus und der Schirm blieb in einem niedrigen Baum hängen. Die Person konnte unverletzt geborgen werden.",
    area: "paragliding", activity: "cross_country", phase: "landing", launch: "hill_launch",
    injury: "none", damage: "minor", reportable: false, probability: "3", risk: "C",
    anonymous: false, reporterRole: "involved_pilot",
    learned: "Die Auswahl einer Außenlandefläche muss früher beginnen.",
    suggested: "Entscheidungshöhen im jährlichen Streckenflugbriefing auffrischen.",
  },
  {
    type: "near_miss", status: "measures_defined", priority: "high", days: -48,
    title: "Retterwurf nach Twist in turbulenter Thermik",
    detail: "Eine schnelle Störung entwickelte sich nach mehreren Richtungswechseln zu einem Leinentwist. Da die verbleibende Höhe für weitere Lösungsversuche nicht ausreichte, wurde das Rettungsgerät ausgelöst. Die Landung verlief ohne Verletzung.",
    area: "paragliding", activity: "safety_training", phase: "flight", launch: "hill_launch",
    injury: "none", damage: "none", reportable: false, probability: "2", risk: "B",
    learned: "Eine vorab festgelegte Entscheidungshöhe verkürzt unsichere Lösungsversuche.",
    suggested: "Retterwurf und Entscheidungshöhen im Sicherheitstraining wiederholen.",
  },
  {
    type: "hazard", status: "in_progress", priority: "medium", days: -22,
    title: "Windanzeiger am Übungshang schlecht erkennbar",
    detail: "Der untere Windanzeiger ist aus mehreren Startpositionen durch Bewuchs verdeckt. Dadurch werden wechselnde Windrichtungen erst spät erkannt. Bei zwei Schulungsstarts waren zusätzliche Abbruchkommandos nötig.",
    area: "paragliding", activity: "basic_training", phase: "pre_flight", launch: "hill_launch",
    probability: "4", risk: "D", anonymous: false, reporterRole: "flight_instructor",
    learned: "Die vorhandene Anzeige liefert nur dann Nutzen, wenn sie aus jeder Startposition sichtbar ist.",
    suggested: "Standort versetzen und einen zweiten Windsack ergänzen.",
  },
  {
    type: "observation", status: "new", priority: "low", days: -6,
    title: "Unruhe durch parallele Funkkanäle im Schulungsbetrieb",
    detail: "Während einer Ausbildungseinheit wurden zwei Funkkanäle parallel genutzt. Mehrere Anweisungen mussten wiederholt werden. Es kam zu keinem Ereignis, die zusätzliche Arbeitsbelastung war jedoch deutlich bemerkbar.",
    area: "paragliding", activity: "high_flight_training", phase: "flight", launch: "hill_launch",
    probability: "3", risk: "E", anonymous: true,
    learned: "Ein einheitlicher Funkplan reduziert Missverständnisse.",
    suggested: "Kanal und Ersatzkanal im Tagesbriefing festhalten.",
  },
  {
    type: "suggestion", status: "in_review", priority: "low", days: -28,
    title: "Materialablage vom Landeweg trennen",
    detail: "Am Rand des Landeplatzes werden Packsäcke regelmäßig in einem Bereich abgelegt, der bei stärkerem Wind als Ausweichweg dient. Eine markierte Ablagefläche könnte den Weg dauerhaft freihalten.",
    area: "paragliding", activity: "other", phase: "post_flight", launch: "not_applicable",
    probability: "2", risk: "D", anonymous: true,
    learned: "Kleine organisatorische Änderungen können Ausweichräume zuverlässig schützen.",
    suggested: "Ablagefläche markieren und im Platzbriefing erwähnen.",
  },
  {
    type: "accident", status: "in_progress", priority: "medium", days: -63,
    title: "Harte Landung nach wechselnder Windrichtung",
    detail: "Im Endanflug wechselte die Windrichtung mehrfach. Die landende Person korrigierte spät und setzte mit erhöhter Geschwindigkeit auf. Dabei entstand eine leichte Fußverletzung und geringer Materialschaden.",
    area: "paragliding", activity: "solo_flight", phase: "landing", launch: "hill_launch",
    injury: "minor", damage: "minor", reportable: false, probability: "3", risk: "C",
    learned: "Bei stark wechselnder Richtung ist eine konservative Landeeinteilung erforderlich.",
    suggested: "Alternative Landerichtung vor dem Start festlegen.",
  },
  {
    type: "near_miss", status: "closed", priority: "medium", days: -320,
    publicClosedDays: -120,
    title: "Ablenkung durch zweites Fluginstrument",
    detail: "Während der Suche nach einem geeigneten Landeplatz beanspruchte ein zusätzlich mitgeführtes Instrument wiederholt Aufmerksamkeit. Die verfügbare Höhe wurde dadurch spät erkannt; eine sichere Außenlandung gelang noch rechtzeitig.",
    area: "paragliding", activity: "cross_country", phase: "flight", launch: "hill_launch",
    injury: "none", damage: "none", reportable: false, probability: "2", risk: "C",
    learned: "Nicht benötigte Anzeigen dürfen in arbeitsintensiven Flugphasen nicht ablenken.",
    suggested: "Instrumentenkonfiguration vor dem Start vereinfachen.",
  },
  {
    type: "hazard", status: "measures_defined", priority: "critical", days: -41,
    title: "Rettungsgeräte-Kompatibilität nicht dokumentiert",
    detail: "Bei einer Materialkontrolle fehlte für mehrere Kombinationen aus Gurtzeug und Rettungsgerät ein dokumentierter Kompatibilitätsnachweis. Ein Fehlverhalten wurde nicht beobachtet, die sichere Auslösung kann ohne Prüfung aber nicht vorausgesetzt werden.",
    area: "paragliding", activity: "other_training", phase: "pre_flight", launch: "not_applicable",
    probability: "4", risk: "B", anonymous: false, reporterRole: "flight_instructor",
    learned: "Eine vollständige Inventarliste ersetzt keine dokumentierte Einbau- und Kompatibilitätsprüfung.",
    suggested: "Alle Kombinationen prüfen, kennzeichnen und zentral dokumentieren.",
  },
  {
    type: "observation", status: "closed", priority: "low", days: -430,
    publicClosedDays: -45,
    title: "Startabbrüche werden selten im Tagesprotokoll notiert",
    detail: "In mehreren Ausbildungstagen wurden Startabbrüche besprochen, aber nicht im Tagesprotokoll festgehalten. Dadurch fehlen Hinweise auf wiederkehrende Ursachen wie Seitenwind oder unvollständige Startchecks.",
    area: "paragliding", activity: "basic_training", phase: "launch", launch: "hill_launch",
    probability: "3", risk: "E", anonymous: true,
    learned: "Auch folgenlose Abbrüche liefern Hinweise auf systematische Schwachstellen.",
    suggested: "Eine kurze Abbruchkategorie in das Tagesprotokoll aufnehmen.",
  },
  {
    type: "suggestion", status: "measures_defined", priority: "medium", days: -75,
    title: "Entscheidungskarte für böige Bedingungen einführen",
    detail: "Eine kompakte Entscheidungskarte könnte Windmittel, Böenspitze, Geländeeinfluss und Erfahrungsstand vor Übungen gemeinsam sichtbar machen. Sie soll das Briefing unterstützen, nicht die Entscheidung der verantwortlichen Person ersetzen.",
    area: "paragliding", activity: "supervised_flying", phase: "pre_flight", launch: "hill_launch",
    probability: "4", risk: "D", anonymous: false, reporterRole: "helper",
    learned: "Ein gemeinsames Schema verbessert die Nachvollziehbarkeit von Go/No-Go-Entscheidungen.",
    suggested: "Karte in zwei Gruppen erproben und nach vier Wochen auswerten.",
  },
  {
    type: "other", status: "in_review", priority: "medium", days: -16,
    title: "Rückfrage zur Meldung von Außenlandungen",
    detail: "Ein Mitglied fragt, welche Außenlandungen als sicherheitsrelevante Beobachtung gemeldet werden sollen. Gewünscht ist eine kurze Orientierung, die ausdrücklich auch Beinahe-Ereignisse und Lernerfahrungen einschließt.",
    area: "paragliding", activity: "cross_country", phase: "post_flight", launch: "not_applicable",
    probability: null, risk: null, anonymous: false, reporterRole: "involved_pilot",
    learned: "Unklare Meldekriterien können wertvolle Hinweise verhindern.",
    suggested: "Kurze Beispiele in die interne Anleitung aufnehmen.",
  },
  {
    type: "near_miss", status: "in_progress", priority: "high", days: -9,
    title: "Startabbruch bei starkem Seitenwind zu spät eingeleitet",
    detail: "Nach einer längeren Wartephase wurde ein Startversuch trotz wechselnder Seitenwindanteile begonnen. Der Schirm stieg schräg und der Abbruch erfolgte erst nach mehreren Korrekturen. Die Person blieb unverletzt.",
    area: "paragliding", activity: "supervised_flying", phase: "launch", launch: "hill_launch",
    injury: "none", damage: "none", reportable: false, probability: "4", risk: "C",
    learned: "Abbruchkriterien müssen vor dem Aufziehen feststehen.",
    suggested: "Seitenwindgrenze und eindeutiges Abbruchkommando im Briefing festlegen.",
  },
  {
    type: "accident", status: "closed", priority: "medium", days: -510,
    publicClosedDays: -200,
    title: "Flügelspitze berührt bei Drachenlandung den Boden",
    detail: "Beim Ausdrücken in der Landung senkte sich eine Flügelspitze und berührte den Boden. Das Fluggerät drehte ein; die pilotierende Person zog sich eine leichte Handverletzung zu. Die Anfluggeschwindigkeit war zuvor stabil.",
    area: "hang_gliding", activity: "solo_flight", phase: "landing", launch: "hill_launch",
    injury: "minor", damage: "minor", reportable: false, probability: "2", risk: "D",
    learned: "Das symmetrische Ausdrücken sollte nach längeren Flugpausen gezielt geübt werden.",
    suggested: "Landetraining vor dem Saisonstart anbieten.",
  },
  {
    type: "hazard", status: "new", priority: "medium", days: -3,
    title: "Schleppseil kreuzt zeitweise den Rückholweg",
    detail: "Beim Rückholen des Windenseils kreuzt das Seil einen häufig genutzten Fußweg. Eine Person musste warten, bis das Seil vollständig abgelegt war. Markierungen und eine klare Sperrregel fehlen.",
    area: "paragliding", activity: "basic_training", phase: "launch", launch: "winch_launch",
    probability: "4", risk: "D", anonymous: false, reporterRole: "winch_operator",
    learned: "Der Rückholvorgang braucht dieselbe eindeutige Platzorganisation wie der Start.",
    suggested: "Weg während des Rückholens sperren und sichtbar kennzeichnen.",
  },
  {
    type: "accident", status: "hidden", priority: "high", days: -145,
    publicClosedDays: -130,
    title: "Unkontrollierte Pendelbewegung nach Klapper",
    detail: "In geringer Höhe führte eine asymmetrische Störung zu einer deutlichen Pendelbewegung. Die Kappe öffnete, bevor ein Retterwurf nötig wurde; bei der anschließenden Hangberührung entstand eine leichte Verletzung. Der Fall wurde nach Abschluss ausgeblendet.",
    area: "paragliding", activity: "solo_flight", phase: "flight", launch: "hill_launch",
    injury: "minor", damage: "major", reportable: false, probability: "2", risk: "B",
    learned: "Geländeabstand schafft Zeit für eine kontrollierte Reaktion.",
    suggested: "Mindestabstände im lokalen Sicherheitsbriefing konkretisieren.",
  },
  {
    type: "other", status: "closed", priority: "low", days: -390,
    publicClosedDays: -10,
    title: "Positive Rückmeldung zum gemeinsamen Startcheck",
    detail: "Nach Einführung eines kurzen gegenseitigen Startchecks wurden in mehreren Wochen zwei falsch geführte Leinen und ein offener Beingurt vor dem Aufziehen erkannt. Die Rückmeldung dokumentiert die Wirkung der Maßnahme.",
    area: "paragliding", activity: "basic_training", phase: "pre_flight", launch: "hill_launch",
    probability: "3", risk: "E", anonymous: true,
    learned: "Ein kurzer standardisierter Check wird akzeptiert und verhindert Fehler.",
    suggested: "Ablauf beibehalten und nach der Saison erneut bewerten.",
  },
]

const MEASURES = [
  [1, 1, "Vier-Augen-Check einführen", "Checkkarte erstellen und vor jedem Start anwenden.", "Ausbildungsleitung", "in_progress", 14],
  [2, 2, "Groundhandling-Abbruchkriterien festlegen", "Wind- und Böengrenzen für Übungsgruppen dokumentieren.", "Safety Manager", "open", -3],
  [3, 3, "Landebriefing überarbeiten", "Ausweichflächen und stabile Mindestfahrt ergänzen.", "Fluglehrerteam", "in_progress", 21],
  [4, 4, "Leebereiche in Karte markieren", "Lokale Gefahrenkarte im Briefing aktualisieren.", "Geländereferat", "open", 30],
  [5, 5, "Entscheidungshöhen trainieren", "Streckenflugabend mit Fallbeispielen durchführen.", "Sportwart", "completed", -120],
  [6, 6, "Rettertraining anbieten", "Praxisabend mit gepacktem Übungsretter organisieren.", "Ausbildungsleitung", "completed", -20],
  [7, 7, "Zweiten Windsack montieren", "Sichtbaren Standort am unteren Übungshang auswählen.", "Geländewart", "open", -7],
  [8, 9, "Ablagefläche markieren", "Weg und Materialzone farblich voneinander trennen.", "Platzdienst", "discarded", 10],
  [9, 12, "Kompatibilitätsprüfung abschließen", "Alle dokumentierten Gerätekombinationen systematisch prüfen.", "Materialwart", "in_progress", 7],
  [10, 18, "Rückholweg absichern", "Mobile Hinweisschilder und Sperrablauf beschaffen.", "Windenführerteam", "open", 5],
]

const NOTES = [
  [2, "internal_note", "Die Böenspitzen lagen deutlich über dem zuvor besprochenen Übungsbereich."],
  [3, "witness_statement", "Die Landekurve wurde erst nach einer kurzfristigen Verkehrssituation enger geflogen."],
  [4, "supplement", "Die Gefahrenkarte zeigt den betroffenen Leebereich bislang nicht."],
  [5, "reporter_followup", "Die Bergung verlief ruhig; es waren keine Einsatzkräfte erforderlich."],
  [7, "internal_note", "Ein alternativer Standort für den zweiten Windsack ist bereits vermessen."],
  [12, "supplement", "Für zwei Gerätekombinationen liegen inzwischen Herstellerbestätigungen vor."],
]

export function createDemoFixture(now = new Date()) {
  const reports = REPORTS.map((source, index) => {
    const createdAt = daysFrom(now, source.days + 1)
    const closed = source.status === "closed" || source.status === "hidden"
    const deleted = source.status === "hidden"
    return {
      id: reportId(index + 1),
      reportType: source.type,
      status: source.status,
      priority: source.priority,
      shortDescription: `[Spieldaten] ${source.title}`,
      detailedDescription: source.detail,
      isAnonymous: source.anonymous ?? true,
      occurredAt: daysFrom(now, source.days),
      locationText: "Fiktives Fluggelände",
      reporterLessonsLearned: source.learned,
      reporterSuggestedMeasures: source.suggested,
      sourceChannel: "demo",
      activityArea: source.area,
      activityType: source.activity,
      flightPhase: source.phase,
      launchType: source.launch,
      injurySeverity: source.injury ?? null,
      damageSeverity: source.damage ?? null,
      isReportableAccident: source.reportable ?? null,
      riskProbability: source.probability,
      riskSeverity: source.risk,
      reporterName: source.anonymous === false ? `Beispielperson ${index + 1}` : null,
      reporterRole: source.anonymous === false ? source.reporterRole : null,
      reporterContact: source.anonymous === false ? `beispiel-${index + 1}@example.invalid` : null,
      publicCode: PUBLIC_CODES[index],
      publicClosedAt: source.publicClosedDays === undefined
        ? null
        : daysFrom(now, source.publicClosedDays),
      createdAt,
      updatedAt: createdAt,
      deletedAt: deleted ? daysFrom(now, -120) : null,
      deletedBy: deleted ? "demo-fixture" : null,
      deleteReason: deleted ? "Ausgeblendeter Spieldatenfall" : null,
      retentionReviewEligibleAt: closed
        ? daysFrom(now, source.days + (deleted ? 20 : 30))
        : null,
    }
  })

  const measures = MEASURES.map(([index, reportIndex, title, description, assignedToText, status, dueDays]) => ({
    ...(() => {
      const linkedReport = reports[reportIndex - 1]
      return {
        createdAt: daysFrom(linkedReport.occurredAt, 2),
        updatedAt: daysFrom(now, dueDays < 0 ? dueDays : -2),
      }
    })(),
    id: measureId(index),
    reportId: reportId(reportIndex),
    title: `[Spieldaten] ${title}`,
    description,
    assignedToText,
    status,
    dueDate: daysFrom(now, dueDays),
  }))

  const notes = NOTES.map(([reportIndex, noteType, content], index) => ({
    id: `${REPORT_ID_PREFIX}${String(101 + index).padStart(12, "0")}`,
    reportId: reportId(reportIndex),
    noteType,
    content: `[Spieldaten] ${content}`,
    createdAt: daysFrom(now, -24 + index),
  }))

  const meetings = [
    {
      id: `${REPORT_ID_PREFIX}000000000201`,
      meetingDate: daysFrom(now, -690).toISOString().slice(0, 10),
      title: "[Spieldaten] Rückblick auf die Vorsaison",
      notes: "Synthetische Sicherheitsbesprechung zur Einführung des Meldewegs.",
      createdAt: daysFrom(now, -690),
    },
    {
      id: `${REPORT_ID_PREFIX}000000000202`,
      meetingDate: daysFrom(now, -335).toISOString().slice(0, 10),
      title: "[Spieldaten] Jährliche Sicherheitsbesprechung",
      notes: "Synthetische Besprechung zu Startchecks, Landeeinteilung und Windgrenzen.",
      createdAt: daysFrom(now, -335),
    },
  ]

  return { reports, measures, notes, meetings }
}

export function createDemoSeedQueries({ organizationId, adminUserId, now = new Date() }) {
  const fixture = createDemoFixture(now)
  const queries = []
  for (const report of fixture.reports) {
    queries.push({
      text: `INSERT INTO reports (
        id, organization_id, report_type, status, priority, short_description,
        detailed_description, is_anonymous, occurred_at, location_text,
        reporter_lessons_learned, reporter_suggested_measures, source_channel,
        activity_area, activity_type, flight_phase, launch_type, injury_severity,
        damage_severity, is_reportable_accident, risk_probability, risk_severity,
        reporter_name, reporter_role, reporter_contact, public_code,
        public_closed_at, created_at, updated_at, deleted_at, deleted_by,
        delete_reason, retention_review_eligible_at
      ) VALUES (
        $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,
        $20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33
      )`,
      values: [
        report.id, organizationId, report.reportType, report.status, report.priority,
        report.shortDescription, report.detailedDescription, report.isAnonymous,
        report.occurredAt, report.locationText, report.reporterLessonsLearned,
        report.reporterSuggestedMeasures, report.sourceChannel, report.activityArea,
        report.activityType, report.flightPhase, report.launchType, report.injurySeverity,
        report.damageSeverity, report.isReportableAccident, report.riskProbability,
        report.riskSeverity, report.reporterName, report.reporterRole,
        report.reporterContact, report.publicCode, report.publicClosedAt,
        report.createdAt, report.updatedAt, report.deletedAt, report.deletedBy,
        report.deleteReason, report.retentionReviewEligibleAt,
      ],
    })
  }
  for (const measure of fixture.measures) {
    queries.push({
      text: `INSERT INTO measures (id, report_id, title, description, assigned_to_text, status, due_date, created_at, updated_at)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
      values: [measure.id, measure.reportId, measure.title, measure.description, measure.assignedToText, measure.status, measure.dueDate, measure.createdAt, measure.updatedAt],
    })
  }
  for (const note of fixture.notes) {
    queries.push({
      text: `INSERT INTO report_notes (id, organization_id, report_id, author_clerk_user_id, note_type, content, created_at)
        VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      values: [note.id, organizationId, note.reportId, adminUserId, note.noteType, note.content, note.createdAt],
    })
  }
  for (const meeting of fixture.meetings) {
    queries.push({
      text: `INSERT INTO safety_meetings (id, organization_id, meeting_date, title, notes, created_by_clerk_user_id, created_at)
        VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      values: [meeting.id, organizationId, meeting.meetingDate, meeting.title, meeting.notes, adminUserId, meeting.createdAt],
    })
  }
  const inserted = {
    reports: fixture.reports.length,
    measures: fixture.measures.length,
    reportNotes: fixture.notes.length,
    safetyMeetings: fixture.meetings.length,
  }
  queries.push({
    text: `INSERT INTO audit_logs (organization_id, clerk_user_id, action, resource_type, resource_id, changes, created_at)
      VALUES ($1,$2,'DEMO_DATA_LOADED','organization',$1,$3::jsonb,$4)`,
    values: [organizationId, adminUserId, JSON.stringify({ fixtureVersion: DEMO_FIXTURE_VERSION, ...inserted }), now],
  })
  return { fixture, inserted, queries }
}
