#!/bin/sh
# Update einer Installation im Quellpaket-Layout auf das Release, in dessen
# Verzeichnis dieses Skript liegt. Ablauf und Rueckfallgrenzen:
# docs/update-from-package.md.
#
#   1. Paket pruefen (SHA256SUMS), nach <PAOLO_HOME>/releases/ entpacken
#   2. sh <PAOLO_HOME>/releases/<neu>/scripts/deploy/paolo-update.sh [--prod] [--dry-run] [--skip-backup] [--yes]
#
# Reihenfolge (Migration VOR der Aktivierung des neuen Anwendungscodes):
#   Pruefung -> Sicherung -> Rueckfall-Image sichern -> neues Image bauen (alte App laeuft
#   weiter) -> alte App stoppen -> SQL-Satz mit dem NEUEN Image anwenden -> current umstellen
#   -> neue App starten -> Gesundheitspruefung.
# Schlaegt die Migration fehl, bleibt die Datenbank unveraendert (eine Transaktion) und die
# alte App wird wieder gestartet. Schlaegt der Start fehl, wird der alte Code nur dann
# automatisch zurueckgestellt, wenn das Schema unveraendert blieb. Sonst entscheidet der
# Betreiber (paolo-rollback.sh oder Wiederherstellung der Sicherung).
set -eu

here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
# shellcheck disable=SC1091
. "$here/paolo-lib.sh"

new_dir=$(CDPATH= cd -- "$here/../.." && pwd -P)
releases_dir=$(dirname -- "$new_dir")
[ "$(basename -- "$releases_dir")" = "releases" ] || pl_die "Dieses Release liegt nicht unter <PAOLO_HOME>/releases/: $new_dir"
home=${PAOLO_HOME:-$(dirname -- "$releases_dir")}
new_name=$(basename -- "$new_dir")

prod=""
dry_run=0
skip_backup=0
assume_yes=0
while [ $# -gt 0 ]; do
  case $1 in
    --prod) prod="--prod" ;;
    --dry-run) dry_run=1 ;;
    --skip-backup) skip_backup=1 ;;
    --yes) assume_yes=1 ;;
    *) pl_die "Unbekannte Option: $1" ;;
  esac
  shift
done

[ -L "$home/current" ] || pl_die "$home/current ist kein Symlink auf ein Release. Layout: docs/install-from-package.md"
old_dir=$(CDPATH= cd -- "$home/current" && pwd -P)
old_name=$(basename -- "$old_dir")
[ "$old_dir" != "$new_dir" ] || pl_die "current zeigt bereits auf dieses Release ($new_name)."

new_compose="$new_dir/scripts/deploy/paolo-compose.sh"
old_compose="$old_dir/scripts/deploy/paolo-compose.sh"
[ -f "$old_compose" ] || pl_die "Das aktuelle Release enthaelt kein paolo-compose.sh: $old_dir"

echo "== Pruefung"
pl_verify_release "$new_dir"
pl_verify_release "$old_dir"
new_version=$(pl_json "$new_dir/RELEASE.json" version)
old_version=$(pl_json "$old_dir/RELEASE.json" version)
new_migration=$(pl_json "$new_dir/RELEASE.json" latestMigration)
old_migration=$(pl_json "$old_dir/RELEASE.json" latestMigration)
[ "$(pl_json "$new_dir/RELEASE.json" name)" = "paolo-sms" ] || pl_die "RELEASE.json nennt kein PAOLO-SMS-Paket."
[ "$new_version" != "$old_version" ] || pl_die "Version $new_version ist bereits installiert."
if [ "$(pl_migration_number "$new_migration")" -lt "$(pl_migration_number "$old_migration")" ]; then
  pl_die "Das neue Paket kennt nur Migration $new_migration, die Installation steht auf $old_migration. Ein Wechsel auf ein Paket mit weniger Migrationen ist ein Downgrade und kein Update: nur ueber paolo-rollback.sh bei nachgewiesener Schemakompatibilitaet."
fi
schema_change=0
[ "$new_migration" = "$old_migration" ] || schema_change=1
new_count=$(pl_migration_count "$new_dir")
old_count=$(pl_migration_count "$old_dir")
echo "Installiert: $old_version ($old_name), letzte Migration $old_migration ($old_count)"
echo "Neu:         $new_version ($new_name), letzte Migration $new_migration ($new_count)"
if [ "$schema_change" -eq 1 ]; then
  echo "Schemaaenderung: ja, $((new_count - old_count)) neue Migration(en). Ein Zurueckstellen des Anwendungscodes ist danach nur bei nachgewiesener Schemakompatibilitaet zulaessig."
else
  echo "Schemaaenderung: nein."
fi

# Die Installation muss laufen: nur so ist der Ausgangszustand bekannt.
# shellcheck disable=SC2086
old_container=$(sh "$old_compose" $prod ps -q app 2>/dev/null | head -n 1)
[ -n "$old_container" ] || pl_die "Die Anwendung der aktuellen Installation laeuft nicht. Erst den Betrieb herstellen, dann aktualisieren."
if ! pl_wait_healthy "$old_compose" "$prod" 3; then
  pl_die "Die aktuelle Installation ist nicht gesund. Update abgebrochen."
fi

if [ "$dry_run" -eq 1 ]; then
  echo "== Trockenlauf beendet: keine Aenderung vorgenommen."
  exit 0
fi

if [ "$assume_yes" -ne 1 ]; then
  [ -t 0 ] || pl_die "Keine Rueckfrage moeglich. Mit --yes bestaetigen."
  printf 'Update von %s auf %s durchfuehren? Die Anwendung ist waehrend der Migration kurz nicht erreichbar. [j/N] ' "$old_version" "$new_version"
  read -r answer
  case $answer in j | J | y | Y) ;; *) pl_die "Abgebrochen." ;; esac
fi

backup_note="keine"
if [ "$skip_backup" -eq 0 ]; then
  echo "== Sicherung vor dem Update"
  # shellcheck disable=SC2086
  backup_out=$(sh "$old_dir/scripts/deploy/paolo-backup.sh" $prod create) || pl_die "Sicherung fehlgeschlagen. Update abgebrochen; nichts wurde veraendert."
  printf '%s\n' "$backup_out"
  backup_note=$(printf '%s\n' "$backup_out" | sed -n 's/^SICHERUNG ABGESCHLOSSEN: //p' | tail -n 1)
  [ -n "$backup_note" ] || pl_die "Die Sicherung meldet keinen Abschluss. Update abgebrochen."
else
  echo "WARNUNG: Update ohne Sicherung (--skip-backup)." >&2
fi

echo "== Rueckfall-Image sichern"
rollback_tag="paolo-sms:rollback-$old_version"
old_image_id=$(docker inspect -f '{{.Image}}' "$old_container") || pl_die "Image der laufenden Anwendung nicht ermittelbar."
docker tag "$old_image_id" "$rollback_tag" || pl_die "Rueckfall-Image konnte nicht markiert werden."

echo "== Neues Image bauen (die alte Anwendung laeuft weiter)"
# shellcheck disable=SC2086
sh "$new_compose" $prod build app || pl_die "Image-Build fehlgeschlagen. Nichts wurde veraendert; die alte Anwendung laeuft weiter."

echo "== Alte Anwendung anhalten"
# shellcheck disable=SC2086
sh "$old_compose" $prod stop app || pl_die "Die Anwendung liess sich nicht anhalten."

echo "== SQL-Satz des neuen Releases anwenden"
# shellcheck disable=SC2086
if ! sh "$new_compose" $prod run --rm --no-deps -T app sh /app/scripts/migrate.sh; then
  echo "FEHLER: Migration fehlgeschlagen. Der SQL-Satz laeuft in einer Transaktion; die Datenbank ist unveraendert." >&2
  # shellcheck disable=SC2086
  sh "$old_compose" $prod start app >/dev/null 2>&1 || true
  echo "Die alte Anwendung ($old_version) wurde wieder gestartet. current zeigt weiter auf $old_name." >&2
  exit 1
fi

echo "== Neues Release aktivieren"
pl_switch_current "$home" "$new_name"
# shellcheck disable=SC2086
sh "$new_compose" $prod up -d --force-recreate app || echo "WARNUNG: Start der neuen Anwendung meldete einen Fehler." >&2
if [ -n "$prod" ]; then
  # Ein neu erstellter App-Container hat eine andere interne Adresse; Nginx neu starten.
  sh "$new_compose" --prod restart nginx || echo "WARNUNG: Nginx liess sich nicht neu starten." >&2
fi

echo "== Gesundheitspruefung"
if pl_wait_healthy "$new_compose" "$prod" "${PAOLO_HEALTH_TIMEOUT:-90}"; then
  log="$home/config/update-history.log"
  mkdir -p "$home/config"
  printf '%s update %s -> %s migration %s -> %s sicherung: %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$old_version" "$new_version" "$old_migration" "$new_migration" "$backup_note" >>"$log"
  echo "UPDATE ERFOLGREICH: $old_version -> $new_version"
  echo "Funktionspruefung durchfuehren (docs/update-from-package.md). Das alte Release ($old_name) und das Rueckfall-Image $rollback_tag bleiben bis zur Abnahme erhalten."
  exit 0
fi

echo "FEHLER: Die neue Anwendung wurde nicht gesund." >&2
# shellcheck disable=SC2086
sh "$new_compose" $prod logs --tail=40 app >&2 || true
if [ "$schema_change" -eq 0 ]; then
  echo "Das Schema blieb unveraendert; der alte Code wird automatisch zurueckgestellt." >&2
  pl_switch_current "$home" "$old_name"
  image=$(pl_app_image "$old_compose" "$prod")
  [ -n "$image" ] && docker tag "$rollback_tag" "$image"
  # shellcheck disable=SC2086
  sh "$old_compose" $prod up -d --force-recreate app || true
  if [ -n "$prod" ]; then sh "$old_compose" --prod restart nginx || true; fi
  if pl_wait_healthy "$old_compose" "$prod" "${PAOLO_HEALTH_TIMEOUT:-90}"; then
    echo "Zurueckgestellt auf $old_version. Update fehlgeschlagen." >&2
  else
    echo "Auch das alte Release wurde nicht gesund. Manuelle Pruefung noetig." >&2
  fi
  exit 1
fi
echo "Es wurden Migrationen angewendet. Der alte Code wird NICHT automatisch zurueckgestellt, weil er gegen das neue Schema laufen wuerde." >&2
echo "Optionen: Fehler beheben und erneut starten; Rueckstellung nur bei nachgewiesener Schemakompatibilitaet (paolo-rollback.sh); oder Datenbank und Anhaenge aus der Sicherung wiederherstellen ($backup_note)." >&2
exit 2
