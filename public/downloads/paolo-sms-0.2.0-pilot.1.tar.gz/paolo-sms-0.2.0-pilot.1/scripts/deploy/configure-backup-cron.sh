#!/usr/bin/env bash
set -euo pipefail

if [ "${EUID}" -ne 0 ]; then
  echo "Run as root, for example: sudo bash scripts/deploy/configure-backup-cron.sh" >&2
  exit 1
fi

env_file="${1:-/opt/paolo-sms/.env.docker.local}"
cron_schedule="${PAOLO_BACKUP_CRON_SCHEDULE:-15 3 * * *}"

if [ ! -r "${env_file}" ]; then
  echo "Environment file is not readable: ${env_file}" >&2
  exit 1
fi

read_env_value() {
  local key="$1"
  local line
  line="$(grep -E "^${key}=" "${env_file}" | tail -n 1 || true)"
  if [ -z "${line}" ]; then
    return 1
  fi

  line="${line#*=}"
  line="${line%$'\r'}"
  if [[ "${line}" == \"*\" && "${line}" == *\" ]]; then
    line="${line:1:${#line}-2}"
  elif [[ "${line}" == \'*\' && "${line}" == *\' ]]; then
    line="${line:1:${#line}-2}"
  fi
  printf '%s' "${line}"
}

app_base_url="$(read_env_value APP_BASE_URL || true)"
cron_secret="$(read_env_value BACKUP_CRON_SECRET || true)"

if [[ ! "${app_base_url}" =~ ^https://[A-Za-z0-9.-]+(:[0-9]+)?(/[^[:space:]\"\']*)?$ ]]; then
  echo "APP_BASE_URL must be a public HTTPS URL in ${env_file}." >&2
  exit 1
fi

if [ "${#cron_secret}" -lt 32 ] || [[ ! "${cron_secret}" =~ ^[A-Za-z0-9._~-]+$ ]]; then
  echo "BACKUP_CRON_SECRET must contain at least 32 URL-safe characters in ${env_file}." >&2
  exit 1
fi

if [[ ! "${cron_schedule}" =~ ^[[:alnum:]*/,-]+[[:space:]]+[[:alnum:]*/,-]+[[:space:]]+[[:alnum:]*/,-]+[[:space:]]+[[:alnum:]*/,-]+[[:space:]]+[[:alnum:]*/,-]+$ ]]; then
  echo "PAOLO_BACKUP_CRON_SCHEDULE must contain exactly five valid cron fields." >&2
  exit 1
fi

backup_url="${app_base_url%/}/api/cron/backup"

install -d -o root -g root -m 0700 /etc/paolo
curl_config="$(mktemp /etc/paolo/backup-cron.curl.XXXXXX)"
cron_config="$(mktemp /etc/cron.d/paolo-backup.XXXXXX)"
trap 'rm -f "${curl_config}" "${cron_config}"' EXIT

{
  printf 'url = "%s"\n' "${backup_url}"
  printf 'request = "POST"\n'
  printf 'header = "Authorization: Bearer %s"\n' "${cron_secret}"
  printf '%s\n' 'silent' 'show-error' 'fail' 'output = "/dev/null"'
} >"${curl_config}"
chmod 0600 "${curl_config}"

{
  printf 'SHELL=/bin/sh\n'
  printf 'PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\n'
  printf '%s root /usr/bin/curl --config /etc/paolo/backup-cron.curl\n' "${cron_schedule}"
} >"${cron_config}"
chmod 0644 "${cron_config}"

install -o root -g root -m 0600 "${curl_config}" /etc/paolo/backup-cron.curl
install -o root -g root -m 0644 "${cron_config}" /etc/cron.d/paolo-backup

echo "Installed daily PAOLO database backup cron: ${cron_schedule}"
echo "Endpoint: ${backup_url}"
echo "Run it once after the application is healthy:"
echo "  sudo /usr/bin/curl --config /etc/paolo/backup-cron.curl"
