# Einheitlicher Docker-Compose-Aufruf fuer das Quellpaket-Layout unter Windows
# (PowerShell 7 oder Windows PowerShell). Gleiche Aufgabe und gleiche Regeln wie
# scripts/deploy/paolo-compose.sh; siehe docs/install-from-package.md.
#
#   scripts\deploy\paolo-compose.ps1 [--prod] <docker compose Argumente>
#
# Umgebungsvariablen: PAOLO_HOME, PAOLO_ENV_FILE, PAOLO_COMPOSE_PROJECT_NAME.
# Die Argumente bleiben bewusst ungebunden ($args): So erreicht jedes Argument,
# auch `--`-Optionen, unveraendert docker compose.
$ErrorActionPreference = 'Stop'

$releaseDir = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..\..')).Path
$releasesDir = Split-Path -Parent $releaseDir

if ($env:PAOLO_HOME) {
    $paoloHome = $env:PAOLO_HOME
} elseif ((Split-Path -Leaf $releasesDir) -eq 'releases') {
    $paoloHome = Split-Path -Parent $releasesDir
} else {
    Write-Error "Release-Verzeichnis nicht unter <PAOLO_HOME>\releases\: $releaseDir`nPAOLO_HOME setzen oder das Layout aus docs/install-from-package.md verwenden."
}

if ($args.Count -gt 0 -and $args[0] -eq '--home') {
    $paoloHome
    exit 0
}

$envFile = if ($env:PAOLO_ENV_FILE) { $env:PAOLO_ENV_FILE } else { Join-Path $paoloHome 'config\.env.docker.local' }
if (-not (Test-Path -LiteralPath $envFile -PathType Leaf)) {
    Write-Error "Konfigurationsdatei fehlt: $envFile`nAus .env.docker.example im Release-Verzeichnis anlegen."
}

$project = $env:PAOLO_COMPOSE_PROJECT_NAME
$projectFile = Join-Path $paoloHome 'config\compose-project-name'
if (-not $project -and (Test-Path -LiteralPath $projectFile -PathType Leaf)) {
    $project = ((Get-Content -LiteralPath $projectFile -TotalCount 1) -replace '\s', '')
}
if (-not $project) { $project = 'paolo-sms' }
if ($project -cnotmatch '^[a-z0-9][a-z0-9_-]*$') {
    Write-Error "Ungueltiger Compose-Projektname: $project"
}

$env:PAOLO_ENV_FILE = $envFile
$env:COMPOSE_PROJECT_NAME = $project

$composeFiles = @('-f', 'docker-compose.yml')
$rest = @($args)
if ($rest.Count -gt 0 -and $rest[0] -eq '--prod') {
    $rest = @($rest | Select-Object -Skip 1)
    $nginxDir = if ($env:PAOLO_NGINX_CONF_DIR) { $env:PAOLO_NGINX_CONF_DIR } else { Join-Path $paoloHome 'config\nginx\conf.d' }
    if (-not (Test-Path -LiteralPath $nginxDir -PathType Container)) {
        Write-Error "Nginx-Konfiguration fehlt: $nginxDir`nAus deploy\nginx\conf.d im Release-Verzeichnis kopieren (docs/install-from-package.md)."
    }
    $env:PAOLO_NGINX_CONF_DIR = $nginxDir
    $composeFiles += @('-f', 'docker-compose.prod.yml')
}

Push-Location -LiteralPath $releaseDir
try {
    docker compose @composeFiles @rest
    exit $LASTEXITCODE
} finally {
    Pop-Location
}
