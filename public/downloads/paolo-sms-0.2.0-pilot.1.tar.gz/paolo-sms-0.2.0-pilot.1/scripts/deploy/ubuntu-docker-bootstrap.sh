#!/usr/bin/env bash
set -euo pipefail

if [ "${EUID}" -ne 0 ]; then
  echo "Run as root, for example: sudo bash scripts/deploy/ubuntu-docker-bootstrap.sh" >&2
  exit 1
fi

install -m 0755 -d /etc/apt/keyrings
apt-get update
apt-get install -y ca-certificates cron curl git gnupg lsb-release

if [ ! -f /etc/apt/keyrings/docker.asc ]; then
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
  chmod a+r /etc/apt/keyrings/docker.asc
fi

arch="$(dpkg --print-architecture)"
codename="$(. /etc/os-release && echo "${VERSION_CODENAME}")"
cat >/etc/apt/sources.list.d/docker.list <<EOF
deb [arch=${arch} signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu ${codename} stable
EOF

apt-get update
apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

deployment_user="${SUDO_USER:-root}"
if ! id "${deployment_user}" >/dev/null 2>&1; then
  echo "Deployment user does not exist: ${deployment_user}" >&2
  exit 1
fi

install -d -o "${deployment_user}" -g "${deployment_user}" -m 0750 /opt/paolo-sms
systemctl enable --now docker
systemctl enable --now cron

if [ "${deployment_user}" != "root" ]; then
  usermod -aG docker "${deployment_user}"
  echo "Added ${deployment_user} to the docker group. Log out and back in before using docker without sudo."
fi

echo "Docker and Compose are installed. Deployment directory: /opt/paolo-sms (owner: ${deployment_user})"
