#!/bin/sh
# Stellt den Anwendungscode auf ein frueheres Release zurueck, dessen Verzeichnis
# dieses Skript enthaelt. ES MACHT KEINE DATENBANKMIGRATION RUECKGAENGIG.
# Grenzen und Alternativen: docs/update-from-package.md.
#
#   sh <PAOLO_HOME>/releases/<frueher>/scripts/deploy/paolo-rollback.sh [--prod] [--schema-compatible] [--skip-backup] [--yes]
#
# Ohne Schemaaenderung seit dem frueheren Release (gleiche letzte Migration) ist die
# Rueckstellung unkritisch. Mit Schemaaenderung wird sie nur ausgefuehrt, wenn der
# Betreiber --schema-compatible angibt: Er bestaetigt damit anhand der Release-Notes,
# dass das fruehere Release mit dem migrierten Schema funktioniert (rein additive
# Aenderungen, die der alte Code nicht benoetigt). Andernfalls bleibt nur die
# Wiederherstellung von Datenbank und Anhaengen aus der Sicherung vor dem Update.
set -eu

here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
# shellcheck disable=SC1091
. "$here/paolo-lib.sh"

target_dir=$(CDPATH= cd -- "$here/../.." && pwd -P)
releases_dir=$(dirname -- "$target_dir")
[ "$(basename -- "$releases_dir")" = "releases" ] || pl_die "Dieses Release liegt nicht unter <PAOLO_HOME>/releases/: $target_dir"
home=${PAOLO_HOME:-$(dirname -- "$releases_dir")}
target_name=$(basename -- "$target_dir")

prod=""
compatible=0
skip_backup=0
assume_yes=0
while [ $# -gt 0 ]; do
  case $1 in
    --prod) prod="--prod" ;;
    --schema-compatible) compatible=1 ;;
    --skip-backup) skip_backup=1 ;;
    --yes) assume_yes=1 ;;
    *) pl_die "Unbekannte Option: $1" ;;
  esac
  shift
done

[ -L "$home/current" ] || pl_die "$home/current ist kein Symlink auf ein Release."
current_dir=$(CDPATH= cd -- "$home/current" && pwd -P)
current_name=$(basename -- "$current_dir")
[ "$current_dir" != "$target_dir" ] || pl_die "current zeigt bereits auf $target_name."

pl_verify_release "$target_dir"
pl_verify_release "$current_dir"
target_version=$(pl_json "$target_dir/RELEASE.json" version)
current_version=$(pl_json "$current_dir/RELEASE.json" version)
target_migration=$(pl_json "$target_dir/RELEASE.json" latestMigration)
current_migration=$(pl_json "$current_dir/RELEASE.json" latestMigration)

echo "Installiert: $current_version, letzte Migration $current_migration"
echo "Ziel:        $target_version, letzte Migration $target_migration"
if [ "$target_migration" != "$current_migration" ]; then
  echo "WARNUNG: Zwischen beiden Releases wurde das Schema geaendert. Die Datenbank bleibt auf dem neueren Stand." >&2
  if [ "$compatible" -ne 1 ]; then
    pl_die "Rueckstellung abgelehnt: Ohne nachgewiesene Schemakompatibilitaet (--schema-compatible, siehe Release-Notes) ist nur die Wiederherstellung aus der Sicherung vor dem Update zulaessig."
  fi
fi

if [ "$assume_yes" -ne 1 ]; then
  [ -t 0 ] || pl_die "Keine Rueckfrage moeglich. Mit --yes bestaetigen."
  printf 'Anwendungscode von %s auf %s zurueckstellen? [j/N] ' "$current_version" "$target_version"
  read -r answer
  case $answer in j | J | y | Y) ;; *) pl_die "Abgebrochen." ;; esac
fi

current_compose="$current_dir/scripts/deploy/paolo-compose.sh"
target_compose="$target_dir/scripts/deploy/paolo-compose.sh"

if [ "$skip_backup" -eq 0 ]; then
  echo "== Sicherung vor der Rueckstellung"
  # shellcheck disable=SC2086
  sh "$current_dir/scripts/deploy/paolo-backup.sh" $prod create || pl_die "Sicherung fehlgeschlagen. Nichts wurde veraendert."
fi

echo "== Anwendung anhalten"
# shellcheck disable=SC2086
sh "$current_compose" $prod stop app || pl_die "Die Anwendung liess sich nicht anhalten."

echo "== Frueheres Release aktivieren"
pl_switch_current "$home" "$target_name"
rollback_tag="paolo-sms:rollback-$target_version"
image=$(pl_app_image "$target_compose" "$prod")
if [ -n "$image" ] && docker image inspect "$rollback_tag" >/dev/null 2>&1; then
  docker tag "$rollback_tag" "$image"
else
  # shellcheck disable=SC2086
  sh "$target_compose" $prod build app || pl_die "Image-Build des frueheren Releases fehlgeschlagen."
fi
# shellcheck disable=SC2086
sh "$target_compose" $prod up -d --force-recreate app || echo "WARNUNG: Start meldete einen Fehler." >&2
if [ -n "$prod" ]; then sh "$target_compose" --prod restart nginx || true; fi

if pl_wait_healthy "$target_compose" "$prod" "${PAOLO_HEALTH_TIMEOUT:-90}"; then
  log="$home/config/update-history.log"
  mkdir -p "$home/config"
  printf '%s rollback %s -> %s migration %s (Schema bleibt %s) schema-compatible=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$current_version" "$target_version" "$target_migration" "$current_migration" "$compatible" >>"$log"
  echo "RUECKSTELLUNG ERFOLGREICH: Anwendungscode $target_version, Schema unveraendert $current_migration."
  exit 0
fi
echo "FEHLER: Das zurueckgestellte Release wurde nicht gesund." >&2
echo "Naechster Schritt: Datenbank und Anhaenge aus der Sicherung vor dem Update wiederherstellen (docs/backup-restore.md)." >&2
exit 1
