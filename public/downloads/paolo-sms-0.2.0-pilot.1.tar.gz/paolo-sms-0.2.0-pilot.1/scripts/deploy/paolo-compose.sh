#!/bin/sh
# Einheitlicher Docker-Compose-Aufruf fuer das Quellpaket-Layout
# (docs/install-from-package.md):
#
#   <PAOLO_HOME>/config/.env.docker.local   Betreiberkonfiguration (bleibt bei Updates)
#   <PAOLO_HOME>/config/nginx/conf.d/       aktive Nginx-Konfiguration (nur mit --prod)
#   <PAOLO_HOME>/releases/<release>/        austauschbares Release-Verzeichnis
#
# Das Skript setzt den dauerhaft gleichen Compose-Projektnamen, damit ein
# Release-Wechsel dieselben Datenbank-, Storage- und Backup-Volumes verwendet.
# Docker Compose leitet den Namen sonst aus dem Verzeichnisnamen ab, und der
# Verzeichnisname enthaelt die Version.
#
#   scripts/deploy/paolo-compose.sh [--prod] <docker compose Argumente>
#   scripts/deploy/paolo-compose.sh --home      gibt die Betreiberwurzel aus
#
# Umgebungsvariablen (nur bei bewusster Abweichung):
#   PAOLO_HOME                    Betreiberwurzel; Standard: Elternverzeichnis von releases/
#   PAOLO_ENV_FILE                Pfad der Konfigurationsdatei
#   PAOLO_COMPOSE_PROJECT_NAME    Projektname; Standard: Inhalt von config/compose-project-name, sonst paolo-sms
set -eu

release_dir=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd -P)
releases_dir=$(dirname -- "$release_dir")

if [ -n "${PAOLO_HOME:-}" ]; then
  home=$PAOLO_HOME
elif [ "$(basename -- "$releases_dir")" = "releases" ]; then
  home=$(dirname -- "$releases_dir")
else
  echo "Release-Verzeichnis nicht unter <PAOLO_HOME>/releases/: $release_dir" >&2
  echo "PAOLO_HOME setzen oder das Layout aus docs/install-from-package.md verwenden." >&2
  exit 1
fi

if [ "${1:-}" = "--home" ]; then
  printf '%s
' "$home"
  exit 0
fi

env_file=${PAOLO_ENV_FILE:-$home/config/.env.docker.local}
if [ ! -f "$env_file" ]; then
  echo "Konfigurationsdatei fehlt: $env_file" >&2
  echo "Aus .env.docker.example im Release-Verzeichnis anlegen." >&2
  exit 1
fi

project=${PAOLO_COMPOSE_PROJECT_NAME:-}
# Uebernommene Git-Installation: Der bisherige Projektname steht in
# <PAOLO_HOME>/config/compose-project-name, damit die vorhandenen Volumes weiter gelten.
if [ -z "$project" ] && [ -f "$home/config/compose-project-name" ]; then
  project=$(head -n 1 "$home/config/compose-project-name" | tr -d '\r ')
fi
project=${project:-paolo-sms}
case $project in
  *[!a-z0-9_-]* | "" | [-_]*)
    echo "Ungueltiger Compose-Projektname: $project" >&2
    exit 1
    ;;
esac

PAOLO_ENV_FILE=$env_file
COMPOSE_PROJECT_NAME=$project
export PAOLO_ENV_FILE COMPOSE_PROJECT_NAME

compose_files="-f docker-compose.yml"
if [ "${1:-}" = "--prod" ]; then
  shift
  nginx_dir=${PAOLO_NGINX_CONF_DIR:-$home/config/nginx/conf.d}
  if [ ! -d "$nginx_dir" ]; then
    echo "Nginx-Konfiguration fehlt: $nginx_dir" >&2
    echo "Aus deploy/nginx/conf.d im Release-Verzeichnis kopieren (docs/install-from-package.md)." >&2
    exit 1
  fi
  PAOLO_NGINX_CONF_DIR=$nginx_dir
  export PAOLO_NGINX_CONF_DIR
  compose_files="$compose_files -f docker-compose.prod.yml"
fi

cd -- "$release_dir"
# shellcheck disable=SC2086
exec docker compose $compose_files "$@"
