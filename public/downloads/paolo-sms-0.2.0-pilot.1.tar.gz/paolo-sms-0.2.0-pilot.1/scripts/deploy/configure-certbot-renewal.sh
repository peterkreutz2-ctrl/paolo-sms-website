#!/usr/bin/env bash
set -euo pipefail

if [ "${EUID}" -ne 0 ]; then
  echo "Run as root, for example: sudo bash scripts/deploy/configure-certbot-renewal.sh" >&2
  exit 1
fi

deployment_dir="${1:-/opt/paolo-sms}"
cron_schedule="${PAOLO_CERTBOT_CRON_SCHEDULE:-17 2,14 * * *}"

if [[ ! "${deployment_dir}" =~ ^/[A-Za-z0-9._/-]+$ ]]; then
  echo "Deployment directory must be an absolute path without spaces." >&2
  exit 1
fi

if [ ! -f "${deployment_dir}/docker-compose.yml" ] ||
   [ ! -f "${deployment_dir}/docker-compose.prod.yml" ]; then
  echo "Compose files not found in deployment directory: ${deployment_dir}" >&2
  exit 1
fi

if [[ ! "${cron_schedule}" =~ ^[[:alnum:]*/,-]+[[:space:]]+[[:alnum:]*/,-]+[[:space:]]+[[:alnum:]*/,-]+[[:space:]]+[[:alnum:]*/,-]+[[:space:]]+[[:alnum:]*/,-]+$ ]]; then
  echo "PAOLO_CERTBOT_CRON_SCHEDULE must contain exactly five valid cron fields." >&2
  exit 1
fi


# Quellpaket-Layout (docs/install-from-package.md): Die Konfiguration liegt
# ausserhalb des Release-Verzeichnisses. Dann laeuft der Aufruf ueber den
# Wrapper, der Konfigurationsdatei und den festen Projektnamen setzt. Als
# deployment_dir dient der Symlink auf das aktuelle Release, damit ein
# Release-Wechsel ohne neue Cron-Datei greift.
if [ ! -f "${deployment_dir}/.env.docker.local" ] &&
   [ -f "${deployment_dir}/scripts/deploy/paolo-compose.sh" ]; then
  compose_cmd="/bin/sh scripts/deploy/paolo-compose.sh --prod"
else
  compose_cmd="/usr/bin/docker compose -f docker-compose.yml -f docker-compose.prod.yml"
fi

cron_config="$(mktemp /etc/cron.d/paolo-certbot.XXXXXX)"
trap 'rm -f "${cron_config}"' EXIT

{
  printf 'SHELL=/bin/sh\n'
  printf 'PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\n'
  printf '%s root cd %s && ' "${cron_schedule}" "${deployment_dir}"
  printf '%s ' "${compose_cmd}"
  printf '%s ' '--profile certbot run --rm certbot renew --webroot --webroot-path /var/www/certbot --quiet'
  printf '&& %s ' "${compose_cmd}"
  printf 'exec -T nginx nginx -s reload >/dev/null\n'
} >"${cron_config}"

chmod 0644 "${cron_config}"
install -o root -g root -m 0644 "${cron_config}" /etc/cron.d/paolo-certbot

echo "Installed PAOLO certificate renewal cron: ${cron_schedule}"
echo "Run a dry-run now:"
echo "  cd ${deployment_dir}"
echo "  sudo ${compose_cmd} --profile certbot run --rm certbot renew --dry-run"
