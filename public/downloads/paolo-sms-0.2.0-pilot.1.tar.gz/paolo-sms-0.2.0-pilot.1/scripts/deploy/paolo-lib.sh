# Gemeinsame Funktionen fuer paolo-update.sh und paolo-rollback.sh (wird mit `.`
# eingelesen, nicht direkt ausgefuehrt). Nur POSIX sh.

pl_die() {
  echo "[paolo] $*" >&2
  exit 1
}

# Liest einen Wert aus einer JSON-Datei mit einem Schluessel je Zeile (RELEASE.json).
pl_json() {
  sed -n "s/^  \"$2\": \"\{0,1\}\([^\",]*\)\"\{0,1\},\{0,1\}\$/\1/p" "$1" | head -n 1
}

# Laufende Nummer aus einem Migrationsnamen (0035_name -> 35).
pl_migration_number() {
  n=$(printf '%s' "$1" | cut -c1-4 | sed 's/^0*//')
  printf '%s\n' "${n:-0}"
}

# Anzahl der Migrationsdateien eines Release-Verzeichnisses.
pl_migration_count() {
  find "$1/drizzle" -maxdepth 1 -name '[0-9][0-9][0-9][0-9]_*.sql' | wc -l | tr -d ' '
}

# Prueft FILES.sha256 eines entpackten Release-Verzeichnisses.
pl_verify_release() {
  [ -f "$1/RELEASE.json" ] || pl_die "RELEASE.json fehlt in $1"
  [ -f "$1/FILES.sha256" ] || pl_die "FILES.sha256 fehlt in $1"
  (cd "$1" && sha256sum -c FILES.sha256 --quiet) || pl_die "Dateien von $1 weichen von FILES.sha256 ab."
}

# pl_wait_healthy <compose-skript> <prod-flag-oder-leer> <sekunden>
# Probiert alle 3 Sekunden, mindestens einmal.
pl_wait_healthy() {
  waited=0
  while :; do
    # shellcheck disable=SC2086
    if sh "$1" $2 exec -T app node -e "require('http').get('http://127.0.0.1:3000/api/health',r=>process.exit(r.statusCode===200?0:1)).on('error',()=>process.exit(1))" >/dev/null 2>&1; then
      return 0
    fi
    waited=$((waited + 3))
    [ "$waited" -lt "$3" ] || return 1
    sleep 3
  done
}

# Setzt den Symlink <home>/current atomar auf releases/<name>.
pl_switch_current() {
  ln -sfn "releases/$2" "$1/current.new" || pl_die "Symlink konnte nicht angelegt werden."
  mv -T "$1/current.new" "$1/current" || pl_die "Symlink current konnte nicht umgestellt werden."
}

# Name des Images, das docker-compose.yml fuer den Dienst app verwendet.
pl_app_image() {
  # shellcheck disable=SC2086
  sh "$1" $2 config --images 2>/dev/null | grep '^paolo-sms:' | head -n 1
}
