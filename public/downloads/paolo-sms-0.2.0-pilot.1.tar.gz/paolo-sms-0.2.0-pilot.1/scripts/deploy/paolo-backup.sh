#!/bin/sh
# Vollstaendige Sicherung und Wiederherstellung im Quellpaket-Layout
# (docs/backup-restore.md, docs/install-from-package.md). Ruft im App-Container
# scripts/backup-installation.sh auf; Datenbank, Anhaenge und Konfiguration
# werden gemeinsam gesichert.
#
#   scripts/deploy/paolo-backup.sh [--prod] create [--no-attachments]
#   scripts/deploy/paolo-backup.sh [--prod] restore <db-backup-id> --identity <datei> \
#       --confirm RESTORE:<datenbank> [--replace-attachments] [--without-attachments]
#   scripts/deploy/paolo-backup.sh [--prod] list
#
# Die Konfiguration (Geheimnisse, Rechte 0600 des Betreibers) und die private
# age-Identitaet liest der HOST und uebergibt sie ueber die Standardeingabe an den
# Container. Der Container-Benutzer kann diese Dateien nicht lesen und braucht es
# nicht; die Identitaet liegt nur fuer die Dauer des Aufrufs in /tmp des Containers.
set -eu

here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
compose="$here/paolo-compose.sh"

prod=""
if [ "${1:-}" = "--prod" ]; then
  prod="--prod"
  shift
fi

home=$(sh "$compose" --home)
command=${1:-}
if [ $# -gt 0 ]; then shift; fi

case $command in
  create)
    # shellcheck disable=SC2086
    sh "$compose" $prod run --rm --no-deps -T app sh /app/scripts/backup-installation.sh create "$@"
    if [ -d "$home/config" ]; then
      status="${TMPDIR:-/tmp}/paolo-config-tar.$$"
      trap 'rm -f "$status"' EXIT
      # Ohne pipefail zaehlt sonst nur der Status des letzten Prozesses: tar getrennt pruefen.
      # shellcheck disable=SC2086
      (set +e; tar -C "$home/config" -cf - .; echo $? >"$status") |
        sh "$compose" $prod run --rm --no-deps -T app sh /app/scripts/backup-installation.sh config-archive
      [ "$(cat "$status")" = "0" ] || { echo "Konfiguration konnte nicht gelesen werden; die Sicherung ist unvollstaendig." >&2; exit 1; }
    fi
    ;;
  restore)
    id=${1:-}
    [ -n "$id" ] || { echo "Backup-ID fehlt." >&2; exit 1; }
    shift
    identity=""
    rest=""
    # Die uebrigen Argumente (ohne Leerzeichen) unveraendert weiterreichen.
    while [ $# -gt 0 ]; do
      case $1 in
        --identity) identity=${2:-}; shift 2 ;;
        --identity=*) identity=${1#--identity=}; shift ;;
        *) rest="$rest $1"; shift ;;
      esac
    done
    [ -n "$identity" ] && [ -f "$identity" ] || { echo "Identitaetsdatei fehlt: $identity" >&2; exit 1; }
    # Die Identitaet kommt ueber die Standardeingabe in eine Datei im Container (/tmp, Rechte 0600).
    # shellcheck disable=SC2086
    sh "$compose" $prod run --rm --no-deps -T app sh -c       'umask 077; cat >/tmp/paolo-identity; trap "rm -f /tmp/paolo-identity" EXIT; sh /app/scripts/backup-installation.sh restore "$@" --identity /tmp/paolo-identity'       sh "$id" $rest <"$identity"
    ;;
  list)
    # shellcheck disable=SC2086
    exec sh "$compose" $prod run --rm --no-deps -T app sh -c \
      'ls -l "${BACKUP_DIR:-/app/backups}" | grep -E "\.age$|manifest" || true; sh /app/scripts/backup-attachments.sh list'
    ;;
  *)
    echo "Aufruf: create [--no-attachments] | restore <db-backup-id> --identity <datei> --confirm RESTORE:<datenbank> | list" >&2
    exit 2
    ;;
esac
