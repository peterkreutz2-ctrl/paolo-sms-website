#!/bin/sh
# Vollstaendige Sicherung und Wiederherstellung einer Docker-Installation:
# Datenbank, lokale Anhaenge und (optional) die Betreiberkonfiguration.
# Laeuft im App-Container; ueblicherweise ueber scripts/deploy/paolo-backup.sh.
#
#   sh /app/scripts/backup-installation.sh create [--no-attachments]
#   sh /app/scripts/backup-installation.sh restore <db-backup-id> --identity <datei> \
#       --confirm RESTORE:<datenbank> [--replace-attachments] [--without-attachments]
#
# Reihenfolge bei create: erst Datenbank, dann Anhaenge. Eine Datei, die zwischen
# beiden Schritten hochgeladen wird, liegt im Anhangsarchiv ohne Datenbankzeile
# (harmlos). Umgekehrt entstuende ein Verweis ohne Datei. Fuer einen exakt
# zusammenpassenden Stand die Anwendung vorher stoppen (docs/backup-restore.md).
# Das Datenbank-Backup entsteht wie in der Weboberflaeche (createBackup) und ist
# im Admin-Bereich sichtbar.
set -eu
umask 077

backup_root=${BACKUP_DIR:-/app/backups}
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

die() {
  echo "[backup-installation] $*" >&2
  exit 1
}

local_storage() {
  [ "${STORAGE_PROVIDER:-vercel-blob}" = "local" ]
}

cmd_create() {
  attachments=1
  while [ $# -gt 0 ]; do
    case $1 in
      --no-attachments) attachments=0; shift ;;
      *) die "Unbekannte Option: $1" ;;
    esac
  done

  output=$(node "$here/backup-create.mjs") || die "Datenbank-Backup fehlgeschlagen."
  printf '%s\n' "$output"
  db_id=$(printf '%s\n' "$output" | sed -n 's/^BACKUP_ID=//p' | tail -n 1)
  [ -n "$db_id" ] || die "Die Backup-ID wurde nicht gemeldet."

  att_id=""
  if [ "$attachments" -eq 1 ]; then
    if local_storage; then
      att_output=$(sh "$here/backup-attachments.sh" create --db-backup "$db_id") || die "Anhangssicherung fehlgeschlagen. Das Datenbank-Backup $db_id existiert; die Sicherung ist unvollstaendig."
      printf '%s\n' "$att_output"
      att_id=$(printf '%s\n' "$att_output" | sed -n 's/^ATTACHMENTS_ID=//p' | tail -n 1)
    else
      echo "HINWEIS: STORAGE_PROVIDER ist nicht 'local'. Anhaenge in Vercel Blob sind NICHT gesichert." >&2
    fi
  fi

  echo "SICHERUNG ABGESCHLOSSEN: Datenbank $db_id${att_id:+, Anhaenge $att_id}"
  echo "Die Betreiberkonfiguration sichert der Aufruf ueber paolo-backup.sh (config-archive)."
}

# Verschluesselt ein tar-Archiv von der Standardeingabe nach $BACKUP_DIR/config-<zeit>.tar.age.
# Die Betreiberkonfiguration enthaelt Geheimnisse und liegt auf dem Host mit Rechten, die der
# Container-Benutzer nicht lesen kann; deshalb liest der Host sie und uebergibt den Strom.
cmd_config_archive() {
  [ -n "${BACKUP_AGE_RECIPIENTS:-}" ] || die "BACKUP_AGE_RECIPIENTS ist nicht gesetzt."
  set --
  for recipient in $(printf '%s' "$BACKUP_AGE_RECIPIENTS" | tr ',' ' '); do
    set -- "$@" -r "$recipient"
  done
  out="$backup_root/config-$(date -u +%Y%m%dT%H%M%SZ).tar.age"
  trap 'rm -f "$out.tmp"' EXIT
  age "$@" -o "$out.tmp"
  [ -s "$out.tmp" ] || die "Leeres Konfigurationsarchiv."
  mv "$out.tmp" "$out"
  echo "Konfiguration gesichert: $(basename "$out")"
}

cmd_restore() {
  db_id=${1:-}
  [ -n "$db_id" ] || die "Backup-ID fehlt."
  shift
  identity=""
  confirm=""
  replace=""
  attachments=1
  while [ $# -gt 0 ]; do
    case $1 in
      --identity) identity=${2:-}; shift 2 ;;
      --confirm) confirm=${2:-}; shift 2 ;;
      --replace-attachments) replace="--replace"; shift ;;
      --without-attachments) attachments=0; shift ;;
      *) die "Unbekannte Option: $1" ;;
    esac
  done
  [ -n "$identity" ] && [ -r "$identity" ] || die "Identitaetsdatei fehlt oder ist nicht lesbar (--identity)."
  [ -n "$confirm" ] || die "Bestaetigung fehlt (--confirm RESTORE:<datenbank>)."

  # Vorpruefung VOR jeder Aenderung: passendes Anhangsarchiv vorhanden und unversehrt?
  att_id=""
  if [ "$attachments" -eq 1 ] && local_storage; then
    for m in "$backup_root"/attachments/*.manifest.json; do
      [ -f "$m" ] || continue
      if grep -q "\"dbBackupId\": \"$db_id\"" "$m"; then
        att_id=$(sed -n 's/^  "archiveId": "\([^"]*\)".*/\1/p' "$m" | head -n 1)
      fi
    done
    [ -n "$att_id" ] || die "Kein Anhangsarchiv zu Backup $db_id gefunden. Mit --without-attachments nur die Datenbank wiederherstellen."
    sh "$here/backup-attachments.sh" verify "$att_id" --identity "$identity"
    storage=${LOCAL_STORAGE_DIR:-/app/storage}
    if [ -z "$replace" ] && [ -n "$(find "$storage" -mindepth 1 -maxdepth 1 2>/dev/null | head -n 1)" ]; then
      die "Speicherverzeichnis ist nicht leer ($storage). Datenbank unveraendert. Mit --replace-attachments ersetzen oder ein leeres Ziel verwenden."
    fi
  fi

  node "$here/backup-restore.mjs" "$db_id" "--identity=$identity" "--confirm=$confirm"

  if [ -n "$att_id" ]; then
    sh "$here/backup-attachments.sh" restore "$att_id" --identity "$identity" $replace
  fi

  echo "WIEDERHERSTELLUNG ABGESCHLOSSEN."
  echo "Naechste Schritte: SQL-Satz des installierten Releases anwenden (scripts/migrate.sh), Anwendung starten, Anmeldung und Daten pruefen."
}

command=${1:-}
if [ $# -gt 0 ]; then shift; fi
case $command in
  create) cmd_create "$@" ;;
  config-archive) cmd_config_archive ;;
  restore) cmd_restore "$@" ;;
  *) die "Aufruf: create [--no-attachments] | restore <db-backup-id> --identity <datei> --confirm RESTORE:<datenbank> [--replace-attachments] [--without-attachments]" ;;
esac
