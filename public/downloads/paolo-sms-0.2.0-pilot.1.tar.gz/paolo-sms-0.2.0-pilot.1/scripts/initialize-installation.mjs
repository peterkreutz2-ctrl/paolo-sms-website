#!/usr/bin/env node
import { loadEnvFile, stdin as input, stdout as output } from "node:process"
import { createInterface } from "node:readline/promises"

import { hashPassword } from "better-auth/crypto"
import pg from "pg"

import {
  BootstrapError,
  initializeInstallation,
  inspectInstallation,
  normalizeEmail,
  normalizeOrganizationName,
  normalizeOrganizationType,
  parseArguments,
  parseDatabaseTarget,
  poolOptions,
  resolveClerkAdmin,
  sanitizeText,
  validateBetterAuthPassword,
} from "./initialize-installation-core.mjs"

const HELP = `PAOLO-Erstinitialisierung (nach migrate.sh)

Aufruf:
  npm run setup:initialize
  npm run setup:initialize -- --non-interactive \\
    --organization-name=<name> --organization-type=club|flight_school \\
    --admin-email=<email> --confirm-database=<database>

Better Auth benötigt zusätzlich:
  --admin-name=<name> und BETTER_AUTH_BOOTSTRAP_PASSWORD

Clerk akzeptiert anstelle von --admin-email:
  --admin-user-id=<clerk-user-id>

Vollständiges non-interaktives Beispiel:
  npm run setup:initialize -- --non-interactive \\
    --organization-name=<name> --organization-type=club \\
    --admin-email=<email> --admin-name=<name> \\
    --confirm-database=<database>

Das Better-Auth-Passwort wird interaktiv verdeckt oder ausschließlich über
BETTER_AUTH_BOOTSTRAP_PASSWORD übergeben.`

async function ask(prompt) {
  const readline = createInterface({ input, output })
  try {
    return await readline.question(prompt)
  } finally {
    readline.close()
  }
}

function readHidden(prompt) {
  if (!input.isTTY || typeof input.setRawMode !== "function") {
    throw new BootstrapError("Verdeckte Passworteingabe benötigt ein interaktives Terminal.")
  }
  return new Promise((resolve, reject) => {
    let value = ""
    output.write(prompt)
    input.setRawMode(true)
    input.resume()
    input.setEncoding("utf8")

    const finish = (error) => {
      input.setRawMode(false)
      input.pause()
      input.removeListener("data", onData)
      output.write("\n")
      if (error) reject(error)
      else resolve(value)
    }
    const onData = (key) => {
      if (key === "\u0003") return finish(new BootstrapError("Abgebrochen."))
      if (key === "\r" || key === "\n") return finish()
      if (key === "\u0008" || key === "\u007f") {
        if (value.length > 0) {
          value = value.slice(0, -1)
          output.write("\b \b")
        }
        return
      }
      if (!key.startsWith("\u001b")) {
        value += key
        output.write("*")
      }
    }
    input.on("data", onData)
  })
}

function requiredNonInteractive(values, key) {
  const value = values[key]
  if (!value) throw new BootstrapError(`Im non-interaktiven Modus fehlt --${key}=...`)
  return value
}

async function valueOrPrompt(values, key, prompt, nonInteractive) {
  return values[key] ?? (nonInteractive ? requiredNonInteractive(values, key) : await ask(prompt))
}

async function main() {
  const parsed = parseArguments(process.argv.slice(2))
  if (parsed.help) {
    console.log(HELP)
    return
  }

  try {
    loadEnvFile(".env.local")
  } catch (error) {
    if (error?.code !== "ENOENT") throw error
  }
  const authMode = process.env.AUTH_MODE
  if (authMode !== "clerk" && authMode !== "betterauth") {
    throw new BootstrapError("AUTH_MODE muss clerk oder betterauth sein.")
  }
  const databaseUrl = process.env.DATABASE_URL
  const databaseTarget = parseDatabaseTarget(databaseUrl)
  const organizationName = normalizeOrganizationName(
    await valueOrPrompt(parsed.values, "organization-name", "Name der Organisation: ", parsed.nonInteractive)
  )
  const rawType = await valueOrPrompt(
    parsed.values,
    "organization-type",
    "Organisationstyp (1 = Verein, 2 = Flugschule): ",
    parsed.nonInteractive
  )
  const organizationType = normalizeOrganizationType(rawType, { interactive: !parsed.nonInteractive })

  if (authMode === "clerk" && parsed.values["admin-name"]) {
    throw new BootstrapError("--admin-name ist nur für Better Auth zulässig.")
  }
  if (authMode === "betterauth" && parsed.values["admin-user-id"]) {
    throw new BootstrapError("--admin-user-id ist nur für Clerk zulässig.")
  }

  const pool = new pg.Pool(
    poolOptions(databaseUrl, process.env.DATABASE_SSL_ALLOW_SELF_SIGNED === "true")
  )
  let password = process.env.BETTER_AUTH_BOOTSTRAP_PASSWORD
  delete process.env.BETTER_AUTH_BOOTSTRAP_PASSWORD
  const secrets = [databaseUrl, databaseTarget.password, process.env.CLERK_SECRET_KEY, password]

  try {
    await inspectInstallation(pool, authMode)

    let authInput
    if (authMode === "clerk") {
      let email = parsed.values["admin-email"]
      let userId = parsed.values["admin-user-id"]
      if (!email && !userId && !parsed.nonInteractive) {
        const identifier = (await ask("Clerk-E-Mail oder User-ID: ")).trim()
        if (identifier.includes("@")) email = identifier
        else userId = identifier
      }
      if (!email && !userId) {
        throw new BootstrapError("Für Clerk ist --admin-email oder --admin-user-id erforderlich.")
      }
      const admin = await resolveClerkAdmin({
        email,
        userId,
        secretKey: process.env.CLERK_SECRET_KEY,
      })
      authInput = { adminId: admin.id }
    } else {
      const adminEmail = normalizeEmail(
        await valueOrPrompt(parsed.values, "admin-email", "Admin-E-Mail: ", parsed.nonInteractive)
      )
      const adminName = String(
        await valueOrPrompt(parsed.values, "admin-name", "Admin-Anzeigename: ", parsed.nonInteractive)
      ).trim().replace(/\s+/g, " ")
      if (!adminName) throw new BootstrapError("Der Admin-Anzeigename darf nicht leer sein.")
      if (password === undefined) {
        if (parsed.nonInteractive) {
          throw new BootstrapError(
            "Im non-interaktiven Modus fehlt BETTER_AUTH_BOOTSTRAP_PASSWORD."
          )
        }
        password = await readHidden("Passwort (mindestens 8 Zeichen): ")
        const repeated = await readHidden("Passwort wiederholen: ")
        validateBetterAuthPassword(password, repeated)
      } else {
        validateBetterAuthPassword(password, password)
      }
      secrets.push(password)
      authInput = {
        adminEmail,
        adminName,
        passwordHash: await hashPassword(password),
      }
    }

    console.log("\nGeplanter Schreibzugriff:")
    console.log(`  Host: ${databaseTarget.host}`)
    console.log(`  Port: ${databaseTarget.port}`)
    console.log(`  Datenbank: ${databaseTarget.database}`)
    console.log(`  DB-Benutzer: ${databaseTarget.user}`)
    console.log(`  Auth-Modus: ${authMode}`)
    console.log(`  Organisationstyp: ${organizationType}`)

    const confirmation = parsed.values["confirm-database"] ??
      (parsed.nonInteractive
        ? requiredNonInteractive(parsed.values, "confirm-database")
        : await ask(`Zum Bestätigen Datenbanknamen ${databaseTarget.database} eingeben: `))
    if (confirmation !== databaseTarget.database) {
      throw new BootstrapError("Datenbankbestätigung stimmt nicht überein; es wurde nichts geschrieben.")
    }

    await initializeInstallation(pool, {
      authMode,
      organizationName,
      organizationType,
      ...authInput,
    })
    console.log("PAOLO wurde mit einer Organisation und einem globalen Administrator initialisiert.")
  } catch (error) {
    const message = error instanceof Error ? error.message : "Bootstrap fehlgeschlagen."
    throw new BootstrapError(sanitizeText(message, secrets), error?.code)
  } finally {
    password = undefined
    await pool.end()
  }
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : "Bootstrap fehlgeschlagen.")
  process.exitCode = 1
})
