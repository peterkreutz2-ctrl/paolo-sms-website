import { config } from "dotenv"

config({ path: ".env.local" })

import { hashPassword } from "better-auth/crypto"
import { and, eq, isNull, sql } from "drizzle-orm"

import { db } from "../lib/db"
import {
  betterAuthAccounts,
  betterAuthUsers,
  roles,
  userRoles,
} from "../lib/db/schema"

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

function readHiddenPassword(prompt: string): Promise<string> {
  const fromEnvironment = process.env.BETTER_AUTH_BOOTSTRAP_PASSWORD
  delete process.env.BETTER_AUTH_BOOTSTRAP_PASSWORD
  if (fromEnvironment !== undefined) return Promise.resolve(fromEnvironment)

  if (!process.stdin.isTTY || typeof process.stdin.setRawMode !== "function") {
    throw new Error(
      "Kein interaktives Terminal. BETTER_AUTH_BOOTSTRAP_PASSWORD nur für diesen Befehl setzen."
    )
  }

  return new Promise((resolve, reject) => {
    let password = ""
    process.stdout.write(prompt)
    process.stdin.setRawMode(true)
    process.stdin.resume()
    process.stdin.setEncoding("utf8")

    const finish = (error?: Error) => {
      process.stdin.setRawMode(false)
      process.stdin.pause()
      process.stdin.removeListener("data", onData)
      process.stdout.write("\n")
      if (error) reject(error)
      else resolve(password)
    }

    const onData = (key: string) => {
      if (key === "\u0003") return finish(new Error("Abgebrochen."))
      if (key === "\r" || key === "\n") return finish()
      if (key === "\u0008" || key === "\u007f") {
        if (password.length > 0) {
          password = password.slice(0, -1)
          process.stdout.write("\b \b")
        }
        return
      }
      if (!key.startsWith("\u001b")) {
        password += key
        process.stdout.write("*")
      }
    }

    process.stdin.on("data", onData)
  })
}

async function main() {
  if (process.env.AUTH_MODE !== "betterauth") {
    throw new Error("AUTH_MODE muss auf betterauth gesetzt sein.")
  }

  const email = process.argv[2]?.trim().toLowerCase()
  const name = process.argv.slice(3).join(" ").trim() || "Administrator"
  if (!email || !EMAIL_RE.test(email)) {
    throw new Error(
      "Aufruf: npm run auth:bootstrap-admin -- admin@example.org [Anzeigename]"
    )
  }

  const password = await readHiddenPassword("Passwort (mindestens 8 Zeichen): ")
  if (password.length < 8) throw new Error("Das Passwort muss mindestens 8 Zeichen lang sein.")
  const passwordHash = await hashPassword(password)
  const userId = crypto.randomUUID()
  const now = new Date()

  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(70651001)`)

    const [existingUser] = await tx.select({ id: betterAuthUsers.id }).from(betterAuthUsers).limit(1)
    const [existingAdmin] = await tx
      .select({ id: userRoles.id })
      .from(userRoles)
      .innerJoin(roles, eq(userRoles.roleId, roles.id))
      .innerJoin(betterAuthUsers, eq(userRoles.clerkUserId, betterAuthUsers.id))
      .where(and(eq(roles.key, "admin"), isNull(userRoles.organizationId)))
      .limit(1)

    if (existingUser || existingAdmin) {
      throw new Error(
        "Bootstrap verweigert: Ein Better-Auth-Benutzer oder globaler Administrator existiert bereits."
      )
    }

    await tx.insert(roles).values({ key: "admin", label: "Administrator" }).onConflictDoNothing({ target: roles.key })
    const [adminRole] = await tx.select({ id: roles.id }).from(roles).where(eq(roles.key, "admin")).limit(1)
    if (!adminRole) throw new Error("Die Administratorrolle konnte nicht angelegt werden.")

    await tx.insert(betterAuthUsers).values({
      id: userId,
      name,
      email,
      emailVerified: true,
      createdAt: now,
      updatedAt: now,
    })
    await tx.insert(betterAuthAccounts).values({
      id: crypto.randomUUID(),
      accountId: userId,
      providerId: "credential",
      userId,
      password: passwordHash,
      createdAt: now,
      updatedAt: now,
    })
    await tx.insert(userRoles).values({ clerkUserId: userId, roleId: adminRole.id })
  })

  console.log(`Better-Auth-Administrator ${email} wurde angelegt.`)
}

main()
  .then(() => process.exit(0))
  .catch((error: unknown) => {
    console.error(error instanceof Error ? error.message : "Bootstrap fehlgeschlagen.")
    process.exit(1)
  })
