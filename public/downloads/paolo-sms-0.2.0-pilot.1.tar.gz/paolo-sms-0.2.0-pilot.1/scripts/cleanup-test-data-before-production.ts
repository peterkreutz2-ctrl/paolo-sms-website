// scripts/cleanup-test-data-before-production.ts
//
// Kontrolliertes Wartungsskript zur Testdatenbereinigung vor einem Produktivstart.
//
// Aufruf (TypeScript, via tsx):
//   npx tsx scripts/cleanup-test-data-before-production.ts
//
// ACHTUNG — PRODUKTIONSKRITISCH:
//   Dieses Skript löscht KEINE einzelnen Testdaten, sondern ganze
//   Tabellenbereiche (report_notes, measures, attachments, reports,
//   safety_meetings, audit_logs) sowie alle user_roles außerhalb der Keep-Liste
//   und die zugehörigen Storage-Dateien der Attachments. Es unterscheidet NICHT
//   zwischen Test- und Echtdaten. Vor jeder Verwendung Ziel-DB, Keep-Liste und
//   Umgebung prüfen.
//
// STANDARD IST DRY-RUN. Es werden keine Daten verändert, solange nicht
// ausdrücklich per Umgebungsvariablen scharfgeschaltet wird:
//   CONFIRM_CLEANUP=true            -> schaltet das echte Löschen frei
//   CONFIRM_TARGET=<host-oder-db>   -> muss zum Ziel passen (zweite Bestätigung)
//   KEEP_CLERK_USER_IDS=a,b,c       -> zu erhaltende Rollen (kommagetrennt)
//   CLEANUP_ENV_FILE=.env.local     -> zu ladende Env-Datei (Default .env.local)
//
// DB-Zugriff über den Standard-PostgreSQL-Treiber (pg) und DATABASE_URL.
// Die Löschung der Attachment-Dateien läuft provider-neutral über die
// Storage-Schicht (lib/storage: deleteStoredFile) und richtet sich nach
// STORAGE_PROVIDER (Default "vercel-blob", alternativ "local"). BLOB_READ_WRITE_TOKEN
// wird nur bei STORAGE_PROVIDER=vercel-blob benötigt. „Datei fehlt" ist im jeweiligen
// Provider ein No-op; echte Storage-Fehler brechen den echten Lauf ab.

import { config } from "dotenv"
import { resolve, dirname } from "path"
import { fileURLToPath } from "url"
import { Pool } from "pg"

const __dirname = dirname(fileURLToPath(import.meta.url))

// --- Env-Datei laden (konfigurierbar, sichtbar) ---
const ENV_FILE = process.env.CLEANUP_ENV_FILE ?? ".env.local"
const ENV_PATH = resolve(__dirname, "..", ENV_FILE)
const envResult = config({ path: ENV_PATH })

// --- Scharfschaltung ausschließlich über Env, Default Dry-Run ---
const CONFIRM_CLEANUP = process.env.CONFIRM_CLEANUP === "true"
const CONFIRM_TARGET = process.env.CONFIRM_TARGET ?? ""

// --- Storage-Provider: Default bleibt vercel-blob (wie in lib/storage) ---
const STORAGE_PROVIDER = process.env.STORAGE_PROVIDER ?? "vercel-blob"
const IS_VERCEL_BLOB = STORAGE_PROVIDER === "vercel-blob"

// --- Keep-Liste: bevorzugt aus Env, sonst hartcodierter Fallback ---
// Der Fallback ist INSTANZSPEZIFISCH (aktuelle Produktions-Clerk-IDs) und nur als
// Notnagel gedacht. Für andere Instanzen zwingend KEEP_CLERK_USER_IDS setzen.
const FALLBACK_KEEP_CLERK_USER_IDS = [
  "user_3DRZvHymipyKvLDbPTfW6Z5xB2N", // Peter Kreutz   – Administrator
  "user_3DmG0i6MVRLwXmLg68RnHue5ZXa", // T Behrens       – Administrator
  "user_3DfMtICGg8fuWMCdMQZFWzXtZe9", // instructor7      – Safety Assistant
  "user_3DxUX13k1ELhGIw5EdL82368GUD", // sm2              – Safety Manager
]

const envKeepRaw = process.env.KEEP_CLERK_USER_IDS ?? ""
const envKeepIds = envKeepRaw
  .split(",")
  .map((s) => s.trim())
  .filter((s) => s.length > 0)

const KEEP_FROM_ENV = envKeepIds.length > 0
const KEEP_CLERK_USER_IDS = KEEP_FROM_ENV
  ? envKeepIds
  : FALLBACK_KEEP_CLERK_USER_IDS

const LOCAL_HOSTS = new Set(["localhost", "127.0.0.1", "::1", "db"])

interface TargetInfo {
  host: string
  port: string
  dbName: string
}

function inParams(ids: string[]): string {
  return ids.map((_, i) => `$${i + 1}`).join(", ")
}

// Zerlegt DATABASE_URL in anzeigbare Zielangaben OHNE User/Passwort.
function parseTarget(databaseUrl: string): TargetInfo {
  const u = new URL(databaseUrl)
  const host = u.hostname
  const port = u.port || "5432"
  const dbName = decodeURIComponent(u.pathname.replace(/^\//, "")) || "(unbekannt)"
  return { host, port, dbName }
}

async function getCounts(
  pool: Pool,
  keepIds: string[]
): Promise<Record<string, number>> {
  const simple: [string, string][] = [
    ["reports", "SELECT COUNT(*) FROM reports"],
    ["measures", "SELECT COUNT(*) FROM measures"],
    ["attachments", "SELECT COUNT(*) FROM attachments"],
    ["report_notes", "SELECT COUNT(*) FROM report_notes"],
    ["safety_meetings", "SELECT COUNT(*) FROM safety_meetings"],
    ["audit_logs", "SELECT COUNT(*) FROM audit_logs"],
    ["user_roles", "SELECT COUNT(*) FROM user_roles"],
    ["organizations", "SELECT COUNT(*) FROM organizations"],
    ["roles", "SELECT COUNT(*) FROM roles"],
  ]

  const counts: Record<string, number> = {}

  for (const [label, sql] of simple) {
    const res = await pool.query(sql)
    counts[label] = parseInt(res.rows[0].count, 10)
  }

  if (keepIds.length > 0) {
    const ph = inParams(keepIds)
    const keep = await pool.query(
      `SELECT COUNT(*) FROM user_roles WHERE clerk_user_id IN (${ph})`,
      keepIds
    )
    const remove = await pool.query(
      `SELECT COUNT(*) FROM user_roles WHERE clerk_user_id NOT IN (${ph})`,
      keepIds
    )
    counts["user_roles (erhalten)"] = parseInt(keep.rows[0].count, 10)
    counts["user_roles (entfernen)"] = parseInt(remove.rows[0].count, 10)
  } else {
    counts["user_roles (erhalten)"] = 0
    counts["user_roles (entfernen)"] = counts["user_roles"]
  }

  return counts
}

function printCounts(counts: Record<string, number>, header: string): void {
  console.log(`\n=== ${header} ===`)
  for (const [key, val] of Object.entries(counts)) {
    console.log(`  ${key.padEnd(28)} ${val}`)
  }
}

async function verifyKeepUserRoles(
  pool: Pool,
  keepIds: string[]
): Promise<void> {
  const total = await pool.query("SELECT COUNT(*) FROM user_roles")
  const totalCount = parseInt(total.rows[0].count, 10)

  let keepCount = 0
  let outsideCount = totalCount
  if (keepIds.length > 0) {
    const ph = inParams(keepIds)
    const keep = await pool.query(
      `SELECT COUNT(*) FROM user_roles WHERE clerk_user_id IN (${ph})`,
      keepIds
    )
    const outside = await pool.query(
      `SELECT COUNT(*) FROM user_roles WHERE clerk_user_id NOT IN (${ph})`,
      keepIds
    )
    keepCount = parseInt(keep.rows[0].count, 10)
    outsideCount = parseInt(outside.rows[0].count, 10)
  }

  console.log("\n=== NACHKONTROLLE USER ROLES ===")
  console.log(`  user_roles gesamt               ${totalCount}`)
  console.log(`  user_roles Keep-Liste           ${keepCount}`)
  console.log(`  user_roles außerhalb Keep-Liste ${outsideCount}  (erwartet: 0)`)

  const ok = totalCount === keepCount && outsideCount === 0
  if (ok) {
    console.log("\n  ✅  Nachkontrolle bestanden.")
  } else {
    console.log("\n  ⚠️  WARNUNG: Nachkontrolle fehlgeschlagen!")
    console.log("      Bitte user_roles manuell prüfen.")
    process.exitCode = 1
  }
}

function printSecurityBanner(target: TargetInfo, hasToken: boolean): void {
  console.log("\n" + "═".repeat(60))
  console.log("  PAOLO – Testdatenbereinigung")
  console.log("═".repeat(60))
  console.log(`  Modus:            ${CONFIRM_CLEANUP ? "CONFIRM (echtes Löschen)" : "DRY-RUN (keine Änderung)"}`)
  console.log(`  Env-Datei:        ${ENV_PATH}${envResult.error ? "  (nicht gefunden – nutze vorhandene Umgebung)" : ""}`)
  console.log(`  Ziel-Datenbank:   ${target.host}:${target.port} / ${target.dbName}`)
  console.log(`  Keep-IDs:         ${KEEP_CLERK_USER_IDS.length} (${KEEP_FROM_ENV ? "aus KEEP_CLERK_USER_IDS" : "HARTCODIERTER FALLBACK – instanzspezifisch!"})`)
  console.log(`  Storage:          Löschung über Storage-Schicht (Provider: ${STORAGE_PROVIDER})`)
  if (IS_VERCEL_BLOB) {
    console.log(`  Vercel-Blob:      Token ${hasToken ? "gesetzt" : "FEHLT"} (nur für Provider vercel-blob nötig)`)
  }
  console.log("  Hinweis:          Löscht keine einzelnen Testdaten, sondern GANZE Tabellenbereiche.")
  if (!LOCAL_HOSTS.has(target.host)) {
    console.log("\n  ⚠️  ZIEL IST KEINE LOKALE DATENBANK (mögliche Produktion). Besondere Vorsicht!")
    if (target.host.endsWith("neon.tech")) {
      console.log("  ⚠️  Host sieht nach Neon aus.")
    }
  }
  console.log("═".repeat(60))
}

async function main(): Promise<void> {
  const hasToken = Boolean(process.env.BLOB_READ_WRITE_TOKEN)

  if (!process.env.DATABASE_URL) {
    console.error(`FEHLER: DATABASE_URL nicht gesetzt. Geladene Env-Datei: ${ENV_PATH}`)
    process.exit(1)
  }

  let target: TargetInfo
  try {
    target = parseTarget(process.env.DATABASE_URL)
  } catch {
    console.error("FEHLER: DATABASE_URL konnte nicht als URL geparst werden. Abbruch.")
    process.exit(1)
  }

  printSecurityBanner(target, hasToken)

  // --- Guards NUR für echtes Löschen (Dry-Run analysiert immer) ---
  if (CONFIRM_CLEANUP) {
    if (KEEP_CLERK_USER_IDS.length === 0) {
      console.error("\nFEHLER: CONFIRM_CLEANUP=true, aber Keep-Liste ist leer. Abbruch (würde alle user_roles löschen).")
      process.exit(1)
    }
    if (!CONFIRM_TARGET || (CONFIRM_TARGET !== target.host && CONFIRM_TARGET !== target.dbName)) {
      console.error(`\nFEHLER: CONFIRM_TARGET stimmt nicht mit dem Ziel überein. Erwartet: Host "${target.host}" oder DB-Name "${target.dbName}". Abbruch.`)
      process.exit(1)
    }
  } else {
    if (KEEP_CLERK_USER_IDS.length === 0) {
      console.log("\n  ⚠️  Dry-Run mit leerer Keep-Liste: bei echtem Lauf würden ALLE user_roles gelöscht.")
    }
    if (IS_VERCEL_BLOB && !hasToken) {
      console.log("  ⚠️  STORAGE_PROVIDER=vercel-blob, aber BLOB_READ_WRITE_TOKEN fehlt: Attachment-Dateien könnten bei echtem Lauf nicht gelöscht werden.")
    }
  }

  const pool = new Pool({ connectionString: process.env.DATABASE_URL })

  try {
    const before = await getCounts(pool, KEEP_CLERK_USER_IDS)
    printCounts(before, "ZÄHLUNG VOR BEREINIGUNG")

    const blobRows = await pool.query(
      "SELECT storage_key, original_file_name FROM attachments ORDER BY created_at"
    )

    console.log(`\n=== ATTACHMENT-DATEIEN ZUM LÖSCHEN (${blobRows.rows.length}) ===`)
    for (const row of blobRows.rows) {
      console.log(`  ${row.storage_key}  (${row.original_file_name})`)
    }

    if (KEEP_CLERK_USER_IDS.length > 0) {
      const ph = inParams(KEEP_CLERK_USER_IDS)

      const removeRoles = await pool.query(
        `SELECT ur.clerk_user_id, r.key AS role_key
           FROM user_roles ur
           JOIN roles r ON ur.role_id = r.id
          WHERE ur.clerk_user_id NOT IN (${ph})
          ORDER BY ur.clerk_user_id`,
        KEEP_CLERK_USER_IDS
      )
      console.log(`\n=== USER ROLES ZUM ENTFERNEN (${removeRoles.rows.length}) ===`)
      for (const row of removeRoles.rows) {
        console.log(`  ${row.clerk_user_id}  |  ${row.role_key}`)
      }

      const keepRoles = await pool.query(
        `SELECT ur.clerk_user_id, r.key AS role_key
           FROM user_roles ur
           JOIN roles r ON ur.role_id = r.id
          WHERE ur.clerk_user_id IN (${ph})
          ORDER BY ur.clerk_user_id`,
        KEEP_CLERK_USER_IDS
      )
      console.log(`\n=== USER ROLES DIE BLEIBEN (${keepRoles.rows.length}) ===`)
      for (const row of keepRoles.rows) {
        console.log(`  ${row.clerk_user_id}  |  ${row.role_key}`)
      }
    }

    if (!CONFIRM_CLEANUP) {
      console.log("\n" + "═".repeat(60))
      console.log("  DRY RUN – CONFIRM_CLEANUP ist nicht 'true'.")
      console.log("  Keine Daten wurden geändert.")
      console.log("  Zum Ausführen: CONFIRM_CLEANUP=true und CONFIRM_TARGET=<host|dbname> setzen.")
      console.log("═".repeat(60))
      return
    }

    // --- DB-abhängige Guards vor dem echten Löschen ---
    if (before["user_roles (erhalten)"] === 0) {
      console.error("\nFEHLER: Keine der Keep-IDs existiert in user_roles. Abbruch (Schutz vor Total-Rollen-Löschung).")
      return
    }
    if (IS_VERCEL_BLOB && blobRows.rows.length > 0 && !hasToken) {
      console.error("\nFEHLER: STORAGE_PROVIDER=vercel-blob und Attachments vorhanden, aber BLOB_READ_WRITE_TOKEN fehlt. Abbruch vor jeder Änderung.")
      return
    }

    // Storage-Schicht erst NACH dem dotenv-Load dynamisch importieren, damit
    // STORAGE_PROVIDER bei der Provider-Initialisierung (lib/storage) gesetzt ist.
    // Ein statischer Import würde die Provider-Auswahl vor dem Env-Laden auslösen.
    const { deleteStoredFile } = await import("../lib/storage/index")

    console.log("\n" + "═".repeat(60))
    console.log("  BEREINIGUNG WIRD AUSGEFÜHRT")
    console.log("═".repeat(60))

    console.log(`\n[1/8] Attachment-Dateien über Storage-Schicht löschen (Provider: ${STORAGE_PROVIDER})...`)
    let storageOk = 0
    for (const row of blobRows.rows) {
      try {
        await deleteStoredFile(row.storage_key)
        storageOk++
        console.log(`  ✓  ${row.storage_key}`)
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err)
        console.error(`  ✗  ${row.storage_key}  FEHLER: ${message}`)
        throw err
      }
    }
    console.log(`     → ${storageOk} verarbeitet (fehlende Dateien sind im Provider ein No-op).`)

    console.log("\n[2/8] report_notes löschen...")
    const rn = await pool.query("DELETE FROM report_notes")
    console.log(`     → ${rn.rowCount} Zeilen gelöscht.`)

    console.log("\n[3/8] measures löschen...")
    const ms = await pool.query("DELETE FROM measures")
    console.log(`     → ${ms.rowCount} Zeilen gelöscht.`)

    console.log("\n[4/8] attachments löschen...")
    const at = await pool.query("DELETE FROM attachments")
    console.log(`     → ${at.rowCount} Zeilen gelöscht.`)

    console.log("\n[5/8] reports löschen...")
    const rp = await pool.query("DELETE FROM reports")
    console.log(`     → ${rp.rowCount} Zeilen gelöscht.`)

    console.log("\n[6/8] safety_meetings löschen...")
    const sm = await pool.query("DELETE FROM safety_meetings")
    console.log(`     → ${sm.rowCount} Zeilen gelöscht.`)

    console.log("\n[7/8] audit_logs löschen...")
    const al = await pool.query("DELETE FROM audit_logs")
    console.log(`     → ${al.rowCount} Zeilen gelöscht.`)

    console.log("\n[8/8] user_roles entfernen (außer Keep-Liste)...")
    const ph = inParams(KEEP_CLERK_USER_IDS)
    const ur = await pool.query(
      `DELETE FROM user_roles WHERE clerk_user_id NOT IN (${ph})`,
      KEEP_CLERK_USER_IDS
    )
    console.log(`     → ${ur.rowCount} Zeilen gelöscht.`)

    const after = await getCounts(pool, KEEP_CLERK_USER_IDS)
    printCounts(after, "ZÄHLUNG NACH BEREINIGUNG")

    await verifyKeepUserRoles(pool, KEEP_CLERK_USER_IDS)

    if (process.exitCode !== 1) {
      console.log("\n" + "═".repeat(60))
      console.log("  ✅  Bereinigung erfolgreich abgeschlossen.")
      console.log("═".repeat(60))
    } else {
      console.log("\n" + "═".repeat(60))
      console.log("  ⚠️  Bereinigung abgeschlossen, aber Nachkontrolle fehlgeschlagen.")
      console.log("      Bitte Datenbankzustand manuell prüfen.")
      console.log("═".repeat(60))
    }
  } finally {
    await pool.end()
  }
}

main().catch((err) => {
  console.error("\nFATAL:", err)
  process.exit(1)
})
