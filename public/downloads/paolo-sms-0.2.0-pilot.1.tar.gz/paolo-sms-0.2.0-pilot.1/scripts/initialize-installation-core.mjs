import { randomUUID } from "node:crypto"

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const ORGANIZATION_TYPES = new Set(["club", "flight_school"])
const KNOWN_ARGUMENTS = new Set([
  "organization-name",
  "organization-type",
  "admin-email",
  "admin-user-id",
  "admin-name",
  "confirm-database",
])
const REQUIRED_TABLES = ["organizations", "roles", "user_roles", "audit_logs"]
const BETTER_AUTH_TABLES = ["better_auth_users", "better_auth_accounts"]
const BOOTSTRAP_LOCK_ID = 70651002

export class BootstrapError extends Error {
  constructor(message, code = "bootstrap_error") {
    super(message)
    this.name = "BootstrapError"
    this.code = code
  }
}

export function parseArguments(argv) {
  const values = {}
  let nonInteractive = false
  let help = false

  for (const argument of argv) {
    if (argument === "--non-interactive") {
      nonInteractive = true
      continue
    }
    if (argument === "--help" || argument === "-h") {
      help = true
      continue
    }
    if (!argument.startsWith("--") || !argument.includes("=")) {
      throw new BootstrapError(`Ungültiges Argument: ${argument}`, "invalid_argument")
    }
    const separator = argument.indexOf("=")
    const key = argument.slice(2, separator)
    const value = argument.slice(separator + 1)
    if (!KNOWN_ARGUMENTS.has(key)) {
      throw new BootstrapError(`Unbekanntes Argument: --${key}`, "invalid_argument")
    }
    if (Object.hasOwn(values, key)) {
      throw new BootstrapError(`Argument doppelt angegeben: --${key}`, "invalid_argument")
    }
    values[key] = value
  }

  return { values, nonInteractive, help }
}

export function parseDatabaseTarget(connectionString) {
  if (!connectionString) {
    throw new BootstrapError("DATABASE_URL ist nicht gesetzt.", "missing_database_url")
  }

  let url
  try {
    url = new URL(connectionString)
  } catch {
    throw new BootstrapError("DATABASE_URL ist keine gültige PostgreSQL-URL.", "invalid_database_url")
  }
  if (url.protocol !== "postgres:" && url.protocol !== "postgresql:") {
    throw new BootstrapError("DATABASE_URL muss postgres:// oder postgresql:// verwenden.", "invalid_database_url")
  }

  const database = decodeURIComponent(url.pathname.replace(/^\//, ""))
  if (!url.hostname || !database) {
    throw new BootstrapError("DATABASE_URL muss Host und Datenbankname enthalten.", "invalid_database_url")
  }

  return {
    host: url.hostname,
    port: url.port || "5432",
    database,
    user: decodeURIComponent(url.username || "(nicht angegeben)"),
    password: decodeURIComponent(url.password || ""),
  }
}

export function poolOptions(connectionString, allowSelfSignedCertificate = false) {
  if (!allowSelfSignedCertificate) {
    return { connectionString, max: 1, connectionTimeoutMillis: 10_000 }
  }
  const url = new URL(connectionString)
  url.searchParams.set("sslmode", "no-verify")
  return { connectionString: url.toString(), max: 1, connectionTimeoutMillis: 10_000 }
}

export function normalizeOrganizationName(value) {
  const result = String(value ?? "").trim().replace(/\s+/g, " ")
  if (!result) throw new BootstrapError("Der Organisationsname darf nicht leer sein.", "invalid_input")
  return result
}

export function normalizeOrganizationType(value, { interactive = false } = {}) {
  const normalized = String(value ?? "").trim().toLowerCase()
  const aliases = interactive
    ? { "1": "club", verein: "club", "2": "flight_school", flugschule: "flight_school" }
    : {}
  const result = aliases[normalized] ?? normalized
  if (!ORGANIZATION_TYPES.has(result)) {
    throw new BootstrapError("Organisationstyp muss club oder flight_school sein.", "invalid_input")
  }
  return result
}

export function normalizeEmail(value) {
  const email = String(value ?? "").trim().toLowerCase()
  if (!EMAIL_RE.test(email)) throw new BootstrapError("Ungültige E-Mail-Adresse.", "invalid_input")
  return email
}

export function validateBetterAuthPassword(password, repeatedPassword) {
  if (String(password ?? "").length < 8) {
    throw new BootstrapError("Das Passwort muss mindestens 8 Zeichen lang sein.", "invalid_input")
  }
  if (password !== repeatedPassword) {
    throw new BootstrapError("Die Passwörter stimmen nicht überein.", "invalid_input")
  }
  return password
}

export function sanitizeText(value, secrets = []) {
  let result = String(value ?? "")
  for (const secret of secrets) {
    if (secret) result = result.split(String(secret)).join("[REDACTED]")
  }
  return result
}

function verifiedEmail(user, requestedEmail) {
  const addresses = Array.isArray(user?.email_addresses) ? user.email_addresses : []
  const selected = requestedEmail
    ? addresses.find((item) => item?.email_address?.toLowerCase() === requestedEmail)
    : addresses.find((item) => item?.id === user?.primary_email_address_id)
  return selected?.verification?.status === "verified"
}

function validateClerkUser(user, requestedEmail) {
  if (!user?.id) throw new BootstrapError("Clerk-Benutzer wurde nicht gefunden.", "clerk_user_invalid")
  if (user.banned || user.locked) {
    throw new BootstrapError("Das Clerk-Konto ist gesperrt oder gebannt.", "clerk_user_inactive")
  }
  if (!verifiedEmail(user, requestedEmail)) {
    throw new BootstrapError("Das Clerk-Konto besitzt keine passende verifizierte E-Mail-Adresse.", "clerk_email_unverified")
  }
  return { id: user.id }
}

async function clerkRequest(path, secretKey, fetchImpl) {
  let response
  try {
    response = await fetchImpl(`https://api.clerk.com${path}`, {
      headers: { Authorization: `Bearer ${secretKey}` },
    })
  } catch {
    throw new BootstrapError("Clerk ist nicht erreichbar; es wurde nichts geschrieben.", "clerk_unavailable")
  }
  if (!response.ok) {
    throw new BootstrapError("Clerk-Verifikation fehlgeschlagen; es wurde nichts geschrieben.", "clerk_unavailable")
  }
  try {
    return await response.json()
  } catch {
    throw new BootstrapError("Clerk lieferte keine gültige Antwort; es wurde nichts geschrieben.", "clerk_unavailable")
  }
}

/**
 * @param {{
 *   email?: string,
 *   userId?: string,
 *   secretKey?: string,
 *   fetchImpl?: typeof fetch
 * }} options
 */
export async function resolveClerkAdmin({ email, userId, secretKey, fetchImpl = fetch }) {
  if (!secretKey) throw new BootstrapError("CLERK_SECRET_KEY ist nicht gesetzt.", "missing_clerk_secret")
  if (Boolean(email) === Boolean(userId)) {
    throw new BootstrapError("Genau eine Clerk-E-Mail oder User-ID ist erforderlich.", "invalid_input")
  }

  if (userId) {
    const normalizedId = String(userId).trim()
    if (!normalizedId) throw new BootstrapError("Die Clerk-User-ID darf nicht leer sein.", "invalid_input")
    const user = await clerkRequest(`/v1/users/${encodeURIComponent(normalizedId)}`, secretKey, fetchImpl)
    return validateClerkUser(user)
  }

  const normalizedEmail = normalizeEmail(email)
  const response = await clerkRequest(
    `/v1/users?email_address=${encodeURIComponent(normalizedEmail)}&limit=100`,
    secretKey,
    fetchImpl
  )
  const candidates = Array.isArray(response) ? response : response?.data
  const exact = (Array.isArray(candidates) ? candidates : []).filter((user) =>
    user?.email_addresses?.some(
      (item) => item?.email_address?.toLowerCase() === normalizedEmail
    )
  )
  if (exact.length !== 1) {
    throw new BootstrapError(
      exact.length === 0
        ? "Kein Clerk-Benutzer mit dieser E-Mail-Adresse gefunden."
        : "Die Clerk-E-Mail-Adresse ist nicht eindeutig.",
      "clerk_user_invalid"
    )
  }
  return validateClerkUser(exact[0], normalizedEmail)
}

async function requireSchema(client, authMode) {
  const required = authMode === "betterauth"
    ? [...REQUIRED_TABLES, ...BETTER_AUTH_TABLES]
    : REQUIRED_TABLES
  const result = await client.query(
    "SELECT name, to_regclass('public.' || name) IS NOT NULL AS present FROM unnest($1::text[]) AS name",
    [required]
  )
  const missing = result.rows.filter((row) => !row.present).map((row) => row.name)
  if (missing.length > 0) {
    throw new BootstrapError(
      `Datenbankschema unvollständig (${missing.length} erforderliche Tabellen fehlen). Bitte zuerst migrate.sh ausführen.`,
      "schema_incomplete"
    )
  }

  const adminRoles = await client.query("SELECT count(*)::int AS count FROM roles WHERE key = 'admin'")
  if (adminRoles.rows[0]?.count !== 1) {
    throw new BootstrapError(
      "Administratorrolle fehlt oder ist nicht eindeutig. Bitte Migrationen prüfen.",
      "schema_incomplete"
    )
  }
}

async function requireFresh(client, authMode) {
  const result = await client.query(`
    SELECT
      (SELECT count(*)::int FROM organizations) AS organizations,
      (SELECT count(*)::int FROM user_roles) AS role_assignments
      ${authMode === "betterauth" ? `,
      (SELECT count(*)::int FROM better_auth_users) AS better_auth_users,
      (SELECT count(*)::int FROM better_auth_accounts) AS better_auth_accounts` : ""}
  `)
  const state = result.rows[0]
  const counts = {
    organizations: state.organizations,
    roleAssignments: state.role_assignments,
    ...(authMode === "betterauth"
      ? {
          betterAuthUsers: state.better_auth_users,
          betterAuthAccounts: state.better_auth_accounts,
        }
      : {}),
  }
  if (Object.values(counts).some((count) => count !== 0)) {
    throw new BootstrapError(
      `Bootstrap verweigert: Installation ist nicht frisch (${Object.entries(counts)
        .map(([key, count]) => `${key}=${count}`)
        .join(", ")}).`,
      "not_fresh"
    )
  }
  return counts
}

export async function inspectInstallation(pool, authMode) {
  const client = await pool.connect()
  try {
    await requireSchema(client, authMode)
    return await requireFresh(client, authMode)
  } finally {
    client.release()
  }
}

export async function initializeInstallation(pool, input) {
  const client = await pool.connect()
  try {
    await client.query("BEGIN")
    await client.query("SELECT pg_advisory_xact_lock($1)", [BOOTSTRAP_LOCK_ID])
    await requireSchema(client, input.authMode)
    await requireFresh(client, input.authMode)

    const organization = await client.query(
      // display_name startet mit dem Namen (#117): Der Betreiber hat ihn gerade
      // eingegeben, und ein neuer Kopf ohne Namen waere kein sinnvoller Anfang.
      "INSERT INTO organizations (name, display_name, type) VALUES ($1, $1, $2) RETURNING id",
      [input.organizationName, input.organizationType]
    )
    const organizationId = organization.rows[0].id
    let adminId = input.adminId

    if (input.authMode === "betterauth") {
      adminId = randomUUID()
      const now = new Date()
      await client.query(
        `INSERT INTO better_auth_users
          (id, name, email, email_verified, created_at, updated_at)
         VALUES ($1, $2, $3, true, $4, $4)`,
        [adminId, input.adminName, input.adminEmail, now]
      )
      await client.query(
        `INSERT INTO better_auth_accounts
          (id, account_id, provider_id, user_id, password, created_at, updated_at)
         VALUES ($1, $2, 'credential', $2, $3, $4, $4)`,
        [randomUUID(), adminId, input.passwordHash, now]
      )
    }

    if (!adminId) throw new BootstrapError("Administrator-ID fehlt.", "invalid_input")
    const assignment = await client.query(
      `INSERT INTO user_roles (clerk_user_id, role_id, organization_id)
       SELECT $1, id, NULL FROM roles WHERE key = 'admin'
       RETURNING id`,
      [adminId]
    )
    if (assignment.rowCount !== 1) {
      throw new BootstrapError("Globale Administratorrolle konnte nicht zugewiesen werden.")
    }

    await client.query(
      `INSERT INTO audit_logs
        (organization_id, clerk_user_id, action, resource_type, resource_id, changes)
       VALUES ($1, $2, 'INSTALLATION_BOOTSTRAPPED', 'organization', $1, $3::jsonb)`,
      [
        organizationId,
        adminId,
        JSON.stringify({ authMode: input.authMode, organizationType: input.organizationType }),
      ]
    )
    await client.query("COMMIT")
    return { organizationId, adminId }
  } catch (error) {
    try {
      await client.query("ROLLBACK")
    } catch {
      // Preserve the original error; the pool is closed by the caller.
    }
    throw error
  } finally {
    client.release()
  }
}
