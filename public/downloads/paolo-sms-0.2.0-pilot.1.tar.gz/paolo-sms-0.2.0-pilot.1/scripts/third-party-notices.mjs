// Erzeugt die Drittanbieter-Lizenzliste fuer eine Weitergabe (Standalone-Build
// oder Docker-Image). GPLv3 verlangt beim Conveying eines Bundles, dass die
// Hinweise der mitgelieferten Pakete erhalten bleiben.
//
//   node scripts/third-party-notices.mjs            -> stdout
//   node scripts/third-party-notices.mjs --out FILE -> Datei
//   node scripts/third-party-notices.mjs --check    -> Exit 1 bei unbekannter
//                                                      oder GPL-unvertraeglicher Lizenz
//
// Liest den installierten node_modules-Baum, nicht package.json: Nur was
// tatsaechlich installiert ist, wird auch weitergegeben. Die Liste ist bewusst
// nicht eingecheckt, weil sie mit jedem Dependency-Update veraltet.

import fs from "node:fs"
import path from "node:path"

import { COMPATIBLE } from "./license-allowlist.mjs"

function readLicense(pkgJson, dir) {
  let license = pkgJson.license
  if (!license && pkgJson.licenses) {
    license = Array.isArray(pkgJson.licenses)
      ? pkgJson.licenses.map((l) => l.type || l).join(" OR ")
      : pkgJson.licenses.type || pkgJson.licenses
  }
  if (license && typeof license === "object") license = license.type
  if (!license) return { id: "UNKNOWN", file: null }

  const candidates = ["LICENSE", "LICENSE.md", "LICENSE.txt", "LICENCE", "COPYING"]
  const file = candidates.find((name) => fs.existsSync(path.join(dir, name))) ?? null
  return { id: String(license), file }
}

function collect(root, into) {
  let entries
  try {
    entries = fs.readdirSync(root, { withFileTypes: true })
  } catch {
    return
  }
  for (const entry of entries) {
    if (!entry.isDirectory() || entry.name === ".bin") continue
    const dir = path.join(root, entry.name)
    if (entry.name.startsWith("@")) {
      collect(dir, into)
      continue
    }
    const manifest = path.join(dir, "package.json")
    if (fs.existsSync(manifest)) {
      try {
        const pkg = JSON.parse(fs.readFileSync(manifest, "utf8"))
        const { id, file } = readLicense(pkg, dir)
        into.set(`${pkg.name ?? entry.name}@${pkg.version ?? "?"}`, {
          license: id,
          licenseFile: file ? path.relative(process.cwd(), path.join(dir, file)) : null,
          homepage: pkg.homepage ?? pkg.repository?.url ?? null,
        })
      } catch {
        // Unlesbares Manifest ueberspringen; --check meldet es nicht, weil das
        // Paket dann auch nicht im Bundle landet.
      }
    }
    const nested = path.join(dir, "node_modules")
    if (fs.existsSync(nested)) collect(nested, into)
  }
}

const packages = new Map()
collect(path.resolve("node_modules"), packages)

if (packages.size === 0) {
  console.error("node_modules ist leer — zuerst `npm install` ausfuehren.")
  process.exit(1)
}

const sorted = [...packages.entries()].sort(([a], [b]) => a.localeCompare(b))
const histogram = new Map()
for (const [, meta] of sorted) {
  histogram.set(meta.license, (histogram.get(meta.license) ?? 0) + 1)
}

const problems = sorted.filter(([, meta]) => !COMPATIBLE.has(meta.license))

const lines = []
lines.push("# Third-party notices")
lines.push("")
lines.push(
  "PAOLO SMS steht unter GPL-3.0-or-later. Die folgenden Pakete werden mit " +
    "einem Standalone-Build oder Docker-Image weitergegeben und stehen unter " +
    "eigenen, GPLv3-vertraeglichen Lizenzen. Ihre vollstaendigen Lizenztexte " +
    "liegen in den jeweiligen Paketverzeichnissen."
)
lines.push("")
lines.push(`Erzeugt am ${new Date().toISOString().slice(0, 10)} aus dem installierten Baum.`)
lines.push("")
lines.push("## Uebersicht")
lines.push("")
lines.push("| Lizenz | Pakete |")
lines.push("|---|---:|")
for (const [license, count] of [...histogram].sort((a, b) => b[1] - a[1])) {
  lines.push(`| ${license} | ${count} |`)
}
lines.push("")
lines.push(`Gesamt: ${sorted.length} Pakete.`)
lines.push("")
lines.push("## Pakete")
lines.push("")
lines.push("| Paket | Lizenz | Lizenztext |")
lines.push("|---|---|---|")
for (const [id, meta] of sorted) {
  lines.push(`| \`${id}\` | ${meta.license} | ${meta.licenseFile ? `\`${meta.licenseFile}\`` : "—"} |`)
}
lines.push("")

const output = lines.join("\n")
const outIndex = process.argv.indexOf("--out")

if (process.argv.includes("--check")) {
  if (problems.length > 0) {
    console.error("Nicht vertraegliche oder unbekannte Lizenzen:")
    for (const [id, meta] of problems) console.error(`  ${id}  ${meta.license}`)
    process.exit(1)
  }
  console.log(`OK — ${sorted.length} Pakete, alle Lizenzen GPLv3-vertraeglich.`)
} else if (outIndex !== -1 && process.argv[outIndex + 1]) {
  fs.writeFileSync(process.argv[outIndex + 1], output)
  console.log(`${sorted.length} Pakete nach ${process.argv[outIndex + 1]} geschrieben.`)
} else {
  console.log(output)
}
