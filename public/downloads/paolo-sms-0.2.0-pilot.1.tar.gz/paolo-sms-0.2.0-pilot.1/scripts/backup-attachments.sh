#!/bin/sh
# Sicherung und Wiederherstellung der lokalen Anhaenge (STORAGE_PROVIDER=local).
# Laeuft im App-Container (busybox sh, age und tar sind im Image):
#
#   sh /app/scripts/backup-attachments.sh create [--db-backup <backup-id>]
#   sh /app/scripts/backup-attachments.sh list
#   sh /app/scripts/backup-attachments.sh verify  <archiv-id> --identity <datei>
#   sh /app/scripts/backup-attachments.sh restore <archiv-id> --identity <datei> [--replace]
#
# Ergebnis: $BACKUP_DIR/attachments/<archiv-id>.tar.age und <archiv-id>.manifest.json.
# Das Archiv ist mit denselben age-Empfaengern verschluesselt wie die
# Datenbank-Backups (BACKUP_AGE_RECIPIENTS). Das Manifest wird zuletzt geschrieben;
# nur Archive mit Manifest gelten als vollstaendig. Die Anhaenge liegen in einem
# Unterverzeichnis, damit die Aufbewahrungsregel der Datenbank-Backups sie nicht
# beruehrt. Konzept und Reihenfolge: docs/backup-restore.md.
set -eu
umask 077

storage_dir=${LOCAL_STORAGE_DIR:-/app/storage}
backup_root=${BACKUP_DIR:-/app/backups}
att_dir="$backup_root/attachments"

die() {
  echo "[backup-attachments] $*" >&2
  exit 1
}

require_local() {
  [ "${STORAGE_PROVIDER:-vercel-blob}" = "local" ] ||
    die "STORAGE_PROVIDER ist nicht 'local'. Anhaenge in Vercel Blob sichert dieses Werkzeug nicht."
}

valid_archive_id() {
  case $1 in
    attachments-[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]T[0-9][0-9][0-9][0-9][0-9][0-9]Z) return 0 ;;
    *) return 1 ;;
  esac
}

# Liest einen Wert aus dem Manifest (ein Schluessel je Zeile).
manifest_value() {
  sed -n "s/^  \"$2\": \"\{0,1\}\([^\",]*\)\"\{0,1\},\{0,1\}\$/\1/p" "$1" | head -n 1
}

# Anzahl der Dateien und Summe der Bytes unterhalb eines Verzeichnisses.
tree_stats() {
  count=$(find "$1" -type f | wc -l | tr -d ' ')
  bytes=0
  if [ "$count" -gt 0 ]; then
    bytes=$(find "$1" -type f -exec wc -c {} + | awk 'NF==2 && $2=="total" {next} {s+=$1} END {print s+0}')
  fi
}

cmd_create() {
  require_local
  db_backup=""
  while [ $# -gt 0 ]; do
    case $1 in
      --db-backup) db_backup=${2:-}; shift 2 ;;
      *) die "Unbekannte Option: $1" ;;
    esac
  done
  if [ -n "$db_backup" ]; then
    case $db_backup in
      [0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f]-*) ;;
      *) die "Ungueltige Backup-ID: $db_backup" ;;
    esac
  fi
  [ -d "$storage_dir" ] || die "Speicherverzeichnis fehlt: $storage_dir"
  [ -n "${BACKUP_AGE_RECIPIENTS:-}" ] || die "BACKUP_AGE_RECIPIENTS ist nicht gesetzt."

  set --
  for recipient in $(printf '%s' "$BACKUP_AGE_RECIPIENTS" | tr ',' ' '); do
    set -- "$@" -r "$recipient"
  done

  mkdir -p "$att_dir"
  ts=$(date -u +%Y%m%dT%H%M%SZ)
  id="attachments-$ts"
  list="$att_dir/.$id.list.tmp"
  tmp="$att_dir/.$id.tar.age.tmp"
  tmp_manifest="$att_dir/.$id.manifest.tmp"
  trap 'rm -f "$list" "$tmp" "$tmp_manifest"' EXIT

  # Feste Dateiliste: Das Manifest beschreibt genau das, was im Archiv liegt.
  (cd "$storage_dir" && find . -type f) >"$list"
  file_count=$(wc -l <"$list" | tr -d ' ')
  total_bytes=0
  if [ "$file_count" -gt 0 ]; then
    total_bytes=$(cd "$storage_dir" && tr '\n' '\0' <"$list" | xargs -0 wc -c | awk 'NF==2 && $2=="total" {next} {s+=$1} END {print s+0}')
  fi

  # Ohne pipefail sieht die Shell nur den Status von age. Schlaegt tar fehl (zum
  # Beispiel bei einer nicht lesbaren Datei), waere das Archiv unvollstaendig und
  # trotzdem "erfolgreich": deshalb den Status von tar getrennt festhalten.
  tar_status="$att_dir/.$id.tar-status.tmp"
  trap 'rm -f "$list" "$tmp" "$tmp_manifest" "$tar_status"' EXIT
  if [ "$file_count" -eq 0 ]; then
    # Leerer Anhangsspeicher (Erstzustand): tar weigert sich, ein leeres Archiv zu schreiben.
    # Ein gueltiges leeres tar-Archiv besteht aus Nullbloecken.
    head -c 10240 /dev/zero | age "$@" -o "$tmp"
  else
    # set +e: Der Status von tar soll auch bei einem Fehler in die Datei gelangen.
    (set +e; tar -C "$storage_dir" -cf - -T "$list"; echo $? >"$tar_status") | age "$@" -o "$tmp"
    [ "$(cat "$tar_status")" = "0" ] || die "tar konnte nicht alle Dateien lesen; es wurde kein Archiv angelegt."
  fi

  archive_sha=$(sha256sum "$tmp" | cut -d' ' -f1)
  archive_size=$(wc -c <"$tmp" | tr -d ' ')
  paolo_version=$(node -p "require('/app/package.json').version" 2>/dev/null || echo unbekannt)
  latest_migration=$(ls /app/drizzle/*.sql 2>/dev/null | sort | tail -n 1 | sed 's#.*/##; s#\.sql$##')

  {
    printf '{\n'
    printf '  "format": "paolo-attachments-tar-age",\n'
    printf '  "formatVersion": 1,\n'
    printf '  "archiveId": "%s",\n' "$id"
    printf '  "createdAt": "%s",\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    printf '  "dbBackupId": "%s",\n' "$db_backup"
    printf '  "fileCount": %s,\n' "$file_count"
    printf '  "totalBytes": %s,\n' "$total_bytes"
    printf '  "archiveSize": %s,\n' "$archive_size"
    printf '  "archiveSha256": "%s",\n' "$archive_sha"
    printf '  "paoloVersion": "%s",\n' "$paolo_version"
    printf '  "latestMigration": "%s"\n' "$latest_migration"
    printf '}\n'
  } >"$tmp_manifest"

  mv "$tmp" "$att_dir/$id.tar.age"
  mv "$tmp_manifest" "$att_dir/$id.manifest.json"
  echo "Anhaenge gesichert: $id ($file_count Dateien, $total_bytes Bytes)"
  echo "ATTACHMENTS_ID=$id"
}

cmd_list() {
  [ -d "$att_dir" ] || { echo "Keine Anhangsarchive vorhanden."; return 0; }
  found=0
  for m in "$att_dir"/*.manifest.json; do
    [ -f "$m" ] || continue
    found=1
    printf '%s  erstellt %s  DB-Backup %s  %s Dateien\n' \
      "$(manifest_value "$m" archiveId)" "$(manifest_value "$m" createdAt)" \
      "$(manifest_value "$m" dbBackupId)" "$(manifest_value "$m" fileCount)"
  done
  [ "$found" -eq 1 ] || echo "Keine Anhangsarchive vorhanden."
}

# Entschluesselt, prueft und entpackt nach $1 (Verzeichnis).
extract_checked() {
  target=$1
  id=$2
  identity=$3
  valid_archive_id "$id" || die "Ungueltige Archiv-ID: $id"
  manifest="$att_dir/$id.manifest.json"
  archive="$att_dir/$id.tar.age"
  [ -f "$manifest" ] && [ -f "$archive" ] || die "Archiv oder Manifest fehlt: $id"
  [ -n "$identity" ] && [ -r "$identity" ] || die "Identitaetsdatei fehlt oder ist nicht lesbar (--identity)."

  expected_sha=$(manifest_value "$manifest" archiveSha256)
  actual_sha=$(sha256sum "$archive" | cut -d' ' -f1)
  [ "$expected_sha" = "$actual_sha" ] || die "Pruefsumme des Archivs stimmt nicht mit dem Manifest ueberein."

  plain="$att_dir/.$id.plain.$$.tmp"
  names="$att_dir/.$id.names.$$.tmp"
  trap 'rm -rf "$plain" "$names" "$cleanup_dir"' EXIT
  age -d -i "$identity" -o "$plain" "$archive" || die "Entschluesselung fehlgeschlagen (falsche Identitaet oder beschaedigtes Archiv)."

  # Nur regulaere Dateien und Verzeichnisse, keine absoluten oder aufwaerts fuehrenden Pfade.
  if tar -tvf "$plain" | cut -c1 | grep -qv '^[-d]$'; then
    die "Archiv enthaelt andere Eintraege als Dateien und Verzeichnisse."
  fi
  tar -tf "$plain" >"$names"
  while IFS= read -r name; do
    case $name in
      /* | .. | ../* | */.. | */../*) die "Archiv enthaelt einen unzulaessigen Pfad: $name" ;;
    esac
  done <"$names"

  mkdir -p "$target"
  tar -xf "$plain" -C "$target"
  rm -f "$plain" "$names"

  tree_stats "$target"
  [ "$count" = "$(manifest_value "$manifest" fileCount)" ] ||
    die "Dateianzahl nach dem Entpacken ($count) weicht vom Manifest ab."
  [ "$bytes" = "$(manifest_value "$manifest" totalBytes)" ] ||
    die "Gesamtgroesse nach dem Entpacken ($bytes) weicht vom Manifest ab."
}

parse_identity_args() {
  identity=""
  replace=0
  while [ $# -gt 0 ]; do
    case $1 in
      --identity) identity=${2:-}; shift 2 ;;
      --identity=*) identity=${1#--identity=}; shift ;;
      --replace) replace=1; shift ;;
      *) die "Unbekannte Option: $1" ;;
    esac
  done
}

cleanup_dir=""

cmd_verify() {
  id=${1:-}
  [ -n "$id" ] || die "Archiv-ID fehlt."
  shift
  parse_identity_args "$@"
  cleanup_dir="$att_dir/.verify.$$"
  extract_checked "$cleanup_dir" "$id" "$identity"
  echo "Archiv $id ist unversehrt und vollstaendig ($count Dateien, $bytes Bytes)."
}

cmd_restore() {
  require_local
  id=${1:-}
  [ -n "$id" ] || die "Archiv-ID fehlt."
  shift
  parse_identity_args "$@"
  mkdir -p "$storage_dir"
  if [ -n "$(find "$storage_dir" -mindepth 1 -maxdepth 1 2>/dev/null | head -n 1)" ]; then
    [ "$replace" -eq 1 ] || die "Speicherverzeichnis ist nicht leer ($storage_dir). Mit --replace ersetzen oder ein leeres Ziel verwenden."
    find "$storage_dir" -mindepth 1 -delete
  fi
  extract_checked "$storage_dir" "$id" "$identity"
  echo "Anhaenge wiederhergestellt: $id ($count Dateien, $bytes Bytes) nach $storage_dir"
}

command=${1:-}
if [ $# -gt 0 ]; then shift; fi
case $command in
  create) cmd_create "$@" ;;
  list) cmd_list ;;
  verify) cmd_verify "$@" ;;
  restore) cmd_restore "$@" ;;
  *) die "Aufruf: create [--db-backup <id>] | list | verify <id> --identity <datei> | restore <id> --identity <datei> [--replace]" ;;
esac
