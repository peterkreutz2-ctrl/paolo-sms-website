import { spawn } from "node:child_process"
import { createRequire } from "node:module"
import { fileURLToPath } from "node:url"

const buildSafeBetterAuthSecret =
  "build-time-only-better-auth-placeholder-9f4d7c2b1a0e6f8c3d5b7a9e1f2c4d6b"

const env = {
  ...process.env,
}

env.BETTER_AUTH_SECRET ??= env.AUTH_SECRET ?? buildSafeBetterAuthSecret

const require = createRequire(import.meta.url)
const nextCli = require.resolve("next/dist/bin/next")

const child = spawn(process.execPath, [nextCli, "build"], {
  env,
  stdio: "inherit",
  shell: false,
})

child.on("exit", (code, signal) => {
  if (signal) {
    process.kill(process.pid, signal)
    return
  }

  if (code !== 0) {
    process.exit(code ?? 1)
    return
  }

  const utilityBuild = spawn(
    process.execPath,
    [fileURLToPath(new URL("./build-initialize.mjs", import.meta.url))],
    { env, stdio: "inherit", shell: false }
  )
  utilityBuild.on("exit", (utilityCode, utilitySignal) => {
    if (utilitySignal) {
      process.kill(process.pid, utilitySignal)
      return
    }
    process.exit(utilityCode ?? 1)
  })
})
