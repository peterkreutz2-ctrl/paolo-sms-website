// scripts/redact-anonymized-report-audit-logs.ts
//
// Einmaliges, manuell auszufuehrendes Wartungsskript (Arbeitspaket 2 des
// DSGVO-Retention-Plans, docs bzw. .claude/plans): redigiert historische
// audit_logs-Klartext-Reste (REPORT_CORE_UPDATED / REPORT_REPORTER_INFO_UPDATED)
// fuer Reports, die bereits VOR der Audit-Log-Haertung (Arbeitspaket 1)
// anonymisiert wurden. Ab Arbeitspaket 1 entsteht dieser Klartext fuer neu
// anonymisierte Reports nicht mehr — dieses Skript adressiert ausschliesslich
// den historischen Altbestand.
//
// Aufruf (TypeScript, via tsx):
//   npx tsx scripts/redact-anonymized-report-audit-logs.ts
//
// Idempotent: ein erneuter Lauf redigiert nur noch tatsaechlich vorhandene
// Klartext-Reste (0, wenn bereits alles bereinigt ist) und schreibt dann auch
// keinen weiteren Audit-Nachweis mehr. Kein Dry-Run-Modus noetig, da die
// Aktion selbst keine Inhalte loescht, sondern nur bereits unbeabsichtigt
// gespeicherte personenbezogene Klartextwerte durch Feldnamen/Metadaten
// ersetzt — dieselbe Redaktionslogik, die seit Arbeitspaket 1 bei jeder
// laufenden Anonymisierung automatisch greift.
//
// Jeder tatsaechlich bereinigte Report erhaelt einen eigenen
// Audit-Nachweis-Eintrag (REPORT_ANONYMIZED, changes.source =
// "backfill_script"), atomar zusammen mit der jeweiligen Redaktion.
//
// Kein automatischer/geplanter Aufruf — bewusst manuell auszufuehren, analog
// zur "kein Massenprozess ohne bewusste Ausloesung"-Philosophie dieses
// Projekts. Nutzt den ueber lib/db konfigurierten Standard-DATABASE_URL.

import { redactAnonymizedReportAuditLogs } from "../lib/audit"

async function main(): Promise<void> {
  console.log("\n" + "═".repeat(60))
  console.log("  Audit-Log-Redaktion fuer bereits anonymisierte Reports")
  console.log("═".repeat(60))

  const summary = await redactAnonymizedReportAuditLogs()

  console.log(`  Reports geprueft:              ${summary.reportsChecked}`)
  console.log(`  Reports bereinigt:             ${summary.reportsRedacted}`)
  console.log(`  Audit-Log-Eintraege redigiert: ${summary.auditLogEntriesRedacted}`)
  console.log("═".repeat(60))

  if (summary.reportsRedacted === 0) {
    console.log("  Keine Aenderungen noetig — bereits vollstaendig bereinigt.")
  } else {
    console.log("  ✅  Bereinigung abgeschlossen.")
  }
}

main().catch((error) => {
  console.error("\nFATAL:", error)
  process.exit(1)
})
