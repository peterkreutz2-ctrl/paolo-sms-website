import { config } from "dotenv"

// Achtung: Dieses Skript lädt bewusst .env.local (Host-Workflow).
// Für Docker-Compose-Bootstrap (lokale Container-DB) die SQL-Schritte aus
// docs/docker-setup.md Abschnitt 6.2 direkt im db-Container verwenden.
config({ path: ".env.local" })

import { db } from "../lib/db"
import { organizations } from "../lib/db/schema"

async function main() {
  const result = await db
    .insert(organizations)
    .values({
      name: "Testorganisation",
      type: "flight_school",
    })
    .returning()

  console.log("Seed organization created:")
  console.log(result)
}

main()
  .then(() => {
    console.log("Seed completed")
    process.exit(0)
  })
  .catch((error) => {
    console.error("Seed failed")
    console.error(error)
    process.exit(1)
  })