import { homedir } from "node:os"
import { lstat, mkdir, open, readdir, realpath, rm } from "node:fs/promises"
import path from "node:path"

import { createDemoSeedQueries, DEMO_FIXTURE_VERSION } from "./operator-data-fixtures.mjs"

/**
 * @typedef {{
 *   listBlobs: (input: { prefix: string, cursor?: string }) => Promise<{
 *     blobs: Array<{ pathname: string }>, hasMore: boolean, cursor?: string
 *   }>,
 *   deleteBlob: (paths: string[]) => Promise<unknown>
 * }} BlobApi
 */

export const OPERATOR_DATA_VERSION = 1
export const OPERATOR_DATA_LOCK_ID = 70651072

const REQUIRED_TABLES = [
  "organizations", "roles", "user_roles", "reports", "measures", "attachments",
  "report_notes", "report_retention_reviews", "audit_logs", "safety_meetings",
  "organization_legal_settings", "privacy_incidents", "sms_documents",
  "public_report_rate_limits", "backup_cron_state", "better_auth_users",
  "better_auth_accounts", "better_auth_sessions", "better_auth_verifications",
]

const SEED_GUARD_TABLES = [
  "reports", "measures", "attachments", "report_notes", "report_retention_reviews",
  "safety_meetings", "privacy_incidents", "sms_documents",
]

const LOCK_TABLES = [
  "audit_logs", "report_retention_reviews", "report_notes", "attachments", "measures",
  "safety_meetings", "public_report_rate_limits", "reports", "privacy_incidents",
  "sms_documents", "organization_legal_settings", "backup_cron_state",
  "better_auth_sessions", "better_auth_verifications", "organizations",
]

export class OperatorDataError extends Error {
  constructor(message, code = "operator_data_error") {
    super(message)
    this.name = "OperatorDataError"
    this.code = code
  }
}

function quoteIdentifier(value) {
  if (!/^[a-z_]+$/.test(value)) throw new OperatorDataError("Ungültiger Tabellenname.")
  return `"${value}"`
}

export function parseOperatorArguments(argv) {
  const command = argv[0]
  if (command !== "seed" && command !== "reset") {
    throw new OperatorDataError("Erwartet wird der Unterbefehl seed oder reset.", "invalid_arguments")
  }
  const values = {}
  let execute = false
  for (const argument of argv.slice(1)) {
    if (argument === "--execute") {
      if (execute) throw new OperatorDataError("Argument doppelt angegeben: --execute", "invalid_arguments")
      execute = true
      continue
    }
    const match = /^--([a-z-]+)=(.*)$/.exec(argument)
    if (!match || !["confirm-database", "confirm-organization-id", "admin-user-id"].includes(match[1])) {
      throw new OperatorDataError(`Unbekanntes Argument: ${argument}`, "invalid_arguments")
    }
    if (values[match[1]] !== undefined) {
      throw new OperatorDataError(`Argument doppelt angegeben: --${match[1]}`, "invalid_arguments")
    }
    values[match[1]] = match[2]
  }
  return { command, execute, values }
}

export function databaseDisplayTarget(connectionString) {
  if (!connectionString?.trim()) throw new OperatorDataError("DATABASE_URL ist nicht gesetzt.", "missing_database_url")
  const url = new URL(connectionString)
  if (url.protocol !== "postgres:" && url.protocol !== "postgresql:") {
    throw new OperatorDataError("DATABASE_URL ist keine PostgreSQL-URL.", "invalid_database_url")
  }
  const database = decodeURIComponent(url.pathname.replace(/^\//, ""))
  if (!database) throw new OperatorDataError("DATABASE_URL enthält keinen Datenbanknamen.", "invalid_database_url")
  return {
    host: url.port ? `${url.hostname}:${url.port}` : url.hostname,
    database,
  }
}

export function requireExecutionConfirmation({ values, database, organizationId }) {
  if (!values["admin-user-id"]?.trim()) {
    throw new OperatorDataError("Für die Ausführung fehlt --admin-user-id.", "confirmation_failed")
  }
  if (values["confirm-database"] !== database) {
    throw new OperatorDataError("Datenbankbestätigung stimmt nicht überein.", "confirmation_failed")
  }
  if (values["confirm-organization-id"] !== organizationId) {
    throw new OperatorDataError("Organisationsbestätigung stimmt nicht überein.", "confirmation_failed")
  }
  return values["admin-user-id"].trim()
}

async function requireSchema(client) {
  const result = await client.query(
    "SELECT name, to_regclass('public.' || name) IS NOT NULL AS present FROM unnest($1::text[]) AS name",
    [REQUIRED_TABLES],
  )
  const missing = result.rows.filter((row) => !row.present).map((row) => row.name)
  if (missing.length > 0) {
    throw new OperatorDataError(`Datenbankschema unvollständig; fehlend: ${missing.join(", ")}.`, "schema_incomplete")
  }
}

async function readSingleOrganization(client) {
  const result = await client.query("SELECT id, name, type FROM organizations ORDER BY created_at")
  if (result.rowCount !== 1) {
    throw new OperatorDataError(`Operator-Werkzeug erwartet genau eine Organisation; gefunden: ${result.rowCount}.`, "organization_count")
  }
  return result.rows[0]
}

async function readGlobalAdmins(client) {
  const result = await client.query(`
    SELECT DISTINCT ur.clerk_user_id
    FROM user_roles ur
    JOIN roles r ON r.id = ur.role_id
    WHERE r.key = 'admin' AND ur.organization_id IS NULL
    ORDER BY ur.clerk_user_id
  `)
  return result.rows.map((row) => row.clerk_user_id)
}

async function requireGlobalAdmin(client, userId) {
  const result = await client.query(`
    SELECT 1
    FROM user_roles ur
    JOIN roles r ON r.id = ur.role_id
    WHERE ur.clerk_user_id = $1 AND r.key = 'admin' AND ur.organization_id IS NULL
    LIMIT 1
  `, [userId])
  if (result.rowCount !== 1) {
    throw new OperatorDataError("Die angegebene Benutzer-ID besitzt keine globale Administratorrolle.", "admin_required")
  }
}

async function requireAttachmentProvider(client, storageProvider) {
  const expected = storageProvider === "local"
    ? "local_file"
    : storageProvider === "vercel-blob"
      ? "vercel_blob"
      : null
  if (!expected) throw new OperatorDataError(`Unbekannter STORAGE_PROVIDER: ${storageProvider}`, "storage_provider")
  const result = await client.query(
    "SELECT DISTINCT storage_provider FROM attachments WHERE storage_provider <> $1 ORDER BY storage_provider",
    [expected],
  )
  if (result.rowCount > 0) {
    throw new OperatorDataError(
      `Attachment-Datensätze verwenden einen anderen oder unbekannten Provider: ${result.rows.map((row) => row.storage_provider).join(", ")}.`,
      "storage_provider_mismatch",
    )
  }
}

async function tableCounts(client, tables) {
  const counts = {}
  for (const table of tables) {
    const result = await client.query(`SELECT count(*)::int AS count FROM ${quoteIdentifier(table)}`)
    counts[table] = result.rows[0].count
  }
  return counts
}

async function readOtherConnections(client) {
  const result = await client.query(`
    SELECT pid, application_name, usename, state
    FROM pg_stat_activity
    WHERE datname = current_database() AND pid <> pg_backend_pid()
      AND backend_type = 'client backend'
    ORDER BY pid
  `)
  return result.rows
}

function connectionValue(value) {
  return JSON.stringify(value === null || value === "" ? "<nicht gesetzt>" : String(value))
}

export function formatConnectionDetails(connections) {
  return connections.map((connection) => (
    `pid=${connection.pid}, application_name=${connectionValue(connection.application_name)}, ` +
    `usename=${connectionValue(connection.usename)}, state=${connectionValue(connection.state)}`
  ))
}

export function requireNoOtherConnections(connections) {
  if (connections.length === 0) return
  const details = formatConnectionDetails(connections).map((line) => `  ${line}`).join("\n")
  throw new OperatorDataError(
    `Es bestehen ${connections.length} weitere Datenbankverbindung(en):\n${details}\n` +
      "App und Jobs stoppen und erneut versuchen.",
    "active_connections",
  )
}

export async function inspectOperatorDatabase(client) {
  await requireSchema(client)
  const organization = await readSingleOrganization(client)
  // Ein einzelner pg-Client verarbeitet Abfragen seriell. Explizites await
  // vermeidet die in pg 9 entfernte nebenläufige client.query()-Nutzung.
  const admins = await readGlobalAdmins(client)
  const counts = await tableCounts(client, REQUIRED_TABLES)
  const connections = await readOtherConnections(client)
  const attachmentProviders = await client.query(
    "SELECT storage_provider, count(*)::int AS count FROM attachments GROUP BY storage_provider ORDER BY storage_provider",
  )
  return {
    organization,
    globalAdminIds: admins,
    counts,
    otherConnections: connections.length,
    otherConnectionDetails: connections,
    attachmentProviders: attachmentProviders.rows,
  }
}

async function lockForMutation(client) {
  await client.query("SET LOCAL lock_timeout = '10s'")
  await client.query("SELECT pg_advisory_xact_lock($1)", [OPERATOR_DATA_LOCK_ID])
  await client.query(`LOCK TABLE ${LOCK_TABLES.map(quoteIdentifier).join(", ")} IN ACCESS EXCLUSIVE MODE`)
}

async function ensureNoOtherConnections(client) {
  requireNoOtherConnections(await readOtherConnections(client))
}

export async function seedDemoData(client, { adminUserId, now = new Date() }) {
  await client.query("BEGIN")
  try {
    await lockForMutation(client)
    await requireSchema(client)
    await ensureNoOtherConnections(client)
    const organization = await readSingleOrganization(client)
    await requireGlobalAdmin(client, adminUserId)
    const counts = await tableCounts(client, SEED_GUARD_TABLES)
    const populated = Object.entries(counts).filter(([, count]) => count > 0)
    if (populated.length > 0) {
      throw new OperatorDataError(
        `Spieldaten werden nur in einen fachlich leeren Bestand geladen; befüllt: ${populated.map(([name, count]) => `${name}=${count}`).join(", ")}.`,
        "seed_not_empty",
      )
    }

    const seed = createDemoSeedQueries({ organizationId: organization.id, adminUserId, now })
    for (const query of seed.queries) await client.query(query.text, query.values)
    await client.query("COMMIT")
    return { organization, inserted: seed.inserted, fixtureVersion: DEMO_FIXTURE_VERSION }
  } catch (error) {
    await client.query("ROLLBACK").catch(() => undefined)
    throw error
  }
}

function ensureSafeRoot(candidate, forbidden = []) {
  const resolved = path.resolve(candidate)
  const parsedRoot = path.parse(resolved).root
  const sameOrAncestor = (parent, child) => {
    const relative = path.relative(parent, child)
    return relative === "" || (!relative.startsWith("..") && !path.isAbsolute(relative))
  }
  const dangerous = [parsedRoot, path.resolve(process.cwd()), path.resolve(homedir())]
  if (
    dangerous.some((protectedPath) => sameOrAncestor(resolved, protectedPath)) ||
    forbidden.some((value) => sameOrAncestor(resolved, path.resolve(value)))
  ) {
    throw new OperatorDataError(`Unsicheres Löschziel abgelehnt: ${resolved}`, "unsafe_path")
  }
  return resolved
}

function ensureSeparateRoots(first, second) {
  const firstToSecond = path.relative(first, second)
  const secondToFirst = path.relative(second, first)
  const nested = (relative) => relative === "" || (!relative.startsWith("..") && !path.isAbsolute(relative))
  if (nested(firstToSecond) || nested(secondToFirst)) {
    throw new OperatorDataError(
      `Storage- und Backup-Ziel dürfen nicht identisch oder ineinander verschachtelt sein: ${first}, ${second}`,
      "unsafe_path",
    )
  }
}

async function inventoryDirectory(root, { allowDirectories }) {
  let resolved
  try {
    const rootInfo = await lstat(root)
    if (rootInfo.isSymbolicLink()) throw new OperatorDataError(`Symlink als Löschziel abgelehnt: ${root}`, "unsafe_path")
    if (!rootInfo.isDirectory()) throw new OperatorDataError(`Löschziel ist kein Verzeichnis: ${root}`, "unsafe_path")
    resolved = await realpath(root)
  } catch (error) {
    if (error?.code === "ENOENT") return { root: path.resolve(root), entries: [] }
    throw error
  }
  const entries = await readdir(resolved, { withFileTypes: true })
  for (const entry of entries) {
    if (entry.isSymbolicLink()) throw new OperatorDataError(`Symlink im Löschziel abgelehnt: ${entry.name}`, "unsafe_path")
    if (!allowDirectories && entry.isDirectory()) throw new OperatorDataError(`Unterverzeichnis im Backup-Ziel abgelehnt: ${entry.name}`, "unsafe_path")
  }
  return { root: resolved, entries: entries.map((entry) => ({ name: entry.name, directory: entry.isDirectory() })) }
}

async function countFiles(root, ignoredNames = new Set()) {
  let count = 0
  for (const entry of await readdir(root, { withFileTypes: true })) {
    if (ignoredNames.has(entry.name)) continue
    if (entry.isSymbolicLink()) throw new OperatorDataError(`Symlink im Löschziel abgelehnt: ${entry.name}`, "unsafe_path")
    if (entry.isDirectory()) count += await countFiles(path.join(root, entry.name))
    else if (entry.isFile()) count += 1
    else throw new OperatorDataError(`Unbekannter Dateityp im Löschziel: ${entry.name}`, "unsafe_path")
  }
  return count
}

async function loadBlobApi() {
  const { del, list } = await import("@vercel/blob")
  return { deleteBlob: del, listBlobs: list }
}

/** @param {{ storageProvider: string, localStorageDir: string, backupDir: string, blobApi?: BlobApi }} options */
export async function inspectExternalData({ storageProvider, localStorageDir, backupDir, blobApi }) {
  const safeStorage = ensureSafeRoot(localStorageDir)
  const safeBackup = ensureSafeRoot(backupDir, [safeStorage])
  ensureSeparateRoots(safeStorage, safeBackup)
  const backup = await inventoryDirectory(safeBackup, { allowDirectories: true })
  backup.entries = backup.entries.filter((entry) => entry.name !== ".backup.lock")
  let storageEntries = []
  if (storageProvider === "local") {
    const storage = await inventoryDirectory(safeStorage, { allowDirectories: true })
    storageEntries = storage.entries
  } else if (storageProvider === "vercel-blob") {
    blobApi ??= await loadBlobApi()
    for (const prefix of ["reports/", "sms-documents/"]) {
      let cursor
      do {
        const page = await blobApi.listBlobs({ prefix, cursor })
        storageEntries.push(...page.blobs.map((blob) => ({ name: blob.pathname, directory: false })))
        cursor = page.hasMore ? page.cursor : undefined
      } while (cursor)
    }
  } else {
    throw new OperatorDataError(`Unbekannter STORAGE_PROVIDER: ${storageProvider}`, "storage_provider")
  }
  const storageFileCount = storageProvider === "local" && storageEntries.length > 0
    ? await countFiles(safeStorage)
    : storageEntries.length
  const backupFileCount = backup.entries.length > 0
    ? await countFiles(safeBackup, new Set([".backup.lock"]))
    : 0
  return {
    storageRoot: safeStorage,
    backupRoot: safeBackup,
    storageEntries,
    storageFileCount,
    backupEntries: backup.entries,
    backupFileCount,
  }
}

export function formatExternalPreview(inventory, storageProvider) {
  const storageTarget = storageProvider === "local"
    ? `Attachment-Storage-Verzeichnis (wird geleert): ${inventory.storageRoot}`
    : `Lokales Storage-Verzeichnis (wird nicht geleert): ${inventory.storageRoot}`
  const lines = [
    storageTarget,
    ...(storageProvider === "vercel-blob"
      ? ["Vercel-Blob-Präfixe (werden geleert): reports/, sms-documents/"]
      : []),
    `Backup-Verzeichnis (wird geleert): ${inventory.backupRoot}`,
    `Dateien im Attachment-Storage: ${inventory.storageFileCount}`,
    `Dateien im Backup-Verzeichnis: ${inventory.backupFileCount}`,
  ]
  return lines
}

/** @param {any} inventory @param {{ storageProvider: string, blobApi?: BlobApi }} options */
export async function deleteExternalData(inventory, { storageProvider, blobApi }) {
  if (storageProvider === "local") {
    for (const entry of inventory.storageEntries) {
      await rm(path.join(inventory.storageRoot, entry.name), { recursive: entry.directory, force: true })
    }
  } else {
    blobApi ??= await loadBlobApi()
    const paths = inventory.storageEntries.map((entry) => entry.name)
    for (let index = 0; index < paths.length; index += 100) {
      await blobApi.deleteBlob(paths.slice(index, index + 100))
    }
  }
  for (const entry of inventory.backupEntries) {
    await rm(path.join(inventory.backupRoot, entry.name), { recursive: entry.directory, force: true })
  }
  return {
    attachmentFiles: inventory.storageFileCount,
    backupFiles: inventory.backupFileCount,
  }
}

export async function purgeExternalData(options) {
  const safeStorage = ensureSafeRoot(options.localStorageDir)
  const safeBackup = ensureSafeRoot(options.backupDir, [safeStorage])
  ensureSeparateRoots(safeStorage, safeBackup)
  await mkdir(safeBackup, { recursive: true })
  const backupInfo = await lstat(safeBackup)
  if (backupInfo.isSymbolicLink() || !backupInfo.isDirectory()) {
    throw new OperatorDataError(`Unsicheres Backup-Löschziel abgelehnt: ${safeBackup}`, "unsafe_path")
  }
  const lockPath = path.join(safeBackup, ".backup.lock")
  let handle
  try {
    handle = await open(lockPath, "wx", 0o600)
    await handle.writeFile(`${process.pid}\n${new Date().toISOString()}\n`)
  } catch (error) {
    if (error?.code === "EEXIST") {
      throw new OperatorDataError("Es wird bereits ein Backup erstellt oder bereinigt.", "backup_locked")
    }
    throw error
  }
  try {
    const inventory = await inspectExternalData(options)
    return await deleteExternalData(inventory, options)
  } finally {
    await handle.close().catch(() => undefined)
    await rm(lockPath, { force: true }).catch(() => undefined)
  }
}

export async function resetInstallationData(client, { adminUserId, storageProvider, deleteExternal, now = new Date() }) {
  await client.query("BEGIN")
  try {
    await lockForMutation(client)
    await requireSchema(client)
    await ensureNoOtherConnections(client)
    const organization = await readSingleOrganization(client)
    await requireGlobalAdmin(client, adminUserId)
    await requireAttachmentProvider(client, storageProvider)
    const external = await deleteExternal()

    const deleted = {}
    for (const table of [
      "audit_logs", "report_retention_reviews", "report_notes", "attachments", "measures",
      "safety_meetings", "public_report_rate_limits", "reports", "privacy_incidents",
      "sms_documents", "organization_legal_settings", "backup_cron_state",
      "better_auth_sessions", "better_auth_verifications",
    ]) {
      const result = await client.query(`DELETE FROM ${quoteIdentifier(table)}`)
      deleted[table] = result.rowCount
    }
    await client.query(`
      UPDATE organizations SET
        safety_meeting_interval_months = 12,
        report_retention_review_interval_months = NULL,
        accountable_executive_name = NULL,
        accountable_executive_function = NULL,
        accountable_executive_contact = NULL,
        accountable_executive_term = NULL,
        safety_manager_name = NULL,
        safety_manager_function = NULL,
        safety_manager_contact = NULL,
        safety_manager_term = NULL,
        updated_at = $2
      WHERE id = $1
    `, [organization.id, now])
    await client.query(`
      INSERT INTO audit_logs (organization_id, clerk_user_id, action, resource_type, resource_id, changes, created_at)
      VALUES ($1,$2,'INSTALLATION_DATA_RESET','organization',$1,$3::jsonb,$4)
    `, [organization.id, adminUserId, JSON.stringify({ resetVersion: OPERATOR_DATA_VERSION, deleted, external }), now])
    await client.query("COMMIT")
    return { organization, deleted, external, resetVersion: OPERATOR_DATA_VERSION }
  } catch (error) {
    await client.query("ROLLBACK").catch(() => undefined)
    throw error
  }
}
