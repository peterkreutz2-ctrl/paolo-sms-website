// Baut das Quellpaket paolo-sms-<version>.tar.gz aus einem festen Git-Commit.
//
//   node scripts/release/build-source-package.mjs --commit <ref> [--out-dir dist/release]
//
// Es werden nur Objekte dieses Commits gelesen; lokale Aenderungen und
// unversionierte Dateien beeinflussen das Ergebnis nicht. Der Skriptstand muss
// mit dem Commit uebereinstimmen (siehe source-package-core.mjs). Das Verfahren
// ist in docs/release-package.md beschrieben.

import { mkdirSync, writeFileSync } from "node:fs"
import path from "node:path"
import { fileURLToPath } from "node:url"

import { FILE_LIST_PATH, assertBuilderMatchesCommit, buildSourcePackage, diffFileLists, git, packageFileListText, planPackage, resolveCommit } from "./source-package-core.mjs"

function arg(name) {
  const i = process.argv.indexOf(name)
  return i === -1 ? undefined : process.argv[i + 1]
}

const ref = arg("--commit")
if (!ref) {
  console.error("Aufruf: node scripts/release/build-source-package.mjs --commit <ref> [--out-dir <verzeichnis>] [--since <frueherer-ref>] [--update-file-list]")
  console.error("Der Commit ist Pflicht: Ein Paket entsteht nie aus einem impliziten Stand.")
  process.exit(2)
}

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..")
const repo = git(root, ["rev-parse", "--show-toplevel"]).toString().trim()
const outDir = path.resolve(arg("--out-dir") ?? "dist/release")

// --update-file-list: schreibt die Dateiliste des Commits in das Arbeitsverzeichnis (zur Pruefung und zum Commit).
// --since <ref>: zeigt Dateien, die gegenueber dem Paket dieses frueheren Commits neu sind oder fehlen.
if (process.argv.includes("--update-file-list") || arg("--since")) {
  try {
    const { sha } = resolveCommit(repo, ref)
    assertBuilderMatchesCommit(repo, sha, repo)
    const current = planPackage(repo, sha)
    if (process.argv.includes("--update-file-list")) {
      writeFileSync(path.join(repo, FILE_LIST_PATH), packageFileListText(current.result))
      console.log(`${FILE_LIST_PATH} aktualisiert (${current.result.included.length} Dateien). Aenderungen mit git diff pruefen und committen.`)
    }
    if (arg("--since")) {
      const before = planPackage(repo, resolveCommit(repo, arg("--since")).sha)
      const { added, removed } = diffFileLists(before.result.included, current.result.included)
      console.log(`Paketdateien gegenueber ${arg("--since")}: ${added.length} neu, ${removed.length} entfernt`)
      for (const p of added) console.log(`  + ${p}`)
      for (const p of removed) console.log(`  - ${p}`)
    }
    process.exit(0)
  } catch (error) {
    console.error(error instanceof Error ? error.message : error)
    process.exit(1)
  }
}

let pkg
try {
  pkg = buildSourcePackage({ repo, ref, root: repo })
} catch (error) {
  console.error(error instanceof Error ? error.message : error)
  process.exit(1)
}

mkdirSync(outDir, { recursive: true })
writeFileSync(path.join(outDir, pkg.fileName), pkg.archive)
writeFileSync(path.join(outDir, "SHA256SUMS"), `${pkg.archiveSha256}  ${pkg.fileName}\n`)

console.log(`Paket:      ${path.join(outDir, pkg.fileName)}`)
console.log(`Version:    ${pkg.version}`)
console.log(`Commit:     ${pkg.sha} (${pkg.commitDate})`)
console.log(`SHA-256:    ${pkg.archiveSha256}`)
console.log(`Dateien:    ${pkg.files.length} im Paket, ${pkg.excluded.length} ausgeschlossen`)
if (pkg.brokenLinks.length > 0) {
  console.warn(`Hinweis: ${pkg.brokenLinks.length} relative Markdown-Verweise laufen im Paket ins Leere:`)
  for (const l of pkg.brokenLinks) console.warn(`  ${l.file} -> ${l.target}`)
}
