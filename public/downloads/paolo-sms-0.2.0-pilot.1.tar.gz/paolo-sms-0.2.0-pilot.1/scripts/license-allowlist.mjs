// Lizenzen, die mit GPL-3.0-or-later vertraeglich sind. Gemeinsame Quelle fuer
// scripts/third-party-notices.mjs (installierter Baum) und
// scripts/release/ (Lockfile eines Release-Commits). Neue Eintraege nur nach
// Pruefung ergaenzen.
export const COMPATIBLE = new Set([
  "MIT",
  "ISC",
  "Apache-2.0",
  "BSD-2-Clause",
  "BSD-3-Clause",
  "0BSD",
  "Unlicense",
  "CC0-1.0",
  "CC-BY-4.0",
  "BlueOak-1.0.0",
  "MPL-2.0",
  "Python-2.0",
  "LGPL-3.0-or-later",
  "Apache-2.0 AND LGPL-3.0-or-later",
  // @img/sharp-wasm32 declares all three licenses; reviewed for issue #95.
  "Apache-2.0 AND LGPL-3.0-or-later AND MIT",
  // Zweifache Lizenzierung, beide Alternativen sind GPLv3-vertraeglich (type-fest, geprueft 26.10.2026).
  "(MIT OR CC0-1.0)",
  "GPL-3.0-or-later",
  "GPL-3.0-only",
])
