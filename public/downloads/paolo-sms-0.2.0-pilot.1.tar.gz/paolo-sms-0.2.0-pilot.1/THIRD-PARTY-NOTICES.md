# Third-party notices

PAOLO SMS steht unter GPL-3.0-or-later (siehe [`LICENSE`](LICENSE) und
[`NOTICE`](NOTICE)). Die Anwendung nutzt Pakete aus dem npm-Ökosystem, die
unter eigenen Lizenzen stehen.

## Stand der Prüfung

Der vollständige installierte Baum wurde geprüft: **818 Pakete, keines ohne
Lizenzangabe, keines GPLv3-unverträglich.**

| Lizenz | Pakete |
|---|---:|
| MIT | 723 |
| Apache-2.0 | 34 |
| ISC | 28 |
| BSD-2-Clause | 14 |
| BSD-3-Clause | 8 |
| MPL-2.0 | 3 |
| BlueOak-1.0.0 | 2 |
| Apache-2.0 AND LGPL-3.0-or-later | 1 |
| Python-2.0 | 1 |
| CC-BY-4.0 | 1 |
| Unlicense | 1 |
| CC0-1.0 | 1 |
| 0BSD | 1 |

Seit diesem Prüfstand enthält der Lockfile-Baum zusätzlich
`@img/sharp-wasm32@0.35.5` mit
`Apache-2.0 AND LGPL-3.0-or-later AND MIT`. Der SPDX-Ausdruck wurde für Issue
#95 geprüft und als mit GPL-3.0-or-later verträglich bestätigt. Das optionale
Paket wird nur über plattformspezifische Sharp-Abhängigkeiten installiert;
wenn es im Zielsystem installiert ist, nimmt der Generator auch
`node_modules/@img/sharp-wasm32/LICENSE` in die Paketliste auf.

Einordnungen, die nicht selbsterklärend sind:

- **Apache-2.0** ist mit GPLv3 verträglich, mit GPLv2 nicht. Das ist einer der
  Gründe, warum GPLv3 und nicht GPLv2 gewählt wurde — `drizzle-orm`,
  `@vercel/blob` und `typescript` stehen unter Apache-2.0.
- **LGPL-3.0-or-later** betrifft `@img/sharp-*` (libvips) im Produktionsbaum
  über `next`. Verträglich, aber die LGPL-Hinweise müssen bei der Weitergabe
  eines Bundles erhalten bleiben.

## Wann eine Liste nötig ist

Der reine Betrieb einer Installation ist kein Conveying und löst keine
Hinweispflicht aus. Sobald ein **Build-Artefakt weitergegeben** wird — ein
Standalone-Next.js-Build oder ein Docker-Image, das `node_modules` enthält —
müssen die Hinweise der mitgelieferten Pakete erhalten bleiben.

## Liste erzeugen

Die Paketliste ist bewusst **nicht** eingecheckt: Sie veraltet mit jedem
Dependency-Update und wäre dann falscher als keine Liste. Sie wird aus dem
tatsächlich installierten Baum erzeugt:

```bash
npm run licenses:notices -- --out THIRD-PARTY-LIST.md   # Liste für ein Release
npm run licenses:check                                  # nur prüfen
```

`licenses:check` meldet mit Exit-Code 1, wenn ein Paket ohne Lizenzangabe oder
mit einer nicht als GPLv3-verträglich hinterlegten Lizenz auftaucht. Die
Positivliste steht in [`scripts/third-party-notices.mjs`](scripts/third-party-notices.mjs)
und ist nur nach Prüfung zu erweitern.

Die vollständigen Lizenztexte liegen in den jeweiligen Paketverzeichnissen
unter `node_modules/` und gehen mit einem Bundle ohnehin mit.

Ein **Quellpaket** enthält kein `node_modules/`. Sein Build erzeugt stattdessen
`THIRD-PARTY-LIST.md` aus dem `package-lock.json` desselben Commits und bricht
bei einer Lizenz außerhalb der Positivliste ab (siehe
[`docs/release-package.md`](docs/release-package.md)).
